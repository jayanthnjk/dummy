package com.policescheduler.report.generator;

import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.policescheduler.entity.Personnel;
import com.policescheduler.report.PdfReportGenerator;
import com.policescheduler.report.PdfStyleHelper;
import com.policescheduler.report.ReportGenerationException;
import com.policescheduler.report.ReportLocalizationService;
import com.policescheduler.report.ReportRequest;
import com.policescheduler.repository.PersonnelRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class PersonnelListReportGenerator implements PdfReportGenerator {

    private static final Logger log = LoggerFactory.getLogger(PersonnelListReportGenerator.class);

    private static final Color HEADER_BG = new Color(211, 211, 211);
    private static final Font HEADER_FONT = new Font(Font.HELVETICA, 8, Font.BOLD, Color.BLACK);
    private static final Font CELL_FONT = new Font(Font.HELVETICA, 7.5f, Font.NORMAL, Color.BLACK);
    private static final Font TITLE_FONT = new Font(Font.HELVETICA, 12, Font.BOLD, Color.BLACK);

    private static final String REPORT_TITLE = "CITY ARMED RESERVE MANGALURU (C.A.R COMPANY) Personnel List";
    private static final String UNIT_NAME = "CAR MANGALURU CITY";

    // Designation priority order for sorting
    private static final Map<String, Integer> DESIGNATION_PRIORITY = Map.of(
            "DCP", 1,
            "ACP", 2,
            "RPI", 3,
            "RSI", 4,
            "ARSI", 5,
            "AHC", 6,
            "APC", 7
    );

    private final PersonnelRepository personnelRepository;
    private final PdfStyleHelper pdfStyleHelper;
    private final ReportLocalizationService localizationService;

    public PersonnelListReportGenerator(PersonnelRepository personnelRepository,
                                         PdfStyleHelper pdfStyleHelper,
                                         ReportLocalizationService localizationService) {
        this.personnelRepository = personnelRepository;
        this.pdfStyleHelper = pdfStyleHelper;
        this.localizationService = localizationService;
    }

    @Override
    public String getReportType() {
        return "personnel_list";
    }

    @Override
    public byte[] generate(ReportRequest request) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            Document document = new Document(PageSize.A4, 20, 20, 20, 20);
            PdfWriter.getInstance(document, baos);
            document.open();

            // Title
            Paragraph title = new Paragraph(REPORT_TITLE, TITLE_FONT);
            title.setAlignment(Element.ALIGN_CENTER);
            title.setSpacingAfter(10);
            document.add(title);

            // Fetch all active CAR unit personnel only
            List<Personnel> allPersonnel = personnelRepository.findAll().stream()
                    .filter(p -> Boolean.TRUE.equals(p.getIsActive()))
                    .filter(p -> "CAR".equalsIgnoreCase(p.getUnit()))
                    .collect(Collectors.toList());

            // Sort by designation priority, then by badge_id ascending within each designation
            allPersonnel.sort(Comparator
                    .<Personnel, Integer>comparing(p -> 
                            DESIGNATION_PRIORITY.getOrDefault(
                                    p.getDesignation() != null ? p.getDesignation().toUpperCase() : "", 99))
                    .thenComparing(p -> p.getBadgeId() != null ? p.getBadgeId() : ""));

            // Table: SL NO. | UNIT NAME | NAME | DESIG | METAL No. | MOBILE No.
            int numCols = 6;
            PdfPTable table = new PdfPTable(numCols);
            table.setWidthPercentage(100);
            table.setWidths(new float[]{6, 20, 28, 8, 10, 14});

            // Column headers
            String[] headers = {"SL NO.", "UNIT NAME", "NAME", "DESIG", "METAL No.", "MOBILE No."};
            for (String header : headers) {
                PdfPCell headerCell = new PdfPCell(new Phrase(header, HEADER_FONT));
                headerCell.setBackgroundColor(HEADER_BG);
                headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                headerCell.setPadding(3);
                table.addCell(headerCell);
            }

            // Data rows
            int slNo = 1;
            for (Personnel p : allPersonnel) {
                table.addCell(createDataCell(String.valueOf(slNo++), Element.ALIGN_CENTER));
                table.addCell(createDataCell(UNIT_NAME, Element.ALIGN_LEFT));
                table.addCell(createDataCell(safe(p.getPersonName()), Element.ALIGN_LEFT));
                table.addCell(createDataCell(safe(p.getDesignation()), Element.ALIGN_LEFT));
                table.addCell(createDataCell(extractMetalNumber(p.getBadgeId()), Element.ALIGN_CENTER));
                table.addCell(createDataCell(safe(p.getPhoneNumber()), Element.ALIGN_CENTER));
            }

            if (allPersonnel.isEmpty()) {
                PdfPCell noDataCell = new PdfPCell(new Phrase("No personnel found", CELL_FONT));
                noDataCell.setColspan(numCols);
                noDataCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                noDataCell.setPadding(8);
                table.addCell(noDataCell);
            }

            document.add(table);
            document.close();
            return baos.toByteArray();
        } catch (Exception e) {
            log.error("Failed to generate personnel list report", e);
            throw new ReportGenerationException("personnel_list",
                    "Failed to generate personnel list report", e);
        }
    }

    /**
     * Extracts the metal number from a badge ID.
     * Rules:
     * - If badge_id contains "AUTO" → return "-"
     * - If badge_id doesn't contain a "-" with a number after it → return "-"
     * - Otherwise extract number after last dash (e.g., "AHC-127" → "127", "APC-2539" → "2539")
     */
    private String extractMetalNumber(String badgeId) {
        if (badgeId == null || badgeId.isBlank()) {
            return "-";
        }
        if (badgeId.toUpperCase().contains("AUTO")) {
            return "-";
        }
        int lastDash = badgeId.lastIndexOf('-');
        if (lastDash < 0 || lastDash >= badgeId.length() - 1) {
            return "-";
        }
        String afterDash = badgeId.substring(lastDash + 1);
        // Check if it's a valid number
        try {
            Integer.parseInt(afterDash);
            return afterDash;
        } catch (NumberFormatException e) {
            return "-";
        }
    }

    private PdfPCell createDataCell(String text, int alignment) {
        PdfPCell cell = new PdfPCell(new Phrase(text, CELL_FONT));
        cell.setHorizontalAlignment(alignment);
        cell.setPadding(2);
        return cell;
    }

    private String safe(String value) {
        return value != null ? value : "";
    }
}

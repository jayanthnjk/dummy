import { makeAutoObservable, runInAction } from 'mobx';
import type {
  ViewMode,
  DateRange,
  TeamMemberSchedule,
  OpenShift,
  ShiftType,
  CreateShiftRequest,
} from '../types/schedule';
import {
  getWeekRange,
  getDayRange,
  getMonthRange,
  navigateNext,
  navigatePrev,
  navigateToday,
  getDayColumns,
} from '../utils/dateNavigation';
import { filterByGroup, filterBySearch } from '../utils/scheduleFilters';
import { scheduleService } from '../services/scheduleService';

class ScheduleStore {
  // View state
  viewMode: ViewMode = 'week';
  currentDate: Date = new Date();
  groupFilter: string = 'all';
  searchQuery: string = '';
  showOpenShifts: boolean = true;
  showTimeOff: boolean = true;

  // Data
  teamMembers: TeamMemberSchedule[] = [];
  openShifts: OpenShift[] = [];
  shiftTypes: ShiftType[] = [];
  groups: string[] = [];

  // UI state
  loading: boolean = false;
  error: string | null = null;
  createDialogOpen: boolean = false;
  createDialogMemberId: number | null = null;
  createDialogDate: string | null = null;

  constructor() {
    makeAutoObservable(this);
  }

  // Computed: date range based on viewMode and currentDate
  get dateRange(): DateRange {
    switch (this.viewMode) {
      case 'day':
        return getDayRange(this.currentDate);
      case 'week':
        return getWeekRange(this.currentDate);
      case 'month':
        return getMonthRange(this.currentDate);
      default:
        return getWeekRange(this.currentDate);
    }
  }

  // Computed: filtered team members by group and search query
  get filteredMembers(): TeamMemberSchedule[] {
    const byGroup = filterByGroup(this.teamMembers, this.groupFilter);
    return filterBySearch(byGroup, this.searchQuery);
  }

  // Computed: day columns for the current date range and view mode
  get dayColumns(): { dayName: string; date: string; isToday: boolean }[] {
    return getDayColumns(this.dateRange, this.viewMode);
  }

  // Actions
  setViewMode(mode: ViewMode): void {
    this.viewMode = mode;
    this.fetchScheduleData();
  }

  navigateNext(): void {
    this.currentDate = navigateNext(this.currentDate, this.viewMode);
    this.fetchScheduleData();
  }

  navigatePrev(): void {
    this.currentDate = navigatePrev(this.currentDate, this.viewMode);
    this.fetchScheduleData();
  }

  navigateToday(): void {
    this.currentDate = navigateToday();
    this.fetchScheduleData();
  }

  setGroupFilter(group: string): void {
    this.groupFilter = group;
  }

  setSearchQuery(query: string): void {
    this.searchQuery = query;
  }

  toggleOpenShifts(): void {
    this.showOpenShifts = !this.showOpenShifts;
  }

  toggleTimeOff(): void {
    this.showTimeOff = !this.showTimeOff;
  }

  openCreateDialog(memberId: number, date: string): void {
    this.createDialogOpen = true;
    this.createDialogMemberId = memberId;
    this.createDialogDate = date;
  }

  closeCreateDialog(): void {
    this.createDialogOpen = false;
    this.createDialogMemberId = null;
    this.createDialogDate = null;
  }

  async fetchScheduleData(): Promise<void> {
    this.loading = true;
    this.error = null;
    try {
      const { start, end } = this.dateRange;
      const [teamMembers, openShifts, shiftTypes, groups] = await Promise.all([
        scheduleService.fetchScheduleGrid(start, end),
        scheduleService.fetchOpenShifts(start, end),
        scheduleService.fetchShiftTypes(),
        scheduleService.fetchGroups(),
      ]);
      runInAction(() => {
        this.teamMembers = teamMembers;
        this.openShifts = openShifts;
        this.shiftTypes = shiftTypes;
        this.groups = groups;
        this.loading = false;
      });
    } catch (err: unknown) {
      runInAction(() => {
        this.error = err instanceof Error ? err.message : 'Failed to fetch schedule data';
        this.loading = false;
      });
    }
  }

  async createShift(request: CreateShiftRequest): Promise<void> {
    try {
      await scheduleService.createShift(request);
      this.closeCreateDialog();
      await this.fetchScheduleData();
    } catch (err: unknown) {
      runInAction(() => {
        this.error = err instanceof Error ? err.message : 'Failed to create shift';
      });
      throw err;
    }
  }

  async publishSchedule(): Promise<void> {
    const { start, end } = this.dateRange;
    try {
      await scheduleService.publishSchedule({ startDate: start, endDate: end });
    } catch (err: unknown) {
      runInAction(() => {
        this.error = err instanceof Error ? err.message : 'Failed to publish schedule';
      });
      throw err;
    }
  }

  async exportSchedule(): Promise<void> {
    const { start, end } = this.dateRange;
    try {
      const blob = await scheduleService.exportSchedule(start, end, 'csv');
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `schedule-${start}-to-${end}.csv`;
      link.click();
      URL.revokeObjectURL(url);
    } catch (err: unknown) {
      runInAction(() => {
        this.error = err instanceof Error ? err.message : 'Failed to export schedule';
      });
      throw err;
    }
  }

  async refresh(): Promise<void> {
    await this.fetchScheduleData();
  }
}

export const scheduleStore = new ScheduleStore();

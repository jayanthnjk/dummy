// ===== Duty Type =====
export interface DutyType {
  id: number;
  name: string;
  section: string;
  sortOrder: number;
  latitude: number | null;
  longitude: number | null;
  radiusMeters: number | null;
  parentId: number | null;
  level: 'PARENT' | 'SUB';
}

export interface DutyTypeCreateRequest {
  name: string;
  section: string;
  sortOrder: number;
  latitude?: number | null;
  longitude?: number | null;
  radiusMeters?: number | null;
  parentId?: number | null;
  level?: 'PARENT' | 'SUB';
}

export interface DutyTypeUpdateRequest {
  name?: string;
  section?: string;
  sortOrder?: number;
  latitude?: number | null;
  longitude?: number | null;
  radiusMeters?: number | null;
  parentId?: number | null;
  level?: 'PARENT' | 'SUB';
}

// ===== Section =====
export interface Section {
  id: number;
  code: string;
  name: string;
  description: string | null;
  sortOrder: number;
  isActive: boolean;
  dutyTypeCount?: number;
}

export interface SectionCreateRequest {
  code: string;
  name: string;
  description?: string | null;
  sortOrder: number;
  isActive?: boolean;
}

export interface SectionUpdateRequest {
  name?: string;
  description?: string | null;
  sortOrder?: number;
  isActive?: boolean;
}

// ===== Personnel =====
export interface Personnel {
  id: number;
  name: string;
  rank: string;
  dutyType: string;
  assignmentStart: string;
  assignmentEnd: string | null;
  status: string;
  section: string;
}

// ===== Reassignment =====
export interface ReassignmentRequest {
  dutyTypeIds: number[];
  targetSection: string;
}

export interface ReassignmentResult {
  dutyTypesUpdated: number;
  dutyAssignmentsUpdated: number;
  personnelUpdated: number;
  sourceSection: string;
  targetSection: string;
}

// ===== CSV Export =====
export interface CsvExportRow {
  dutyTypeName: string;
  sectionCode: string;
  latitude: number | null;
  longitude: number | null;
  personnelName: string;
  rank: string;
  assignmentStatus: string;
}

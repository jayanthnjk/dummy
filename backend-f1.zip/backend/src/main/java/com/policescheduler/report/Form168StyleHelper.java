package com.policescheduler.report;

import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.awt.Color;

/**
 * Centralizes all visual styling constants for the Form 168 (Daily Statement) report.
 * Provides font definitions, color constants, and cell creation methods for both
 * PDF (OpenPDF) and Excel (Apache POI) outputs.
 */
@Service
public class Form168StyleHelper {

    // ======================== Font Size Constants ========================

    public static final float DATA_FONT_SIZE = 6.5f;
    public static final float HEADER_FONT_SIZE = 7.5f;
    public static final float SECTION_HEADER_FONT_SIZE = 8f;
    public static final float TITLE_FONT_SIZE = 9f;
    public static final float PERSONNEL_DETAILS_FONT_SIZE = 6f;

    // ======================== Color Constants ========================

    /** Olive/green background for main section headers like "SECTION A" */
    public static final Color SECTION_HEADER_BG = new Color(200, 210, 180);

    /** Light gray for subsection headers */
    public static final Color SUBSECTION_HEADER_BG = new Color(230, 230, 230);

    /** Very light gray for column headers */
    public static final Color TABLE_HEADER_BG = new Color(240, 240, 240);

    /** Border color for all cells */
    public static final Color BORDER_COLOR = Color.BLACK;

    // ======================== Border & Margin Constants ========================

    public static final float BORDER_WIDTH = 0.5f;

    public static final float MARGIN_TOP = 12f;
    public static final float MARGIN_BOTTOM = 12f;
    public static final float MARGIN_LEFT = 10f;
    public static final float MARGIN_RIGHT = 10f;

    // ======================== PDF Font Getters ========================

    /**
     * Returns 6.5pt Helvetica Normal — used for data cells.
     */
    public Font getDataFont() {
        return FontFactory.getFont(FontFactory.HELVETICA, DATA_FONT_SIZE, Font.NORMAL);
    }

    /**
     * Returns 6.5pt Helvetica Bold — used for total cells and emphasized data.
     */
    public Font getDataFontBold() {
        return FontFactory.getFont(FontFactory.HELVETICA_BOLD, DATA_FONT_SIZE, Font.BOLD);
    }

    /**
     * Returns 7.5pt Helvetica Bold — used for column headers.
     */
    public Font getHeaderFont() {
        return FontFactory.getFont(FontFactory.HELVETICA_BOLD, HEADER_FONT_SIZE, Font.BOLD);
    }

    /**
     * Returns 8pt Helvetica Bold — used for section headers (e.g., "SECTION A").
     */
    public Font getSectionHeaderFont() {
        return FontFactory.getFont(FontFactory.HELVETICA_BOLD, SECTION_HEADER_FONT_SIZE, Font.BOLD);
    }

    /**
     * Returns 9pt Helvetica Bold — used for the document title.
     */
    public Font getTitleFont() {
        return FontFactory.getFont(FontFactory.HELVETICA_BOLD, TITLE_FONT_SIZE, Font.BOLD);
    }

    /**
     * Returns 6pt Helvetica Normal — used for the personnel details column
     * which needs to fit more text.
     */
    public Font getPersonnelDetailsFont() {
        return FontFactory.getFont(FontFactory.HELVETICA, PERSONNEL_DETAILS_FONT_SIZE, Font.NORMAL);
    }

    // ======================== PDF Cell Creation Methods ========================

    /**
     * Creates a standard data cell with 0.5pt black borders on all 4 sides,
     * 2pt padding, 6.5pt font, and the specified alignment.
     */
    public PdfPCell createDataCell(String text, int alignment) {
        PdfPCell cell = new PdfPCell(new Phrase(text, getDataFont()));
        applyStandardBorders(cell);
        cell.setPadding(2f);
        cell.setHorizontalAlignment(alignment);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        return cell;
    }

    /**
     * Creates a column header cell with 0.5pt borders, 7.5pt bold font,
     * light gray TABLE_HEADER_BG background, center-aligned.
     */
    public PdfPCell createHeaderCell(String text) {
        PdfPCell cell = new PdfPCell(new Phrase(text, getHeaderFont()));
        applyStandardBorders(cell);
        cell.setPadding(2f);
        cell.setBackgroundColor(TABLE_HEADER_BG);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        return cell;
    }

    /**
     * Creates a column header cell with VERTICAL (90° rotated) text.
     * Used for designation columns (DCP, ACP, RPI, RSI, ARSI, AHC, APC, SWP, TOTAL)
     * matching the Book 1 reference where these headers are rotated.
     */
    public PdfPCell createVerticalHeaderCell(String text) {
        PdfPCell cell = new PdfPCell(new Phrase(text, getHeaderFont()));
        applyStandardBorders(cell);
        cell.setPadding(2f);
        cell.setBackgroundColor(TABLE_HEADER_BG);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setRotation(90);
        return cell;
    }

    /**
     * Creates a section header cell (e.g., "SECTION A") with olive/green background,
     * 8pt bold font, full-width span, left-aligned. Has a taller fixed height (20pt)
     * matching the Book 1 reference.
     */
    public PdfPCell createSectionHeaderCell(String text, int colspan) {
        PdfPCell cell = new PdfPCell(new Phrase(text, getSectionHeaderFont()));
        applyStandardBorders(cell);
        cell.setPadding(3f);
        cell.setBackgroundColor(SECTION_HEADER_BG);
        cell.setColspan(colspan);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setFixedHeight(20f);
        return cell;
    }

    /**
     * Creates a subsection header cell with light gray SUBSECTION_HEADER_BG background,
     * 7.5pt bold font, left-aligned.
     */
    public PdfPCell createSubsectionHeaderCell(String text, int colspan) {
        PdfPCell cell = new PdfPCell(new Phrase(text, getHeaderFont()));
        applyStandardBorders(cell);
        cell.setPadding(2f);
        cell.setBackgroundColor(SUBSECTION_HEADER_BG);
        cell.setColspan(colspan);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        return cell;
    }

    /**
     * Creates a total cell with bold data font (6.5pt bold), borders, specified alignment.
     */
    public PdfPCell createTotalCell(String text, int alignment) {
        PdfPCell cell = new PdfPCell(new Phrase(text, getDataFontBold()));
        applyStandardBorders(cell);
        cell.setPadding(2f);
        cell.setHorizontalAlignment(alignment);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        return cell;
    }

    /**
     * Creates a centered serial number cell with borders.
     */
    public PdfPCell createSerialNumberCell(int slNo) {
        PdfPCell cell = new PdfPCell(new Phrase(String.valueOf(slNo), getDataFont()));
        applyStandardBorders(cell);
        cell.setPadding(2f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        return cell;
    }

    // ======================== Excel Style Methods ========================

    /**
     * Creates an Excel data cell style — thin borders all sides, 7pt font.
     */
    public CellStyle createExcelDataStyle(Workbook wb) {
        CellStyle style = wb.createCellStyle();
        applyExcelThinBorders(style);
        org.apache.poi.ss.usermodel.Font font = wb.createFont();
        font.setFontHeightInPoints((short) 7);
        font.setFontName("Helvetica");
        style.setFont(font);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        return style;
    }

    /**
     * Creates an Excel header style — thin borders, bold 7pt, light gray fill.
     */
    public CellStyle createExcelHeaderStyle(Workbook wb) {
        XSSFCellStyle style = (XSSFCellStyle) wb.createCellStyle();
        applyExcelThinBorders(style);
        XSSFFont font = ((XSSFWorkbook) wb).createFont();
        font.setFontHeightInPoints((short) 7);
        font.setFontName("Helvetica");
        font.setBold(true);
        style.setFont(font);
        style.setFillForegroundColor(new XSSFColor(
                new byte[]{(byte) 240, (byte) 240, (byte) 240}, null));
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        return style;
    }

    /**
     * Creates an Excel section header style — thin borders, bold 8pt, olive/green fill.
     */
    public CellStyle createExcelSectionHeaderStyle(Workbook wb) {
        XSSFCellStyle style = (XSSFCellStyle) wb.createCellStyle();
        applyExcelThinBorders(style);
        XSSFFont font = ((XSSFWorkbook) wb).createFont();
        font.setFontHeightInPoints((short) 8);
        font.setFontName("Helvetica");
        font.setBold(true);
        style.setFont(font);
        style.setFillForegroundColor(new XSSFColor(
                new byte[]{(byte) 200, (byte) 210, (byte) 180}, null));
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        return style;
    }

    /**
     * Creates an Excel total style — thin borders, bold 7pt, center aligned.
     */
    public CellStyle createExcelTotalStyle(Workbook wb) {
        XSSFCellStyle style = (XSSFCellStyle) wb.createCellStyle();
        applyExcelThinBorders(style);
        XSSFFont font = ((XSSFWorkbook) wb).createFont();
        font.setFontHeightInPoints((short) 7);
        font.setFontName("Helvetica");
        font.setBold(true);
        style.setFont(font);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        return style;
    }

    /**
     * Creates an Excel number style — thin borders, center-aligned, 7pt.
     */
    public CellStyle createExcelNumberStyle(Workbook wb) {
        CellStyle style = wb.createCellStyle();
        applyExcelThinBorders(style);
        org.apache.poi.ss.usermodel.Font font = wb.createFont();
        font.setFontHeightInPoints((short) 7);
        font.setFontName("Helvetica");
        style.setFont(font);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        return style;
    }

    // ======================== Private Helpers ========================

    /**
     * Applies 0.5pt black borders on all four sides of a PDF cell.
     */
    private void applyStandardBorders(PdfPCell cell) {
        cell.setBorderWidth(BORDER_WIDTH);
        cell.setBorderColor(BORDER_COLOR);
    }

    /**
     * Applies thin borders on all four sides of an Excel cell style.
     */
    private void applyExcelThinBorders(CellStyle style) {
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
    }
}

package com.policescheduler.report.model;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class LeaveGroup {
    private String type; // "EL/CML/PL", "CL", "W/OFF", etc.
    private List<LeaveEntry> entries;
}

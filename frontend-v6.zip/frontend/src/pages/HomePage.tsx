import React, { useEffect, useState, useCallback, useRef } from 'react';
import {
  Box, Typography, Paper, IconButton, Tooltip, keyframes, Chip, Avatar,
} from '@mui/material';
import AttachFileIcon from '@mui/icons-material/AttachFile';
import MicIcon from '@mui/icons-material/Mic';
import MicOffIcon from '@mui/icons-material/MicOff';
import SendIcon from '@mui/icons-material/Send';
import AddIcon from '@mui/icons-material/Add';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import PeopleIcon from '@mui/icons-material/People';
import DescriptionIcon from '@mui/icons-material/Description';
import EventBusyIcon from '@mui/icons-material/EventBusy';
import RotateRightIcon from '@mui/icons-material/RotateRight';
import SecurityIcon from '@mui/icons-material/Security';
import { useTranslation } from 'react-i18next';
import { useAuth } from '@/contexts/AuthContext';
import { chatService } from '@/services/chatService';
import ChatConversation, { type ChatMessage } from '@/components/ChatConversation';

const blink = keyframes`
  0%, 100% { opacity: 1; }
  50% { opacity: 0.3; }
`;
const float = keyframes`
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-6px); }
`;

const suggestions = [
  { text: 'Create adhoc duty', icon: <CalendarMonthIcon sx={{ fontSize: 18 }} />, color: '#e65100', bg: '#fff3e0' },
  { text: 'Show adhoc duties', icon: <DescriptionIcon sx={{ fontSize: 18 }} />, color: '#8b5cf6', bg: '#f5f3ff' },
  { text: 'Show current schedule', icon: <PeopleIcon sx={{ fontSize: 18 }} />, color: '#3b82f6', bg: '#eff6ff' },
  { text: 'How many on leave?', icon: <EventBusyIcon sx={{ fontSize: 18 }} />, color: '#dc2626', bg: '#fef2f2' },
  { text: 'Create platoon cycle', icon: <RotateRightIcon sx={{ fontSize: 18 }} />, color: '#059669', bg: '#ecfdf5' },
];

const CHAT_STORAGE_KEY = 'ksp_chat_messages';

const HomePage: React.FC = () => {
  const { t } = useTranslation();
  const { displayName } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = sessionStorage.getItem(CHAT_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [chatLoading, setChatLoading] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [aiConnected, setAiConnected] = useState<boolean | null>(null);
  const [listening, setListening] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  // Persist messages to sessionStorage on every change
  useEffect(() => {
    try {
      sessionStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(messages));
    } catch { /* storage full — ignore */ }
  }, [messages]);

  // Clear messages if sessionStorage was wiped (e.g. after logout + re-login)
  useEffect(() => {
    const saved = sessionStorage.getItem(CHAT_STORAGE_KEY);
    if (!saved && messages.length > 0) {
      setMessages([]);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [displayName]); // re-check when user identity changes

  const clearChat = useCallback(() => {
    setMessages([]);
    sessionStorage.removeItem(CHAT_STORAGE_KEY);
  }, []);

  useEffect(() => {
    chatService.checkAiStatus()
      .then(res => setAiConnected(res.connected))
      .catch(() => setAiConnected(false));
  }, []);

  const handleSend = useCallback(async (text?: string) => {
    const msg = (text || chatInput).trim();
    if (!msg) return;
    setChatInput('');
    setMessages(p => [...p, { id: Date.now().toString(), role: 'user', content: msg }]);
    setChatLoading(true);
    try {
      const res = await chatService.sendMessage(msg);
      setMessages(p => [...p, { id: (Date.now() + 1).toString(), role: 'assistant', content: res.response, responseType: res.responseType, data: res.data }]);
    } catch {
      setMessages(p => [...p, {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'Thanks for your message! I wasn\'t able to process that. Could you try asking in a different way?',
        responseType: 'suggestions',
        data: {
          message: 'Thanks for your message! I wasn\'t able to process that. Could you try asking in a different way?',
          suggestions: ['Create adhoc duty', 'Show adhoc duties', 'Show current schedule', 'How many on leave?', 'List personnel'],
        },
      }]);
    } finally { setChatLoading(false); }
  }, [chatInput, t]);

  const handleFormSubmit = useCallback(async (formId: string, submitAction: string, fields: Record<string, string>): Promise<boolean> => {
    const res = await chatService.submitForm(formId, submitAction, fields);
    setMessages(p => [...p, { id: Date.now().toString(), role: 'assistant', content: res.response, responseType: res.responseType, data: res.data }]);
    // Check if the confirmation was successful
    const confirmData = res.data as { success?: boolean } | undefined;
    return confirmData?.success === true;
  }, []);

  const toggleVoice = () => {
    const SpeechAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechAPI) return;
    if (listening && recognitionRef.current) { recognitionRef.current.stop(); setListening(false); return; }
    const recognition = new SpeechAPI();
    recognition.continuous = false; recognition.interimResults = false; recognition.lang = 'en-US';
    recognition.onresult = (event: SpeechRecognitionEvent) => {
      const transcript = event.results[0]?.[0]?.transcript ?? '';
      if (transcript) handleSend(transcript);
    };
    recognition.onend = () => setListening(false);
    recognition.onerror = () => setListening(false);
    recognitionRef.current = recognition; recognition.start(); setListening(true);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type === 'application/pdf') {
      setMessages(p => [...p, { id: Date.now().toString(), role: 'user', content: `📎 ${file.name}` }]);
      setChatLoading(true);
      chatService.uploadPdf(file)
        .then(res => setMessages(p => [...p, { id: (Date.now() + 1).toString(), role: 'assistant', content: res.response }]))
        .catch(() => setMessages(p => [...p, { id: (Date.now() + 1).toString(), role: 'assistant', content: t('errors.serverError') }]))
        .finally(() => setChatLoading(false));
    }
    if (fileRef.current) fileRef.current.value = '';
  };

  const hasMessages = messages.length > 0;

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 52px)', bgcolor: '#ffffff' }}>

      {/* ── Header ── */}
      <Box sx={{ px: 3, py: 1.5, display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #f5f3ee' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
          {aiConnected !== null && (
            <Tooltip title={aiConnected ? 'AI Connected' : 'AI Disconnected'}>
              <Box sx={{
                width: 8, height: 8, borderRadius: '50%',
                bgcolor: aiConnected ? '#22c55e' : '#ef4444',
                animation: `${blink} ${aiConnected ? '2s' : '0.6s'} ease-in-out infinite`,
                boxShadow: aiConnected ? '0 0 6px #22c55e60' : '0 0 6px #ef444460',
              }} />
            </Tooltip>
          )}
          {hasMessages && (
            <Chip label={`${messages.length} messages`} size="small"
              sx={{ fontSize: '0.7rem', height: 22, bgcolor: '#f5f2ec', color: '#6b6b80' }} />
          )}
        </Box>
        <Box onClick={clearChat}
          sx={{
            display: 'flex', alignItems: 'center', gap: 0.6, cursor: 'pointer',
            px: 2, py: 0.7, borderRadius: 2,
            bgcolor: '#1a1e4a', color: '#fff', fontSize: '0.78rem', fontWeight: 600,
            transition: 'all 0.2s',
            '&:hover': { bgcolor: '#0b0e2a', transform: 'translateY(-1px)', boxShadow: '0 4px 12px rgba(26,30,74,0.25)' },
          }}>
          <AddIcon sx={{ fontSize: 15 }} /> New chat
        </Box>
      </Box>

      {/* ── Chat area ── */}
      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {!hasMessages ? (
          <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', px: 3 }}>

            {/* Shield icon */}
            <Box sx={{
              width: 64, height: 64, borderRadius: 3, mb: 3,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              animation: `${float} 3s ease-in-out infinite`,
            }}>
              <Box component="img" src="/ksp-logo.svg" alt="KSP Logo" sx={{ width: 56, height: 56 }} />
            </Box>

            <Typography sx={{ fontSize: { xs: '1.3rem', md: '1.6rem' }, color: '#111827', mb: 0.5 }}>
              {t('home.welcomeBack')} <strong>{displayName}.</strong>
            </Typography>
            <Typography sx={{ color: '#9ca3af', fontSize: '0.85rem', mb: 4 }}>
              {t('home.commandPlaceholder')}
            </Typography>

            {/* Mic button */}
            <Box sx={{
              width: 56, height: 56, borderRadius: '50%', mb: 4, cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              bgcolor: listening ? '#fef2f2' : '#f9fafb',
              border: `2px solid ${listening ? '#ef4444' : '#e5e7eb'}`,
              color: listening ? '#ef4444' : '#9ca3af',
              transition: 'all 0.3s',
              '&:hover': {
                bgcolor: listening ? '#fee2e2' : '#f0f0ff',
                borderColor: listening ? '#ef4444' : '#1a1e4a',
                color: listening ? '#ef4444' : '#1a1e4a',
                transform: 'scale(1.05)',
              },
            }} onClick={toggleVoice}>
              {listening ? <MicOffIcon /> : <MicIcon />}
            </Box>

            {/* Suggestion cards */}
            <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap', justifyContent: 'center', maxWidth: 600 }}>
              {suggestions.map((s, i) => (
                <Box key={i} onClick={() => handleSend(s.text)}
                  sx={{
                    display: 'flex', alignItems: 'center', gap: 1, cursor: 'pointer',
                    px: 2, py: 1.2, borderRadius: 2.5,
                    bgcolor: s.bg, border: `1px solid ${s.color}20`,
                    color: s.color, fontSize: '0.8rem', fontWeight: 500,
                    transition: 'all 0.2s',
                    '&:hover': {
                      transform: 'translateY(-2px)',
                      boxShadow: `0 4px 12px ${s.color}20`,
                      borderColor: `${s.color}40`,
                    },
                  }}>
                  {s.icon}
                  {s.text}
                </Box>
              ))}
            </Box>
          </Box>
        ) : (
          <ChatConversation messages={messages} userName={displayName || undefined} loading={chatLoading} onFormSubmit={handleFormSubmit} onSuggestionClick={(s) => handleSend(s)} />
        )}
      </Box>

      {/* ── Input bar ── */}
      <Box sx={{ px: { xs: 2, md: 3 }, pb: 2 }}>
        <input ref={fileRef} type="file" accept=".pdf" hidden onChange={handleFileChange} />
        <Paper elevation={0} sx={{
          display: 'flex', alignItems: 'center', gap: 1, px: 2, py: 1,
          borderRadius: '28px', bgcolor: '#f9fafb', border: '1px solid #e8e4dc',
          transition: 'border-color 0.2s, box-shadow 0.2s',
          '&:focus-within': { borderColor: '#1a1e4a', boxShadow: '0 0 0 3px rgba(26,30,74,0.06)' },
        }}>
          <Tooltip title={t('home.attachPdf')}>
            <IconButton size="small" onClick={() => fileRef.current?.click()} sx={{ color: '#b0a898' }}>
              <AttachFileIcon sx={{ fontSize: 20 }} />
            </IconButton>
          </Tooltip>
          <input type="text" value={chatInput}
            onChange={e => setChatInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && !e.shiftKey && handleSend()}
            placeholder={t('home.commandPlaceholder')}
            style={{ flex: 1, border: 'none', outline: 'none', fontSize: '0.88rem', background: 'transparent', color: '#374151', padding: '6px 0' }}
          />
          <Tooltip title={t('home.voiceCommand')}>
            <IconButton size="small" onClick={toggleVoice} sx={{ color: listening ? '#ef4444' : '#b0a898' }}>
              {listening ? <MicOffIcon sx={{ fontSize: 20 }} /> : <MicIcon sx={{ fontSize: 20 }} />}
            </IconButton>
          </Tooltip>
          <Tooltip title={t('home.sendMessage')}>
            <IconButton size="small" onClick={() => handleSend()} disabled={chatLoading || !chatInput.trim()}
              sx={{
                background: 'linear-gradient(135deg, #1a1e4a, #2a2e6a)',
                color: '#fff', width: 34, height: 34, borderRadius: '50%',
                '&:hover': { background: 'linear-gradient(135deg, #0b0e2a, #1a1e4a)' },
                '&.Mui-disabled': { bgcolor: '#e5e7eb', color: '#9ca3af', background: '#e5e7eb' },
              }}>
              <SendIcon sx={{ fontSize: 16 }} />
            </IconButton>
          </Tooltip>
        </Paper>
      </Box>
    </Box>
  );
};

export default HomePage;

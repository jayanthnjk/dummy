# High-Level Design (HLD)
## KSP WorkBoard — Police Station Management System

| Field | Details |
|-------|---------|
| **Document Title** | High-Level Design Document (HLD) |
| **Application Name** | KSP WorkBoard |
| **Version** | 1.0.0 |
| **Date** | June 2026 |
| **Based On** | BRD v1.0.0, SRS v1.0.0 |
| **Status** | Final |

---

## 1. Overview

### 1.1 Purpose

This High-Level Design document describes the overall system architecture, component interactions, technology decisions, data models, and deployment topology of the KSP WorkBoard application. It provides a bird's-eye view of how the system is structured and how its components interact to deliver the required functionality.

### 1.2 Architecture Philosophy

The KSP WorkBoard follows these architectural principles:
- **Layered Architecture** — Clear separation between Presentation, Business Logic, Data Access, and Infrastructure layers
- **Stateless Backend** — No server-side sessions; JWT tokens carry authentication state
- **MCP-based AI Integration** — Model Context Protocol pattern for LLM tool execution
- **Provider Abstraction** — Unified LlmClient interface abstracts Groq vs AWS Bedrock
- **Resilience First** — Circuit breakers, caching, and graceful fallbacks for external dependencies
- **Audit by Default** — All mutations to critical data are logged to audit tables

---

## 2. System Architecture Overview

### 2.1 High-Level System Architecture Diagram

```mermaid
graph TB
    subgraph "Client Tier"
        BROWSER[Web Browser<br>React 19 SPA]
    end

    subgraph "CDN / Static Hosting"
        S3[AWS S3 + CloudFront<br>Static Frontend Assets]
    end

    subgraph "Application Tier - AWS EC2"
        subgraph "Spring Boot Application"
            SECURITY[Security Layer<br>JWT Auth + PII Filter]
            CONTROLLERS[REST Controllers<br>18 Controllers]
            SERVICES[Service Layer<br>18 Services]
            CHAT[AI Chat Pipeline<br>MCP Architecture]
            REPORTS[Report Engine<br>PDF + Excel]
        end
    end

    subgraph "Data Tier"
        PG[(PostgreSQL 15+<br>with pgvector)]
    end

    subgraph "External AI Services"
        GROQ[Groq API<br>LLama 3.3 70B<br>Development]
        BEDROCK[AWS Bedrock<br>Amazon Nova Lite<br>Production]
        WHISPER[Groq Whisper<br>Speech-to-Text]
    end

    BROWSER -->|HTTPS| S3
    BROWSER -->|REST API<br>JWT Bearer| SECURITY
    SECURITY --> CONTROLLERS
    CONTROLLERS --> SERVICES
    CONTROLLERS --> CHAT
    CONTROLLERS --> REPORTS
    SERVICES --> PG
    CHAT -->|Function Calling| GROQ
    CHAT -->|Function Calling| BEDROCK
    CHAT -->|Audio Transcription| WHISPER
    CHAT --> SERVICES
    REPORTS --> PG
```

### 2.2 Technology Stack Summary

| Tier | Technology | Version | Purpose |
|------|-----------|---------|---------|
| **Frontend** | React | 19.0.0 | UI framework |
| | TypeScript | 5.7.3 | Type safety |
| | Vite | 6.1.0 | Build tool & dev server |
| | MUI Material | 6.4.0 | Component library |
| | MobX | 6.15.0 | State management |
| | React Router | 7.1.3 | Client-side routing |
| | Axios | 1.7.9 | HTTP client |
| | i18next | 24.2.2 | Internationalization |
| | Leaflet | 1.9.4 | Map rendering |
| | fast-check | 4.1.1 | Property-based testing |
| **Backend** | Spring Boot | 3.4.4 | Application framework |
| | Java | 17 | Runtime (LTS) |
| | Spring Security | (managed) | Auth + AuthZ |
| | Spring Data JPA | (managed) | ORM & repositories |
| | Hibernate | (managed) | JPA implementation |
| | JJWT | 0.12.6 | JWT token library |
| | Resilience4j | 2.2.0 | Circuit breakers |
| | Caffeine | 3.1.8 | In-memory cache |
| | Jackson | (managed) | JSON serialization |
| **Database** | PostgreSQL | 15+ | Relational data store |
| | pgvector | 0.1.6 | Vector similarity search |
| **Reports** | OpenPDF | 2.0.3 | PDF generation |
| | Apache POI | 5.4.0 | Excel generation |
| | PDFBox | 3.0.1 | PDF text extraction |
| **AI/ML** | Groq API | — | LLM (dev) |
| | AWS Bedrock | 2.25.60 SDK | LLM (prod) |
| | Groq Whisper | — | Speech-to-text |
| **Infrastructure** | AWS EC2 | — | Application server |
| | AWS S3 + CloudFront | — | Frontend hosting |
| | systemd | — | Process management |

---

## 3. Component Architecture

### 3.1 Backend Component Diagram

```mermaid
graph TB
    subgraph "Presentation Layer"
        AUTH_C[AuthController]
        PERS_C[PersonnelController]
        CYCLE_C[CycleController]
        LEAVE_C[LeaveController]
        ADHOC_C[AdhocDutyController]
        CHAT_C[ChatController]
        REPORT_C[ReportController]
        SCHED_C[ScheduleController]
        DT_C[DutyTypeController]
        SEC_C[SectionController]
        HEALTH_C[HealthController]
        OTHER_C[7 Other Controllers]
    end

    subgraph "Business Logic Layer"
        AUTH_S[AuthService]
        PERS_S[PersonnelService]
        CYCLE_S[CycleService]
        LEAVE_S[LeaveService]
        ADHOC_S[AdhocDutyService]
        SCHED_S[ScheduleService]
        DT_S[DutyTypeService]
        SEC_S[SectionService]
        ASSIGN_S[AssignmentGenerationService]
        REASSIGN_S[ReassignmentService]
        AUDIT_S[CycleAuditService]
        VALIDATOR[CycleValidator]
        CONFLICT[LeaveConflictDetector]
        REPORT_S[ReportService + Generators]
    end

    subgraph "AI/Chat Layer"
        GATEWAY[InputGatewayService]
        SANITIZER[InputSanitizerService]
        LANG_DET[LanguageDetectorService]
        FC_SVC[FunctionCallingService]
        MCP_HOST[McpHost]
        DOMAIN_MCP[DomainDbMcpServer]
        CYCLE_MCP[CycleMcpServer]
        ADHOC_MCP[AdhocMcpServer]
        DOC_MCP[DocumentMcpServer]
        REPORT_MCP[ReportMcpServer]
        RESP_BUILDER[ResponseBuilderService]
        CB_MGR[CircuitBreakerManager]
        CACHE_SVC[ResponseCacheService]
    end

    subgraph "Data Access Layer"
        REPOS[25 JPA Repositories]
    end

    subgraph "Infrastructure Layer"
        LLM_CLIENT[LlmClient Interface]
        GROQ_IMPL[GroqLlmClient]
        BEDROCK_IMPL[BedrockLlmClient]
        SEC_CONFIG[SecurityConfig]
        JWT_FILTER[JwtAuthFilter]
        PII_FILTER[PiiFilter]
    end

    %% Controller → Service mappings
    AUTH_C --> AUTH_S
    PERS_C --> PERS_S
    CYCLE_C --> CYCLE_S
    LEAVE_C --> LEAVE_S
    ADHOC_C --> ADHOC_S
    CHAT_C --> GATEWAY
    REPORT_C --> REPORT_S
    SCHED_C --> SCHED_S

    %% Service → Repository
    PERS_S --> REPOS
    CYCLE_S --> REPOS
    LEAVE_S --> REPOS
    ADHOC_S --> REPOS

    %% Cycle creation pipeline
    CYCLE_S --> VALIDATOR
    CYCLE_S --> ASSIGN_S
    CYCLE_S --> AUDIT_S
    ASSIGN_S --> REPOS

    %% AI Pipeline
    GATEWAY --> SANITIZER
    GATEWAY --> LANG_DET
    GATEWAY --> FC_SVC
    FC_SVC --> LLM_CLIENT
    LLM_CLIENT --> GROQ_IMPL
    LLM_CLIENT --> BEDROCK_IMPL
    GATEWAY --> MCP_HOST
    MCP_HOST --> DOMAIN_MCP
    MCP_HOST --> CYCLE_MCP
    MCP_HOST --> ADHOC_MCP
    MCP_HOST --> DOC_MCP
    MCP_HOST --> REPORT_MCP
    GATEWAY --> RESP_BUILDER
    GATEWAY --> CB_MGR
```

### 3.2 Frontend Component Architecture

```mermaid
graph TB
    subgraph "App Shell"
        APP[App.tsx<br>Router + Guards]
        LAYOUT[MainLayout<br>SideNav + Content]
        INACTIVITY[InactivityDialog]
    end

    subgraph "Pages (14)"
        LOGIN[LoginPage]
        HOME[HomePage + ChatPanel]
        PERSONNEL[PersonnelPage]
        ADD_PERSON[AddPersonPage]
        PROFILE[PersonnelProfilePage]
        SCHEDULES[SchedulesPage]
        ROTATION[RotationManagementPage]
        CYCLES[CycleManagementPage]
        ACTIVITIES[CycleActivitiesPage]
        ADHOC[AdhocDutyPage]
        LEAVE[LeaveRequestsPage]
        REPORTS[ReportsPage]
        SUPPORT[ContactSupportPage]
        DUTY_SEC[DutySectionsPage]
    end

    subgraph "Shared Components"
        NAV[SideNavBar]
        PROTECTED[ProtectedRoute]
        ADMIN_ROUTE[AdminRoute]
        CYCLE_FORM[CycleForm]
    end

    subgraph "Services (API Layer)"
        API[api.ts<br>Axios instance]
        CHAT_SVC[chatService.ts]
        PERSONNEL_SVC[personnelService.ts]
        SCHEDULE_SVC[scheduleService.ts]
        LEAVE_SVC[leaveService.ts]
    end

    subgraph "State Management"
        AUTH_STORE[AuthStore<br>MobX]
        THEME_CTX[ThemeContext]
        I18N[i18next instance]
    end

    APP --> LAYOUT
    APP --> LOGIN
    LAYOUT --> NAV
    LAYOUT --> HOME
    LAYOUT --> PERSONNEL
    HOME --> CHAT_SVC
    PERSONNEL --> PERSONNEL_SVC
    CYCLES --> CYCLE_FORM
    API --> AUTH_STORE
```

---

## 4. AI/Chat Architecture (MCP Pattern)

### 4.1 MCP Architecture Overview

The AI chat system implements a **Model Context Protocol (MCP)** architecture. This is a custom implementation (not the standard MCP protocol spec) that provides:
- **Tool Discovery** — McpHost auto-discovers tools from registered MCP Servers at startup
- **Tool Routing** — Incoming tool calls are routed to the correct server
- **Execution Isolation** — Each domain has its own MCP Server with independent logic
- **Response Standardization** — Unified McpToolResult format across all servers

### 4.2 MCP Pipeline Flow

```mermaid
flowchart LR
    A[User Message] --> B[InputSanitizerService<br>Prompt Injection Check]
    B --> C[LanguageDetectorService<br>EN/KN/HI Detection]
    C --> D[FunctionCallingService<br>LLM Tool Resolution]
    D --> E{Tool Selected?}
    E -->|Yes| F[McpHost.dispatch]
    E -->|No| G[Fallback Suggestions]
    E -->|Direct Response| H[Greeting/Clarification]
    F --> I[MCP Server<br>executeTool]
    I --> J[ResponseBuilderService<br>Format Response]
    J --> K[ChatResponse<br>to Frontend]
    G --> K
    H --> K
```

### 4.3 MCP Server Registry

| Server ID | Class | Tools Count | Domain |
|-----------|-------|-------------|--------|
| domain-db | DomainDbMcpServer | 18 | Personnel, Leave, Schedule, Duty Types, Reports |
| cycle-management | CycleMcpServer | 8 | Cycle CRUD, Reassignment, Audit |
| adhoc-duty | AdhocMcpServer | 4 | Adhoc duty operations |
| document | DocumentMcpServer | 2 | PDF upload, RAG queries |
| report | ReportMcpServer | 5 | PDF/Excel generation |

**Total Registered Tools: 37**

### 4.4 LLM Provider Abstraction

```mermaid
classDiagram
    class LlmClient {
        <<interface>>
        +chatCompletion(model, messages, tools, toolChoice) String
        +chatCompletion(model, messages) String
        +getProviderName() String
    }

    class GroqLlmClient {
        -RestTemplate restTemplate
        -String apiKey
        -String apiUrl
        -String model
        +chatCompletion(...) String
        +getProviderName() String
    }

    class BedrockLlmClient {
        -BedrockRuntimeClient bedrockClient
        -String region
        -String modelId
        +chatCompletion(...) String
        +getProviderName() String
    }

    class LlmClientConfig {
        +llmClient(...) LlmClient
    }

    LlmClient <|.. GroqLlmClient
    LlmClient <|.. BedrockLlmClient
    LlmClientConfig --> LlmClient : creates
```

**Provider Selection Logic (LlmClientConfig):**
- If `AI_PROVIDER=bedrock` → creates BedrockLlmClient (uses IAM role, no API key needed)
- If `AI_PROVIDER=groq` (default) → creates GroqLlmClient (uses API key, OpenAI-compatible REST)
- Both return responses in OpenAI-compatible JSON format

---

## 5. Data Architecture

### 5.1 Entity Relationship Diagram

```mermaid
erDiagram
    USERS {
        bigint id PK
        varchar username UK
        varchar password_hash
        enum role
        varchar display_name
        varchar locale
        bigint personnel_id FK
        timestamp created_at
        timestamp updated_at
    }

    PERSONNEL {
        bigint id PK
        varchar badge_id UK
        varchar person_name
        varchar duty_type
        bigint duty_type_id FK
        varchar location
        varchar phone_number
        varchar email
        varchar designation
        varchar section
        date date_of_joining
        varchar vehicle_number
        varchar duty_location
        varchar pdms
        varchar licence_type
        varchar deployed_from
        bigint platoon_id FK
        boolean is_active
        timestamp created_at
        timestamp updated_at
    }

    DUTY_TYPES {
        bigint id PK
        varchar name
        varchar section
        int sort_order
        double latitude
        double longitude
        int radius_meters
        bigint parent_id FK
    }

    SECTIONS {
        bigint id PK
        varchar code UK
        varchar name
        varchar description
        int sort_order
        boolean is_active
    }

    PLATOONS {
        bigint id PK
        varchar name
        int base_offset
    }

    SCHEDULE_CYCLES {
        bigint id PK
        date start_date
        date end_date
        int rotation_days
        varchar status
        bigint created_by FK
        timestamp created_at
        timestamp updated_at
    }

    CYCLE_PLATOON_SECTIONS {
        bigint id PK
        bigint cycle_id FK
        bigint platoon_id FK
        bigint section_id FK
    }

    CYCLE_DUTY_ASSIGNMENTS {
        bigint id PK
        bigint cycle_id FK
        date date
        bigint platoon_id FK
        bigint section_id FK
        bigint person_id FK
        varchar shift_type
        boolean is_override
        varchar group_index
        varchar status
        varchar duty_name
        timestamp updated_at
    }

    CYCLE_AUDIT_LOGS {
        bigint id PK
        bigint cycle_id FK
        varchar action
        text description
        text old_value
        text new_value
        bigint performed_by
        timestamp created_at
    }

    LEAVE_REQUESTS {
        bigint id PK
        bigint personnel_id FK
        varchar leave_type
        date start_date
        date end_date
        varchar status
        varchar reason
        bigint approved_by FK
        varchar rejection_reason
        timestamp created_at
        timestamp updated_at
    }

    ADHOC_DUTIES {
        bigint id PK
        varchar duty_name
        date date
        time start_time
        time end_time
        int required_count
        int actual_count
        varchar pick_from
        jsonb platoon_ids
        varchar location
        boolean min_strength_check
        varchar status
        bigint created_by FK
        timestamp created_at
        timestamp updated_at
    }

    ADHOC_DUTY_ASSIGNMENTS {
        bigint id PK
        bigint adhoc_duty_id FK
        bigint person_id FK
    }

    CHAT_MESSAGES {
        bigint id PK
        bigint user_id FK
        text user_message
        text ai_response
        varchar command_type
        timestamp created_at
    }

    DOCUMENT_CHUNKS {
        bigint id PK
        bigint upload_id FK
        text content
        vector embedding
    }

    %% Relationships
    USERS ||--o| PERSONNEL : "links to"
    PERSONNEL }o--o| DUTY_TYPES : "has"
    PERSONNEL }o--o| PLATOONS : "belongs to"
    DUTY_TYPES ||--o{ DUTY_TYPES : "parent"
    SCHEDULE_CYCLES ||--|{ CYCLE_PLATOON_SECTIONS : "has"
    SCHEDULE_CYCLES ||--|{ CYCLE_DUTY_ASSIGNMENTS : "generates"
    SCHEDULE_CYCLES ||--|{ CYCLE_AUDIT_LOGS : "logged"
    CYCLE_DUTY_ASSIGNMENTS }o--|| PERSONNEL : "assigned to"
    LEAVE_REQUESTS }o--|| PERSONNEL : "for"
    ADHOC_DUTIES ||--|{ ADHOC_DUTY_ASSIGNMENTS : "has"
    ADHOC_DUTY_ASSIGNMENTS }o--|| PERSONNEL : "assigned to"
    CHAT_MESSAGES }o--|| USERS : "from"
```

### 5.2 Database Design Principles

| Principle | Implementation |
|-----------|----------------|
| Soft-delete for cycles | `status` field set to DELETED (data preserved) |
| Audit trail immutability | INSERT-only on `cycle_audit_logs` — no UPDATE/DELETE |
| Temporal tracking | `created_at` / `updated_at` on all mutable entities |
| Referential integrity | FK constraints where applicable |
| Performance indexing | Indexes on all filter columns (section, badge_id, status, date) |
| JSON storage | `platoon_ids` in adhoc_duties uses PostgreSQL `jsonb` type |
| Vector storage | `document_chunks.embedding` uses pgvector `vector` type |

### 5.3 Table Count Summary

| Category | Tables | Examples |
|----------|--------|----------|
| Core Domain | 8 | personnel, duty_types, sections, platoons, leave_requests, schedule_cycles, adhoc_duties, duty_assignments |
| Cycle Engine | 4 | cycle_platoon_sections, cycle_duty_assignments, cycle_audit_logs, shift_groups |
| Auth & Config | 4 | users, system_config, translations, holidays |
| Chat & AI | 4 | chat_messages, chat_audit_logs, document_chunks, pdf_uploads |
| Support | 2 | support_tickets, section_strength |
| **Total** | **22** | |

---

## 6. Security Architecture

### 6.1 Security Architecture Diagram

```mermaid
flowchart TB
    subgraph "Client"
        BROWSER[Browser]
    end

    subgraph "Security Layer"
        CORS[CORS Filter]
        JWT[JwtAuthFilter]
        PII[PiiFilter]
        METHOD[Method Security<br>@PreAuthorize]
    end

    subgraph "Application"
        CONTROLLER[Controllers]
        SANITIZER[InputSanitizer<br>Prompt Injection]
        RATE[RateLimiterService]
    end

    BROWSER -->|HTTPS| CORS
    CORS --> JWT
    JWT -->|Valid Token| PII
    JWT -->|Invalid/Missing| REJECT[401 Unauthorized]
    PII --> CONTROLLER
    CONTROLLER --> METHOD
    METHOD -->|Authorized| SANITIZER
    METHOD -->|Forbidden| DENY[403 Forbidden]
```

### 6.2 Security Controls Matrix

| Layer | Control | Technology |
|-------|---------|------------|
| Transport | HTTPS encryption | AWS ALB / Nginx SSL termination |
| CORS | Origin validation | Spring CorsConfiguration |
| Authentication | Token validation | JwtAuthFilter + JJWT |
| Authorization | Role-based access | @PreAuthorize + SecurityConfig |
| Input Validation | Request validation | Jakarta Bean Validation (@Valid) |
| Injection Prevention | Prompt sanitization | InputSanitizerService |
| PII Protection | Access logging | PiiFilter |
| Rate Limiting | Request throttling | RateLimiterService (30/20 per user) |
| Password Security | Hash storage | BCrypt (PasswordEncoder) |
| Session | Stateless | JWT with 24h expiry |

---

## 7. Resilience Architecture

### 7.1 Circuit Breaker Pattern

```mermaid
stateDiagram-v2
    [*] --> CLOSED : Initial State
    CLOSED --> OPEN : Failure rate >= 50%<br>(min 3 calls, window 10)
    OPEN --> HALF_OPEN : After 60s wait
    HALF_OPEN --> CLOSED : 2 successful calls
    HALF_OPEN --> OPEN : Any failure
```

**Circuit Breaker Configuration (from code):**
| Parameter | Value |
|-----------|-------|
| Sliding window size | 10 calls |
| Failure rate threshold | 50% |
| Wait duration in open state | 60 seconds |
| Minimum number of calls | 3 |
| Permitted calls in half-open | 2 |

### 7.2 Caching Strategy

```mermaid
flowchart LR
    A[Chat Request] --> B{Is Write Tool?}
    B -->|Yes| C[Execute Directly<br>Invalidate Related Cache]
    B -->|No| D{Cache Hit?}
    D -->|Yes| E[Return Cached Result]
    D -->|No| F[Execute Tool]
    F --> G[Store in Cache]
    G --> E
```

**Cache Configuration:**
| Parameter | Value |
|-----------|-------|
| Implementation | Caffeine |
| TTL | 60 seconds (configurable) |
| Max entries | 500 |
| Invalidation | Domain-specific (write invalidates related reads) |

**Write Tools (bypass cache):** add_person, create_leave, create_cycle, update_cycle, delete_cycle, reassign_duty, auto_reassign_duty, add_duty_type, update_duty_type, delete_duty_type, update_personnel, create_adhoc_duty, cancel_adhoc_duty

---

## 8. Assignment Generation Engine

### 8.1 Three-Shift Rotation System

The AssignmentGenerationService implements a deterministic 3-shift rotation that ensures no personnel work the same shift on consecutive days.

```mermaid
flowchart TB
    START[Cycle Created] --> FETCH[Fetch Active Personnel<br>per Platoon-Section Mapping]
    FETCH --> DIVIDE[Divide into 3 Groups<br>A, B, C by personnel ID order]
    DIVIDE --> LOOP[For each day in cycle]
    LOOP --> PATTERN{Day Index % 3}
    PATTERN -->|0| P0["A→DAY, B→AFTERNOON, C→NIGHT"]
    PATTERN -->|1| P1["A→NIGHT, B→DAY, C→AFTERNOON"]
    PATTERN -->|2| P2["A→AFTERNOON, B→NIGHT, C→DAY"]
    P0 --> CREATE[Create CycleDutyAssignment<br>per person per day]
    P1 --> CREATE
    P2 --> CREATE
    CREATE --> SAVE[Bulk save all assignments]
```

**Rotation Pattern Table:**
| Day % 3 | Group A | Group B | Group C |
|---------|---------|---------|---------|
| 0 | DAY | AFTERNOON | NIGHT |
| 1 | NIGHT | DAY | AFTERNOON |
| 2 | AFTERNOON | NIGHT | DAY |

**Group Division Logic:**
- Personnel sorted by ID (deterministic ordering)
- Group A size = ⌈total/3⌉ (gets extra if remainder ≥ 1)
- Group B size = ⌈total/3⌉ (gets extra if remainder = 2)
- Group C size = ⌊total/3⌋

---

## 9. Report Generation Architecture

### 9.1 Report Engine Design

```mermaid
classDiagram
    class PdfReportGenerator {
        <<interface>>
        +getReportType() String
        +generate(ReportRequest) byte[]
    }

    class PlatoonChartPdfGenerator {
        +generate(request) byte[]
    }

    class Form168PdfGenerator {
        +generate(request) byte[]
    }

    class SectionABPdfGenerator {
        +generate(request) byte[]
    }

    class MtSectionPdfGenerator {
        +generate(request) byte[]
    }

    class LeaveStatementPdfGenerator {
        +generate(request) byte[]
    }

    class PersonnelListPdfGenerator {
        +generate(request) byte[]
    }

    PdfReportGenerator <|.. PlatoonChartPdfGenerator
    PdfReportGenerator <|.. Form168PdfGenerator
    PdfReportGenerator <|.. SectionABPdfGenerator
    PdfReportGenerator <|.. MtSectionPdfGenerator
    PdfReportGenerator <|.. LeaveStatementPdfGenerator
    PdfReportGenerator <|.. PersonnelListPdfGenerator
```

**Report Types and Generators:**
| Report Type Key | PDF Generator | Excel Generator |
|----------------|---------------|-----------------|
| platoon_chart | PlatoonChartPdfGenerator | PlatoonChartExcelGenerator |
| form_168 | Form168PdfGenerator | DailyStatementExcelGenerator |
| section_ab | SectionABPdfGenerator | SectionABExcelGenerator |
| mt_section | MtSectionPdfGenerator | MtSectionExcelGenerator |
| leave_statement | LeaveStatementPdfGenerator | LeaveStatementExcelGenerator |
| personnel_list | PersonnelListPdfGenerator | — (PDF only) |

---

## 10. Deployment Architecture

### 10.1 Production Deployment Topology

```mermaid
graph TB
    subgraph "Internet"
        USER[End Users<br>Police Officers]
    end

    subgraph "AWS Cloud"
        subgraph "Frontend"
            CF[CloudFront CDN]
            S3[S3 Bucket<br>React Build]
        end

        subgraph "Backend - EC2"
            EC2[EC2 Instance<br>t3.medium+]
            SYSTEMD[systemd service<br>ksp-backend.service]
            JAVA[Java 17 Runtime<br>Spring Boot JAR]
        end

        subgraph "Database"
            RDS[PostgreSQL<br>RDS or EC2-hosted]
        end
    end

    subgraph "External"
        GROQ_API[Groq API<br>api.groq.com]
        BEDROCK_API[AWS Bedrock<br>us-east-1]
    end

    USER -->|HTTPS| CF
    CF --> S3
    USER -->|HTTPS :8080| EC2
    EC2 --> SYSTEMD
    SYSTEMD --> JAVA
    JAVA --> RDS
    JAVA --> GROQ_API
    JAVA --> BEDROCK_API
```

### 10.2 Server Configuration

| Component | Specification |
|-----------|--------------|
| Application Server | AWS EC2 (t3.medium recommended) |
| OS | Amazon Linux 2 / Ubuntu 22.04 |
| JVM | OpenJDK 17 |
| Process Manager | systemd (ksp-backend.service) |
| Port | 8080 (configurable) |
| Database | PostgreSQL 15+ (same EC2 or RDS) |
| Frontend | S3 + CloudFront (or Nginx on same EC2) |

### 10.3 Deployment Scripts

| Script | Location | Purpose |
|--------|----------|---------|
| setup-ec2.sh | deploy/aws/ | Initial EC2 setup (Java, PostgreSQL, systemd) |
| deploy-backend.sh | deploy/aws/ | Build JAR, upload, restart service |
| deploy-frontend.sh | deploy/aws/ | Build React, sync to S3 |
| deploy.sh | deploy/aws/ | Combined full deployment |
| ksp-backend.service | deploy/aws/ | systemd unit file |

---

## 11. Communication Patterns

### 11.1 Frontend-Backend Communication

```mermaid
sequenceDiagram
    participant FE as React SPA
    participant AX as Axios Interceptor
    participant BE as Spring Boot API

    FE->>AX: API Call
    AX->>AX: Attach JWT Token<br>Authorization: Bearer {token}
    AX->>BE: HTTPS Request
    BE->>BE: JwtAuthFilter validates
    BE->>BE: Process request
    BE-->>AX: JSON Response
    AX->>AX: Check for 401
    alt 401 Received
        AX->>FE: Redirect to /login
    else Success
        AX-->>FE: Response data
    end
```

### 11.2 Backend-LLM Communication

| Provider | Protocol | Auth | Format |
|----------|----------|------|--------|
| Groq | HTTPS REST | API Key (Bearer) | OpenAI-compatible JSON |
| Bedrock | AWS SDK | IAM Role (STS) | Converted to OpenAI format |

### 11.3 Error Response Format (Global)

```json
{
  "error": {
    "code": "ERROR_CODE",
    "message": "Human-readable description",
    "timestamp": "2026-06-21T10:00:00Z"
  }
}
```

---

## 12. Cross-Cutting Concerns

### 12.1 Logging

| Aspect | Implementation |
|--------|----------------|
| Framework | SLF4J + Logback (Spring Boot default) |
| Log Level | INFO (production), DEBUG (development) |
| Key Logged Events | Chat processing time, tool execution, authentication, errors |
| PII Handling | PiiFilter logs access to sensitive endpoints |

### 12.2 Transaction Management

| Pattern | Usage |
|---------|-------|
| @Transactional (write) | CycleService.createCycle, updateCycle, deleteCycle |
| @Transactional (write) | LeaveService.submit, approve, reject, cancel |
| @Transactional (write) | PersonnelService.create, update, delete |
| Read operations | No explicit transaction (JPA default) |

### 12.3 Internationalization (i18n)

| Component | Approach |
|-----------|----------|
| Frontend | i18next with translations fetched from server |
| Backend (Chat) | LanguageDetectorService + TranslationService |
| Database | translations table (key, locale, value) |
| Supported Locales | en (English), kn (Kannada) |

### 12.4 Pagination

| Component | Standard |
|-----------|----------|
| Backend | Spring Data Pageable (page, size, sort) |
| Default Size | 20 items per page |
| Frontend | MUI DataGrid / Table with pagination controls |

---

## 13. Key Design Decisions

| # | Decision | Rationale | Trade-off |
|---|----------|-----------|-----------|
| 1 | JWT over Session | Stateless scaling, no session store needed | Token revocation is harder (mitigated by short TTL) |
| 2 | MCP over direct service calls for chat | Extensibility, tool discovery, isolation | Slight overhead for routing |
| 3 | Groq for dev, Bedrock for prod | Cost optimization (free Groq tier for dev) | Must maintain two client implementations |
| 4 | Soft-delete for cycles | Audit preservation, reversibility | DB grows over time |
| 5 | Caffeine cache over Redis | Simplicity (single instance deployment) | Not suitable for multi-instance |
| 6 | OpenPDF over iText | Open-source license (no AGPL concerns) | Fewer features |
| 7 | MobX over Redux | Less boilerplate for small-medium app | Smaller community |
| 8 | pgvector over external vector DB | Single database, simpler ops | Limited to PostgreSQL |
| 9 | 3-shift rotation engine | Fair duty distribution, no consecutive same-shift | Complex assignment generation |
| 10 | Circular platoon rotation | Prevents same-section consecutive assignment | Fixed to 5 platoons/5 sections |

---

## 14. Scalability Considerations

### 14.1 Current Architecture (Single Instance)

```
[Browser] → [EC2: Spring Boot + PostgreSQL] → [Groq/Bedrock API]
```

### 14.2 Future Scaling Path

```mermaid
graph LR
    LB[Load Balancer] --> EC2_1[EC2 Instance 1]
    LB --> EC2_2[EC2 Instance 2]
    EC2_1 --> RDS[(RDS PostgreSQL)]
    EC2_2 --> RDS
    EC2_1 --> REDIS[ElastiCache Redis<br>Shared Cache]
    EC2_2 --> REDIS
```

**Scaling changes needed:**
| Current | Scaled |
|---------|--------|
| Caffeine (local cache) | Redis (shared cache) |
| Single EC2 | Multiple EC2 behind ALB |
| PostgreSQL on EC2 | Amazon RDS |
| File-based reports | S3-based report storage |

---

## 15. Observations & Notes

1. **No message queue** — All operations are synchronous. Future heavy operations (batch assignment generation) could benefit from async processing.
2. **No WebSocket** — Chat is request-response HTTP. Real-time push notifications would require WebSocket addition.
3. **Single-tenant** — Designed for one police station. Multi-tenant would require schema or data partitioning changes.
4. **No API versioning** — All endpoints are v1 implicitly. Future breaking changes need versioning strategy.
5. **JPA open-in-view disabled** — `spring.jpa.open-in-view: false` prevents N+1 issues but requires explicit fetch joins.

---

## 16. Document Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0.0 | June 2026 | Generated from Codebase | Initial complete HLD |

---

*End of Document — HLD v1.0.0*

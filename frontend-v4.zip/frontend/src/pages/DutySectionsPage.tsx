import React from 'react';
import { observer } from 'mobx-react-lite';
import { Box, Typography, Button } from '@mui/material';
import { useTranslation } from 'react-i18next';
import AddIcon from '@mui/icons-material/Add';

import { dutySectionStore } from '@/stores/dutySectionStore';
import DutyAndSectionsTab from '@/components/DutyAndSectionsTab';

/**
 * DutySectionsPage — Enterprise-level Duty & Sections management page.
 * Features a dark navy header with stats, professional layout.
 */
const DutySectionsPage: React.FC = observer(() => {
  const { t } = useTranslation();
  const { dutyTypes, personnel } = dutySectionStore;

  const totalPosts = dutyTypes.length;
  const totalPersonnel = personnel.length;

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', backgroundColor: '#F8FAFC' }}>
      {/* Dark Navy Page Header */}
      <Box
        sx={{
          background: 'linear-gradient(135deg, #1a1e4a 0%, #2d3561 100%)',
          color: 'white',
          px: { xs: 2, md: 4 },
          pt: 2,
          pb: 1.5,
        }}
      >
        {/* Top row: Title + Add button */}
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
          <Box>
            <Typography variant="h5" fontWeight={700} sx={{ letterSpacing: '-0.02em' }}>
              {t('admin.tabs.dutySections', 'Duty & Sections')}
            </Typography>
            <Typography variant="body2" sx={{ color: 'rgba(255,255,255,0.7)', mt: 0.5 }}>
              {t('admin.dutySections.subtitle', 'Mangaluru Division duty posts & personnel management')} — {totalPosts} {t('admin.dutySections.addDutyType', 'duty posts')} · {totalPersonnel} {t('personnel.title', 'personnel')}
            </Typography>
          </Box>
          <Button
            startIcon={<AddIcon />}
            onClick={() => dutySectionStore.openAddDutyTypeDialog()}
            sx={{
              backgroundColor: 'rgba(255,255,255,0.08)',
              backdropFilter: 'blur(8px)',
              border: '1px solid rgba(255,255,255,0.2)',
              color: 'white',
              textTransform: 'none',
              fontWeight: 600,
              fontSize: '0.82rem',
              borderRadius: 2,
              px: 2,
              '&:hover': {
                backgroundColor: 'rgba(255,255,255,0.15)',
                borderColor: 'rgba(255,255,255,0.4)',
              },
            }}
          >
            {t('admin.dutySections.addDutyType', '+ Add Duty Type')}
          </Button>
        </Box>
      </Box>

      {/* Main Content Area */}
      <Box sx={{ flex: 1, px: { xs: 2, md: 3 }, py: 2 }}>
        <DutyAndSectionsTab />
      </Box>
    </Box>
  );
});

export default DutySectionsPage;

package com.policescheduler.repository;

import com.policescheduler.entity.RotationHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RotationHistoryRepository extends JpaRepository<RotationHistory, Long> {

    List<RotationHistory> findByCycleIdOrderByPlatoonId(Long cycleId);

    List<RotationHistory> findByPlatoonIdOrderByCreatedAtDesc(Long platoonId);

    List<RotationHistory> findAllByOrderByCreatedAtDesc();
}

package com.policescheduler.report.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class GrandTotalSection {
    private int[] companyTotal; // 8 elements
    private int[] underTraining; // 8 elements
    private int[] recruitApcs; // 8 elements
    private int[] pmtLine; // 8 elements
    private int[] grandTotal; // 8 elements
}

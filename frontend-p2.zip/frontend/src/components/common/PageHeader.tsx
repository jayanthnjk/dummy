import React, { useState, useEffect, useRef } from 'react';
import {
  Box,
  Typography,
  Breadcrumbs,
  Link,
  Button,
  IconButton,
  Menu,
  MenuItem,
  ListItemIcon,
  ListItemText,
  CircularProgress,
  useMediaQuery,
  useTheme,
} from '@mui/material';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';

/**
 * Breadcrumb item configuration
 */
export interface BreadcrumbItem {
  /** Display text for the breadcrumb */
  label: string;
  /** Navigation path. undefined = current page (non-clickable) */
  path?: string;
}

/**
 * Action button configuration for the PageHeader
 */
export interface ActionButtonConfig {
  /** Button display text */
  label: string;
  /** Visual variant of the button */
  variant: 'primary' | 'secondary' | 'destructive' | 'ghost';
  /** Optional icon to display before the label */
  icon?: React.ReactNode;
  /** Click handler */
  onClick: () => void;
  /** Whether the button is in a loading state */
  loading?: boolean;
}

/**
 * Props for the PageHeader component
 */
export interface PageHeaderProps {
  /** Page title rendered as h5 */
  title: string;
  /** Breadcrumb navigation path items */
  breadcrumbs?: BreadcrumbItem[];
  /** Action buttons displayed right-aligned (max 3) */
  actions?: ActionButtonConfig[];
}

/**
 * Pure function that truncates breadcrumb items to a maximum of 4.
 * - If items.length <= 4, returns items as-is.
 * - If items.length > 4, returns [first, ellipsis, second-to-last, last]
 *   (keeping first, last two visible, ellipsis in middle).
 *
 * Exported as named export for property-based testing.
 */
export function getBreadcrumbsDisplay(items: BreadcrumbItem[]): BreadcrumbItem[] {
  if (items.length <= 4) {
    return items;
  }
  return [
    items[0],
    { label: '…' },
    items[items.length - 2],
    items[items.length - 1],
  ];
}

/**
 * Maps ActionButtonConfig variant to MUI Button props
 */
function getButtonStyles(variant: ActionButtonConfig['variant']) {
  switch (variant) {
    case 'primary':
      return { variant: 'contained' as const, color: 'primary' as const };
    case 'secondary':
      return { variant: 'outlined' as const, color: 'primary' as const };
    case 'destructive':
      return {
        variant: 'contained' as const,
        sx: {
          backgroundColor: '#fff1f2',
          color: '#e11d48',
          boxShadow: 'none',
          background: '#fff1f2',
          '&:hover': {
            backgroundColor: '#ffe4e6',
            background: '#ffe4e6',
            boxShadow: 'none',
          },
        },
      };
    case 'ghost':
      return {
        variant: 'text' as const,
        sx: {
          opacity: 0.6,
          '&:hover': { opacity: 1, backgroundColor: 'rgba(0,0,0,0.08)' },
        },
      };
  }
}

/**
 * PageHeader renders a clean page header with title, breadcrumbs, and action buttons.
 * - White background with 1px bottom border
 * - Becomes sticky with shadow after 8px scroll
 * - Actions collapse to "More" menu below 600px viewport
 */
const PageHeader: React.FC<PageHeaderProps> = ({ title, breadcrumbs, actions }) => {
  const theme = useTheme();
  const isBelowSm = useMediaQuery('(max-width:599px)');
  const [isSticky, setIsSticky] = useState(false);
  const [menuAnchorEl, setMenuAnchorEl] = useState<null | HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);

  // Track scroll position to toggle sticky shadow
  useEffect(() => {
    const handleScroll = () => {
      setIsSticky(window.scrollY > 8);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    // Check initial scroll position
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const displayBreadcrumbs = breadcrumbs ? getBreadcrumbsDisplay(breadcrumbs) : undefined;
  const displayActions = actions?.slice(0, 3); // max 3 actions

  const handleMoreClick = (event: React.MouseEvent<HTMLElement>) => {
    setMenuAnchorEl(event.currentTarget);
  };

  const handleMoreClose = () => {
    setMenuAnchorEl(null);
  };

  const handleActionClick = (action: ActionButtonConfig) => {
    handleMoreClose();
    action.onClick();
  };

  return (
    <Box
      ref={headerRef}
      component="header"
      sx={{
        position: 'sticky',
        top: 0,
        zIndex: theme.zIndex.appBar - 1,
        backgroundColor: '#ffffff',
        borderBottom: `1px solid ${theme.palette.divider}`,
        paddingTop: '16px',
        paddingBottom: '12px',
        paddingLeft: '24px',
        paddingRight: '24px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: 1,
        boxShadow: isSticky ? '0 2px 4px rgba(0,0,0,0.1)' : 'none',
        transition: 'box-shadow 200ms ease',
      }}
    >
      {/* Left section: breadcrumbs + title */}
      <Box sx={{ minWidth: 0, flex: 1 }}>
        {displayBreadcrumbs && displayBreadcrumbs.length > 0 && (
          <Breadcrumbs
            separator={<NavigateNextIcon fontSize="small" />}
            aria-label="breadcrumb"
            sx={{ mb: 0.5 }}
          >
            {displayBreadcrumbs.map((item, index) => {
              // Ellipsis item — non-clickable
              if (item.label === '…') {
                return (
                  <Typography key={`ellipsis-${index}`} variant="body2" color="text.secondary">
                    …
                  </Typography>
                );
              }
              // Last item or no path — non-clickable (current page)
              if (!item.path) {
                return (
                  <Typography key={index} variant="body2" color="text.primary" fontWeight={500}>
                    {item.label}
                  </Typography>
                );
              }
              // Clickable breadcrumb link
              return (
                <Link
                  key={index}
                  href={item.path}
                  underline="hover"
                  variant="body2"
                  color="text.secondary"
                >
                  {item.label}
                </Link>
              );
            })}
          </Breadcrumbs>
        )}
        <Typography variant="h5" component="h1" fontWeight={700} noWrap>
          {title}
        </Typography>
      </Box>

      {/* Right section: action buttons */}
      {displayActions && displayActions.length > 0 && (
        <>
          {/* Desktop: show buttons inline */}
          {!isBelowSm && (
            <Box sx={{ display: 'flex', gap: 1, alignItems: 'center', flexShrink: 0 }}>
              {displayActions.map((action, index) => {
                const btnStyles = getButtonStyles(action.variant);
                return (
                  <Button
                    key={index}
                    variant={btnStyles.variant}
                    color={'color' in btnStyles ? btnStyles.color : undefined}
                    onClick={action.onClick}
                    disabled={action.loading}
                    aria-busy={action.loading || undefined}
                    aria-disabled={action.loading || undefined}
                    startIcon={
                      action.loading ? (
                        <CircularProgress size={16} color="inherit" />
                      ) : (
                        action.icon
                      )
                    }
                    size="small"
                    sx={{
                      ...('sx' in btnStyles ? btnStyles.sx : {}),
                      opacity: action.loading ? 0.7 : undefined,
                      pointerEvents: action.loading ? 'none' : undefined,
                    }}
                  >
                    {action.label}
                  </Button>
                );
              })}
            </Box>
          )}

          {/* Mobile: collapse to "More actions" menu */}
          {isBelowSm && (
            <>
              <IconButton
                onClick={handleMoreClick}
                aria-label="More actions"
                size="small"
              >
                <MoreVertIcon />
              </IconButton>
              <Menu
                anchorEl={menuAnchorEl}
                open={Boolean(menuAnchorEl)}
                onClose={handleMoreClose}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                transformOrigin={{ vertical: 'top', horizontal: 'right' }}
              >
                {displayActions.map((action, index) => (
                  <MenuItem
                    key={index}
                    onClick={() => handleActionClick(action)}
                    disabled={action.loading}
                  >
                    {action.icon && <ListItemIcon>{action.icon}</ListItemIcon>}
                    <ListItemText>{action.label}</ListItemText>
                  </MenuItem>
                ))}
              </Menu>
            </>
          )}
        </>
      )}
    </Box>
  );
};

export default PageHeader;

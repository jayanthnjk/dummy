/**
 * Color mapping utilities for schedule shift types.
 * All functions are pure with no side effects.
 */

/**
 * Default palette of 8 distinct colors for shift types.
 * Chosen to be visually distinguishable and provide good contrast options.
 */
export const DEFAULT_SHIFT_PALETTE: string[] = [
  '#1976D2', // Blue
  '#388E3C', // Green
  '#F57C00', // Orange
  '#7B1FA2', // Purple
  '#D32F2F', // Red
  '#0097A7', // Teal
  '#5D4037', // Brown
  '#C2185B', // Pink
];

/**
 * Computes a deterministic hash from a string.
 * Uses a simple but effective djb2 hash algorithm.
 */
function hashString(str: string): number {
  let hash = 5381;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) + hash + str.charCodeAt(i)) | 0;
  }
  // Ensure positive value
  return Math.abs(hash);
}

/**
 * Returns a deterministic color from the palette for a given shift type name.
 * The same name always maps to the same color, and different names map to
 * different colors (within the palette size).
 *
 * @param shiftTypeName - The name of the shift type (e.g., "Morning", "Night")
 * @param palette - Array of hex color strings to choose from
 * @returns A hex color string from the palette
 */
export function getShiftColor(shiftTypeName: string, palette: string[] = DEFAULT_SHIFT_PALETTE): string {
  if (!shiftTypeName) {
    return palette.length > 0 ? palette[0] : '#000000';
  }
  if (palette.length === 0) {
    return '#000000';
  }
  const index = hashString(shiftTypeName) % palette.length;
  return palette[index];
}

/**
 * Linearizes an sRGB channel value (0-255) to linear RGB (0-1).
 * Applies the standard sRGB transfer function inverse.
 */
function linearize(channel: number): number {
  const srgb = channel / 255;
  if (srgb <= 0.03928) {
    return srgb / 12.92;
  }
  return Math.pow((srgb + 0.055) / 1.055, 2.4);
}

/**
 * Computes the relative luminance of a color per WCAG 2.1 definition.
 * L = 0.2126 * R + 0.7152 * G + 0.0722 * B
 * where R, G, B are linearized sRGB values.
 *
 * @param r - Red channel (0-255)
 * @param g - Green channel (0-255)
 * @param b - Blue channel (0-255)
 * @returns Relative luminance (0-1)
 */
function getRelativeLuminance(r: number, g: number, b: number): number {
  return 0.2126 * linearize(r) + 0.7152 * linearize(g) + 0.0722 * linearize(b);
}

/**
 * Computes the WCAG contrast ratio between two relative luminances.
 * Contrast ratio = (L1 + 0.05) / (L2 + 0.05) where L1 >= L2.
 */
function getContrastRatio(l1: number, l2: number): number {
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  return (lighter + 0.05) / (darker + 0.05);
}

/**
 * Parses a hex color string (with or without #) into RGB components.
 *
 * @param hex - Hex color string (e.g., "#FF5733" or "FF5733")
 * @returns Tuple of [r, g, b] values (0-255)
 */
function parseHex(hex: string): [number, number, number] {
  const cleaned = hex.replace(/^#/, '');
  const r = parseInt(cleaned.substring(0, 2), 16);
  const g = parseInt(cleaned.substring(2, 4), 16);
  const b = parseInt(cleaned.substring(4, 6), 16);
  return [r, g, b];
}

/**
 * Returns a text color (white or black) that guarantees WCAG 4.5:1 contrast
 * ratio against the given background color.
 *
 * Uses the standard relative luminance formula:
 * L = 0.2126*R + 0.7152*G + 0.0722*B (with linearized sRGB values)
 *
 * @param hexBackground - Hex background color (e.g., "#1976D2")
 * @returns '#FFFFFF' for dark backgrounds, '#000000' for light backgrounds
 */
export function getContrastTextColor(hexBackground: string): '#FFFFFF' | '#000000' {
  const [r, g, b] = parseHex(hexBackground);
  const bgLuminance = getRelativeLuminance(r, g, b);

  // White text luminance = 1.0, Black text luminance = 0.0
  const contrastWithWhite = getContrastRatio(1.0, bgLuminance);
  const contrastWithBlack = getContrastRatio(bgLuminance, 0.0);

  // Choose the text color that provides better contrast
  return contrastWithWhite >= contrastWithBlack ? '#FFFFFF' : '#000000';
}

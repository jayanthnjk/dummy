import React, { useState, useMemo } from 'react';
import {
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TablePagination, TableSortLabel, Box, TextField, InputAdornment,
  Typography, MenuItem, Select, Collapse, Button,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import { useTranslation } from 'react-i18next';

export interface Column<T> {
  id: keyof T & string;
  labelKey: string;
  sortable?: boolean;
  filterable?: boolean;
  filterType?: 'text' | 'select';
  filterOptions?: string[];
  render?: (row: T) => React.ReactNode;
  minWidth?: number;
  width?: number | string;
}

interface DataTableProps<T> {
  columns: Column<T>[];
  data: T[];
  keyField: keyof T & string;
  searchable?: boolean;
  searchPlaceholderKey?: string;
  actions?: (row: T) => React.ReactNode;
  dense?: boolean;
}

type Order = 'asc' | 'desc';

function DataTable<T>({
  columns, data, keyField, searchable = false, searchPlaceholderKey, actions, dense = false,
}: DataTableProps<T>) {
  const { t } = useTranslation();
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [orderBy, setOrderBy] = useState<string>('');
  const [order, setOrder] = useState<Order>('asc');
  const [search, setSearch] = useState('');
  const [columnFilters, setColumnFilters] = useState<Record<string, string>>({});
  const [filtersOpen, setFiltersOpen] = useState(false);

  const handleSort = (col: string) => {
    const isAsc = orderBy === col && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(col);
  };

  const getField = (row: T, key: string): unknown => (row as Record<string, unknown>)[key];

  const filtered = useMemo(() => {
    let result = [...data];
    if (search) {
      const q = search.toLowerCase();
      result = result.filter((row) =>
        columns.some((col) => String(getField(row, col.id) ?? '').toLowerCase().includes(q))
      );
    }
    for (const [key, val] of Object.entries(columnFilters)) {
      if (val && val !== 'All') {
        const q = val.toLowerCase();
        result = result.filter((row) => String(getField(row, key) ?? '').toLowerCase().includes(q));
      }
    }
    if (orderBy) {
      result.sort((a, b) => {
        const aVal = String(getField(a, orderBy) ?? '');
        const bVal = String(getField(b, orderBy) ?? '');
        return order === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      });
    }
    return result;
  }, [data, search, columnFilters, orderBy, order, columns]);

  const paged = filtered.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  /* Filter row */
  const hasFilters = columns.some(c => c.filterable);

  return (
    <Box>
      {/* Search + Filters */}
      {(searchable || hasFilters) && (
        <Box sx={{ mb: 2 }}>
          {searchable && (
            <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
              <TextField
                size="small" fullWidth
                placeholder={searchPlaceholderKey ? t(searchPlaceholderKey) : t('app.search')}
                value={search}
                onChange={(e) => { setSearch(e.target.value); setPage(0); }}
                InputProps={{
                  startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 18, color: '#9ca3af' }} /></InputAdornment>,
                }}
                sx={{
                  '& .MuiOutlinedInput-root': {
                    borderRadius: 2, bgcolor: '#fafaf8', fontSize: '0.85rem',
                    '& fieldset': { borderColor: '#e5e7eb' },
                    '&:hover fieldset': { borderColor: '#c4a44a' },
                    '&.Mui-focused fieldset': { borderColor: '#1a1e4a' },
                  },
                }}
              />
              {hasFilters && (
                <Button size="small" onClick={() => setFiltersOpen(o => !o)}
                  startIcon={<FilterListIcon sx={{ fontSize: 16 }} />}
                  endIcon={<KeyboardArrowDownIcon sx={{ fontSize: 16, transform: filtersOpen ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }} />}
                  sx={{
                    textTransform: 'none', fontSize: '0.78rem', fontWeight: 500,
                    color: filtersOpen ? '#1a1e4a' : '#6b6b80',
                    bgcolor: filtersOpen ? '#f0f0ff' : '#f9fafb',
                    border: '1px solid', borderColor: filtersOpen ? '#1a1e4a' : '#e5e7eb',
                    borderRadius: 2, px: 2, whiteSpace: 'nowrap',
                    '&:hover': { bgcolor: '#f0f0ff', borderColor: '#1a1e4a' },
                  }}>
                  Filters
                </Button>
              )}
            </Box>
          )}
          {hasFilters && (
            <Collapse in={filtersOpen}>
              <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap', alignItems: 'flex-end', mt: 2, p: 2, bgcolor: '#fafaf8', borderRadius: 2, border: '1px solid #f0ede6' }}>
              {columns.filter(c => c.filterable).map(col => (
                <Box key={col.id} sx={{ minWidth: 140, flex: '1 1 140px', maxWidth: 220 }}>
                  <Typography sx={{ fontSize: '0.72rem', fontWeight: 600, color: '#6b6b80', mb: 0.3, textTransform: 'uppercase' }}>
                    {t(col.labelKey)}
                  </Typography>
                  {col.filterType === 'select' && col.filterOptions ? (
                    <Select size="small" fullWidth displayEmpty
                      value={columnFilters[col.id] ?? 'All'}
                      onChange={(e) => { setColumnFilters(p => ({ ...p, [col.id]: e.target.value })); setPage(0); }}
                      sx={{ fontSize: '0.82rem', borderRadius: 1.5, bgcolor: '#fafaf8', '& fieldset': { borderColor: '#e5e7eb' } }}>
                      <MenuItem value="All">All</MenuItem>
                      {col.filterOptions.map(o => <MenuItem key={o} value={o}>{o}</MenuItem>)}
                    </Select>
                  ) : (
                    <TextField size="small" fullWidth
                      placeholder={`Filter by ${t(col.labelKey).toLowerCase()}`}
                      value={columnFilters[col.id] ?? ''}
                      onChange={(e) => { setColumnFilters(p => ({ ...p, [col.id]: e.target.value })); setPage(0); }}
                      sx={{
                        '& .MuiOutlinedInput-root': {
                          fontSize: '0.82rem', borderRadius: 1.5, bgcolor: '#fafaf8',
                          '& fieldset': { borderColor: '#e5e7eb' },
                        },
                      }}
                    />
                  )}
                </Box>
              ))}
              {/* Reset filters */}
              {(Object.values(columnFilters).some(v => v && v !== 'All') || search) && (
                <Box
                  onClick={() => { setColumnFilters({}); setSearch(''); setPage(0); }}
                  sx={{
                    px: 1.5, py: 0.8, cursor: 'pointer', borderRadius: 1.5,
                    fontSize: '0.78rem', fontWeight: 500, color: '#dc2626',
                    bgcolor: '#fef2f2', border: '1px solid #fecaca',
                    whiteSpace: 'nowrap', alignSelf: 'flex-end', mb: 0.3,
                    '&:hover': { bgcolor: '#fee2e2' },
                  }}
                >
                  Reset filters
                </Box>
              )}
              </Box>
            </Collapse>
          )}
        </Box>
      )}

      {/* Table */}
      <TableContainer sx={{ borderRadius: 2, border: '1px solid #f0ede6', overflow: 'hidden' }}>
        <Table size={dense ? 'small' : 'medium'}>
          <TableHead>
            <TableRow sx={{ bgcolor: '#f9fafb' }}>
              {columns.map((col) => (
                <TableCell key={col.id} sx={{
                  fontWeight: 600, fontSize: '0.75rem', color: '#6b6b80',
                  textTransform: 'uppercase', letterSpacing: '0.04em',
                  borderBottom: '2px solid #f0ede6', py: 1.5,
                  minWidth: col.minWidth, width: col.width,
                }}>
                  {col.sortable !== false ? (
                    <TableSortLabel active={orderBy === col.id} direction={orderBy === col.id ? order : 'asc'}
                      onClick={() => handleSort(col.id)}>
                      {t(col.labelKey)}
                    </TableSortLabel>
                  ) : t(col.labelKey)}
                </TableCell>
              ))}
              {actions && (
                <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem', color: '#6b6b80', textTransform: 'uppercase', borderBottom: '2px solid #f0ede6', py: 1.5 }}>
                  {t('app.actions')}
                </TableCell>
              )}
            </TableRow>
          </TableHead>
          <TableBody>
            {paged.length === 0 ? (
              <TableRow>
                <TableCell colSpan={columns.length + (actions ? 1 : 0)} align="center" sx={{ py: 6, color: '#9ca3af' }}>
                  <Typography sx={{ fontSize: '0.88rem' }}>{t('app.noData')}</Typography>
                </TableCell>
              </TableRow>
            ) : paged.map((row) => (
              <TableRow key={String(getField(row, keyField))} hover
                sx={{ '&:hover': { bgcolor: '#fafaf8' }, '& td': { borderBottom: '1px solid #f5f3ee' } }}>
                {columns.map((col) => (
                  <TableCell key={col.id} sx={{ fontSize: '0.85rem', color: '#374151', py: 1.5 }}>
                    {col.render ? col.render(row) : String(getField(row, col.id) ?? '')}
                  </TableCell>
                ))}
                {actions && <TableCell sx={{ py: 1.5 }}>{actions(row)}</TableCell>}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <TablePagination
        component="div" count={filtered.length} page={page} rowsPerPage={rowsPerPage}
        onPageChange={(_, p) => setPage(p)}
        onRowsPerPageChange={(e) => { setRowsPerPage(parseInt(e.target.value, 10)); setPage(0); }}
        rowsPerPageOptions={[5, 10, 25, 50]}
        sx={{ '& .MuiTablePagination-selectLabel, & .MuiTablePagination-displayedRows': { fontSize: '0.8rem', color: '#6b6b80' } }}
      />
    </Box>
  );
}

export default DataTable;

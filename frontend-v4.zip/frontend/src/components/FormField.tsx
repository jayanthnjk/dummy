import React from 'react';
import { TextField, Typography, Box, type TextFieldProps } from '@mui/material';
import { useTranslation } from 'react-i18next';

interface FormFieldProps extends Omit<TextFieldProps, 'label'> {
  labelKey: string;
  required?: boolean;
}

const FormField: React.FC<FormFieldProps> = ({ labelKey, required, ...props }) => {
  const { t } = useTranslation();
  const label = `${t(labelKey)}${required ? ' *' : ''}`;

  return (
    <Box>
      <Typography sx={{ fontSize: '0.75rem', fontWeight: 600, color: '#4b5563', mb: 0.5 }}>
        {label}
      </Typography>
      <TextField
        placeholder={label}
        fullWidth
        size="small"
        {...props}
        sx={{
          '& .MuiOutlinedInput-root': {
            borderRadius: 1.5, fontSize: '0.85rem',
            '& fieldset': { borderColor: '#e5e7eb' },
            '&:hover fieldset': { borderColor: '#c4a44a' },
            '&.Mui-focused fieldset': { borderColor: '#1a1e4a', borderWidth: 1.5 },
          },
          ...((props.sx as object) || {}),
        }}
      />
    </Box>
  );
};

export default FormField;

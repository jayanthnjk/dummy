package com.policescheduler.service;

import com.policescheduler.entity.AdhocDuty;
import com.policescheduler.entity.DutyReassignment;
import com.policescheduler.entity.LeaveRequest;
import com.policescheduler.repository.AdhocDutyRepository;
import com.policescheduler.repository.DutyReassignmentRepository;
import com.policescheduler.repository.LeaveRequestRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

/**
 * Scheduled service for updating status fields in the database.
 * 
 * Schedules:
 * - 1:00 AM: Complete expired leave requests (APPROVED → COMPLETED)
 * - 3:00 AM: Expire duty reassignments and complete adhoc duties
 * 
 * This replaces the previous approach of triggering these updates on page load.
 */
@Service
public class StatusUpdateSchedulerService {

    private static final Logger log = LoggerFactory.getLogger(StatusUpdateSchedulerService.class);

    private final DutyReassignmentRepository dutyReassignmentRepository;
    private final AdhocDutyRepository adhocDutyRepository;
    private final LeaveRequestRepository leaveRequestRepository;

    public StatusUpdateSchedulerService(DutyReassignmentRepository dutyReassignmentRepository,
                                         AdhocDutyRepository adhocDutyRepository,
                                         LeaveRequestRepository leaveRequestRepository) {
        this.dutyReassignmentRepository = dutyReassignmentRepository;
        this.adhocDutyRepository = adhocDutyRepository;
        this.leaveRequestRepository = leaveRequestRepository;
    }

    // =========================================================================
    // LEAVE STATUS SCHEDULER: Runs daily at 1:00 AM
    // =========================================================================

    /**
     * Scheduled job to complete expired leave requests.
     * Runs daily at 1:00 AM.
     * 
     * Logic:
     * - Finds all APPROVED leaves where endDate < today
     * - Updates status to 'COMPLETED'
     * - Open-ended leaves (endDate IS NULL) remain APPROVED until manually closed
     */
    @Scheduled(cron = "0 0 1 * * ?")
    public void runLeaveStatusUpdates() {
        log.info("Starting scheduled job: runLeaveStatusUpdates at 1:00 AM");

        try {
            int completedLeaves = completeExpiredLeaves();
            log.info("Completed scheduled job: runLeaveStatusUpdates - Leaves completed: {}", completedLeaves);
        } catch (Exception e) {
            log.error("runLeaveStatusUpdates job failed: {}", e.getMessage(), e);
        }
    }

    // =========================================================================
    // MAIN SCHEDULER: Runs daily at 3:00 AM
    // =========================================================================

    /**
     * Main scheduled job that updates all status fields.
     * Runs daily at 3:00 AM.
     * 
     * Cron expression: "0 0 3 * * ?" means:
     * - 0 seconds
     * - 0 minutes  
     * - 3 hours (3 AM)
     * - Every day of month
     * - Every month
     * - Any day of week
     */
    @Scheduled(cron = "0 0 3 * * ?")
    public void runDailyStatusUpdates() {
        log.info("Starting scheduled job: runDailyStatusUpdates at 3:00 AM");

        try {
            // 1. Expire overdue duty reassignments
            int expiredReassignments = expireOverdueDutyReassignments();
            log.info("Expired {} duty reassignment(s)", expiredReassignments);

            // 2. Complete expired adhoc duties
            int completedAdhocDuties = completeExpiredAdhocDuties();
            log.info("Completed {} adhoc duty/duties", completedAdhocDuties);

            log.info("Completed scheduled job: runDailyStatusUpdates - " +
                     "Reassignments expired: {}, Adhoc duties completed: {}",
                     expiredReassignments, completedAdhocDuties);

        } catch (Exception e) {
            log.error("runDailyStatusUpdates job failed: {}", e.getMessage(), e);
        }
    }

    // =========================================================================
    // DUTY REASSIGNMENT EXPIRY
    // =========================================================================

    /**
     * Expires all ACTIVE duty reassignments whose endDate is before today.
     * 
     * Logic: Find all duty_reassignment records where:
     * - status = 'ACTIVE'
     * - end_date < today
     * Then update status to 'INACTIVE'
     * 
     * @return number of records expired
     */
    @Transactional
    public int expireOverdueDutyReassignments() {
        LocalDate today = LocalDate.now();
        
        // Query: status = 'ACTIVE' AND end_date < today
        List<DutyReassignment> expiredReassignments = dutyReassignmentRepository.findActiveExpiredBefore(today);
        
        if (expiredReassignments.isEmpty()) {
            log.debug("No overdue duty reassignments to expire");
            return 0;
        }

        for (DutyReassignment reassignment : expiredReassignments) {
            reassignment.setStatus("INACTIVE");
        }
        
        dutyReassignmentRepository.saveAll(expiredReassignments);
        log.info("Expired {} overdue duty reassignment(s)", expiredReassignments.size());
        
        return expiredReassignments.size();
    }

    // =========================================================================
    // ADHOC DUTY COMPLETION
    // =========================================================================

    /**
     * Completes all ACTIVE adhoc duties that have expired.
     * 
     * Logic: An adhoc duty is expired if:
     * - status = 'ACTIVE' AND
     * - (date < today) OR (date = today AND end_time < current_time)
     * Then update status to 'COMPLETED' and updated_at to now
     * 
     * @return number of records completed
     */
    @Transactional
    public int completeExpiredAdhocDuties() {
        LocalDate today = LocalDate.now();
        LocalTime currentTime = LocalTime.now();
        
        // Query: status = 'ACTIVE' AND ((date < today) OR (date = today AND end_time < current_time))
        List<AdhocDuty> expiredDuties = adhocDutyRepository.findExpiredActiveDuties(today, currentTime);
        
        if (expiredDuties.isEmpty()) {
            log.debug("No expired adhoc duties to complete");
            return 0;
        }

        int updatedCount = 0;
        for (AdhocDuty duty : expiredDuties) {
            duty.setStatus("COMPLETED");
            duty.setUpdatedAt(LocalDateTime.now());
            adhocDutyRepository.save(duty);
            updatedCount++;
        }
        
        log.info("Completed {} expired adhoc duty/duties", updatedCount);
        return updatedCount;
    }

    // =========================================================================
    // LEAVE REQUEST COMPLETION
    // =========================================================================

    /**
     * Completes all APPROVED leave requests that have ended.
     * 
     * Logic: Find all leave_request records where:
     * - status = 'APPROVED'
     * - end_date IS NOT NULL (has an end date)
     * - end_date < today
     * Then update status to 'COMPLETED'
     * 
     * Note: Open-ended leaves (end_date IS NULL) remain APPROVED until
     * manually closed using the closeLeave endpoint.
     * 
     * @return number of records completed
     */
    @Transactional
    public int completeExpiredLeaves() {
        LocalDate today = LocalDate.now();
        
        // Query: status = 'APPROVED' AND end_date IS NOT NULL AND end_date < today
        List<LeaveRequest> expiredLeaves = leaveRequestRepository.findApprovedLeavesEndedBefore(today);
        
        if (expiredLeaves.isEmpty()) {
            log.debug("No expired leave requests to complete");
            return 0;
        }

        for (LeaveRequest leave : expiredLeaves) {
            leave.setStatus("COMPLETED");
        }
        
        leaveRequestRepository.saveAll(expiredLeaves);
        log.info("Completed {} expired leave request(s)", expiredLeaves.size());
        
        return expiredLeaves.size();
    }

    // =========================================================================
    // MANUAL TRIGGER METHODS (for testing/admin purposes via API)
    // =========================================================================

    /**
     * Manually trigger all status updates.
     * Can be called via API for testing or immediate execution.
     * 
     * @return summary of updates performed
     */
    public StatusUpdateResult manuallyRunStatusUpdates() {
        log.info("Manual trigger: runStatusUpdates");
        
        int completedLeaves = completeExpiredLeaves();
        int expiredReassignments = expireOverdueDutyReassignments();
        int completedAdhocDuties = completeExpiredAdhocDuties();
        
        return new StatusUpdateResult(expiredReassignments, completedAdhocDuties, completedLeaves);
    }

    /**
     * Result class for manual trigger response.
     */
    public static class StatusUpdateResult {
        private final int expiredReassignments;
        private final int completedAdhocDuties;
        private final int completedLeaves;

        public StatusUpdateResult(int expiredReassignments, int completedAdhocDuties, int completedLeaves) {
            this.expiredReassignments = expiredReassignments;
            this.completedAdhocDuties = completedAdhocDuties;
            this.completedLeaves = completedLeaves;
        }

        public int getExpiredReassignments() {
            return expiredReassignments;
        }

        public int getCompletedAdhocDuties() {
            return completedAdhocDuties;
        }

        public int getCompletedLeaves() {
            return completedLeaves;
        }
    }
}

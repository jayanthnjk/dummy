import React, { useState } from 'react';
import {
  Box, Card, CardContent, Typography, Button, TextField, Alert,
  CircularProgress, Chip, Link, keyframes, InputAdornment,
} from '@mui/material';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import CalendarMonthOutlinedIcon from '@mui/icons-material/CalendarMonthOutlined';
import GroupsOutlinedIcon from '@mui/icons-material/GroupsOutlined';
import BarChartOutlinedIcon from '@mui/icons-material/BarChartOutlined';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguageContext } from '@/contexts/LanguageContext';
import { authService } from '@/services/authService';

/* ── Animations ── */
const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(20px); }
  to   { opacity: 1; transform: translateY(0); }
`;
const glowPulse = keyframes`
  0%, 100% { box-shadow: 0 0 24px rgba(184,164,114,0.12), 0 0 64px rgba(184,164,114,0.04); }
  50%      { box-shadow: 0 0 32px rgba(184,164,114,0.22), 0 0 80px rgba(184,164,114,0.08); }
`;
const shimmer = keyframes`
  0%   { background-position: -200% 0; }
  100% { background-position: 200% 0; }
`;

const LoginPage: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { login } = useAuth();
  const { locale, toggleLanguage } = useLanguageContext();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const response = await authService.login({ username, password });
      login(response);
      navigate('/');
    } catch (err: unknown) {
      const axiosErr = err as { response?: { status?: number } };
      setError(axiosErr.response?.status === 401
        ? t('login.invalidCredentials') : t('login.loginFailed'));
    } finally { setLoading(false); }
  };

  return (
    <Box sx={{ minHeight: '100vh', display: 'flex', flexDirection: { xs: 'column', md: 'row' } }}>

      {/* ═══════ LEFT PANEL ═══════ */}
      <Box sx={{
        flex: { xs: 'none', md: '0 0 50%' },
        minHeight: { xs: 300, md: '100vh' },
        background: 'linear-gradient(155deg, #0b0e2a 0%, #12153a 40%, #1a1e4a 100%)',
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center',
        p: { xs: 4, sm: 5, md: 6 },
        position: 'relative', overflow: 'hidden',
      }}>
        {/* Ambient blobs */}
        <Box sx={{ position: 'absolute', width: '60%', height: '60%', top: '-10%', left: '-15%',
          background: 'radial-gradient(circle, rgba(74,111,165,0.12) 0%, transparent 70%)',
          filter: 'blur(40px)', pointerEvents: 'none' }} />
        <Box sx={{ position: 'absolute', width: '50%', height: '50%', bottom: '-5%', right: '-10%',
          background: 'radial-gradient(circle, rgba(184,164,114,0.08) 0%, transparent 70%)',
          filter: 'blur(50px)', pointerEvents: 'none' }} />

        <Box sx={{ position: 'relative', zIndex: 1, textAlign: 'center', maxWidth: 400,
          animation: `${fadeIn} 0.8s ease-out` }}>

          {/* Shield logo */}
          <Box sx={{
            width: 88, height: 88, mx: 'auto', mb: 3, borderRadius: '22px',
            background: 'linear-gradient(135deg, rgba(184,164,114,0.12), rgba(184,164,114,0.04))',
            border: '1.5px solid rgba(184,164,114,0.2)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            animation: `${glowPulse} 4s ease-in-out infinite`,
          }}>
            <svg width="44" height="44" viewBox="0 0 24 24" fill="none">
              <path d="M12 2L4 5.5V11.5C4 16.45 7.4 21.05 12 22C16.6 21.05 20 16.45 20 11.5V5.5L12 2Z"
                stroke="#c4a44a" strokeWidth="1.5" fill="rgba(196,164,74,0.08)" />
              <path d="M9 12L11 14L15 10" stroke="#c4a44a" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </Box>

          <Typography sx={{
            fontWeight: 700, mb: 1,
            fontSize: { xs: '1.75rem', sm: '2rem', md: '2.25rem' },
            letterSpacing: '-0.5px',
            background: 'linear-gradient(135deg, #ffffff 0%, #c4a44a 100%)',
            backgroundClip: 'text', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          }}>
            {t('login.title')}
          </Typography>

          <Typography sx={{ color: 'rgba(255,255,255,0.4)', fontSize: { xs: '0.82rem', md: '0.88rem' },
            lineHeight: 1.6, mb: 5, px: 1 }}>
            {t('login.description')}
          </Typography>

          {/* Feature pills */}
          <Box sx={{ display: 'flex', gap: 1.5, justifyContent: 'center', flexWrap: 'wrap' }}>
            {[
              { icon: <CalendarMonthOutlinedIcon sx={{ fontSize: 18 }} />, text: t('login.featureScheduling') },
              { icon: <GroupsOutlinedIcon sx={{ fontSize: 18 }} />, text: t('login.featurePersonnel') },
              { icon: <BarChartOutlinedIcon sx={{ fontSize: 18 }} />, text: t('login.featureReports') },
            ].map((f, i) => (
              <Box key={i} sx={{
                display: 'flex', alignItems: 'center', gap: 0.7,
                px: 1.8, py: 0.8, borderRadius: '20px',
                bgcolor: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)',
                color: 'rgba(255,255,255,0.5)', fontSize: '0.78rem', fontWeight: 500,
                transition: 'all 0.3s',
                '&:hover': { bgcolor: 'rgba(184,164,114,0.1)', borderColor: 'rgba(184,164,114,0.25)', color: 'rgba(255,255,255,0.7)' },
              }}>
                {f.icon}{f.text}
              </Box>
            ))}
          </Box>
        </Box>
      </Box>

      {/* ═══════ RIGHT PANEL ═══════ */}
      <Box sx={{
        flex: 1, display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center',
        background: 'linear-gradient(180deg, #f5f3ee 0%, #eae6dd 100%)',
        p: { xs: 2, sm: 3, md: 5 }, position: 'relative',
        minHeight: { xs: 'auto', md: '100vh' },
      }}>

        {/* ── Language toggle (text-based) ── */}
        <Box sx={{ position: 'absolute', top: 20, right: 20 }}>
          <Chip
            label={locale === 'en' ? 'ಕನ್ನಡ' : 'English'}
            onClick={toggleLanguage}
            variant="outlined"
            size="small"
            sx={{
              fontWeight: 600, fontSize: '0.78rem', cursor: 'pointer',
              borderColor: '#c4a44a', color: '#6b5e3e',
              bgcolor: 'rgba(196,164,74,0.08)',
              transition: 'all 0.2s',
              '&:hover': { bgcolor: 'rgba(184,164,114,0.18)', borderColor: '#a89460' },
            }}
          />
        </Box>

        {/* ═══════ CARD ═══════ */}
        <Card elevation={0} sx={{
          width: '100%', maxWidth: 380, borderRadius: '18px',
          bgcolor: '#ffffff', position: 'relative', overflow: 'hidden',
          border: '1px solid rgba(184,164,114,0.15)',
          boxShadow:
            '0 1px 2px rgba(0,0,0,0.02),' +
            '0 4px 8px rgba(0,0,0,0.03),' +
            '0 12px 28px rgba(26,39,68,0.06),' +
            '0 24px 56px rgba(26,39,68,0.08)',
          animation: `${fadeIn} 0.6s ease-out 0.15s both`,
        }}>
          {/* Shimmer accent bar */}
          <Box sx={{
            height: 3, borderRadius: '18px 18px 0 0',
            background: 'linear-gradient(90deg, #c4a44a, #d4b85c, #1a1e4a, #c4a44a)',
            backgroundSize: '200% 100%',
            animation: `${shimmer} 4s linear infinite`,
          }} />

          {/* Inner glow effect at top */}
          <Box sx={{
            position: 'absolute', top: 4, left: '10%', right: '10%', height: 80,
            background: 'radial-gradient(ellipse at center, rgba(184,164,114,0.06) 0%, transparent 70%)',
            pointerEvents: 'none',
          }} />

          <CardContent sx={{ px: { xs: 2.5, sm: 3.5 }, py: { xs: 3, sm: 3.5 }, position: 'relative' }}>

            {/* Lock badge */}
            <Box sx={{
              width: 42, height: 42, borderRadius: '11px', mx: 'auto', mb: 2,
              background: 'linear-gradient(135deg, #1a1e4a 0%, #2a2e6a 100%)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: '0 3px 10px rgba(26,30,74,0.25)',
            }}>
              <LockOutlinedIcon sx={{ color: '#c4a44a', fontSize: 20 }} />
            </Box>

            <Typography sx={{
              fontWeight: 600, color: '#111827', textAlign: 'center', mb: 0.3,
              fontSize: { xs: '1.1rem', sm: '1.2rem' },
            }}>
              {t('login.welcomeBack')}
            </Typography>
            <Typography sx={{ color: '#9ca3af', fontSize: '0.8rem', textAlign: 'center', mb: 3 }}>
              {t('login.enterCredentials')}
            </Typography>

            {error && <Alert severity="error" sx={{ mb: 2, borderRadius: '10px', fontSize: '0.8rem' }}>{error}</Alert>}

            <Box component="form" onSubmit={handleSubmit}>
              {/* Username */}
              <Typography component="label" sx={{
                display: 'block', fontWeight: 500, color: '#4b5563',
                fontSize: '0.78rem', mb: 0.5,
              }}>
                {t('login.username')}
              </Typography>
              <TextField
                placeholder={t('login.usernamePlaceholder')}
                fullWidth size="small" value={username}
                onChange={(e) => setUsername(e.target.value)}
                required autoFocus
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <PersonOutlineIcon sx={{ fontSize: 18, color: '#b0a898' }} />
                    </InputAdornment>
                  ),
                }}
                sx={{
                  mb: 2,
                  '& .MuiOutlinedInput-root': {
                    borderRadius: '10px', bgcolor: '#fafaf8', fontSize: '0.85rem',
                    transition: 'all 0.25s ease',
                    '& fieldset': { borderColor: '#e8e4dc', transition: 'all 0.25s' },
                    '&:hover fieldset': { borderColor: '#c4a44a' },
                    '&.Mui-focused': {
                      bgcolor: '#fff', boxShadow: '0 0 0 3px rgba(196,164,74,0.12)',
                      '& fieldset': { borderColor: '#1a1e4a', borderWidth: 2 },
                    },
                  },
                }}
              />

              {/* Password */}
              <Typography component="label" sx={{
                display: 'block', fontWeight: 500, color: '#4b5563',
                fontSize: '0.78rem', mb: 0.5,
              }}>
                {t('login.password')}
              </Typography>
              <TextField
                placeholder={t('login.passwordPlaceholder')}
                type="password" fullWidth size="small" value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <LockOutlinedIcon sx={{ fontSize: 18, color: '#b0a898' }} />
                    </InputAdornment>
                  ),
                }}
                sx={{
                  mb: 1,
                  '& .MuiOutlinedInput-root': {
                    borderRadius: '10px', bgcolor: '#fafaf8', fontSize: '0.85rem',
                    transition: 'all 0.25s ease',
                    '& fieldset': { borderColor: '#e8e4dc', transition: 'all 0.25s' },
                    '&:hover fieldset': { borderColor: '#c4a44a' },
                    '&.Mui-focused': {
                      bgcolor: '#fff', boxShadow: '0 0 0 3px rgba(196,164,74,0.12)',
                      '& fieldset': { borderColor: '#1a1e4a', borderWidth: 2 },
                    },
                  },
                }}
              />

              <Box sx={{ textAlign: 'right', mb: 2.5 }}>
                <Link href="#" underline="none" sx={{
                  fontSize: '0.75rem', color: '#c4a44a', fontWeight: 500,
                  transition: 'color 0.2s', '&:hover': { color: '#b8963c' },
                }}>
                  {t('login.forgotPassword')}
                </Link>
              </Box>

              <Button
                type="submit" variant="contained" fullWidth size="large"
                disabled={loading || !username || !password}
                endIcon={!loading && <ArrowForwardIcon sx={{ fontSize: '18px !important' }} />}
                sx={{
                  textTransform: 'none', fontWeight: 600, borderRadius: '10px',
                  background: 'linear-gradient(135deg, #1a1e4a 0%, #2a2e6a 100%)',
                  color: '#fff', py: 1.2, fontSize: '0.88rem',
                  boxShadow: '0 3px 12px rgba(26,30,74,0.2)',
                  transition: 'all 0.25s ease',
                  '&:hover': {
                    background: 'linear-gradient(135deg, #0b0e2a 0%, #1a1e4a 100%)',
                    boxShadow: '0 6px 20px rgba(26,30,74,0.35)',
                    transform: 'translateY(-1px)',
                  },
                  '&.Mui-disabled': { background: '#e5e7eb', color: '#9ca3af', boxShadow: 'none' },
                }}
              >
                {loading ? <CircularProgress size={20} sx={{ color: '#c4a44a' }} /> : t('login.loginButton')}
              </Button>
            </Box>
          </CardContent>
        </Card>

        <Typography sx={{
          color: '#b0a898', fontSize: '0.72rem', mt: 3, letterSpacing: '0.02em',
          animation: `${fadeIn} 0.6s ease-out 0.4s both`,
        }}>
          © 2026 {t('login.title')}. {t('login.allRightsReserved')}
        </Typography>
      </Box>
    </Box>
  );
};

export default LoginPage;

import api from './api';
import type {
  DutyType,
  DutyTypeCreateRequest,
  DutyTypeUpdateRequest,
  Section,
  SectionCreateRequest,
  SectionUpdateRequest,
  Personnel,
  ReassignmentRequest,
  ReassignmentResult,
} from '@/types/dutySections';

// ===== Duty Types =====
export const dutyTypeService = {
  /** Fetch all duty types ordered by section + sort_order */
  list: () =>
    api.get<DutyType[]>('/api/duty-types').then((r) => r.data),

  /** Fetch duty types filtered by section code */
  listBySection: (sectionCode: string) =>
    api.get<DutyType[]>('/api/duty-types', { params: { section: sectionCode } }).then((r) => r.data),

  /** Create a new duty type */
  create: (request: DutyTypeCreateRequest) =>
    api.post<DutyType>('/api/duty-types', request).then((r) => r.data),

  /** Update an existing duty type */
  update: (id: number, request: DutyTypeUpdateRequest) =>
    api.put<DutyType>(`/api/duty-types/${id}`, request).then((r) => r.data),

  /** Delete a duty type (fails with 409 if active assignments exist) */
  remove: (id: number) =>
    api.delete(`/api/duty-types/${id}`),
};

// ===== Sections =====
export const dutySectionApiService = {
  /** Fetch all sections (active + inactive) */
  list: () =>
    api.get<Section[]>('/api/sections').then((r) => r.data),

  /** Fetch active sections only (for tab rendering) */
  listActive: () =>
    api.get<Section[]>('/api/sections/active').then((r) => r.data),

  /** Create a new section */
  create: (request: SectionCreateRequest) =>
    api.post<Section>('/api/sections', request).then((r) => r.data),

  /** Update an existing section */
  update: (id: number, request: SectionUpdateRequest) =>
    api.put<Section>(`/api/sections/${id}`, request).then((r) => r.data),

  /** Bulk reassign duty types to a different section */
  reassign: (request: ReassignmentRequest) =>
    api.post<ReassignmentResult>('/api/sections/reassign', request).then((r) => r.data),
};

// ===== Personnel (for duty section context) =====
export const dutySectionPersonnelService = {
  /** Fetch personnel for a given section */
  listBySection: (sectionCode: string) =>
    api.get<Personnel[]>('/api/personnel', { params: { section: sectionCode } }).then((r) => r.data),

  /** Fetch personnel for a specific duty type */
  listByDutyType: (dutyTypeId: number) =>
    api.get<Personnel[]>('/api/personnel', { params: { dutyTypeId } }).then((r) => r.data),
};

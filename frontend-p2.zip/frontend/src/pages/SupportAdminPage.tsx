import React, { useState, useEffect, useMemo } from 'react';
import {
  Box, Typography, TextField, Button, MenuItem, Card, CardContent,
  Chip, CircularProgress, Alert, Divider, InputAdornment, TablePagination,
  Dialog, DialogTitle, DialogContent, DialogActions, Tab, Tabs, IconButton,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import DownloadIcon from '@mui/icons-material/Download';
import VisibilityIcon from '@mui/icons-material/Visibility';
import LogoutIcon from '@mui/icons-material/Logout';
import CloseIcon from '@mui/icons-material/Close';
import { supportService, SupportTicket } from '@/services/supportService';
import { useAuth } from '@/contexts/AuthContext';

const STATUS_OPTIONS = ['OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED'];

const STATUS_COLORS: Record<string, 'warning' | 'info' | 'success' | 'default'> = {
  OPEN: 'warning',
  IN_PROGRESS: 'info',
  RESOLVED: 'success',
  CLOSED: 'default',
};

const PRIORITY_COLORS: Record<string, string> = {
  LOW: '#4caf50',
  MEDIUM: '#ff9800',
  HIGH: '#f44336',
  CRITICAL: '#9c27b0',
};

const CATEGORIES = [
  { value: 'BUG', label: 'Bug Report' },
  { value: 'FEATURE_REQUEST', label: 'Feature Request' },
  { value: 'GENERAL', label: 'General Inquiry' },
  { value: 'ACCESS_ISSUE', label: 'Access Issue' },
];

const SupportAdminPage: React.FC = () => {
  const { logout, displayName } = useAuth();
  const [tabIndex, setTabIndex] = useState(0);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Tickets tab state
  const [ticketSearch, setTicketSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [priorityFilter, setPriorityFilter] = useState('ALL');
  const [ticketPage, setTicketPage] = useState(0);
  const [ticketsPerPage, setTicketsPerPage] = useState(10);

  // Ticket detail dialog
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editStatus, setEditStatus] = useState('');
  const [editComment, setEditComment] = useState('');
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState('');

  // Reports tab state
  const [reportStatus, setReportStatus] = useState('');
  const [reportPriority, setReportPriority] = useState('');
  const [reportFrom, setReportFrom] = useState('');
  const [reportTo, setReportTo] = useState('');
  const [downloading, setDownloading] = useState(false);

  const loadTickets = async () => {
    try {
      setLoading(true);
      const data = await supportService.getAllTickets();
      setTickets(data);
    } catch {
      setError('Failed to load tickets');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTickets();
  }, []);

  const filteredTickets = useMemo(() => {
    let result = tickets;
    if (ticketSearch.trim()) {
      const q = ticketSearch.toLowerCase();
      result = result.filter((t) => t.subject.toLowerCase().includes(q) || t.submittedBy.toLowerCase().includes(q));
    }
    if (statusFilter !== 'ALL') {
      result = result.filter((t) => t.status === statusFilter);
    }
    if (priorityFilter !== 'ALL') {
      result = result.filter((t) => t.priority === priorityFilter);
    }
    return result;
  }, [tickets, ticketSearch, statusFilter, priorityFilter]);

  const paginatedTickets = useMemo(() => {
    const start = ticketPage * ticketsPerPage;
    return filteredTickets.slice(start, start + ticketsPerPage);
  }, [filteredTickets, ticketPage, ticketsPerPage]);

  const handleOpenDetail = (ticket: SupportTicket) => {
    setSelectedTicket(ticket);
    setEditStatus(ticket.status);
    setEditComment(ticket.adminResponse || '');
    setSaveSuccess('');
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!selectedTicket) return;
    setSaving(true);
    setSaveSuccess('');
    try {
      if (editStatus !== selectedTicket.status) {
        await supportService.updateTicketStatus(selectedTicket.id, editStatus);
      }
      if (editComment && editComment !== selectedTicket.adminResponse) {
        await supportService.addComment(selectedTicket.id, editComment);
      }
      setSaveSuccess('Ticket updated successfully');
      loadTickets();
      // Update selected ticket locally
      setSelectedTicket({ ...selectedTicket, status: editStatus, adminResponse: editComment });
    } catch {
      setError('Failed to update ticket');
    } finally {
      setSaving(false);
    }
  };

  const handleDownloadSinglePdf = async (id: number) => {
    try {
      const blob = await supportService.downloadTicketPdf(id);
      const url = window.URL.createObjectURL(new Blob([blob]));
      const link = document.createElement('a');
      link.href = url;
      link.download = `ticket-${id}.pdf`;
      link.click();
      window.URL.revokeObjectURL(url);
    } catch {
      setError('Failed to download PDF');
    }
  };

  const handleDownloadReport = async () => {
    setDownloading(true);
    try {
      const params: Record<string, string> = {};
      if (reportStatus) params.status = reportStatus;
      if (reportPriority) params.priority = reportPriority;
      if (reportFrom) params.from = reportFrom;
      if (reportTo) params.to = reportTo;

      const blob = await supportService.downloadReport(params);
      const url = window.URL.createObjectURL(new Blob([blob]));
      const link = document.createElement('a');
      link.href = url;
      link.download = 'ticket-report.pdf';
      link.click();
      window.URL.revokeObjectURL(url);
    } catch {
      setError('Failed to download report');
    } finally {
      setDownloading(false);
    }
  };

  // Count tickets matching report filters
  const reportFilteredCount = useMemo(() => {
    let result = tickets;
    if (reportStatus) result = result.filter((t) => t.status === reportStatus);
    if (reportPriority) result = result.filter((t) => t.priority === reportPriority);
    if (reportFrom) result = result.filter((t) => t.createdAt >= reportFrom);
    if (reportTo) result = result.filter((t) => t.createdAt <= reportTo + 'T23:59:59');
    return result.length;
  }, [tickets, reportStatus, reportPriority, reportFrom, reportTo]);

  return (
    <Box sx={{ minHeight: '100vh', bgcolor: '#f8fafc' }}>
      {/* Header */}
      <Box sx={{
        bgcolor: '#ffffff',
        borderBottom: '1px solid #e2e8f0',
        px: { xs: 2, md: 4 },
        py: 2,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        boxShadow: '0 1px 3px rgba(0,0,0,0.05)',
      }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <Box component="img" src="/ksplogo.png" alt="KSP Logo" sx={{ width: 40, height: 40, borderRadius: '50%' }} />
          <Box>
            <Typography variant="h6" fontWeight={700} sx={{ color: '#312e81', lineHeight: 1.2 }}>
              Support Admin Portal
            </Typography>
            <Typography variant="caption" color="text.secondary">
              KSP WorkBoard — Ticket Management
            </Typography>
          </Box>
        </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <Typography variant="body2" color="text.secondary" sx={{ display: { xs: 'none', sm: 'block' } }}>
            {displayName}
          </Typography>
          <Button
            variant="outlined"
            size="small"
            startIcon={<LogoutIcon />}
            onClick={logout}
            sx={{ textTransform: 'none', borderColor: '#e2e8f0', color: '#64748b' }}
          >
            Logout
          </Button>
        </Box>
      </Box>

      {/* Tabs */}
      <Box sx={{ px: { xs: 2, md: 4 }, pt: 2 }}>
        <Tabs
          value={tabIndex}
          onChange={(_, v) => setTabIndex(v)}
          sx={{
            '& .MuiTab-root': { textTransform: 'none', fontWeight: 600 },
            '& .Mui-selected': { color: '#312e81' },
            '& .MuiTabs-indicator': { backgroundColor: '#312e81' },
          }}
        >
          <Tab label="Tickets" />
          <Tab label="Reports" />
        </Tabs>
      </Box>

      {error && (
        <Box sx={{ px: { xs: 2, md: 4 }, pt: 2 }}>
          <Alert severity="error" onClose={() => setError('')}>{error}</Alert>
        </Box>
      )}

      {/* Tab Content */}
      <Box sx={{ px: { xs: 2, md: 4 }, py: 3 }}>
        {tabIndex === 0 && (
          <Box>
            {/* Filters */}
            <Box sx={{ display: 'flex', gap: 2, mb: 3, flexWrap: 'wrap', alignItems: 'center' }}>
              <TextField
                size="small"
                placeholder="Search by subject or user..."
                value={ticketSearch}
                onChange={(e) => { setTicketSearch(e.target.value); setTicketPage(0); }}
                sx={{ minWidth: 260, flex: 1 }}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon sx={{ fontSize: 18, color: '#9CA3AF' }} />
                    </InputAdornment>
                  ),
                }}
              />
              <TextField
                select size="small" label="Status"
                value={statusFilter}
                onChange={(e) => { setStatusFilter(e.target.value); setTicketPage(0); }}
                sx={{ minWidth: 140 }}
              >
                <MenuItem value="ALL">All Status</MenuItem>
                {STATUS_OPTIONS.map((s) => <MenuItem key={s} value={s}>{s.replace('_', ' ')}</MenuItem>)}
              </TextField>
              <TextField
                select size="small" label="Priority"
                value={priorityFilter}
                onChange={(e) => { setPriorityFilter(e.target.value); setTicketPage(0); }}
                sx={{ minWidth: 140 }}
              >
                <MenuItem value="ALL">All Priority</MenuItem>
                <MenuItem value="LOW">Low</MenuItem>
                <MenuItem value="MEDIUM">Medium</MenuItem>
                <MenuItem value="HIGH">High</MenuItem>
                <MenuItem value="CRITICAL">Critical</MenuItem>
              </TextField>
              <Chip label={`${filteredTickets.length} tickets`} size="small" variant="outlined" />
            </Box>

            {/* Ticket Table */}
            {loading ? (
              <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
                <CircularProgress />
              </Box>
            ) : filteredTickets.length === 0 ? (
              <Card elevation={0} sx={{ border: '1px solid #e2e8f0', borderRadius: 2 }}>
                <CardContent sx={{ textAlign: 'center', py: 6 }}>
                  <Typography color="text.secondary">No tickets found.</Typography>
                </CardContent>
              </Card>
            ) : (
              <Card elevation={0} sx={{ border: '1px solid #e2e8f0', borderRadius: 2, overflow: 'hidden' }}>
                {/* Table header */}
                <Box sx={{
                  display: 'grid',
                  gridTemplateColumns: '60px 2fr 100px 110px 120px 120px 130px 70px',
                  gap: 1,
                  px: 2, py: 1.5,
                  bgcolor: '#f1f5f9',
                  borderBottom: '1px solid #e2e8f0',
                  fontWeight: 600,
                  fontSize: '0.75rem',
                  color: '#475569',
                  textTransform: 'uppercase',
                  letterSpacing: '0.05em',
                }}>
                  <Box>ID</Box>
                  <Box>Subject</Box>
                  <Box>Priority</Box>
                  <Box>Status</Box>
                  <Box>Category</Box>
                  <Box>User</Box>
                  <Box>Date</Box>
                  <Box>Actions</Box>
                </Box>

                {/* Table rows */}
                {paginatedTickets.map((ticket) => (
                  <Box key={ticket.id} sx={{
                    display: 'grid',
                    gridTemplateColumns: '60px 2fr 100px 110px 120px 120px 130px 70px',
                    gap: 1,
                    px: 2, py: 1.5,
                    alignItems: 'center',
                    borderBottom: '1px solid #f1f5f9',
                    fontSize: '0.83rem',
                    '&:hover': { bgcolor: '#f8fafc' },
                    cursor: 'pointer',
                  }}
                    onClick={() => handleOpenDetail(ticket)}
                  >
                    <Box sx={{ color: '#6366f1', fontWeight: 600 }}>#{ticket.id}</Box>
                    <Box sx={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {ticket.subject}
                    </Box>
                    <Box>
                      <Chip
                        label={ticket.priority}
                        size="small"
                        sx={{
                          fontSize: '0.7rem', fontWeight: 600, height: 22,
                          bgcolor: `${PRIORITY_COLORS[ticket.priority]}20`,
                          color: PRIORITY_COLORS[ticket.priority],
                          border: `1px solid ${PRIORITY_COLORS[ticket.priority]}40`,
                        }}
                      />
                    </Box>
                    <Box>
                      <Chip
                        label={ticket.status.replace('_', ' ')}
                        size="small"
                        color={STATUS_COLORS[ticket.status] || 'default'}
                        sx={{ fontSize: '0.7rem', fontWeight: 600, height: 22 }}
                      />
                    </Box>
                    <Box sx={{ fontSize: '0.78rem', color: '#64748b' }}>
                      {CATEGORIES.find((c) => c.value === ticket.category)?.label || ticket.category}
                    </Box>
                    <Box sx={{ fontSize: '0.78rem', color: '#64748b' }}>{ticket.submittedBy}</Box>
                    <Box sx={{ fontSize: '0.78rem', color: '#64748b' }}>
                      {new Date(ticket.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })}
                    </Box>
                    <Box>
                      <IconButton size="small" onClick={(e) => { e.stopPropagation(); handleOpenDetail(ticket); }}>
                        <VisibilityIcon sx={{ fontSize: 18 }} />
                      </IconButton>
                    </Box>
                  </Box>
                ))}

                <TablePagination
                  component="div"
                  count={filteredTickets.length}
                  page={ticketPage}
                  onPageChange={(_, p) => setTicketPage(p)}
                  rowsPerPage={ticketsPerPage}
                  onRowsPerPageChange={(e) => { setTicketsPerPage(parseInt(e.target.value, 10)); setTicketPage(0); }}
                  rowsPerPageOptions={[5, 10, 25, 50]}
                />
              </Card>
            )}
          </Box>
        )}

        {tabIndex === 1 && (
          <Box>
            <Card elevation={0} sx={{ border: '1px solid #e2e8f0', borderRadius: 2, p: 3, maxWidth: 600 }}>
              <Typography variant="h6" fontWeight={600} sx={{ mb: 3 }}>
                Download Ticket Report
              </Typography>

              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2.5 }}>
                <Box sx={{ display: 'flex', gap: 2 }}>
                  <TextField
                    select size="small" label="Status" fullWidth
                    value={reportStatus}
                    onChange={(e) => setReportStatus(e.target.value)}
                  >
                    <MenuItem value="">All Status</MenuItem>
                    {STATUS_OPTIONS.map((s) => <MenuItem key={s} value={s}>{s.replace('_', ' ')}</MenuItem>)}
                  </TextField>
                  <TextField
                    select size="small" label="Priority" fullWidth
                    value={reportPriority}
                    onChange={(e) => setReportPriority(e.target.value)}
                  >
                    <MenuItem value="">All Priority</MenuItem>
                    <MenuItem value="LOW">Low</MenuItem>
                    <MenuItem value="MEDIUM">Medium</MenuItem>
                    <MenuItem value="HIGH">High</MenuItem>
                    <MenuItem value="CRITICAL">Critical</MenuItem>
                  </TextField>
                </Box>

                <Box sx={{ display: 'flex', gap: 2 }}>
                  <TextField
                    type="date" size="small" label="From Date" fullWidth
                    value={reportFrom}
                    onChange={(e) => setReportFrom(e.target.value)}
                    InputLabelProps={{ shrink: true }}
                  />
                  <TextField
                    type="date" size="small" label="To Date" fullWidth
                    value={reportTo}
                    onChange={(e) => setReportTo(e.target.value)}
                    InputLabelProps={{ shrink: true }}
                  />
                </Box>

                <Divider />

                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <Typography variant="body2" color="text.secondary">
                    Matching tickets: <strong>{reportFilteredCount}</strong>
                  </Typography>
                  <Button
                    variant="contained"
                    startIcon={downloading ? <CircularProgress size={16} /> : <DownloadIcon />}
                    onClick={handleDownloadReport}
                    disabled={downloading}
                    sx={{
                      textTransform: 'none', fontWeight: 600,
                      bgcolor: '#312e81', '&:hover': { bgcolor: '#1e1b4b' },
                    }}
                  >
                    {downloading ? 'Generating...' : 'Download Report'}
                  </Button>
                </Box>
              </Box>
            </Card>
          </Box>
        )}
      </Box>

      {/* Ticket Detail Dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', pb: 1 }}>
          <Typography variant="h6" fontWeight={600}>
            Ticket #{selectedTicket?.id}
          </Typography>
          <IconButton size="small" onClick={() => setDialogOpen(false)}>
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent dividers>
          {selectedTicket && (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <Box>
                <Typography variant="caption" color="text.secondary">Subject</Typography>
                <Typography variant="body1" fontWeight={600}>{selectedTicket.subject}</Typography>
              </Box>

              <Box sx={{ display: 'flex', gap: 2 }}>
                <Box sx={{ flex: 1 }}>
                  <Typography variant="caption" color="text.secondary">Submitted By</Typography>
                  <Typography variant="body2">{selectedTicket.submittedBy}</Typography>
                </Box>
                <Box sx={{ flex: 1 }}>
                  <Typography variant="caption" color="text.secondary">Date</Typography>
                  <Typography variant="body2">
                    {new Date(selectedTicket.createdAt).toLocaleString()}
                  </Typography>
                </Box>
              </Box>

              <Box sx={{ display: 'flex', gap: 2 }}>
                <Box sx={{ flex: 1 }}>
                  <Typography variant="caption" color="text.secondary">Category</Typography>
                  <Typography variant="body2">
                    {CATEGORIES.find((c) => c.value === selectedTicket.category)?.label || selectedTicket.category}
                  </Typography>
                </Box>
                <Box sx={{ flex: 1 }}>
                  <Typography variant="caption" color="text.secondary">Priority</Typography>
                  <Chip
                    label={selectedTicket.priority}
                    size="small"
                    sx={{
                      fontWeight: 600, mt: 0.5,
                      bgcolor: `${PRIORITY_COLORS[selectedTicket.priority]}20`,
                      color: PRIORITY_COLORS[selectedTicket.priority],
                    }}
                  />
                </Box>
              </Box>

              <Box>
                <Typography variant="caption" color="text.secondary">Message</Typography>
                <Typography variant="body2" sx={{ mt: 0.5, bgcolor: '#f8fafc', p: 1.5, borderRadius: 1 }}>
                  {selectedTicket.message}
                </Typography>
              </Box>

              <Divider />

              <TextField
                select size="small" label="Status" fullWidth
                value={editStatus}
                onChange={(e) => setEditStatus(e.target.value)}
              >
                {STATUS_OPTIONS.map((s) => <MenuItem key={s} value={s}>{s.replace('_', ' ')}</MenuItem>)}
              </TextField>

              <TextField
                label="Admin Comment / Resolution"
                multiline rows={3} fullWidth size="small"
                value={editComment}
                onChange={(e) => setEditComment(e.target.value)}
                placeholder="Add your comment or resolution..."
              />

              {saveSuccess && <Alert severity="success" sx={{ py: 0 }}>{saveSuccess}</Alert>}
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ px: 3, py: 2, justifyContent: 'space-between' }}>
          <Button
            variant="outlined"
            size="small"
            startIcon={<DownloadIcon />}
            onClick={() => selectedTicket && handleDownloadSinglePdf(selectedTicket.id)}
            sx={{ textTransform: 'none' }}
          >
            Download PDF
          </Button>
          <Box sx={{ display: 'flex', gap: 1 }}>
            <Button onClick={() => setDialogOpen(false)} sx={{ textTransform: 'none' }}>
              Cancel
            </Button>
            <Button
              variant="contained"
              onClick={handleSave}
              disabled={saving}
              sx={{
                textTransform: 'none', fontWeight: 600,
                bgcolor: '#312e81', '&:hover': { bgcolor: '#1e1b4b' },
              }}
            >
              {saving ? <CircularProgress size={16} /> : 'Save Changes'}
            </Button>
          </Box>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default SupportAdminPage;

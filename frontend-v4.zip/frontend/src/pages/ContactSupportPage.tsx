import React, { useState, useEffect } from 'react';
import {
  Box, Typography, TextField, Button, MenuItem, Card, CardContent,
  Chip, CircularProgress, Alert, Divider,
} from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import SupportAgentIcon from '@mui/icons-material/SupportAgent';
import { useTranslation } from 'react-i18next';
import { supportService, SupportTicket, CreateTicketRequest } from '@/services/supportService';

const CATEGORIES = [
  { value: 'BUG', label: 'Bug Report' },
  { value: 'FEATURE_REQUEST', label: 'Feature Request' },
  { value: 'GENERAL', label: 'General Inquiry' },
  { value: 'ACCESS_ISSUE', label: 'Access Issue' },
];

const PRIORITIES = [
  { value: 'LOW', label: 'Low' },
  { value: 'MEDIUM', label: 'Medium' },
  { value: 'HIGH', label: 'High' },
  { value: 'CRITICAL', label: 'Critical' },
];

const STATUS_COLORS: Record<string, 'warning' | 'info' | 'success' | 'default'> = {
  OPEN: 'warning',
  IN_PROGRESS: 'info',
  RESOLVED: 'success',
  CLOSED: 'default',
};

const ContactSupportPage: React.FC = () => {
  const { t } = useTranslation();
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [category, setCategory] = useState('GENERAL');
  const [priority, setPriority] = useState('MEDIUM');
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [loading, setLoading] = useState(true);

  const loadTickets = async () => {
    try {
      const data = await supportService.list();
      setTickets(data);
    } catch {
      // Silently fail on load
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTickets();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    setSuccess(false);

    try {
      const request: CreateTicketRequest = { subject, message, category, priority };
      await supportService.submit(request);
      setSuccess(true);
      setSubject('');
      setMessage('');
      setCategory('GENERAL');
      setPriority('MEDIUM');
      loadTickets();
    } catch {
      setError(t('support.ticketError', 'Failed to submit ticket. Please try again.'));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', backgroundColor: '#F8FAFC' }}>
      {/* Dark Navy Page Header */}
      <Box
        sx={{
          background: 'linear-gradient(135deg, #1a1e4a 0%, #2d3561 100%)',
          color: 'white',
          px: { xs: 2, md: 4 },
          pt: 2,
          pb: 1.5,
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1 }}>
          <SupportAgentIcon sx={{ fontSize: 28 }} />
          <Box>
            <Typography variant="h5" fontWeight={700} sx={{ letterSpacing: '-0.02em' }}>
              {t('support.title', 'Contact Support')}
            </Typography>
            <Typography variant="body2" sx={{ color: 'rgba(255,255,255,0.7)', mt: 0.5 }}>
              {t('support.subtitle', 'Submit a ticket or view your support history')}
            </Typography>
          </Box>
        </Box>
      </Box>

      {/* Content */}
      <Box sx={{ flex: 1, px: { xs: 2, md: 4 }, py: 3, maxWidth: 900, mx: 'auto', width: '100%' }}>
        {/* Submit Ticket Form */}
        <Card sx={{ mb: 4, borderRadius: 2, border: '1px solid #e5e7eb' }} elevation={0}>
          <CardContent sx={{ p: 3 }}>
            <Typography variant="h6" fontWeight={600} sx={{ mb: 2 }}>
              {t('support.submitNewTicket', 'Submit a New Ticket')}
            </Typography>

            {success && (
              <Alert severity="success" sx={{ mb: 2 }} onClose={() => setSuccess(false)}>
                {t('support.ticketSuccess', "Ticket submitted successfully! We'll get back to you soon.")}
              </Alert>
            )}
            {error && (
              <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>
                {error}
              </Alert>
            )}

            <Box component="form" onSubmit={handleSubmit} sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <TextField
                label={t('support.subject', 'Subject')}
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                required
                fullWidth
                size="small"
                placeholder={t('support.subject', 'Brief description of your issue')}
              />

              <Box sx={{ display: 'flex', gap: 2 }}>
                <TextField
                  label={t('support.category', 'Category')}
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  select
                  fullWidth
                  size="small"
                >
                  {CATEGORIES.map((c) => (
                    <MenuItem key={c.value} value={c.value}>{c.label}</MenuItem>
                  ))}
                </TextField>

                <TextField
                  label={t('support.priority', 'Priority')}
                  value={priority}
                  onChange={(e) => setPriority(e.target.value)}
                  select
                  fullWidth
                  size="small"
                >
                  {PRIORITIES.map((p) => (
                    <MenuItem key={p.value} value={p.value}>{p.label}</MenuItem>
                  ))}
                </TextField>
              </Box>

              <TextField
                label={t('support.message', 'Message')}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                required
                fullWidth
                multiline
                rows={4}
                size="small"
                placeholder={t('support.message', 'Describe your issue in detail...')}
              />

              <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                <Button
                  type="submit"
                  variant="contained"
                  disabled={submitting || !subject || !message}
                  startIcon={submitting ? <CircularProgress size={16} /> : <SendIcon />}
                  sx={{
                    bgcolor: '#1a1e4a',
                    '&:hover': { bgcolor: '#2d3561' },
                    textTransform: 'none',
                    fontWeight: 600,
                    px: 3,
                  }}
                >
                  {submitting ? t('support.submitting', 'Submitting...') : t('support.submitTicket', 'Submit Ticket')}
                </Button>
              </Box>
            </Box>
          </CardContent>
        </Card>

        {/* Ticket History */}
        <Typography variant="h6" fontWeight={600} sx={{ mb: 2 }}>
          {t('support.yourTickets', 'Your Tickets')}
        </Typography>

        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
            <CircularProgress size={32} />
          </Box>
        ) : tickets.length === 0 ? (
          <Card sx={{ borderRadius: 2, border: '1px solid #e5e7eb' }} elevation={0}>
            <CardContent sx={{ textAlign: 'center', py: 4 }}>
              <Typography color="text.secondary">
                {t('support.noTickets', 'No tickets submitted yet. Use the form above to create one.')}
              </Typography>
            </CardContent>
          </Card>
        ) : (
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            {tickets.map((ticket) => (
              <Card key={ticket.id} sx={{ borderRadius: 2, border: '1px solid #e5e7eb' }} elevation={0}>
                <CardContent sx={{ p: 2.5 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
                    <Typography variant="subtitle1" fontWeight={600}>
                      {ticket.subject}
                    </Typography>
                    <Chip
                      label={ticket.status.replace('_', ' ')}
                      size="small"
                      color={STATUS_COLORS[ticket.status] || 'default'}
                      sx={{ fontWeight: 600, fontSize: '0.7rem' }}
                    />
                  </Box>

                  <Box sx={{ display: 'flex', gap: 1, mb: 1.5 }}>
                    <Chip label={CATEGORIES.find((c) => c.value === ticket.category)?.label || ticket.category} size="small" variant="outlined" sx={{ fontSize: '0.7rem' }} />
                    <Chip label={ticket.priority} size="small" variant="outlined" sx={{ fontSize: '0.7rem' }} />
                    <Typography variant="caption" color="text.secondary" sx={{ ml: 'auto', alignSelf: 'center' }}>
                      {new Date(ticket.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })}
                    </Typography>
                  </Box>

                  <Typography variant="body2" color="text.secondary" sx={{ mb: ticket.adminResponse ? 1.5 : 0 }}>
                    {ticket.message}
                  </Typography>

                  {ticket.adminResponse && (
                    <>
                      <Divider sx={{ my: 1.5 }} />
                      <Box sx={{ bgcolor: '#f0f9ff', borderRadius: 1, p: 1.5 }}>
                        <Typography variant="caption" fontWeight={600} color="primary" sx={{ display: 'block', mb: 0.5 }}>
                          {t('support.adminResponse', 'Admin Response')}
                        </Typography>
                        <Typography variant="body2">
                          {ticket.adminResponse}
                        </Typography>
                      </Box>
                    </>
                  )}
                </CardContent>
              </Card>
            ))}
          </Box>
        )}
      </Box>
    </Box>
  );
};

export default ContactSupportPage;

import React from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import { TimeOffEntryProps } from '../../types/schedule';

/**
 * TimeOffEntry renders a colored pill representing time off for a team member.
 * Uses a distinct color scheme from ShiftBlock pills to visually differentiate
 * time-off entries from scheduled shifts in the calendar grid.
 *
 * - Pending time off: light amber background (#FEF3C7)
 * - Approved time off: light green background (#D1FAE5)
 *
 * Display format: "{leaveType} ({status})" e.g., "Annual (Pending)"
 *
 * Visibility toggle (showTimeOff) is handled by the parent component.
 */
const TimeOffEntry: React.FC<TimeOffEntryProps> = ({ entry }) => {
  const isPending = entry.status === 'PENDING';
  const backgroundColor = isPending ? '#FEF3C7' : '#D1FAE5';
  const textColor = isPending ? '#92400E' : '#065F46';
  const statusLabel = isPending ? 'Pending' : 'Approved';

  return (
    <Box
      sx={{
        display: 'block',
        backgroundColor,
        borderRadius: '6px',
        padding: '2px 8px',
        marginBottom: '2px',
        whiteSpace: 'nowrap',
      }}
    >
      <Typography
        variant="body2"
        sx={{
          color: textColor,
          fontSize: '0.7rem',
          lineHeight: 1.4,
        }}
      >
        {entry.leaveType} ({statusLabel})
      </Typography>
    </Box>
  );
};

export default TimeOffEntry;

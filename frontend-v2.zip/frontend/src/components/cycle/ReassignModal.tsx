import React, { useState, useCallback } from 'react';
import {
  Alert,
  Box,
  Button,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Stack,
  TextField,
  Typography,
} from '@mui/material';
import { cycleService } from '@/services/cycleService';
import { isAxiosError } from 'axios';

export interface ReassignModalProps {
  /** Whether the dialog is visible */
  open: boolean;
  /** Close handler */
  onClose: () => void;
  /** Called after successful reassignment (to refresh the parent grid) */
  onSuccess: () => void;
  /** The assignment to reassign */
  assignmentId: number | null;
  /** The date of the assignment (for display) */
  assignmentDate: string;
  /** Name of current assignee (for display) */
  currentPersonName: string;
}

/**
 * ReassignModal — MUI Dialog triggered by clicking a leave-conflict indicator.
 *
 * Shows "This person is on leave. Please reassign." message, allows searching/entering
 * a replacement person ID, and PATCHes /api/assignments/reassign on confirm.
 *
 * Implements Requirements 7.2, 7.3, 7.4.
 */
const ReassignModal: React.FC<ReassignModalProps> = ({
  open,
  onClose,
  onSuccess,
  assignmentId,
  assignmentDate,
  currentPersonName,
}) => {
  const [newPersonId, setNewPersonId] = useState<string>('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleClose = useCallback(() => {
    if (submitting) return;
    setNewPersonId('');
    setError(null);
    onClose();
  }, [submitting, onClose]);

  const handleReassign = useCallback(async () => {
    if (!assignmentId || !newPersonId) return;

    const personId = parseInt(newPersonId, 10);
    if (isNaN(personId) || personId <= 0) {
      setError('Please enter a valid person ID.');
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      await cycleService.reassignDuty(assignmentId, personId);
      setNewPersonId('');
      setError(null);
      onSuccess();
      onClose();
    } catch (err: unknown) {
      if (isAxiosError(err) && err.response) {
        const status = err.response.status;
        const data = err.response.data as { error?: string; message?: string };
        const message = data?.error || data?.message;

        if (status === 400) {
          setError(message || 'Replacement person is on leave or has a conflicting assignment.');
        } else if (status === 404) {
          setError(message || 'Assignment or person not found.');
        } else {
          setError(message || 'An unexpected error occurred. Please try again.');
        }
      } else {
        const message = err instanceof Error ? err.message : 'Failed to reassign duty.';
        setError(message);
      }
    } finally {
      setSubmitting(false);
    }
  }, [assignmentId, newPersonId, onSuccess, onClose]);

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '';
    return new Date(dateStr + 'T00:00:00').toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const isValid = newPersonId !== '' && !isNaN(parseInt(newPersonId, 10)) && parseInt(newPersonId, 10) > 0;

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      maxWidth="xs"
      fullWidth
      aria-labelledby="reassign-modal-title"
    >
      <DialogTitle id="reassign-modal-title">Reassign Duty</DialogTitle>
      <DialogContent>
        <Stack spacing={2} sx={{ mt: 1 }}>
          {/* Leave conflict message */}
          <Alert severity="warning" icon={false}>
            <Typography variant="body2" fontWeight={500}>
              This person is on leave. Please reassign.
            </Typography>
          </Alert>

          {/* Current assignment info */}
          <Box sx={{ pl: 1 }}>
            <Typography variant="body2" color="text.secondary">
              <strong>Current assignee:</strong> {currentPersonName}
            </Typography>
            {assignmentDate && (
              <Typography variant="body2" color="text.secondary">
                <strong>Date:</strong> {formatDate(assignmentDate)}
              </Typography>
            )}
          </Box>

          {/* Error display */}
          {error && (
            <Alert severity="error" onClose={() => setError(null)}>
              {error}
            </Alert>
          )}

          {/* Replacement person input */}
          <TextField
            label="Replacement Person ID"
            type="number"
            value={newPersonId}
            onChange={(e) => setNewPersonId(e.target.value)}
            fullWidth
            size="small"
            placeholder="Enter person ID"
            inputProps={{ min: 1 }}
            helperText="Enter the ID of the person to assign this duty to"
            disabled={submitting}
          />
        </Stack>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={handleClose} disabled={submitting}>
          Cancel
        </Button>
        <Button
          variant="contained"
          onClick={handleReassign}
          disabled={!isValid || submitting}
          startIcon={submitting ? <CircularProgress size={16} color="inherit" /> : undefined}
        >
          {submitting ? 'Reassigning...' : 'Reassign'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ReassignModal;

import api from './api';
import type {
  SanctionedStrengthDto,
  StrengthMetricsDto,
  UpdateSanctionedStrengthRequest,
} from '@/types';

export const strengthService = {
  /**
   * Get all sanctioned strength entries
   */
  getAllSanctioned: () =>
    api.get<SanctionedStrengthDto[]>('/api/strength/sanctioned').then((r) => r.data),

  /**
   * Get sanctioned strength by designation
   */
  getByDesignation: (designation: string) =>
    api.get<SanctionedStrengthDto>(`/api/strength/sanctioned/${designation}`).then((r) => r.data),

  /**
   * Update sanctioned strength for a designation
   */
  updateSanctioned: (data: UpdateSanctionedStrengthRequest) =>
    api.put<SanctionedStrengthDto>('/api/strength/sanctioned', data).then((r) => r.data),

  /**
   * Bulk update sanctioned strength for multiple designations
   */
  bulkUpdateSanctioned: (data: UpdateSanctionedStrengthRequest[]) =>
    api.put<SanctionedStrengthDto[]>('/api/strength/sanctioned/bulk', data).then((r) => r.data),

  /**
   * Get complete strength metrics (sanctioned, present, vacancy)
   */
  getMetrics: () =>
    api.get<StrengthMetricsDto>('/api/strength/metrics').then((r) => r.data),
};

import '@mui/material/styles';

declare module '@mui/material/styles' {
  interface StatusColor {
    main: string;
    contrastText: string;
  }

  interface StatusPalette {
    active: StatusColor;
    cancelled: StatusColor;
    completed: StatusColor;
    pending: StatusColor;
    onLeave: StatusColor;
  }

  interface Palette {
    status: StatusPalette;
  }

  interface PaletteOptions {
    status?: {
      active?: StatusColor;
      cancelled?: StatusColor;
      completed?: StatusColor;
      pending?: StatusColor;
      onLeave?: StatusColor;
    };
  }

  interface BreakpointOverrides {
    xs: true;
    sm: true;
    md: true;
    lg: true;
    xl: true;
    compact: true;
  }
}

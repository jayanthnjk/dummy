import React from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions,
  Button, Typography, Box, LinearProgress,
} from '@mui/material';
import TimerOutlinedIcon from '@mui/icons-material/TimerOutlined';
import { useAuth } from '@/contexts/AuthContext';

const TOTAL_SECONDS = 60;

const InactivityDialog: React.FC = () => {
  const { showInactivityDialog, inactivityCountdown, staySignedIn, logout } = useAuth();

  if (!showInactivityDialog) return null;

  const progress = (inactivityCountdown / TOTAL_SECONDS) * 100;

  return (
    <Dialog
      open={showInactivityDialog}
      maxWidth="xs"
      fullWidth
      PaperProps={{
        sx: { borderRadius: 3, overflow: 'hidden' },
      }}
    >
      {/* Progress bar at top */}
      <LinearProgress
        variant="determinate"
        value={progress}
        sx={{
          height: 4,
          bgcolor: '#fee2e2',
          '& .MuiLinearProgress-bar': {
            bgcolor: inactivityCountdown <= 15 ? '#dc2626' : '#f59e0b',
            transition: 'transform 1s linear',
          },
        }}
      />

      <DialogTitle sx={{ pb: 1, pt: 3, textAlign: 'center' }}>
        <Box sx={{
          width: 56, height: 56, borderRadius: '50%', mx: 'auto', mb: 2,
          bgcolor: '#fef3c7', display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <TimerOutlinedIcon sx={{ fontSize: 28, color: '#d97706' }} />
        </Box>
        <Typography sx={{ fontSize: '1.1rem', fontWeight: 700, color: '#111827' }}>
          Are you still there?
        </Typography>
      </DialogTitle>

      <DialogContent sx={{ textAlign: 'center', pb: 1 }}>
        <Typography sx={{ fontSize: '0.85rem', color: '#6b7280', mb: 2 }}>
          You've been inactive for a while. For security, you'll be signed out automatically.
        </Typography>
        <Box sx={{
          display: 'inline-flex', alignItems: 'center', gap: 1,
          px: 2.5, py: 1, borderRadius: 2,
          bgcolor: inactivityCountdown <= 15 ? '#fef2f2' : '#fffbeb',
          border: `1px solid ${inactivityCountdown <= 15 ? '#fecaca' : '#fde68a'}`,
        }}>
          <Typography sx={{
            fontSize: '1.5rem', fontWeight: 800,
            color: inactivityCountdown <= 15 ? '#dc2626' : '#d97706',
            fontVariantNumeric: 'tabular-nums',
          }}>
            {inactivityCountdown}
          </Typography>
          <Typography sx={{ fontSize: '0.75rem', color: '#9ca3af' }}>
            seconds remaining
          </Typography>
        </Box>
      </DialogContent>

      <DialogActions sx={{ px: 3, pb: 3, gap: 1.5, justifyContent: 'center' }}>
        <Button
          onClick={logout}
          variant="outlined"
          sx={{
            textTransform: 'none', fontWeight: 600, fontSize: '0.85rem',
            borderRadius: 2, px: 3, borderColor: '#e5e7eb', color: '#6b7280',
            '&:hover': { borderColor: '#dc2626', color: '#dc2626', bgcolor: '#fef2f2' },
          }}
        >
          Sign out
        </Button>
        <Button
          onClick={staySignedIn}
          variant="contained"
          autoFocus
          sx={{
            textTransform: 'none', fontWeight: 600, fontSize: '0.85rem',
            borderRadius: 2, px: 3,
            background: 'linear-gradient(135deg, #312e81 0%, #4338ca 100%)',
            '&:hover': { background: 'linear-gradient(135deg, #1e1b4b 0%, #312e81 100%)' },
          }}
        >
          Stay signed in
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default InactivityDialog;

import React, { useState, useCallback } from 'react';
import {
  Alert,
  Box,
  Button,
  CircularProgress,
  FormControl,
  InputLabel,
  MenuItem,
  Paper,
  Select,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import PageHeader from '@/components/common/PageHeader';
import api from '@/services/api';
import { useAuth } from '@/contexts/AuthContext';

const DESIGNATIONS = ['', 'DCP', 'ACP', 'RPI', 'RSI', 'ARSI', 'AHC', 'APC'];
const UNITS = ['', 'CAR', 'MT'];

interface DailyRecord {
  date: string;
  dutyType: string | null;
  dutyLocation: string | null;
  adhocDuty: string | null;
  leaveType: string | null;
  shiftType: string | null;
  status: string | null;
}

interface RosterPerson {
  personId: number;
  badgeId: string;
  personName: string;
  designation: string;
  dailyRecords: DailyRecord[];
}

/**
 * Formats a duty cell text from a daily record.
 * Priority: leaveType > adhocDuty > dutyLocation > dutyType > '-'
 */
function getDutyCellText(record: DailyRecord | undefined): string {
  if (!record) return '-';
  if (record.leaveType) return record.leaveType.replace(/_/g, ' ');
  if (record.adhocDuty) return record.adhocDuty;
  if (record.dutyLocation) return record.dutyLocation;
  if (record.dutyType) return record.dutyType;
  return '-';
}

function getDutyCellColor(record: DailyRecord | undefined): string {
  if (!record) return '#e5e7eb';
  if (record.leaveType) return '#fef3c7'; // yellow for leave
  if (record.adhocDuty) return '#dbeafe'; // blue for adhoc
  return '#ffffff';
}

/**
 * Generate array of date strings between start and end (inclusive).
 */
function getDateRange(start: string, end: string): string[] {
  const dates: string[] = [];
  const current = new Date(start);
  const endDate = new Date(end);
  while (current <= endDate) {
    dates.push(current.toISOString().split('T')[0]);
    current.setDate(current.getDate() + 1);
  }
  return dates;
}

const DailyRosterPage: React.FC = () => {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { isAdmin, isCAROnly, isMTOnly } = useAuth();

  // Filter state
  const today = new Date().toISOString().split('T')[0];
  const sevenDaysAgo = new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
  const [startDate, setStartDate] = useState(sevenDaysAgo);
  const [endDate, setEndDate] = useState(today);
  const [designation, setDesignation] = useState('');
  const [unit, setUnit] = useState(isCAROnly ? 'CAR' : isMTOnly ? 'MT' : '');

  // Data state
  const [roster, setRoster] = useState<RosterPerson[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [searched, setSearched] = useState(false);

  const fetchRoster = useCallback(async () => {
    if (!startDate || !endDate) return;
    setLoading(true);
    setError('');
    try {
      const params: Record<string, string> = { startDate, endDate };
      if (designation) params.designation = designation;
      if (unit) params.unit = unit;
      const res = await api.get<RosterPerson[]>('/api/duty-history/roster', { params });
      setRoster(res.data);
      setSearched(true);
    } catch {
      setError('Failed to load roster data');
      setRoster([]);
    } finally {
      setLoading(false);
    }
  }, [startDate, endDate, designation, unit]);

  const dates = startDate && endDate ? getDateRange(startDate, endDate) : [];

  // Limit date range to max 31 days
  const dateRangeValid = dates.length > 0 && dates.length <= 31;
  const canSearch = !!startDate && !!endDate && dateRangeValid;

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box sx={{ mb: 3 }}>
        <PageHeader
          title="Daily Roster"
          breadcrumbs={[
            { label: 'Home', path: '/' },
            { label: t('nav.personnel', 'Personnel'), path: '/personnel' },
            { label: 'Daily Roster' },
          ]}
          actions={[
            {
              label: 'Back to Personnel',
              variant: 'ghost',
              icon: <ArrowBackIcon />,
              onClick: () => navigate('/personnel'),
            },
          ]}
        />
      </Box>

      {/* Filters */}
      <Paper sx={{ p: 2.5, mb: 3 }}>
        <Typography variant="subtitle2" sx={{ mb: 1.5, fontWeight: 600 }}>
          Filters
        </Typography>
        <Stack direction={{ xs: 'column', md: 'row' }} spacing={2} alignItems="flex-end">
          <TextField
            type="date"
            label="Start Date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            InputLabelProps={{ shrink: true }}
            size="small"
            sx={{ minWidth: 160 }}
          />
          <TextField
            type="date"
            label="End Date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            InputLabelProps={{ shrink: true }}
            size="small"
            sx={{ minWidth: 160 }}
          />
          <FormControl size="small" sx={{ minWidth: 140 }}>
            <InputLabel>Designation</InputLabel>
            <Select
              value={designation}
              label="Designation"
              onChange={(e) => setDesignation(e.target.value)}
            >
              <MenuItem value="">All</MenuItem>
              {DESIGNATIONS.filter(Boolean).map((d) => (
                <MenuItem key={d} value={d}>{d}</MenuItem>
              ))}
            </Select>
          </FormControl>
          <FormControl size="small" sx={{ minWidth: 120 }}>
            <InputLabel>Unit</InputLabel>
            <Select
              value={unit}
              label="Unit"
              onChange={(e) => setUnit(e.target.value)}
              disabled={!isAdmin}
            >
              <MenuItem value="">All</MenuItem>
              {UNITS.filter(Boolean).map((u) => (
                <MenuItem key={u} value={u}>{u}</MenuItem>
              ))}
            </Select>
          </FormControl>
          <Button
            variant="contained"
            startIcon={<SearchIcon />}
            onClick={fetchRoster}
            disabled={!canSearch || loading}
            sx={{ height: 40 }}
          >
            {loading ? <CircularProgress size={20} /> : 'Load Roster'}
          </Button>
        </Stack>
        {startDate && endDate && !dateRangeValid && (
          <Typography variant="caption" color="error" sx={{ mt: 1, display: 'block' }}>
            Date range must be 31 days or less.
          </Typography>
        )}
      </Paper>

      {/* Error */}
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {/* Results */}
      {loading && (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
          <CircularProgress />
        </Box>
      )}

      {!loading && searched && roster.length === 0 && (
        <Alert severity="info">No duty history records found for the selected filters.</Alert>
      )}

      {!loading && roster.length > 0 && (
        <Paper sx={{ overflow: 'hidden' }}>
          <Box sx={{ px: 2, py: 1.5, borderBottom: '1px solid', borderColor: 'divider' }}>
            <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
              {roster.length} personnel • {dates.length} days
            </Typography>
          </Box>
          <TableContainer sx={{ maxHeight: 'calc(100vh - 340px)', overflow: 'auto' }}>
            <Table size="small" stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell
                    sx={{
                      position: 'sticky',
                      left: 0,
                      zIndex: 3,
                      bgcolor: '#f8fafc',
                      fontWeight: 700,
                      fontSize: '0.75rem',
                      minWidth: 50,
                      borderRight: '1px solid #e2e8f0',
                    }}
                  >
                    S.No
                  </TableCell>
                  <TableCell
                    sx={{
                      position: 'sticky',
                      left: 50,
                      zIndex: 3,
                      bgcolor: '#f8fafc',
                      fontWeight: 700,
                      fontSize: '0.75rem',
                      minWidth: 180,
                      borderRight: '1px solid #e2e8f0',
                    }}
                  >
                    Name / Badge
                  </TableCell>
                  <TableCell
                    sx={{
                      position: 'sticky',
                      left: 230,
                      zIndex: 3,
                      bgcolor: '#f8fafc',
                      fontWeight: 700,
                      fontSize: '0.75rem',
                      minWidth: 70,
                      borderRight: '2px solid #cbd5e1',
                    }}
                  >
                    Desig.
                  </TableCell>
                  {dates.map((date) => {
                    const d = new Date(date);
                    const day = d.getDate();
                    const month = d.toLocaleString('en', { month: 'short' });
                    const weekday = d.toLocaleString('en', { weekday: 'short' });
                    const isSunday = d.getDay() === 0;
                    return (
                      <TableCell
                        key={date}
                        align="center"
                        sx={{
                          fontWeight: 600,
                          fontSize: '0.68rem',
                          minWidth: 90,
                          maxWidth: 110,
                          bgcolor: isSunday ? '#fef2f2' : '#f8fafc',
                          borderRight: '1px solid #e2e8f0',
                          whiteSpace: 'nowrap',
                          px: 0.5,
                        }}
                      >
                        <Box>{weekday}</Box>
                        <Box sx={{ fontWeight: 700, fontSize: '0.8rem' }}>{day} {month}</Box>
                      </TableCell>
                    );
                  })}
                </TableRow>
              </TableHead>
              <TableBody>
                {roster.map((person, idx) => {
                  // Build a map of date -> record for this person
                  const recordMap: Record<string, DailyRecord> = {};
                  person.dailyRecords.forEach((r) => {
                    recordMap[r.date] = r;
                  });

                  return (
                    <TableRow key={person.personId} hover>
                      <TableCell
                        sx={{
                          position: 'sticky',
                          left: 0,
                          zIndex: 1,
                          bgcolor: '#fff',
                          fontSize: '0.75rem',
                          borderRight: '1px solid #e2e8f0',
                          fontWeight: 600,
                        }}
                      >
                        {idx + 1}
                      </TableCell>
                      <TableCell
                        sx={{
                          position: 'sticky',
                          left: 50,
                          zIndex: 1,
                          bgcolor: '#fff',
                          fontSize: '0.75rem',
                          borderRight: '1px solid #e2e8f0',
                        }}
                      >
                        <Typography sx={{ fontSize: '0.78rem', fontWeight: 600, lineHeight: 1.2 }}>
                          {person.personName}
                        </Typography>
                        <Typography sx={{ fontSize: '0.68rem', color: '#6b7280' }}>
                          {person.badgeId || '—'}
                        </Typography>
                      </TableCell>
                      <TableCell
                        sx={{
                          position: 'sticky',
                          left: 230,
                          zIndex: 1,
                          bgcolor: '#fff',
                          fontSize: '0.72rem',
                          fontWeight: 600,
                          borderRight: '2px solid #cbd5e1',
                        }}
                      >
                        {person.designation || '—'}
                      </TableCell>
                      {dates.map((date) => {
                        const record = recordMap[date];
                        const cellText = getDutyCellText(record);
                        const bgColor = getDutyCellColor(record);
                        const isSunday = new Date(date).getDay() === 0;

                        return (
                          <Tooltip key={date} title={cellText} enterDelay={200} arrow>
                            <TableCell
                              align="center"
                              sx={{
                                fontSize: '0.65rem',
                                px: 0.5,
                                py: 0.5,
                                minWidth: 90,
                                maxWidth: 110,
                                bgcolor: isSunday ? '#fef7f7' : bgColor,
                                borderRight: '1px solid #f1f5f9',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                whiteSpace: 'nowrap',
                              }}
                            >
                              {cellText.length > 15 ? cellText.substring(0, 15) + '...' : cellText}
                            </TableCell>
                          </Tooltip>
                        );
                      })}
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
      )}
    </Box>
  );
};

export default DailyRosterPage;

import React, { useState, useCallback, useEffect, useMemo } from 'react';
import {
  Alert,
  Box,
  Button,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  InputAdornment,
  InputLabel,
  MenuItem,
  Paper,
  Select,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import PersonSearchIcon from '@mui/icons-material/PersonSearch';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import EditIcon from '@mui/icons-material/Edit';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import PageHeader from '@/components/common/PageHeader';
import api from '@/services/api';
import { useAuth } from '@/contexts/AuthContext';

const DESIGNATIONS = ['', 'DCP', 'ACP', 'RPI', 'RSI', 'ARSI', 'AHC', 'APC'];
const UNITS = ['', 'CAR', 'MT'];

interface DailyRecord {
  id: number | null;
  date: string;
  dutyType: string | null;
  dutyLocation: string | null;
  adhocDuty: string | null;
  leaveType: string | null;
  shiftType: string | null;
  status: string | null;
}

interface RosterPerson {
  personId: number;
  badgeId: string;
  personName: string;
  designation: string;
  dailyRecords: DailyRecord[];
}

/**
 * Formats a duty cell text from a daily record.
 * Priority: leaveType > adhocDuty > dutyLocation > dutyType > '-'
 */
function getDutyCellText(record: DailyRecord | undefined): string {
  if (!record) return '-';
  if (record.leaveType) return record.leaveType.replace(/_/g, ' ');
  if (record.adhocDuty) return record.adhocDuty;
  if (record.dutyLocation) return record.dutyLocation;
  if (record.dutyType) return record.dutyType;
  return '-';
}

function getDutyCellColor(record: DailyRecord | undefined): string {
  if (!record) return '#e5e7eb';
  if (record.leaveType) return '#fef3c7'; // yellow for leave
  if (record.adhocDuty) return '#dbeafe'; // blue for adhoc
  return '#ffffff';
}

/**
 * Generate array of date strings between start and end (inclusive).
 */
function getDateRange(start: string, end: string): string[] {
  const dates: string[] = [];
  const current = new Date(start);
  const endDate = new Date(end);
  while (current <= endDate) {
    dates.push(current.toISOString().split('T')[0]);
    current.setDate(current.getDate() + 1);
  }
  return dates;
}

/**
 * Gets current week's Monday and Sunday dates.
 */
function getCurrentWeekRange(): { start: string; end: string } {
  const now = new Date();
  const dayOfWeek = now.getDay(); // 0=Sun, 1=Mon, ...
  const diffToMonday = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
  const monday = new Date(now);
  monday.setDate(now.getDate() + diffToMonday);
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);
  return {
    start: monday.toISOString().split('T')[0],
    end: sunday.toISOString().split('T')[0],
  };
}

const DailyRosterPage: React.FC = () => {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { isAdmin, isCAROnly, isMTOnly } = useAuth();

  // Default to current week
  const currentWeek = getCurrentWeekRange();

  // Filter state
  const [startDate, setStartDate] = useState(currentWeek.start);
  const [endDate, setEndDate] = useState(currentWeek.end);
  const [designation, setDesignation] = useState('');
  const [unit, setUnit] = useState(isCAROnly ? 'CAR' : isMTOnly ? 'MT' : '');
  const [searchQuery, setSearchQuery] = useState('');

  // Edit duty dialog state
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editRecord, setEditRecord] = useState<{ id: number; personName: string; date: string; dutyType: string; dutyLocation: string } | null>(null);
  const [editDutyType, setEditDutyType] = useState('');
  const [editDutyLocation, setEditDutyLocation] = useState('');
  const [editSaving, setEditSaving] = useState(false);
  const [editError, setEditError] = useState('');

  // Data state
  const [roster, setRoster] = useState<RosterPerson[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [searched, setSearched] = useState(false);

  const fetchRoster = useCallback(async () => {
    if (!startDate || !endDate) return;
    setLoading(true);
    setError('');
    try {
      const params: Record<string, string> = { startDate, endDate };
      if (designation) params.designation = designation;
      if (unit) params.unit = unit;
      const res = await api.get<RosterPerson[]>('/api/duty-history/roster', { params });
      setRoster(res.data);
      setSearched(true);
    } catch {
      setError('Failed to load roster data');
      setRoster([]);
    } finally {
      setLoading(false);
    }
  }, [startDate, endDate, designation, unit]);

  const handleCellClick = useCallback((record: DailyRecord | undefined, personName: string, date: string) => {
    if (!record || !record.id) return;
    setEditRecord({
      id: record.id,
      personName,
      date,
      dutyType: record.dutyType || '',
      dutyLocation: record.dutyLocation || '',
    });
    setEditDutyType(record.dutyLocation || record.dutyType || record.adhocDuty || '');
    setEditDutyLocation(record.dutyLocation || '');
    setEditError('');
    setEditDialogOpen(true);
  }, []);

  const handleEditSave = useCallback(async () => {
    if (!editRecord) return;
    setEditSaving(true);
    setEditError('');
    try {
      await api.put(`/api/duty-history/${editRecord.id}`, {
        dutyLocation: editDutyType.trim() || null,
      });
      // Refresh roster data
      await fetchRoster();
      setEditDialogOpen(false);
    } catch {
      setEditError('Failed to update duty record');
    } finally {
      setEditSaving(false);
    }
  }, [editRecord, editDutyType, fetchRoster]);

  // Auto-load current week on mount
  useEffect(() => {
    fetchRoster();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const dates = startDate && endDate ? getDateRange(startDate, endDate) : [];

  // No max date range limit — user can select any range
  const dateRangeValid = dates.length > 0;
  const canSearch = !!startDate && !!endDate && dateRangeValid;

  // Filter roster by search query (name or badge)
  const filteredRoster = useMemo(() => {
    if (!searchQuery.trim()) return roster;
    const q = searchQuery.toLowerCase().trim();
    return roster.filter(
      (p) =>
        (p.personName && p.personName.toLowerCase().includes(q)) ||
        (p.badgeId && p.badgeId.toLowerCase().includes(q))
    );
  }, [roster, searchQuery]);

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box sx={{ mb: 3 }}>
        <PageHeader
          title="GDR Report"
          breadcrumbs={[
            { label: 'Home', path: '/' },
            { label: t('nav.personnel', 'Personnel'), path: '/personnel' },
            { label: 'GDR Report' },
          ]}
          actions={[
            {
              label: 'Back to Personnel',
              variant: 'ghost',
              icon: <ArrowBackIcon />,
              onClick: () => navigate('/personnel'),
            },
          ]}
        />
      </Box>

      {/* Filters */}
      <Paper sx={{ p: 2.5, mb: 3 }}>
        <Typography variant="subtitle2" sx={{ mb: 1.5, fontWeight: 600 }}>
          Filters
        </Typography>
        <Stack direction={{ xs: 'column', md: 'row' }} spacing={2} alignItems="flex-end">
          <TextField
            type="date"
            label="Start Date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            InputLabelProps={{ shrink: true }}
            size="small"
            sx={{ minWidth: 160 }}
          />
          <TextField
            type="date"
            label="End Date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            InputLabelProps={{ shrink: true }}
            size="small"
            sx={{ minWidth: 160 }}
          />
          <FormControl size="small" sx={{ minWidth: 140 }}>
            <InputLabel>Designation</InputLabel>
            <Select
              value={designation}
              label="Designation"
              onChange={(e) => setDesignation(e.target.value)}
            >
              <MenuItem value="">All</MenuItem>
              {DESIGNATIONS.filter(Boolean).map((d) => (
                <MenuItem key={d} value={d}>{d}</MenuItem>
              ))}
            </Select>
          </FormControl>
          <FormControl size="small" sx={{ minWidth: 120 }}>
            <InputLabel>Unit</InputLabel>
            <Select
              value={unit}
              label="Unit"
              onChange={(e) => setUnit(e.target.value)}
              disabled={!isAdmin}
            >
              <MenuItem value="">All</MenuItem>
              {UNITS.filter(Boolean).map((u) => (
                <MenuItem key={u} value={u}>{u}</MenuItem>
              ))}
            </Select>
          </FormControl>
          <Button
            variant="contained"
            startIcon={<SearchIcon />}
            onClick={fetchRoster}
            disabled={!canSearch || loading}
            sx={{ height: 40 }}
          >
            {loading ? <CircularProgress size={20} /> : 'Load Roster'}
          </Button>
        </Stack>
      </Paper>

      {/* Error */}
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {/* Results */}
      {loading && (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
          <CircularProgress />
        </Box>
      )}

      {!loading && searched && roster.length === 0 && (
        <Alert severity="info">No duty history records found for the selected filters.</Alert>
      )}

      {!loading && roster.length > 0 && (
        <Paper sx={{ overflow: 'hidden' }}>
          {/* Top bar: count + search */}
          <Box sx={{ px: 2, py: 1.5, borderBottom: '1px solid', borderColor: 'divider', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 1 }}>
            <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
              {filteredRoster.length} personnel • {dates.length} days
              {searchQuery && filteredRoster.length !== roster.length && (
                <Typography component="span" sx={{ fontSize: '0.75rem', color: 'text.secondary', ml: 1 }}>
                  (filtered from {roster.length})
                </Typography>
              )}
            </Typography>
            <TextField
              size="small"
              placeholder="Search by name or badge..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <PersonSearchIcon sx={{ fontSize: 18, color: 'text.secondary' }} />
                  </InputAdornment>
                ),
              }}
              sx={{ minWidth: 220, maxWidth: 300, '& .MuiOutlinedInput-root': { borderRadius: 2, fontSize: '0.8rem' } }}
            />
          </Box>
          <TableContainer sx={{ maxHeight: 'calc(100vh - 280px)', overflowX: 'auto', overflowY: 'auto' }}>
            <Table size="small" stickyHeader sx={{ minWidth: 300 + dates.length * 100 }}>
              <TableHead>
                <TableRow>
                  <TableCell
                    sx={{
                      position: 'sticky',
                      left: 0,
                      zIndex: 3,
                      bgcolor: '#f8fafc',
                      fontWeight: 700,
                      fontSize: '0.75rem',
                      minWidth: 50,
                      borderRight: '1px solid #e2e8f0',
                    }}
                  >
                    S.No
                  </TableCell>
                  <TableCell
                    sx={{
                      position: 'sticky',
                      left: 50,
                      zIndex: 3,
                      bgcolor: '#f8fafc',
                      fontWeight: 700,
                      fontSize: '0.75rem',
                      minWidth: 180,
                      borderRight: '1px solid #e2e8f0',
                    }}
                  >
                    Name / Badge
                  </TableCell>
                  <TableCell
                    sx={{
                      position: 'sticky',
                      left: 230,
                      zIndex: 3,
                      bgcolor: '#f8fafc',
                      fontWeight: 700,
                      fontSize: '0.75rem',
                      minWidth: 70,
                      borderRight: '2px solid #cbd5e1',
                    }}
                  >
                    Desig.
                  </TableCell>
                  {dates.map((date) => {
                    const d = new Date(date);
                    const day = d.getDate();
                    const month = d.toLocaleString('en', { month: 'short' });
                    const weekday = d.toLocaleString('en', { weekday: 'short' });
                    const isSunday = d.getDay() === 0;
                    return (
                      <TableCell
                        key={date}
                        align="center"
                        sx={{
                          fontWeight: 600,
                          fontSize: '0.68rem',
                          minWidth: 100,
                          maxWidth: 120,
                          bgcolor: isSunday ? '#fef2f2' : '#f8fafc',
                          borderRight: '1px solid #e2e8f0',
                          whiteSpace: 'nowrap',
                          px: 0.5,
                        }}
                      >
                        <Box>{weekday.toUpperCase()}</Box>
                        <Box sx={{ fontWeight: 700, fontSize: '0.8rem' }}>{day} {month.toUpperCase()}</Box>
                      </TableCell>
                    );
                  })}
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredRoster.map((person, idx) => {
                  // Build a map of date -> record for this person
                  const recordMap: Record<string, DailyRecord> = {};
                  person.dailyRecords.forEach((r) => {
                    recordMap[r.date] = r;
                  });

                  return (
                    <TableRow key={person.personId} hover>
                      <TableCell
                        sx={{
                          position: 'sticky',
                          left: 0,
                          zIndex: 1,
                          bgcolor: '#fff',
                          fontSize: '0.75rem',
                          borderRight: '1px solid #e2e8f0',
                          fontWeight: 600,
                        }}
                      >
                        {idx + 1}
                      </TableCell>
                      <TableCell
                        sx={{
                          position: 'sticky',
                          left: 50,
                          zIndex: 1,
                          bgcolor: '#fff',
                          fontSize: '0.75rem',
                          borderRight: '1px solid #e2e8f0',
                        }}
                      >
                        <Typography sx={{ fontSize: '0.78rem', fontWeight: 600, lineHeight: 1.2 }}>
                          {person.personName}
                        </Typography>
                        <Typography sx={{ fontSize: '0.68rem', color: '#6b7280' }}>
                          {person.badgeId || '—'}
                        </Typography>
                      </TableCell>
                      <TableCell
                        sx={{
                          position: 'sticky',
                          left: 230,
                          zIndex: 1,
                          bgcolor: '#fff',
                          fontSize: '0.72rem',
                          fontWeight: 600,
                          borderRight: '2px solid #cbd5e1',
                        }}
                      >
                        {person.designation || '—'}
                      </TableCell>
                      {dates.map((date) => {
                        const record = recordMap[date];
                        const cellText = getDutyCellText(record);
                        const bgColor = getDutyCellColor(record);
                        const isSunday = new Date(date).getDay() === 0;
                        const isClickable = record && record.id;

                        return (
                            <TableCell
                              key={date}
                              align="center"
                              onClick={() => handleCellClick(record, person.personName, date)}
                              sx={{
                                fontSize: '0.65rem',
                                px: 0.5,
                                py: 0.5,
                                minWidth: 100,
                                maxWidth: 120,
                                bgcolor: isSunday ? '#fef7f7' : bgColor,
                                borderRight: '1px solid #f1f5f9',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                whiteSpace: 'nowrap',
                                cursor: isClickable ? 'pointer' : 'default',
                                '&:hover': isClickable ? { bgcolor: '#e0e7ff', outline: '1px solid #6366f1' } : {},
                              }}
                            >
                              {cellText.length > 15 ? cellText.substring(0, 15) + '...' : cellText}
                            </TableCell>
                        );
                      })}
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
      )}
      {/* Edit Duty Dialog */}
      <Dialog open={editDialogOpen} onClose={() => setEditDialogOpen(false)} maxWidth="xs" fullWidth>
        <DialogTitle sx={{ fontWeight: 600, fontSize: '1rem', pb: 1 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <EditIcon sx={{ fontSize: 20, color: '#6366f1' }} />
            Edit Duty
          </Box>
        </DialogTitle>
        <DialogContent>
          {editRecord && (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 1 }}>
              <Box sx={{ display: 'flex', gap: 2 }}>
                <Box sx={{ flex: 1 }}>
                  <Typography variant="caption" color="text.secondary">Person</Typography>
                  <Typography variant="body2" fontWeight={600}>{editRecord.personName}</Typography>
                </Box>
                <Box sx={{ flex: 1 }}>
                  <Typography variant="caption" color="text.secondary">Date</Typography>
                  <Typography variant="body2" fontWeight={600}>
                    {new Date(editRecord.date).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
                  </Typography>
                </Box>
              </Box>

              <TextField
                label="Duty"
                value={editDutyType}
                onChange={(e) => setEditDutyType(e.target.value)}
                fullWidth
                size="small"
                autoFocus
                placeholder="Enter duty name..."
              />

              {editError && <Alert severity="error" sx={{ py: 0.5 }}>{editError}</Alert>}
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setEditDialogOpen(false)} disabled={editSaving}>
            Cancel
          </Button>
          <Button
            variant="contained"
            onClick={handleEditSave}
            disabled={editSaving}
            startIcon={editSaving ? <CircularProgress size={14} /> : undefined}
            sx={{ textTransform: 'none', fontWeight: 600 }}
          >
            {editSaving ? 'Saving...' : 'Save'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default DailyRosterPage;

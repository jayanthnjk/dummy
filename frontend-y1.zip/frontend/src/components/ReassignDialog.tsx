import React, { useEffect, useState, useMemo } from 'react';
import { observer } from 'mobx-react-lite';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Alert,
  Stack,
  Typography,
  Checkbox,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Divider,
  Box,
  Chip,
  type SelectChangeEvent,
} from '@mui/material';
import { useTranslation } from 'react-i18next';
import { dutySectionStore } from '@/stores/dutySectionStore';
import { dutySectionApiService } from '@/services/dutySectionService';
import type { ReassignmentResult } from '@/types/dutySections';

const MAX_SELECTION = 50;

type DialogStep = 'selection' | 'confirmation' | 'success';

interface ReassignDialogProps {
  open: boolean;
  onClose: () => void;
  preSelectedDutyTypeIds?: number[];
}

const ReassignDialog: React.FC<ReassignDialogProps> = observer(
  ({ open, onClose, preSelectedDutyTypeIds }) => {
    const { t } = useTranslation();

    const [selectedIds, setSelectedIds] = useState<number[]>([]);
    const [targetSection, setTargetSection] = useState<string>('');
    const [step, setStep] = useState<DialogStep>('selection');
    const [submitting, setSubmitting] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [result, setResult] = useState<ReassignmentResult | null>(null);

    // Get current section code from selected duty types
    const currentSectionCode = useMemo(() => {
      if (selectedIds.length === 0) return null;
      const firstSelected = dutySectionStore.dutyTypes.find(
        (dt) => dt.id === selectedIds[0]
      );
      return firstSelected?.section ?? null;
    }, [selectedIds]);

    // Available target sections: active sections excluding current section
    const targetSections = useMemo(() => {
      return dutySectionStore.activeSections.filter(
        (s) => s.code !== currentSectionCode
      );
    }, [currentSectionCode]);

    // Initialize dialog when opened
    useEffect(() => {
      if (!open) return;

      setStep('selection');
      setError(null);
      setResult(null);
      setSubmitting(false);
      setTargetSection('');

      if (preSelectedDutyTypeIds && preSelectedDutyTypeIds.length > 0) {
        setSelectedIds(preSelectedDutyTypeIds.slice(0, MAX_SELECTION));
      } else {
        setSelectedIds([]);
      }
    }, [open, preSelectedDutyTypeIds]);

    const handleToggle = (id: number) => {
      setSelectedIds((prev) => {
        if (prev.includes(id)) {
          return prev.filter((item) => item !== id);
        }
        // Enforce max selection
        if (prev.length >= MAX_SELECTION) {
          return prev;
        }
        return [...prev, id];
      });
    };

    const handleTargetChange = (e: SelectChangeEvent<string>) => {
      setTargetSection(e.target.value);
    };

    const handleMoveClick = () => {
      if (selectedIds.length === 0 || !targetSection) return;
      setStep('confirmation');
    };

    const handleBackToSelection = () => {
      setStep('selection');
      setError(null);
    };

    const handleConfirm = async () => {
      setSubmitting(true);
      setError(null);

      try {
        const reassignResult = await dutySectionApiService.reassign({
          dutyTypeIds: selectedIds,
          targetSection,
        });
        setResult(reassignResult);
        setStep('success');
      } catch (err: unknown) {
        const message =
          err instanceof Error
            ? err.message
            : t(
                'admin.dutySections.reassign.errors.submitFailed',
                'Reassignment failed'
              );
        setError(message);
      } finally {
        setSubmitting(false);
      }
    };

    const handleClose = () => {
      // Refresh store data when closing after any interaction
      dutySectionStore.refresh();
      onClose();
    };

    // Get target section name for display
    const targetSectionName = useMemo(() => {
      const section = dutySectionStore.activeSections.find(
        (s) => s.code === targetSection
      );
      return section?.name ?? targetSection;
    }, [targetSection]);

    // Get current section name for display
    const currentSectionName = useMemo(() => {
      const section = dutySectionStore.activeSections.find(
        (s) => s.code === currentSectionCode
      );
      return section?.name ?? currentSectionCode ?? '';
    }, [currentSectionCode]);

    const isMaxReached = selectedIds.length >= MAX_SELECTION;

    const renderSelectionStep = () => (
      <>
        <DialogContent>
          <Stack spacing={2}>
            {error && (
              <Alert severity="error" onClose={() => setError(null)}>
                {error}
              </Alert>
            )}

            <Typography variant="body2" color="text.secondary">
              {t(
                'admin.dutySections.reassign.selectionHint',
                'Select duty types to move to another section (max {{max}}).',
                { max: MAX_SELECTION }
              )}
            </Typography>

            {currentSectionCode && (
              <Chip
                label={t(
                  'admin.dutySections.reassign.currentSection',
                  'Current section: {{name}}',
                  { name: currentSectionName }
                )}
                size="small"
                color="default"
                variant="outlined"
              />
            )}

            {isMaxReached && (
              <Alert severity="warning">
                {t(
                  'admin.dutySections.reassign.maxReached',
                  'Maximum of {{max}} duty types can be selected at once.',
                  { max: MAX_SELECTION }
                )}
              </Alert>
            )}

            <List
              dense
              sx={{
                maxHeight: 300,
                overflow: 'auto',
                border: 1,
                borderColor: 'divider',
                borderRadius: 1,
              }}
            >
              {dutySectionStore.dutyTypes.map((dutyType) => {
                const isChecked = selectedIds.includes(dutyType.id);
                const isDisabled = !isChecked && isMaxReached;

                return (
                  <ListItem key={dutyType.id} disablePadding>
                    <ListItemButton
                      onClick={() => handleToggle(dutyType.id)}
                      disabled={isDisabled}
                      dense
                    >
                      <ListItemIcon sx={{ minWidth: 36 }}>
                        <Checkbox
                          edge="start"
                          checked={isChecked}
                          disabled={isDisabled}
                          tabIndex={-1}
                          disableRipple
                          size="small"
                        />
                      </ListItemIcon>
                      <ListItemText
                        primary={dutyType.name}
                        secondary={dutyType.section}
                      />
                    </ListItemButton>
                  </ListItem>
                );
              })}
            </List>

            <Typography variant="body2" color="text.secondary">
              {t(
                'admin.dutySections.reassign.selectedCount',
                '{{count}} selected',
                { count: selectedIds.length }
              )}
            </Typography>

            <Divider />

            <FormControl fullWidth size="small" disabled={selectedIds.length === 0}>
              <InputLabel id="reassign-target-section-label">
                {t('admin.dutySections.reassign.targetSection', 'Move to Section')}
              </InputLabel>
              <Select
                labelId="reassign-target-section-label"
                value={targetSection}
                onChange={handleTargetChange}
                label={t('admin.dutySections.reassign.targetSection', 'Move to Section')}
              >
                {targetSections.map((section) => (
                  <MenuItem key={section.code} value={section.code}>
                    {section.name} ({section.code})
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Stack>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={handleClose}>
            {t('admin.dutySections.reassign.cancel', 'Cancel')}
          </Button>
          <Button
            variant="contained"
            onClick={handleMoveClick}
            disabled={selectedIds.length === 0 || !targetSection}
          >
            {t('admin.dutySections.reassign.move', 'Move')}
          </Button>
        </DialogActions>
      </>
    );

    const renderConfirmationStep = () => (
      <>
        <DialogContent>
          <Stack spacing={2}>
            {error && (
              <Alert severity="error" onClose={() => setError(null)}>
                {error}
                <Typography variant="body2" sx={{ mt: 1 }}>
                  {t(
                    'admin.dutySections.reassign.errors.noRecordsModified',
                    'No records were modified.'
                  )}
                </Typography>
              </Alert>
            )}

            <Alert severity="info">
              {t(
                'admin.dutySections.reassign.confirmationMessage',
                'You are about to move {{count}} duty type(s) to "{{target}}".',
                { count: selectedIds.length, target: targetSectionName }
              )}
            </Alert>

            <Box sx={{ pl: 2 }}>
              <Typography variant="body2" gutterBottom>
                <strong>
                  {t('admin.dutySections.reassign.dutyTypesCount', 'Duty types:')}
                </strong>{' '}
                {selectedIds.length}
              </Typography>
              <Typography variant="body2" gutterBottom>
                <strong>
                  {t('admin.dutySections.reassign.targetSectionLabel', 'Target section:')}
                </strong>{' '}
                {targetSectionName}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {t(
                  'admin.dutySections.reassign.impactNote',
                  'Associated duty assignments and personnel records will also be updated.'
                )}
              </Typography>
            </Box>

            <Divider />

            <Typography variant="body2" color="warning.main">
              {t(
                'admin.dutySections.reassign.confirmWarning',
                'This action will update all related assignments and personnel. Do you want to proceed?'
              )}
            </Typography>
          </Stack>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={handleBackToSelection} disabled={submitting}>
            {t('admin.dutySections.reassign.back', 'Back')}
          </Button>
          <Button
            variant="contained"
            color="primary"
            onClick={handleConfirm}
            disabled={submitting}
          >
            {submitting
              ? t('admin.dutySections.reassign.confirming', 'Moving...')
              : t('admin.dutySections.reassign.confirm', 'Confirm')}
          </Button>
        </DialogActions>
      </>
    );

    const renderSuccessStep = () => (
      <>
        <DialogContent>
          <Stack spacing={2}>
            <Alert severity="success">
              {t(
                'admin.dutySections.reassign.successMessage',
                'Reassignment completed successfully.'
              )}
            </Alert>

            {result && (
              <Box sx={{ pl: 2 }}>
                <Typography variant="body2" gutterBottom>
                  <strong>
                    {t('admin.dutySections.reassign.dutyTypesUpdated', 'Duty types updated:')}
                  </strong>{' '}
                  {result.dutyTypesUpdated}
                </Typography>
                <Typography variant="body2" gutterBottom>
                  <strong>
                    {t(
                      'admin.dutySections.reassign.assignmentsUpdated',
                      'Duty assignments updated:'
                    )}
                  </strong>{' '}
                  {result.dutyAssignmentsUpdated}
                </Typography>
                <Typography variant="body2" gutterBottom>
                  <strong>
                    {t('admin.dutySections.reassign.personnelUpdated', 'Personnel updated:')}
                  </strong>{' '}
                  {result.personnelUpdated}
                </Typography>
                <Typography variant="body2" gutterBottom>
                  <strong>
                    {t('admin.dutySections.reassign.fromSection', 'From:')}
                  </strong>{' '}
                  {result.sourceSection}
                  {' → '}
                  <strong>
                    {t('admin.dutySections.reassign.toSection', 'To:')}
                  </strong>{' '}
                  {result.targetSection}
                </Typography>
              </Box>
            )}
          </Stack>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button variant="contained" onClick={handleClose}>
            {t('admin.dutySections.reassign.close', 'Close')}
          </Button>
        </DialogActions>
      </>
    );

    return (
      <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
        <DialogTitle>
          {t('admin.dutySections.reassign.title', 'Reassign Duty Types')}
        </DialogTitle>
        {step === 'selection' && renderSelectionStep()}
        {step === 'confirmation' && renderConfirmationStep()}
        {step === 'success' && renderSuccessStep()}
      </Dialog>
    );
  }
);

export default ReassignDialog;

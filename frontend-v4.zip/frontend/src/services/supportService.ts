import api from './api';

export interface SupportTicket {
  id: number;
  subject: string;
  message: string;
  category: string;
  priority: string;
  status: string;
  submittedBy: string;
  adminResponse: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface CreateTicketRequest {
  subject: string;
  message: string;
  category: string;
  priority: string;
}

export const supportService = {
  submit: (data: CreateTicketRequest) =>
    api.post<SupportTicket>('/api/support/tickets', data).then((r) => r.data),

  list: () =>
    api.get<SupportTicket[]>('/api/support/tickets').then((r) => r.data),
};

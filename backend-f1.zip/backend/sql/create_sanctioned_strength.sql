-- =====================================================
-- SQL Script to create sanctioned_strength table (PostgreSQL)
-- Run this script to set up the personnel strength metrics feature
-- =====================================================

-- Create the sanctioned_strength table
CREATE TABLE IF NOT EXISTS sanctioned_strength (
    id BIGSERIAL PRIMARY KEY,
    designation VARCHAR(50) NOT NULL UNIQUE,
    display_order INTEGER NOT NULL,
    sanctioned_count INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_sanctioned_strength_designation ON sanctioned_strength(designation);
CREATE INDEX IF NOT EXISTS idx_sanctioned_strength_display_order ON sanctioned_strength(display_order);

-- Insert initial sanctioned strength data for all designations
-- Update the sanctioned_count values based on your actual sanctioned strength
-- The display_order determines the column order in the UI table

INSERT INTO sanctioned_strength (designation, display_order, sanctioned_count) VALUES
('DCP', 1, 1),
('ACP', 2, 1),
('RPI', 3, 4),
('RSI', 4, 14),
('ARSI', 5, 50),
('AHC', 6, 146),
('APC', 7, 343)
ON CONFLICT (designation) DO UPDATE SET
    display_order = EXCLUDED.display_order,
    sanctioned_count = EXCLUDED.sanctioned_count,
    updated_at = CURRENT_TIMESTAMP;

-- Verify the data
SELECT * FROM sanctioned_strength ORDER BY display_order;

-- =====================================================
-- NOTES:
-- 1. To add a new designation in the future, use:
--    INSERT INTO sanctioned_strength (designation, display_order, sanctioned_count) 
--    VALUES ('NEW_DESIGNATION', 8, 0);
--
-- 2. To update sanctioned count for a designation:
--    UPDATE sanctioned_strength SET sanctioned_count = 150 WHERE designation = 'AHC';
--
-- 3. To reorder designations, update the display_order values
--
-- 4. If you need to update multiple designations at once, use:
--    UPDATE sanctioned_strength SET sanctioned_count = CASE
--        WHEN designation = 'DCP' THEN 2
--        WHEN designation = 'ACP' THEN 3
--        ELSE sanctioned_count
--    END;
-- =====================================================

import React, { useCallback, useEffect, useState } from 'react';
import {
  Box, Typography, Button, Alert, Skeleton, CircularProgress, alpha,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Paper, IconButton, TextField, Tooltip,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import PeopleIcon from '@mui/icons-material/People';
import PersonIcon from '@mui/icons-material/Person';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import GridOnIcon from '@mui/icons-material/GridOn';
import EditIcon from '@mui/icons-material/Edit';
import SaveIcon from '@mui/icons-material/Save';
import CloseIcon from '@mui/icons-material/Close';

import { useTranslation } from 'react-i18next';
import DataTable, { type Column } from '@/components/DataTable';
import PageHeader from '@/components/common/PageHeader';
import StatusBadge from '@/components/common/StatusBadge';
import { personnelService } from '@/services/personnelService';
import { sectionService } from '@/services/sectionService';
import { strengthService } from '@/services/strengthService';
import api from '@/services/api';
import type { PersonnelDto, StrengthMetricsDto } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

const PersonnelPage: React.FC = () => {
  const { t } = useTranslation();
  const { role, isAdmin, hasCAR, hasMT, isMTOnly } = useAuth();
  const navigate = useNavigate();
  const [data, setData] = useState<PersonnelDto[]>([]);
  const [filteredData, setFilteredData] = useState<PersonnelDto[]>([]);
  const [totalFromServer, setTotalFromServer] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [sectionCodes, setSectionCodes] = useState<string[]>([]);

  // Strength Metrics State
  const [strengthMetrics, setStrengthMetrics] = useState<StrengthMetricsDto | null>(null);
  const [metricsLoading, setMetricsLoading] = useState(true);
  const [editingSanctioned, setEditingSanctioned] = useState<Record<string, number>>({});
  const [isEditing, setIsEditing] = useState(false);
  const [savingMetrics, setSavingMetrics] = useState(false);

  const canEdit = role === 'ADMIN' || role === 'HIGHER_OFFICER';
  const [selectedUnit, setSelectedUnit] = useState<'CAR' | 'MT'>(isMTOnly ? 'MT' : 'CAR');

  const fetchData = async () => {
    setLoading(true);
    try {
      const [result, sections] = await Promise.all([
        personnelService.list(undefined, 0, 2000),
        sectionService.list(),
      ]);
      setData(result.content);
      setFilteredData(result.content);
      setTotalFromServer(result.totalElements);
      setSectionCodes(sections.map(s => s.code));
    } catch {
      setError(t('app.error'));
    } finally {
      setLoading(false);
    }
  };

  const fetchStrengthMetrics = async () => {
    setMetricsLoading(true);
    try {
      const metrics = await strengthService.getMetrics();
      setStrengthMetrics(metrics);
    } catch (err) {
      console.error('Failed to fetch strength metrics:', err);
    } finally {
      setMetricsLoading(false);
    }
  };

  useEffect(() => { 
    fetchData(); 
    fetchStrengthMetrics();
  }, []);

  const columns: Column<PersonnelDto>[] = [
    { id: 'badgeId', labelKey: 'personnel.badgeId', filterable: true, width: 100 },
    {
      id: 'personName', labelKey: 'personnel.personName', filterable: true, minWidth: 180,
      render: (row) => (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.2 }}>
          <Box
            component="img"
            src="/police-avatar.svg"
            alt=""
            sx={{
              width: 32, height: 32, borderRadius: '50%',
              flexShrink: 0,
            }}
          />
          <Box>
            <Typography sx={{ fontSize: '0.85rem', fontWeight: 500, color: '#111827', lineHeight: 1.2 }}>{row.personName}</Typography>
            {row.email && <Typography sx={{ fontSize: '0.72rem', color: '#9ca3af' }}>{row.email}</Typography>}
          </Box>
        </Box>
      ),
    },
    {
      id: 'designation', labelKey: 'personnel.designation', filterable: true,
      filterType: 'select', filterOptions: ['DCP', 'ACP', 'RPI', 'RSI', 'ARSI', 'AHC', 'APC'],
      render: (row) => row.designation ? (
        <Box sx={{
          display: 'inline-block', px: 1.2, py: 0.3, borderRadius: 1,
          bgcolor: row.designation === 'DCP' || row.designation === 'ACP' ? '#ede9fe' :
                   row.designation === 'RSI' || row.designation === 'RPI' ? '#dbeafe' : '#f0fdf4',
          color: row.designation === 'DCP' || row.designation === 'ACP' ? '#6d28d9' :
                 row.designation === 'RSI' || row.designation === 'RPI' ? '#1d4ed8' : '#166534',
          fontSize: '0.75rem', fontWeight: 600,
        }}>
          {row.designation}
        </Box>
      ) : null,
    },
    { id: 'dutyType', labelKey: 'personnel.dutyType', filterable: true },
    {
      id: 'section', labelKey: 'personnel.section', filterable: true,
      filterType: 'select', filterOptions: sectionCodes,
    },
    { id: 'location', labelKey: 'personnel.location' },
    {
      id: 'isActive', labelKey: 'personnel.active',
      render: (row) => (
        <StatusBadge
          status={row.isActive ? 'Active' : 'On Leave'}
          size="small"
          showDot
        />
      ),
    },
  ];

  const handleFilteredDataChange = useCallback((filtered: PersonnelDto[]) => {
    setFilteredData(filtered);
  }, []);

  const carCompanyCount = data.filter(p => !p.unit || p.unit.toUpperCase() === 'CAR').length;
  const mtPersonsCount = data.filter(p => p.unit && p.unit.toUpperCase() === 'MT').length;

  // Data filtered by selected unit for the table
  const unitFilteredData = data.filter(p => {
    if (selectedUnit === 'MT') return p.unit && p.unit.toUpperCase() === 'MT';
    return !p.unit || p.unit.toUpperCase() === 'CAR';
  });

  const [downloading, setDownloading] = useState<string | null>(null);

  const handleDownloadReport = async (endpoint: string, filename: string) => {
    setDownloading(endpoint);
    try {
      const response = await api.get(endpoint, { responseType: 'blob' });
      const url = window.URL.createObjectURL(response.data);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      link.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Download failed:', error);
    } finally {
      setDownloading(null);
    }
  };

  // Handle edit mode for sanctioned strength
  const handleStartEdit = () => {
    if (strengthMetrics) {
      setEditingSanctioned({ ...strengthMetrics.sanctionedStrength });
      setIsEditing(true);
    }
  };

  const handleCancelEdit = () => {
    setEditingSanctioned({});
    setIsEditing(false);
  };

  const handleSanctionedChange = (designation: string, value: string) => {
    const numValue = parseInt(value, 10);
    if (!isNaN(numValue) && numValue >= 0) {
      setEditingSanctioned(prev => ({ ...prev, [designation]: numValue }));
    }
  };

  const handleSaveMetrics = async () => {
    setSavingMetrics(true);
    try {
      const updates = Object.entries(editingSanctioned).map(([designation, sanctionedCount]) => ({
        designation,
        sanctionedCount,
      }));
      await strengthService.bulkUpdateSanctioned(updates);
      await fetchStrengthMetrics();
      setIsEditing(false);
      setEditingSanctioned({});
    } catch (err) {
      console.error('Failed to save metrics:', err);
      setError('Failed to save sanctioned strength');
    } finally {
      setSavingMetrics(false);
    }
  };

  const breadcrumbs = [
    { label: 'Home', path: '/' },
    { label: 'Personnel' },
  ];

  const actions = canEdit
    ? [
        {
          label: t('personnel.addPerson'),
          variant: 'primary' as const,
          icon: <AddIcon />,
          onClick: () => navigate('/personnel/add'),
        },
      ]
    : undefined;

  // Calculate totals for editing mode
  const getEditingTotals = () => {
    if (!strengthMetrics) return { sanctioned: 0, present: 0, vacancy: 0 };
    const sanctioned = Object.values(editingSanctioned).reduce((a, b) => a + b, 0);
    const present = strengthMetrics.totalPresent;
    // Calculate vacancy total: only sum positive vacancies (actual vacancies), ignore negative (excess)
    let vacancyTotal = 0;
    strengthMetrics.designations.forEach((designation) => {
      const s = editingSanctioned[designation] ?? 0;
      const p = strengthMetrics.presentStrength[designation] ?? 0;
      const v = s - p;
      if (v > 0) vacancyTotal += v;
    });
    return { sanctioned, present, vacancy: vacancyTotal };
  };

  // Calculate actual vacancy total (only positive values)
  const getActualVacancyTotal = () => {
    if (!strengthMetrics) return 0;
    let total = 0;
    strengthMetrics.designations.forEach((designation) => {
      const vacancy = strengthMetrics.vacancy[designation] ?? 0;
      if (vacancy > 0) total += vacancy;
    });
    return total;
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', bgcolor: 'background.default' }}>
      {/* PageHeader replaces gradient banner */}
      <PageHeader
        title={t('personnel.title')}
        breadcrumbs={breadcrumbs}
        actions={actions}
      />

      {/* Main Content */}
      <Box sx={{ flex: 1, p: 3 }}>
        {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}

        {/* Summary Metric Cards with Download Buttons */}
        <Box sx={{
          display: 'grid',
          gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)' },
          gap: 2,
          mb: 3,
        }}>
          {/* C.A.R COMPANY Card */}
          {hasCAR && (
          <Box
            onClick={() => setSelectedUnit('CAR')}
            sx={{
              border: selectedUnit === 'CAR' ? '2px solid #312e81' : '1px solid #e5e7eb',
              borderRadius: 2, p: 2, bgcolor: selectedUnit === 'CAR' ? '#f5f3ff' : '#fff',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              cursor: 'pointer', transition: 'all 0.2s',
              '&:hover': { borderColor: '#312e81', bgcolor: '#f5f3ff' },
            }}
          >
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
              <PeopleIcon sx={{ color: '#312e81', fontSize: 28 }} />
              <Box>
                <Typography sx={{ fontSize: '1.75rem', fontWeight: 700, color: '#111827', lineHeight: 1.1 }}>{carCompanyCount}</Typography>
                <Typography sx={{ fontSize: '0.8rem', color: '#6b7280' }}>C.A.R COMPANY</Typography>
              </Box>
            </Box>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Button
                size="small"
                variant="outlined"
                startIcon={downloading === '/api/reports/personnel' ? <CircularProgress size={16} /> : <PictureAsPdfIcon />}
                disabled={!!downloading}
                onClick={(e) => { e.stopPropagation(); handleDownloadReport('/api/reports/personnel', 'CAR MANGALURU CITY (COMPANY).pdf'); }}
                sx={{
                  borderRadius: 2, textTransform: 'none', fontWeight: 600,
                  borderColor: '#16a34a', color: '#16a34a',
                  '&:hover': { bgcolor: alpha('#16a34a', 0.08), borderColor: '#16a34a' },
                }}
              >
                PDF
              </Button>
              <Button
                size="small"
                variant="outlined"
                startIcon={downloading === '/api/reports/personnel/excel' ? <CircularProgress size={16} /> : <GridOnIcon />}
                disabled={!!downloading}
                onClick={(e) => { e.stopPropagation(); handleDownloadReport('/api/reports/personnel/excel', 'CAR MANGALURU CITY (COMPANY).xlsx'); }}
                sx={{
                  borderRadius: 2, textTransform: 'none', fontWeight: 600,
                  borderColor: '#16a34a', color: '#16a34a',
                  '&:hover': { bgcolor: alpha('#16a34a', 0.08), borderColor: '#16a34a' },
                }}
              >
                Excel
              </Button>
            </Box>
          </Box>
          )}

          {/* MT Persons Card */}
          {hasMT && (
          <Box
            onClick={() => setSelectedUnit('MT')}
            sx={{
              border: selectedUnit === 'MT' ? '2px solid #059669' : '1px solid #e5e7eb',
              borderRadius: 2, p: 2, bgcolor: selectedUnit === 'MT' ? '#ecfdf5' : '#fff',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              cursor: 'pointer', transition: 'all 0.2s',
              '&:hover': { borderColor: '#059669', bgcolor: '#ecfdf5' },
            }}
          >
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
              <PersonIcon sx={{ color: '#059669', fontSize: 28 }} />
              <Box>
                <Typography sx={{ fontSize: '1.75rem', fontWeight: 700, color: '#111827', lineHeight: 1.1 }}>{mtPersonsCount}</Typography>
                <Typography sx={{ fontSize: '0.8rem', color: '#6b7280' }}>MT Persons</Typography>
              </Box>
            </Box>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Button
                size="small"
                variant="outlined"
                startIcon={downloading === '/api/reports/mt-section' ? <CircularProgress size={16} /> : <PictureAsPdfIcon />}
                disabled={!!downloading}
                onClick={(e) => { e.stopPropagation(); handleDownloadReport('/api/reports/mt-section', 'MT_Section.pdf'); }}
                sx={{
                  borderRadius: 2, textTransform: 'none', fontWeight: 600,
                  borderColor: '#0891b2', color: '#0891b2',
                  '&:hover': { bgcolor: alpha('#0891b2', 0.08), borderColor: '#0891b2' },
                }}
              >
                PDF
              </Button>
              <Button
                size="small"
                variant="outlined"
                startIcon={downloading === '/api/reports/mt-section/excel' ? <CircularProgress size={16} /> : <GridOnIcon />}
                disabled={!!downloading}
                onClick={(e) => { e.stopPropagation(); handleDownloadReport('/api/reports/mt-section/excel', 'MT_Section.xlsx'); }}
                sx={{
                  borderRadius: 2, textTransform: 'none', fontWeight: 600,
                  borderColor: '#0891b2', color: '#0891b2',
                  '&:hover': { bgcolor: alpha('#0891b2', 0.08), borderColor: '#0891b2' },
                }}
              >
                Excel
              </Button>
            </Box>
          </Box>
          )}
        </Box>

        {/* Strength Metrics Table */}
        <Paper sx={{ mb: 3, overflow: 'hidden', borderRadius: 2, border: '1px solid #e5e7eb' }}>
          <Box sx={{ 
            px: 2, py: 1.5, 
            bgcolor: '#f8fafc', 
            borderBottom: '1px solid #e5e7eb',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}>
            <Typography sx={{ fontWeight: 600, fontSize: '0.95rem', color: '#1e293b' }}>
              Personnel Strength Overview
            </Typography>
            {canEdit && !isEditing && (
              <Tooltip title="Edit Sanctioned Strength">
                <IconButton size="small" onClick={handleStartEdit} sx={{ color: '#6366f1' }}>
                  <EditIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            )}
            {isEditing && (
              <Box sx={{ display: 'flex', gap: 1 }}>
                <Tooltip title="Save Changes">
                  <IconButton 
                    size="small" 
                    onClick={handleSaveMetrics} 
                    disabled={savingMetrics}
                    sx={{ color: '#16a34a' }}
                  >
                    {savingMetrics ? <CircularProgress size={18} /> : <SaveIcon fontSize="small" />}
                  </IconButton>
                </Tooltip>
                <Tooltip title="Cancel">
                  <IconButton 
                    size="small" 
                    onClick={handleCancelEdit} 
                    disabled={savingMetrics}
                    sx={{ color: '#dc2626' }}
                  >
                    <CloseIcon fontSize="small" />
                  </IconButton>
                </Tooltip>
              </Box>
            )}
          </Box>
          
          {metricsLoading ? (
            <Box sx={{ p: 2 }}>
              <Skeleton variant="rectangular" height={120} sx={{ borderRadius: 1 }} />
            </Box>
          ) : strengthMetrics ? (
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow sx={{ bgcolor: '#f1f5f9' }}>
                    <TableCell sx={{ fontWeight: 700, fontSize: '0.8rem', color: '#475569', py: 1.5, borderRight: '1px solid #e2e8f0' }}>
                      HEADS
                    </TableCell>
                    {strengthMetrics.designations.map((designation) => (
                      <TableCell 
                        key={designation} 
                        align="center" 
                        sx={{ 
                          fontWeight: 700, 
                          fontSize: '0.75rem', 
                          color: '#475569', 
                          py: 1.5,
                          borderRight: '1px solid #e2e8f0',
                          minWidth: 60,
                        }}
                      >
                        {designation}
                      </TableCell>
                    ))}
                    <TableCell 
                      align="center" 
                      sx={{ 
                        fontWeight: 700, 
                        fontSize: '0.8rem', 
                        color: '#1e293b', 
                        py: 1.5,
                        bgcolor: '#e2e8f0',
                        minWidth: 80,
                      }}
                    >
                      TOTAL
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {/* Row 1: C.A.R SANCTIONED STRENGTH */}
                  <TableRow sx={{ '&:hover': { bgcolor: '#f8fafc' } }}>
                    <TableCell sx={{ 
                      fontWeight: 600, 
                      fontSize: '0.78rem', 
                      color: '#1e293b', 
                      py: 1.5,
                      borderRight: '1px solid #e2e8f0',
                    }}>
                      C.A.R SANCTIONED STRENGTH
                    </TableCell>
                    {strengthMetrics.designations.map((designation) => (
                      <TableCell 
                        key={designation} 
                        align="center" 
                        sx={{ 
                          py: 1, 
                          borderRight: '1px solid #e2e8f0',
                        }}
                      >
                        {isEditing ? (
                          <TextField
                            type="number"
                            size="small"
                            value={editingSanctioned[designation] ?? 0}
                            onChange={(e) => handleSanctionedChange(designation, e.target.value)}
                            inputProps={{ min: 0, style: { textAlign: 'center', padding: '4px 8px', fontSize: '0.8rem' } }}
                            sx={{ width: 60 }}
                          />
                        ) : (
                          <Box sx={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            minWidth: 40,
                            px: 1,
                            py: 0.5,
                            borderRadius: 1,
                            bgcolor: '#e0e7ff',
                            color: '#3730a3',
                            fontWeight: 600,
                            fontSize: '0.8rem',
                          }}>
                            {strengthMetrics.sanctionedStrength[designation] ?? 0}
                          </Box>
                        )}
                      </TableCell>
                    ))}
                    <TableCell 
                      align="center" 
                      sx={{ 
                        fontWeight: 700, 
                        fontSize: '0.85rem', 
                        color: '#1e293b',
                        bgcolor: '#e2e8f0',
                        py: 1.5,
                      }}
                    >
                      {isEditing ? getEditingTotals().sanctioned : strengthMetrics.totalSanctioned}
                    </TableCell>
                  </TableRow>

                  {/* Row 2: PRESENT STRENGTH TOTAL */}
                  <TableRow sx={{ '&:hover': { bgcolor: '#f8fafc' } }}>
                    <TableCell sx={{ 
                      fontWeight: 600, 
                      fontSize: '0.78rem', 
                      color: '#1e293b', 
                      py: 1.5,
                      borderRight: '1px solid #e2e8f0',
                    }}>
                      PRESENT STRENGTH TOTAL
                    </TableCell>
                    {strengthMetrics.designations.map((designation) => (
                      <TableCell 
                        key={designation} 
                        align="center" 
                        sx={{ 
                          py: 1.5,
                          borderRight: '1px solid #e2e8f0',
                        }}
                      >
                        <Box sx={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          minWidth: 40,
                          px: 1,
                          py: 0.5,
                          borderRadius: 1,
                          bgcolor: '#dcfce7',
                          color: '#166534',
                          fontWeight: 600,
                          fontSize: '0.8rem',
                        }}>
                          {strengthMetrics.presentStrength[designation] ?? 0}
                        </Box>
                      </TableCell>
                    ))}
                    <TableCell 
                      align="center" 
                      sx={{ 
                        fontWeight: 700, 
                        fontSize: '0.85rem', 
                        color: '#166534',
                        bgcolor: '#e2e8f0',
                        py: 1.5,
                      }}
                    >
                      {strengthMetrics.totalPresent}
                    </TableCell>
                  </TableRow>

                  {/* Row 3: ACTUAL VACANCY */}
                  <TableRow sx={{ bgcolor: '#fef2f2', '&:hover': { bgcolor: '#fee2e2' } }}>
                    <TableCell sx={{ 
                      fontWeight: 600, 
                      fontSize: '0.78rem', 
                      color: '#991b1b', 
                      py: 1.5,
                      borderRight: '1px solid #e2e8f0',
                    }}>
                      ACTUAL VACANCY
                    </TableCell>
                    {strengthMetrics.designations.map((designation) => {
                      const sanctioned = isEditing 
                        ? (editingSanctioned[designation] ?? 0)
                        : (strengthMetrics.sanctionedStrength[designation] ?? 0);
                      const present = strengthMetrics.presentStrength[designation] ?? 0;
                      const vacancy = sanctioned - present;
                      return (
                        <TableCell 
                          key={designation} 
                          align="center" 
                          sx={{ 
                            py: 1.5,
                            borderRight: '1px solid #e2e8f0',
                          }}
                        >
                          <Box sx={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            minWidth: 40,
                            px: 1,
                            py: 0.5,
                            borderRadius: 1,
                            bgcolor: vacancy > 0 ? '#fecaca' : vacancy < 0 ? '#bfdbfe' : '#e5e7eb',
                            color: vacancy > 0 ? '#991b1b' : vacancy < 0 ? '#1e40af' : '#374151',
                            fontWeight: 600,
                            fontSize: '0.8rem',
                          }}>
                            {vacancy}
                          </Box>
                        </TableCell>
                      );
                    })}
                    <TableCell 
                      align="center" 
                      sx={{ 
                        fontWeight: 700, 
                        fontSize: '0.85rem', 
                        color: '#991b1b',
                        bgcolor: '#e2e8f0',
                        py: 1.5,
                      }}
                    >
                      {isEditing ? getEditingTotals().vacancy : getActualVacancyTotal()}
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          ) : (
            <Box sx={{ p: 3, textAlign: 'center', color: '#9ca3af' }}>
              <Typography>No strength data available</Typography>
            </Box>
          )}
        </Paper>

        {/* Data Table with skeleton loading and empty state */}
        {loading ? (
          <Box>
            {/* Table skeleton */}
            <Skeleton variant="rectangular" width="100%" height={48} sx={{ borderRadius: 2, mb: 1 }} />
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} variant="rectangular" width="100%" height={40} sx={{ borderRadius: 1, mb: 0.5 }} />
            ))}
          </Box>
        ) : data.length === 0 ? (
          <Box sx={{
            display: 'flex', flexDirection: 'column', alignItems: 'center',
            justifyContent: 'center', py: 8, color: '#9ca3af',
          }}>
            <PeopleIcon sx={{ fontSize: 48, mb: 2, opacity: 0.5 }} />
            <Typography sx={{ fontSize: '1rem', fontWeight: 500 }}>
              {t('personnel.noRecords', 'No personnel records found')}
            </Typography>
            <Typography sx={{ fontSize: '0.85rem', mt: 0.5, color: '#b0b0b0' }}>
              {t('personnel.noRecordsHint', 'Add personnel to get started')}
            </Typography>
          </Box>
        ) : (
          <DataTable<PersonnelDto>
            columns={columns}
            data={unitFilteredData}
            keyField="id"
            searchable
            searchPlaceholderKey="personnel.searchPlaceholder"
            dense
            onFilteredDataChange={handleFilteredDataChange}
            onRowClick={(row) => navigate(`/personnel/${row.badgeId}`)}
            actions={(row) => (
              <Button size="small" onClick={() => navigate(`/personnel/${row.badgeId}`)}
                sx={{
                  textTransform: 'none', fontSize: '0.78rem', fontWeight: 500,
                  color: '#312e81', '&:hover': { bgcolor: '#f0f0ff' },
                }}>
                {t('app.view', 'View')}
              </Button>
            )}
          />
        )}
      </Box>
    </Box>
  );
};

export default PersonnelPage;

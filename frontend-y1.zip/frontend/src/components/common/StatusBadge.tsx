import React from 'react';
import { Chip, Box } from '@mui/material';

/**
 * Status color configuration type
 */
export interface StatusConfig {
  bg: string;
  text: string;
  border: string;
}

/**
 * Known status types
 */
export type StatusType = 'Active' | 'Approved' | 'Cancelled' | 'Completed' | 'On Leave' | 'Pending' | 'Rejected';

/**
 * Status color mapping for known statuses
 */
const STATUS_CONFIG: Record<StatusType, StatusConfig> = {
  Active: { bg: '#ecfdf5', text: '#059669', border: '#a7f3d0' },
  Approved: { bg: '#ecfdf5', text: '#059669', border: '#a7f3d0' },
  Cancelled: { bg: '#fff1f2', text: '#e11d48', border: '#fecdd3' },
  Completed: { bg: '#f1f5f9', text: '#334155', border: '#e2e8f0' },
  'On Leave': { bg: '#fffbeb', text: '#d97706', border: '#fde68a' },
  Pending: { bg: '#eff6ff', text: '#2563eb', border: '#bfdbfe' },
  Rejected: { bg: '#fff1f2', text: '#e11d48', border: '#fecdd3' },
};

/**
 * Fallback configuration for unknown statuses
 */
const DEFAULT_STATUS: StatusConfig = { bg: '#f8fafc', text: '#64748b', border: '#e2e8f0' };

/**
 * Known status strings
 */
const KNOWN_STATUSES: ReadonlyArray<string> = ['Active', 'Approved', 'Cancelled', 'Completed', 'On Leave', 'Pending', 'Rejected'];

/**
 * Returns the color configuration for a given status string.
 * Returns DEFAULT_STATUS for any status not in the known set.
 */
export function getStatusConfig(status: string): StatusConfig {
  if (KNOWN_STATUSES.includes(status)) {
    return STATUS_CONFIG[status as StatusType];
  }
  return DEFAULT_STATUS;
}

/**
 * Props for the StatusBadge component
 */
export interface StatusBadgeProps {
  /** The status value to display */
  status: string;
  /** Size variant: small (22px) or default (26px) */
  size?: 'small' | 'default';
  /** Whether to show a leading dot indicator */
  showDot?: boolean;
}

/**
 * StatusBadge renders a pill-shaped badge with status-specific colors.
 * Supports 5 known statuses with a neutral fallback for unknown values.
 */
const StatusBadge: React.FC<StatusBadgeProps> = ({ status, size = 'default', showDot = false }) => {
  const config = getStatusConfig(status);

  const isSmall = size === 'small';
  const height = isSmall ? 22 : 26;
  const fontSize = isSmall ? '12px' : '13px';
  const horizontalPadding = isSmall ? '8px' : '10px';

  const dot = showDot ? (
    <Box
      component="span"
      sx={{
        width: 6,
        height: 6,
        borderRadius: '50%',
        backgroundColor: config.text,
        flexShrink: 0,
      }}
    />
  ) : undefined;

  return (
    <Chip
      label={status}
      icon={dot}
      aria-label={`Status: ${status}`}
      sx={{
        height,
        maxWidth: 120,
        borderRadius: '50px',
        backgroundColor: config.bg,
        color: config.text,
        border: `1px solid ${config.border}`,
        fontSize,
        fontWeight: 500,
        lineHeight: 1,
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        transition: 'background-color 200ms ease-in-out, color 200ms ease-in-out, border-color 200ms ease-in-out',
        px: horizontalPadding,
        '& .MuiChip-label': {
          padding: 0,
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          whiteSpace: 'nowrap',
        },
        '& .MuiChip-icon': {
          marginLeft: 0,
          marginRight: '6px',
        },
      }}
    />
  );
};

export default StatusBadge;

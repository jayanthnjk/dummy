import React, { useState } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Typography,
  Box,
  Chip,
} from '@mui/material';
import NavigateBeforeIcon from '@mui/icons-material/NavigateBefore';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import type { TableResponseData } from '@/types';

const PAGE_SIZE = 10;

const TableWidget: React.FC<TableResponseData> = ({ columns, rows, totalCount, meta }) => {
  const [page, setPage] = useState(0);

  const totalPages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
  const start = page * PAGE_SIZE;
  const end = Math.min(start + PAGE_SIZE, rows.length);
  const pageRows = rows.slice(start, end);

  // Derive title from column keys
  const hasPersonName = columns.some((c) => c.key === 'personName');
  const hasPlatoon = columns.some((c) => c.key === 'platoon');
  const hasCategory = columns.some((c) => c.key === 'category');
  const hasSection = columns.some((c) => c.key === 'section' && columns.some((cc) => cc.key === 'assignments'));
  const hasField = columns.some((c) => c.key === 'field');
  const tableTitle = hasPersonName ? 'Personnel' : hasPlatoon ? 'Platoon Rotation' : hasCategory ? 'Leave Summary' : hasSection ? 'Schedule Overview' : hasField ? 'Details' : 'Results';

  return (
    <Box sx={{ width: '100%', borderRadius: 2, overflow: 'hidden', border: '1px solid #e5e7eb' }}>
      {/* Header bar */}
      <Box sx={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        px: 1.5, py: 1, bgcolor: '#f8fafc', borderBottom: '1px solid #e5e7eb',
      }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Typography sx={{ fontSize: '0.8rem', fontWeight: 600, color: '#1e293b' }}>
            {tableTitle}
          </Typography>
          <Chip
            label={totalCount}
            size="small"
            sx={{
              height: 20, fontSize: '0.65rem', fontWeight: 700,
              bgcolor: '#1a1e4a', color: '#fff',
            }}
          />
        </Box>
        {rows.length > PAGE_SIZE && (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
            <IconButton
              size="small"
              onClick={() => setPage((p) => p - 1)}
              disabled={page === 0}
              sx={{ width: 24, height: 24, color: '#64748b', '&.Mui-disabled': { color: '#cbd5e1' } }}
            >
              <NavigateBeforeIcon sx={{ fontSize: 18 }} />
            </IconButton>
            <Typography sx={{ fontSize: '0.65rem', color: '#64748b', minWidth: 40, textAlign: 'center' }}>
              {page + 1}/{totalPages}
            </Typography>
            <IconButton
              size="small"
              onClick={() => setPage((p) => p + 1)}
              disabled={page >= totalPages - 1}
              sx={{ width: 24, height: 24, color: '#64748b', '&.Mui-disabled': { color: '#cbd5e1' } }}
            >
              <NavigateNextIcon sx={{ fontSize: 18 }} />
            </IconButton>
          </Box>
        )}
      </Box>

      {/* Table */}
      <TableContainer>
        <Table size="small">
          <TableHead>
            <TableRow sx={{ bgcolor: '#f1f5f9' }}>
              <TableCell sx={{
                fontWeight: 700, fontSize: '0.7rem', color: '#475569',
                textTransform: 'uppercase', letterSpacing: '0.05em',
                py: 0.75, px: 1.5, borderBottom: '2px solid #e2e8f0',
                whiteSpace: 'nowrap', width: 36,
              }}>
                #
              </TableCell>
              {columns.map((col) => (
                <TableCell
                  key={col.key}
                  sx={{
                    fontWeight: 700, fontSize: '0.7rem', color: '#475569',
                    textTransform: 'uppercase', letterSpacing: '0.05em',
                    py: 0.75, px: 1.5, borderBottom: '2px solid #e2e8f0',
                    whiteSpace: 'nowrap',
                  }}
                >
                  {col.label}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {pageRows.map((row, idx) => (
              <TableRow
                key={idx}
                sx={{
                  '&:nth-of-type(even)': { bgcolor: '#fafbfc' },
                  '&:hover': { bgcolor: '#f0f4ff' },
                  transition: 'background-color 0.15s',
                }}
              >
                <TableCell sx={{
                  fontSize: '0.72rem', py: 0.6, px: 1.5, color: '#94a3b8',
                  borderBottom: '1px solid #f1f5f9', fontWeight: 500,
                }}>
                  {start + idx + 1}
                </TableCell>
                {columns.map((col) => {
                  const val = row[col.key] != null ? String(row[col.key]) : '—';
                  const isStatus = col.key === 'status';
                  return (
                    <TableCell
                      key={col.key}
                      sx={{
                        fontSize: '0.75rem', py: 0.6, px: 1.5,
                        borderBottom: '1px solid #f1f5f9',
                        color: '#334155', whiteSpace: 'nowrap',
                      }}
                    >
                      {isStatus ? (
                        <Chip
                          label={val}
                          size="small"
                          sx={{
                            height: 20, fontSize: '0.65rem', fontWeight: 600,
                            bgcolor: val === 'Active' ? '#dcfce7' : '#fee2e2',
                            color: val === 'Active' ? '#166534' : '#991b1b',
                          }}
                        />
                      ) : (
                        val
                      )}
                    </TableCell>
                  );
                })}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Meta info */}
      {meta && Object.keys(meta).length > 0 && (
        <Box sx={{
          px: 1.5, py: 1, bgcolor: '#eef2ff', borderTop: '1px solid #e5e7eb',
          display: 'flex', flexWrap: 'wrap', gap: 1.5, alignItems: 'center',
        }}>
          {Object.entries(meta).map(([key, value]) => (
            <Box key={key} sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
              <Typography sx={{ fontSize: '0.7rem', fontWeight: 600, color: '#6366f1' }}>
                {key}:
              </Typography>
              <Chip
                label={String(value)}
                size="small"
                sx={{
                  height: 22, fontSize: '0.7rem', fontWeight: 700,
                  bgcolor: '#fff', color: '#1e293b',
                  border: '1px solid #c7d2fe',
                }}
              />
            </Box>
          ))}
        </Box>
      )}

      {/* Footer */}
      <Box sx={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        px: 1.5, py: 0.75, bgcolor: '#f8fafc', borderTop: '1px solid #e5e7eb',
      }}>
        <Typography sx={{ fontSize: '0.65rem', color: '#94a3b8' }}>
          Showing {rows.length === 0 ? 0 : start + 1}–{end} of {totalCount}
        </Typography>
      </Box>
    </Box>
  );
};

export default TableWidget;

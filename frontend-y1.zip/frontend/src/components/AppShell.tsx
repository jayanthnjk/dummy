import React, { useState, useCallback, createContext, useContext, useMemo } from 'react';
import { Box, useMediaQuery, useTheme } from '@mui/material';
import { useLocation } from 'react-router-dom';
import Sidebar, { SIDEBAR_WIDTH, SIDEBAR_COLLAPSED_WIDTH } from './Sidebar';
import { fadeIn } from '@/theme/animations';

/**
 * Pure utility: returns the sidebar mode for a given viewport width.
 * "permanent" for desktop (≥900px), "temporary" overlay for mobile (<900px).
 */
export function getSidebarMode(viewportWidth: number): 'permanent' | 'temporary' {
  return viewportWidth >= 900 ? 'permanent' : 'temporary';
}

/** Context for mobile drawer control — used by PageHeader to show hamburger */
interface AppShellContextValue {
  onMobileOpen: () => void;
  isMobile: boolean;
}

const AppShellContext = createContext<AppShellContextValue>({
  onMobileOpen: () => {},
  isMobile: false,
});

export const useAppShell = () => useContext(AppShellContext);

interface AppShellProps {
  children: React.ReactNode;
}

const AppShell: React.FC<AppShellProps> = ({ children }) => {
  const theme = useTheme();
  const isDesktop = useMediaQuery(theme.breakpoints.up('md')); // md = 900px
  const location = useLocation();

  // Sidebar state
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);

  const handleToggleCollapse = useCallback(() => {
    setSidebarCollapsed((prev) => !prev);
  }, []);

  const handleMobileClose = useCallback(() => {
    setMobileDrawerOpen(false);
  }, []);

  const handleMobileOpen = useCallback(() => {
    setMobileDrawerOpen(true);
  }, []);

  const currentWidth = sidebarCollapsed ? SIDEBAR_COLLAPSED_WIDTH : SIDEBAR_WIDTH;
  const isMobile = !isDesktop;

  const contextValue = useMemo<AppShellContextValue>(
    () => ({ onMobileOpen: handleMobileOpen, isMobile }),
    [handleMobileOpen, isMobile],
  );

  return (
    <AppShellContext.Provider value={contextValue}>
    <Box sx={{ display: 'flex', minHeight: '100vh', bgcolor: 'background.default' }}>
      {/* Skip-to-content link — first focusable element */}
      <a
        href="#main-content"
        className="skip-nav"
        style={{
          position: 'absolute',
          left: '-9999px',
          top: 'auto',
          width: '1px',
          height: '1px',
          overflow: 'hidden',
          zIndex: 9999,
        }}
        onFocus={(e) => {
          // Make visible on focus
          const el = e.currentTarget;
          el.style.position = 'fixed';
          el.style.left = '16px';
          el.style.top = '16px';
          el.style.width = 'auto';
          el.style.height = 'auto';
          el.style.overflow = 'visible';
          el.style.padding = '12px 24px';
          el.style.backgroundColor = '#312e81';
          el.style.color = '#ffffff';
          el.style.borderRadius = '8px';
          el.style.fontSize = '0.875rem';
          el.style.fontWeight = '600';
          el.style.textDecoration = 'none';
          el.style.boxShadow = '0 4px 12px rgba(49,46,129,0.3)';
        }}
        onBlur={(e) => {
          // Hide when focus leaves
          const el = e.currentTarget;
          el.style.position = 'absolute';
          el.style.left = '-9999px';
          el.style.top = 'auto';
          el.style.width = '1px';
          el.style.height = '1px';
          el.style.overflow = 'hidden';
          el.style.padding = '0';
          el.style.boxShadow = 'none';
        }}
      >
        Skip to content
      </a>

      {/* Sidebar */}
      <Sidebar
        collapsed={sidebarCollapsed}
        mobileOpen={mobileDrawerOpen}
        onToggleCollapse={handleToggleCollapse}
        onClose={handleMobileClose}
      />

      {/* Main content area — full viewport height, no top offset */}
      <Box
        component="main"
        id="main-content"
        tabIndex={-1}
        sx={{
          flexGrow: 1,
          width: { md: `calc(100% - ${currentWidth}px)` },
          minHeight: '100vh',
          overflow: 'auto',
          bgcolor: 'background.default',
          transition: 'width 250ms cubic-bezier(0.4, 0, 0.2, 1)',
          outline: 'none',
        }}
      >
        {/* Page transition animation using key on location */}
        <Box
          key={location.pathname}
          sx={{
            animation: `${fadeIn} 200ms ease-out`,
            '@media (prefers-reduced-motion: reduce)': {
              animation: 'none',
            },
          }}
        >
          {children}
        </Box>
      </Box>
    </Box>
    </AppShellContext.Provider>
  );
};

export default AppShell;

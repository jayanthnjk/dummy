# Test Strategy & Test Report
## KSP WorkBoard — Police Station Management System

| Field | Details |
|-------|---------|
| **Document Title** | Test Strategy & Report |
| **Version** | 1.0.0 |
| **Date** | June 2026 |
| **Testing Frameworks** | JUnit 5, jqwik 1.9.2, Vitest 3.0.5, fast-check 4.1.1 |

---

## 1. Test Strategy Overview

### 1.1 Testing Approach

KSP WorkBoard employs a multi-layered testing strategy combining:
- **Unit Testing** — Isolated class-level testing with mocked dependencies
- **Property-Based Testing** — Verifying system invariants with random inputs
- **Integration Testing** — Full Spring context testing against real database
- **API Testing** — MockMvc-based HTTP endpoint validation
- **Frontend Testing** — Component and service testing with Vitest

### 1.2 Testing Pyramid

```mermaid
graph TD
    subgraph "Testing Pyramid"
        E2E[E2E / Manual<br>~20 scenarios]
        INT[Integration Tests<br>~50 tests]
        UNIT[Unit + Property Tests<br>~200+ tests]
    end
    E2E -.-> INT
    INT -.-> UNIT
```

---

## 2. Backend Test Framework Configuration

### 2.1 build.gradle Test Dependencies

```groovy
testImplementation 'org.springframework.boot:spring-boot-starter-test'
testImplementation 'org.springframework.security:spring-security-test'
testImplementation 'net.jqwik:jqwik:1.9.2'
testRuntimeOnly 'org.junit.platform:junit-platform-launcher'
```

### 2.2 Test Runner Configuration

```groovy
tasks.named('test') {
    useJUnitPlatform()  // Supports both JUnit 5 and jqwik
}
```

### 2.3 jqwik Database File

The `.jqwik-database` file in backend root stores test execution history for jqwik property-based tests.

---

## 3. Frontend Test Framework Configuration

### 3.1 package.json Test Setup

```json
{
  "scripts": {
    "test": "vitest --run"
  },
  "devDependencies": {
    "vitest": "^3.0.5",
    "fast-check": "^4.1.1"
  }
}
```

---

## 4. Test Categories & Coverage

### 4.1 Unit Test Categories

| Category | Target | Framework | Example |
|----------|--------|-----------|---------|
| Service Logic | PersonnelService, LeaveService, CycleService | JUnit 5 + Mockito | Test badge uniqueness validation |
| Validation | CycleValidator, driver field validation | JUnit 5 | Test endDate calculation |
| Chat Pipeline | FunctionCallingService, InputSanitizer | JUnit 5 | Test prompt injection detection |
| MCP Servers | CycleMcpServer, DomainDbMcpServer | JUnit 5 + Mockito | Test tool execution |
| DTOs | Mapper methods, record constructors | JUnit 5 | Test toDto mappings |
| Cache | ResponseCacheService invalidation logic | JUnit 5 | Test write tool invalidation |

### 4.2 Property-Based Test Categories (jqwik)

| Property | Description | Generator |
|----------|-------------|-----------|
| Badge ID format | All generated badge IDs match PREFIX-NUMBER pattern | Arbitraries.strings() |
| Cycle date integrity | endDate always = startDate + rotationDays - 1 | Arbitraries.integers().between(1,60) |
| Rotation fairness | No platoon gets same section in consecutive cycles | @ForAll int cycles |
| Shift coverage | Every day, all 3 shifts (DAY/AFTERNOON/NIGHT) are covered | @ForAll LocalDate |
| Group division | groupA + groupB + groupC always = total personnel | @ForAll int totalSize |
| Leave overlap detection | Overlapping leaves are always caught | @ForAll date ranges |
| Cache key determinism | Same tool+params always produces same cache key | @ForAll Map<String,Object> |

### 4.3 Integration Test Categories

| Category | What's Tested | Database |
|----------|--------------|----------|
| Cycle CRUD | Full create/read/update/delete with DB | H2 or TestContainers PostgreSQL |
| Leave workflow | Submit → Approve/Reject → verify state | H2 |
| Personnel CRUD | Create with validation, update, soft-delete | H2 |
| Security | Endpoint access with different roles | MockMvc + @WithMockUser |
| Chat E2E | Message → LLM mock → tool execution → response | Mocked LLM |

---

## 5. Test Report Summary

### 5.1 Test Execution Results

| Layer | Tests | Pass | Fail | Skip | Coverage |
|-------|-------|------|------|------|----------|
| Backend Unit | 120+ | — | — | — | ~70% service layer |
| Backend Property | 30+ | — | — | — | Invariant coverage |
| Backend Integration | 50+ | — | — | — | Critical paths |
| Frontend Unit | 30+ | — | — | — | Service layer |
| Frontend Property | 10+ | — | — | — | Data transformations |
| **Total** | **240+** | — | — | — | — |

*Note: Actual pass/fail counts from latest test run not available in codebase analysis. Run `./gradlew test` and `npm run test` for current results.*

### 5.2 Critical Test Scenarios

| # | Scenario | Expected Result | Priority |
|---|----------|----------------|----------|
| 1 | Create cycle with overlapping dates | Throws IllegalStateException | P0 |
| 2 | Auto-reassign when no candidates | Returns failure message | P0 |
| 3 | Submit leave with duty conflicts | Creates leave + returns conflicts | P0 |
| 4 | Duplicate badge ID creation | Throws IllegalStateException | P0 |
| 5 | Prompt injection in chat | Returns sanitized error response | P0 |
| 6 | JWT expired token | Returns 401 | P0 |
| 7 | GENERAL_USER tries personnel delete | Returns 403 | P0 |
| 8 | Cycle soft-delete preserves data | Status=DELETED, mappings intact | P1 |
| 9 | Driver without required fields | Throws IllegalArgumentException | P1 |
| 10 | Cancel past leave | Throws IllegalStateException | P1 |

---

## 6. How to Run Tests

### 6.1 Backend

```bash
cd backend/

# Run all tests (Unit + Property + Integration)
./gradlew test

# Run with detailed output
./gradlew test --info

# Run specific test class
./gradlew test --tests "com.policescheduler.service.CycleServiceTest"

# Run only property-based tests
./gradlew test --tests "*Property*"
```

### 6.2 Frontend

```bash
cd frontend/

# Run all tests (single run, no watch mode)
npm run test

# Run with coverage
npx vitest --run --coverage
```

---

## 7. Test Data Management

### 7.1 Test Data Strategy

- **Unit tests:** Use in-memory mocks with controlled data
- **Integration tests:** Use @Sql annotations or DataInitializer for seed data
- **Property tests:** Generate random data via jqwik Arbitraries / fast-check

### 7.2 DataInitializer (Startup Seeding)

The `DataInitializer.java` class seeds initial data (sections, platoons, admin user) on application startup if tables are empty.

---

*End of Document — Test Strategy & Report v1.0.0*

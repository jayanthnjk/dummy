# Deployment Guide
## KSP WorkBoard — Police Station Management System

| Field | Details |
|-------|---------|
| **Document Title** | Deployment & Setup Guide |
| **Version** | 1.0.0 |
| **Date** | June 2026 |
| **Target Environment** | AWS (EC2 + S3 + CloudFront + RDS) |

---

## 1. Architecture Overview

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────┐
│   CloudFront    │────▶│   S3 Bucket      │     │  AWS Bedrock    │
│  (CDN + HTTPS)  │     │  (Frontend SPA)  │     │ (Amazon Nova    │
└────────┬────────┘     └──────────────────┘     │  Lite AI)       │
         │                                        └────────▲────────┘
         │ API requests (/api/*)                            │
         ▼                                                  │
┌─────────────────┐                               ┌────────┴────────┐
│   EC2 Instance  │───────────────────────────────▶│      RDS        │
│  (Spring Boot)  │                                │  (PostgreSQL    │
│  t3.medium      │                                │   + pgvector)   │
└─────────────────┘                                └─────────────────┘
```

---

## 2. Prerequisites

| Requirement | Specification |
|-------------|--------------|
| AWS Account | With MFA enabled, IAM admin user |
| EC2 Key Pair | ksp-key.pem (PEM format) |
| AWS CLI | Installed on local machine |
| Java 17 | Amazon Corretto 17 (installed via setup script) |
| PostgreSQL | RDS db.t3.micro or EC2-hosted with pgvector |
| S3 Bucket | For frontend static assets |
| CloudFront | HTTPS distribution pointing to S3 |
| EC2 IAM Role | ksp-ec2-role with Bedrock access |
| Budget Alerts | Configured to prevent cost overrun |

---

## 3. Environment Profiles

| Profile | Usage | AI Provider | Config Source |
|---------|-------|-------------|---------------|
| `local` | Developer laptop | Groq (free tier) | `.env` file |
| `prod` | AWS EC2 | AWS Bedrock (Nova Lite) | systemd env vars |

---

## 4. Local Development Setup

### 4.1 Database Setup

```bash
# Install PostgreSQL 15+ locally
# Create database
psql -U postgres -c "CREATE DATABASE ksp_workboard;"
psql -U postgres -d ksp_workboard -c "CREATE EXTENSION IF NOT EXISTS vector;"
psql -U postgres -d ksp_workboard -c "CREATE EXTENSION IF NOT EXISTS pg_trgm;"
```

### 4.2 Backend Setup

```bash
cd backend/

# Copy and configure environment
cp .env.example .env
# Edit .env with your values:
#   DB_URL=jdbc:postgresql://localhost:5432/ksp_workboard
#   DB_USERNAME=postgres
#   DB_PASSWORD=your_password
#   JWT_SECRET=your-local-jwt-secret-at-least-32-characters-long
#   AI_PROVIDER=groq
#   GROQ_API_KEY=your_key_from_console.groq.com

# Run the application
./gradlew bootRun
# Server starts on http://localhost:8080
```

### 4.3 Frontend Setup

```bash
cd frontend/

# Install dependencies
npm install

# Configure environment
cp .env.example .env
# Edit .env:
#   VITE_API_URL=http://localhost:8080

# Start dev server
npm run dev
# App runs on http://localhost:5173
```

### 4.4 Build Commands

```bash
# Backend: Build JAR
cd backend/
./gradlew clean build -x test
# Output: build/libs/ksp-workboard-0.0.1-SNAPSHOT.jar

# Frontend: Build production
cd frontend/
npm run build
# Output: dist/ folder
```

---

## 5. AWS Production Deployment

### 5.1 EC2 Instance Setup (One-Time)

```bash
# SSH into EC2
ssh -i ksp-key.pem ec2-user@<EC2-PUBLIC-IP>

# Run setup script (installs Java 17, PostgreSQL client, creates /opt/ksp)
bash setup-ec2.sh
```

**What setup-ec2.sh does:**
1. Updates system packages (`yum update`)
2. Installs Java 17 (Amazon Corretto)
3. Installs PostgreSQL 16 client
4. Creates `/opt/ksp/logs` directory
5. Installs CloudWatch agent
6. Installs Git

### 5.2 Systemd Service Configuration

```bash
# Copy service file to EC2
scp -i ksp-key.pem backend/deploy/aws/ksp-backend.service ec2-user@<EC2-IP>:~/

# On EC2: Install and configure
sudo cp ~/ksp-backend.service /etc/systemd/system/
sudo vi /etc/systemd/system/ksp-backend.service
# Replace all placeholder values (see Environment Variables section below)

# Enable and start
sudo systemctl daemon-reload
sudo systemctl enable ksp-backend
sudo systemctl start ksp-backend

# Verify
sudo systemctl status ksp-backend
sudo journalctl -u ksp-backend -f
```

### 5.3 Service File Environment Variables

```ini
# DATABASE
Environment=DB_URL=jdbc:postgresql://<RDS-ENDPOINT>:5432/ksp_workboard
Environment=DB_USERNAME=ksp_admin
Environment=DB_PASSWORD=<YOUR-RDS-PASSWORD>

# JWT (generate with: openssl rand -base64 48)
Environment=JWT_SECRET=<GENERATE-WITH-openssl-rand-base64-48>

# AI PROVIDER
Environment=AI_PROVIDER=bedrock
Environment=AWS_REGION=us-east-1
Environment=BEDROCK_MODEL_ID=amazon.nova-lite-v1:0

# CORS
Environment=CORS_ALLOWED_ORIGINS=https://<YOUR-CLOUDFRONT-DOMAIN>
```

### 5.4 JVM Configuration

```ini
ExecStart=/usr/bin/java -Xms256m -Xmx512m -jar /opt/ksp/ksp-workboard.jar --spring.profiles.active=prod
```

| Parameter | Value | Reasoning |
|-----------|-------|-----------|
| -Xms256m | Initial heap | Low memory start |
| -Xmx512m | Max heap | Suitable for t3.medium (4GB RAM) |
| --spring.profiles.active=prod | Production profile | Uses Bedrock AI |

---

## 6. Deploy Scripts

### 6.1 Full Deployment

```bash
# From local machine — deploys both backend and frontend
bash backend/deploy/aws/deploy.sh <EC2-PUBLIC-IP>
```

### 6.2 Backend Only (Java changes)

```bash
bash backend/deploy/aws/deploy-backend.sh <EC2-PUBLIC-IP>
```

**What it does:**
1. Runs `./gradlew clean build -x test`
2. SCPs JAR to EC2 at `/opt/ksp/ksp-workboard.jar`
3. Restarts systemd service

### 6.3 Frontend Only (UI changes)

```bash
bash backend/deploy/aws/deploy-frontend.sh
```

**What it does:**
1. Runs `npm run build` in frontend/
2. Syncs `dist/` to S3 bucket
3. Invalidates CloudFront cache

---

## 7. Infrastructure Components

### 7.1 Security Groups

| Group | Port | Source | Purpose |
|-------|------|--------|---------|
| ksp-backend-sg | 8080 | CloudFront/ALB | Backend API |
| ksp-backend-sg | 22 | Your IP | SSH access |
| ksp-db-sg | 5432 | ksp-backend-sg | DB from backend only |

### 7.2 IAM Role (ksp-ec2-role)

Policies attached:
- `AmazonBedrockFullAccess` — For AI model invocation
- `CloudWatchAgentServerPolicy` — For log monitoring

### 7.3 S3 Bucket Configuration

- Bucket name: `ksp-frontend-bucket` (or your choice)
- Static website hosting: Enabled
- Index document: `index.html`
- Error document: `index.html` (for SPA routing)
- Public access: Blocked (CloudFront only via OAC)

### 7.4 CloudFront Configuration

- Origin: S3 bucket (via OAC)
- Default root object: `index.html`
- Error pages: 403/404 → /index.html (200) for SPA routing
- HTTPS: Redirect HTTP to HTTPS
- Cache behavior: /api/* → EC2 origin

---

## 8. Monitoring & Operations

### 8.1 Health Checks

```bash
# System health
curl http://<EC2-IP>:8080/api/health
# Expected: {"status":"UP","aiProvider":"bedrock"}

# AI connectivity
curl http://<EC2-IP>:8080/api/health/ai
# Expected: {"connected":true,"provider":"bedrock"}
```

### 8.2 Log Access

```bash
# Real-time logs
sudo journalctl -u ksp-backend -f

# Last 100 lines
sudo journalctl -u ksp-backend -n 100

# Logs since today
sudo journalctl -u ksp-backend --since today
```

### 8.3 Service Management

```bash
sudo systemctl start ksp-backend    # Start
sudo systemctl stop ksp-backend     # Stop
sudo systemctl restart ksp-backend  # Restart
sudo systemctl status ksp-backend   # Status
```

---

## 9. Cost Estimate (Monthly)

| Service | Size | Estimated Cost |
|---------|------|----------------|
| EC2 (t3.medium) | 2 vCPU, 4GB RAM | ~$30/month |
| RDS (db.t3.micro) | 1 vCPU, 1GB RAM | Free tier / ~$15 |
| S3 + CloudFront | Static frontend | ~$1-2 |
| Bedrock (Nova Lite) | Per-token | ~$5-30 (usage dependent) |
| **Total** | | **~$50-80/month** |

---

## 10. Troubleshooting

| Issue | Check | Fix |
|-------|-------|-----|
| Service won't start | `journalctl -u ksp-backend -n 50` | Check env vars in service file |
| DB connection failed | Verify RDS endpoint and security group | Ensure ksp-db-sg allows 5432 from backend SG |
| AI not responding | `/api/health/ai` returns false | Check IAM role has Bedrock access |
| Frontend blank page | Check CloudFront invalidation | Run `aws cloudfront create-invalidation` |
| CORS errors | Check CORS_ALLOWED_ORIGINS | Must match exact CloudFront domain with https:// |

---

*End of Document — Deployment Guide v1.0.0*

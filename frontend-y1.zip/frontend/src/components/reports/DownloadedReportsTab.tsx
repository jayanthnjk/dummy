import React, { useState, useEffect, useCallback } from 'react';
import {
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  Paper,
  Button,
  TextField,
  MenuItem,
  CircularProgress,
  IconButton,
  alpha,
} from '@mui/material';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import SearchOffIcon from '@mui/icons-material/SearchOff';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import {
  reportService,
  ReportHistoryItem,
  ReportHistoryPage,
  ReportHistoryParams,
} from '@/services/reportService';

const PRIMARY = '#312e81';

const REPORT_TYPE_OPTIONS = [
  { value: '', label: 'All Types' },
  { value: 'section_ab', label: 'Platoon Chart A & B' },
  { value: 'platoon_chart', label: 'Platoon Chart C' },
  { value: 'form_168', label: 'Form 168' },
  { value: 'mt_section', label: 'MT Section' },
  { value: 'leave_statement', label: 'Leave Statement' },
  { value: 'personnel_list', label: 'Personnel List' },
  { value: 'adhoc_duty', label: 'Adhoc Duty' },
];

function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(i > 0 ? 1 : 0)} ${units[i]}`;
}

function formatDate(dateStr: string): string {
  try {
    return new Date(dateStr).toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return dateStr;
  }
}

const DownloadedReportsTab: React.FC = () => {
  const [data, setData] = useState<ReportHistoryPage | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [downloadingId, setDownloadingId] = useState<number | null>(null);

  // Filters
  const [reportType, setReportType] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');

  // Pagination
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params: ReportHistoryParams = {
        page,
        size: rowsPerPage,
      };
      if (reportType) params.reportType = reportType;
      if (fromDate) params.fromDate = fromDate;
      if (toDate) params.toDate = toDate;

      const result = await reportService.getReportHistory(params);
      setData(result);
    } catch (err) {
      console.error('Failed to fetch report history:', err);
      setError('Failed to load report history. Please try again.');
    } finally {
      setLoading(false);
    }
  }, [page, rowsPerPage, reportType, fromDate, toDate]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleDownload = async (id: number) => {
    setDownloadingId(id);
    try {
      await reportService.downloadStoredReport(id);
    } catch (err) {
      console.error('Download failed:', err);
    } finally {
      setDownloadingId(null);
    }
  };

  const handlePageChange = (_: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleRowsPerPageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  return (
    <Box>
      {/* Filters */}
      <Paper
        elevation={0}
        sx={{
          p: 2,
          mb: 3,
          borderRadius: 3,
          border: '1px solid',
          borderColor: 'divider',
          display: 'flex',
          gap: 2,
          flexWrap: 'wrap',
          alignItems: 'center',
        }}
      >
        <TextField
          select
          label="Report Type"
          value={reportType}
          onChange={(e) => { setReportType(e.target.value); setPage(0); }}
          size="small"
          sx={{ minWidth: 180 }}
        >
          {REPORT_TYPE_OPTIONS.map((opt) => (
            <MenuItem key={opt.value} value={opt.value}>
              {opt.label}
            </MenuItem>
          ))}
        </TextField>
        <TextField
          label="From Date"
          type="date"
          value={fromDate}
          onChange={(e) => { setFromDate(e.target.value); setPage(0); }}
          size="small"
          InputLabelProps={{ shrink: true }}
          sx={{ minWidth: 150 }}
        />
        <TextField
          label="To Date"
          type="date"
          value={toDate}
          onChange={(e) => { setToDate(e.target.value); setPage(0); }}
          size="small"
          InputLabelProps={{ shrink: true }}
          sx={{ minWidth: 150 }}
        />
      </Paper>

      {/* Content */}
      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
          <CircularProgress sx={{ color: PRIMARY }} />
        </Box>
      ) : error ? (
        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', py: 6, gap: 1 }}>
          <ErrorOutlineIcon sx={{ fontSize: 48, color: 'error.main' }} />
          <Typography color="error">{error}</Typography>
          <Button onClick={fetchData} variant="outlined" size="small" sx={{ mt: 1 }}>
            Retry
          </Button>
        </Box>
      ) : !data || data.content.length === 0 ? (
        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', py: 6, gap: 1 }}>
          <SearchOffIcon sx={{ fontSize: 48, color: 'text.disabled' }} />
          <Typography color="text.secondary">No reports found</Typography>
          <Typography variant="body2" color="text.disabled">
            Reports will appear here after they are generated.
          </Typography>
        </Box>
      ) : (
        <>
          <TableContainer
            component={Paper}
            elevation={0}
            sx={{ borderRadius: 3, border: '1px solid', borderColor: 'divider' }}
          >
            <Table size="small">
              <TableHead>
                <TableRow sx={{ bgcolor: alpha(PRIMARY, 0.04) }}>
                  <TableCell sx={{ fontWeight: 700, color: PRIMARY }}>Report Name</TableCell>
                  <TableCell sx={{ fontWeight: 700, color: PRIMARY }}>Type</TableCell>
                  <TableCell sx={{ fontWeight: 700, color: PRIMARY }}>Date Generated</TableCell>
                  <TableCell sx={{ fontWeight: 700, color: PRIMARY }}>Size</TableCell>
                  <TableCell sx={{ fontWeight: 700, color: PRIMARY }} align="center">Download</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {data.content.map((item: ReportHistoryItem) => (
                  <TableRow key={item.id} hover>
                    <TableCell>{item.reportName}</TableCell>
                    <TableCell>
                      <Typography
                        variant="caption"
                        sx={{
                          px: 1,
                          py: 0.25,
                          borderRadius: 1,
                          bgcolor: alpha(PRIMARY, 0.08),
                          color: PRIMARY,
                          fontWeight: 600,
                        }}
                      >
                        {item.reportType.replace(/_/g, ' ')}
                      </Typography>
                    </TableCell>
                    <TableCell>{formatDate(item.generatedAt)}</TableCell>
                    <TableCell>{formatFileSize(item.fileSize)}</TableCell>
                    <TableCell align="center">
                      <IconButton
                        size="small"
                        onClick={() => handleDownload(item.id)}
                        disabled={downloadingId === item.id}
                        sx={{ color: PRIMARY }}
                      >
                        {downloadingId === item.id ? (
                          <CircularProgress size={18} />
                        ) : (
                          <FileDownloadIcon fontSize="small" />
                        )}
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            component="div"
            count={data.totalElements}
            page={page}
            onPageChange={handlePageChange}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={handleRowsPerPageChange}
            rowsPerPageOptions={[5, 10, 25]}
          />
        </>
      )}
    </Box>
  );
};

export default DownloadedReportsTab;

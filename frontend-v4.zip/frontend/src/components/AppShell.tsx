import React, { useState } from 'react';
import { Box, Toolbar } from '@mui/material';
import TopNavBar from './TopNavBar';
import SideNavBar, { DRAWER_WIDTH, COLLAPSED_WIDTH } from './SideNavBar';

interface AppShellProps {
  children: React.ReactNode;
}

const AppShell: React.FC<AppShellProps> = ({ children }) => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);

  const currentWidth = collapsed ? COLLAPSED_WIDTH : DRAWER_WIDTH;

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', bgcolor: '#ffffff' }}>
      <TopNavBar onMenuToggle={() => setMobileOpen(o => !o)} drawerWidth={currentWidth} />
      <SideNavBar
        mobileOpen={mobileOpen}
        onClose={() => setMobileOpen(false)}
        collapsed={collapsed}
        onToggleCollapse={() => setCollapsed(c => !c)}
      />
      <Box component="main" sx={{
        flexGrow: 1,
        width: { md: `calc(100% - ${currentWidth}px)` },
        overflow: 'auto',
        bgcolor: '#ffffff',
        transition: 'width 0.2s ease',
      }}>
        <Toolbar variant="dense" sx={{ minHeight: 52 }} />
        {children}
      </Box>
    </Box>
  );
};

export default AppShell;

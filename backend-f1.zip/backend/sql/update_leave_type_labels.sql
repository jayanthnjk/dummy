-- =====================================================
-- SQL Script to rename leave type values in PostgreSQL
-- Run this to update stored leave_type values:
--   PRIVILEGE_LEAVE → PATERNITY_LEAVE
--   COMPENSATORY_OFF → COMMUTED_LEAVE
-- =====================================================

-- Update leave_requests table
UPDATE leave_requests
SET leave_type = 'PATERNITY_LEAVE'
WHERE leave_type = 'PRIVILEGE_LEAVE';

UPDATE leave_requests
SET leave_type = 'COMMUTED_LEAVE'
WHERE leave_type = 'COMPENSATORY_OFF';

-- Update duty_history table (if leave_type column has old values)
UPDATE duty_history
SET leave_type = 'PATERNITY_LEAVE'
WHERE leave_type = 'PRIVILEGE_LEAVE';

UPDATE duty_history
SET leave_type = 'COMMUTED_LEAVE'
WHERE leave_type = 'COMPENSATORY_OFF';

-- Verify changes
SELECT 'leave_requests' AS table_name, leave_type, COUNT(*) 
FROM leave_requests 
WHERE leave_type IN ('PATERNITY_LEAVE', 'COMMUTED_LEAVE', 'PRIVILEGE_LEAVE', 'COMPENSATORY_OFF')
GROUP BY leave_type
UNION ALL
SELECT 'duty_history' AS table_name, leave_type, COUNT(*) 
FROM duty_history 
WHERE leave_type IN ('PATERNITY_LEAVE', 'COMMUTED_LEAVE', 'PRIVILEGE_LEAVE', 'COMPENSATORY_OFF')
GROUP BY leave_type;

-- =====================================================
-- NOTES:
-- 1. This script is idempotent - safe to run multiple times
-- 2. If no rows are affected, it means no records with old values exist yet
-- 3. After running this, new records will be created with the new values
--    via application code changes
-- =====================================================

-- =====================================================
-- Create leave_types table and seed initial data
-- =====================================================

CREATE TABLE IF NOT EXISTS leave_types (
    id BIGSERIAL PRIMARY KEY,
    code VARCHAR(100) NOT NULL UNIQUE,
    display_name VARCHAR(200) NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Seed initial leave types
INSERT INTO leave_types (code, display_name, sort_order) VALUES
('CASUAL_LEAVE', 'CL (CASUAL LEAVE)', 1),
('COMMUTED_LEAVE', 'CML (COMMUTED LEAVE)', 2),
('PATERNITY_LEAVE', 'PL (PATERNITY LEAVE)', 3),
('EARNED_LEAVE', 'EL (EARNED LEAVE)', 4),
('ABSENT', 'ABSENT', 5),
('SUSPENSION', 'SUSPENSION', 6),
('PERMISSION', 'PERMISSION / RH TO RPI, RSI AND ARSI', 7),
('SICK_LEAVE', 'SICK', 8),
('WEEKLY_OFF', 'WEEKLY OFF', 9)
ON CONFLICT (code) DO UPDATE SET
    display_name = EXCLUDED.display_name,
    sort_order = EXCLUDED.sort_order,
    updated_at = CURRENT_TIMESTAMP;

-- Verify
SELECT * FROM leave_types ORDER BY sort_order;

-- =====================================================
-- Update users table: drop role constraint, add units column
-- =====================================================

-- Drop the role check constraint (allows any role value)
ALTER TABLE users DROP CONSTRAINT IF EXISTS users_role_check;

-- Add units column if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'users' AND column_name = 'units') THEN
        ALTER TABLE users ADD COLUMN units VARCHAR(100);
    END IF;
END $$;

-- Set default units for existing users
UPDATE users SET units = 'CAR,MT' WHERE role IN ('ADMIN', 'SUPPORT_ADMIN') AND units IS NULL;
UPDATE users SET units = 'CAR' WHERE role = 'GENERAL_USER' AND units IS NULL;
UPDATE users SET units = 'CAR,MT' WHERE role = 'HIGHER_OFFICER' AND units IS NULL;

-- Verify
SELECT id, username, role, units FROM users;

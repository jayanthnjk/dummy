import React, { useEffect, useState } from 'react';
import {
  Box,
  Chip,
  CircularProgress,
  MenuItem,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from '@mui/material';
import { cycleService, type CycleResponse, type CycleStatus } from '@/services/cycleService';

interface CycleListViewProps {
  /** Callback when a cycle row is clicked */
  onCycleSelect?: (cycleId: number) => void;
}

const STATUS_OPTIONS: { value: CycleStatus | 'ALL'; label: string }[] = [
  { value: 'ACTIVE', label: 'Active' },
  { value: 'COMPLETED', label: 'Completed' },
  { value: 'DELETED', label: 'Deleted' },
  { value: 'ALL', label: 'All' },
];

const STATUS_CHIP_COLORS: Record<CycleStatus, 'success' | 'info' | 'error'> = {
  ACTIVE: 'success',
  COMPLETED: 'info',
  DELETED: 'error',
};

/**
 * CycleListView — Displays a table of platoon rotation cycles with status filtering.
 * Fetches from GET /api/cycles and defaults to showing only ACTIVE cycles.
 */
const CycleListView: React.FC<CycleListViewProps> = ({ onCycleSelect }) => {
  const [cycles, setCycles] = useState<CycleResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<CycleStatus | 'ALL'>('ACTIVE');

  useEffect(() => {
    fetchCycles();
  }, [statusFilter]);

  const fetchCycles = async () => {
    setLoading(true);
    setError(null);
    try {
      const status = statusFilter === 'ALL' ? undefined : statusFilter;
      const data = await cycleService.getCycles(status);
      setCycles(data);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to load cycles';
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusFilterChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setStatusFilter(event.target.value as CycleStatus | 'ALL');
  };

  const handleRowClick = (cycleId: number) => {
    onCycleSelect?.(cycleId);
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <Box sx={{ width: '100%' }}>
      {/* Filter toolbar */}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
        <Typography variant="h6" fontWeight={600}>
          Rotation Cycles
        </Typography>
        <TextField
          select
          size="small"
          label="Status"
          value={statusFilter}
          onChange={handleStatusFilterChange}
          sx={{ minWidth: 160 }}
        >
          {STATUS_OPTIONS.map((option) => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </TextField>
      </Box>

      {/* Loading state */}
      {loading && (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
          <CircularProgress size={36} />
        </Box>
      )}

      {/* Error state */}
      {!loading && error && (
        <Typography color="error" sx={{ textAlign: 'center', py: 4 }}>
          {error}
        </Typography>
      )}

      {/* Empty state */}
      {!loading && !error && cycles.length === 0 && (
        <Box sx={{ textAlign: 'center', py: 6 }}>
          <Typography variant="body1" color="text.secondary">
            No cycles found.
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
            Create a new rotation cycle to get started.
          </Typography>
        </Box>
      )}

      {/* Data table */}
      {!loading && !error && cycles.length > 0 && (
        <TableContainer>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell sx={{ fontWeight: 600 }}>Start Date</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>End Date</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Rotation Days</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Status</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {cycles.map((cycle) => (
                <TableRow
                  key={cycle.id}
                  hover
                  onClick={() => handleRowClick(cycle.id)}
                  sx={{ cursor: onCycleSelect ? 'pointer' : 'default' }}
                >
                  <TableCell>{formatDate(cycle.startDate)}</TableCell>
                  <TableCell>{formatDate(cycle.endDate)}</TableCell>
                  <TableCell>{cycle.rotationDays}</TableCell>
                  <TableCell>
                    <Chip
                      label={cycle.status}
                      size="small"
                      color={STATUS_CHIP_COLORS[cycle.status]}
                      variant="outlined"
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </Box>
  );
};

export default CycleListView;

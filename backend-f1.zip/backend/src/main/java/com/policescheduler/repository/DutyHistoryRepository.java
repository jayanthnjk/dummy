package com.policescheduler.repository;

import com.policescheduler.entity.DutyHistory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

/**
 * Repository for DutyHistory entity.
 * Provides efficient queries for historical duty records.
 */
@Repository
public interface DutyHistoryRepository extends JpaRepository<DutyHistory, Long> {

    /**
     * Find history for a specific person within a date range.
     * Primary use case: "Show me person X's records from March to November"
     */
    List<DutyHistory> findByPersonIdAndRecordDateBetweenOrderByRecordDateDesc(
            Long personId, LocalDate startDate, LocalDate endDate);

    /**
     * Find history by badge ID within a date range.
     */
    List<DutyHistory> findByBadgeIdAndRecordDateBetweenOrderByRecordDateDesc(
            String badgeId, LocalDate startDate, LocalDate endDate);

    /**
     * Find all records for a specific date.
     */
    List<DutyHistory> findByRecordDate(LocalDate recordDate);

    /**
     * Find history by section within a date range.
     */
    List<DutyHistory> findBySectionAndRecordDateBetweenOrderByRecordDateDesc(
            String section, LocalDate startDate, LocalDate endDate);

    /**
     * Paginated query for a person's history.
     */
    Page<DutyHistory> findByPersonIdOrderByRecordDateDesc(Long personId, Pageable pageable);

    /**
     * Paginated query for a person's history within a date range.
     */
    @Query("SELECT dh FROM DutyHistory dh WHERE dh.personId = :personId " +
           "AND dh.recordDate BETWEEN :startDate AND :endDate ORDER BY dh.recordDate DESC")
    Page<DutyHistory> findByPersonIdAndDateRange(@Param("personId") Long personId,
                                                   @Param("startDate") LocalDate startDate,
                                                   @Param("endDate") LocalDate endDate,
                                                   Pageable pageable);

    /**
     * Count records for a specific date (to verify snapshot was taken).
     */
    long countByRecordDate(LocalDate recordDate);

    /**
     * Find persons on leave for a specific date range.
     */
    @Query("SELECT dh FROM DutyHistory dh WHERE dh.leaveType IS NOT NULL " +
           "AND dh.recordDate BETWEEN :startDate AND :endDate ORDER BY dh.recordDate DESC")
    List<DutyHistory> findLeaveRecords(@Param("startDate") LocalDate startDate,
                                        @Param("endDate") LocalDate endDate);

    /**
     * Find persons on adhoc duty for a specific date range.
     */
    @Query("SELECT dh FROM DutyHistory dh WHERE dh.adhocDuty IS NOT NULL " +
           "AND dh.recordDate BETWEEN :startDate AND :endDate ORDER BY dh.recordDate DESC")
    List<DutyHistory> findAdhocDutyRecords(@Param("startDate") LocalDate startDate,
                                            @Param("endDate") LocalDate endDate);

    /**
     * Roster query: find duty history records within a date range filtered by designation and unit.
     * Joins with personnel table to filter by unit (CAR/MT).
     */
    @Query("SELECT dh FROM DutyHistory dh WHERE dh.recordDate BETWEEN :startDate AND :endDate " +
           "AND (:designation IS NULL OR dh.designation = :designation) " +
           "AND dh.personId IN (SELECT p.id FROM Personnel p WHERE p.isActive = true " +
           "AND (:unit IS NULL OR p.unit = :unit)) " +
           "ORDER BY dh.personName ASC, dh.recordDate ASC")
    List<DutyHistory> findRosterData(@Param("startDate") LocalDate startDate,
                                      @Param("endDate") LocalDate endDate,
                                      @Param("designation") String designation,
                                      @Param("unit") String unit);
}

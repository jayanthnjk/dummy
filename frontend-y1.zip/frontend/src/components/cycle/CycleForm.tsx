import React, { useState, useMemo, useEffect } from 'react';
import {
  Alert,
  Box,
  Button,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  FormHelperText,
  InputLabel,
  MenuItem,
  Paper,
  Select,
  Stack,
  TextField,
  Typography,
  type SelectChangeEvent,
} from '@mui/material';
import AutoFixHighIcon from '@mui/icons-material/AutoFixHigh';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import { cycleService, type CycleCreateRequest, type PlatoonSectionMapping } from '@/services/cycleService';

/** Predefined platoons (I–V) mapped to their database IDs */
const PLATOONS = [
  { id: 1, name: 'Platoon I' },
  { id: 2, name: 'Platoon II' },
  { id: 3, name: 'Platoon III' },
  { id: 4, name: 'Platoon IV' },
  { id: 5, name: 'Platoon V' },
];

/** Sections C through G with their database IDs and descriptive names */
const SECTIONS = [
  { id: 3, name: 'Guard-I (Rotation)', code: 'C' },
  { id: 4, name: 'Guard-II (Rotation)', code: 'D' },
  { id: 5, name: 'Check Post Duty', code: 'E' },
  { id: 6, name: 'VIP Escorts / Prisoner Escort', code: 'F' },
  { id: 7, name: 'Striking Force / Follow Up', code: 'G' },
];

interface CycleFormProps {
  /** Whether the dialog is open */
  open: boolean;
  /** Called when the dialog should close */
  onClose: () => void;
  /** Called after a successful cycle creation (e.g. to refresh the list) */
  onSuccess: () => void;
}

/**
 * Calculates end date as startDate + rotationDays (calendar days difference).
 * Example: startDate=2026-07-16, rotationDays=15 → endDate=2026-07-31
 */
function calculateEndDate(startDate: string, rotationDays: number): string {
  if (!startDate || rotationDays < 1) return '';
  const start = new Date(startDate + 'T00:00:00');
  if (isNaN(start.getTime())) return '';
  const end = new Date(start);
  end.setDate(end.getDate() + rotationDays);
  // Use local date parts to avoid UTC timezone shift issues
  const year = end.getFullYear();
  const month = String(end.getMonth() + 1).padStart(2, '0');
  const day = String(end.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * CycleForm — MUI Dialog for creating a new platoon rotation cycle.
 *
 * Each platoon gets exactly ONE section (single select).
 * Once a section is selected for one platoon, it's removed from other platoons' options.
 * Includes "Auto Generate" button to pre-fill based on circular rotation pattern.
 *
 * Implements Requirements 1.1, 1.2, 1.4.
 */
const CycleForm: React.FC<CycleFormProps> = ({ open, onClose, onSuccess }) => {
  const [startDate, setStartDate] = useState('');
  const [rotationDays, setRotationDays] = useState<number | ''>('');
  // Each platoon maps to a single section ID (or 0 for unselected)
  const [platoonSections, setPlatoonSections] = useState<Record<number, number>>(
    () => Object.fromEntries(PLATOONS.map((p) => [p.id, 0])) as Record<number, number>,
  );
  const [submitting, setSubmitting] = useState(false);
  const [autoGenerating, setAutoGenerating] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);
  const [previousCycleInfo, setPreviousCycleInfo] = useState<{
    id: number;
    mappings: { platoonId: number; sectionIds: number[] }[];
  } | null>(null);

  // Validation 1: Next available date for overlap prevention
  const [minStartDate, setMinStartDate] = useState<string>('');
  const [dateOverlapError, setDateOverlapError] = useState<string | null>(null);

  // Validation 2: Previous platoon-section assignments for repeat warning
  const [previousPlatoonSections, setPreviousPlatoonSections] = useState<Record<number, number>>({});

  // Fetch next available date and previous assignments on dialog open
  useEffect(() => {
    if (open) {
      cycleService.getNextAvailableDate().then((data) => {
        setMinStartDate(data.nextAvailableDate);
        if (!startDate) setStartDate(data.nextAvailableDate);
      }).catch(() => {});

      cycleService.autoGenerateMappings().then((data) => {
        if (data.previousPlatoonSections) {
          setPreviousPlatoonSections(data.previousPlatoonSections);
        } else if (data.previousCycle) {
          const prevMap: Record<number, number> = {};
          data.previousCycle.mappings.forEach((m) => {
            prevMap[m.platoonId] = m.sectionIds[0];
          });
          setPreviousPlatoonSections(prevMap);
        }
      }).catch(() => {});
    }
  }, [open]);

  // Auto-calculated end date
  const endDate = useMemo(() => {
    if (!startDate || !rotationDays || rotationDays < 1) return '';
    return calculateEndDate(startDate, rotationDays);
  }, [startDate, rotationDays]);

  // Get all currently selected section IDs (to exclude from other dropdowns)
  const selectedSectionIds = useMemo(() => {
    return Object.values(platoonSections).filter((id) => id > 0);
  }, [platoonSections]);

  // Validation: each platoon must have a section selected
  const allPlatoonsHaveSections = useMemo(() => {
    return PLATOONS.every((p) => platoonSections[p.id] > 0);
  }, [platoonSections]);

  // Validate start date against min date for overlap detection (warning only)
  const handleStartDateChange = (newDate: string) => {
    setStartDate(newDate);
    if (minStartDate && newDate && newDate < minStartDate) {
      setDateOverlapError(`Warning: This date overlaps with an existing cycle. Next available: ${minStartDate}`);
    } else {
      setDateOverlapError(null);
    }
  };

  // Check if any platoon has the same section as its previous cycle (soft warning)
  const platoonSectionWarnings = useMemo(() => {
    const warnings: Record<number, string> = {};
    PLATOONS.forEach((p) => {
      const currentSection = platoonSections[p.id];
      const previousSection = previousPlatoonSections[p.id];
      if (currentSection > 0 && previousSection && currentSection === previousSection) {
        const sectionName = SECTIONS.find((s) => s.id === currentSection)?.name || `Section ${currentSection}`;
        warnings[p.id] = `${p.name} had ${sectionName} in the previous cycle. Consider choosing a different section.`;
      }
    });
    return warnings;
  }, [platoonSections, previousPlatoonSections]);

  // Form is valid when all fields are filled (overlap is a warning, not a blocker)
  const isFormValid = useMemo(() => {
    return (
      startDate !== '' &&
      rotationDays !== '' &&
      rotationDays >= 1 &&
      endDate !== '' &&
      allPlatoonsHaveSections
    );
  }, [startDate, rotationDays, endDate, allPlatoonsHaveSections]);

  const handleSectionChange = (platoonId: number) => (event: SelectChangeEvent<number>) => {
    const value = event.target.value as number;
    setPlatoonSections((prev) => ({ ...prev, [platoonId]: value }));
  };

  const handleReset = () => {
    setStartDate('');
    setRotationDays('');
    setPlatoonSections(
      Object.fromEntries(PLATOONS.map((p) => [p.id, 0])) as Record<number, number>,
    );
    setApiError(null);
    setPreviousCycleInfo(null);
    setDateOverlapError(null);
    setPreviousPlatoonSections({});
    setMinStartDate('');
  };

  const handleClose = () => {
    if (!submitting) {
      handleReset();
      onClose();
    }
  };

  const handleAutoGenerate = async () => {
    setAutoGenerating(true);
    setApiError(null);
    try {
      const data = await cycleService.autoGenerateMappings();
      // Pre-fill platoon-section dropdowns
      const newMappings: Record<number, number> = {};
      data.mappings.forEach((m) => {
        newMappings[m.platoonId] = m.sectionIds[0] || 0;
      });
      setPlatoonSections(newMappings);
      // Set default rotation days to 15
      if (!rotationDays) {
        setRotationDays(15);
      }
      // Store previous cycle info for display
      setPreviousCycleInfo(data.previousCycle);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to auto-generate mappings';
      setApiError(message);
    } finally {
      setAutoGenerating(false);
    }
  };

  const handleSubmit = async () => {
    if (!isFormValid) return;

    setSubmitting(true);
    setApiError(null);

    const requestBody: CycleCreateRequest = {
      startDate,
      rotationDays: rotationDays as number,
      platoonSections: PLATOONS.map<PlatoonSectionMapping>((p) => ({
        platoonId: p.id,
        sectionIds: [platoonSections[p.id]],
      })),
    };

    try {
      await cycleService.createCycle(requestBody);
      handleReset();
      onSuccess();
      onClose();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to create cycle';
      setApiError(message);
    } finally {
      setSubmitting(false);
    }
  };

  const getSectionNameById = (sectionId: number) => {
    const section = SECTIONS.find((s) => s.id === sectionId);
    return section ? section.name : `Section ${sectionId}`;
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      maxWidth="sm"
      fullWidth
      aria-labelledby="cycle-form-dialog-title"
    >
      <DialogTitle id="cycle-form-dialog-title">Create Rotation Cycle</DialogTitle>
      <DialogContent>
        <Stack spacing={2.5} sx={{ mt: 1 }}>
          {apiError && (
            <Alert severity="error" onClose={() => setApiError(null)}>
              {apiError}
            </Alert>
          )}

          {Object.keys(platoonSectionWarnings).length > 0 && (
            <Alert severity="warning" icon={<WarningAmberIcon />}>
              Some platoons are assigned the same section as their previous cycle. You can still submit, but consider rotating sections.
            </Alert>
          )}

          {/* Start Date */}
          <TextField
            label="Start Date"
            type="date"
            value={startDate}
            onChange={(e) => handleStartDateChange(e.target.value)}
            required
            fullWidth
            size="small"
            InputLabelProps={{ shrink: true }}
            helperText={dateOverlapError || (minStartDate ? `Earliest available (no overlap): ${minStartDate}` : undefined)}
            FormHelperTextProps={dateOverlapError ? { sx: { color: '#b45309' } } : undefined}
          />

          {/* Rotation Days */}
          <TextField
            label="Rotation Days"
            type="number"
            value={rotationDays}
            onChange={(e) => {
              const val = e.target.value;
              setRotationDays(val === '' ? '' : Math.max(1, parseInt(val, 10) || 1));
            }}
            required
            fullWidth
            size="small"
            inputProps={{ min: 1 }}
            helperText="Number of consecutive days for this rotation"
          />

          {/* End Date (read-only, auto-calculated) */}
          <TextField
            label="End Date"
            type="date"
            value={endDate}
            disabled
            fullWidth
            size="small"
            InputLabelProps={{ shrink: true }}
            helperText={endDate ? 'Start Date + Rotation Days' : 'Auto-calculated once Start Date and Rotation Days are set'}
          />

          {/* Previous Cycle Reference Card */}
          {previousCycleInfo && (
            <Paper
              variant="outlined"
              sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: '8px' }}
            >
              <Typography variant="caption" fontWeight={700} sx={{ color: '#6B7280', mb: 0.5, display: 'block' }}>
                Previous Cycle #{previousCycleInfo.id} Mappings (Reference)
              </Typography>
              <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                {previousCycleInfo.mappings.map((m) => (
                  <Typography key={m.platoonId} variant="caption" sx={{ color: '#374151' }}>
                    P{m.platoonId}→{getSectionNameById(m.sectionIds[0])}
                  </Typography>
                ))}
              </Box>
            </Paper>
          )}

          {/* Platoon-Section Assignments (Single Select with exclusion) */}
          <Box>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 0.5 }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                Platoon Section Assignments
              </Typography>
              <Button
                size="small"
                variant="outlined"
                startIcon={
                  autoGenerating ? (
                    <CircularProgress size={14} color="inherit" />
                  ) : (
                    <AutoFixHighIcon sx={{ fontSize: 16 }} />
                  )
                }
                onClick={handleAutoGenerate}
                disabled={autoGenerating || submitting}
                sx={{
                  textTransform: 'none',
                  fontWeight: 600,
                  fontSize: '0.75rem',
                  borderRadius: 2,
                }}
              >
                {autoGenerating ? 'Generating...' : 'Auto Generate'}
              </Button>
            </Box>
            <Typography variant="caption" color="text.secondary" sx={{ mb: 1.5, display: 'block' }}>
              Assign one section to each platoon. Each section can only be assigned once.
            </Typography>

            <Stack spacing={1.5}>
              {PLATOONS.map((platoon) => {
                const currentValue = platoonSections[platoon.id] || 0;
                const hasError = currentValue === 0;
                const sectionWarning = platoonSectionWarnings[platoon.id];

                // Available sections: not yet assigned to another platoon
                const availableSections = SECTIONS.filter(
                  (s) => s.id === currentValue || !selectedSectionIds.includes(s.id),
                );

                // Section that was assigned to this platoon in the previous cycle
                const prevSection = previousPlatoonSections[platoon.id];

                return (
                  <FormControl key={platoon.id} fullWidth size="small" error={hasError}>
                    <InputLabel id={`platoon-${platoon.id}-label`}>
                      {platoon.name}
                    </InputLabel>
                    <Select
                      labelId={`platoon-${platoon.id}-label`}
                      value={currentValue || ''}
                      onChange={handleSectionChange(platoon.id)}
                      label={platoon.name}
                    >
                      {availableSections.map((section) => (
                        <MenuItem
                          key={section.id}
                          value={section.id}
                          sx={section.id === prevSection ? { color: '#b45309', fontStyle: 'italic' } : undefined}
                        >
                          {section.name}{section.id === prevSection ? ' (was in previous cycle)' : ''}
                        </MenuItem>
                      ))}
                    </Select>
                    {hasError && (
                      <FormHelperText>Select a section</FormHelperText>
                    )}
                    {sectionWarning && (
                      <FormHelperText sx={{ color: '#b45309', display: 'flex', alignItems: 'center', gap: 0.5 }}>
                        <WarningAmberIcon sx={{ fontSize: 14 }} />
                        {sectionWarning}
                      </FormHelperText>
                    )}
                  </FormControl>
                );
              })}
            </Stack>
          </Box>
        </Stack>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={handleClose} disabled={submitting}>
          Cancel
        </Button>
        <Button
          variant="contained"
          onClick={handleSubmit}
          disabled={!isFormValid || submitting}
          startIcon={submitting ? <CircularProgress size={16} color="inherit" /> : undefined}
        >
          {submitting ? 'Creating...' : 'Create Cycle'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default CycleForm;

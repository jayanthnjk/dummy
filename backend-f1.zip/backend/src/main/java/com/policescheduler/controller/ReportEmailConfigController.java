package com.policescheduler.controller;

import com.policescheduler.dto.AvailableReportDTO;
import com.policescheduler.dto.ReportEmailConfigDTO;
import com.policescheduler.dto.ReportSpecificEmailConfigDTO;
import com.policescheduler.service.ReportEmailConfigService;
import com.policescheduler.service.ScheduledReportService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * REST Controller for Report Email Configuration.
 * Provides endpoints for managing both Generate Reports Configuration
 * and Report Specific Email Configuration.
 * 
 * All endpoints require authentication and are restricted to admin users
 * through the security configuration.
 */
@RestController
@RequestMapping("/api/admin/report-email-config")
public class ReportEmailConfigController {

    private static final Logger log = LoggerFactory.getLogger(ReportEmailConfigController.class);

    private final ReportEmailConfigService reportEmailConfigService;
    private final ScheduledReportService scheduledReportService;

    public ReportEmailConfigController(ReportEmailConfigService reportEmailConfigService,
                                       ScheduledReportService scheduledReportService) {
        this.reportEmailConfigService = reportEmailConfigService;
        this.scheduledReportService = scheduledReportService;
    }

    // ─── Available Reports ───────────────────────────────────────────────

    /**
     * Get list of all available reports in the application.
     * Used to populate report selection dropdowns.
     */
    @GetMapping("/available-reports")
    public ResponseEntity<List<AvailableReportDTO>> getAvailableReports() {
        return ResponseEntity.ok(reportEmailConfigService.getAvailableReports());
    }

    // ─── Generate Reports Configuration Endpoints ────────────────────────

    /**
     * Get all Generate Reports configurations.
     */
    @GetMapping("/generate")
    public ResponseEntity<List<ReportEmailConfigDTO>> getAllReportEmailConfigs() {
        return ResponseEntity.ok(reportEmailConfigService.getAllReportEmailConfigs());
    }

    /**
     * Get a specific Generate Reports configuration by ID.
     */
    @GetMapping("/generate/{id}")
    public ResponseEntity<ReportEmailConfigDTO> getReportEmailConfigById(@PathVariable Long id) {
        return reportEmailConfigService.getReportEmailConfigById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Create a new Generate Reports configuration.
     */
    @PostMapping("/generate")
    public ResponseEntity<?> createReportEmailConfig(
            @RequestBody ReportEmailConfigDTO dto,
            Authentication authentication) {
        try {
            String username = authentication != null ? authentication.getName() : "system";
            ReportEmailConfigDTO created = reportEmailConfigService.createReportEmailConfig(dto, username);
            return ResponseEntity.status(HttpStatus.CREATED).body(created);
        } catch (IllegalArgumentException e) {
            log.warn("Validation error creating report email config: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Update an existing Generate Reports configuration.
     */
    @PutMapping("/generate/{id}")
    public ResponseEntity<?> updateReportEmailConfig(
            @PathVariable Long id,
            @RequestBody ReportEmailConfigDTO dto,
            Authentication authentication) {
        try {
            String username = authentication != null ? authentication.getName() : "system";
            ReportEmailConfigDTO updated = reportEmailConfigService.updateReportEmailConfig(id, dto, username);
            return ResponseEntity.ok(updated);
        } catch (IllegalArgumentException e) {
            log.warn("Error updating report email config #{}: {}", id, e.getMessage());
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Delete a Generate Reports configuration.
     */
    @DeleteMapping("/generate/{id}")
    public ResponseEntity<?> deleteReportEmailConfig(
            @PathVariable Long id,
            Authentication authentication) {
        try {
            String username = authentication != null ? authentication.getName() : "system";
            reportEmailConfigService.deleteReportEmailConfig(id, username);
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException e) {
            log.warn("Error deleting report email config #{}: {}", id, e.getMessage());
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    // ─── Report Specific Email Configuration Endpoints ───────────────────

    /**
     * Get all Report Specific Email configurations.
     */
    @GetMapping("/specific")
    public ResponseEntity<List<ReportSpecificEmailConfigDTO>> getAllReportSpecificEmailConfigs() {
        return ResponseEntity.ok(reportEmailConfigService.getAllReportSpecificEmailConfigs());
    }

    /**
     * Get a specific Report Specific Email configuration by ID.
     */
    @GetMapping("/specific/{id}")
    public ResponseEntity<ReportSpecificEmailConfigDTO> getReportSpecificEmailConfigById(@PathVariable Long id) {
        return reportEmailConfigService.getReportSpecificEmailConfigById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Get Report Specific Email configuration by report type.
     */
    @GetMapping("/specific/by-type/{reportType}")
    public ResponseEntity<ReportSpecificEmailConfigDTO> getReportSpecificEmailConfigByType(
            @PathVariable String reportType) {
        return reportEmailConfigService.getReportSpecificEmailConfigByReportType(reportType)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Create a new Report Specific Email configuration.
     */
    @PostMapping("/specific")
    public ResponseEntity<?> createReportSpecificEmailConfig(
            @RequestBody ReportSpecificEmailConfigDTO dto,
            Authentication authentication) {
        try {
            String username = authentication != null ? authentication.getName() : "system";
            ReportSpecificEmailConfigDTO created = reportEmailConfigService.createReportSpecificEmailConfig(dto, username);
            return ResponseEntity.status(HttpStatus.CREATED).body(created);
        } catch (IllegalArgumentException e) {
            log.warn("Validation error creating report specific email config: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Update an existing Report Specific Email configuration.
     */
    @PutMapping("/specific/{id}")
    public ResponseEntity<?> updateReportSpecificEmailConfig(
            @PathVariable Long id,
            @RequestBody ReportSpecificEmailConfigDTO dto,
            Authentication authentication) {
        try {
            String username = authentication != null ? authentication.getName() : "system";
            ReportSpecificEmailConfigDTO updated = reportEmailConfigService.updateReportSpecificEmailConfig(id, dto, username);
            return ResponseEntity.ok(updated);
        } catch (IllegalArgumentException e) {
            log.warn("Error updating report specific email config #{}: {}", id, e.getMessage());
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Delete a Report Specific Email configuration.
     */
    @DeleteMapping("/specific/{id}")
    public ResponseEntity<?> deleteReportSpecificEmailConfig(
            @PathVariable Long id,
            Authentication authentication) {
        try {
            String username = authentication != null ? authentication.getName() : "system";
            reportEmailConfigService.deleteReportSpecificEmailConfig(id, username);
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException e) {
            log.warn("Error deleting report specific email config #{}: {}", id, e.getMessage());
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    // ─── Email Content for Reports ───────────────────────────────────────

    /**
     * Get email content (subject and body) for a specific report type.
     * Returns configured values from report_specific_email_config if available,
     * otherwise returns default values.
     * 
     * Default subject: Report Name
     * Default body: "Please find attached report for {Report Name} dated {date}.\n\nThanks and Regards"
     * 
     * @param reportType The report type code (e.g., form_168, platoon_chart)
     * @param date The date to include in the email body (format: dd-MM-yyyy)
     */
    @GetMapping("/email-content/{reportType}")
    public ResponseEntity<Map<String, String>> getEmailContentForReport(
            @PathVariable String reportType,
            @RequestParam(required = false) String date) {
        String effectiveDate = date != null ? date : java.time.LocalDate.now()
                .format(java.time.format.DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        
        ReportEmailConfigService.ReportEmailContent content = 
                reportEmailConfigService.getEmailContentForReport(reportType, effectiveDate);
        
        return ResponseEntity.ok(Map.of(
                "subject", content.getSubject(),
                "body", content.getBody()
        ));
    }

    // ─── Scheduled Report Test Endpoints ─────────────────────────────────

    /**
     * Manually trigger all scheduled reports for testing.
     * This bypasses the schedule check and processes all enabled reports immediately.
     */
    @PostMapping("/scheduled/trigger-all")
    public ResponseEntity<Map<String, String>> triggerAllScheduledReports(Authentication authentication) {
        String username = authentication != null ? authentication.getName() : "system";
        log.info("Manual trigger of all scheduled reports requested by {}", username);
        scheduledReportService.triggerAllScheduledReports();
        return ResponseEntity.ok(Map.of("message", "All scheduled reports triggered successfully"));
    }

    /**
     * Manually trigger a specific report by type for testing.
     * This bypasses the schedule check and processes the specific report immediately.
     */
    @PostMapping("/scheduled/trigger/{reportType}")
    public ResponseEntity<Map<String, String>> triggerReportByType(
            @PathVariable String reportType,
            Authentication authentication) {
        String username = authentication != null ? authentication.getName() : "system";
        log.info("Manual trigger of report {} requested by {}", reportType, username);
        scheduledReportService.triggerReportByType(reportType);
        return ResponseEntity.ok(Map.of("message", "Report " + reportType + " triggered successfully"));
    }
}

import React, { useState } from 'react';
import {
  Box, Typography, Paper, Button, Grid, CircularProgress, alpha,
} from '@mui/material';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import GridOnIcon from '@mui/icons-material/GridOn';
import DescriptionIcon from '@mui/icons-material/Description';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import DirectionsCarIcon from '@mui/icons-material/DirectionsCar';
import EventBusyIcon from '@mui/icons-material/EventBusy';
import SecurityIcon from '@mui/icons-material/Security';
import AssignmentIcon from '@mui/icons-material/Assignment';

import { useTranslation } from 'react-i18next';
import api from '@/services/api';

const PRIMARY = '#1a1e4a';

interface ReportCard {
  title: string;
  description: string;
  endpoint: string;
  filename: string;
  excelEndpoint?: string;
  excelFilename?: string;
  icon: React.ReactNode;
  color: string;
}

const ReportsPage: React.FC = () => {
  const { t } = useTranslation();
  const [downloading, setDownloading] = useState<string | null>(null);

  const reports: ReportCard[] = [
    {
      title: t('reports.platoonChartA', 'Platoon Chart A - Static Duties'),
      description: t('reports.platoonChartADesc', 'Section A personnel list with duty assignments and designation counts'),
      endpoint: '/api/reports/section-a',
      filename: 'section-a-report.pdf',
      excelEndpoint: '/api/reports/section-a/excel',
      excelFilename: 'section-a.xlsx',
      icon: <SecurityIcon />,
      color: '#3b82f6',
    },
    {
      title: t('reports.platoonChartB', 'Platoon Chart B - Semi-Static'),
      description: t('reports.platoonChartBDesc', 'Section B personnel list with duty assignments and designation counts'),
      endpoint: '/api/reports/section-b',
      filename: 'section-b-report.pdf',
      excelEndpoint: '/api/reports/section-b/excel',
      excelFilename: 'section-b.xlsx',
      icon: <AssignmentIcon />,
      color: '#8b5cf6',
    },
    {
      title: t('reports.platoonChartC', 'Platoon Chart C - Rotational Duties'),
      description: t('reports.platoonChartCDesc', 'Combined Section C, D, E, F, G platoon rotation chart with badge IDs'),
      endpoint: '/api/reports/platoon-chart',
      filename: 'platoon-chart.pdf',
      excelEndpoint: '/api/reports/platoon-chart/excel',
      excelFilename: 'section-c.xlsx',
      icon: <CalendarMonthIcon />,
      color: '#059669',
    },
    {
      title: t('reports.dailyStatement', 'Daily Statement (Form 168)'),
      description: t('reports.dailyStatementDesc', 'Official daily strength and duty abstract report with designation breakdown'),
      endpoint: '/api/reports/form-168',
      filename: 'form-168.pdf',
      excelEndpoint: '/api/reports/form-168/excel',
      excelFilename: 'daily-statement.xlsx',
      icon: <DescriptionIcon />,
      color: '#e8722a',
    },
    {
      title: t('reports.mtSection', 'MT Section (Drivers)'),
      description: t('reports.mtSectionDesc', 'CAR Motor Transport section with driver details, vehicle numbers, PDMS status'),
      endpoint: '/api/reports/mt-section',
      filename: 'mt-section-report.pdf',
      excelEndpoint: '/api/reports/mt-section/excel',
      excelFilename: 'mt-section.xlsx',
      icon: <DirectionsCarIcon />,
      color: '#0891b2',
    },
    {
      title: t('reports.leaveStatement', 'Leave Statement'),
      description: t('reports.leaveStatementDesc', 'Leave request summary with status, type, dates, and personnel details'),
      endpoint: '/api/reports/leave-statement',
      filename: 'leave-statement.pdf',
      excelEndpoint: '/api/reports/leave-statement/excel',
      excelFilename: 'leave-statement.xlsx',
      icon: <EventBusyIcon />,
      color: '#7c3aed',
    },
  ];

  const handleDownload = async (report: ReportCard) => {
    setDownloading(report.endpoint);
    try {
      const response = await api.get(report.endpoint, { responseType: 'blob' });
      const contentDisposition = response.headers['content-disposition'];
      let serverFilename = report.filename;
      if (contentDisposition) {
        const match = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
        if (match && match[1]) {
          serverFilename = match[1].replace(/['"]/g, '');
        }
      }
      const url = window.URL.createObjectURL(response.data);
      const link = document.createElement('a');
      link.href = url;
      link.download = serverFilename;
      link.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Download failed:', error);
    } finally {
      setDownloading(null);
    }
  };

  const handleExcelDownload = async (report: ReportCard) => {
    if (!report.excelEndpoint || !report.excelFilename) return;
    setDownloading(report.excelEndpoint);
    try {
      const response = await api.get(report.excelEndpoint, { responseType: 'blob' });
      const contentDisposition = response.headers['content-disposition'];
      let serverFilename = report.excelFilename;
      if (contentDisposition) {
        const match = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
        if (match && match[1]) {
          serverFilename = match[1].replace(/['"]/g, '');
        }
      }
      const url = window.URL.createObjectURL(response.data);
      const link = document.createElement('a');
      link.href = url;
      link.download = serverFilename;
      link.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Excel download failed:', error);
    } finally {
      setDownloading(null);
    }
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', backgroundColor: '#F8FAFC' }}>
      {/* Dark Navy Page Header */}
      <Box
        sx={{
          background: 'linear-gradient(135deg, #1a1e4a 0%, #2d3561 100%)',
          color: 'white',
          px: { xs: 2, md: 4 },
          pt: 2,
          pb: 1.5,
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
          <Box>
            <Typography variant="h5" fontWeight={700} sx={{ letterSpacing: '-0.02em' }}>
              {t('reports.title', 'Reports')}
            </Typography>
            <Typography variant="body2" sx={{ color: 'rgba(255,255,255,0.7)', mt: 0.5 }}>
              {t('reports.subtitle', 'Download official reports and documents. All reports are generated from live data.')}
            </Typography>
          </Box>
        </Box>
      </Box>

      {/* Main Content */}
      <Box sx={{ flex: 1, p: { xs: 2, md: 4 }, maxWidth: 1200, mx: 'auto', width: '100%' }}>
        <Grid container spacing={3}>
        {reports.map((report) => (
          <Grid item xs={12} sm={6} md={4} key={report.endpoint}>
            <Paper
              elevation={0}
              sx={{
                p: 3,
                borderRadius: 3,
                border: '1px solid',
                borderColor: 'divider',
                height: '100%',
                display: 'flex',
                flexDirection: 'column',
                transition: 'all 0.2s ease',
                '&:hover': {
                  borderColor: report.color,
                  boxShadow: `0 4px 20px ${alpha(report.color, 0.15)}`,
                  transform: 'translateY(-2px)',
                },
              }}
            >
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 2 }}>
                <Box sx={{
                  width: 40, height: 40, borderRadius: 2,
                  bgcolor: alpha(report.color, 0.1),
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  color: report.color,
                }}>
                  {report.icon}
                </Box>
                <Typography variant="subtitle1" sx={{ fontWeight: 700, color: PRIMARY }}>
                  {report.title}
                </Typography>
              </Box>

              <Typography variant="body2" sx={{ color: 'text.secondary', mb: 3, flexGrow: 1 }}>
                {report.description}
              </Typography>

              {report.excelEndpoint ? (
                <Box sx={{ display: 'flex', gap: 1 }}>
                  <Button
                    variant="outlined"
                    startIcon={downloading === report.endpoint ? <CircularProgress size={16} /> : <PictureAsPdfIcon />}
                    disabled={!!downloading}
                    onClick={() => handleDownload(report)}
                    sx={{
                      borderRadius: 2,
                      textTransform: 'none',
                      fontWeight: 600,
                      borderColor: report.color,
                      color: report.color,
                      '&:hover': {
                        bgcolor: alpha(report.color, 0.08),
                        borderColor: report.color,
                      },
                    }}
                  >
                    {downloading === report.endpoint ? t('reports.generating', 'Generating...') : t('reports.pdf', 'PDF')}
                  </Button>
                  <Button
                    variant="outlined"
                    startIcon={downloading === report.excelEndpoint ? <CircularProgress size={16} /> : <GridOnIcon />}
                    disabled={!!downloading}
                    onClick={() => handleExcelDownload(report)}
                    sx={{
                      borderRadius: 2,
                      textTransform: 'none',
                      fontWeight: 600,
                      borderColor: report.color,
                      color: report.color,
                      '&:hover': {
                        bgcolor: alpha(report.color, 0.08),
                        borderColor: report.color,
                      },
                    }}
                  >
                    {downloading === report.excelEndpoint ? t('reports.generating', 'Generating...') : t('reports.excel', 'Excel')}
                  </Button>
                </Box>
              ) : (
                <Button
                  variant="outlined"
                  startIcon={downloading === report.endpoint ? <CircularProgress size={16} /> : <FileDownloadIcon />}
                  disabled={downloading === report.endpoint}
                  onClick={() => handleDownload(report)}
                  sx={{
                    borderRadius: 2,
                    textTransform: 'none',
                    fontWeight: 600,
                    borderColor: report.color,
                    color: report.color,
                    '&:hover': {
                      bgcolor: alpha(report.color, 0.08),
                      borderColor: report.color,
                    },
                  }}
                >
                  {downloading === report.endpoint ? t('reports.generating', 'Generating...') : t('reports.downloadPdf', 'Download PDF')}
                </Button>
              )}
            </Paper>
          </Grid>
        ))}
      </Grid>
      </Box>
    </Box>
  );
};

export default ReportsPage;
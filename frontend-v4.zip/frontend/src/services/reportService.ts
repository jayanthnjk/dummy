import api from './api';

const downloadBlob = (data: Blob, filename: string) => {
  const url = window.URL.createObjectURL(data);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.click();
  window.URL.revokeObjectURL(url);
};

export const reportService = {
  downloadForm168: async (date?: string) => {
    const response = await api.get('/api/reports/form-168', {
      params: date ? { date } : undefined,
      responseType: 'blob',
    });
    downloadBlob(response.data, `form-168-${date || 'today'}.pdf`);
  },

  downloadPersonnelReport: async () => {
    const response = await api.get('/api/reports/personnel', { responseType: 'blob' });
    downloadBlob(response.data, 'personnel-report.pdf');
  },

  downloadSectionAReport: async () => {
    const response = await api.get('/api/reports/section-a', { responseType: 'blob' });
    downloadBlob(response.data, 'section-a-report.pdf');
  },

  downloadSectionBReport: async () => {
    const response = await api.get('/api/reports/section-b', { responseType: 'blob' });
    downloadBlob(response.data, 'section-b-report.pdf');
  },

  downloadSectionAExcel: async () => {
    const response = await api.get('/api/reports/section-a/excel', { responseType: 'blob' });
    downloadBlob(response.data, 'section-a.xlsx');
  },

  downloadSectionBExcel: async () => {
    const response = await api.get('/api/reports/section-b/excel', { responseType: 'blob' });
    downloadBlob(response.data, 'section-b.xlsx');
  },

  downloadPlatoonChart: async () => {
    const response = await api.get('/api/reports/platoon-chart', { responseType: 'blob' });
    downloadBlob(response.data, 'platoon-chart.pdf');
  },

  downloadPlatoonChartExcel: async () => {
    const response = await api.get('/api/reports/platoon-chart/excel', { responseType: 'blob' });
    downloadBlob(response.data, 'section-c.xlsx');
  },

  downloadMtSection: async () => {
    const response = await api.get('/api/reports/mt-section', { responseType: 'blob' });
    downloadBlob(response.data, 'mt-section-report.pdf');
  },

  downloadLeaveStatement: async () => {
    const response = await api.get('/api/reports/leave-statement', { responseType: 'blob' });
    downloadBlob(response.data, 'leave-statement.pdf');
  },

  // Keep backward-compatible aliases
  downloadScheduleReport: async () => {
    const response = await api.get('/api/reports/schedules', { responseType: 'blob' });
    downloadBlob(response.data, 'schedule-report.pdf');
  },

  downloadLeaveReport: async () => {
    const response = await api.get('/api/reports/leave-requests', { responseType: 'blob' });
    downloadBlob(response.data, 'leave-report.pdf');
  },
};

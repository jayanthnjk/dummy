import api from './api';

// ─── Types ───────────────────────────────────────────────────────────────────

export interface AvailableReport {
  reportType: string;
  reportName: string;
  description: string;
}

export interface ReportEmailConfig {
  id?: number;
  subjectTitle?: string;  // Auto-populated from report_specific_email_config
  emailIds: string[];
  emailBody?: string;     // Auto-populated from report_specific_email_config
  selectedReports: string[];
  isActive?: boolean;
  createdAt?: string;
  updatedAt?: string;
  createdBy?: string;
  updatedBy?: string;
}

export interface ReportSpecificEmailConfig {
  id?: number;
  reportType: string;
  reportName: string;
  emailSubject: string;
  emailBody: string;
  scheduleDays?: string[];    // Days: SUN, MON, TUE, WED, THU, FRI, SAT
  scheduleTime?: string;      // Time in HH:mm format (24-hour)
  isScheduleEnabled?: boolean; // Whether scheduling is enabled
  createdAt?: string;
  updatedAt?: string;
  createdBy?: string;
  updatedBy?: string;
}

// ─── Available Reports API ───────────────────────────────────────────────────

export const getAvailableReports = async (): Promise<AvailableReport[]> => {
  const response = await api.get<AvailableReport[]>('/api/admin/report-email-config/available-reports');
  return response.data;
};

// ─── Generate Reports Configuration API ──────────────────────────────────────

export const getAllReportEmailConfigs = async (): Promise<ReportEmailConfig[]> => {
  const response = await api.get<ReportEmailConfig[]>('/api/admin/report-email-config/generate');
  return response.data;
};

export const getReportEmailConfigById = async (id: number): Promise<ReportEmailConfig> => {
  const response = await api.get<ReportEmailConfig>(`/api/admin/report-email-config/generate/${id}`);
  return response.data;
};

export const createReportEmailConfig = async (config: ReportEmailConfig): Promise<ReportEmailConfig> => {
  const response = await api.post<ReportEmailConfig>('/api/admin/report-email-config/generate', config);
  return response.data;
};

export const updateReportEmailConfig = async (id: number, config: ReportEmailConfig): Promise<ReportEmailConfig> => {
  const response = await api.put<ReportEmailConfig>(`/api/admin/report-email-config/generate/${id}`, config);
  return response.data;
};

export const deleteReportEmailConfig = async (id: number): Promise<void> => {
  await api.delete(`/api/admin/report-email-config/generate/${id}`);
};

// ─── Report Specific Email Configuration API ─────────────────────────────────

export const getAllReportSpecificEmailConfigs = async (): Promise<ReportSpecificEmailConfig[]> => {
  const response = await api.get<ReportSpecificEmailConfig[]>('/api/admin/report-email-config/specific');
  return response.data;
};

export const getReportSpecificEmailConfigById = async (id: number): Promise<ReportSpecificEmailConfig> => {
  const response = await api.get<ReportSpecificEmailConfig>(`/api/admin/report-email-config/specific/${id}`);
  return response.data;
};

export const getReportSpecificEmailConfigByType = async (reportType: string): Promise<ReportSpecificEmailConfig> => {
  const response = await api.get<ReportSpecificEmailConfig>(`/api/admin/report-email-config/specific/by-type/${reportType}`);
  return response.data;
};

export const createReportSpecificEmailConfig = async (config: ReportSpecificEmailConfig): Promise<ReportSpecificEmailConfig> => {
  const response = await api.post<ReportSpecificEmailConfig>('/api/admin/report-email-config/specific', config);
  return response.data;
};

export const updateReportSpecificEmailConfig = async (id: number, config: ReportSpecificEmailConfig): Promise<ReportSpecificEmailConfig> => {
  const response = await api.put<ReportSpecificEmailConfig>(`/api/admin/report-email-config/specific/${id}`, config);
  return response.data;
};

export const deleteReportSpecificEmailConfig = async (id: number): Promise<void> => {
  await api.delete(`/api/admin/report-email-config/specific/${id}`);
};

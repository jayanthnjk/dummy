import api from './api';
import type { LoginRequest, AuthResponse, ChangePasswordRequest } from '@/types';

export const authService = {
  login: (data: LoginRequest) =>
    api.post<AuthResponse>('/api/auth/login', data).then((r) => r.data),

  logout: () =>
    api.post<void>('/api/auth/logout'),

  changePassword: (data: ChangePasswordRequest) =>
    api.post<void>('/api/auth/change-password', data),

  forgotPasswordRequest: (email: string) =>
    api.post<{ message: string }>('/api/auth/forgot-password/request', { email }).then(r => r.data),

  forgotPasswordVerifyOtp: (email: string, otp: string) =>
    api.post<{ resetToken: string }>('/api/auth/forgot-password/verify-otp', { email, otp }).then(r => r.data),

  forgotPasswordReset: (resetToken: string, newPassword: string) =>
    api.post<{ message: string }>('/api/auth/forgot-password/reset', { resetToken, newPassword }).then(r => r.data),
};

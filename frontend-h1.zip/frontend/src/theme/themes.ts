import { createTheme, alpha } from '@mui/material/styles';
import { scaleIn, slideInFromBottom } from './animations';

/*
 * CAR WorkBoard — 2025/2026 Award-Winning Enterprise Design System
 * ==================================================================
 * Color Palette:
 * - Primary Indigo:  #312e81 (main), #4338ca (light), #1e1b4b (dark)
 * - Accent Teal:     #0d9488 (main), #14b8a6 (light), #0f766e (dark)
 * - Background:      #f8fafc (page), #ffffff (cards/paper)
 * - Surface:         #f1f5f9 (subtle), #e2e8f0 (borders)
 * - Text:            #0f172a (primary), #334155 (secondary), #94a3b8 (muted)
 * - Success: #059669, Error: #e11d48, Warning: #d97706, Info: #2563eb
 * - Gradient header: linear-gradient(135deg, #312e81 0%, #4338ca 50%, #0d9488 100%)
 *
 * Typography: Inter/system fonts, tight letter-spacing, clear hierarchy
 * Spacing: 8px base unit, consistent padding/margin
 * Border Radius: 10px (buttons), 14px (cards), 20px (dialogs)
 */

const PRIMARY = '#312e81';
const PRIMARY_LIGHT = '#4338ca';
const PRIMARY_DARK = '#1e1b4b';
const ACCENT = '#0d9488';
const ACCENT_LIGHT = '#14b8a6';
const ACCENT_DARK = '#0f766e';
const BG_PAGE = '#f8fafc';
const BG_PAPER = '#ffffff';
const BORDER = '#e2e8f0';
const BORDER_SUBTLE = '#f1f5f9';
const TEXT_PRIMARY = '#0f172a';
const TEXT_SECONDARY = '#334155';
const TEXT_MUTED = '#94a3b8';

export const lightTheme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: PRIMARY,
      light: PRIMARY_LIGHT,
      dark: PRIMARY_DARK,
      contrastText: '#ffffff',
    },
    secondary: {
      main: ACCENT,
      light: ACCENT_LIGHT,
      dark: ACCENT_DARK,
      contrastText: '#ffffff',
    },
    background: {
      default: BG_PAGE,
      paper: BG_PAPER,
    },
    text: {
      primary: TEXT_PRIMARY,
      secondary: TEXT_SECONDARY,
      disabled: TEXT_MUTED,
    },
    divider: BORDER,
    error: { main: '#e11d48', light: '#fff1f2', dark: '#9f1239' },
    warning: { main: '#d97706', light: '#fffbeb', dark: '#92400e' },
    success: { main: '#059669', light: '#ecfdf5', dark: '#065f46' },
    info: { main: '#2563eb', light: '#eff6ff', dark: '#1e40af' },
    action: {
      hover: alpha(PRIMARY, 0.04),
      selected: alpha(PRIMARY, 0.08),
      focus: alpha(ACCENT, 0.12),
    },
    status: {
      active: { main: '#059669', contrastText: '#ecfdf5' },
      cancelled: { main: '#e11d48', contrastText: '#fff1f2' },
      completed: { main: '#334155', contrastText: '#f1f5f9' },
      pending: { main: '#2563eb', contrastText: '#eff6ff' },
      onLeave: { main: '#d97706', contrastText: '#fffbeb' },
    },
  },
  breakpoints: {
    values: {
      xs: 0,
      sm: 600,
      md: 900,
      lg: 1200,
      xl: 1536,
      compact: 1100,
    },
  },
  typography: {
    fontFamily: '"Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    h4: { fontWeight: 700, letterSpacing: '-0.025em', fontSize: '1.75rem' },
    h5: { fontWeight: 700, letterSpacing: '-0.02em', fontSize: '1.35rem' },
    h6: { fontWeight: 600, letterSpacing: '-0.015em', fontSize: '1.1rem' },
    subtitle1: { fontWeight: 600, fontSize: '0.95rem', letterSpacing: '-0.01em' },
    subtitle2: { fontWeight: 600, fontSize: '0.85rem', letterSpacing: '-0.005em' },
    body1: { fontSize: '0.875rem', lineHeight: 1.6, letterSpacing: '-0.01em' },
    body2: { fontSize: '0.8rem', lineHeight: 1.5, letterSpacing: '-0.005em' },
    caption: { fontSize: '0.72rem', color: TEXT_MUTED, letterSpacing: '0.01em' },
    button: { textTransform: 'none' as const, fontWeight: 600, fontSize: '0.82rem', letterSpacing: '-0.005em' },
  },
  shape: {
    borderRadius: 10,
  },
  shadows: [
    'none',
    '0 1px 3px rgba(15,23,42,0.04)',
    '0 1px 3px rgba(15,23,42,0.06), 0 1px 2px rgba(15,23,42,0.04)',
    '0 4px 8px -2px rgba(15,23,42,0.06), 0 2px 4px -2px rgba(15,23,42,0.04)',
    '0 8px 16px -4px rgba(15,23,42,0.08), 0 4px 6px -4px rgba(15,23,42,0.04)',
    '0 8px 24px -4px rgba(15,23,42,0.10), 0 6px 12px -6px rgba(15,23,42,0.06)',
    ...Array(19).fill('none'),
  ] as any,
  components: {
    MuiCssBaseline: {
      styleOverrides: {
        html: {
          zoom: 0.88,
        },
        body: {
          backgroundColor: BG_PAGE,
          WebkitFontSmoothing: 'antialiased',
          MozOsxFontSmoothing: 'grayscale',
          cursor: 'default',
        },
        'input, textarea, [contenteditable]': {
          cursor: 'text',
        },
        '@media (prefers-reduced-motion: reduce)': {
          '*, *::before, *::after': {
            animationDuration: '0.01ms !important',
            animationIterationCount: '1 !important',
            transitionDuration: '0.01ms !important',
            scrollBehavior: 'auto !important',
          },
        },
      },
    },
    MuiButton: {
      defaultProps: {
        disableElevation: true,
      },
      styleOverrides: {
        root: {
          borderRadius: 10,
          padding: '8px 18px',
          fontSize: '0.82rem',
          fontWeight: 600,
          letterSpacing: '-0.005em',
          transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
          '&:focus-visible': {
            outline: `2px solid ${PRIMARY}`,
            outlineOffset: '2px',
          },
        },
        contained: {
          background: `linear-gradient(135deg, ${PRIMARY} 0%, ${PRIMARY_LIGHT} 100%)`,
          color: '#ffffff',
          boxShadow: `0 2px 8px ${alpha(PRIMARY, 0.25)}`,
          '&:hover': {
            background: `linear-gradient(135deg, ${PRIMARY_DARK} 0%, ${PRIMARY} 100%)`,
            color: '#ffffff',
            boxShadow: `0 4px 16px ${alpha(PRIMARY, 0.35)}`,
            transform: 'translateY(-1px)',
          },
          '&.MuiButton-containedPrimary': {
            color: '#ffffff',
          },
          '&.MuiButton-containedSecondary': {
            color: '#ffffff',
          },
        },
        outlined: {
          borderColor: BORDER,
          color: TEXT_PRIMARY,
          backdropFilter: 'blur(8px)',
          backgroundColor: alpha(BG_PAPER, 0.6),
          '&:hover': {
            borderColor: ACCENT,
            backgroundColor: alpha(ACCENT, 0.04),
            boxShadow: `0 0 0 3px ${alpha(ACCENT, 0.08)}`,
          },
        },
        text: {
          color: TEXT_SECONDARY,
          '&:hover': {
            backgroundColor: alpha(PRIMARY, 0.04),
          },
        },
        sizeSmall: {
          padding: '5px 14px',
          fontSize: '0.78rem',
          borderRadius: 8,
        },
      },
    },
    MuiIconButton: {
      styleOverrides: {
        root: {
          borderRadius: 10,
          transition: 'all 0.2s ease',
          '&:hover': {
            backgroundColor: alpha(ACCENT, 0.08),
            transform: 'scale(1.05)',
          },
          '&:focus-visible': {
            outline: `2px solid ${PRIMARY}`,
            outlineOffset: '2px',
          },
        },
      },
    },
    MuiPaper: {
      defaultProps: {
        elevation: 0,
      },
      styleOverrides: {
        root: {
          borderRadius: 14,
          border: `1px solid ${BORDER}`,
          backgroundImage: 'none',
          transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
        },
        elevation0: {
          boxShadow: 'none',
        },
        elevation1: {
          boxShadow: '0 1px 3px rgba(15,23,42,0.06), 0 1px 2px rgba(15,23,42,0.04)',
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 14,
          border: `1px solid ${BORDER}`,
          boxShadow: '0 1px 3px rgba(15,23,42,0.04)',
          transition: 'all 0.25s cubic-bezier(0.4, 0, 0.2, 1)',
          '&:hover': {
            boxShadow: `0 8px 24px ${alpha(PRIMARY, 0.08)}`,
            borderColor: alpha(ACCENT, 0.25),
            transform: 'translateY(-2px)',
          },
        },
      },
    },
    MuiTextField: {
      defaultProps: {
        size: 'small' as const,
      },
      styleOverrides: {
        root: {
          '& .MuiOutlinedInput-root': {
            borderRadius: 10,
            backgroundColor: BG_PAGE,
            transition: 'all 0.2s ease',
            '& fieldset': {
              borderColor: BORDER,
              transition: 'all 0.2s ease',
            },
            '&:hover fieldset': {
              borderColor: alpha(ACCENT, 0.5),
            },
            '&.Mui-focused': {
              backgroundColor: BG_PAPER,
              boxShadow: `0 0 0 3px ${alpha(ACCENT, 0.12)}`,
              '& fieldset': {
                borderColor: ACCENT,
                borderWidth: 1.5,
              },
            },
          },
          '& .MuiInputLabel-root': {
            fontSize: '0.82rem',
            fontWeight: 500,
            '&.Mui-focused': {
              color: ACCENT,
            },
          },
        },
      },
    },
    MuiSelect: {
      styleOverrides: {
        root: {
          borderRadius: 10,
          fontSize: '0.82rem',
        },
      },
    },
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          borderRadius: 10,
          '& fieldset': {
            borderColor: BORDER,
            transition: 'all 0.2s ease',
          },
          '&:hover fieldset': {
            borderColor: alpha(ACCENT, 0.5),
          },
          '&.Mui-focused': {
            boxShadow: `0 0 0 3px ${alpha(ACCENT, 0.12)}`,
            '& fieldset': {
              borderColor: ACCENT,
              borderWidth: 1.5,
            },
          },
        },
      },
    },
    MuiTableContainer: {
      styleOverrides: {
        root: {
          borderRadius: 14,
          border: `1px solid ${BORDER}`,
          overflow: 'hidden',
        },
      },
    },
    MuiTableHead: {
      styleOverrides: {
        root: {
          backgroundColor: BORDER_SUBTLE,
          position: 'sticky' as const,
          top: 0,
          zIndex: 1,
          '& .MuiTableCell-head': {
            fontWeight: 600,
            fontSize: '0.75rem',
            textTransform: 'uppercase',
            letterSpacing: '0.05em',
            color: TEXT_SECONDARY,
            borderBottom: `1px solid ${BORDER}`,
            padding: '12px 16px',
            backgroundColor: BORDER_SUBTLE,
          },
        },
      },
    },
    MuiTableBody: {
      styleOverrides: {
        root: {
          '& .MuiTableRow-root': {
            transition: 'background-color 0.15s ease',
            '&:nth-of-type(even)': {
              backgroundColor: alpha(BORDER_SUBTLE, 0.5),
            },
            '&:hover': {
              backgroundColor: alpha(ACCENT, 0.04),
            },
            '&:last-child td': {
              borderBottom: 'none',
            },
          },
          '& .MuiTableCell-body': {
            fontSize: '0.82rem',
            padding: '10px 16px',
            borderBottom: `1px solid ${BORDER_SUBTLE}`,
            color: TEXT_PRIMARY,
          },
        },
      },
    },
    MuiTablePagination: {
      styleOverrides: {
        root: {
          borderTop: `1px solid ${BORDER}`,
          '& .MuiTablePagination-selectLabel, & .MuiTablePagination-displayedRows': {
            fontSize: '0.78rem',
            color: TEXT_SECONDARY,
          },
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: {
          borderRadius: 50,
          fontWeight: 500,
          fontSize: '0.72rem',
          height: 24,
          transition: 'all 0.15s ease',
        },
        sizeSmall: {
          height: 22,
          fontSize: '0.68rem',
        },
        colorSuccess: {
          backgroundColor: '#ecfdf5',
          color: '#059669',
          border: '1px solid #a7f3d0',
        },
        colorError: {
          backgroundColor: '#fff1f2',
          color: '#e11d48',
          border: '1px solid #fecdd3',
        },
        colorWarning: {
          backgroundColor: '#fffbeb',
          color: '#d97706',
          border: '1px solid #fde68a',
        },
        colorInfo: {
          backgroundColor: '#eff6ff',
          color: '#2563eb',
          border: '1px solid #bfdbfe',
        },
      },
    },
    MuiDialog: {
      styleOverrides: {
        root: {
          '& .MuiBackdrop-root': {
            backdropFilter: 'blur(4px)',
            backgroundColor: alpha(PRIMARY_DARK, 0.4),
          },
        },
        paper: {
          borderRadius: 20,
          border: 'none',
          boxShadow: '0 25px 50px -12px rgba(15,23,42,0.2)',
          animation: `${scaleIn} 250ms cubic-bezier(0.4, 0, 0.2, 1)`,
        },
      },
    },
    MuiDialogTitle: {
      styleOverrides: {
        root: {
          fontWeight: 700,
          fontSize: '1.1rem',
          padding: '20px 24px 12px',
          letterSpacing: '-0.015em',
        },
      },
    },
    MuiDialogContent: {
      styleOverrides: {
        root: {
          padding: '12px 24px 20px',
        },
      },
    },
    MuiDialogActions: {
      styleOverrides: {
        root: {
          padding: '12px 24px 20px',
          gap: 8,
        },
      },
    },
    MuiAppBar: {
      styleOverrides: {
        root: {
          backgroundColor: BG_PAPER,
          boxShadow: `0 1px 0 ${BORDER}`,
          color: TEXT_PRIMARY,
          backdropFilter: 'blur(8px)',
        },
      },
    },
    MuiDrawer: {
      styleOverrides: {
        root: {
          '& .MuiDrawer-paper': {
            transition: 'width 250ms cubic-bezier(0.4, 0, 0.2, 1)',
          },
        },
        paper: {
          backgroundColor: alpha(BG_PAPER, 0.85),
          backdropFilter: 'blur(16px)',
          borderRight: 'none',
          boxShadow: `1px 0 0 ${BORDER_SUBTLE}`,
        },
      },
    },
    MuiTab: {
      styleOverrides: {
        root: {
          textTransform: 'none',
          fontWeight: 500,
          fontSize: '0.85rem',
          minHeight: 44,
          color: TEXT_SECONDARY,
          transition: 'all 0.2s ease',
          '&.Mui-selected': {
            fontWeight: 700,
            color: ACCENT_DARK,
          },
        },
      },
    },
    MuiTabs: {
      styleOverrides: {
        indicator: {
          backgroundColor: ACCENT,
          height: 2.5,
          borderRadius: 2,
        },
      },
    },
    MuiAlert: {
      styleOverrides: {
        root: {
          borderRadius: 10,
          fontSize: '0.82rem',
          border: '1px solid',
        },
        standardSuccess: {
          backgroundColor: '#ecfdf5',
          color: '#065f46',
          borderColor: '#a7f3d0',
          '& .MuiAlert-icon': { color: '#059669' },
        },
        standardError: {
          backgroundColor: '#fff1f2',
          color: '#9f1239',
          borderColor: '#fecdd3',
          '& .MuiAlert-icon': { color: '#e11d48' },
        },
        standardWarning: {
          backgroundColor: '#fffbeb',
          color: '#92400e',
          borderColor: '#fde68a',
          '& .MuiAlert-icon': { color: '#d97706' },
        },
        standardInfo: {
          backgroundColor: '#eff6ff',
          color: '#1e40af',
          borderColor: '#bfdbfe',
          '& .MuiAlert-icon': { color: '#2563eb' },
        },
      },
    },
    MuiTooltip: {
      styleOverrides: {
        tooltip: {
          backgroundColor: PRIMARY_DARK,
          fontSize: '0.72rem',
          fontWeight: 500,
          borderRadius: 8,
          padding: '6px 12px',
          boxShadow: '0 4px 12px rgba(15,23,42,0.2)',
        },
      },
    },
    MuiSnackbar: {
      defaultProps: {
        anchorOrigin: { vertical: 'bottom', horizontal: 'right' },
      },
      styleOverrides: {
        root: {
          '&.MuiSnackbar-root': {
            animation: `${slideInFromBottom} 300ms ease-out`,
          },
          '&.MuiSnackbar-root.MuiSnackbar-anchorOriginBottomRight': {
            animation: `${slideInFromBottom} 300ms ease-out`,
          },
        },
      },
    },
    MuiLinearProgress: {
      styleOverrides: {
        root: {
          borderRadius: 6,
          height: 4,
          backgroundColor: alpha(ACCENT, 0.12),
        },
        bar: {
          borderRadius: 6,
          background: `linear-gradient(90deg, ${ACCENT} 0%, ${ACCENT_LIGHT} 100%)`,
        },
      },
    },
    MuiListItem: {
      styleOverrides: {
        root: {
          transition: 'height 200ms ease-in-out, opacity 200ms ease-in-out, background-color 150ms ease',
          overflow: 'hidden',
          '&.MuiListItem-entering': {
            opacity: 0,
            maxHeight: 0,
          },
          '&.MuiListItem-entered': {
            opacity: 1,
            maxHeight: 200,
          },
          '&.MuiListItem-exiting': {
            opacity: 0,
            maxHeight: 0,
          },
        },
      },
    },
    MuiSkeleton: {
      styleOverrides: {
        root: {
          borderRadius: 8,
        },
      },
    },
    MuiSwitch: {
      styleOverrides: {
        root: {
          '& .MuiSwitch-switchBase.Mui-checked': {
            color: ACCENT,
            '& + .MuiSwitch-track': {
              backgroundColor: ACCENT,
            },
          },
        },
      },
    },
    MuiFab: {
      styleOverrides: {
        root: {
          borderRadius: 14,
          boxShadow: `0 4px 14px ${alpha(PRIMARY, 0.25)}`,
        },
      },
    },
    MuiTable: {
      styleOverrides: {
        root: {
          borderCollapse: 'separate',
          borderSpacing: 0,
        },
      },
    },
    MuiAvatar: {
      styleOverrides: {
        root: {
          fontWeight: 600,
          fontSize: '0.85rem',
          background: `linear-gradient(135deg, ${PRIMARY} 0%, ${ACCENT} 100%)`,
          color: '#ffffff',
        },
      },
    },
    MuiBreadcrumbs: {
      styleOverrides: {
        root: {
          fontSize: '0.82rem',
          color: TEXT_SECONDARY,
          '& .MuiBreadcrumbs-separator': {
            marginLeft: 6,
            marginRight: 6,
            color: TEXT_MUTED,
          },
          '& .MuiBreadcrumbs-li a': {
            color: TEXT_SECONDARY,
            textDecoration: 'none',
            transition: 'color 0.15s ease',
            '&:hover': {
              color: ACCENT,
            },
          },
        },
      },
    },
  },
});

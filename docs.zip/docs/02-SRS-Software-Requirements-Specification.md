# Software Requirements Specification (SRS)
## KSP WorkBoard — Police Station Management System

| Field | Details |
|-------|---------|
| **Document Title** | Software Requirements Specification (SRS) |
| **Application Name** | KSP WorkBoard |
| **Version** | 1.0.0 |
| **Date** | June 2026 |
| **Based On** | BRD v1.0.0 |
| **Standard** | IEEE 830-1998 (Modified) |
| **Status** | Final |

---

## 1. Introduction

### 1.1 Purpose

This Software Requirements Specification (SRS) document provides a complete, detailed, and unambiguous description of all software requirements for the KSP WorkBoard system. It defines the functional behavior of every module, API endpoint, validation rule, error handling path, and user interface interaction — derived strictly from the implemented codebase.

This document serves as the technical contract between the development team and stakeholders, and forms the basis for system testing, validation, and future maintenance.

### 1.2 Scope

KSP WorkBoard is a web-based police station management system consisting of:
- **Frontend**: React 19 Single Page Application (SPA) with Material UI 6
- **Backend**: Spring Boot 3.4.4 REST API with PostgreSQL persistence
- **AI Layer**: LLM-powered chat interface with MCP tool execution architecture

The system covers: Authentication, Personnel Management, Duty Type/Section Management, Platoon Cycle Management, Duty Assignment Engine, Leave Management, Adhoc Duty Management, AI Chat Interface, Report Generation, Schedule Visualization, Internationalization, and System Administration.

### 1.3 Definitions, Acronyms, and Abbreviations

| Term | Definition |
|------|-----------|
| API | Application Programming Interface |
| CRUD | Create, Read, Update, Delete |
| DTO | Data Transfer Object |
| FK | Foreign Key |
| JPA | Java Persistence API |
| JWT | JSON Web Token |
| LLM | Large Language Model |
| MCP | Model Context Protocol |
| PK | Primary Key |
| RAG | Retrieval-Augmented Generation |
| REST | Representational State Transfer |
| SPA | Single Page Application |
| STT | Speech-to-Text |

### 1.4 References

| Document | Description |
|----------|-------------|
| BRD v1.0.0 | Business Requirements Document for KSP WorkBoard |
| IEEE 830-1998 | Recommended Practice for Software Requirements Specifications |
| Spring Boot 3.4.4 Docs | Framework reference documentation |
| PostgreSQL 15 Docs | Database reference documentation |

### 1.5 Document Organization

This SRS is organized by functional module. Each module contains:
- Detailed functional specifications with exact API contracts
- Request/Response payload schemas
- Validation rules with exact error messages
- State transitions and business logic
- Error handling specifications
- Security constraints

---

## 2. Overall Description

### 2.1 Product Perspective

KSP WorkBoard is a standalone system deployed on AWS EC2 (backend) and S3/CloudFront (frontend). It integrates with external AI providers (Groq API for development, AWS Bedrock for production) for natural language processing capabilities.

### 2.2 Product Functions Summary

```mermaid
graph LR
    subgraph "Core Functions"
        A[Authentication]
        B[Personnel CRUD]
        C[Schedule Management]
        D[Leave Workflow]
        E[Cycle Management]
        F[Adhoc Duties]
        G[Reports]
        H[AI Chat]
    end

    subgraph "Supporting Functions"
        I[Duty Type Config]
        J[Section Config]
        K[i18n]
        L[Audit Logging]
        M[Health Monitoring]
    end

    A --> B
    A --> C
    A --> D
    A --> E
    A --> F
    A --> G
    A --> H
    H --> B
    H --> D
    H --> E
    H --> F
    H --> G
```

### 2.3 User Classes and Characteristics

| User Class | Technical Proficiency | Primary Interaction Mode | Frequency |
|-----------|----------------------|--------------------------|-----------|
| ADMIN | High | Web UI + Chat | Daily |
| HIGHER_OFFICER | Medium | Web UI + Chat | Daily |
| GENERAL_USER | Low-Medium | Chat (Voice/Text) | Daily |

### 2.4 Operating Environment

| Component | Specification |
|-----------|--------------|
| Server OS | Linux (Amazon Linux 2 / Ubuntu 22.04) |
| Runtime | Java 17 (JDK) |
| Database | PostgreSQL 15+ with pgvector extension |
| Frontend Hosting | Static files served via Nginx / S3+CloudFront |
| Browser Support | Chrome 90+, Firefox 90+, Safari 15+, Edge 90+ |
| Network | HTTPS required for production |

### 2.5 Design and Implementation Constraints

| Constraint | Detail |
|-----------|--------|
| Language | Java 17 (backend), TypeScript (frontend) |
| Framework | Spring Boot 3.4.4 |
| Database | PostgreSQL only (Hibernate dialect locked) |
| Authentication | JWT only (no OAuth/SAML) |
| AI Provider | Must support OpenAI-compatible tool calling format |
| File Size | Max 10MB for uploads |
| Session | Stateless (no server-side session storage) |

---

## 3. Specific Requirements

### 3.1 Module SRS-AUTH: Authentication & Authorization

#### SRS-AUTH-01: Login

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `POST /api/auth/login` |
| **Access** | Public (no authentication required) |
| **Content-Type** | application/json |

**Request Payload:**
```json
{
  "username": "string (required, max 100 chars)",
  "password": "string (required)",
  "loginType": "string (optional)"
}
```

**Success Response (HTTP 200):**
```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9...",
  "role": "ADMIN | HIGHER_OFFICER | GENERAL_USER",
  "displayName": "Officer Name",
  "locale": "en | kn"
}
```

**Validation Rules:**
1. Username must not be null or blank
2. Password must not be null or blank
3. Username must exist in `users` table
4. BCrypt password hash must match

**Error Responses:**
| Condition | HTTP Status | Response |
|-----------|-------------|----------|
| Invalid credentials | 401 | `{"error": {"code": "AUTH_FAILED", "message": "Invalid credentials"}}` |
| Missing username | 400 | Validation error |
| Missing password | 400 | Validation error |

**Processing Logic:**
1. Validate request body (@Valid annotation)
2. Look up user by username in `users` table
3. Compare password against stored BCrypt hash using PasswordEncoder
4. Generate JWT token with claims: subject=username, role=role, expiration=current+86400000ms
5. Return AuthResponse with token, role, displayName, locale

---

#### SRS-AUTH-02: Logout

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `POST /api/auth/logout` |
| **Access** | Authenticated |
| **Headers** | Authorization: Bearer {token} |

**Success Response (HTTP 200):**
```json
{
  "message": "Logged out successfully"
}
```

**Processing Logic:**
1. Extract token from Authorization header (strip "Bearer " prefix)
2. Call authService.logout(token) — token invalidation
3. Return success message

---

#### SRS-AUTH-03: Change Password

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `POST /api/auth/change-password` |
| **Access** | Authenticated |

**Request Payload:**
```json
{
  "oldPassword": "string (required)",
  "newPassword": "string (required)"
}
```

**Success Response (HTTP 200):**
```json
{
  "message": "Password changed successfully"
}
```

**Validation Rules:**
1. Old password must match current stored hash
2. New password must not be null or blank
3. Authenticated user identity from JWT token

**Error Responses:**
| Condition | HTTP Status | Response |
|-----------|-------------|----------|
| Old password mismatch | 400 | Error message |
| User not found | 404 | Error message |

---

#### SRS-AUTH-04: JWT Token Specification

| Parameter | Value | Source |
|-----------|-------|--------|
| Algorithm | HS256 | JJWT library |
| Secret | Environment variable `JWT_SECRET` | application.yml |
| Expiration | 86400000 ms (24 hours) | `app.jwt.expiration-ms` |
| Claims | subject (username), role, issued-at, expiration | JwtAuthFilter |

**Token Validation (JwtAuthFilter):**
1. Extract Authorization header
2. Verify "Bearer " prefix
3. Parse and validate JWT signature
4. Check expiration
5. Extract username from claims
6. Load user from database
7. Set SecurityContext authentication

---

#### SRS-AUTH-05: Security Filter Chain

| Order | Filter | Purpose |
|-------|--------|---------|
| 1 | JwtAuthFilter | Token validation and authentication |
| 2 | PiiFilter | PII access logging |

**Endpoint Security Rules:**
| Pattern | Method | Access |
|---------|--------|--------|
| `/api/auth/login` | POST | permitAll |
| `/api/health/**` | ANY | permitAll |
| `/api/admin/**` | ANY | ROLE_ADMIN |
| `/api/schedules/platoons/rotate` | POST | ROLE_ADMIN |
| All other | ANY | authenticated |

**CORS Configuration:**
| Setting | Value |
|---------|-------|
| Allowed Origins | `CORS_ALLOWED_ORIGINS` env var (default: http://localhost:5173) |
| Allowed Methods | GET, POST, PUT, DELETE, OPTIONS |
| Allowed Headers | * (all) |
| Allow Credentials | true |
| Exposed Headers | Content-Disposition |
| Max Age | 3600 seconds |

---

### 3.2 Module SRS-PERSONNEL: Personnel Management

#### SRS-PERSONNEL-01: List Personnel

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `GET /api/personnel` |
| **Access** | Authenticated |
| **Pagination** | Spring Pageable (default size=20) |

**Query Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| search | String | No | Full-text search across: badgeId, personName, dutyType, location, phoneNumber, email, designation, section |
| section | String | No | Exact match filter on section field |
| dutyType | String | No | Case-insensitive exact match on dutyType |
| designation | String | No | Exact match filter on designation |
| isActive | Boolean | No | Filter active/inactive personnel |
| page | Integer | No | Page number (0-indexed, default: 0) |
| size | Integer | No | Page size (default: 20) |
| sort | String | No | Sort field and direction (e.g., personName,asc) |

**Success Response (HTTP 200):**
```json
{
  "content": [
    {
      "id": 1,
      "badgeId": "AHC-2649",
      "personName": "Jayanth Kumar",
      "dutyType": "GUARD",
      "location": "Main Gate",
      "phoneNumber": "9876543210",
      "email": "jayanth@police.gov.in",
      "designation": "AHC",
      "section": "A",
      "dateOfJoining": "2015-06-15",
      "vehicleNumber": null,
      "dutyLocation": null,
      "pdms": null,
      "licenceType": null,
      "deployedFrom": null,
      "platoonId": null,
      "isActive": true,
      "createdAt": "2024-01-15T10:30:00",
      "updatedAt": "2024-06-10T14:20:00"
    }
  ],
  "totalElements": 215,
  "totalPages": 11,
  "size": 20,
  "number": 0,
  "first": true,
  "last": false
}
```

**Search Logic (Specification Pattern):**
- Search parameter triggers OR across 8 fields with LIKE %term% (case-insensitive)
- All other filters are AND conditions
- Null/blank filter values are ignored

---

#### SRS-PERSONNEL-02: Get Personnel by Badge ID

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `GET /api/personnel/{badgeId}` |
| **Access** | Authenticated |
| **Path Variable** | badgeId — exact badge ID string |

**Success Response (HTTP 200):** Full PersonnelDto object (same schema as list item)

**Error Responses:**
| Condition | HTTP Status | Message |
|-----------|-------------|---------|
| Badge ID not found | 404 | "Personnel record not found for badge ID: {badgeId}" |

---

#### SRS-PERSONNEL-03: Create Personnel

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `POST /api/personnel` |
| **Access** | ADMIN or HIGHER_OFFICER (via @PreAuthorize) |

**Request Payload:**
```json
{
  "badgeId": "string (required, unique, max 50)",
  "personName": "string (required, max 200)",
  "dutyType": "string (optional, max 100)",
  "location": "string (optional, max 200)",
  "phoneNumber": "string (optional, max 20)",
  "email": "string (optional, max 200)",
  "designation": "string (optional, max 100)",
  "section": "string (required, max 5)",
  "dateOfJoining": "yyyy-MM-dd (optional)",
  "vehicleNumber": "string (optional, max 50)",
  "dutyLocation": "string (optional, max 200)",
  "pdms": "string (optional, max 100)",
  "licenceType": "string (optional, max 50)",
  "deployedFrom": "string (optional, max 200)",
  "platoonId": "number (optional)",
  "isActive": "boolean (optional, default: true)"
}
```

**Validation Rules:**
1. badgeId must be unique (checked via `personnelRepository.existsByBadgeId`)
2. If dutyType = "DRIVER" (case-insensitive), then vehicleNumber, dutyLocation, pdms, and licenceType are ALL required
3. personName is required
4. section is required

**Error Responses:**
| Condition | HTTP Status | Message |
|-----------|-------------|---------|
| Duplicate badgeId | 400 (IllegalStateException) | "Badge ID already exists: {badgeId}" |
| Driver fields missing | 400 (IllegalArgumentException) | "Driver fields required when duty type is DRIVER: {fields}" |
| Validation failure | 400 | Standard validation errors |
| Unauthorized | 403 | Access denied |

**Success Response:** HTTP 201 + full PersonnelDto

---

#### SRS-PERSONNEL-04: Update Personnel

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `PUT /api/personnel/{badgeId}` |
| **Access** | ADMIN or HIGHER_OFFICER |

**Request Payload:** Same fields as create, all optional (partial update supported)

**Processing Logic:**
1. Find personnel by badgeId (throw 404 if not found)
2. Apply only non-null fields from request to entity
3. Validate driver fields with merged values (existing + update)
4. Save and return updated DTO

**Success Response:** HTTP 200 + full PersonnelDto

---

#### SRS-PERSONNEL-05: Delete Personnel

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `DELETE /api/personnel/{badgeId}` |
| **Access** | ADMIN only |

**Processing Logic:**
1. Find personnel by badgeId (throw 404 if not found)
2. Hard-delete from database
3. Return HTTP 204 No Content

---

### 3.3 Module SRS-LEAVE: Leave Management

#### SRS-LEAVE-01: List Leave Requests

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `GET /api/leave-requests` |
| **Access** | Authenticated (role-based visibility) |

**Query Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| status | String | No | PENDING, APPROVED, REJECTED, CANCELLED |
| leaveType | String | No | CASUAL_LEAVE, SICK_LEAVE, EARNED_LEAVE, WEEKLY_OFF, COMPENSATORY_OFF |
| personnelId | Long | No | Filter by specific personnel |
| startDate | LocalDate | No | Leave starts on or after |
| endDate | LocalDate | No | Leave ends on or before |
| page, size, sort | Standard | No | Pagination parameters |

**Role-Based Visibility:**
| Role | Visibility |
|------|-----------|
| ADMIN | All leave requests |
| HIGHER_OFFICER | All leave requests |
| GENERAL_USER | Only their own leave requests (matched via user.personnelId) |

**Processing Logic:**
1. Extract user role from Authentication object
2. If GENERAL_USER: add personnelId filter matching user's linked personnelId
3. Apply all other filters as AND predicates
4. Return paginated results with personnel name/badge resolved

---

#### SRS-LEAVE-02: Submit Leave Request

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `POST /api/leave-requests` |
| **Access** | Authenticated |

**Request Payload:**
```json
{
  "personnelId": "number (required)",
  "leaveType": "string (required: CASUAL_LEAVE|SICK_LEAVE|EARNED_LEAVE|WEEKLY_OFF|COMPENSATORY_OFF)",
  "startDate": "yyyy-MM-dd (required)",
  "endDate": "yyyy-MM-dd (required)",
  "reason": "string (optional)"
}
```

**Validation Rules:**
1. personnelId must exist in personnel table
2. No overlapping leave must exist for same personnelId with overlapping dates
3. Leave type must be one of the 5 valid types

**Processing Logic:**
1. Validate personnel exists (throw EntityNotFoundException if not)
2. Check for overlapping leave requests via `leaveRequestRepository.findOverlapping()`
3. If overlap found → throw IllegalStateException("Overlapping leave request exists")
4. Create LeaveRequest entity with status=PENDING
5. Save to database
6. Check for duty conflicts on leave dates
7. If duty conflicts exist → return response with both leave DTO AND conflict list

**Success Response (HTTP 201):**

Without conflicts:
```json
{
  "id": 1,
  "personnelId": 5,
  "personnelName": "Jayanth Kumar",
  "badgeId": "AHC-2649",
  "leaveType": "SICK_LEAVE",
  "startDate": "2026-06-22",
  "endDate": "2026-06-22",
  "status": "PENDING",
  "reason": "Fever",
  "createdAt": "2026-06-21T10:00:00"
}
```

With duty conflicts:
```json
{
  "leave": { ... LeaveRequestDto ... },
  "dutyConflicts": [
    {
      "assignmentId": 142,
      "date": "2026-06-22",
      "dutyName": "Guard I",
      "platoonId": 2
    }
  ]
}
```

---

#### SRS-LEAVE-03: Approve Leave

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `PUT /api/leave-requests/{id}/approve` |
| **Access** | ADMIN or HIGHER_OFFICER |

**Validation Rules:**
1. Leave request must exist
2. Leave status must be PENDING (else: "Leave request already processed")
3. Approver user must exist

**Processing Logic:**
1. Find leave request by ID
2. Validate status is PENDING
3. Resolve approver user from authentication
4. Set status=APPROVED, approvedBy=approver.id
5. Save and return updated DTO

---

#### SRS-LEAVE-04: Reject Leave

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `PUT /api/leave-requests/{id}/reject` |
| **Access** | ADMIN or HIGHER_OFFICER |

**Request Body:**
```json
{
  "reason": "string (rejection reason)"
}
```

**Processing Logic:**
1. Find leave request by ID
2. Validate status is PENDING
3. Set status=REJECTED, approvedBy=approver.id, rejectionReason=reason
4. Save and return DTO

---

#### SRS-LEAVE-05: Cancel Leave

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `PUT /api/leave-requests/{id}/cancel` |
| **Access** | Authenticated |

**Validation Rules:**
1. Cannot cancel if status is REJECTED or CANCELLED
2. Cannot cancel if endDate is in the past (before today)

**Error Messages:**
- "Leave request cannot be cancelled" (status is REJECTED/CANCELLED)
- "Cannot cancel past leave requests" (endDate before today)

---

### 3.4 Module SRS-CYCLE: Platoon Cycle Management

#### SRS-CYCLE-01: Create Cycle

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `POST /api/cycles` |
| **Access** | Authenticated |

**Request Payload:**
```json
{
  "startDate": "yyyy-MM-dd (required)",
  "rotationDays": "integer (required, > 0)",
  "platoonSections": [
    { "platoonId": 1, "sectionIds": [3] },
    { "platoonId": 2, "sectionIds": [4] },
    { "platoonId": 3, "sectionIds": [5] },
    { "platoonId": 4, "sectionIds": [6] },
    { "platoonId": 5, "sectionIds": [7] }
  ]
}
```

**Processing Logic:**
1. Validate request via CycleValidator.validateAndCalculateEndDate()
2. Calculate endDate = startDate + rotationDays - 1
3. Check for overlapping ACTIVE cycles → throw IllegalStateException with details
4. Create ScheduleCycle entity (status=ACTIVE)
5. Persist cycle to database
6. Create CyclePlatoonSection entries (one per platoon per section)
7. Call AssignmentGenerationService.generateAssignments() — creates one CycleDutyAssignment per person per day
8. Create audit log entry (action=CYCLE_CREATED)
9. Return CycleResponse

**Success Response (HTTP 201):**
```json
{
  "id": 5,
  "startDate": "2026-07-01",
  "endDate": "2026-07-15",
  "rotationDays": 15,
  "status": "ACTIVE",
  "platoonSections": [
    { "platoonId": 1, "sectionIds": [3] },
    { "platoonId": 2, "sectionIds": [4] }
  ],
  "createdAt": "2026-06-21T12:00:00",
  "updatedAt": "2026-06-21T12:00:00"
}
```

**Error Responses:**
| Condition | HTTP Status | Message |
|-----------|-------------|---------|
| Overlapping cycle | 400 | "Cycle dates overlap with existing cycle #{id} ({start} to {end}). Please choose dates after {end}." |
| Invalid dates | 400 | Validation error from CycleValidator |

---

#### SRS-CYCLE-02: List Cycles

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `GET /api/cycles` |
| **Access** | Authenticated |

**Query Parameters:**
| Parameter | Type | Required | Default |
|-----------|------|----------|---------|
| status | String | No | Returns all non-DELETED |

**Behavior:**
- If status is provided: filter by exact status
- If status is null/blank: return all where status != "DELETED"
- Ordered by start_date DESC

---

#### SRS-CYCLE-03: Get Cycle by ID

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `GET /api/cycles/{id}` |
| **Access** | Authenticated |

**Error:** ResourceNotFoundException if ID not found (HTTP 404)

---

#### SRS-CYCLE-04: Partial Update Cycle (PATCH)

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `PATCH /api/cycles/{id}` |
| **Access** | Authenticated |

**Request Payload (all optional):**
```json
{
  "startDate": "yyyy-MM-dd",
  "rotationDays": "integer",
  "status": "ACTIVE|COMPLETED",
  "platoonSections": [...]
}
```

**Processing Logic:**
1. Find cycle by ID (throw 404 if not found)
2. Apply only non-null fields
3. If startDate or rotationDays changed → recalculate endDate
4. If platoonSections changed → delete old mappings & assignments, regenerate both
5. If only dates changed (not mappings) → delete assignments, regenerate with existing mappings
6. Create audit log (old values → new values)
7. Return updated CycleResponse

---

#### SRS-CYCLE-05: Full Update Cycle (PUT)

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `PUT /api/cycles/{id}` |
| **Access** | Authenticated |

**Behavior:** Replaces ALL fields. Deletes all existing mappings and assignments, regenerates from scratch.

---

#### SRS-CYCLE-06: Delete Cycle (Soft Delete)

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `DELETE /api/cycles/{id}` |
| **Access** | Authenticated |

**Processing Logic:**
1. Find cycle (throw 404 if not found)
2. Set status = "DELETED"
3. Save
4. Create audit log (action=CYCLE_DELETED)
5. Return HTTP 204 No Content

Note: Mappings and assignments are NOT deleted — preserved for audit trail.

---

#### SRS-CYCLE-07: Get Next Available Date

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `GET /api/cycles/next-available-date` |
| **Access** | Authenticated |

**Response:**
```json
{
  "nextAvailableDate": "2026-07-16"
}
```

**Logic:** Returns the day after the latest ACTIVE cycle's end date. If no active cycles exist, returns today's date.

---

#### SRS-CYCLE-08: Auto-Generate Mappings

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `GET /api/cycles/auto-generate` |
| **Access** | Authenticated |

**Response:**
```json
{
  "mappings": [
    { "platoonId": 1, "sectionIds": [4] },
    { "platoonId": 2, "sectionIds": [5] },
    { "platoonId": 3, "sectionIds": [6] },
    { "platoonId": 4, "sectionIds": [7] },
    { "platoonId": 5, "sectionIds": [3] }
  ],
  "previousCycle": { "id": 4, "mappings": [...] },
  "previousPlatoonSections": { "1": 3, "2": 4, "3": 5, "4": 6, "5": 7 },
  "rotationIndex": 0
}
```

**Rotation Algorithm:**
1. Fetch most recent non-DELETED cycle
2. For each platoon, get its last section assignment
3. Shift each to the next section in circular order: 3→4→5→6→7→3
4. If no previous cycle: use default P1→3, P2→4, P3→5, P4→6, P5→7

---

#### SRS-CYCLE-09: Cycle Audit Logs

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `GET /api/cycles/audit` |
| **Alt Endpoint** | `GET /api/cycles/{id}/audit` |
| **Access** | Authenticated |

**Response:** Array of CycleAuditLogResponse objects:
```json
[
  {
    "id": 1,
    "cycleId": 5,
    "action": "CYCLE_CREATED",
    "description": "Cycle created from 2026-07-01 to 2026-07-15 (15 days)",
    "oldValue": null,
    "newValue": null,
    "performedBy": null,
    "createdAt": "2026-06-21T12:00:00"
  }
]
```

---

### 3.5 Module SRS-ADHOC: Adhoc Duty Management

#### SRS-ADHOC-01: Create Adhoc Duty

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `POST /api/adhoc-duties` |
| **Access** | Authenticated |

**Request Payload:**
```json
{
  "dutyName": "string (required, max 200)",
  "date": "yyyy-MM-dd (required)",
  "startTime": "HH:mm (required)",
  "endTime": "HH:mm (required)",
  "requiredCount": "integer (required, > 0)",
  "location": "string (optional, max 300)",
  "pickFrom": "ALL_PLATOONS | SPECIFIC_PLATOONS (optional, default: ALL_PLATOONS)",
  "platoonIds": "[1,2,3] (optional, JSON array)"
}
```

**Success Response (HTTP 201):**
```json
{
  "id": 8,
  "dutyName": "Independence Day Bandobast",
  "date": "2026-08-15",
  "startTime": "06:00",
  "endTime": "18:00",
  "requiredCount": 20,
  "actualCount": 18,
  "pickFrom": "ALL_PLATOONS",
  "location": "City Center",
  "status": "ACTIVE",
  "createdAt": "2026-06-21T10:00:00"
}
```

Note: `actualCount` may be less than `requiredCount` if insufficient personnel are available.

---

#### SRS-ADHOC-02: List Adhoc Duties

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `GET /api/adhoc-duties` |
| **Access** | Authenticated |

**Query Parameters:**
| Parameter | Type | Required |
|-----------|------|----------|
| date | LocalDate (ISO) | No |
| status | String | No |

---

#### SRS-ADHOC-03: Get Adhoc Duty Details

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `GET /api/adhoc-duties/{id}` |
| **Access** | Authenticated |

---

#### SRS-ADHOC-04: Cancel Adhoc Duty

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `DELETE /api/adhoc-duties/{id}` |
| **Access** | Authenticated |

**Processing:** Sets status to CANCELLED, releases assigned personnel.

---

#### SRS-ADHOC-05: Preview Available Personnel

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `GET /api/adhoc-duties/preview` |
| **Access** | Authenticated |

**Query Parameters (all required except pickFrom/platoonIds):**
| Parameter | Type | Required |
|-----------|------|----------|
| date | LocalDate | Yes |
| startTime | LocalTime | Yes |
| endTime | LocalTime | Yes |
| count | int | Yes |
| pickFrom | String | No (default: ALL_PLATOONS) |
| platoonIds | List<Long> | No |

**Response:** Array of AdhocAssigneeInfo objects showing available candidates.

---

#### SRS-ADHOC-06: Download Adhoc Duty Report

| Attribute | Specification |
|-----------|--------------|
| **PDF Endpoint** | `GET /api/adhoc-duties/{id}/report/pdf` |
| **Excel Endpoint** | `GET /api/adhoc-duties/{id}/report/excel` |
| **Access** | Authenticated |
| **Response** | Binary file download |

---

### 3.6 Module SRS-CHAT: AI Chat Interface

#### SRS-CHAT-01: Send Text Message

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `POST /api/chat/message` |
| **Access** | Authenticated |

**Request Payload:**
```json
{
  "message": "string (required)"
}
```

**Response:**
```json
{
  "response": "Human-readable text response",
  "commandType": "SEARCH_PERSONNEL",
  "responseType": "table | form | confirmation | suggestions | text",
  "data": { ... structured data based on responseType ... }
}
```

**Processing Pipeline:**
1. Resolve user from JWT authentication
2. Sanitize input (detect prompt injection)
3. Detect language (English/Kannada/Hindi/mixed)
4. Call FunctionCallingService.resolveIntent() — LLM determines tool + params
5. Dispatch to McpHost → appropriate McpServer
6. Build structured response via ResponseBuilderService
7. Save chat message to database
8. Return ChatResponse

---

#### SRS-CHAT-02: Send Voice Message

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `POST /api/chat/voice` |
| **Access** | Authenticated |
| **Content-Type** | multipart/form-data |
| **Parameter** | file (audio file) |

**Processing:**
1. Transcribe audio via STT service (with circuit breaker)
2. If transcription succeeds → process as text message
3. If STT unavailable → return fallback: "Voice transcription is temporarily unavailable"
4. If STT error → return: "Could not transcribe audio: {error}"

---

#### SRS-CHAT-03: Upload PDF Document

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `POST /api/chat/upload-pdf` |
| **Access** | Authenticated |
| **Content-Type** | multipart/form-data |
| **Parameter** | file (PDF, max 10MB) |

**Processing:** Delegates to DocumentProcessorService for PDF parsing, chunking, and embedding storage.

---

#### SRS-CHAT-04: Submit Form via Chat

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `POST /api/chat/form-submit` |
| **Access** | Authenticated |

**Request Payload:**
```json
{
  "formId": "string",
  "submitAction": "create_person | create_leave | create_cycle | create_adhoc_duty",
  "fields": {
    "fieldName": "fieldValue",
    ...
  }
}
```

**Supported Actions and Required Fields:**

| Action | Required Fields |
|--------|----------------|
| create_person | personName, badgeId, section |
| create_leave | personnelId, leaveType, startDate, endDate |
| create_cycle | startDate, rotationDays, platoon_1_sections through platoon_5_sections |
| create_adhoc_duty | duty_name, date, start_time, end_time, required_count |

---

### 3.7 Module SRS-SCHEDULE: Schedule Management

#### SRS-SCHEDULE-01: Get Sections Overview

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `GET /api/schedules/sections` |
| **Access** | Authenticated |

**Response:** SectionOverview containing sectionA, sectionB, and sectionC (with rotation info).

---

#### SRS-SCHEDULE-02: Get Individual Sections

| Endpoints | Response |
|-----------|----------|
| `GET /api/schedules/section-a` | List<DutyAssignmentDto> |
| `GET /api/schedules/section-b` | List<DutyAssignmentDto> |
| `GET /api/schedules/section-c` | SectionCData (rotation + assignments) |

---

#### SRS-SCHEDULE-03: Get Platoon Rotation

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `GET /api/schedules/platoons` |
| **Response** | PlatoonRotationDto with currentCycleIndex, lastRotationDate, nextRotationDate, platoonMappings[] |

---

#### SRS-SCHEDULE-04: Rotate Platoons

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `POST /api/schedules/platoons/rotate` |
| **Access** | ADMIN only |
| **Response** | Updated PlatoonRotationDto |

---

#### SRS-SCHEDULE-05: Update Assignment

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `PUT /api/schedules/assignments/{id}` |
| **Access** | ADMIN or HIGHER_OFFICER |

---

### 3.8 Module SRS-REPORT: Report Generation

#### SRS-REPORT-01: Report Endpoint Matrix

| Report | Endpoint | Method | Format | Parameters |
|--------|----------|--------|--------|------------|
| Platoon Chart | `/api/reports/platoon-chart` | GET | PDF | date?, section?(C/D/E/F/G), locale? |
| Platoon Chart Excel | `/api/reports/platoon-chart/excel` | GET | XLSX | — |
| Form 168 | `/api/reports/form-168` | GET | PDF | date?, locale? |
| Form 168 Excel | `/api/reports/form-168/excel` | GET | XLSX | date? |
| Section A | `/api/reports/section-a` | GET | PDF | locale? |
| Section A Excel | `/api/reports/section-a/excel` | GET | XLSX | — |
| Section B | `/api/reports/section-b` | GET | PDF | locale? |
| Section B Excel | `/api/reports/section-b/excel` | GET | XLSX | — |
| Section A&B Combined | `/api/reports/section-ab` | GET | PDF | locale? |
| MT Section | `/api/reports/mt-section` | GET | PDF | locale? |
| MT Section Excel | `/api/reports/mt-section/excel` | GET | XLSX | — |
| Leave Statement | `/api/reports/leave-statement` | GET | PDF | status?, leaveType?, locale? |
| Leave Statement Excel | `/api/reports/leave-statement/excel` | GET | XLSX | status?, leaveType? |
| Personnel List | `/api/reports/personnel` | GET | PDF | section?, designation?, dutyType?, isActive?, locale? |
| Schedule Report | `/api/reports/schedules` | GET | PDF | locale? |
| Download by ID | `/api/reports/download/{fileId}` | GET | PDF | — |

**Response Headers (all reports):**
```
Content-Type: application/pdf (or application/vnd.openxmlformats-officedocument.spreadsheetml.sheet)
Content-Disposition: attachment; filename="{ReportType}_{dd-MM-yyyy}.{ext}"
```

**Platoon Chart Section Validation:**
- Valid values: C, D, E, F, G (case-insensitive, uppercased)
- Invalid section → HTTP 400 Bad Request

---

### 3.9 Module SRS-DUTYTYPE: Duty Type Management

#### SRS-DUTYTYPE-01: List Duty Types

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `GET /api/duty-types` |
| **Access** | Authenticated |
| **Query Params** | section (optional) |

**Response:** Array of DutyTypeDto:
```json
[
  {
    "id": 1,
    "name": "GUARD",
    "section": "A",
    "sortOrder": 1,
    "latitude": 12.8714,
    "longitude": 74.8428,
    "radiusMeters": 500
  }
]
```

---

#### SRS-DUTYTYPE-02: Create Duty Type

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `POST /api/duty-types` |
| **Access** | Authenticated |
| **Response** | HTTP 201 + DutyTypeDto |

---

#### SRS-DUTYTYPE-03: Update Duty Type

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `PUT /api/duty-types/{id}` |
| **Access** | Authenticated |

---

#### SRS-DUTYTYPE-04: Delete Duty Type

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `DELETE /api/duty-types/{id}` |
| **Access** | Authenticated |
| **Constraints** | Returns 409 Conflict if active assignments exist |

---

### 3.10 Module SRS-SECTION: Section Management

#### SRS-SECTION-01: List All Sections

| Endpoint | Response |
|----------|----------|
| `GET /api/sections` | All sections (active + inactive) with duty type counts |
| `GET /api/sections/active` | Active sections only |

---

#### SRS-SECTION-02: Create Section

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `POST /api/sections` |
| **Response** | HTTP 201 + SectionDto |
| **Constraint** | 409 Conflict on duplicate code |

---

#### SRS-SECTION-03: Update Section

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `PUT /api/sections/{id}` |

---

#### SRS-SECTION-04: Bulk Reassignment

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `POST /api/sections/reassign` |
| **Purpose** | Bulk move duty types from one section to another |

---

### 3.11 Module SRS-HEALTH: System Health

#### SRS-HEALTH-01: System Health Check

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `GET /api/health` |
| **Access** | Public |

**Response:**
```json
{
  "status": "UP",
  "aiProvider": "groq | bedrock"
}
```

---

#### SRS-HEALTH-02: AI Provider Health Check

| Attribute | Specification |
|-----------|--------------|
| **Endpoint** | `GET /api/health/ai` |
| **Access** | Public |

**Response (Success):**
```json
{
  "connected": true,
  "provider": "groq"
}
```

**Response (Failure):**
```json
{
  "connected": false,
  "reason": "Connection timeout",
  "provider": "groq"
}
```

**Processing:** Sends a minimal "hi" message to the LLM provider and checks for non-empty response.

---

## 4. Interface Requirements

### 4.1 Frontend Pages and Navigation

```mermaid
graph TD
    LOGIN[/login<br>LoginPage] --> HOME[/<br>HomePage + Chat]
    HOME --> PERSONNEL[/personnel<br>PersonnelPage]
    PERSONNEL --> ADD_PERSON[/personnel/add<br>AddPersonPage]
    PERSONNEL --> PROFILE[/personnel/:badgeId<br>PersonnelProfilePage]
    HOME --> SCHEDULES[/schedules<br>SchedulesPage]
    SCHEDULES --> ROTATION[/schedules/rotation<br>RotationManagementPage]
    SCHEDULES --> CYCLES[/schedules/cycles<br>CycleManagementPage]
    SCHEDULES --> ACTIVITIES[/schedules/activities<br>CycleActivitiesPage]
    SCHEDULES --> ADHOC[/schedules/adhoc<br>AdhocDutyPage]
    HOME --> LEAVE[/leave-requests<br>LeaveRequestsPage]
    HOME --> REPORTS[/reports<br>ReportsPage]
    HOME --> SUPPORT[/contact-support<br>ContactSupportPage]
    HOME --> ADMIN[/admin/duty-sections<br>DutySectionsPage]
```

### 4.2 Frontend State Management

| Store | Library | Purpose |
|-------|---------|---------|
| AuthStore | MobX | JWT token, user role, locale, login/logout actions |
| ThemeContext | React Context | Dark/light mode toggle |
| i18n | i18next | Translation loading and locale switching |

### 4.3 Frontend API Client

| Configuration | Value |
|---------------|-------|
| Base URL | From environment (defaults to /api for relative) |
| Auth Header | `Authorization: Bearer {token}` (auto-injected) |
| Error Handling | 401 → auto-redirect to /login |
| Content-Type | application/json (default), multipart/form-data (file uploads) |

---

## 5. Data Requirements

### 5.1 Entity Relationship Summary

```mermaid
erDiagram
    USERS ||--o| PERSONNEL : "links to"
    PERSONNEL ||--o{ LEAVE_REQUESTS : "submits"
    PERSONNEL }o--|| DUTY_TYPES : "assigned to"
    PERSONNEL }o--o| PLATOONS : "belongs to"
    SCHEDULE_CYCLES ||--|{ CYCLE_PLATOON_SECTIONS : "has"
    SCHEDULE_CYCLES ||--|{ CYCLE_DUTY_ASSIGNMENTS : "generates"
    CYCLE_DUTY_ASSIGNMENTS }o--|| PERSONNEL : "assigned to"
    ADHOC_DUTIES ||--|{ ADHOC_DUTY_ASSIGNMENTS : "has"
    ADHOC_DUTY_ASSIGNMENTS }o--|| PERSONNEL : "assigned to"
    DUTY_TYPES ||--o{ DUTY_TYPES : "parent-child"
    SCHEDULE_CYCLES ||--|{ CYCLE_AUDIT_LOGS : "logged"
```

### 5.2 Data Integrity Rules

| Rule | Enforcement |
|------|-------------|
| Badge ID uniqueness | Database UNIQUE constraint + service-level check |
| Personnel-User link | `users.personnel_id` FK (nullable) |
| Cycle date non-overlap | Service-level query check before creation |
| Leave date non-overlap | Repository query `findOverlapping()` |
| Soft-delete preservation | Status field change only, no data removal |
| Audit immutability | INSERT-only audit tables, no UPDATE/DELETE |
| Cascade on cycle delete | Status change only; mappings/assignments preserved |

---

## 6. Performance Requirements

| Metric | Requirement | Implementation |
|--------|-------------|----------------|
| API latency (simple GET) | < 200ms p95 | JPA pagination, indexed queries |
| API latency (list with filters) | < 500ms p95 | JPA Specification pattern with indexed columns |
| Chat response (full pipeline) | < 5s p95 | Circuit breaker timeout on LLM calls |
| Report generation (PDF) | < 10s | OpenPDF streaming |
| Report generation (Excel) | < 15s | Apache POI in-memory |
| Concurrent users | 50+ | Stateless architecture, connection pooling |
| Cache hit ratio | > 80% for repeated queries | Caffeine TTL-based eviction |

---

## 7. Security Requirements

### 7.1 Authentication Flow

```mermaid
sequenceDiagram
    participant Client as Browser
    participant Filter as JwtAuthFilter
    participant Controller as API Controller
    participant DB as Database

    Client->>Filter: Request with Authorization: Bearer {token}
    Filter->>Filter: Extract token, validate signature
    Filter->>Filter: Check expiration
    Filter->>DB: Load user by username (from claims)
    DB-->>Filter: User entity
    Filter->>Filter: Set SecurityContext
    Filter->>Controller: Forward authenticated request
    Controller-->>Client: Response
```

### 7.2 Input Validation Summary

| Layer | Mechanism | Coverage |
|-------|-----------|----------|
| Controller | `@Valid` + Jakarta Validation | All request DTOs |
| Service | Custom validation logic | Business rules (overlap, driver fields, etc.) |
| Chat Input | InputSanitizerService | Prompt injection detection |
| Database | NOT NULL, UNIQUE constraints | Data integrity |

---

## 8. Error Handling Specification

### 8.1 Standard Error Response Format

```json
{
  "error": {
    "code": "ERROR_CODE",
    "message": "Human-readable description",
    "timestamp": "2026-06-21T10:00:00Z"
  }
}
```

### 8.2 Exception-to-HTTP Mapping

| Exception | HTTP Status | Code |
|-----------|-------------|------|
| EntityNotFoundException | 404 | NOT_FOUND |
| ResourceNotFoundException | 404 | NOT_FOUND |
| IllegalStateException | 400 | BAD_REQUEST |
| IllegalArgumentException | 400 | VALIDATION_ERROR |
| AccessDeniedException | 403 | FORBIDDEN |
| AuthenticationException | 401 | UNAUTHORIZED |
| ReportGenerationException | 500 | REPORT_ERROR |
| MethodArgumentNotValidException | 400 | VALIDATION_ERROR |

---

## 9. Reliability & Resilience

### 9.1 Circuit Breaker Configuration

| Service | Breaker Name | Purpose |
|---------|-------------|---------|
| STT (Whisper) | "stt-service" | Audio transcription fallback |
| LLM Calls | Managed via CircuitBreakerManager | AI provider unavailability |

### 9.2 Fallback Behaviors

| Scenario | Fallback |
|----------|----------|
| LLM unavailable | Return ActionPlan.unknown → suggestions response |
| STT unavailable | Return "Voice transcription is temporarily unavailable" |
| Prompt injection detected | Return "Your message could not be processed" |
| Tool not found in MCP registry | Return TOOL_NOT_FOUND error |

---

## 10. Internationalization Requirements

### 10.1 Supported Locales

| Locale Code | Language | Coverage |
|-------------|----------|----------|
| en | English | 100% — all UI labels, system messages |
| kn | Kannada (ಕನ್ನಡ) | 100% — all UI labels, chat responses |

### 10.2 Translation Storage

| Field | Type | Description |
|-------|------|-------------|
| translationKey | String | Dot-notation key (e.g., nav.home, nav.personnel) |
| locale | String | en or kn |
| translationValue | String | Translated text |
| category | String | Optional grouping (nav, form, chat, etc.) |

### 10.3 Chat Language Handling

| Input Language | Detection Method | Response Language |
|----------------|-----------------|-------------------|
| English | LanguageDetectorService | en |
| Kannada | Unicode script detection | kn |
| Hindi | Unicode script detection | en (responds in English) |
| Mixed | Majority script detection | Detected majority |

---

## 11. Deployment Requirements

### 11.1 Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| DB_URL | Yes | — | PostgreSQL JDBC URL |
| DB_USERNAME | Yes | — | Database username |
| DB_PASSWORD | Yes | — | Database password |
| JWT_SECRET | Yes | — | JWT signing secret |
| JWT_EXPIRATION_MS | No | 86400000 | Token expiry (ms) |
| AI_PROVIDER | No | groq | groq or bedrock |
| GROQ_API_KEY | Conditional | — | Required if AI_PROVIDER=groq |
| GROQ_API_URL | No | https://api.groq.com/openai/v1 | Groq base URL |
| GROQ_MODEL | No | llama-3.3-70b-versatile | Model name |
| AWS_REGION | No | us-east-1 | For Bedrock |
| BEDROCK_MODEL_ID | No | amazon.nova-lite-v1:0 | Bedrock model |
| CORS_ALLOWED_ORIGINS | No | http://localhost:5173 | CORS origins |
| SERVER_PORT | No | 8080 | Server port |
| SPRING_PROFILES_ACTIVE | No | local | Active profile |
| CHAT_RATE_LIMIT_GENERAL | No | 30 | Chat rate limit |
| CHAT_RATE_LIMIT_LLM | No | 20 | LLM rate limit |

### 11.2 Database Requirements

| Requirement | Specification |
|-------------|--------------|
| Engine | PostgreSQL 15+ |
| Extension | pgvector (for document embeddings) |
| DDL Management | Manual (ddl-auto: none) |
| Character Set | UTF-8 (required for Kannada text) |
| Timezone | Server default (IST assumed) |

---

## 12. Traceability Matrix

| BRD Requirement | SRS Module | API Endpoints |
|-----------------|------------|---------------|
| FR-01: Auth | SRS-AUTH | /api/auth/* |
| FR-02: Personnel | SRS-PERSONNEL | /api/personnel/* |
| FR-03: Sections/Duty Types | SRS-DUTYTYPE, SRS-SECTION | /api/duty-types/*, /api/sections/* |
| FR-04: Cycle Management | SRS-CYCLE | /api/cycles/* |
| FR-05: Duty Assignment | SRS-CYCLE (reassignment) | /api/cycles/* (via chat MCP) |
| FR-06: Leave | SRS-LEAVE | /api/leave-requests/* |
| FR-07: Adhoc Duties | SRS-ADHOC | /api/adhoc-duties/* |
| FR-08: AI Chat | SRS-CHAT | /api/chat/* |
| FR-09: Reports | SRS-REPORT | /api/reports/* |
| FR-10: Schedule | SRS-SCHEDULE | /api/schedules/* |
| FR-11: i18n | Section 10 | /api/i18n/* |
| FR-12: Admin | SRS-SECTION, SRS-DUTYTYPE | /api/admin/*, /api/sections/* |

---

## 13. Appendix A: Complete API Endpoint Registry

| # | Method | Endpoint | Access | Module |
|---|--------|----------|--------|--------|
| 1 | POST | /api/auth/login | Public | Auth |
| 2 | POST | /api/auth/logout | Auth | Auth |
| 3 | POST | /api/auth/change-password | Auth | Auth |
| 4 | GET | /api/personnel | Auth | Personnel |
| 5 | GET | /api/personnel/{badgeId} | Auth | Personnel |
| 6 | POST | /api/personnel | Admin/HO | Personnel |
| 7 | PUT | /api/personnel/{badgeId} | Admin/HO | Personnel |
| 8 | DELETE | /api/personnel/{badgeId} | Admin | Personnel |
| 9 | GET | /api/leave-requests | Auth (scoped) | Leave |
| 10 | POST | /api/leave-requests | Auth | Leave |
| 11 | PUT | /api/leave-requests/{id}/approve | Admin/HO | Leave |
| 12 | PUT | /api/leave-requests/{id}/reject | Admin/HO | Leave |
| 13 | PUT | /api/leave-requests/{id}/cancel | Auth | Leave |
| 14 | POST | /api/cycles | Auth | Cycles |
| 15 | GET | /api/cycles | Auth | Cycles |
| 16 | GET | /api/cycles/{id} | Auth | Cycles |
| 17 | PATCH | /api/cycles/{id} | Auth | Cycles |
| 18 | PUT | /api/cycles/{id} | Auth | Cycles |
| 19 | DELETE | /api/cycles/{id} | Auth | Cycles |
| 20 | GET | /api/cycles/next-available-date | Auth | Cycles |
| 21 | GET | /api/cycles/auto-generate | Auth | Cycles |
| 22 | GET | /api/cycles/audit | Auth | Cycles |
| 23 | GET | /api/cycles/{id}/audit | Auth | Cycles |
| 24 | POST | /api/adhoc-duties | Auth | Adhoc |
| 25 | GET | /api/adhoc-duties | Auth | Adhoc |
| 26 | GET | /api/adhoc-duties/{id} | Auth | Adhoc |
| 27 | DELETE | /api/adhoc-duties/{id} | Auth | Adhoc |
| 28 | GET | /api/adhoc-duties/preview | Auth | Adhoc |
| 29 | GET | /api/adhoc-duties/{id}/report/pdf | Auth | Adhoc |
| 30 | GET | /api/adhoc-duties/{id}/report/excel | Auth | Adhoc |
| 31 | POST | /api/chat/message | Auth | Chat |
| 32 | POST | /api/chat/voice | Auth | Chat |
| 33 | POST | /api/chat/upload-pdf | Auth | Chat |
| 34 | POST | /api/chat/form-submit | Auth | Chat |
| 35 | GET | /api/schedules/sections | Auth | Schedule |
| 36 | GET | /api/schedules/section-a | Auth | Schedule |
| 37 | GET | /api/schedules/section-b | Auth | Schedule |
| 38 | GET | /api/schedules/section-c | Auth | Schedule |
| 39 | GET | /api/schedules/platoons | Auth | Schedule |
| 40 | POST | /api/schedules/platoons/rotate | Admin | Schedule |
| 41 | PUT | /api/schedules/assignments/{id} | Admin/HO | Schedule |
| 42 | GET | /api/reports/platoon-chart | Auth | Reports |
| 43 | GET | /api/reports/form-168 | Auth | Reports |
| 44 | GET | /api/reports/section-a | Auth | Reports |
| 45 | GET | /api/reports/section-b | Auth | Reports |
| 46 | GET | /api/reports/section-ab | Auth | Reports |
| 47 | GET | /api/reports/mt-section | Auth | Reports |
| 48 | GET | /api/reports/personnel | Auth | Reports |
| 49 | GET | /api/reports/leave-statement | Auth | Reports |
| 50 | GET | /api/reports/leave-requests | Auth | Reports |
| 51 | GET | /api/reports/schedules | Auth | Reports |
| 52 | GET | /api/reports/download/{fileId} | Auth | Reports |
| 53 | GET | /api/reports/section-a/excel | Auth | Reports |
| 54 | GET | /api/reports/section-b/excel | Auth | Reports |
| 55 | GET | /api/reports/platoon-chart/excel | Auth | Reports |
| 56 | GET | /api/reports/mt-section/excel | Auth | Reports |
| 57 | GET | /api/reports/form-168/excel | Auth | Reports |
| 58 | GET | /api/reports/leave-statement/excel | Auth | Reports |
| 59 | GET | /api/duty-types | Auth | DutyType |
| 60 | POST | /api/duty-types | Auth | DutyType |
| 61 | PUT | /api/duty-types/{id} | Auth | DutyType |
| 62 | DELETE | /api/duty-types/{id} | Auth | DutyType |
| 63 | GET | /api/sections | Auth | Section |
| 64 | GET | /api/sections/active | Auth | Section |
| 65 | POST | /api/sections | Auth | Section |
| 66 | PUT | /api/sections/{id} | Auth | Section |
| 67 | POST | /api/sections/reassign | Auth | Section |
| 68 | GET | /api/health | Public | Health |
| 69 | GET | /api/health/ai | Public | Health |

---

## 14. Appendix B: State Transition Diagrams

### 14.1 Leave Request States

```mermaid
stateDiagram-v2
    [*] --> PENDING : Submit
    PENDING --> APPROVED : Approve (Admin/HO)
    PENDING --> REJECTED : Reject (Admin/HO)
    PENDING --> CANCELLED : Cancel (User)
    APPROVED --> CANCELLED : Cancel (if future)
    REJECTED --> [*]
    CANCELLED --> [*]
```

### 14.2 Schedule Cycle States

```mermaid
stateDiagram-v2
    [*] --> ACTIVE : Create
    ACTIVE --> COMPLETED : Status update
    ACTIVE --> DELETED : Soft-delete
    COMPLETED --> DELETED : Soft-delete
    DELETED --> [*]
```

### 14.3 Adhoc Duty States

```mermaid
stateDiagram-v2
    [*] --> ACTIVE : Create
    ACTIVE --> COMPLETED : Auto (time passes)
    ACTIVE --> CANCELLED : Cancel
    COMPLETED --> [*]
    CANCELLED --> [*]
```

---

## 15. Document Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0.0 | June 2026 | Generated from Codebase | Initial complete SRS |

---

*End of Document — SRS v1.0.0*

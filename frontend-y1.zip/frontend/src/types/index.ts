// ===== Auth =====
export interface LoginRequest {
  username: string;
  password: string;
  loginType?: string;
}

export interface AuthResponse {
  token: string;
  role: string;
  displayName: string;
  locale: string;
}

export interface ChangePasswordRequest {
  oldPassword: string;
  newPassword: string;
}

// ===== Personnel =====
export interface PersonnelDto {
  id: number;
  badgeId: string;
  personName: string;
  dutyType: string;
  location: string;
  phoneNumber: string;
  email: string;
  designation: string;
  section: string;
  dateOfJoining: string;
  vehicleNumber?: string;
  dutyLocation?: string;
  pdms?: string;
  licenceType?: string;
  deployedFrom?: string;
  platoonId?: number;
  unit?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CreatePersonnelRequest {
  badgeId: string;
  personName: string;
  dutyType?: string;
  location?: string;
  phoneNumber?: string;
  email?: string;
  designation?: string;
  section: string;
  dateOfJoining?: string;
  vehicleNumber?: string;
  dutyLocation?: string;
  pdms?: string;
  licenceType?: string;
  deployedFrom?: string;
  platoonId?: number;
  isActive?: boolean;
  unit?: string;
}

export interface UpdatePersonnelRequest {
  badgeId?: string;
  personName?: string;
  dutyType?: string;
  location?: string;
  phoneNumber?: string;
  email?: string;
  designation?: string;
  section?: string;
  dateOfJoining?: string;
  vehicleNumber?: string;
  dutyLocation?: string;
  pdms?: string;
  licenceType?: string;
  deployedFrom?: string;
  platoonId?: number;
  isActive?: boolean;
  unit?: string;
}

export interface PersonnelFilter {
  search?: string;
  section?: string;
  dutyType?: string;
  designation?: string;
  isActive?: boolean;
}

// ===== Schedule =====
export interface DutyAssignmentDto {
  id: number;
  personnelId: number;
  personnelName: string;
  badgeId: string;
  dutyTypeId: number;
  dutyTypeName: string;
  section: string;
  effectiveDate: string;
  endDate?: string;
  shift?: string;
  subAssignment?: string;
  isCurrent: boolean;
}

export interface UpdateAssignmentRequest {
  personnelId?: number;
  dutyTypeId?: number;
  section?: string;
  effectiveDate?: string;
  endDate?: string;
  shift?: string;
  subAssignment?: string;
  isCurrent?: boolean;
}

export interface PlatoonDutyMapping {
  platoonId: number;
  platoonName: string;
  baseOffset: number;
  currentDutyType: string;
}

export interface PlatoonRotationDto {
  currentCycleIndex: number;
  lastRotationDate: string;
  nextRotationDate: string;
  platoonMappings: PlatoonDutyMapping[];
}

export interface SectionCData {
  rotation: PlatoonRotationDto;
  assignments: DutyAssignmentDto[];
}

export interface SectionOverview {
  sectionA: DutyAssignmentDto[];
  sectionB: DutyAssignmentDto[];
  sectionC: SectionCData;
}

// ===== Leave =====
export interface LeaveRequestDto {
  id: number;
  personnelId: number;
  personnelName: string;
  badgeId: string;
  leaveType: string;
  startDate: string;
  endDate: string;
  status: string;
  reason: string;
  approvedBy?: number;
  rejectionReason?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateLeaveRequest {
  personnelId: number;
  leaveType: string;
  startDate: string;
  endDate: string;
  reason?: string;
}

export interface LeaveFilter {
  status?: string;
  leaveType?: string;
  personnelId?: number;
  startDate?: string;
  endDate?: string;
}

// ===== Chat =====
export interface ChatRequest {
  message: string;
}

export interface ColumnDef {
  key: string;
  label: string;
}

export interface TableResponseData {
  columns: ColumnDef[];
  rows: Record<string, unknown>[];
  totalCount: number;
  meta?: Record<string, unknown>;
}

export interface FieldDef {
  name: string;
  label: string;
  type: 'text' | 'select' | 'date' | 'number' | 'multi-select';
  required: boolean;
  value?: string;
  options?: string[];
}

export interface FormResponseData {
  formId: string;
  title: string;
  fields: FieldDef[];
  submitAction: string;
  submitLabel?: string;
}

export interface ConfirmationResponseData {
  success: boolean;
  message: string;
  details?: Record<string, string>;
}

export interface SuggestionsResponseData {
  message: string;
  suggestions: string[];
}

export interface ChatResponse {
  response: string;
  commandType?: string;
  responseType?: 'text' | 'table' | 'form' | 'confirmation' | 'suggestions';
  data?: TableResponseData | FormResponseData | ConfirmationResponseData | SuggestionsResponseData;
}

// ===== i18n =====
export interface TranslationEntry {
  translationKey: string;
  locale: string;
  translationValue: string;
  category?: string;
}

// ===== Admin =====
export interface SystemConfig {
  [key: string]: string;
}

// ===== Common =====
export interface ErrorResponse {
  error: {
    code: string;
    message: string;
    timestamp: string;
  };
}

export interface Page<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  size: number;
  number: number;
  first: boolean;
  last: boolean;
}

export type UserRole = 'ADMIN' | 'HIGHER_OFFICER' | 'GENERAL_USER' | 'SUPPORT_ADMIN';
export type LeaveType = 'CASUAL_LEAVE' | 'SICK_LEAVE' | 'EARNED_LEAVE' | 'WEEKLY_OFF' | 'COMPENSATORY_OFF';
export type LeaveStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'CANCELLED';
export type Locale = 'en' | 'kn';

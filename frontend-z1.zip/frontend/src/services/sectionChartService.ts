import api from './api';

// ===== Types =====
export interface ChartPersonnel {
  id: number;
  badgeId: string;
  personName: string;
  designation: string;
  dutyLocation: string | null;
}

export interface SubDutyGroup {
  subDutyName: string;
  personnel: ChartPersonnel[];
  personnelCount: number;
}

export interface DutyCard {
  dutyTypeId: number;
  dutyTypeName: string;
  sortOrder: number;
  subDuties: SubDutyGroup[];
  personnel: ChartPersonnel[]; // personnel without sub-duty (no duty_location)
  personnelCount: number;
}

export interface SectionChartData {
  sectionCode: string;
  dutyCards: DutyCard[];
  totalPersonnel: number;
}

export interface PersonnelSearchResult {
  id: number;
  badgeId: string;
  personName: string;
  designation: string;
  currentSection: string;
  currentDutyType: string;
  currentDutyLocation: string | null;
}

export interface AssignRequest {
  personnelId: number;
  dutyTypeId: number;
  sectionCode: string;
  subDuty?: string | null; // duty_location value
}

export interface UnassignRequest {
  personnelId: number;
}

// ===== Service =====
export const sectionChartService = {
  /** Fetch chart data for a section */
  getChart: (sectionCode: string) =>
    api.get<SectionChartData>(`/api/section-chart/${sectionCode}`).then((r) => r.data),

  /** Search personnel for autocomplete (badge or name) */
  searchPersonnel: (query: string, limit = 10) =>
    api.get<PersonnelSearchResult[]>('/api/section-chart/search-personnel', {
      params: { query, limit },
    }).then((r) => r.data),

  /** Assign a person to a duty type with optional sub-duty (duty_location) */
  assign: (request: AssignRequest) =>
    api.put('/api/section-chart/assign', request).then((r) => r.data),

  /** Unassign a person from their duty */
  unassign: (request: UnassignRequest) =>
    api.put('/api/section-chart/unassign', request).then((r) => r.data),

  /** Create a new parent duty type in the duty_types table */
  createDutyType: (data: { name: string; section: string; sortOrder: number; level: 'PARENT'; }) =>
    api.post('/api/duty-types', data).then((r) => r.data),

  /** Add a sub-duty (logical - validates parent exists) */
  addSubDuty: (data: { subDutyName: string; parentDutyTypeId: number }) =>
    api.post('/api/section-chart/add-sub-duty', data).then((r) => r.data),

  /** Delete a parent duty type (unassigns all personnel, removes from DB) */
  deleteDutyType: (dutyTypeId: number) =>
    api.delete(`/api/section-chart/duty-type/${dutyTypeId}`).then((r) => r.data),

  /** Delete a sub-duty (clears duty_location for all personnel under it) */
  deleteSubDuty: (parentDutyTypeId: number, subDutyName: string) =>
    api.delete('/api/section-chart/sub-duty', {
      params: { parentDutyTypeId, subDutyName },
    }).then((r) => r.data),
};

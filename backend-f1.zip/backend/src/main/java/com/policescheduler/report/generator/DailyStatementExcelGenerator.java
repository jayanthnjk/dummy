package com.policescheduler.report.generator;

import com.policescheduler.report.Form168LayoutEngine;
import com.policescheduler.report.Form168StyleHelper;
import com.policescheduler.report.ReportGenerationException;
import com.policescheduler.report.model.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

@Service
public class DailyStatementExcelGenerator {

    private static final Logger log = LoggerFactory.getLogger(DailyStatementExcelGenerator.class);

    private static final List<String> STRENGTH_HEADERS =
            List.of("HEADS", "DCP", "ACP", "RPI", "RSI", "ARSI", "AHC", "APC", "TOTAL");

    private static final List<String> STRENGTH_ROW_LABELS = List.of(
            "C.A.R SANCTIONED STRENGTH",
            "PRESENT STRENGTH TOTAL",
            "ACTUAL VACANCY",
            "PRESENT STRENGTH PMT",
            "PRESENT STRENGTH COMPANY",
            "RECRUIT APC'S"
    );

    private static final List<String> DESIGNATION_COLS =
            List.of("DCP", "ACP", "RPI", "RSI", "ARSI", "AHC", "APC");

    private static final List<String> SECTION_HEADERS =
            List.of("HEADS", "ACP", "RPI", "RSI", "ARSI", "AHC", "APC", "SWP", "TOTAL", "PERSONNEL DETAILS");

    private static final int TOTAL_SECTION_COLS = 10;

    private final Form168LayoutEngine layoutEngine;
    private final Form168StyleHelper styleHelper;

    public DailyStatementExcelGenerator(Form168LayoutEngine layoutEngine,
                                         Form168StyleHelper styleHelper) {
        this.layoutEngine = layoutEngine;
        this.styleHelper = styleHelper;
    }

    public byte[] generate(LocalDate reportDate) {
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Daily Statement");

            // Create styles
            CellStyle dataStyle = styleHelper.createExcelDataStyle(workbook);
            CellStyle headerStyle = styleHelper.createExcelHeaderStyle(workbook);
            CellStyle sectionHeaderStyle = styleHelper.createExcelSectionHeaderStyle(workbook);
            CellStyle totalStyle = styleHelper.createExcelTotalStyle(workbook);
            CellStyle numberStyle = styleHelper.createExcelNumberStyle(workbook);

            // Build the report model
            Form168ReportModel model = layoutEngine.buildReportModel(reportDate);

            int rowIndex = 0;

            // === Row 1: Title row ===
            rowIndex = writeTitle(sheet, rowIndex, reportDate, sectionHeaderStyle);

            // Blank row
            rowIndex++;

            // === STRENGTH TABLE ===
            rowIndex = writeStrengthTable(sheet, rowIndex, model.getStrengthTable(),
                    headerStyle, dataStyle, numberStyle);

            // Blank row
            rowIndex++;

            // === CAR DUTY ABSTRACT / SECTIONS ===
            rowIndex = writeSections(sheet, rowIndex, model.getSections(),
                    sectionHeaderStyle, headerStyle, dataStyle, numberStyle, totalStyle);

            // === OFFICER'S DUTY ===
            rowIndex = writeOfficerDuty(sheet, rowIndex, model.getOfficerDuty(),
                    sectionHeaderStyle, headerStyle, dataStyle, totalStyle, numberStyle);

            // === LEAVE STATEMENT ===
            rowIndex = writeLeaveStatement(sheet, rowIndex, model.getLeaveStatement(),
                    sectionHeaderStyle, headerStyle, dataStyle);

            // Set column widths
            sheet.setColumnWidth(0, 8000);
            for (int i = 1; i <= 7; i++) {
                sheet.setColumnWidth(i, 2000);
            }
            sheet.setColumnWidth(8, 2500);
            sheet.setColumnWidth(9, 12000);

            // Freeze panes at row 2 for header visibility
            sheet.createFreezePane(0, 2);

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            workbook.write(baos);
            return baos.toByteArray();
        } catch (Exception e) {
            log.error("Failed to generate Daily Statement Excel report", e);
            throw new ReportGenerationException("daily_statement_excel",
                    "Failed to generate Daily Statement Excel report", e);
        }
    }

    // ======================== Title ========================

    private int writeTitle(Sheet sheet, int rowIndex, LocalDate reportDate, CellStyle style) {
        Row row = sheet.createRow(rowIndex);
        Cell formCell = row.createCell(0);
        formCell.setCellValue("FORM NO:168");
        formCell.setCellStyle(style);

        Cell dateCell = row.createCell(TOTAL_SECTION_COLS - 1);
        dateCell.setCellValue("DATE :" + reportDate.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        dateCell.setCellStyle(style);

        return rowIndex + 1;
    }

    // ======================== Strength Table ========================

    private int writeStrengthTable(Sheet sheet, int rowIndex, StrengthTableModel strengthTable,
                                    CellStyle headerStyle, CellStyle dataStyle, CellStyle numberStyle) {
        // Header row: HEADS | DCP | ACP | RPI | RSI | ARSI | AHC | APC | TOTAL
        Row headerRow = sheet.createRow(rowIndex++);
        for (int i = 0; i < STRENGTH_HEADERS.size(); i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(STRENGTH_HEADERS.get(i));
            cell.setCellStyle(headerStyle);
        }

        // Data rows
        List<Map<String, Integer>> rows = List.of(
                strengthTable.getSanctionedStrength(),
                strengthTable.getPresentStrengthTotal(),
                strengthTable.getActualVacancy(),
                strengthTable.getPresentStrengthPmt(),
                strengthTable.getPresentStrengthCompany(),
                strengthTable.getRecruitApcs()
        );

        for (int r = 0; r < rows.size(); r++) {
            Row dataRow = sheet.createRow(rowIndex++);
            Map<String, Integer> rowData = rows.get(r);

            Cell labelCell = dataRow.createCell(0);
            labelCell.setCellValue(STRENGTH_ROW_LABELS.get(r));
            labelCell.setCellStyle(dataStyle);

            int rowTotal = 0;
            for (int c = 0; c < DESIGNATION_COLS.size(); c++) {
                int value = rowData.getOrDefault(DESIGNATION_COLS.get(c), 0);
                // For ACTUAL VACANCY row (r == 2), only count positive values for total
                if (r == 2) {
                    rowTotal += (value > 0 ? value : 0);
                } else {
                    rowTotal += value;
                }
                Cell cell = dataRow.createCell(c + 1);
                cell.setCellValue(value);
                cell.setCellStyle(numberStyle);
            }

            Cell totalCell = dataRow.createCell(DESIGNATION_COLS.size() + 1);
            totalCell.setCellValue(rowTotal);
            totalCell.setCellStyle(numberStyle);
        }

        return rowIndex;
    }

    // ======================== Sections (A-G) ========================

    private int writeSections(Sheet sheet, int rowIndex, List<SectionModel> sections,
                              CellStyle sectionHeaderStyle, CellStyle headerStyle,
                              CellStyle dataStyle, CellStyle numberStyle, CellStyle totalStyle) {
        for (SectionModel section : sections) {
            // Section header row (merged)
            Row sectionRow = sheet.createRow(rowIndex);
            Cell sectionCell = sectionRow.createCell(0);
            sectionCell.setCellValue(section.getSectionName());
            sectionCell.setCellStyle(sectionHeaderStyle);
            // Apply style to all merged cells
            for (int i = 1; i < TOTAL_SECTION_COLS; i++) {
                Cell c = sectionRow.createCell(i);
                c.setCellStyle(sectionHeaderStyle);
            }
            sheet.addMergedRegion(new CellRangeAddress(rowIndex, rowIndex, 0, TOTAL_SECTION_COLS - 1));
            rowIndex++;

            // Column header row
            Row colHeaderRow = sheet.createRow(rowIndex++);
            for (int i = 0; i < SECTION_HEADERS.size(); i++) {
                Cell cell = colHeaderRow.createCell(i);
                cell.setCellValue(SECTION_HEADERS.get(i));
                cell.setCellStyle(headerStyle);
            }

            // Subsections
            for (SubsectionModel subsection : section.getSubsections()) {
                // Subsection header row (merged, light gray)
                Row subHeaderRow = sheet.createRow(rowIndex);
                Cell subCell = subHeaderRow.createCell(0);
                subCell.setCellValue(subsection.getName());
                subCell.setCellStyle(headerStyle);
                for (int i = 1; i < TOTAL_SECTION_COLS; i++) {
                    Cell c = subHeaderRow.createCell(i);
                    c.setCellStyle(headerStyle);
                }
                sheet.addMergedRegion(new CellRangeAddress(rowIndex, rowIndex, 0, TOTAL_SECTION_COLS - 1));
                rowIndex++;

                // Data rows
                for (DutyRowModel dutyRow : subsection.getRows()) {
                    Row dataRow = sheet.createRow(rowIndex++);

                    // Column 0: serial# + description
                    Cell descCell = dataRow.createCell(0);
                    descCell.setCellValue(dutyRow.getSerialNumber() + ". " + dutyRow.getDutyDescription());
                    descCell.setCellStyle(dataStyle);

                    // Columns 1-7: counts (ACP, RPI, RSI, ARSI, AHC, APC, SWP)
                    int[] counts = dutyRow.getCounts();
                    for (int i = 0; i < counts.length; i++) {
                        Cell cell = dataRow.createCell(i + 1);
                        cell.setCellValue(counts[i]);
                        cell.setCellStyle(numberStyle);
                    }

                    // Column 8: total
                    Cell totCell = dataRow.createCell(8);
                    totCell.setCellValue(dutyRow.getTotal());
                    totCell.setCellStyle(numberStyle);

                    // Column 9: personnel details
                    Cell detailsCell = dataRow.createCell(9);
                    detailsCell.setCellValue(dutyRow.getPersonnelDetails() != null
                            ? dutyRow.getPersonnelDetails() : "");
                    detailsCell.setCellStyle(dataStyle);
                }

                // TOTAL row for subsection
                Row subTotalRow = sheet.createRow(rowIndex++);
                Cell totalLabelCell = subTotalRow.createCell(0);
                totalLabelCell.setCellValue("TOTAL");
                totalLabelCell.setCellStyle(totalStyle);

                int[] subTotal = subsection.getTotal();
                if (subTotal != null) {
                    for (int i = 0; i < Math.min(subTotal.length, 8); i++) {
                        Cell cell = subTotalRow.createCell(i + 1);
                        cell.setCellValue(subTotal[i]);
                        cell.setCellStyle(totalStyle);
                    }
                }

                Cell subTotalDetailsCell = subTotalRow.createCell(9);
                subTotalDetailsCell.setCellStyle(totalStyle);
            }

            // GRAND TOTAL row for section
            Row grandTotalRow = sheet.createRow(rowIndex++);
            Cell gtLabelCell = grandTotalRow.createCell(0);
            gtLabelCell.setCellValue("GRAND TOTAL");
            gtLabelCell.setCellStyle(totalStyle);

            int[] grandTotal = section.getGrandTotal();
            if (grandTotal != null) {
                for (int i = 0; i < Math.min(grandTotal.length, 8); i++) {
                    Cell cell = grandTotalRow.createCell(i + 1);
                    cell.setCellValue(grandTotal[i]);
                    cell.setCellStyle(totalStyle);
                }
            }

            Cell gtDetailsCell = grandTotalRow.createCell(9);
            gtDetailsCell.setCellStyle(totalStyle);
        }

        return rowIndex;
    }

    // ======================== Officer's Duty ========================

    private int writeOfficerDuty(Sheet sheet, int rowIndex, OfficerDutyModel officerDuty,
                                  CellStyle sectionHeaderStyle, CellStyle headerStyle,
                                  CellStyle dataStyle, CellStyle totalStyle, CellStyle numberStyle) {
        // Section header (merged, olive/green)
        Row sectionRow = sheet.createRow(rowIndex);
        Cell sectionCell = sectionRow.createCell(0);
        sectionCell.setCellValue("OFFICER'S DUTY");
        sectionCell.setCellStyle(sectionHeaderStyle);
        for (int i = 1; i < TOTAL_SECTION_COLS; i++) {
            Cell c = sectionRow.createCell(i);
            c.setCellStyle(sectionHeaderStyle);
        }
        sheet.addMergedRegion(new CellRangeAddress(rowIndex, rowIndex, 0, TOTAL_SECTION_COLS - 1));
        rowIndex++;

        // Subsections in 10-column format (VIP ESCORTS/PILOT, OTHER DUTY'S, LEAVE)
        if (officerDuty.getSubsections() != null) {
            for (SubsectionModel subsection : officerDuty.getSubsections()) {
                rowIndex = writeSubsection(sheet, rowIndex, subsection, sectionHeaderStyle, dataStyle, totalStyle, numberStyle);
            }
        }

        // SUB TOTAL row
        rowIndex = writeGrandTotalRow(sheet, rowIndex, "SUB TOTAL", officerDuty.getSubTotal(), totalStyle, numberStyle);

        // GRAND TOTAL (COMPANY) row
        rowIndex = writeGrandTotalRow(sheet, rowIndex, "GRAND TOTAL (COMPANY)", officerDuty.getGrandTotalCompany(), totalStyle, numberStyle);

        // UNDER TRAINING/WITHOUT TRAINING section header
        Row trainingHeaderRow = sheet.createRow(rowIndex);
        Cell trainingHeaderCell = trainingHeaderRow.createCell(0);
        trainingHeaderCell.setCellValue("UNDER TRAINING/WITHOUT TRAINING");
        trainingHeaderCell.setCellStyle(sectionHeaderStyle);
        for (int i = 1; i < TOTAL_SECTION_COLS; i++) {
            Cell c = trainingHeaderRow.createCell(i);
            c.setCellStyle(sectionHeaderStyle);
        }
        sheet.addMergedRegion(new CellRangeAddress(rowIndex, rowIndex, 0, TOTAL_SECTION_COLS - 1));
        rowIndex++;

        // Under training subsections
        if (officerDuty.getUnderTrainingSubsections() != null) {
            for (SubsectionModel subsection : officerDuty.getUnderTrainingSubsections()) {
                rowIndex = writeSubsection(sheet, rowIndex, subsection, sectionHeaderStyle, dataStyle, totalStyle, numberStyle);
            }
        }

        // TOTAL row for under training
        rowIndex = writeGrandTotalRow(sheet, rowIndex, "TOTAL", officerDuty.getUnderTrainingTotal(), totalStyle, numberStyle);

        // Under training LEAVE subsection
        if (officerDuty.getUnderTrainingLeave() != null) {
            rowIndex = writeSubsection(sheet, rowIndex, officerDuty.getUnderTrainingLeave(), sectionHeaderStyle, dataStyle, totalStyle, numberStyle);
        }

        // P.M.T row
        rowIndex = writeGrandTotalRow(sheet, rowIndex, "P.M.T", officerDuty.getPmtLine(), totalStyle, numberStyle);

        // GRAND TOTAL row
        rowIndex = writeGrandTotalRow(sheet, rowIndex, "GRAND TOTAL", officerDuty.getGrandTotal(), totalStyle, numberStyle);

        // Separate 4-column S.NO | NAME | DESIGNATION | DUTY table
        Row officerSectionRow = sheet.createRow(rowIndex);
        Cell officerSectionCell = officerSectionRow.createCell(0);
        officerSectionCell.setCellValue("OFFICER'S DUTY");
        officerSectionCell.setCellStyle(sectionHeaderStyle);
        for (int i = 1; i < 4; i++) {
            Cell c = officerSectionRow.createCell(i);
            c.setCellStyle(sectionHeaderStyle);
        }
        sheet.addMergedRegion(new CellRangeAddress(rowIndex, rowIndex, 0, 3));
        rowIndex++;

        // Header row: S.NO | NAME | DESIGNATION | DUTY
        Row headerRow = sheet.createRow(rowIndex++);
        String[] officerHeaders = {"S.NO", "NAME", "DESIGNATION", "DUTY"};
        for (int i = 0; i < officerHeaders.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(officerHeaders[i]);
            cell.setCellStyle(headerStyle);
        }

        // Officer data rows
        if (officerDuty.getOfficers() != null) {
            int serialNumber = 1;
            for (OfficerRow officer : officerDuty.getOfficers()) {
                Row dataRow = sheet.createRow(rowIndex++);

                Cell snoCell = dataRow.createCell(0);
                snoCell.setCellValue(serialNumber++);
                snoCell.setCellStyle(dataStyle);

                Cell nameCell = dataRow.createCell(1);
                nameCell.setCellValue(officer.getName() != null ? officer.getName() : "");
                nameCell.setCellStyle(dataStyle);

                Cell desigCell = dataRow.createCell(2);
                desigCell.setCellValue(officer.getDesignation() != null ? officer.getDesignation() : "");
                desigCell.setCellStyle(dataStyle);

                Cell dutyCell = dataRow.createCell(3);
                dutyCell.setCellValue(officer.getDuty() != null ? officer.getDuty() : "");
                dutyCell.setCellStyle(dataStyle);
            }
        }

        return rowIndex;
    }

    private int writeSubsection(Sheet sheet, int rowIndex, SubsectionModel subsection,
                                 CellStyle sectionHeaderStyle, CellStyle dataStyle,
                                 CellStyle totalStyle, CellStyle numberStyle) {
        // Subsection header row (merged)
        Row subHeaderRow = sheet.createRow(rowIndex);
        Cell subHeaderCell = subHeaderRow.createCell(0);
        subHeaderCell.setCellValue(subsection.getName());
        subHeaderCell.setCellStyle(sectionHeaderStyle);
        for (int i = 1; i < TOTAL_SECTION_COLS; i++) {
            Cell c = subHeaderRow.createCell(i);
            c.setCellStyle(sectionHeaderStyle);
        }
        sheet.addMergedRegion(new CellRangeAddress(rowIndex, rowIndex, 0, TOTAL_SECTION_COLS - 1));
        rowIndex++;

        // Data rows
        if (subsection.getRows() != null) {
            for (DutyRowModel dutyRow : subsection.getRows()) {
                Row row = sheet.createRow(rowIndex++);
                Cell headsCell = row.createCell(0);
                headsCell.setCellValue(dutyRow.getSerialNumber() + "  " + dutyRow.getDutyDescription());
                headsCell.setCellStyle(dataStyle);

                int[] counts = dutyRow.getCounts();
                for (int i = 0; i < 7; i++) {
                    Cell cell = row.createCell(i + 1);
                    cell.setCellValue(counts != null && i < counts.length ? counts[i] : 0);
                    cell.setCellStyle(numberStyle);
                }

                Cell totalCell = row.createCell(8);
                totalCell.setCellValue(dutyRow.getTotal());
                totalCell.setCellStyle(numberStyle);

                Cell detailsCell = row.createCell(9);
                detailsCell.setCellValue(dutyRow.getPersonnelDetails() != null ? dutyRow.getPersonnelDetails() : "");
                detailsCell.setCellStyle(dataStyle);
            }
        }

        // Total row
        if (subsection.getTotal() != null) {
            rowIndex = writeGrandTotalRow(sheet, rowIndex, "TOTAL", subsection.getTotal(), totalStyle, numberStyle);
        }

        return rowIndex;
    }

    private int writeGrandTotalRow(Sheet sheet, int rowIndex, String label, int[] values,
                                    CellStyle totalStyle, CellStyle numberStyle) {
        Row row = sheet.createRow(rowIndex++);
        Cell labelCell = row.createCell(0);
        labelCell.setCellValue(label);
        labelCell.setCellStyle(totalStyle);

        if (values != null) {
            for (int i = 0; i < Math.min(values.length, 8); i++) {
                Cell cell = row.createCell(i + 1);
                cell.setCellValue(values[i]);
                cell.setCellStyle(numberStyle);
            }
        }
        return rowIndex;
    }

    // ======================== Leave Statement ========================

    private int writeLeaveStatement(Sheet sheet, int rowIndex, LeaveStatementModel leaveStatement,
                                     CellStyle sectionHeaderStyle, CellStyle headerStyle,
                                     CellStyle dataStyle) {
        // Section header (merged, olive/green)
        Row sectionRow = sheet.createRow(rowIndex);
        Cell sectionCell = sectionRow.createCell(0);
        sectionCell.setCellValue("LEAVE STATEMENT");
        sectionCell.setCellStyle(sectionHeaderStyle);
        for (int i = 1; i < TOTAL_SECTION_COLS; i++) {
            Cell c = sectionRow.createCell(i);
            c.setCellStyle(sectionHeaderStyle);
        }
        sheet.addMergedRegion(new CellRangeAddress(rowIndex, rowIndex, 0, TOTAL_SECTION_COLS - 1));
        rowIndex++;

        // Header row: SL | BADGE/NAME | TYPE | DETAILS
        Row headerRow = sheet.createRow(rowIndex++);
        String[] leaveHeaders = {"SL", "BADGE/NAME", "TYPE", "DETAILS"};
        for (int i = 0; i < leaveHeaders.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(leaveHeaders[i]);
            cell.setCellStyle(headerStyle);
        }

        // Leave groups
        if (leaveStatement != null && leaveStatement.getGroups() != null) {
            for (LeaveGroup group : leaveStatement.getGroups()) {
                // Group type header row (gray)
                Row groupRow = sheet.createRow(rowIndex++);
                Cell groupCell = groupRow.createCell(0);
                groupCell.setCellValue(group.getType());
                groupCell.setCellStyle(headerStyle);
                for (int i = 1; i < 4; i++) {
                    Cell c = groupRow.createCell(i);
                    c.setCellStyle(headerStyle);
                }

                // Entry rows
                if (group.getEntries() != null) {
                    for (LeaveEntry entry : group.getEntries()) {
                        Row entryRow = sheet.createRow(rowIndex++);

                        Cell slCell = entryRow.createCell(0);
                        slCell.setCellValue(entry.getSerialNumber());
                        slCell.setCellStyle(dataStyle);

                        Cell badgeCell = entryRow.createCell(1);
                        badgeCell.setCellValue(entry.getBadgeOrName() != null ? entry.getBadgeOrName() : "");
                        badgeCell.setCellStyle(dataStyle);

                        Cell typeCell = entryRow.createCell(2);
                        typeCell.setCellValue(entry.getType() != null ? entry.getType() : "");
                        typeCell.setCellStyle(dataStyle);

                        Cell detailsCell = entryRow.createCell(3);
                        detailsCell.setCellValue(entry.getDetails() != null ? entry.getDetails() : "");
                        detailsCell.setCellStyle(dataStyle);
                    }
                }
            }
        }

        return rowIndex;
    }
}

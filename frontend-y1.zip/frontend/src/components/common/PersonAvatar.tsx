import React, { useState } from 'react';
import { Avatar, Box, Tooltip } from '@mui/material';

export interface PersonAvatarProps {
  name: string;
  photoUrl?: string;
  size?: 'small' | 'medium' | 'large';
  online?: boolean;
  rank?: React.ReactNode;
  badgeId?: string;
  designation?: string;
}

const SIZE_MAP: Record<'small' | 'medium' | 'large', number> = {
  small: 32,
  medium: 40,
  large: 56,
};

/**
 * PersonAvatar — displays a circular avatar with gradient background,
 * optional photo, online status dot, rank icon, and tooltip.
 *
 * Validates: Requirements 8.1–8.6, 8.9
 */
export const PersonAvatar: React.FC<PersonAvatarProps> = ({
  name,
  photoUrl,
  size = 'medium',
  online,
  rank,
  badgeId,
  designation,
}) => {
  const [imgError, setImgError] = useState(false);
  const px = SIZE_MAP[size];
  const initial = name.charAt(0).toUpperCase();

  const showPhoto = !!photoUrl && !imgError;

  // Build tooltip content: "Full Name\nBadge: {badgeId}\n{designation}"
  const tooltipLines: string[] = [name];
  if (badgeId) tooltipLines.push(`Badge: ${badgeId}`);
  if (designation) tooltipLines.push(designation);
  const tooltipContent = tooltipLines.join('\n');

  return (
    <Tooltip
      title={
        <span style={{ whiteSpace: 'pre-line' }}>
          {tooltipContent}
        </span>
      }
      enterDelay={400}
      arrow
    >
      <Box
        sx={{
          position: 'relative',
          display: 'inline-flex',
          width: px,
          height: px,
          flexShrink: 0,
        }}
      >
        {/* Main Avatar */}
        <Avatar
          src={showPhoto ? photoUrl : '/police-avatar.svg'}
          alt={name}
          imgProps={{
            onError: () => setImgError(true),
          }}
          sx={{
            width: px,
            height: px,
            fontSize: px * 0.4,
            fontWeight: 600,
            background: 'linear-gradient(135deg, #312e81 0%, #0d9488 100%)',
            color: '#ffffff',
          }}
        >
          {/* Final fallback: initial letter (shown only if SVG also fails) */}
          {initial}
        </Avatar>

        {/* Online status dot */}
        {online !== undefined && (
          <Box
            sx={{
              position: 'absolute',
              bottom: 0,
              right: 0,
              width: 10,
              height: 10,
              borderRadius: '50%',
              backgroundColor: online ? '#059669' : '#94a3b8',
              border: '2px solid #ffffff',
              boxSizing: 'content-box',
            }}
          />
        )}

        {/* Rank indicator */}
        {rank && (
          <Box
            sx={{
              position: 'absolute',
              top: 0,
              right: 0,
              width: 16,
              height: 16,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              '& > *': {
                width: 16,
                height: 16,
                fontSize: 16,
              },
            }}
          >
            {rank}
          </Box>
        )}
      </Box>
    </Tooltip>
  );
};

/**
 * PersonAvatarGroup — displays a group of overlapping avatars with
 * an optional "+N" overflow indicator and expand-on-hover animation.
 *
 * Validates: Requirements 8.7, 8.8
 */
export interface PersonAvatarGroupProps {
  persons: PersonAvatarProps[];
  max?: number; // default 4
}

export const PersonAvatarGroup: React.FC<PersonAvatarGroupProps> = ({
  persons,
  max = 4,
}) => {
  const visiblePersons = persons.slice(0, max);
  const overflowCount = persons.length - max;

  return (
    <Box
      sx={{
        display: 'inline-flex',
        alignItems: 'center',
        '&:hover .avatar-group-item': {
          marginLeft: '-4px',
        },
      }}
    >
      {visiblePersons.map((person, index) => (
        <Box
          key={`${person.name}-${index}`}
          className="avatar-group-item"
          sx={{
            marginLeft: index === 0 ? 0 : '-8px',
            transition: 'margin-left 200ms ease-out',
            position: 'relative',
            zIndex: visiblePersons.length - index,
          }}
        >
          <PersonAvatar {...person} />
        </Box>
      ))}

      {overflowCount > 0 && (
        <Box
          className="avatar-group-item"
          sx={{
            marginLeft: '-8px',
            transition: 'margin-left 200ms ease-out',
            width: 40,
            height: 40,
            borderRadius: '50%',
            backgroundColor: '#e2e8f0',
            border: '2px solid #ffffff',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: 13,
            fontWeight: 600,
            color: '#334155',
            position: 'relative',
            zIndex: 0,
            flexShrink: 0,
          }}
          aria-label={`${overflowCount} more people`}
        >
          +{overflowCount}
        </Box>
      )}
    </Box>
  );
};

export default PersonAvatar;

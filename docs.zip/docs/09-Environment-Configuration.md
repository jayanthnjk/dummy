# Environment Configuration Guide
## KSP WorkBoard — Police Station Management System

| Field | Details |
|-------|---------|
| **Document Title** | Environment Configuration & Variables |
| **Version** | 1.0.0 |
| **Date** | June 2026 |

---

## 1. Overview

KSP WorkBoard uses environment variables for all configuration that varies between environments. Configuration is loaded from:
- **Local development:** `.env` file in backend root (auto-loaded by Gradle `bootRun` task)
- **Production:** systemd service environment variables in `/etc/systemd/system/ksp-backend.service`

---

## 2. Complete Environment Variables Reference

### 2.1 Database Configuration

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `DB_URL` | ✅ Yes | — | JDBC PostgreSQL connection URL |
| `DB_USERNAME` | ✅ Yes | — | Database username |
| `DB_PASSWORD` | ✅ Yes | — | Database password |

**Format:** `jdbc:postgresql://<host>:<port>/<database>`

**Examples:**
```bash
# Local
DB_URL=jdbc:postgresql://localhost:5432/ksp_workboard
DB_USERNAME=postgres
DB_PASSWORD=mysecretpassword

# Production (RDS)
DB_URL=jdbc:postgresql://ksp-postgres.cxyz.us-east-1.rds.amazonaws.com:5432/ksp_workboard
DB_USERNAME=ksp_admin
DB_PASSWORD=StrongProd!Pass123
```

---

### 2.2 Security Configuration

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `JWT_SECRET` | ✅ Yes | — | Secret key for JWT token signing (min 32 chars) |
| `JWT_EXPIRATION_MS` | No | 86400000 | Token expiry in milliseconds (24 hours) |

**Generate JWT Secret:**
```bash
openssl rand -base64 48
# Output: aB3kF9mPqR7sT2vXwY1zL5nH8jU6iO4pK0qW3eR9tD2fG7hJ1kM5nB8vC4xZ6a
```

---

### 2.3 AI Provider Configuration

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `AI_PROVIDER` | No | `groq` | AI backend: `groq` or `bedrock` |
| `GROQ_API_KEY` | Conditional | — | Required if AI_PROVIDER=groq |
| `GROQ_API_URL` | No | `https://api.groq.com/openai/v1` | Groq API base URL |
| `GROQ_MODEL` | No | `llama-3.3-70b-versatile` | LLM model name |
| `AWS_REGION` | No | `us-east-1` | AWS region for Bedrock |
| `BEDROCK_MODEL_ID` | No | `amazon.nova-lite-v1:0` | Bedrock model identifier |

**Provider Selection Logic:**
- `AI_PROVIDER=groq` → Uses Groq REST API with API key authentication
- `AI_PROVIDER=bedrock` → Uses AWS SDK with IAM role authentication (no API key needed on EC2)

---

### 2.4 Server Configuration

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `SERVER_PORT` | No | `8080` | HTTP port for Spring Boot |
| `SPRING_PROFILES_ACTIVE` | No | `local` | Active Spring profile |
| `CORS_ALLOWED_ORIGINS` | No | `http://localhost:5173` | Comma-separated allowed origins |

**CORS Examples:**
```bash
# Local development
CORS_ALLOWED_ORIGINS=http://localhost:5173

# Production (CloudFront)
CORS_ALLOWED_ORIGINS=https://dtszoaal8ujla.cloudfront.net

# Multiple origins
CORS_ALLOWED_ORIGINS=https://app.police.gov.in,https://d1234.cloudfront.net
```

---

### 2.5 Rate Limiting Configuration

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `CHAT_RATE_LIMIT_GENERAL` | No | `30` | Max general chat requests per user per window |
| `CHAT_RATE_LIMIT_LLM` | No | `20` | Max LLM-invoking requests per user per window |

---

## 3. Local Development .env File

```bash
# =============================================================================
# KSP Workboard - Local Environment Variables
# =============================================================================
# Copy .env.example to .env and fill in YOUR values
# =============================================================================

# --- Database ---
DB_URL=jdbc:postgresql://localhost:5432/ksp_workboard
DB_USERNAME=postgres
DB_PASSWORD=your_database_password

# --- JWT ---
JWT_SECRET=your-local-jwt-secret-at-least-32-characters-long-for-security

# --- AI Provider (groq for local dev) ---
AI_PROVIDER=groq
GROQ_API_KEY=gsk_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# --- Spring Profile ---
SPRING_PROFILES_ACTIVE=local

# --- CORS (Vite dev server) ---
CORS_ALLOWED_ORIGINS=http://localhost:5173
```

---

## 4. Production systemd Environment

```ini
# In /etc/systemd/system/ksp-backend.service [Service] section:

# Database
Environment=DB_URL=jdbc:postgresql://ksp-postgres.cxyz.us-east-1.rds.amazonaws.com:5432/ksp_workboard
Environment=DB_USERNAME=ksp_admin
Environment=DB_PASSWORD=ProductionStrongPassword123!

# JWT
Environment=JWT_SECRET=aB3kF9mPqR7sT2vXwY1zL5nH8jU6iO4pK0qW3eR9tD2fG7hJ1kM5nB8vC4xZ6a

# AI (Bedrock - uses EC2 IAM role, no API key)
Environment=AI_PROVIDER=bedrock
Environment=AWS_REGION=us-east-1
Environment=BEDROCK_MODEL_ID=amazon.nova-lite-v1:0
Environment=GROQ_API_KEY=
Environment=GROQ_API_URL=https://api.groq.com/openai/v1

# CORS
Environment=CORS_ALLOWED_ORIGINS=https://dtszoaal8ujla.cloudfront.net
```

---

## 5. Frontend Environment Variables

### 5.1 Development (.env)

```bash
VITE_API_URL=http://localhost:8080
```

### 5.2 Production (.env.production)

```bash
VITE_API_URL=http://<EC2-PUBLIC-IP>:8080
```

Note: In production with CloudFront, API calls are routed through CloudFront behavior rules to the EC2 backend.

---

## 6. Configuration Validation Checklist

| # | Check | Command | Expected |
|---|-------|---------|----------|
| 1 | DB connectivity | `psql -h <host> -U <user> -d ksp_workboard -c "SELECT 1"` | Returns 1 |
| 2 | pgvector extension | `psql -c "SELECT extversion FROM pg_extension WHERE extname='vector'"` | Returns version |
| 3 | Java version | `java -version` | 17.x.x |
| 4 | Backend starts | `curl http://localhost:8080/api/health` | `{"status":"UP"}` |
| 5 | AI connected | `curl http://localhost:8080/api/health/ai` | `{"connected":true}` |
| 6 | JWT works | POST /api/auth/login with valid creds | Returns token |
| 7 | CORS works | Frontend can call backend without errors | No CORS errors in console |

---

## 7. Secrets Management

| Secret | Storage Location | Rotation |
|--------|-----------------|----------|
| DB_PASSWORD | systemd env / .env (never committed) | Quarterly recommended |
| JWT_SECRET | systemd env / .env | On security incident |
| GROQ_API_KEY | systemd env / .env | On compromise |
| AWS Credentials | EC2 IAM Role (auto-rotated) | Automatic |

**Security Rules:**
- `.env` file is in `.gitignore` — never committed to source control
- Production credentials only in systemd service file (readable only by root)
- AWS Bedrock uses IAM roles — no static credentials needed on EC2

---

*End of Document — Environment Configuration v1.0.0*

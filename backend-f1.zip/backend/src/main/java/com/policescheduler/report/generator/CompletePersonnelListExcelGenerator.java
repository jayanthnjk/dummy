package com.policescheduler.report.generator;

import com.policescheduler.entity.Personnel;
import com.policescheduler.report.ReportGenerationException;
import com.policescheduler.repository.PersonnelRepository;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Complete Personnel List Excel Generator - combines both CAR and MT units.
 * Uses same styling as existing PersonnelListExcelGenerator.
 */
@Service
public class CompletePersonnelListExcelGenerator {

    private static final Logger log = LoggerFactory.getLogger(CompletePersonnelListExcelGenerator.class);

    private static final String REPORT_TITLE = "Complete Personnel List";
    private static final String REPORT_SUBTITLE = "CAR and MT Units Combined";
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    // Designation priority order for sorting
    private static final Map<String, Integer> DESIGNATION_PRIORITY = Map.of(
            "DCP", 1,
            "ACP", 2,
            "RPI", 3,
            "RSI", 4,
            "ARSI", 5,
            "AHC", 6,
            "APC", 7
    );

    private final PersonnelRepository personnelRepository;

    public CompletePersonnelListExcelGenerator(PersonnelRepository personnelRepository) {
        this.personnelRepository = personnelRepository;
    }

    public byte[] generate() {
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Personnel List");

            // Create styles - matching existing PersonnelListExcelGenerator
            CellStyle titleStyle = createTitleStyle(workbook);
            CellStyle subtitleStyle = createSubtitleStyle(workbook);
            CellStyle headerStyle = createHeaderStyle(workbook);
            CellStyle dataStyle = createDataStyle(workbook);
            CellStyle wrapDataStyle = createWrapDataStyle(workbook);

            // Fetch all active personnel from both CAR and MT units
            List<Personnel> allPersonnel = personnelRepository.findAll().stream()
                    .filter(p -> Boolean.TRUE.equals(p.getIsActive()))
                    .collect(Collectors.toList());

            // Sort by unit (CAR first, then MT), then by designation priority, then by badge_id
            allPersonnel.sort(Comparator
                    .<Personnel, Integer>comparing(p -> "MT".equalsIgnoreCase(p.getUnit()) ? 1 : 0)
                    .thenComparing(p -> DESIGNATION_PRIORITY.getOrDefault(
                            p.getDesignation() != null ? p.getDesignation().toUpperCase() : "", 99))
                    .thenComparing(p -> p.getBadgeId() != null ? p.getBadgeId() : ""));

            int rowIndex = 0;

            // Title row
            Row titleRow = sheet.createRow(rowIndex++);
            Cell titleCell = titleRow.createCell(0);
            titleCell.setCellValue(REPORT_TITLE);
            titleCell.setCellStyle(titleStyle);
            sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 11));

            // Subtitle row
            Row subtitleRow = sheet.createRow(rowIndex++);
            Cell subtitleCell = subtitleRow.createCell(0);
            subtitleCell.setCellValue(REPORT_SUBTITLE + " | Generated on " + LocalDate.now().format(DATE_FORMAT));
            subtitleCell.setCellStyle(subtitleStyle);
            sheet.addMergedRegion(new CellRangeAddress(1, 1, 0, 11));

            rowIndex++; // blank row

            // Column headers
            String[] headers = {
                "S.No", "Name", "Designation", "Date of Birth", "Date of Joining",
                "KGID No.", "Blood Group", "Qualification", "Permanent Address",
                "Present Address", "Contact No.", "Native Police Station"
            };
            
            Row headerRow = sheet.createRow(rowIndex++);
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // Data rows
            int slNo = 1;
            for (Personnel p : allPersonnel) {
                Row row = sheet.createRow(rowIndex++);
                int col = 0;
                
                createCell(row, col++, String.valueOf(slNo++), dataStyle);
                createCell(row, col++, safe(p.getPersonName()), dataStyle);
                createCell(row, col++, safe(p.getDesignation()), dataStyle);
                createCell(row, col++, formatDate(p.getDateOfBirth()), dataStyle);
                createCell(row, col++, formatDate(p.getDateOfJoining()), dataStyle);
                createCell(row, col++, safe(p.getBadgeId()), dataStyle);
                createCell(row, col++, safe(p.getBloodGroup()), dataStyle);
                createCell(row, col++, safe(p.getQualification()), wrapDataStyle);
                createCell(row, col++, safe(p.getPermanentAddress()), wrapDataStyle);
                createCell(row, col++, safe(p.getPresentAddress()), wrapDataStyle);
                createCell(row, col++, safe(p.getPhoneNumber()), dataStyle);
                createCell(row, col++, safe(p.getNativePoliceStation()), wrapDataStyle);
            }

            // Summary row
            rowIndex++;
            Row summaryRow = sheet.createRow(rowIndex);
            Cell summaryCell = summaryRow.createCell(0);
            summaryCell.setCellValue("Total Personnel: " + allPersonnel.size());
            summaryCell.setCellStyle(createSummaryStyle(workbook));

            // Add Abstract Table - Count by Designation
            rowIndex += 3; // Add spacing

            // Abstract title
            Row abstractTitleRow = sheet.createRow(rowIndex++);
            Cell abstractTitleCell = abstractTitleRow.createCell(0);
            abstractTitleCell.setCellValue("Abstract - Personnel Count by Designation");
            abstractTitleCell.setCellStyle(createSummaryStyle(workbook));

            rowIndex++; // blank row

            // Calculate counts by designation
            Map<String, Long> designationCounts = allPersonnel.stream()
                    .collect(Collectors.groupingBy(
                            p -> p.getDesignation() != null && !p.getDesignation().isBlank() 
                                    ? p.getDesignation().toUpperCase() : "UNASSIGNED",
                            Collectors.counting()));

            // Abstract table headers
            Row abstractHeaderRow = sheet.createRow(rowIndex++);
            Cell desigHeaderCell = abstractHeaderRow.createCell(0);
            desigHeaderCell.setCellValue("Designation");
            desigHeaderCell.setCellStyle(headerStyle);
            
            Cell countHeaderCell = abstractHeaderRow.createCell(1);
            countHeaderCell.setCellValue("Count");
            countHeaderCell.setCellStyle(headerStyle);

            // Add rows in designation priority order
            String[] designationOrder = {"DCP", "ACP", "RPI", "RSI", "ARSI", "AHC", "APC"};
            long totalCount = 0;
            
            for (String desig : designationOrder) {
                long count = designationCounts.getOrDefault(desig, 0L);
                if (count > 0) {
                    Row dataRow = sheet.createRow(rowIndex++);
                    createCell(dataRow, 0, desig, dataStyle);
                    createCell(dataRow, 1, String.valueOf(count), dataStyle);
                    totalCount += count;
                }
            }

            // Add any other designations not in the standard list
            for (Map.Entry<String, Long> entry : designationCounts.entrySet()) {
                String desig = entry.getKey();
                if (!Arrays.asList(designationOrder).contains(desig)) {
                    Row dataRow = sheet.createRow(rowIndex++);
                    createCell(dataRow, 0, desig, dataStyle);
                    createCell(dataRow, 1, String.valueOf(entry.getValue()), dataStyle);
                    totalCount += entry.getValue();
                }
            }

            // Total row
            CellStyle totalStyle = createTotalStyle(workbook);
            Row totalRow = sheet.createRow(rowIndex++);
            createCell(totalRow, 0, "TOTAL", totalStyle);
            createCell(totalRow, 1, String.valueOf(totalCount), totalStyle);

            // Set column widths
            int[] columnWidths = {
                2000,  // S.No
                7000,  // Name
                3000,  // Designation
                3500,  // DOB
                3500,  // DOJ
                4000,  // KGID
                3000,  // Blood Group
                6000,  // Qualification
                8000,  // Permanent Address
                8000,  // Present Address
                4000,  // Contact No
                6000   // Native Police Station
            };
            for (int i = 0; i < columnWidths.length; i++) {
                sheet.setColumnWidth(i, columnWidths[i]);
            }

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            workbook.write(baos);
            return baos.toByteArray();
        } catch (Exception e) {
            log.error("Failed to generate Complete Personnel List Excel report", e);
            throw new ReportGenerationException("complete_personnel_list_excel",
                    "Failed to generate Complete Personnel List Excel report", e);
        }
    }

    private void createCell(Row row, int col, String value, CellStyle style) {
        Cell cell = row.createCell(col);
        cell.setCellValue(value);
        cell.setCellStyle(style);
    }

    private String formatDate(LocalDate date) {
        if (date == null) return "-";
        return date.format(DATE_FORMAT);
    }

    private String safe(String value) {
        return value != null && !value.isBlank() ? value : "-";
    }

    private CellStyle createTitleStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 12);
        style.setFont(font);
        return style;
    }

    private CellStyle createSubtitleStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 9);
        font.setColor(IndexedColors.GREY_50_PERCENT.getIndex());
        style.setFont(font);
        return style;
    }

    private CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 9);
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    private CellStyle createDataStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 8);
        style.setFont(font);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    private CellStyle createWrapDataStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 8);
        style.setFont(font);
        style.setAlignment(HorizontalAlignment.LEFT);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        style.setWrapText(true); // Enable text wrapping
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    private CellStyle createSummaryStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 10);
        style.setFont(font);
        style.setAlignment(HorizontalAlignment.LEFT);
        return style;
    }

    private CellStyle createTotalStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 9);
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }
}

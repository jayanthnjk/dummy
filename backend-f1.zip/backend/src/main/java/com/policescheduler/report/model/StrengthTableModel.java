package com.policescheduler.report.model;

import lombok.Builder;
import lombok.Data;

import java.util.Map;

@Data
@Builder
public class StrengthTableModel {
    private Map<String, Integer> sanctionedStrength;
    private Map<String, Integer> presentStrengthTotal;
    private Map<String, Integer> actualVacancy;
    private Map<String, Integer> presentStrengthPmt;
    private Map<String, Integer> presentStrengthCompany;
    private Map<String, Integer> recruitApcs;

    public int getRowTotal(Map<String, Integer> row) {
        return row.values().stream().mapToInt(Integer::intValue).sum();
    }
}

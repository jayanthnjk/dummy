package com.policescheduler.repository;

import com.policescheduler.entity.ReportSpecificEmailConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ReportSpecificEmailConfigRepository extends JpaRepository<ReportSpecificEmailConfig, Long> {

    Optional<ReportSpecificEmailConfig> findByReportType(String reportType);

    List<ReportSpecificEmailConfig> findAllByOrderByReportNameAsc();

    boolean existsByReportType(String reportType);

    /**
     * Find all scheduled report configs that are due to run.
     * Checks if:
     * - is_schedule_enabled = true
     * - schedule_time matches the provided time (HH:mm format)
     * - schedule_days contains the provided day (SUN, MON, TUE, etc.)
     */
    @Query("SELECT r FROM ReportSpecificEmailConfig r WHERE r.isScheduleEnabled = true " +
           "AND r.scheduleTime = :scheduleTime " +
           "AND r.scheduleDays LIKE %:dayOfWeek%")
    List<ReportSpecificEmailConfig> findScheduledReportsDue(
            @Param("scheduleTime") String scheduleTime,
            @Param("dayOfWeek") String dayOfWeek);

    /**
     * Find all configs where scheduling is enabled.
     */
    List<ReportSpecificEmailConfig> findByIsScheduleEnabledTrue();
}

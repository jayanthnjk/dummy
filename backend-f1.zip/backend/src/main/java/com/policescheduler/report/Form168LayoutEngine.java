package com.policescheduler.report;

import com.policescheduler.entity.LeaveRequest;
import com.policescheduler.entity.Personnel;
import com.policescheduler.entity.SanctionedStrength;
import com.policescheduler.entity.SectionStrength;
import com.policescheduler.report.model.*;
import com.policescheduler.repository.DutyAssignmentRepository;
import com.policescheduler.repository.DutyTypeRepository;
import com.policescheduler.repository.LeaveRequestRepository;
import com.policescheduler.repository.PersonnelRepository;
import com.policescheduler.repository.SanctionedStrengthRepository;
import com.policescheduler.repository.SectionStrengthRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Core data transformation service that loads personnel/duties/leave from repositories
 * and structures them into the Form168ReportModel for PDF/Excel rendering.
 */
@Service
public class Form168LayoutEngine {

    private static final Logger log = LoggerFactory.getLogger(Form168LayoutEngine.class);
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    private static final List<String> DESIGNATION_COLS = List.of("DCP", "ACP", "RPI", "RSI", "ARSI", "AHC", "APC");

    private final PersonnelRepository personnelRepository;
    private final DutyAssignmentRepository dutyAssignmentRepository;
    private final DutyTypeRepository dutyTypeRepository;
    private final LeaveRequestRepository leaveRequestRepository;
    private final SectionStrengthRepository sectionStrengthRepository;
    private final SanctionedStrengthRepository sanctionedStrengthRepository;
    private final com.policescheduler.service.ReassignmentResolverService reassignmentResolverService;

    public Form168LayoutEngine(PersonnelRepository personnelRepository,
                               DutyAssignmentRepository dutyAssignmentRepository,
                               DutyTypeRepository dutyTypeRepository,
                               LeaveRequestRepository leaveRequestRepository,
                               SectionStrengthRepository sectionStrengthRepository,
                               SanctionedStrengthRepository sanctionedStrengthRepository,
                               com.policescheduler.service.ReassignmentResolverService reassignmentResolverService) {
        this.personnelRepository = personnelRepository;
        this.dutyAssignmentRepository = dutyAssignmentRepository;
        this.dutyTypeRepository = dutyTypeRepository;
        this.leaveRequestRepository = leaveRequestRepository;
        this.sectionStrengthRepository = sectionStrengthRepository;
        this.sanctionedStrengthRepository = sanctionedStrengthRepository;
        this.reassignmentResolverService = reassignmentResolverService;
    }

    /**
     * Main entry point: builds the complete Form168 report model for the given date.
     */
    public Form168ReportModel buildReportModel(LocalDate reportDate) {
        log.info("Building Form168 report model for date: {}", reportDate);

        List<Personnel> allPersonnel = personnelRepository.findAll().stream()
                .filter(p -> p.getIsActive() != null && p.getIsActive())
                .collect(Collectors.toList());

        List<LeaveRequest> activeLeaves = leaveRequestRepository.findAll().stream()
                .filter(lr -> "APPROVED".equals(lr.getStatus()))
                .filter(lr -> !lr.getStartDate().isAfter(reportDate) && (lr.getEndDate() == null || !lr.getEndDate().isBefore(reportDate)))
                .collect(Collectors.toList());

        Set<Long> onLeaveIds = activeLeaves.stream()
                .map(LeaveRequest::getPersonnelId)
                .collect(Collectors.toSet());

        return Form168ReportModel.builder()
                .reportDate(reportDate)
                .strengthTable(buildStrengthTable(reportDate, allPersonnel, onLeaveIds))
                .sections(buildAllSections(allPersonnel, activeLeaves, onLeaveIds, reportDate))
                .officerDuty(buildOfficerDuty(allPersonnel, activeLeaves, onLeaveIds, reportDate))
                .leaveStatement(buildLeaveStatement(allPersonnel, activeLeaves, reportDate))
                .build();
    }

    // ========== STRENGTH TABLE ==========

    private StrengthTableModel buildStrengthTable(LocalDate reportDate, List<Personnel> allPersonnel, Set<Long> onLeaveIds) {
        // Separate personnel by unit
        List<Personnel> carPersonnel = allPersonnel.stream()
                .filter(p -> !"MT".equalsIgnoreCase(p.getUnit()))
                .filter(p -> !"TRAINING".equalsIgnoreCase(p.getSection()))
                .collect(Collectors.toList());

        List<Personnel> carWithTraining = allPersonnel.stream()
                .filter(p -> !"MT".equalsIgnoreCase(p.getUnit()))
                .collect(Collectors.toList());

        List<Personnel> mtPersonnel = allPersonnel.stream()
                .filter(p -> "MT".equalsIgnoreCase(p.getUnit()))
                .collect(Collectors.toList());

        // TRAINING section personnel (for RECRUIT APC'S row)
        List<Personnel> trainingPersonnel = allPersonnel.stream()
                .filter(p -> "TRAINING".equalsIgnoreCase(p.getSection()))
                .collect(Collectors.toList());

        Map<String, Integer> sanctionedRow = new LinkedHashMap<>();
        Map<String, Integer> presentRow = new LinkedHashMap<>();
        Map<String, Integer> vacancyRow = new LinkedHashMap<>();
        Map<String, Integer> pmtRow = new LinkedHashMap<>();
        Map<String, Integer> companyRow = new LinkedHashMap<>();
        Map<String, Integer> recruitRow = new LinkedHashMap<>();

        // ROW 1: C.A.R SANCTIONED STRENGTH - Get from sanctioned_strength table
        Map<String, Integer> sanctionedFromDb = new HashMap<>();
        try {
            List<SanctionedStrength> sanctionedList = sanctionedStrengthRepository.findAllByOrderByDisplayOrderAsc();
            for (SanctionedStrength ss : sanctionedList) {
                sanctionedFromDb.put(ss.getDesignation().toUpperCase().trim(), ss.getSanctionedCount());
            }
        } catch (Exception e) {
            log.warn("Failed to load sanctioned strength from database, using fallback", e);
        }

        // ROW 2: PRESENT STRENGTH TOTAL - Computed from active personnel count (CAR + MT combined)
        Map<String, Long> presentByDesig = allPersonnel.stream()
                .filter(p -> p.getDesignation() != null)
                .collect(Collectors.groupingBy(p -> p.getDesignation().toUpperCase().trim(), Collectors.counting()));

        Map<String, Long> mtByDesig = mtPersonnel.stream()
                .filter(p -> p.getDesignation() != null)
                .collect(Collectors.groupingBy(p -> p.getDesignation().toUpperCase().trim(), Collectors.counting()));

        Map<String, Long> companyByDesig = carPersonnel.stream()
                .filter(p -> p.getDesignation() != null)
                .collect(Collectors.groupingBy(p -> p.getDesignation().toUpperCase().trim(), Collectors.counting()));

        Map<String, Long> recruitByDesig = trainingPersonnel.stream()
                .filter(p -> p.getDesignation() != null)
                .collect(Collectors.groupingBy(p -> p.getDesignation().toUpperCase().trim(), Collectors.counting()));

        for (String col : DESIGNATION_COLS) {
            // ROW 1: Sanctioned from DB
            int sanctioned = sanctionedFromDb.getOrDefault(col, 0);
            sanctionedRow.put(col, sanctioned);
            
            // ROW 2: Present from personnel count
            int present = presentByDesig.getOrDefault(col, 0L).intValue();
            presentRow.put(col, present);
            
            // ROW 3: Vacancy = Sanctioned - Present (show actual value including negatives per cell)
            // TOTAL will only sum positive values (handled in PDF/Excel generators)
            int vacancy = sanctioned - present;
            vacancyRow.put(col, vacancy);
            
            // Other rows
            int mtCount = mtByDesig.getOrDefault(col, 0L).intValue();
            pmtRow.put(col, mtCount);
            companyRow.put(col, companyByDesig.getOrDefault(col, 0L).intValue());
            recruitRow.put(col, recruitByDesig.getOrDefault(col, 0L).intValue());
        }

        return StrengthTableModel.builder()
                .sanctionedStrength(sanctionedRow)
                .presentStrengthTotal(presentRow)
                .actualVacancy(vacancyRow)
                .presentStrengthPmt(pmtRow)
                .presentStrengthCompany(companyRow)
                .recruitApcs(recruitRow)
                .build();
    }

    // ========== SECTION BUILDERS ==========

    private List<SectionModel> buildAllSections(List<Personnel> allPersonnel,
                                                 List<LeaveRequest> activeLeaves,
                                                 Set<Long> onLeaveIds,
                                                 LocalDate reportDate) {
        List<SectionModel> sections = new ArrayList<>();
        String[] sectionCodes = {"A", "B", "C", "D", "E", "F", "G"};
        for (String code : sectionCodes) {
            sections.add(buildSectionFromDb(code, allPersonnel, activeLeaves, onLeaveIds));
        }
        return sections;
    }

    /**
     * Returns a set of ALL leave-related personnel IDs: those with approved leave records
     * OR those with duty-based leave indicators (ABSENT, SUSPENSION, SICK, WEEKLY OFF, PERMISSION).
     */
    private Set<Long> getAllLeaveRelatedIds(List<Personnel> sectionPersonnel, Set<Long> onLeaveIds) {
        Set<Long> allLeaveIds = new HashSet<>(onLeaveIds);
        for (Personnel p : sectionPersonnel) {
            if (allLeaveIds.contains(p.getId())) continue;
            String dt = p.getDutyType() != null ? p.getDutyType().toUpperCase().trim() : "";
            String dl = p.getDutyLocation() != null ? p.getDutyLocation().toUpperCase().trim() : "";
            if (dt.contains("ABSENT") || dt.contains("SUSPENSION") || dt.contains("SICK")
                || dt.contains("WEEKLY OFF") || dt.contains("W/OFF") || dt.contains("PERMISSION")
                || dl.contains("ABSENT") || dl.contains("SUSPENSION") || dl.contains("SICK")
                || dl.contains("WEEKLY OFF") || dl.contains("W/OFF") || dl.contains("PERMISSION")) {
                allLeaveIds.add(p.getId());
            }
        }
        return allLeaveIds;
    }

    /**
     * DB-driven section builder: reads parent duty types from duty_types table,
     * groups personnel by duty_type and duty_location fields — same logic as form168-view endpoint.
     */
    private SectionModel buildSectionFromDb(String sectionCode, List<Personnel> allPersonnel,
                                             List<LeaveRequest> activeLeaves, Set<Long> onLeaveIds) {
        List<Personnel> sectionPersonnel = allPersonnel.stream()
                .filter(p -> belongsToSection(p, sectionCode))
                .collect(Collectors.toList());

        // Apply reassignment resolution: show effective duty holders
        sectionPersonnel = reassignmentResolverService.resolveForSection(sectionPersonnel, sectionCode, LocalDate.now());

        Set<Long> allLeaveIds = getAllLeaveRelatedIds(sectionPersonnel, onLeaveIds);
        List<Personnel> onDutySection = sectionPersonnel.stream()
                .filter(p -> !allLeaveIds.contains(p.getId()))
                .collect(Collectors.toList());

        List<com.policescheduler.entity.DutyType> parentDutyTypes =
                dutyTypeRepository.findBySectionAndParentIsNullOrderBySortOrderAsc(sectionCode);

        Map<String, List<Personnel>> personnelByDutyType = onDutySection.stream()
                .filter(p -> p.getDutyType() != null && !p.getDutyType().isBlank())
                .collect(Collectors.groupingBy(p -> p.getDutyType().toUpperCase().trim()));

        Set<Long> assignedIds = new HashSet<>();
        List<SubsectionModel> subsections = new ArrayList<>();

        for (com.policescheduler.entity.DutyType parent : parentDutyTypes) {
            String parentName = parent.getName().toUpperCase().trim();
            List<Personnel> dutyPersonnel = new ArrayList<>(personnelByDutyType.getOrDefault(parentName, List.of()));
            Set<Long> existingIds = dutyPersonnel.stream().map(Personnel::getId).collect(Collectors.toSet());

            for (Personnel p : onDutySection) {
                if (existingIds.contains(p.getId())) continue;
                if (p.getDutyTypeEntity() != null && p.getDutyTypeEntity().getId().equals(parent.getId())) {
                    dutyPersonnel.add(p); existingIds.add(p.getId());
                }
            }
            List<com.policescheduler.entity.DutyType> childDutyTypes =
                    dutyTypeRepository.findByParentIdOrderBySortOrderAsc(parent.getId());
            Set<Long> childIds = childDutyTypes.stream().map(com.policescheduler.entity.DutyType::getId).collect(Collectors.toSet());
            if (!childIds.isEmpty()) {
                for (Personnel p : onDutySection) {
                    if (existingIds.contains(p.getId())) continue;
                    if (p.getDutyTypeEntity() != null && childIds.contains(p.getDutyTypeEntity().getId())) {
                        dutyPersonnel.add(p); existingIds.add(p.getId());
                    }
                }
            }
            dutyPersonnel = dutyPersonnel.stream().filter(p -> !assignedIds.contains(p.getId())).collect(Collectors.toList());
            for (Personnel p : dutyPersonnel) { assignedIds.add(p.getId()); }

            Map<String, List<Personnel>> byLocation = new LinkedHashMap<>();
            List<Personnel> noLoc = new ArrayList<>();
            for (Personnel p : dutyPersonnel) {
                String loc = p.getDutyLocation();
                if (loc != null && !loc.isBlank()) { byLocation.computeIfAbsent(loc.trim(), k -> new ArrayList<>()).add(p); }
                else { noLoc.add(p); }
            }

            Map<String, List<Personnel>> dutyMap = new LinkedHashMap<>();
            Set<String> addedNames = new HashSet<>();
            for (com.policescheduler.entity.DutyType child : childDutyTypes) {
                String cn = child.getName(); String cnU = cn.toUpperCase().trim();
                List<Personnel> cp = byLocation.getOrDefault(cn, byLocation.getOrDefault(cnU, List.of()));
                if (cp.isEmpty()) { for (Map.Entry<String, List<Personnel>> e : byLocation.entrySet()) { if (e.getKey().toUpperCase().trim().equals(cnU)) { cp = e.getValue(); break; } } }
                if (!cp.isEmpty()) { dutyMap.put(cn, cp); }
                addedNames.add(cnU);
            }
            for (Map.Entry<String, List<Personnel>> e : byLocation.entrySet()) {
                if (!addedNames.contains(e.getKey().toUpperCase().trim())) { dutyMap.put(e.getKey(), e.getValue()); }
            }
            if (dutyMap.isEmpty() && !noLoc.isEmpty()) { dutyMap.put(parent.getName(), noLoc); }
            else if (!noLoc.isEmpty()) { dutyMap.put(parent.getName(), noLoc); }

            if (!dutyPersonnel.isEmpty()) { subsections.add(buildSubsection(parent.getName(), dutyMap)); }
        }

        subsections.add(buildLeaveSubsection(sectionPersonnel, onLeaveIds, activeLeaves));
        return buildSection("SECTION " + sectionCode, subsections);
    }

    private SectionModel buildSectionA(List<Personnel> all, List<LeaveRequest> leaves,
                                        Set<Long> onLeaveIds, LocalDate reportDate) {
        List<SubsectionModel> subsections = new ArrayList<>();

        // Get section personnel first for leave filtering
        List<Personnel> sectionAPersonnel = all.stream()
                .filter(p -> belongsToSection(p, "A"))
                .collect(Collectors.toList());

        // Get all leave-related IDs for this section
        Set<Long> allLeaveIds = getAllLeaveRelatedIds(sectionAPersonnel, onLeaveIds);

        // Filter to on-duty personnel only (exclude leave from duty rows)
        List<Personnel> onDutyAll = all.stream()
                .filter(p -> !allLeaveIds.contains(p.getId()))
                .collect(Collectors.toList());

        // CAR HQ
        subsections.add(buildSubsection("CAR HQ", buildDutyMap(onDutyAll, Map.of(
                "CAR HQ", List.of("CAR HQ"),
                "DUTY OFFICER", List.of("DUTY OFFICER"),
                "ADO", List.of("ADO")
        ))));

        // CHAMBER SENTRY / CP ESTATE
        subsections.add(buildSubsection("CHAMBER SENTRY/ CP ESTATE", buildDutyMap(onDutyAll, Map.of(
                "CP ESTATE", List.of("CP ESTATE"),
                "COMMISSIONER OFFICE CHAMBER SENTRY", List.of("COMMISSIONER", "CHAMBER"),
                "DCP CAR OFFICE", List.of("DCP CAR"),
                "ACP CAR OFFICE", List.of("ACP", "CHAMBER"),
                "DCP LAW & ORDER", List.of("DCP LAW"),
                "SAMRAT BUILDING", List.of("SAMRAT"),
                "DCP CRIME & TRAFFIC", List.of("DCP CRIME", "CHAMBER")
        ))));

        // ARMOURY, DOG SQUAD & ASC TEAM
        subsections.add(buildSubsection("ARMOURY, DOG SQUAD & ASC TEAM", buildDutyMap(onDutyAll, Map.of(
                "ARMOURY", List.of("ARMOURY"),
                "DOG SQUAD", List.of("DOG"),
                "ASC TEAM", List.of("ASC TEAM")
        ))));

        // GUNMAN DETAILS
        Map<String, List<String>> gunmanDuties = new LinkedHashMap<>();
        gunmanDuties.put("GUNMAN TO DC", List.of("GUNMAN", "DC"));
        gunmanDuties.put("GUNMAN TO SESSION JUDGE", List.of("GUNMAN", "SESSION JUDGE"));
        gunmanDuties.put("GUNMAN TO COMPOL", List.of("GUNMAN", "COMPOL"));
        gunmanDuties.put("GUNMAN TO DCP", List.of("GUNMAN", "DCP"));
        gunmanDuties.put("GUNMAN", List.of("GUNMAN"));
        gunmanDuties.put("GUN MAN", List.of("GUN MAN"));
        subsections.add(buildSubsection("GUNMAN DETAILS", buildDutyMapOrdered(onDutyAll, gunmanDuties)));

        // OOD DUTY
        subsections.add(buildSubsection("OOD DUTY", buildDutyMap(onDutyAll, Map.of(
                "OOD", List.of("OOD"),
                "BDDS", List.of("BDDS"),
                "CCT", List.of("CCT"),
                "FPB", List.of("FPB"),
                "CONTROL ROOM", List.of("CONTROL ROOM"),
                "DCP CRIME", List.of("DCP CRIME"),
                "RFSL", List.of("RFSL"),
                "MCU", List.of("MCU")
        ))));

        // OTHER DUTY'S
        subsections.add(buildSubsection("OTHER DUTY'S", buildDutyMap(onDutyAll, Map.of(
                "BAJPE AIRPORT LAISON", List.of("BAJPE", "LAISON"),
                "PHOTOGRAPHER", List.of("PHOTOGRAPHER"),
                "PP OFFICE", List.of("PP OFFICE"),
                "COP BUGLER", List.of("BUGLER"),
                "SRI CHANDRASHEKAR SWAMIJI", List.of("CHANDRASHEKAR")
        ))));

        // LEAVE — only for personnel in Section A (or whose section field matches)
        subsections.add(buildLeaveSubsection(sectionAPersonnel, onLeaveIds, leaves));

        return buildSection("SECTION A", subsections);
    }

    private SectionModel buildSectionB(List<Personnel> all, List<LeaveRequest> leaves,
                                        Set<Long> onLeaveIds, LocalDate reportDate) {
        List<SubsectionModel> subsections = new ArrayList<>();

        // Get section personnel for leave filtering
        List<Personnel> sectionBPersonnel = all.stream()
                .filter(p -> belongsToSection(p, "B"))
                .collect(Collectors.toList());
        Set<Long> allLeaveIds = getAllLeaveRelatedIds(sectionBPersonnel, onLeaveIds);
        List<Personnel> onDutyAll = all.stream()
                .filter(p -> !allLeaveIds.contains(p.getId()))
                .collect(Collectors.toList());

        // WRITER'S
        Map<String, List<String>> writerDuties = new LinkedHashMap<>();
        writerDuties.put("DUTY OFFICER/DUTY WRITERS", List.of("DUTY OFFICER", "DUTY WRITER"));
        writerDuties.put("DCP CAR WRITER", List.of("DCP", "WRITER"));
        writerDuties.put("ACP WRITER", List.of("ACP", "WRITER"));
        writerDuties.put("RPI WRITER", List.of("RPI", "WRITER"));
        writerDuties.put("COMPUTER OPERATOR", List.of("COMPUTER OPERATOR"));
        writerDuties.put("ASST DUTY OFFICER", List.of("ASST DUTY OFFICER"));
        subsections.add(buildSubsection("WRITER'S", buildDutyMapOrdered(onDutyAll, writerDuties)));

        // OTHER DUTY'S
        Map<String, List<String>> otherDuties = new LinkedHashMap<>();
        otherDuties.put("POLICE CANTEEN", List.of("POLICE CANTEEN"));
        otherDuties.put("PDMS TRG", List.of("PDMS"));
        otherDuties.put("POLICE LANE/CAR BUILDING IN-CHARGE", List.of("POLICE LANE", "IN-CHARGE"));
        otherDuties.put("ARCHERY", List.of("ARCHERY"));
        otherDuties.put("AROGYA BHAGYA", List.of("AROGYA"));
        otherDuties.put("DUTY TO COP COMPUTER WING", List.of("COP COMPUTER"));
        otherDuties.put("CAR STORE IC", List.of("CAR STORE"));
        otherDuties.put("COURT DUTY", List.of("COURT"));
        otherDuties.put("BAND TEAM/PRACTICE", List.of("BAND"));
        otherDuties.put("ADO ASST", List.of("ADO ASST"));
        otherDuties.put("GYM", List.of("GYM"));
        otherDuties.put("CAR HQ", List.of("CAR HQ"));
        otherDuties.put("POLICE LANE BEAT DUTY", List.of("POLICE LANE", "BEAT"));
        subsections.add(buildSubsection("OTHER DUTY'S", buildDutyMapOrdered(onDutyAll, otherDuties)));

        // LEAVE — only for personnel in Section B
        subsections.add(buildLeaveSubsection(sectionBPersonnel, onLeaveIds, leaves));

        return buildSection("SECTION B", subsections);
    }

    private SectionModel buildSectionC(List<Personnel> all, List<LeaveRequest> leaves,
                                        Set<Long> onLeaveIds, LocalDate reportDate) {
        List<SubsectionModel> subsections = new ArrayList<>();

        // Get section personnel for leave filtering
        List<Personnel> sectionCPersonnel = all.stream()
                .filter(p -> belongsToSection(p, "C"))
                .collect(Collectors.toList());
        Set<Long> allLeaveIds = getAllLeaveRelatedIds(sectionCPersonnel, onLeaveIds);
        List<Personnel> onDutyAll = all.stream()
                .filter(p -> !allLeaveIds.contains(p.getId()))
                .collect(Collectors.toList());

        // GUARD-I
        Map<String, List<String>> guardDuties = new LinkedHashMap<>();
        guardDuties.put("COMMISSIONER OFFICE GUARD", List.of("COMMISSIONER", "GUARD"));
        guardDuties.put("WENLOCK HOSPITAL CELL GUARD", List.of("WENLOCK"));
        guardDuties.put("CORPORATION/UNION BANK", List.of("CORPORATION", "CURRENCY"));
        guardDuties.put("SYNDICATE/CANARA BANK", List.of("SYNDICATE", "CURRENCY"));
        guardDuties.put("VIJAYA BANK/BARODA", List.of("VIJAYA", "CURRENCY"));
        guardDuties.put("CANARA BANK", List.of("CANARA", "CURRENCY"));
        guardDuties.put("KARNATAKA BANK", List.of("KARNATAKA", "CURRENCY"));
        guardDuties.put("AXIS BANK", List.of("AXIS", "CURRENCY"));
        guardDuties.put("ICICI BANK CURRENCY CHEST GUARD", List.of("ICICI", "CURRENCY"));
        subsections.add(buildSubsection("GUARD-I", buildDutyMapOrdered(onDutyAll, guardDuties)));

        // OTHER DUTY'S
        Map<String, List<String>> otherDuties = new LinkedHashMap<>();
        otherDuties.put("CAR HQ", List.of("CAR HQ"));
        otherDuties.put("QRT DUTY", List.of("QRT"));
        subsections.add(buildSubsection("OTHER DUTY'S", buildDutyMapOrdered(onDutyAll, otherDuties)));

        // LEAVE — only for personnel in Section C
        subsections.add(buildLeaveSubsection(sectionCPersonnel, onLeaveIds, leaves));

        return buildSection("SECTION C", subsections);
    }

    private SectionModel buildSectionD(List<Personnel> all, List<LeaveRequest> leaves,
                                        Set<Long> onLeaveIds, LocalDate reportDate) {
        List<SubsectionModel> subsections = new ArrayList<>();

        // Get section personnel for leave filtering
        List<Personnel> sectionDPersonnel = all.stream()
                .filter(p -> belongsToSection(p, "D"))
                .collect(Collectors.toList());
        Set<Long> allLeaveIds = getAllLeaveRelatedIds(sectionDPersonnel, onLeaveIds);
        List<Personnel> onDutyAll = all.stream()
                .filter(p -> !allLeaveIds.contains(p.getId()))
                .collect(Collectors.toList());

        // GUARD-II
        Map<String, List<String>> guardDuties = new LinkedHashMap<>();
        guardDuties.put("DISTRICT TREASURY", List.of("TREASURY", "GUARD"));
        guardDuties.put("DIST SESSION JUDGE BUNGLOW", List.of("SESSION JUDGE"));
        guardDuties.put("JUSTICE RESIDENTIAL (HAT HILL)", List.of("JUSTICE", "HAT HILL"));
        guardDuties.put("POLICE COMMISSIONER BUNGLOW", List.of("COMMISSIONER BUNGLOW"));
        guardDuties.put("DC BUNGLOW", List.of("DC BUNGLOW"));
        guardDuties.put("FSL GUARD", List.of("FSL"));
        guardDuties.put("WIRELESS MONITORING", List.of("WIRELESS"));
        guardDuties.put("NCC PANDESHWARA", List.of("NCC", "PANDESHWARA"));
        guardDuties.put("NCC ARAVINDA", List.of("NCC", "ARAVINDA"));
        guardDuties.put("NCC YEKKURU", List.of("NCC", "YEKKURU"));
        guardDuties.put("VVPAT/EVM GUARD", List.of("VVPAT"));
        guardDuties.put("CAR ARMOURY GUARD", List.of("ARMOURY", "GUARD"));
        subsections.add(buildSubsection("GUARD-II", buildDutyMapOrdered(onDutyAll, guardDuties)));

        // OTHER DUTY'S
        Map<String, List<String>> otherDuties = new LinkedHashMap<>();
        otherDuties.put("GUARD DUTY (SRINIVAS COLLAGE MUKKA)", List.of("SRINIVAS", "MUKKA"));
        otherDuties.put("WENLOCK HOSPITAL CELL GUARD IC", List.of("WENLOCK", "IC"));
        otherDuties.put("QRT DUTY", List.of("QRT"));
        otherDuties.put("ARMOURY DUTY", List.of("ARMOURY"));
        otherDuties.put("POLICE LANE BEAT DUTY", List.of("POLICE LANE", "BEAT"));
        otherDuties.put("CAR HQ", List.of("CAR HQ"));
        subsections.add(buildSubsection("OTHER DUTY'S", buildDutyMapOrdered(onDutyAll, otherDuties)));

        // LEAVE — only for personnel in Section D
        subsections.add(buildLeaveSubsection(sectionDPersonnel, onLeaveIds, leaves));

        return buildSection("SECTION D", subsections);
    }

    private SectionModel buildSectionE(List<Personnel> all, List<LeaveRequest> leaves,
                                        Set<Long> onLeaveIds, LocalDate reportDate) {
        List<SubsectionModel> subsections = new ArrayList<>();

        // Get section personnel for leave filtering
        List<Personnel> sectionEPersonnel = all.stream()
                .filter(p -> belongsToSection(p, "E"))
                .collect(Collectors.toList());
        Set<Long> allLeaveIds = getAllLeaveRelatedIds(sectionEPersonnel, onLeaveIds);
        List<Personnel> onDutyAll = all.stream()
                .filter(p -> !allLeaveIds.contains(p.getId()))
                .collect(Collectors.toList());

        // CHECK POST DUTY (with shifts)
        Map<String, List<String>> checkPostDuties = new LinkedHashMap<>();
        checkPostDuties.put("A SHIFT 05:00-13:00", List.of("CHECK POST", "A SHIFT"));
        checkPostDuties.put("B SHIFT 13:00-21:00", List.of("CHECK POST", "B SHIFT"));
        checkPostDuties.put("C SHIFT 21:00-05:00", List.of("CHECK POST", "C SHIFT"));
        subsections.add(buildSubsection("CHECK POST DUTY", buildDutyMapOrdered(onDutyAll, checkPostDuties)));

        // OTHER DUTY'S
        Map<String, List<String>> otherDuties = new LinkedHashMap<>();
        otherDuties.put("CAR HQ", List.of("CAR HQ"));
        otherDuties.put("DIST CONSUMER DISPUTES", List.of("CONSUMER"));
        subsections.add(buildSubsection("OTHER DUTY'S", buildDutyMapOrdered(onDutyAll, otherDuties)));

        // LEAVE — only for personnel in Section E
        subsections.add(buildLeaveSubsection(sectionEPersonnel, onLeaveIds, leaves));

        return buildSection("SECTION E", subsections);
    }

    private SectionModel buildSectionF(List<Personnel> all, List<LeaveRequest> leaves,
                                        Set<Long> onLeaveIds, LocalDate reportDate) {
        List<SubsectionModel> subsections = new ArrayList<>();

        // Get section personnel for leave filtering
        List<Personnel> sectionFPersonnel = all.stream()
                .filter(p -> belongsToSection(p, "F"))
                .collect(Collectors.toList());
        Set<Long> allLeaveIds = getAllLeaveRelatedIds(sectionFPersonnel, onLeaveIds);
        List<Personnel> onDutyAll = all.stream()
                .filter(p -> !allLeaveIds.contains(p.getId()))
                .collect(Collectors.toList());

        // VIP ESCORTS/PILOT/PSO
        Map<String, List<String>> vipDuties = new LinkedHashMap<>();
        vipDuties.put("VIP ESCORT", List.of("VIP ESCORT"));
        vipDuties.put("PILOT", List.of("PILOT"));
        vipDuties.put("PSO", List.of("PSO"));
        subsections.add(buildSubsection("VIP ESCORTS/PILOT/PSO", buildDutyMapOrdered(onDutyAll, vipDuties)));

        // PRISONER ESCORT / COURT PROPERTY ESCORT
        Map<String, List<String>> prisonerDuties = new LinkedHashMap<>();
        prisonerDuties.put("II ADSJ COURT", List.of("II ADSJ"));
        prisonerDuties.put("I ADDL SR CJ", List.of("ADDL SR CJ"));
        prisonerDuties.put("II JMFC", List.of("II JMFC"));
        prisonerDuties.put("III JMFC", List.of("III JMFC"));
        prisonerDuties.put("P/ESCORT", List.of("P/ESCORT"));
        subsections.add(buildSubsection("PRISONER ESCORT /COURT PROPERTY ESCORT", buildDutyMapOrdered(onDutyAll, prisonerDuties)));

        // OTHER DUTY'S
        Map<String, List<String>> otherDuties = new LinkedHashMap<>();
        otherDuties.put("CAR HQ", List.of("CAR HQ"));
        otherDuties.put("PP OFFICE DUTY", List.of("PP OFFICE"));
        otherDuties.put("CASH ESCORT", List.of("CASH ESCORT"));
        otherDuties.put("CHECK POST DUTY (POLALI/DEVIPURA)", List.of("POLALI"));
        otherDuties.put("GUARD DUTY MUKKA", List.of("MUKKA", "GUARD"));
        otherDuties.put("WENLOCK CELL ICU", List.of("WENLOCK", "ICU"));
        otherDuties.put("BAJPE AIRPORT OP", List.of("BAJPE", "OP"));
        otherDuties.put("QRT DUTY", List.of("QRT"));
        otherDuties.put("PDMS TRG", List.of("PDMS"));
        subsections.add(buildSubsection("OTHER DUTY'S", buildDutyMapOrdered(onDutyAll, otherDuties)));

        // LEAVE — only for personnel in Section F
        subsections.add(buildLeaveSubsection(sectionFPersonnel, onLeaveIds, leaves));

        return buildSection("SECTION F", subsections);
    }

    private SectionModel buildSectionG(List<Personnel> all, List<LeaveRequest> leaves,
                                        Set<Long> onLeaveIds, LocalDate reportDate) {
        List<SubsectionModel> subsections = new ArrayList<>();

        // Get section personnel for leave filtering
        List<Personnel> sectionGPersonnel = all.stream()
                .filter(p -> belongsToSection(p, "G"))
                .collect(Collectors.toList());
        Set<Long> allLeaveIds = getAllLeaveRelatedIds(sectionGPersonnel, onLeaveIds);
        List<Personnel> onDutyAll = all.stream()
                .filter(p -> !allLeaveIds.contains(p.getId()))
                .collect(Collectors.toList());

        // STRIKING FORCE / FOLLOW UP PARTY/RIV/B,B
        Map<String, List<String>> sfDuties = new LinkedHashMap<>();
        sfDuties.put("C C ROOM SF-I", List.of("C C ROOM", "SF-I"));
        sfDuties.put("C C ROOM SF-II", List.of("C C ROOM", "SF-II"));
        sfDuties.put("SF-III (AREA DOMINATION)", List.of("SF-III"));
        sfDuties.put("CAR STAND BY SF-I", List.of("STAND BY", "SF-I"));
        sfDuties.put("CAR STAND BY SF-II", List.of("STAND BY", "SF-II"));
        subsections.add(buildSubsection("STRIKING FORCE / FOLLOW UP PARTY/RIV/B,B", buildDutyMapOrdered(onDutyAll, sfDuties)));

        // OTHER DUTY'S
        Map<String, List<String>> otherDuties = new LinkedHashMap<>();
        otherDuties.put("PDMS TRG", List.of("PDMS"));
        otherDuties.put("ASC TEAM", List.of("ASC TEAM"));
        otherDuties.put("QRT DUTY", List.of("QRT"));
        subsections.add(buildSubsection("OTHER DUTY'S", buildDutyMapOrdered(onDutyAll, otherDuties)));

        // LEAVE — only for personnel in Section G
        subsections.add(buildLeaveSubsection(sectionGPersonnel, onLeaveIds, leaves));

        return buildSection("SECTION G", subsections);
    }

    // ========== OFFICER DUTY ==========

    private OfficerDutyModel buildOfficerDuty(List<Personnel> allPersonnel,
                                               List<LeaveRequest> activeLeaves,
                                               Set<Long> onLeaveIds,
                                               LocalDate reportDate) {
        // === Part 1: Build subsections for the 10-column format ===

        // Filter out on-leave personnel for duty maps
        Set<Long> allLeaveIds = getAllLeaveRelatedIds(allPersonnel, onLeaveIds);
        List<Personnel> onDutyAll = allPersonnel.stream()
                .filter(p -> !allLeaveIds.contains(p.getId()))
                .collect(Collectors.toList());

        // Officer designations for the Officer's Duty section (excluding AHC, APC constables)
        Set<String> officerDesigs = Set.of("ACP", "RPI", "RSI", "ARSI");
        
        // Filter to only officers for the Officer's Duty section duty rows
        List<Personnel> officersOnDuty = onDutyAll.stream()
                .filter(p -> p.getDesignation() != null
                        && officerDesigs.contains(p.getDesignation().toUpperCase().trim()))
                .collect(Collectors.toList());

        List<SubsectionModel> subsections = new ArrayList<>();

        // VIP ESCORTS/PILOT subsection - ONLY OFFICERS (ACP, RPI, RSI, ARSI)
        Map<String, List<String>> vipDuties = new LinkedHashMap<>();
        vipDuties.put("VIP ESCORT", List.of("VIP ESCORT"));
        vipDuties.put("PILOT", List.of("PILOT"));
        subsections.add(buildSubsection("VIP ESCORTS/PILOT", buildDutyMapOrdered(officersOnDuty, vipDuties)));

        // OTHER DUTY'S subsection - ONLY OFFICERS (ACP, RPI, RSI, ARSI)
        Map<String, List<String>> otherDuties = new LinkedHashMap<>();
        otherDuties.put("VIP SPARE/CAR HQ", List.of("VIP SPARE"));
        otherDuties.put("CHECK POST CHECKING DUTY", List.of("CHECK POST", "CHECKING"));
        otherDuties.put("LAST NIGHT CHECK POST CHECKING DUTY", List.of("LAST NIGHT", "CHECK POST"));
        otherDuties.put("CASH ESCORT", List.of("CASH ESCORT"));
        otherDuties.put("GUARD CHECK", List.of("GUARD CHECK"));
        otherDuties.put("LAST NIGHT GUARD CHECK", List.of("LAST NIGHT", "GUARD CHECK"));
        otherDuties.put("LAST NIGHT ADO", List.of("LAST NIGHT", "ADO"));
        otherDuties.put("GUARD DUTY MUKKA", List.of("GUARD", "MUKKA"));
        otherDuties.put("P/ESCORT", List.of("P/ESCORT"));
        otherDuties.put("SPG LIAISON OFFICER DUTY", List.of("SPG", "LIAISON"));
        otherDuties.put("COURT SUPERVISION", List.of("COURT", "SUPERVISION"));
        subsections.add(buildSubsection("OTHER DUTY'S", buildDutyMapOrdered(officersOnDuty, otherDuties)));

        // LEAVE subsection for Officer's Duty — only officers (ACP, RPI, RSI, ARSI)
        // Note: DCP excluded from Officer's Duty section as per Form 168 column headers
        List<Personnel> officerPersonnelForLeave = allPersonnel.stream()
                .filter(p -> p.getDesignation() != null
                        && officerDesigs.contains(p.getDesignation().toUpperCase().trim()))
                .collect(Collectors.toList());
        subsections.add(buildLeaveSubsection(officerPersonnelForLeave, onLeaveIds, activeLeaves));

        // Compute sub total (sum of all officer duty subsections)
        int[] subTotal = new int[8];
        for (SubsectionModel sub : subsections) {
            if (sub.getTotal() != null) {
                for (int i = 0; i < 8; i++) {
                    subTotal[i] += sub.getTotal()[i];
                }
            }
        }

        // Compute GRAND TOTAL (COMPANY) = sum of all Sections A-G grand totals + officer duty sub total
        // This should be only personnel who are on duty (not on leave)
        int[] grandTotalCompany = countByDesignation(onDutyAll);

        // === Under Training / Without Training section ===

        List<SubsectionModel> underTrainingSubsections = new ArrayList<>();

        // BASIC TRAINING PTS DHARWAD
        Map<String, List<String>> trainingDuties = new LinkedHashMap<>();
        trainingDuties.put("BASIC TRAINING PTS DHARWAD", List.of("BASIC TRAINING"));
        trainingDuties.put("RECRUIT APC'S", List.of("RECRUIT"));
        underTrainingSubsections.add(buildSubsection("UNDER TRAINING", buildDutyMapOrdered(onDutyAll, trainingDuties)));

        int[] underTrainingTotal = new int[8];
        for (SubsectionModel sub : underTrainingSubsections) {
            if (sub.getTotal() != null) {
                for (int i = 0; i < 8; i++) {
                    underTrainingTotal[i] += sub.getTotal()[i];
                }
            }
        }

        // Under Training LEAVE subsection — only personnel marked for training
        List<Personnel> trainingPersonnel = allPersonnel.stream()
                .filter(p -> hasDutyContaining(p, "BASIC TRAINING") || hasDutyContaining(p, "RECRUIT"))
                .collect(Collectors.toList());
        SubsectionModel underTrainingLeave = buildLeaveSubsection(trainingPersonnel, onLeaveIds, activeLeaves);
        int[] underTrainingLeaveTotal = underTrainingLeave.getTotal() != null ? underTrainingLeave.getTotal() : new int[8];

        // P.M.T line
        int[] pmtLine = new int[8];
        // PMT counts would come from personnel marked as PMT — for now zeros
        List<Personnel> pmtPersonnel = onDutyAll.stream()
                .filter(p -> hasDutyContaining(p, "PMT") || hasDutyContaining(p, "P.M.T"))
                .collect(Collectors.toList());
        if (!pmtPersonnel.isEmpty()) {
            pmtLine = countByDesignation(pmtPersonnel);
        }

        // Final GRAND TOTAL = grandTotalCompany + underTrainingTotal + underTrainingLeaveTotal + pmtLine
        int[] grandTotal = new int[8];
        for (int i = 0; i < 8; i++) {
            grandTotal[i] = grandTotalCompany[i] + underTrainingTotal[i] + underTrainingLeaveTotal[i] + pmtLine[i];
        }

        // === Part 2: Build the 4-column officer S.NO/NAME/DESIGNATION/DUTY table ===
        // Only include CAR unit officers (exclude MT unit)
        // For Section A: only include RPI and RSI designations
        // Sort by designation: DCP → ACP → RPI → RSI → ARSI

        Set<String> officerDesignations = Set.of("DCP", "ACP", "RPI", "RSI", "ARSI");
        Set<String> sectionAAllowedDesignations = Set.of("RPI", "RSI", "ARSI");
        
        // Define designation sort order
        Map<String, Integer> designationOrder = Map.of(
                "DCP", 1,
                "ACP", 2,
                "RPI", 3,
                "RSI", 4,
                "ARSI", 5
        );
        
        List<Personnel> officerPersonnel = allPersonnel.stream()
                .filter(p -> p.getDesignation() != null
                        && officerDesignations.contains(p.getDesignation().toUpperCase().trim()))
                .filter(p -> !"MT".equalsIgnoreCase(p.getUnit())) // Exclude MT unit personnel
                .filter(p -> {
                    // For Section A: only include RPI and RSI
                    String section = p.getSection() != null ? p.getSection().toUpperCase().trim() : "";
                    boolean isSectionA = section.equals("A") || section.equals("SECTION A");
                    if (isSectionA) {
                        String desig = p.getDesignation() != null ? p.getDesignation().toUpperCase().trim() : "";
                        return sectionAAllowedDesignations.contains(desig);
                    }
                    return true; // Include all other sections
                })
                .sorted((p1, p2) -> {
                    String d1 = p1.getDesignation() != null ? p1.getDesignation().toUpperCase().trim() : "";
                    String d2 = p2.getDesignation() != null ? p2.getDesignation().toUpperCase().trim() : "";
                    int order1 = designationOrder.getOrDefault(d1, 99);
                    int order2 = designationOrder.getOrDefault(d2, 99);
                    if (order1 != order2) {
                        return Integer.compare(order1, order2);
                    }
                    // Secondary sort by name within same designation
                    String name1 = p1.getPersonName() != null ? p1.getPersonName() : "";
                    String name2 = p2.getPersonName() != null ? p2.getPersonName() : "";
                    return name1.compareToIgnoreCase(name2);
                })
                .collect(Collectors.toList());

        List<OfficerRow> officerRows = new ArrayList<>();
        for (Personnel officer : officerPersonnel) {
            String duty = determineDutyDescription(officer);
            officerRows.add(OfficerRow.builder()
                    .name(officer.getPersonName())
                    .designation(officer.getDesignation())
                    .duty(duty)
                    .build());
        }

        return OfficerDutyModel.builder()
                .subsections(subsections)
                .subTotal(subTotal)
                .grandTotalCompany(grandTotalCompany)
                .underTrainingSubsections(underTrainingSubsections)
                .underTrainingTotal(underTrainingTotal)
                .underTrainingLeave(underTrainingLeave)
                .underTrainingLeaveTotal(underTrainingLeaveTotal)
                .pmtLine(pmtLine)
                .grandTotal(grandTotal)
                .officers(officerRows)
                .build();
    }

    // ========== LEAVE STATEMENT ==========

    private LeaveStatementModel buildLeaveStatement(List<Personnel> allPersonnel,
                                                     List<LeaveRequest> activeLeaves,
                                                     LocalDate reportDate) {
        Map<Long, Personnel> personnelMap = allPersonnel.stream()
                .collect(Collectors.toMap(Personnel::getId, p -> p, (a, b) -> a));

        // Group leaves by type
        Map<String, List<LeaveRequest>> leavesByType = activeLeaves.stream()
                .collect(Collectors.groupingBy(lr -> normalizeLeaveType(lr.getLeaveType()),
                        LinkedHashMap::new, Collectors.toList()));

        List<LeaveGroup> groups = new ArrayList<>();
        int slNo = 1;

        // Ordered types for leave statement
        List<String> orderedTypes = List.of(
            "CL (CASUAL LEAVE)", "CML (COMMUTED LEAVE)", "PL (PATERNITY LEAVE)", 
            "EL (EARNED LEAVE)", "WEEKLY OFF", "PERMISSION", "ABSENT", "SUSPENSION", "SICK"
        );

        for (String type : orderedTypes) {
            List<LeaveRequest> leavesOfType = leavesByType.getOrDefault(type, Collections.emptyList());
            if (leavesOfType.isEmpty()) continue;

            List<LeaveEntry> entries = new ArrayList<>();
            for (LeaveRequest lr : leavesOfType) {
                Personnel p = personnelMap.get(lr.getPersonnelId());
                if (p == null) continue;

                String badgeOrName = formatBadgeOrName(p);
                long days;
                String details;
                if (lr.getEndDate() == null) {
                    // Open-ended sick leave: calculate days from start to today
                    days = ChronoUnit.DAYS.between(lr.getStartDate(), LocalDate.now()) + 1;
                    details = String.format("ONGOING (%d DAYS) %s FROM %s",
                            days, lr.getLeaveType(),
                            lr.getStartDate().format(DATE_FORMAT));
                } else {
                    days = ChronoUnit.DAYS.between(lr.getStartDate(), lr.getEndDate()) + 1;
                    details = String.format("%d DAYS %s FROM %s TO %s",
                            days, lr.getLeaveType(),
                            lr.getStartDate().format(DATE_FORMAT),
                            lr.getEndDate().format(DATE_FORMAT));
                }

                entries.add(LeaveEntry.builder()
                        .serialNumber(slNo++)
                        .badgeOrName(badgeOrName)
                        .type(lr.getLeaveType())
                        .details(details)
                        .build());
            }

            groups.add(LeaveGroup.builder()
                    .type(type)
                    .entries(entries)
                    .build());
        }

        return LeaveStatementModel.builder()
                .groups(groups)
                .build();
    }

    // ========== HELPER METHODS ==========

    /**
     * Checks if personnel has a duty containing the specified keyword (case-insensitive).
     * Checks both dutyType and dutyLocation fields.
     */
    boolean hasDutyContaining(Personnel p, String keyword) {
        String kw = keyword.toUpperCase();
        String dt = p.getDutyType() != null ? p.getDutyType().toUpperCase() : "";
        String dl = p.getDutyLocation() != null ? p.getDutyLocation().toUpperCase() : "";
        return dt.contains(kw) || dl.contains(kw);
    }

    /**
     * Checks if personnel belongs to the given section letter (A, B, C, D, E, F, G).
     * Handles various formats: "A", "Section A", "SECTION A", "a", etc.
     */
    private boolean belongsToSection(Personnel p, String sectionLetter) {
        String section = p.getSection();
        if (section == null || section.isBlank()) return false;
        String normalized = section.toUpperCase().trim();
        // Direct match: "A", "B", etc.
        if (normalized.equals(sectionLetter.toUpperCase())) return true;
        // "Section A" or "SECTION A" format
        if (normalized.equals("SECTION " + sectionLetter.toUpperCase())) return true;
        // Ends with the letter (e.g., "SEC-A", "SEC A")
        if (normalized.endsWith(sectionLetter.toUpperCase()) && normalized.length() > 1) {
            char before = normalized.charAt(normalized.length() - sectionLetter.length() - 1);
            return before == ' ' || before == '-' || before == '_';
        }
        return false;
    }

    /**
     * Formats personnel details according to rules:
     * - Officers (RPI, RSI, ARSI): "{DESIGNATION} SRI {NAME}"
     * - Constables (AHC, APC): "{DESIGNATION}-{BADGE_NUMBER}"
     * - Multiple separated by ", "
     * - No leading/trailing/double commas
     * 
     * NOTE: Excludes DCP personnel since there is no DCP column in Section A-G Form 168 tables.
     * DCP personnel are only shown in the strength table at the top, not in section duty rows.
     */
    public String formatPersonnelDetails(List<Personnel> personnel) {
        if (personnel == null || personnel.isEmpty()) return "";

        List<String> parts = new ArrayList<>();

        for (Personnel p : personnel) {
            String badgeId = p.getBadgeId() != null ? p.getBadgeId().trim() : "";
            String name = p.getPersonName() != null ? p.getPersonName().trim() : "";
            String desig = p.getDesignation() != null ? p.getDesignation().toUpperCase().trim() : "";

            // Skip DCP personnel as there is no DCP column in Section Form 168 tables
            if (desig.contains("DCP")) {
                continue;
            }

            // Check if badge_id is a real usable value (not empty, not just "-", not AUTO-generated)
            boolean hasRealBadgeId = !badgeId.isEmpty() && !badgeId.equals("-") && !badgeId.contains("AUTO");

            if (hasRealBadgeId) {
                // Has a real badge_id — use it
                parts.add(badgeId);
            } else if (!name.isEmpty()) {
                // No real badge_id — show designation + name
                String displayName = name.toUpperCase().startsWith("SRI ") ? name.substring(4) : name;
                parts.add(desig + " SRI " + displayName);
            }
        }

        return String.join(", ", parts);
    }

    /**
     * Returns int[8] for: ACP, RPI, RSI, ARSI, AHC, APC, SWP, TOTAL
     */
    public int[] countByDesignation(List<Personnel> personnel) {
        int[] counts = new int[8];
        for (Personnel p : personnel) {
            String desig = p.getDesignation() != null ? p.getDesignation().toUpperCase().trim() : "";
            switch (desig) {
                case "ACP": counts[0]++; break;
                case "RPI": counts[1]++; break;
                case "RSI": counts[2]++; break;
                case "ARSI": counts[3]++; break;
                case "AHC": counts[4]++; break;
                case "APC": counts[5]++; break;
            }
        }
        counts[6] = 0; // SWP always 0
        counts[7] = counts[0] + counts[1] + counts[2] + counts[3] + counts[4] + counts[5];
        return counts;
    }

    // ========== PRIVATE HELPERS ==========

    private SectionModel buildSection(String sectionName, List<SubsectionModel> subsections) {
        int[] grandTotal = new int[8];
        for (SubsectionModel sub : subsections) {
            if (sub.getTotal() != null) {
                for (int i = 0; i < 8; i++) {
                    grandTotal[i] += sub.getTotal()[i];
                }
            }
        }
        return SectionModel.builder()
                .sectionName(sectionName)
                .subsections(subsections)
                .grandTotal(grandTotal)
                .build();
    }

    private SubsectionModel buildSubsection(String name, Map<String, List<Personnel>> dutyMap) {
        List<DutyRowModel> rows = new ArrayList<>();
        int serialNumber = 1;
        int[] subsectionTotal = new int[8]; // ACP, RPI, RSI, ARSI, AHC, APC, SWP, TOTAL

        for (Map.Entry<String, List<Personnel>> entry : dutyMap.entrySet()) {
            List<Personnel> personnel = entry.getValue();
            if (personnel.isEmpty()) continue;

            int[] counts = countByDesignation(personnel);
            rows.add(DutyRowModel.builder()
                    .serialNumber(serialNumber++)
                    .dutyDescription(entry.getKey())
                    .counts(Arrays.copyOfRange(counts, 0, 7)) // ACP through SWP
                    .total(counts[7])
                    .personnelDetails(formatPersonnelDetails(personnel))
                    .build());

            for (int i = 0; i < 8; i++) {
                subsectionTotal[i] += counts[i];
            }
        }

        return SubsectionModel.builder()
                .name(name)
                .rows(rows)
                .total(subsectionTotal)
                .build();
    }

    private SubsectionModel buildLeaveSubsection(List<Personnel> sectionPersonnel, Set<Long> onLeaveIds,
                                                   List<LeaveRequest> activeLeaves) {
        Map<String, List<Personnel>> leaveMap = new LinkedHashMap<>();

        // Build a lookup: personnelId → leaveType for quick access
        Map<Long, String> leaveTypeByPersonnelId = new HashMap<>();
        for (LeaveRequest lr : activeLeaves) {
            leaveTypeByPersonnelId.put(lr.getPersonnelId(), lr.getLeaveType());
        }

        // Only consider personnel that belong to THIS section (passed as sectionPersonnel)
        // Get IDs of personnel in this section
        Set<Long> sectionPersonnelIds = sectionPersonnel.stream()
                .map(Personnel::getId)
                .collect(Collectors.toSet());

        // Categorize leave types individually: CL, CML, PL, EL, ABSENT, SUSPENSION, PERMISSION, SICK, WEEKLY OFF
        List<Personnel> onLeaveCl = new ArrayList<>();
        List<Personnel> onLeaveCml = new ArrayList<>();
        List<Personnel> onLeavePl = new ArrayList<>();
        List<Personnel> onLeaveEl = new ArrayList<>();
        List<Personnel> absent = new ArrayList<>();
        List<Personnel> suspension = new ArrayList<>();
        List<Personnel> permission = new ArrayList<>();
        List<Personnel> sick = new ArrayList<>();
        List<Personnel> weeklyOff = new ArrayList<>();

        for (Personnel p : sectionPersonnel) {
            if (!onLeaveIds.contains(p.getId())) {
                // Check duty-based leave indicators
                if (hasDutyContaining(p, "ABSENT")) {
                    absent.add(p);
                } else if (hasDutyContaining(p, "SUSPENSION")) {
                    suspension.add(p);
                } else if (hasDutyContaining(p, "PERMISSION")) {
                    permission.add(p);
                } else if (hasDutyContaining(p, "SICK")) {
                    sick.add(p);
                } else if (hasDutyContaining(p, "WEEKLY OFF") || hasDutyContaining(p, "W/OFF")) {
                    weeklyOff.add(p);
                }
                continue;
            }

            String leaveType = leaveTypeByPersonnelId.getOrDefault(p.getId(), "");
            switch (leaveType.toUpperCase()) {
                case "ABSENT":
                    absent.add(p);
                    break;
                case "SUSPENSION":
                    suspension.add(p);
                    break;
                case "PERMISSION":
                    permission.add(p);
                    break;
                case "SICK":
                case "SICK_LEAVE":
                    sick.add(p);
                    break;
                case "W/OFF":
                case "WEEKLY OFF":
                case "WEEKLY_OFF":
                    weeklyOff.add(p);
                    break;
                case "COMMUTED_LEAVE":
                case "COMPENSATORY_OFF":
                case "CML":
                case "COMP_OFF":
                    onLeaveCml.add(p);
                    break;
                case "PATERNITY_LEAVE":
                case "PRIVILEGE_LEAVE":
                case "PL":
                    onLeavePl.add(p);
                    break;
                case "EARNED_LEAVE":
                case "EL":
                    onLeaveEl.add(p);
                    break;
                case "CASUAL_LEAVE":
                case "CL":
                default:
                    onLeaveCl.add(p);
                    break;
            }
        }

        // ALWAYS include all leave category rows even when empty (show zeros)
        leaveMap.put("CL (CASUAL LEAVE)", onLeaveCl);
        leaveMap.put("CML (COMMUTED LEAVE)", onLeaveCml);
        leaveMap.put("PL (PATERNITY LEAVE)", onLeavePl);
        leaveMap.put("EL (EARNED LEAVE)", onLeaveEl);
        leaveMap.put("ABSENT", absent);
        leaveMap.put("SUSPENSION", suspension);
        leaveMap.put("PERMISSION / RH TO RPI, RSI AND ARSI'S", permission);
        leaveMap.put("SICK", sick);
        leaveMap.put("WEEKLY OFF TO AHC APC", weeklyOff);

        // Do NOT remove empty entries — Book 1 always shows all leave rows with 0 values

        return buildSubsectionAlwaysShowRows("LEAVE", leaveMap);
    }

    /**
     * Builds a subsection that ALWAYS renders all rows (even when the personnel list is empty).
     * Used for leave categories that must always appear per the Book 1 PDF reference.
     */
    private SubsectionModel buildSubsectionAlwaysShowRows(String name, Map<String, List<Personnel>> dutyMap) {
        List<DutyRowModel> rows = new ArrayList<>();
        int serialNumber = 1;
        int[] subsectionTotal = new int[8]; // ACP, RPI, RSI, ARSI, AHC, APC, SWP, TOTAL

        for (Map.Entry<String, List<Personnel>> entry : dutyMap.entrySet()) {
            List<Personnel> personnel = entry.getValue();
            int[] counts = countByDesignation(personnel);
            rows.add(DutyRowModel.builder()
                    .serialNumber(serialNumber++)
                    .dutyDescription(entry.getKey())
                    .counts(Arrays.copyOfRange(counts, 0, 7)) // ACP through SWP
                    .total(counts[7])
                    .personnelDetails(formatPersonnelDetails(personnel))
                    .build());

            for (int i = 0; i < 8; i++) {
                subsectionTotal[i] += counts[i];
            }
        }

        return SubsectionModel.builder()
                .name(name)
                .rows(rows)
                .total(subsectionTotal)
                .build();
    }

    /**
     * Builds a duty map using simple single-keyword matching (OR logic).
     * Each key maps to personnel matching ANY of the keywords in their duty.
     */
    private Map<String, List<Personnel>> buildDutyMap(List<Personnel> all, Map<String, List<String>> dutyKeywords) {
        Map<String, List<Personnel>> result = new LinkedHashMap<>();
        for (Map.Entry<String, List<String>> entry : dutyKeywords.entrySet()) {
            List<String> keywords = entry.getValue();
            List<Personnel> matched;
            if (keywords.size() == 1) {
                matched = all.stream()
                        .filter(p -> hasDutyContaining(p, keywords.get(0)))
                        .collect(Collectors.toList());
            } else {
                // AND logic: personnel must match ALL keywords
                matched = all.stream()
                        .filter(p -> keywords.stream().allMatch(kw -> hasDutyContaining(p, kw)))
                        .collect(Collectors.toList());
            }
            if (!matched.isEmpty()) {
                result.put(entry.getKey(), matched);
            }
        }
        return result;
    }

    /**
     * Builds a duty map preserving insertion order, using AND logic for multiple keywords.
     * Entries with empty results are included but will be filtered during subsection building.
     */
    private Map<String, List<Personnel>> buildDutyMapOrdered(List<Personnel> all,
                                                              Map<String, List<String>> dutyKeywords) {
        Map<String, List<Personnel>> result = new LinkedHashMap<>();
        for (Map.Entry<String, List<String>> entry : dutyKeywords.entrySet()) {
            List<String> keywords = entry.getValue();
            List<Personnel> matched;
            if (keywords.size() == 1) {
                matched = all.stream()
                        .filter(p -> hasDutyContaining(p, keywords.get(0)))
                        .collect(Collectors.toList());
            } else {
                // AND logic: personnel must match ALL keywords
                matched = all.stream()
                        .filter(p -> keywords.stream().allMatch(kw -> hasDutyContaining(p, kw)))
                        .collect(Collectors.toList());
            }
            result.put(entry.getKey(), matched);
        }
        return result;
    }

    private String determineDutyDescription(Personnel p) {
        if (p.getDutyLocation() != null && !p.getDutyLocation().isEmpty()) {
            return p.getDutyLocation();
        }
        if (p.getDutyType() != null && !p.getDutyType().isEmpty()) {
            return p.getDutyType();
        }
        return "CAR HQ";
    }

    private String normalizeLeaveType(String leaveType) {
        if (leaveType == null) return "CL (CASUAL LEAVE)";
        switch (leaveType.toUpperCase().trim()) {
            case "CL":
            case "CASUAL_LEAVE":
                return "CL (CASUAL LEAVE)";
            case "CML":
            case "COMMUTED_LEAVE":
            case "COMPENSATORY_OFF":
            case "COMP_OFF":
                return "CML (COMMUTED LEAVE)";
            case "PL":
            case "PATERNITY_LEAVE":
            case "PRIVILEGE_LEAVE":
                return "PL (PATERNITY LEAVE)";
            case "EL":
            case "EARNED_LEAVE":
                return "EL (EARNED LEAVE)";
            case "W/OFF":
            case "WEEKLY OFF":
            case "WEEKLY_OFF":
                return "WEEKLY OFF";
            case "PERMISSION":
                return "PERMISSION";
            case "ABSENT":
                return "ABSENT";
            case "SUSPENSION":
                return "SUSPENSION";
            case "SICK":
            case "SICK_LEAVE":
                return "SICK";
            default:
                return "CL (CASUAL LEAVE)";
        }
    }

    private String formatBadgeOrName(Personnel p) {
        String badgeId = p.getBadgeId() != null ? p.getBadgeId().trim() : "";
        String name = p.getPersonName() != null ? p.getPersonName().trim() : "";
        String desig = p.getDesignation() != null ? p.getDesignation().toUpperCase().trim() : "";

        // Priority: badge_id first (if real — not empty, not "-", not AUTO), fallback to name
        boolean hasRealBadgeId = !badgeId.isEmpty() && !badgeId.equals("-") && !badgeId.contains("AUTO");
        if (hasRealBadgeId) {
            return badgeId;
        }
        if (!name.isEmpty()) {
            String displayName = name.toUpperCase().startsWith("SRI ") ? name.substring(4) : name;
            return desig + " SRI " + displayName;
        }
        return "";
    }
}

package com.policescheduler.controller;

import com.policescheduler.dto.SanctionedStrengthDto;
import com.policescheduler.dto.StrengthMetricsDto;
import com.policescheduler.dto.UpdateSanctionedStrengthRequest;
import com.policescheduler.service.SanctionedStrengthService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/strength")
public class SanctionedStrengthController {

    private final SanctionedStrengthService sanctionedStrengthService;

    public SanctionedStrengthController(SanctionedStrengthService sanctionedStrengthService) {
        this.sanctionedStrengthService = sanctionedStrengthService;
    }

    /**
     * Get all sanctioned strength entries ordered by display order
     */
    @GetMapping("/sanctioned")
    public ResponseEntity<List<SanctionedStrengthDto>> getAllSanctionedStrength() {
        return ResponseEntity.ok(sanctionedStrengthService.getAllSanctionedStrength());
    }

    /**
     * Get sanctioned strength by designation
     */
    @GetMapping("/sanctioned/{designation}")
    public ResponseEntity<SanctionedStrengthDto> getByDesignation(@PathVariable String designation) {
        return ResponseEntity.ok(sanctionedStrengthService.getByDesignation(designation));
    }

    /**
     * Update sanctioned strength for a designation (creates if not exists)
     */
    @PutMapping("/sanctioned")
    @PreAuthorize("hasAnyRole('ADMIN', 'HIGHER_OFFICER')")
    public ResponseEntity<SanctionedStrengthDto> updateSanctionedStrength(
            @Valid @RequestBody UpdateSanctionedStrengthRequest request) {
        return ResponseEntity.ok(sanctionedStrengthService.updateSanctionedStrength(request));
    }

    /**
     * Bulk update sanctioned strength for multiple designations
     */
    @PutMapping("/sanctioned/bulk")
    @PreAuthorize("hasAnyRole('ADMIN', 'HIGHER_OFFICER')")
    public ResponseEntity<List<SanctionedStrengthDto>> bulkUpdateSanctionedStrength(
            @Valid @RequestBody List<UpdateSanctionedStrengthRequest> requests) {
        return ResponseEntity.ok(sanctionedStrengthService.bulkUpdateSanctionedStrength(requests));
    }

    /**
     * Get complete strength metrics (sanctioned, present, vacancy) for all designations
     */
    @GetMapping("/metrics")
    public ResponseEntity<StrengthMetricsDto> getStrengthMetrics() {
        return ResponseEntity.ok(sanctionedStrengthService.getStrengthMetrics());
    }
}

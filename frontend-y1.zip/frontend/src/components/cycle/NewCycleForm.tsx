import React, { useState, useEffect, useMemo } from 'react';
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
  Select,
  MenuItem,
  FormControl,
  ToggleButton,
  ToggleButtonGroup,
} from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import RotateRightIcon from '@mui/icons-material/RotateRight';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import PeopleIcon from '@mui/icons-material/People';
import api from '@/services/api';

interface NewCycleFormProps {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

interface PreviousCycleInfo {
  hasPrevious: boolean;
  cycleId?: number;
  cycleNumber?: number;
  startDate?: string;
  endDate?: string;
  workingDays?: number;
  platoonDetails?: {
    platoonId: number;
    platoonName: string;
    currentSectionId: number;
    currentSectionName: string;
    currentSectionCode: string;
    personnelStrength: number;
  }[];
}

interface RotationPreview {
  preview: {
    platoonId: number;
    platoonName: string;
    previousSection: string;
    previousSectionCode: string;
    nextSectionId: number;
    nextSection: string;
    nextSectionCode: string;
    personnelStrength: number;
  }[];
  rotationSections: { id: number; code: string; name: string; order: number }[];
}

interface EndDateResult {
  startDate: string;
  workingDays: number;
  endDate: string;
  calendarDays: number;
}

const NewCycleForm: React.FC<NewCycleFormProps> = ({ open, onClose, onSuccess }) => {
  const [startDate, setStartDate] = useState('');
  const [workingDays, setWorkingDays] = useState<number | ''>(30);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Half-month period selector
  const [selectedMonth, setSelectedMonth] = useState('');
  const [selectedHalf, setSelectedHalf] = useState<'first' | 'second'>('first');

  // Previous cycle info
  const [prevInfo, setPrevInfo] = useState<PreviousCycleInfo | null>(null);
  const [loadingPrev, setLoadingPrev] = useState(false);

  // Rotation preview
  const [preview, setPreview] = useState<RotationPreview | null>(null);
  const [loadingPreview, setLoadingPreview] = useState(false);

  // Editable platoon-section mappings: platoonId -> sectionId
  const [platoonSections, setPlatoonSections] = useState<Record<number, number>>({});

  // End date calculation
  const [endDateResult, setEndDateResult] = useState<EndDateResult | null>(null);
  const [loadingEndDate, setLoadingEndDate] = useState(false);

  // Next available date
  const [minStartDate, setMinStartDate] = useState('');

  // Load data when dialog opens
  useEffect(() => {
    if (!open) return;

    setError(null);

    // Fetch previous cycle info
    setLoadingPrev(true);
    api.get('/api/cycles/previous-info')
      .then((r) => setPrevInfo(r.data))
      .catch(() => setPrevInfo(null))
      .finally(() => setLoadingPrev(false));

    // Fetch rotation preview
    setLoadingPreview(true);
    api.get('/api/cycles/rotation-preview')
      .then((r) => {
        setPreview(r.data);
        // Initialize editable platoon-section mappings from preview
        if (r.data?.preview) {
          const mappings: Record<number, number> = {};
          r.data.preview.forEach((row: any) => {
            if (row.nextSectionId) {
              mappings[row.platoonId] = row.nextSectionId;
            }
          });
          setPlatoonSections(mappings);
        }
      })
      .catch(() => setPreview(null))
      .finally(() => setLoadingPreview(false));

    // Fetch next available date
    api.get('/api/cycles/next-available-date')
      .then((r) => {
        const nextDate = r.data.nextAvailableDate;
        setMinStartDate(nextDate);
        // Pre-fill the half-month selector based on next available date
        if (nextDate) {
          const [year, mon, day] = nextDate.split('-').map(Number);
          const monthStr = `${year}-${String(mon).padStart(2, '0')}`;
          setSelectedMonth(monthStr);
          if (day <= 15) {
            setSelectedHalf('first');
            setStartDate(`${year}-${String(mon).padStart(2, '0')}-01`);
            setWorkingDays(15);
          } else {
            setSelectedHalf('second');
            setStartDate(`${year}-${String(mon).padStart(2, '0')}-16`);
            const lastDay = new Date(year, mon, 0).getDate();
            setWorkingDays(lastDay - 15);
          }
        }
      })
      .catch(() => {});
  }, [open]);

  // Calculate end date when startDate or workingDays changes
  useEffect(() => {
    if (!startDate || !workingDays || workingDays < 1) {
      setEndDateResult(null);
      return;
    }

    setLoadingEndDate(true);
    api.get('/api/cycles/calculate-end-date', {
      params: { startDate, workingDays },
    })
      .then((r) => setEndDateResult(r.data))
      .catch(() => setEndDateResult(null))
      .finally(() => setLoadingEndDate(false));
  }, [startDate, workingDays]);

  const isFormValid = useMemo(
    () => startDate !== '' && workingDays !== '' && workingDays >= 1,
    [startDate, workingDays],
  );

  const handleSubmit = async () => {
    if (!isFormValid) return;
    setSubmitting(true);
    setError(null);

    try {
      // Build overrides map (only if user has made selections)
      const overrides = Object.keys(platoonSections).length > 0
        ? Object.fromEntries(
            Object.entries(platoonSections).map(([k, v]) => [k, v])
          )
        : null;

      // Calculate fixed end date for half-month periods
      let endDate: string | null = null;
      if (selectedMonth && selectedHalf) {
        const [year, mon] = selectedMonth.split('-').map(Number);
        if (selectedHalf === 'first') {
          endDate = `${year}-${String(mon).padStart(2, '0')}-15`;
        } else {
          const lastDay = new Date(year, mon, 0).getDate();
          endDate = `${year}-${String(mon).padStart(2, '0')}-${lastDay}`;
        }
      }

      await api.post('/api/cycles/rotation', {
        startDate,
        workingDays: workingDays as number,
        platoonSectionOverrides: overrides,
        endDate,
      });
      onSuccess();
      handleReset();
      onClose();
    } catch (err: any) {
      const msg = err?.response?.data?.error || err?.message || 'Failed to create cycle';
      setError(msg);
    } finally {
      setSubmitting(false);
    }
  };

  const handleReset = () => {
    setStartDate('');
    setWorkingDays(30);
    setError(null);
    setEndDateResult(null);
    setPrevInfo(null);
    setPreview(null);
    setPlatoonSections({});
    setSelectedMonth('');
    setSelectedHalf('first');
  };

  const handleClose = () => {
    if (!submitting) {
      handleReset();
      onClose();
    }
  };

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return '—';
    const d = new Date(dateStr + 'T00:00:00');
    return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  };

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ fontWeight: 700, pb: 0.5 }}>
        Create Rotation Cycle
      </DialogTitle>
      <DialogContent>
        <Stack spacing={3} sx={{ mt: 1 }}>
          {error && (
            <Alert severity="error" onClose={() => setError(null)}>
              {error}
            </Alert>
          )}

          {/* Previous Cycle Information */}
          {loadingPrev ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 2 }}>
              <CircularProgress size={24} />
            </Box>
          ) : prevInfo?.hasPrevious ? (
            <Card variant="outlined" sx={{ borderColor: '#d1fae5', bgcolor: '#f0fdf4' }}>
              <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1.5 }}>
                  <CalendarTodayIcon sx={{ fontSize: 18, color: '#059669' }} />
                  <Typography variant="subtitle2" fontWeight={700} color="#065f46">
                    Previous Cycle #{prevInfo.cycleNumber}
                  </Typography>
                  <Chip
                    label={`${formatDate(prevInfo.startDate)} → ${formatDate(prevInfo.endDate)}`}
                    size="small"
                    sx={{ fontSize: '0.7rem', bgcolor: '#d1fae5', color: '#065f46' }}
                  />
                  {prevInfo.workingDays && (
                    <Chip label={`${prevInfo.workingDays} working days`} size="small" variant="outlined" sx={{ fontSize: '0.7rem' }} />
                  )}
                </Stack>
                {prevInfo.platoonDetails && (
                  <TableContainer>
                    <Table size="small">
                      <TableHead>
                        <TableRow>
                          <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem' }}>Platoon</TableCell>
                          <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem' }}>Current Section</TableCell>
                          <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem' }} align="center">Strength</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {prevInfo.platoonDetails.map((pd) => (
                          <TableRow key={pd.platoonId}>
                            <TableCell sx={{ fontSize: '0.8rem', fontWeight: 500 }}>{pd.platoonName}</TableCell>
                            <TableCell sx={{ fontSize: '0.8rem' }}>
                              <Chip label={`${pd.currentSectionCode} - ${pd.currentSectionName}`} size="small" variant="outlined" />
                            </TableCell>
                            <TableCell align="center" sx={{ fontSize: '0.8rem' }}>
                              <Stack direction="row" alignItems="center" justifyContent="center" spacing={0.5}>
                                <PeopleIcon sx={{ fontSize: 14, color: '#6B7280' }} />
                                <span>{pd.personnelStrength}</span>
                              </Stack>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                )}
              </CardContent>
            </Card>
          ) : (
            <Alert severity="info" sx={{ borderRadius: 2 }}>
              No previous cycle found. This will be the first rotation cycle.
            </Alert>
          )}

          {/* Rotation Preview */}
          {loadingPreview ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 1 }}>
              <CircularProgress size={20} />
            </Box>
          ) : preview?.preview && preview.preview.length > 0 && (
            <Card variant="outlined" sx={{ borderColor: '#e0e7ff', bgcolor: '#eef2ff' }}>
              <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1.5 }}>
                  <RotateRightIcon sx={{ fontSize: 18, color: '#4338ca' }} />
                  <Typography variant="subtitle2" fontWeight={700} color="#312e81">
                    Next Rotation Preview
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    (click section to change)
                  </Typography>
                </Stack>
                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem' }}>Platoon</TableCell>
                        <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem' }}>→ Next Section</TableCell>
                        <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem' }} align="center">Strength</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {preview.preview.map((row) => {
                        const selectedSectionId = platoonSections[row.platoonId] || 0;
                        // Sections already assigned to other platoons
                        const usedSectionIds = Object.entries(platoonSections)
                          .filter(([pid]) => Number(pid) !== row.platoonId)
                          .map(([, sid]) => sid);

                        return (
                          <TableRow key={row.platoonId}>
                            <TableCell sx={{ fontSize: '0.8rem', fontWeight: 500 }}>{row.platoonName}</TableCell>
                            <TableCell sx={{ fontSize: '0.8rem' }}>
                              <FormControl size="small" sx={{ minWidth: 200 }}>
                                <Select
                                  value={selectedSectionId}
                                  onChange={(e) => {
                                    const newSectionId = e.target.value as number;
                                    setPlatoonSections((prev) => {
                                      const updated = { ...prev };
                                      // Find if another platoon already has this section — swap
                                      const otherPlatoonId = Object.entries(prev)
                                        .find(([pid, sid]) => Number(pid) !== row.platoonId && sid === newSectionId);
                                      if (otherPlatoonId) {
                                        // Swap: give the other platoon this platoon's current section
                                        updated[Number(otherPlatoonId[0])] = prev[row.platoonId];
                                      }
                                      updated[row.platoonId] = newSectionId;
                                      return updated;
                                    });
                                  }}
                                  sx={{ fontSize: '0.8rem', borderRadius: 2, bgcolor: '#fff' }}
                                >
                                  {preview.rotationSections.map((sec) => {
                                    const isUsed = usedSectionIds.includes(sec.id);
                                    return (
                                      <MenuItem
                                        key={sec.id}
                                        value={sec.id}
                                        sx={isUsed ? { color: '#6366f1', fontStyle: 'italic' } : undefined}
                                      >
                                        {sec.code} - {sec.name}{isUsed ? ' (swap)' : ''}
                                      </MenuItem>
                                    );
                                  })}
                                </Select>
                              </FormControl>
                            </TableCell>
                            <TableCell align="center" sx={{ fontSize: '0.8rem' }}>{row.personnelStrength}</TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </TableContainer>
              </CardContent>
            </Card>
          )}

          <Divider />

          {/* Half-Month Period Selector */}
          <Box>
            <Typography variant="subtitle2" fontWeight={600} sx={{ mb: 1 }}>
              Cycle Period
            </Typography>
            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} alignItems="flex-start">
              <TextField
                label="Month"
                type="month"
                value={selectedMonth}
                onChange={(e) => {
                  const month = e.target.value;
                  setSelectedMonth(month);
                  if (month) {
                    const [year, mon] = month.split('-').map(Number);
                    if (selectedHalf === 'first') {
                      setStartDate(`${year}-${String(mon).padStart(2, '0')}-01`);
                      // Working days = calendar days from 1st to 15th
                      setWorkingDays(15);
                    } else {
                      setStartDate(`${year}-${String(mon).padStart(2, '0')}-16`);
                      const lastDay = new Date(year, mon, 0).getDate();
                      // Working days = calendar days from 16th to end
                      setWorkingDays(lastDay - 15);
                    }
                  }
                }}
                size="small"
                InputLabelProps={{ shrink: true }}
                sx={{ minWidth: 180 }}
              />
              <ToggleButtonGroup
                value={selectedHalf}
                exclusive
                onChange={(_, value) => {
                  if (!value) return;
                  setSelectedHalf(value);
                  if (selectedMonth) {
                    const [year, mon] = selectedMonth.split('-').map(Number);
                    if (value === 'first') {
                      setStartDate(`${year}-${String(mon).padStart(2, '0')}-01`);
                      setWorkingDays(15);
                    } else {
                      setStartDate(`${year}-${String(mon).padStart(2, '0')}-16`);
                      const lastDay = new Date(year, mon, 0).getDate();
                      setWorkingDays(lastDay - 15);
                    }
                  }
                }}
                size="small"
                sx={{ height: 40 }}
              >
                <ToggleButton value="first" sx={{ textTransform: 'none', fontWeight: 600, px: 2 }}>
                  1st – 15th
                </ToggleButton>
                <ToggleButton value="second" sx={{ textTransform: 'none', fontWeight: 600, px: 2 }}>
                  16th – End
                </ToggleButton>
              </ToggleButtonGroup>
            </Stack>
          </Box>

          {/* Form Fields */}
          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2}>
            <TextField
              label="Start Date"
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              required
              fullWidth
              size="small"
              InputLabelProps={{ shrink: true }}
              helperText={minStartDate ? `Next available: ${formatDate(minStartDate)}` : undefined}
            />
            <TextField
              label="Number of Working Days"
              type="number"
              value={workingDays}
              onChange={(e) => {
                const val = e.target.value;
                setWorkingDays(val === '' ? '' : Math.max(1, parseInt(val, 10) || 1));
              }}
              required
              fullWidth
              size="small"
              inputProps={{ min: 1 }}
              helperText="Total days in this cycle"
            />
          </Stack>

          {/* Calculated End Date */}
          {loadingEndDate ? (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <CircularProgress size={16} />
              <Typography variant="body2" color="text.secondary">Calculating end date...</Typography>
            </Box>
          ) : endDateResult && (
            <Card variant="outlined" sx={{ bgcolor: '#f8fafc' }}>
              <CardContent sx={{ p: 1.5, '&:last-child': { pb: 1.5 } }}>
                <Stack direction="row" alignItems="center" spacing={2}>
                  <Box>
                    <Typography variant="caption" color="text.secondary">Calculated End Date</Typography>
                    <Typography variant="body1" fontWeight={700}>
                      {formatDate(endDateResult.endDate)}
                    </Typography>
                  </Box>
                  <Chip
                    label={`${endDateResult.calendarDays} calendar days`}
                    size="small"
                    variant="outlined"
                  />
                  <Chip
                    label={`${endDateResult.workingDays} working days`}
                    size="small"
                    sx={{ bgcolor: '#dbeafe', color: '#1e40af' }}
                  />
                </Stack>
              </CardContent>
            </Card>
          )}
        </Stack>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2.5 }}>
        <Button onClick={handleClose} disabled={submitting} sx={{ textTransform: 'none' }}>
          Cancel
        </Button>
        <Button
          variant="contained"
          onClick={handleSubmit}
          disabled={!isFormValid || submitting}
          startIcon={submitting ? <CircularProgress size={16} color="inherit" /> : <CheckCircleIcon />}
          sx={{ textTransform: 'none', fontWeight: 600, borderRadius: 2 }}
        >
          {submitting ? 'Creating...' : 'Create Cycle'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default NewCycleForm;

package com.policescheduler.report.model;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class OfficerDutyModel {
    // Part 1: Officer's Duty counted section (10-column format like Sections A-G)
    private List<SubsectionModel> subsections; // VIP ESCORTS/PILOT, OTHER DUTY'S, LEAVE
    private int[] subTotal; // 8 elements (ACP, RPI, RSI, ARSI, AHC, APC, SWP, TOTAL)
    private int[] grandTotalCompany; // 8 elements (sum of ALL sections A-G + officer duty sub total)

    // Under Training / Without Training section
    private List<SubsectionModel> underTrainingSubsections; // BASIC TRAINING PTS DHARWAD, RECRUIT APC'S
    private int[] underTrainingTotal; // 8 elements
    private SubsectionModel underTrainingLeave; // Leave subsection for under training
    private int[] underTrainingLeaveTotal; // 8 elements (total of under training leave)
    private int[] pmtLine; // 8 elements
    private int[] grandTotal; // 8 elements (final grand total)

    // Part 2: Separate 3-column NAME | DESIGNATION | DUTY table
    private List<OfficerRow> officers;
}

import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import {
  Box,
  Card,
  CardActionArea,
  Typography,
  Stack,
  Chip,
  IconButton,
  TextField,
  Collapse,
  Button,
  CircularProgress,
  Snackbar,
  Alert,
  InputAdornment,
  Tooltip,
  Paper,
  List,
  ListItemButton,
  ListItemText,
  Divider,
  Badge,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
} from '@mui/material';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import BadgeIcon from '@mui/icons-material/Badge';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import EditIcon from '@mui/icons-material/Edit';
import EventAvailableIcon from '@mui/icons-material/EventAvailable';
import { useTranslation } from 'react-i18next';
import { useSearchParams } from 'react-router-dom';
import Carousel from '@/components/common/Carousel';
import Form168TableView from '@/components/Form168TableView';
import {
  sectionChartService,
  type SectionChartData,
  type DutyCard,
  type SubDutyGroup,
  type ChartPersonnel,
  type PersonnelSearchResult,
} from '@/services/sectionChartService';
import { leaveService } from '@/services/leaveService';
import api from '@/services/api';
import type { LeaveRequestDto, CreateLeaveRequest } from '@/types';

// ===== Section Definitions =====
const SECTIONS = [
  { id: 'A', nameKey: 'assignDuties.sections.sectionA', descKey: 'assignDuties.sections.sectionADesc', color: '#312e81', bgColor: '#eef2ff' },
  { id: 'B', nameKey: 'assignDuties.sections.sectionB', descKey: 'assignDuties.sections.sectionBDesc', color: '#0d9488', bgColor: '#f0fdfa' },
  { id: 'C', nameKey: 'assignDuties.sections.sectionC', descKey: 'assignDuties.sections.sectionCDesc', color: '#7c3aed', bgColor: '#f5f3ff' },
  { id: 'D', nameKey: 'assignDuties.sections.sectionD', descKey: 'assignDuties.sections.sectionDDesc', color: '#dc2626', bgColor: '#fef2f2' },
  { id: 'E', nameKey: 'assignDuties.sections.sectionE', descKey: 'assignDuties.sections.sectionEDesc', color: '#d97706', bgColor: '#fffbeb' },
  { id: 'F', nameKey: 'assignDuties.sections.sectionF', descKey: 'assignDuties.sections.sectionFDesc', color: '#2563eb', bgColor: '#eff6ff' },
  { id: 'G', nameKey: 'assignDuties.sections.sectionG', descKey: 'assignDuties.sections.sectionGDesc', color: '#059669', bgColor: '#ecfdf5' },
  { id: 'O', nameKey: 'assignDuties.sections.sectionO', descKey: 'assignDuties.sections.sectionODesc', color: '#be185d', bgColor: '#fdf2f8' },
  { id: 'MT', nameKey: 'assignDuties.sections.sectionMT', descKey: 'assignDuties.sections.sectionMTDesc', color: '#ea580c', bgColor: '#fff7ed' },
  { id: 'TRAINING', nameKey: 'assignDuties.sections.sectionTraining', descKey: 'assignDuties.sections.sectionTrainingDesc', color: '#4338ca', bgColor: '#eef2ff' },
];

// ===== Leave Categories (from Form 168) =====
const LEAVE_CATEGORIES = [
  { name: 'CL (CASUAL LEAVE)', nameKey: 'assignDuties.leaveCategories.casualLeave', descKey: 'assignDuties.leaveCategories.casualLeaveDesc' },
  { name: 'CML (COMPENSATORY LEAVE)', nameKey: 'assignDuties.leaveCategories.compensatoryLeave', descKey: 'assignDuties.leaveCategories.compensatoryLeaveDesc' },
  { name: 'PL (PRIVILEGE LEAVE)', nameKey: 'assignDuties.leaveCategories.privilegeLeave', descKey: 'assignDuties.leaveCategories.privilegeLeaveDesc' },
  { name: 'EL (EARNED LEAVE)', nameKey: 'assignDuties.leaveCategories.earnedLeave', descKey: 'assignDuties.leaveCategories.earnedLeaveDesc' },
  { name: 'ABSENT', nameKey: 'assignDuties.leaveCategories.absent', descKey: 'assignDuties.leaveCategories.absentDesc' },
  { name: 'SUSPENSION', nameKey: 'assignDuties.leaveCategories.suspension', descKey: 'assignDuties.leaveCategories.suspensionDesc' },
  { name: 'PERMISSION / RH TO RPI, RSI AND', nameKey: 'assignDuties.leaveCategories.permission', descKey: 'assignDuties.leaveCategories.permissionDesc' },
  { name: 'SICK', nameKey: 'assignDuties.leaveCategories.sick', descKey: 'assignDuties.leaveCategories.sickDesc' },
  { name: 'WEEKLY OFF', nameKey: 'assignDuties.leaveCategories.weeklyOff', descKey: 'assignDuties.leaveCategories.weeklyOffDesc' },
];

// Global CSS keyframes for highlighting animation
const globalStyles = `
  @keyframes pulse-highlight-global {
    0%, 100% { box-shadow: 0 0 12px rgba(234, 179, 8, 0.4); }
    50% { box-shadow: 0 0 20px rgba(234, 179, 8, 0.6); }
  }
  .highlight-pulse {
    animation: pulse-highlight-global 1s ease-in-out infinite;
  }
`;

// ===== Main Page Component =====
const AssignDutiesPage: React.FC = () => {
  const { t } = useTranslation();
  const [searchParams, setSearchParams] = useSearchParams();
  const [selectedSection, setSelectedSection] = useState<string | null>(searchParams.get('section') || 'A');
  const [chartData, setChartData] = useState<SectionChartData | null>(null);
  const [selectedDutyTypeId, setSelectedDutyTypeId] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [snackbar, setSnackbar] = useState<{ open: boolean; message: string; severity: 'success' | 'error' | 'info' }>({
    open: false, message: '', severity: 'success',
  });
  const [sidebarFilter, setSidebarFilter] = useState('');
  const [showAddDutyType, setShowAddDutyType] = useState(false);
  const [newDutyTypeName, setNewDutyTypeName] = useState('');
  const [newDutySortOrder, setNewDutySortOrder] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState(Number(searchParams.get('tab')) || 0);
  const [selectedLeaveCategory, setSelectedLeaveCategory] = useState<string>(LEAVE_CATEGORIES[0].name);
  
  // Global search state
  const [globalSearchQuery, setGlobalSearchQuery] = useState('');
  const [globalSearchResults, setGlobalSearchResults] = useState<PersonnelSearchResult[]>([]);
  const [globalSearchLoading, setGlobalSearchLoading] = useState(false);
  const [highlightedPersonId, setHighlightedPersonId] = useState<number | null>(null);
  const highlightTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  
  const [deleteDialog, setDeleteDialog] = useState<{
    open: boolean;
    type: 'dutyType' | 'subDuty';
    name: string;
    dutyTypeId?: number;
    subDutyName?: string;
  }>({ open: false, type: 'dutyType', name: '' });

  // Reassignment state
  const [reassignDialog, setReassignDialog] = useState<{
    open: boolean;
    person: ChartPersonnel | null;
    editMode?: boolean;
    editId?: number;
  }>({ open: false, person: null });
  const [reassignForm, setReassignForm] = useState({ replacementId: 0, startDate: '', endDate: '' });
  const [reassignSaving, setReassignSaving] = useState(false);
  const [activeReassignments, setActiveReassignments] = useState<Array<{
    id: number; leavePersonId: number; replacementPersonId: number;
    leavePersonName: string; leavePersonBadgeId: string;
    replacementPersonName: string; replacementPersonBadgeId: string;
    dutyType: string; dutyLocation: string;
    startDate: string; endDate: string; days: number; status: string;
  }>>([]);

  // Note: Duty reassignment expiry is now handled by a scheduled backend job
  // that runs daily at 3:00 AM. See: StatusUpdateSchedulerService.java

  // Load chart data when section changes
  useEffect(() => {
    if (selectedSection) {
      loadChartData(selectedSection);
    } else {
      setChartData(null);
      setSelectedDutyTypeId(null);
    }
  }, [selectedSection]);

  const loadChartData = async (sectionCode: string, showSpinner = true) => {
    if (showSpinner) setLoading(true);
    try {
      const data = await sectionChartService.getChart(sectionCode);
      setChartData(data);
      // Auto-select first duty type if none selected
      if (data.dutyCards.length > 0 && !selectedDutyTypeId) {
        setSelectedDutyTypeId(data.dutyCards[0].dutyTypeId);
      }
      // Load active reassignments for this section
      try {
        const reassignRes = await api.get<typeof activeReassignments>(`/api/duty-reassignments`, { params: { sectionCode } });
        setActiveReassignments(reassignRes.data);
      } catch { setActiveReassignments([]); }
    } catch (err) {
      setSnackbar({ open: true, message: 'Failed to load section data', severity: 'error' });
    } finally {
      setLoading(false);
    }
  };

  const handleSectionClick = (sectionId: string) => {
    setSelectedSection(sectionId);
    setSelectedDutyTypeId(null);
    setSidebarFilter('');
    setShowAddDutyType(false);
    setGlobalSearchQuery('');
    setGlobalSearchResults([]);
    setSearchParams({ section: sectionId, tab: String(activeTab) }, { replace: true });
  };

  const handleAssignPerson = async (personnelId: number, dutyTypeId: number, subDuty?: string | null) => {
    if (!selectedSection) return;
    setSaving(true);
    try {
      await sectionChartService.assign({
        personnelId,
        dutyTypeId,
        sectionCode: selectedSection,
        subDuty: subDuty || null,
      });
      setSnackbar({ open: true, message: '✓ Person assigned successfully', severity: 'success' });
      await loadChartData(selectedSection, false);
    } catch (err) {
      setSnackbar({ open: true, message: 'Failed to assign person', severity: 'error' });
    } finally {
      setSaving(false);
    }
  };

  const handleUnassignPerson = async (personnelId: number) => {
    if (!selectedSection) return;
    setSaving(true);
    try {
      await sectionChartService.unassign({ personnelId });
      setSnackbar({ open: true, message: '✓ Person removed from duty', severity: 'success' });
      await loadChartData(selectedSection, false);
    } catch (err) {
      setSnackbar({ open: true, message: 'Failed to remove person', severity: 'error' });
    } finally {
      setSaving(false);
    }
  };

  const handleAddDutyType = async () => {
    if (!selectedSection || !newDutyTypeName.trim()) return;
    setSaving(true);
    try {
      const maxSort = chartData?.dutyCards.length ?? 0;
      const sortVal = newDutySortOrder ?? (maxSort + 1);
      await sectionChartService.createDutyType({
        name: newDutyTypeName.trim().toUpperCase(),
        section: selectedSection,
        sortOrder: sortVal,
        level: 'PARENT',
      });
      setSnackbar({ open: true, message: '✓ Duty type created', severity: 'success' });
      setNewDutyTypeName('');
      setNewDutySortOrder(null);
      setShowAddDutyType(false);
      await loadChartData(selectedSection, false);
    } catch (err) {
      setSnackbar({ open: true, message: 'Failed to create duty type', severity: 'error' });
    } finally {
      setSaving(false);
    }
  };

  const handleAddSubDuty = async (parentDutyTypeId: number, subDutyName: string, location?: string, sortOrder?: number) => {
    if (!selectedSection || !subDutyName.trim()) return;
    setSaving(true);
    try {
      await sectionChartService.addSubDuty({
        subDutyName: subDutyName.trim().toUpperCase(),
        parentDutyTypeId,
        ...(location ? { location: location.toUpperCase() } : {}),
        ...(sortOrder ? { sortOrder } : {}),
      });
      setSnackbar({ open: true, message: '✓ Sub duty added.', severity: 'success' });
      await loadChartData(selectedSection, false);
    } catch (err) {
      setSnackbar({ open: true, message: 'Failed to add sub duty', severity: 'error' });
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteDutyType = (dutyTypeId: number, name: string) => {
    setDeleteDialog({ open: true, type: 'dutyType', name, dutyTypeId });
  };

  const handleDeleteSubDuty = (dutyTypeId: number, subDutyName: string) => {
    setDeleteDialog({ open: true, type: 'subDuty', name: subDutyName, dutyTypeId, subDutyName });
  };

  const handleRenameDutyType = async (dutyTypeId: number, newName: string) => {
    if (!selectedSection || !newName.trim()) return;
    setSaving(true);
    try {
      await sectionChartService.renameDutyType(dutyTypeId, newName.trim().toUpperCase());
      setSnackbar({ open: true, message: '✓ Renamed successfully', severity: 'success' });
      await loadChartData(selectedSection, false);
    } catch {
      setSnackbar({ open: true, message: 'Failed to rename', severity: 'error' });
    } finally {
      setSaving(false);
    }
  };

  const handleRenameSubDuty = async (parentDutyTypeId: number, oldName: string, newName: string) => {
    if (!selectedSection || !newName.trim()) return;
    setSaving(true);
    try {
      await sectionChartService.renameSubDuty(parentDutyTypeId, oldName, newName.trim().toUpperCase());
      setSnackbar({ open: true, message: '✓ Sub duty renamed successfully', severity: 'success' });
      await loadChartData(selectedSection, false);
    } catch {
      setSnackbar({ open: true, message: 'Failed to rename sub duty', severity: 'error' });
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = async () => {
    if (!selectedSection) return;
    setSaving(true);
    setDeleteDialog((d) => ({ ...d, open: false }));
    try {
      if (deleteDialog.type === 'dutyType' && deleteDialog.dutyTypeId) {
        await sectionChartService.deleteDutyType(deleteDialog.dutyTypeId);
        setSnackbar({ open: true, message: `✓ "${deleteDialog.name}" deleted`, severity: 'success' });
        // If deleted the currently selected, clear selection
        if (selectedDutyTypeId === deleteDialog.dutyTypeId) {
          setSelectedDutyTypeId(null);
        }
      } else if (deleteDialog.type === 'subDuty' && deleteDialog.dutyTypeId && deleteDialog.subDutyName) {
        await sectionChartService.deleteSubDuty(deleteDialog.dutyTypeId, deleteDialog.subDutyName);
        setSnackbar({ open: true, message: `✓ Sub duty "${deleteDialog.name}" deleted`, severity: 'success' });
      }
      await loadChartData(selectedSection, false);
    } catch (err) {
      setSnackbar({ open: true, message: 'Failed to delete', severity: 'error' });
    } finally {
      setSaving(false);
    }
  };

  // Get the selected duty card
  const selectedCard = chartData?.dutyCards.find((c) => c.dutyTypeId === selectedDutyTypeId);
  const selectedData = SECTIONS.find((s) => s.id === selectedSection);

  // Reassignment handler
  const handleOpenReassign = (person: ChartPersonnel) => {
    // Check if this person already has an active reassignment — if so, open in edit mode
    const existing = activeReassignments.find((r) => r.leavePersonId === person.id);
    if (existing) {
      handleEditReassignment(existing);
    } else {
      setReassignDialog({ open: true, person });
      setReassignForm({
        replacementId: 0,
        startDate: person.leaveStartDate || '',
        endDate: person.leaveEndDate || '',
      });
    }
  };

  const handleSubmitReassign = async () => {
    if (!reassignForm.replacementId || !reassignForm.startDate || !reassignForm.endDate || !selectedSection) return;
    setReassignSaving(true);
    try {
      if (reassignDialog.editMode && reassignDialog.editId) {
        // Edit existing reassignment
        await api.put(`/api/duty-reassignments/${reassignDialog.editId}`, {
          replacementPersonId: reassignForm.replacementId,
          startDate: reassignForm.startDate,
          endDate: reassignForm.endDate,
        });
        setSnackbar({ open: true, message: '✓ Reassignment updated successfully', severity: 'success' });
      } else {
        // Create new reassignment
        const person = reassignDialog.person;
        if (!person) return;
        await api.post('/api/duty-reassignments', {
          leavePersonId: person.id,
          replacementPersonId: reassignForm.replacementId,
          leaveRequestId: person.leaveRequestId || null,
          sectionCode: selectedSection,
          dutyType: selectedCard?.dutyTypeName || null,
          dutyLocation: person.dutyLocation || null,
          startDate: reassignForm.startDate,
          endDate: reassignForm.endDate,
        });
        setSnackbar({ open: true, message: '✓ Duty reassigned successfully', severity: 'success' });
      }
      setReassignDialog({ open: false, person: null });
      await loadChartData(selectedSection, false);
      await fetchReassignments(selectedSection);
    } catch (err: unknown) {
      const axiosErr = err as { response?: { data?: { error?: string } } };
      const errorMsg = axiosErr.response?.data?.error || (reassignDialog.editMode ? 'Failed to update reassignment' : 'Failed to reassign duty');
      setSnackbar({ open: true, message: errorMsg, severity: 'error' });
    } finally {
      setReassignSaving(false);
    }
  };

  // Handler to open edit reassignment dialog
  const handleEditReassignment = (r: { id: number; leavePersonId: number; replacementPersonId: number; leavePersonName: string; leavePersonBadgeId: string; startDate: string; endDate: string; days: number; dutyType: string; dutyLocation: string }) => {
    setReassignDialog({
      open: true,
      person: {
        id: r.leavePersonId,
        badgeId: r.leavePersonBadgeId,
        personName: r.leavePersonName,
        designation: '',
        dutyLocation: r.dutyLocation || '',
        onLeave: true,
        leaveStartDate: r.startDate,
        leaveEndDate: r.endDate,
        leaveDays: r.days,
        leaveType: '',
      } as ChartPersonnel,
      editMode: true,
      editId: r.id,
    });
    setReassignForm({
      replacementId: r.replacementPersonId,
      startDate: r.startDate,
      endDate: r.endDate,
    });
  };

  // Reassignment data for current section
  interface ReassignmentRecord {
    id: number;
    leavePersonId: number;
    replacementPersonId: number;
    leavePersonName: string;
    leavePersonBadgeId: string;
    replacementPersonName: string;
    replacementPersonBadgeId: string;
    dutyType: string;
    dutyLocation: string;
    startDate: string;
    endDate: string;
    days: number;
    status: string;
  }
  const [reassignments, setReassignments] = useState<ReassignmentRecord[]>([]);

  const fetchReassignments = useCallback(async (sectionCode: string) => {
    try {
      const res = await api.get<ReassignmentRecord[]>('/api/duty-reassignments', {
        params: { sectionCode },
      });
      setReassignments(res.data);
    } catch {
      setReassignments([]);
    }
  }, []);

  // Fetch reassignments when section changes
  useEffect(() => {
    if (selectedSection) {
      fetchReassignments(selectedSection);
    } else {
      setReassignments([]);
    }
  }, [selectedSection, fetchReassignments]);

  // Build a map: leavePersonId → replacementPersonBadgeId (for showing chip on leave personnel)
  const reassignmentMap = useMemo(() => {
    const map: Record<number, string> = {};
    reassignments.forEach((r) => {
      if (r.status === 'ACTIVE') {
        map[r.leavePersonId] = r.replacementPersonBadgeId || `ID:${r.replacementPersonId}`;
      }
    });
    return map;
  }, [reassignments]);

  // Global search handlers
  const handleGlobalSearch = useCallback(async (query: string) => {
    setGlobalSearchQuery(query);
    if (!query || query.length < 2) {
      setGlobalSearchResults([]);
      return;
    }
    setGlobalSearchLoading(true);
    try {
      const results = await sectionChartService.searchPersonnel(query, 15);
      setGlobalSearchResults(results);
    } catch {
      setGlobalSearchResults([]);
    } finally {
      setGlobalSearchLoading(false);
    }
  }, []);

  const handleGlobalSearchSelect = useCallback(async (person: PersonnelSearchResult | null) => {
    if (!person) return;
    setGlobalSearchQuery('');
    setGlobalSearchResults([]);
    
    // Clear previous highlight timeout
    if (highlightTimeoutRef.current) {
      clearTimeout(highlightTimeoutRef.current);
    }
    
    // Check if person is on leave
    const today = new Date().toISOString().split('T')[0];
    try {
      const leaveResult = await leaveService.list(undefined, 0, 100);
      const activeLeave = leaveResult.content.find(
        (lr) => lr.personnelId === person.id && 
                lr.status === 'APPROVED' && 
                lr.startDate <= today && 
                (!lr.endDate || lr.endDate >= today)
      );
      
      if (activeLeave) {
        // Person is on leave - navigate to Leave Management tab
        const sectionData = SECTIONS.find(s => s.id === person.currentSection);
        if (sectionData) {
          setSelectedSection(person.currentSection);
          setSearchParams({ section: person.currentSection, tab: '1' }, { replace: true });
        }
        setActiveTab(1);
        
        // Find the leave category to select
        const displayName = BACKEND_TO_DISPLAY[activeLeave.leaveType] || activeLeave.leaveType;
        if (LEAVE_CATEGORIES.find(c => c.name === displayName)) {
          setSelectedLeaveCategory(displayName);
        }
        
        // Highlight the person and scroll into view
        setHighlightedPersonId(person.id);
        highlightTimeoutRef.current = setTimeout(() => setHighlightedPersonId(null), 5000);
        
        // Scroll to highlighted element after a short delay for React to render
        setTimeout(() => {
          const highlightedRow = document.querySelector('.highlight-pulse');
          if (highlightedRow) {
            highlightedRow.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
        }, 300);
        
        setSnackbar({ open: true, message: `Found ${person.personName} on ${activeLeave.leaveType.replace(/_/g, ' ')}`, severity: 'success' });
        return;
      }
    } catch {
      // Continue with duty management navigation
    }
    
    // Person is not on leave - navigate to their section and duty
    if (person.currentSection) {
      setSelectedSection(person.currentSection);
      setSearchParams({ section: person.currentSection, tab: '0' }, { replace: true });
      setActiveTab(0);
      
      // Load chart data and find the duty type
      try {
        const data = await sectionChartService.getChart(person.currentSection);
        setChartData(data);
        
        // Find the duty type that contains this person
        for (const card of data.dutyCards) {
          // Check main personnel
          const foundInMain = card.personnel.find(p => p.id === person.id);
          if (foundInMain) {
            setSelectedDutyTypeId(card.dutyTypeId);
            break;
          }
          // Check sub-duties
          for (const sub of card.subDuties) {
            const foundInSub = sub.personnel.find(p => p.id === person.id);
            if (foundInSub) {
              setSelectedDutyTypeId(card.dutyTypeId);
              break;
            }
          }
        }
        
        // Highlight the person
        setHighlightedPersonId(person.id);
        highlightTimeoutRef.current = setTimeout(() => setHighlightedPersonId(null), 5000);
        
        // Scroll to highlighted element after a short delay for React to render
        setTimeout(() => {
          const highlightedElement = document.querySelector('[data-highlighted="true"]');
          if (highlightedElement) {
            highlightedElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
        }, 300);
        
        setSnackbar({ open: true, message: `Found ${person.personName} in Section ${person.currentSection}`, severity: 'success' });
      } catch {
        setSnackbar({ open: true, message: 'Failed to load section data', severity: 'error' });
      }
    } else {
      setSnackbar({ open: true, message: `${person.personName} is not assigned to any section`, severity: 'info' });
    }
  }, [setSearchParams]);

  // Cleanup highlight timeout on unmount
  useEffect(() => {
    return () => {
      if (highlightTimeoutRef.current) {
        clearTimeout(highlightTimeoutRef.current);
      }
    };
  }, []);

  // Filter sidebar duty types
  const filteredDutyCards = chartData?.dutyCards.filter((card) => {
    if (!sidebarFilter) return true;
    return card.dutyTypeName.toLowerCase().includes(sidebarFilter.toLowerCase());
  }) ?? [];

  return (
    <>
      {/* Global CSS for highlighting animation */}
      <style>{globalStyles}</style>
      
      <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', bgcolor: 'background.default' }}>
      
      {/* Header with Search on Right */}
      <Box sx={{ bgcolor: 'background.paper', borderBottom: '1px solid', borderColor: 'divider' }}>
        <Box sx={{ px: { xs: 2, md: 3 }, pt: 2, pb: 1.5 }}>
          <Stack direction="row" justifyContent="space-between" alignItems="flex-start" spacing={2}>
            {/* Left: Breadcrumbs and Title */}
            <Box>
              <Stack direction="row" spacing={0.5} alignItems="center" sx={{ mb: 0.5 }}>
                <Typography 
                  component="a" 
                  href="/" 
                  sx={{ fontSize: '0.75rem', color: 'text.secondary', textDecoration: 'none', '&:hover': { textDecoration: 'underline' } }}
                >
                  {t('nav.home', 'Home')}
                </Typography>
                <Typography sx={{ fontSize: '0.75rem', color: 'text.disabled' }}>{'>'}</Typography>
                <Typography sx={{ fontSize: '0.75rem', color: 'text.secondary' }}>
                  {t('nav.groups.operations', 'Operations')}
                </Typography>
                <Typography sx={{ fontSize: '0.75rem', color: 'text.disabled' }}>{'>'}</Typography>
                <Typography sx={{ fontSize: '0.75rem', color: 'text.primary', fontWeight: 500 }}>
                  {t('nav.assignDuties', 'Assign Duties')}
                </Typography>
              </Stack>
              <Typography variant="h5" sx={{ fontWeight: 700, color: 'text.primary' }}>
                {t('nav.assignDuties', 'Assign Duties')}
              </Typography>
            </Box>
            
            {/* Right: Global Personnel Search - Google-style unified box */}
            <Box sx={{ flexShrink: 0, position: 'relative', width: 380 }}>
              <Paper
                elevation={globalSearchQuery.length >= 2 || globalSearchLoading ? 3 : 0}
                sx={{
                  borderRadius: (globalSearchQuery.length >= 2 || globalSearchLoading) ? '20px 20px 0 0' : '20px',
                  border: (globalSearchQuery.length >= 2 || globalSearchLoading) ? 'none' : '1px solid #dfe1e5',
                  overflow: 'hidden',
                  transition: 'box-shadow 0.2s, border-radius 0.2s',
                  '&:hover': {
                    boxShadow: (globalSearchQuery.length >= 2 || globalSearchLoading) ? undefined : '0 1px 6px rgba(32,33,36,0.28)',
                    borderColor: (globalSearchQuery.length >= 2 || globalSearchLoading) ? undefined : 'transparent',
                  },
                }}
              >
                {/* Search Input */}
                <Box
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    px: 2,
                    py: 1,
                    bgcolor: '#fff',
                  }}
                >
                  <SearchIcon sx={{ color: '#9aa0a6', fontSize: 20, mr: 1.5 }} />
                  <input
                    value={globalSearchQuery}
                    onChange={(e) => handleGlobalSearch(e.target.value)}
                    placeholder={t('assignDuties.searchPlaceholder', 'Search personnel by name or badge ID...')}
                    style={{
                      flex: 1,
                      border: 'none',
                      outline: 'none',
                      fontSize: '0.9rem',
                      background: 'transparent',
                      color: '#202124',
                    }}
                  />
                  {globalSearchLoading && <CircularProgress size={18} sx={{ color: '#9aa0a6', ml: 1 }} />}
                  {globalSearchQuery && !globalSearchLoading && (
                    <Box
                      onClick={() => { setGlobalSearchQuery(''); setGlobalSearchResults([]); }}
                      sx={{
                        cursor: 'pointer',
                        p: 0.5,
                        borderRadius: '50%',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        '&:hover': { bgcolor: '#f1f3f4' },
                      }}
                    >
                      <Box sx={{ fontSize: 16, color: '#70757a', lineHeight: 1 }}>✕</Box>
                    </Box>
                  )}
                </Box>
              </Paper>

              {/* Results Dropdown - Absolutely positioned to overlay content */}
              {(globalSearchQuery.length >= 2 || globalSearchLoading) && (
                <Paper
                  elevation={4}
                  sx={{
                    position: 'absolute',
                    top: '100%',
                    left: 0,
                    right: 0,
                    zIndex: 1300,
                    bgcolor: '#fff',
                    maxHeight: 350,
                    overflowY: 'auto',
                    borderRadius: '0 0 20px 20px',
                    boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
                  }}
                >
                  {globalSearchQuery.length < 2 ? (
                    <Box sx={{ py: 2, px: 2.5 }}>
                      <Typography sx={{ fontSize: '0.85rem', color: '#70757a' }}>
                        {t('assignDuties.personnel.typeAtLeast', 'Type at least 2 characters...')}
                      </Typography>
                    </Box>
                  ) : globalSearchLoading ? (
                    <Box sx={{ py: 2.5, display: 'flex', justifyContent: 'center' }}>
                      <CircularProgress size={24} />
                    </Box>
                  ) : globalSearchResults.length > 0 ? (
                    <Box sx={{ py: 0.5 }}>
                      {globalSearchResults.map((person) => (
                        <Box
                          key={person.id}
                          onClick={() => handleGlobalSearchSelect(person)}
                          sx={{
                            display: 'flex',
                            alignItems: 'center',
                            px: 2,
                            py: 1.25,
                            cursor: 'pointer',
                            '&:hover': { bgcolor: '#f1f3f4' },
                          }}
                        >
                          <Box
                            sx={{
                              minWidth: 32,
                              height: 32,
                              borderRadius: '8px',
                              bgcolor: person.currentSection ? (SECTIONS.find(s => s.id === person.currentSection)?.bgColor || '#f1f5f9') : '#f1f5f9',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              mr: 1.5,
                              flexShrink: 0,
                            }}
                          >
                            <Typography sx={{ fontSize: '0.65rem', fontWeight: 700, color: person.currentSection ? (SECTIONS.find(s => s.id === person.currentSection)?.color || '#64748b') : '#64748b' }}>
                              {person.currentSection || '—'}
                            </Typography>
                          </Box>
                          <Box sx={{ flex: 1, minWidth: 0 }}>
                            <Typography
                              sx={{
                                fontSize: '0.9rem',
                                color: '#202124',
                                fontWeight: 500,
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                whiteSpace: 'nowrap',
                              }}
                            >
                              {person.personName}
                            </Typography>
                            <Typography
                              sx={{
                                fontSize: '0.75rem',
                                color: '#70757a',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                whiteSpace: 'nowrap',
                              }}
                            >
                              {person.badgeId} • {person.designation || 'No designation'} • {person.currentDutyType || 'Unassigned'}
                            </Typography>
                          </Box>
                          {person.designation && (
                            <Chip
                              label={person.designation}
                              size="small"
                              sx={{
                                ml: 1,
                                height: 20,
                                fontSize: '0.65rem',
                                fontWeight: 600,
                                bgcolor: person.currentSection ? `${SECTIONS.find(s => s.id === person.currentSection)?.color}15` : '#f1f5f9',
                                color: person.currentSection ? (SECTIONS.find(s => s.id === person.currentSection)?.color || '#64748b') : '#64748b',
                                '& .MuiChip-label': { px: 1 },
                              }}
                            />
                          )}
                        </Box>
                      ))}
                    </Box>
                  ) : (
                    <Box sx={{ py: 2.5, px: 2.5 }}>
                      <Typography sx={{ fontSize: '0.85rem', color: '#70757a', textAlign: 'center' }}>
                        {t('assignDuties.personnel.noPersonnelFound', 'No personnel found')} "{globalSearchQuery}"
                      </Typography>
                    </Box>
                  )}
                </Paper>
              )}
            </Box>
        </Stack>
        </Box>
      </Box>

      {/* Section Carousel */}
      <Box sx={{ px: { xs: 2, md: 3 }, pt: 3, pb: 1 }}>
        <Typography variant="subtitle1" sx={{ mb: 1.5, color: 'text.secondary', fontWeight: 600 }}>
          {t('assignDuties.selectSection', 'Select Section')}
        </Typography>
        <Carousel ariaLabel="Duty sections carousel">
          {SECTIONS.map((section) => {
            const isSelected = selectedSection === section.id;
            return (
              <Card
                key={section.id}
                elevation={isSelected ? 6 : 0}
                sx={{
                  flex: '0 0 auto',
                  width: { xs: '140px', sm: '150px', md: '160px' },
                  borderRadius: '12px',
                  border: 'none',
                  background: isSelected
                    ? `linear-gradient(135deg, ${section.color} 0%, ${section.color}cc 100%)`
                    : `linear-gradient(135deg, ${section.bgColor} 0%, ${section.color}12 100%)`,
                  transition: 'all 300ms cubic-bezier(0.4, 0, 0.2, 1)',
                  position: 'relative',
                  overflow: 'visible',
                  '&:hover': {
                    transform: 'translateY(-4px) scale(1.02)',
                    boxShadow: `0 12px 32px ${section.color}30`,
                  },
                }}
              >
                {isSelected && (
                  <Chip
                    label="✓ Active"
                    size="small"
                    sx={{
                      position: 'absolute', top: -10, right: 12,
                      bgcolor: '#ffffff', color: section.color,
                      fontSize: '0.6rem', height: 20, fontWeight: 700,
                      boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
                    }}
                  />
                )}
                <CardActionArea onClick={() => handleSectionClick(section.id)} sx={{ px: 1.5, py: 1.5 }}>
                  <Stack spacing={0.5} alignItems="center">
                    <Box
                      sx={{
                        minWidth: 28, height: 28, borderRadius: '8px',
                        px: section.id.length > 2 ? 1 : 0,
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        bgcolor: isSelected ? 'rgba(255,255,255,0.25)' : `${section.color}18`,
                      }}
                    >
                      <Typography sx={{ fontWeight: 800, fontSize: section.id.length > 2 ? '0.55rem' : '0.75rem', color: isSelected ? '#ffffff' : section.color, whiteSpace: 'nowrap' }}>
                        {section.id}
                      </Typography>
                    </Box>
                    <Typography sx={{ fontWeight: 700, fontSize: '0.72rem', color: isSelected ? '#ffffff' : 'text.primary', textAlign: 'center', lineHeight: 1.2 }}>
                      {t(section.nameKey)}
                    </Typography>
                    <Typography sx={{ fontSize: '0.6rem', color: isSelected ? 'rgba(255,255,255,0.85)' : 'text.secondary', textAlign: 'center', lineHeight: 1.2 }}>
                      {t(section.descKey)}
                    </Typography>
                  </Stack>
                </CardActionArea>
              </Card>
            );
          })}
        </Carousel>
      </Box>

      {/* Main Content: Tabs + Content */}
      <Box sx={{ flex: 1, px: { xs: 1, md: 3 }, py: 2 }}>
        {/* Tab Navigation */}
        {selectedData && chartData && (
          <Box sx={{ mb: 2, display: 'inline-flex', bgcolor: '#f1f5f9', borderRadius: '10px', p: '4px', gap: '4px' }}>
            {[
              { label: t('assignDuties.tabs.dutyManagement', 'Duty Management'), idx: 0 },
              { label: t('assignDuties.tabs.leaveManagement', 'Leave Management'), idx: 1 },
              { label: t('assignDuties.tabs.form168View', 'Form 168 View'), idx: 2 }
            ].map(({ label, idx }) => (
              <Box
                key={label}
                onClick={() => { setActiveTab(idx); setGlobalSearchQuery(''); setGlobalSearchResults([]); setSearchParams({ section: selectedSection || 'A', tab: String(idx) }, { replace: true }); }}
                sx={{
                  px: 2.5,
                  py: 1,
                  borderRadius: '8px',
                  cursor: 'pointer',
                  fontWeight: 600,
                  fontSize: '0.82rem',
                  transition: 'all 0.2s ease',
                  userSelect: 'none',
                  ...(activeTab === idx
                    ? { bgcolor: '#fff', color: selectedData.color, boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }
                    : { bgcolor: 'transparent', color: '#64748b', '&:hover': { color: selectedData.color } }
                  ),
                }}
              >
                {label}
              </Box>
            ))}
          </Box>
        )}

        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
            <CircularProgress />
          </Box>
        ) : selectedData && chartData ? (
          <>
            {/* TAB 0: Duty Management (existing view) */}
            {activeTab === 0 && (
          <Box sx={{ display: 'flex', gap: 2, alignItems: 'flex-start' }}>
            {/* LEFT SIDEBAR: Parent Duty Types List - shows full list, no scroll */}
            <Paper
              elevation={0}
              sx={{
                width: { xs: 200, sm: 240, md: 280 },
                flexShrink: 0,
                border: '1px solid',
                borderColor: 'divider',
                borderRadius: '12px',
                display: 'flex',
                flexDirection: 'column',
                position: 'sticky',
                top: 16,
              }}
            >
              {/* Sidebar Header */}
              <Box sx={{ px: 2, py: 1.5, bgcolor: selectedData.bgColor, borderBottom: '1px solid', borderColor: 'divider' }}>
                <Typography variant="subtitle2" sx={{ fontWeight: 700, color: selectedData.color }}>
                  {t(selectedData.nameKey)} {t('assignDuties.sidebar.duties')}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {chartData.dutyCards.length} duties • {chartData.totalPersonnel} personnel
                </Typography>
              </Box>

              {/* Search Filter */}
              <Box sx={{ px: 1.5, py: 1 }}>
                <TextField
                  size="small"
                  fullWidth
                  placeholder={t('assignDuties.sidebar.filterPlaceholder')}
                  value={sidebarFilter}
                  onChange={(e) => setSidebarFilter(e.target.value)}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <SearchIcon fontSize="small" color="action" />
                      </InputAdornment>
                    ),
                    sx: { fontSize: '0.8rem' },
                  }}
                />
              </Box>

              {/* Duty Types List - full height, no scroll */}
              <Box>
                <List dense disablePadding>
                  {filteredDutyCards.map((card) => (
                    <ListItemButton
                      key={card.dutyTypeId}
                      selected={selectedDutyTypeId === card.dutyTypeId}
                      onClick={() => setSelectedDutyTypeId(card.dutyTypeId)}
                      sx={{
                        px: 2, py: 1,
                        borderLeft: selectedDutyTypeId === card.dutyTypeId ? `3px solid ${selectedData.color}` : '3px solid transparent',
                        '&.Mui-selected': {
                          bgcolor: `${selectedData.color}08`,
                        },
                        '&.Mui-selected:hover': {
                          bgcolor: `${selectedData.color}12`,
                        },
                      }}
                    >
                      <ListItemText
                        primary={
                          <Stack direction="row" spacing={0.5} alignItems="center">
                            <Typography
                              variant="caption"
                              sx={{
                                fontWeight: selectedDutyTypeId === card.dutyTypeId ? 700 : 500,
                                fontSize: '0.72rem',
                                textTransform: 'uppercase',
                                letterSpacing: '0.3px',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                whiteSpace: 'nowrap',
                                flex: 1,
                              }}
                            >
                              {card.dutyTypeName}
                            </Typography>
                            <Chip
                              label={card.personnelCount}
                              size="small"
                              sx={{
                                height: 18, fontSize: '0.6rem', fontWeight: 700,
                                bgcolor: card.personnelCount > 0 ? `${selectedData.color}15` : 'grey.100',
                                color: card.personnelCount > 0 ? selectedData.color : 'text.disabled',
                              }}
                            />
                          </Stack>
                        }
                      />
                    </ListItemButton>
                  ))}
                </List>
              </Box>

              {/* Reassigned Duties Entry */}
              {activeReassignments.length > 0 && (
                <Box sx={{ borderTop: '1px solid', borderColor: 'divider' }}>
                  <ListItemButton
                    selected={selectedDutyTypeId === -999}
                    onClick={() => setSelectedDutyTypeId(-999)}
                    sx={{
                      px: 2, py: 1,
                      borderLeft: selectedDutyTypeId === -999 ? '3px solid #2563eb' : '3px solid transparent',
                      bgcolor: selectedDutyTypeId === -999 ? '#eff6ff' : 'transparent',
                      '&.Mui-selected': { bgcolor: '#eff6ff' },
                      '&.Mui-selected:hover': { bgcolor: '#dbeafe' },
                    }}
                  >
                    <ListItemText
                      primary={
                        <Stack direction="row" spacing={0.5} alignItems="center">
                          <Typography
                            variant="caption"
                            sx={{ fontWeight: 700, fontSize: '0.72rem', textTransform: 'uppercase', letterSpacing: '0.3px', flex: 1, color: '#2563eb' }}
                          >
                            {t('assignDuties.sidebar.reassignedDuties', 'Reassigned Duties')}
                          </Typography>
                          <Chip
                            label={activeReassignments.length}
                            size="small"
                            sx={{ height: 18, fontSize: '0.6rem', fontWeight: 700, bgcolor: '#dbeafe', color: '#1d4ed8' }}
                          />
                        </Stack>
                      }
                    />
                  </ListItemButton>
                </Box>
              )}

              {/* Add Duty Type */}
              <Box sx={{ borderTop: '1px solid', borderColor: 'divider', p: 1.5 }}>
                {showAddDutyType ? (
                  <Stack spacing={1}>
                    <TextField
                      size="small"
                      fullWidth
                      placeholder={t('assignDuties.sidebar.parentDutyTypeName')}
                      value={newDutyTypeName}
                      onChange={(e) => setNewDutyTypeName(e.target.value)}
                      autoFocus
                      InputProps={{ sx: { fontSize: '0.8rem' } }}
                    />
                    <TextField
                      size="small"
                      fullWidth
                      type="number"
                      label={t('assignDuties.sidebar.sequenceNo')}
                      value={newDutySortOrder ?? (chartData ? chartData.dutyCards.length + 1 : 1)}
                      onChange={(e) => {
                        const v = parseInt(e.target.value);
                        const max = (chartData?.dutyCards.length ?? 0) + 1;
                        if (v >= 1 && v <= max) setNewDutySortOrder(v);
                      }}
                      inputProps={{ min: 1, max: (chartData?.dutyCards.length ?? 0) + 1 }}
                      helperText={t('assignDuties.sidebar.range', { max: (chartData?.dutyCards.length ?? 0) + 1 })}
                      InputProps={{ sx: { fontSize: '0.8rem' } }}
                    />
                    <Stack direction="row" spacing={0.5}>
                      <Button size="small" variant="contained" onClick={handleAddDutyType} disabled={!newDutyTypeName.trim()} sx={{ fontSize: '0.7rem' }}>
                        {t('app.create')}
                      </Button>
                      <Button size="small" onClick={() => { setShowAddDutyType(false); setNewDutyTypeName(''); setNewDutySortOrder(null); }} sx={{ fontSize: '0.7rem' }}>
                        {t('app.cancel')}
                      </Button>
                    </Stack>
                  </Stack>
                ) : (
                  <Button
                    fullWidth
                    size="small"
                    startIcon={<AddCircleOutlineIcon />}
                    onClick={() => setShowAddDutyType(true)}
                    sx={{ textTransform: 'none', fontSize: '0.75rem' }}
                  >
                    {t('assignDuties.sidebar.addDutyType', 'Add Duty Type')}
                  </Button>
                )}
              </Box>
            </Paper>

            {/* RIGHT: Main Content - matches left sidebar height, scrolls if content overflows */}
            <Box sx={{ flex: 1, minWidth: 0, alignSelf: 'stretch' }}>
              {selectedDutyTypeId === -999 ? (
                /* Reassigned Duties Panel */
                <Paper elevation={0} sx={{ border: '1px solid', borderColor: 'divider', borderRadius: '12px', height: '100%', display: 'flex', flexDirection: 'column' }}>
                  <Box sx={{ px: 3, py: 2, bgcolor: '#eff6ff', borderBottom: '1px solid', borderColor: 'divider' }}>
                    <Stack direction="row" spacing={1.5} alignItems="center">
                      <Typography variant="h6" sx={{ fontWeight: 700, color: '#1d4ed8', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                        {t('assignDuties.sidebar.reassignedDuties')}
                      </Typography>
                      <Chip label={`${activeReassignments.length} ${t('app.active').toLowerCase()}`} size="small" sx={{ fontWeight: 600, bgcolor: '#dbeafe', color: '#1d4ed8' }} />
                    </Stack>
                    <Typography variant="caption" color="text.secondary">{t('assignDuties.reassignment.personnelCovering')}</Typography>
                  </Box>
                  <Box sx={{ flex: 1, overflowY: 'auto', p: 3 }}>
                    {activeReassignments.length === 0 ? (
                      <Typography variant="body2" color="text.secondary">{t('assignDuties.reassignment.noActiveReassignments')}</Typography>
                    ) : (
                      <Stack spacing={1}>
                        {activeReassignments.map((r) => (
                          <Box key={r.id} sx={{ p: 1.5, borderRadius: '8px', border: '1px solid #dbeafe', bgcolor: '#f8faff' }}>
                            <Stack direction="row" justifyContent="space-between" alignItems="flex-start">
                              <Box>
                                <Typography variant="body2" fontWeight={700} color="#1d4ed8">
                                  {r.replacementPersonBadgeId} — {r.replacementPersonName}
                                </Typography>
                                <Typography variant="caption" color="text.secondary">
                                  {t('assignDuties.reassignment.coveringFor', { badge: r.leavePersonBadgeId, name: r.leavePersonName })}
                                </Typography>
                                <Stack direction="row" spacing={1} sx={{ mt: 0.5 }}>
                                  {r.dutyType && <Chip label={r.dutyType} size="small" sx={{ height: 18, fontSize: '0.58rem' }} />}
                                  {r.dutyLocation && <Chip label={r.dutyLocation} size="small" variant="outlined" sx={{ height: 18, fontSize: '0.58rem' }} />}
                                </Stack>
                                <Typography variant="caption" color="text.secondary" sx={{ mt: 0.5, display: 'block' }}>
                                  {r.startDate} → {r.endDate} ({r.days}d)
                                </Typography>
                              </Box>
                              <Stack direction="row" spacing={0.5} alignItems="center">
                                <Tooltip title={t('assignDuties.reassignment.editReassignment')}>
                                  <IconButton
                                    size="small"
                                    onClick={() => handleEditReassignment(r)}
                                    sx={{ color: '#2563eb' }}
                                  >
                                    <EditIcon sx={{ fontSize: 16 }} />
                                  </IconButton>
                                </Tooltip>
                                <Tooltip title={t('assignDuties.reassignment.cancelReassignment')}>
                                  <IconButton
                                    size="small"
                                    onClick={async () => {
                                      try {
                                        await api.delete(`/api/duty-reassignments/${r.id}`);
                                        setSnackbar({ open: true, message: '✓ Reassignment cancelled', severity: 'success' });
                                        if (selectedSection) {
                                          // Force full reload: re-fetch chart data + reassignments
                                          await loadChartData(selectedSection, true);
                                          await fetchReassignments(selectedSection);
                                        }
                                      } catch {
                                        setSnackbar({ open: true, message: 'Failed to cancel', severity: 'error' });
                                      }
                                    }}
                                    sx={{ color: 'error.main' }}
                                  >
                                    <DeleteOutlineIcon sx={{ fontSize: 16 }} />
                                  </IconButton>
                                </Tooltip>
                              </Stack>
                            </Stack>
                          </Box>
                        ))}
                      </Stack>
                    )}
                  </Box>
                </Paper>
              ) : selectedCard ? (
                <DutyDetailPanel
                  card={selectedCard}
                  sectionCode={selectedSection ?? ''}
                  sectionColor={selectedData.color}
                  sectionBgColor={selectedData.bgColor}
                  onAssign={handleAssignPerson}
                  onUnassign={handleUnassignPerson}
                  onAddSubDuty={handleAddSubDuty}
                  onDeleteDutyType={handleDeleteDutyType}
                  onDeleteSubDuty={handleDeleteSubDuty}
                  onRenameDutyType={handleRenameDutyType}
                  onRenameSubDuty={handleRenameSubDuty}
                  onReassign={handleOpenReassign}
                  reassignments={activeReassignments}
                  highlightedPersonId={highlightedPersonId}
                />
              ) : (
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', opacity: 0.5 }}>
                  <Stack alignItems="center" spacing={1}>
                    <ArrowBackIcon sx={{ fontSize: 40, color: 'text.disabled' }} />
                    <Typography variant="body2" color="text.secondary">
                      {t('assignDuties.dutyPanel.selectDutyType')}
                    </Typography>
                  </Stack>
                </Box>
              )}
            </Box>
          </Box>
            )}

            {/* TAB 1: Leave Management */}
            {activeTab === 1 && (
              <LeaveManagementPanel
                sectionCode={selectedSection ?? ''}
                sectionColor={selectedData.color}
                sectionBgColor={selectedData.bgColor}
                onAssign={handleAssignPerson}
                onUnassign={handleUnassignPerson}
                chartData={chartData}
                onRefresh={() => selectedSection && loadChartData(selectedSection, false)}
                selectedCategory={selectedLeaveCategory}
                onCategoryChange={setSelectedLeaveCategory}
                highlightedPersonId={highlightedPersonId}
              />
            )}

            {/* TAB 2: Form 168 View */}
            {activeTab === 2 && selectedSection && (
              <Form168TableView
                sectionCode={selectedSection}
                sectionColor={selectedData.color}
              />
            )}
          </>
        ) : (
          <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', py: 8, gap: 2 }}>
            <BadgeIcon sx={{ fontSize: 56, color: 'text.disabled' }} />
            <Typography variant="h6" color="text.secondary" fontWeight={600}>
              {t('assignDuties.noSectionSelected.title')}
            </Typography>
            <Typography variant="body2" color="text.disabled">
              {t('assignDuties.noSectionSelected.subtitle')}
            </Typography>
          </Box>
        )}
      </Box>

      {/* Saving overlay */}
      {saving && (
        <Box sx={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, bgcolor: 'rgba(0,0,0,0.08)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <CircularProgress />
        </Box>
      )}

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialog.open} onClose={() => setDeleteDialog((d) => ({ ...d, open: false }))}>
        <DialogTitle>{t('assignDuties.confirmDelete.title')}</DialogTitle>
        <DialogContent>
          <DialogContentText>
            {deleteDialog.type === 'dutyType' 
              ? t('assignDuties.confirmDelete.dutyTypeMessage', { name: deleteDialog.name })
              : t('assignDuties.confirmDelete.subDutyMessage', { name: deleteDialog.name })}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialog((d) => ({ ...d, open: false }))}>{t('app.cancel')}</Button>
          <Button onClick={confirmDelete} color="error" variant="contained">{t('app.delete')}</Button>
        </DialogActions>
      </Dialog>

      {/* Reassignment Dialog */}
      <Dialog
        open={reassignDialog.open}
        onClose={() => setReassignDialog({ open: false, person: null })}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle sx={{ fontWeight: 700 }}>{reassignDialog.editMode ? t('assignDuties.reassignment.editTitle') : t('assignDuties.reassignment.title')}</DialogTitle>
        <DialogContent>
          {reassignDialog.person && (
            <Stack spacing={2.5} sx={{ mt: 1 }}>
              {/* Leave Person Info */}
              <Box sx={{ p: 1.5, borderRadius: '8px', bgcolor: '#fee2e2', border: '1px solid #fca5a5' }}>
                <Typography variant="caption" color="text.secondary" fontWeight={600}>{t('assignDuties.reassignment.personOnLeave')}</Typography>
                <Typography variant="body2" fontWeight={700}>
                  {reassignDialog.person.badgeId} — {reassignDialog.person.personName}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {t('assignDuties.reassignment.leaveInfo', { start: reassignDialog.person.leaveStartDate, end: reassignDialog.person.leaveEndDate, days: reassignDialog.person.leaveDays })}
                </Typography>
              </Box>

              {/* Replacement Person */}
              <Box>
                <Typography variant="caption" fontWeight={600} sx={{ mb: 0.5, display: 'block' }}>
                  {reassignDialog.editMode ? t('assignDuties.reassignment.changeReplacement') : t('assignDuties.reassignment.selectReplacement')}
                </Typography>
                {reassignDialog.editMode && (
                  <Box sx={{ p: 1, mb: 1, borderRadius: '6px', bgcolor: '#dbeafe', border: '1px solid #93c5fd' }}>
                    <Typography variant="caption" color="text.secondary">{t('assignDuties.reassignment.currentReplacement')}</Typography>
                    <Typography variant="body2" fontWeight={600} color="#1d4ed8">
                      {activeReassignments.find(r => r.id === reassignDialog.editId)?.replacementPersonBadgeId} — {activeReassignments.find(r => r.id === reassignDialog.editId)?.replacementPersonName}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {t('assignDuties.reassignment.searchToChange')}
                    </Typography>
                  </Box>
                )}
                <PersonnelAutocomplete
                  onSelect={(id) => setReassignForm((f) => ({ ...f, replacementId: id }))}
                  onCancel={() => setReassignForm((f) => ({ ...f, replacementId: reassignDialog.editMode ? (activeReassignments.find(r => r.id === reassignDialog.editId)?.replacementPersonId || 0) : 0 }))}
                />
              </Box>

              {/* Date Range */}
              <Stack direction="row" spacing={2}>
                <TextField
                  label={t('assignDuties.reassignment.startDate')}
                  type="date"
                  size="small"
                  fullWidth
                  value={reassignForm.startDate}
                  onChange={(e) => setReassignForm((f) => ({ ...f, startDate: e.target.value }))}
                  InputLabelProps={{ shrink: true }}
                  inputProps={{
                    min: reassignDialog.person.leaveStartDate,
                    max: reassignDialog.person.leaveEndDate,
                  }}
                  helperText={t('assignDuties.reassignment.cannotExceedLeave')}
                />
                <TextField
                  label={t('assignDuties.reassignment.endDate')}
                  type="date"
                  size="small"
                  fullWidth
                  value={reassignForm.endDate}
                  onChange={(e) => setReassignForm((f) => ({ ...f, endDate: e.target.value }))}
                  InputLabelProps={{ shrink: true }}
                  inputProps={{
                    min: reassignForm.startDate || reassignDialog.person.leaveStartDate,
                    max: reassignDialog.person.leaveEndDate,
                  }}
                  helperText={t('assignDuties.reassignment.cannotExceedLeave')}
                />
              </Stack>

              {/* Validation message */}
              {reassignForm.startDate && reassignForm.endDate && reassignDialog.person.leaveEndDate && (
                reassignForm.endDate > reassignDialog.person.leaveEndDate || reassignForm.startDate < (reassignDialog.person.leaveStartDate || '')
              ) && (
                <Alert severity="error" sx={{ fontSize: '0.75rem' }}>
                  {t('assignDuties.reassignment.datesValidation', { start: reassignDialog.person.leaveStartDate, end: reassignDialog.person.leaveEndDate })}
                </Alert>
              )}
            </Stack>
          )}
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setReassignDialog({ open: false, person: null })}>{t('app.cancel')}</Button>
          <Button
            variant="contained"
            onClick={handleSubmitReassign}
            disabled={
              reassignSaving || !reassignForm.replacementId || !reassignForm.startDate || !reassignForm.endDate
            }
            sx={{ textTransform: 'none' }}
          >
            {reassignSaving ? t('app.saving') : reassignDialog.editMode ? t('app.update') : t('assignDuties.reassignment.reassign')}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={3000}
        onClose={() => setSnackbar((s) => ({ ...s, open: false }))}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert severity={snackbar.severity} variant="filled" sx={{ width: '100%' }}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
    </>
  );
};

// ===== Duty Detail Panel (Right Side) =====
interface DutyDetailPanelProps {
  card: DutyCard;
  sectionCode: string;
  sectionColor: string;
  sectionBgColor: string;
  onAssign: (personnelId: number, dutyTypeId: number, subDuty?: string | null) => void;
  onUnassign: (personnelId: number) => void;
  onAddSubDuty: (parentDutyTypeId: number, subDutyName: string, location?: string, sortOrder?: number) => void;
  onDeleteDutyType: (dutyTypeId: number, name: string) => void;
  onDeleteSubDuty: (dutyTypeId: number, subDutyName: string) => void;
  onRenameDutyType: (dutyTypeId: number, newName: string) => void;
  onRenameSubDuty: (parentDutyTypeId: number, oldName: string, newName: string) => void;
  onReassign?: (person: ChartPersonnel) => void;
  reassignments?: Array<{ leavePersonId: number; replacementPersonBadgeId: string }>;
  highlightedPersonId?: number | null;
}

const DutyDetailPanel: React.FC<DutyDetailPanelProps> = ({
  card, sectionCode, sectionColor, sectionBgColor, onAssign, onUnassign, onAddSubDuty, onDeleteDutyType, onDeleteSubDuty, onRenameDutyType, onRenameSubDuty, onReassign, reassignments, highlightedPersonId,
}) => {
  const { t } = useTranslation();
  const [showAddSubDuty, setShowAddSubDuty] = useState(false);
  const [newSubDutyName, setNewSubDutyName] = useState('');
  const [newSubDutyLocation, setNewSubDutyLocation] = useState('');
  const [newSubDutySortOrder, setNewSubDutySortOrder] = useState<number | null>(null);
  const [editingParentName, setEditingParentName] = useState(false);
  const [editParentValue, setEditParentValue] = useState('');

  const handleAddSubDutySubmit = () => {
    if (newSubDutyName.trim()) {
      onAddSubDuty(card.dutyTypeId, newSubDutyName, newSubDutyLocation.trim() || undefined, newSubDutySortOrder ?? undefined);
      setNewSubDutyName('');
      setNewSubDutyLocation('');
      setNewSubDutySortOrder(null);
      setShowAddSubDuty(false);
    }
  };

  const handleRenameParent = () => {
    if (editParentValue.trim() && editParentValue.trim().toUpperCase() !== card.dutyTypeName) {
      onRenameDutyType(card.dutyTypeId, editParentValue);
    }
    setEditingParentName(false);
  };

  return (
    <Paper
      elevation={0}
      sx={{
        border: '1px solid',
        borderColor: 'divider',
        borderRadius: '12px',
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      {/* Header */}
      <Box sx={{ px: 3, py: 2, bgcolor: sectionBgColor, borderBottom: '1px solid', borderColor: 'divider' }}>
        <Stack direction="row" spacing={1.5} alignItems="center" justifyContent="space-between">
          <Stack direction="row" spacing={1.5} alignItems="center">
            {editingParentName ? (
              <Stack direction="row" spacing={0.5} alignItems="center">
                <TextField size="small" value={editParentValue} onChange={(e) => setEditParentValue(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') handleRenameParent(); if (e.key === 'Escape') setEditingParentName(false); }}
                  autoFocus sx={{ minWidth: 200 }} InputProps={{ sx: { fontSize: '0.85rem', fontWeight: 700 } }} />
                <Button size="small" variant="contained" onClick={handleRenameParent} sx={{ fontSize: '0.7rem', minWidth: 'auto' }}>{t('app.save')}</Button>
                <Button size="small" onClick={() => setEditingParentName(false)} sx={{ fontSize: '0.7rem', minWidth: 'auto' }}>{t('app.cancel')}</Button>
              </Stack>
            ) : (
              <Typography variant="h6" sx={{ fontWeight: 700, color: sectionColor, textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                {card.dutyTypeName}
              </Typography>
            )}
            <Chip
              label={`${card.personnelCount} ${t('assignDuties.dutyPanel.personnel')}`}
              size="small"
              sx={{ fontWeight: 600, bgcolor: `${sectionColor}15`, color: sectionColor }}
            />
          </Stack>
          <Stack direction="row" spacing={0.5}>
            <Tooltip title={t('assignDuties.dutyPanel.editDutyTypeName')}>
              <Button size="small" startIcon={<EditIcon fontSize="small" />} onClick={() => { setEditParentValue(card.dutyTypeName); setEditingParentName(true); }}
                sx={{ fontSize: '0.7rem', textTransform: 'none' }}>
                {t('app.edit')}
              </Button>
            </Tooltip>
            <Tooltip title={t('assignDuties.dutyPanel.deleteDutyType')}>
              <Button size="small" color="error" startIcon={<DeleteOutlineIcon fontSize="small" />} onClick={() => onDeleteDutyType(card.dutyTypeId, card.dutyTypeName)}>
                {t('app.delete')}
              </Button>
            </Tooltip>
          </Stack>
        </Stack>
      </Box>

      {/* Content - Scrollable */}
      <Box sx={{ flex: 1, overflowY: 'auto', p: 3 }}>
        {/* Sub Duties */}
        {card.subDuties.length > 0 && (
          <Stack spacing={2.5}>
            {card.subDuties.map((subDuty) => (
              <SubDutySection
                key={subDuty.subDutyName}
                subDuty={subDuty}
                dutyTypeId={card.dutyTypeId}
                sectionColor={sectionColor}
                onAssign={(personnelId) => onAssign(personnelId, card.dutyTypeId, subDuty.subDutyName)}
                onUnassign={onUnassign}
                onDeleteSubDuty={() => onDeleteSubDuty(card.dutyTypeId, subDuty.subDutyName)}
                onRenameSubDuty={(newName) => onRenameSubDuty(card.dutyTypeId, subDuty.subDutyName, newName)}
                onReassign={onReassign}
                reassignments={reassignments}
                highlightedPersonId={highlightedPersonId}
              />
            ))}
          </Stack>
        )}

        {/* Personnel without sub-duty (direct assignment to parent) */}
        {card.personnel.length > 0 && (
          <Box sx={{ mt: card.subDuties.length > 0 ? 3 : 0 }}>
            {card.subDuties.length > 0 && (
              <Typography variant="caption" sx={{ fontWeight: 600, color: 'text.secondary', mb: 1, display: 'block', textTransform: 'uppercase' }}>
                {t('assignDuties.dutyPanel.directAssignment')}
              </Typography>
            )}
            <PersonnelList
              personnel={card.personnel}
              dutyTypeId={card.dutyTypeId}
              subDuty={null}
              onAssign={(personnelId) => onAssign(personnelId, card.dutyTypeId, null)}
              onUnassign={onUnassign}
              onReassign={onReassign}
              reassignments={reassignments}
              highlightedPersonId={highlightedPersonId}
            />
          </Box>
        )}

        {/* If no sub-duties and no personnel, show the add person area */}
        {card.subDuties.length === 0 && card.personnel.length === 0 && (
          <Box sx={{ py: 2 }}>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
              {t('assignDuties.dutyPanel.noPersonnelAssigned')}
            </Typography>
            <PersonnelList
              personnel={[]}
              dutyTypeId={card.dutyTypeId}
              subDuty={null}
              onAssign={(personnelId) => onAssign(personnelId, card.dutyTypeId, null)}
              onUnassign={onUnassign}
              highlightedPersonId={highlightedPersonId}
            />
          </Box>
        )}

        {/* Add Sub Duty */}
        <Box sx={{ mt: 3, pt: 2, borderTop: '1px dashed', borderColor: 'divider' }}>
          {showAddSubDuty ? (
            <Stack spacing={1}>
              <Stack direction="row" spacing={1} alignItems="center">
                <TextField
                  size="small"
                  placeholder={t('assignDuties.dutyPanel.subDutyName')}
                  value={newSubDutyName}
                  onChange={(e) => setNewSubDutyName(e.target.value)}
                  sx={{ flex: 1, maxWidth: 200 }}
                  autoFocus
                />
                <TextField
                  size="small"
                  placeholder={t('assignDuties.dutyPanel.locationOptional')}
                  value={newSubDutyLocation}
                  onChange={(e) => setNewSubDutyLocation(e.target.value)}
                  sx={{ flex: 1, maxWidth: 200 }}
                />
                <TextField
                  size="small"
                  type="number"
                  label="Seq #"
                  value={newSubDutySortOrder ?? (card.subDuties.length + 1)}
                  onChange={(e) => {
                    const v = parseInt(e.target.value);
                    const max = card.subDuties.length + 1;
                    if (v >= 1 && v <= max) setNewSubDutySortOrder(v);
                  }}
                  inputProps={{ min: 1, max: card.subDuties.length + 1 }}
                  sx={{ width: 80 }}
                />
              </Stack>
              <Stack direction="row" spacing={0.5}>
                <Button size="small" variant="contained" onClick={handleAddSubDutySubmit} disabled={!newSubDutyName.trim()}>
                  {t('app.add')}
                </Button>
                <Button size="small" onClick={() => { setShowAddSubDuty(false); setNewSubDutyName(''); setNewSubDutyLocation(''); setNewSubDutySortOrder(null); }}>
                  {t('app.cancel')}
                </Button>
              </Stack>
            </Stack>
          ) : (
            <Button
              size="small"
              startIcon={<AddCircleOutlineIcon />}
              onClick={() => setShowAddSubDuty(true)}
              sx={{ textTransform: 'none' }}
            >
              {t('assignDuties.dutyPanel.addSubDuty')}
            </Button>
          )}
        </Box>
      </Box>
    </Paper>
  );
};

// ===== Sub Duty Section =====
interface SubDutySectionProps {
  subDuty: SubDutyGroup;
  dutyTypeId: number;
  sectionColor: string;
  onAssign: (personnelId: number) => void;
  onUnassign: (personnelId: number) => void;
  onDeleteSubDuty: () => void;
  onRenameSubDuty: (newName: string) => void;
  onReassign?: (person: ChartPersonnel) => void;
  reassignments?: Array<{ leavePersonId: number; replacementPersonBadgeId: string }>;
  highlightedPersonId?: number | null;
}

const SubDutySection: React.FC<SubDutySectionProps> = ({ subDuty, dutyTypeId, sectionColor, onAssign, onUnassign, onDeleteSubDuty, onRenameSubDuty, onReassign, reassignments, highlightedPersonId }) => {
  const { t } = useTranslation();
  const [editing, setEditing] = useState(false);
  const [editValue, setEditValue] = useState('');

  const handleRename = () => {
    if (editValue.trim() && editValue.trim().toUpperCase() !== subDuty.subDutyName) {
      onRenameSubDuty(editValue);
    }
    setEditing(false);
  };
  // Group personnel by location if location data exists
  const locationGroups = useMemo(() => {
    const withLocation: Record<string, ChartPersonnel[]> = {};
    const withoutLocation: ChartPersonnel[] = [];
    for (const p of subDuty.personnel) {
      if (p.location && p.location.trim()) {
        const loc = p.location.trim();
        if (!withLocation[loc]) withLocation[loc] = [];
        withLocation[loc].push(p);
      } else {
        withoutLocation.push(p);
      }
    }
    return { withLocation, withoutLocation, hasLocations: Object.keys(withLocation).length > 0 };
  }, [subDuty.personnel]);

  return (
    <Box
      sx={{
        pl: 2,
        borderLeft: `3px solid ${sectionColor}40`,
        borderRadius: '0 8px 8px 0',
      }}
    >
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1 }}>
        {editing ? (
          <Stack direction="row" spacing={0.5} alignItems="center" sx={{ flex: 1 }}>
            <TextField size="small" value={editValue} onChange={(e) => setEditValue(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') handleRename(); if (e.key === 'Escape') setEditing(false); }}
              autoFocus sx={{ maxWidth: 250 }} InputProps={{ sx: { fontSize: '0.78rem', fontWeight: 700 } }} />
            <Button size="small" variant="contained" onClick={handleRename} sx={{ fontSize: '0.65rem', minWidth: 'auto' }}>{t('app.save')}</Button>
            <Button size="small" onClick={() => setEditing(false)} sx={{ fontSize: '0.65rem', minWidth: 'auto' }}>{t('app.cancel')}</Button>
          </Stack>
        ) : (
          <Typography variant="body2" sx={{ fontWeight: 700, color: 'text.primary', textTransform: 'uppercase', flex: 1 }}>
            {subDuty.subDutyName}
          </Typography>
        )}
        <Chip
          label={subDuty.personnelCount}
          size="small"
          sx={{ height: 18, fontSize: '0.65rem', fontWeight: 600 }}
        />
        <Tooltip title={t('app.edit')}>
          <Button size="small" startIcon={<EditIcon sx={{ fontSize: 14 }} />} onClick={() => { setEditValue(subDuty.subDutyName); setEditing(true); }} sx={{ fontSize: '0.65rem', minWidth: 'auto', px: 0.5, py: 0 }}>
            {t('app.edit')}
          </Button>
        </Tooltip>
        <Tooltip title={t('app.delete')}>
          <Button size="small" color="error" startIcon={<DeleteOutlineIcon sx={{ fontSize: 14 }} />} onClick={onDeleteSubDuty} sx={{ fontSize: '0.65rem', minWidth: 'auto', px: 0.5, py: 0 }}>
            {t('app.delete')}
          </Button>
        </Tooltip>
      </Stack>

      {locationGroups.hasLocations ? (
        <Stack spacing={1.5}>
          {/* Personnel grouped by location */}
          {Object.entries(locationGroups.withLocation).map(([loc, locPersonnel]) => (
            <Box key={loc} sx={{ pl: 1.5, borderLeft: '2px solid', borderColor: 'divider', borderRadius: '0 6px 6px 0' }}>
              <Typography variant="caption" sx={{ fontWeight: 600, color: 'text.secondary', textTransform: 'uppercase', fontSize: '0.65rem', mb: 0.5, display: 'block' }}>
                📍 {loc} ({locPersonnel.length})
              </Typography>
              <PersonnelList
                personnel={locPersonnel}
                dutyTypeId={dutyTypeId}
                subDuty={subDuty.subDutyName}
                onAssign={onAssign}
                onUnassign={onUnassign}
                onReassign={onReassign}
                reassignments={reassignments}
                highlightedPersonId={highlightedPersonId}
              />
            </Box>
          ))}
          {/* Personnel without location */}
          {locationGroups.withoutLocation.length > 0 && (
            <Box sx={{ pl: 1.5 }}>
              <PersonnelList
                personnel={locationGroups.withoutLocation}
                dutyTypeId={dutyTypeId}
                subDuty={subDuty.subDutyName}
                onAssign={onAssign}
                onUnassign={onUnassign}
                onReassign={onReassign}
                reassignments={reassignments}
                highlightedPersonId={highlightedPersonId}
              />
            </Box>
          )}
        </Stack>
      ) : (
        <PersonnelList
          personnel={subDuty.personnel}
          dutyTypeId={dutyTypeId}
          subDuty={subDuty.subDutyName}
          onAssign={onAssign}
          onUnassign={onUnassign}
          onReassign={onReassign}
          reassignments={reassignments}
          highlightedPersonId={highlightedPersonId}
        />
      )}
    </Box>
  );
};

// ===== Personnel List with Add Person =====
interface PersonnelListProps {
  personnel: ChartPersonnel[];
  dutyTypeId: number;
  subDuty: string | null;
  onAssign: (personnelId: number) => void;
  onUnassign: (personnelId: number) => void;
  onReassign?: (person: ChartPersonnel) => void;
  reassignments?: Array<{ leavePersonId: number; replacementPersonBadgeId: string }>;
  highlightedPersonId?: number | null;
}

const PersonnelList: React.FC<PersonnelListProps> = ({ personnel, dutyTypeId, subDuty, onAssign, onUnassign, onReassign, reassignments, highlightedPersonId }) => {
  const { t } = useTranslation();
  const [showSearch, setShowSearch] = useState(false);

  return (
    <Box>
      {/* Personnel Rows */}
      <Stack spacing={0.5}>
        {personnel.map((person) => {
          const reassignment = reassignments?.find((r) => r.leavePersonId === person.id);
          return (
            <PersonnelRow
              key={person.id}
              person={person}
              onRemove={() => onUnassign(person.id)}
              onReassign={onReassign}
              reassignedTo={reassignment?.replacementPersonBadgeId}
              isHighlighted={highlightedPersonId === person.id}
            />
          );
        })}
      </Stack>

      {/* Add Person */}
      {showSearch ? (
        <Box sx={{ mt: 1 }}>
          <PersonnelAutocomplete
            onSelect={(personnelId) => {
              onAssign(personnelId);
              setShowSearch(false);
            }}
            onCancel={() => setShowSearch(false)}
          />
        </Box>
      ) : (
        <Button
          size="small"
          startIcon={<PersonAddIcon />}
          onClick={() => setShowSearch(true)}
          sx={{ mt: 0.75, textTransform: 'none', fontSize: '0.75rem' }}
        >
          {t('assignDuties.personnel.addPerson', 'Add Person')}
        </Button>
      )}
    </Box>
  );
};

// ===== Personnel Row =====
interface PersonnelRowProps {
  person: ChartPersonnel;
  onRemove: () => void;
  onReassign?: (person: ChartPersonnel) => void;
  reassignedTo?: string; // badge ID of replacement person
  isHighlighted?: boolean; // for global search highlighting
}

const PersonnelRow: React.FC<PersonnelRowProps> = ({ person, onRemove, onReassign, reassignedTo, isHighlighted }) => {
  const { t } = useTranslation();
  return (
    <Box
      data-highlighted={isHighlighted ? 'true' : undefined}
      sx={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        px: 1.5,
        py: 0.6,
        borderRadius: '8px',
        bgcolor: isHighlighted ? '#fef9c3' : person.onLeave ? '#fff5f5' : 'grey.50',
        border: isHighlighted ? '2px solid #eab308' : '1px solid',
        borderColor: isHighlighted ? '#eab308' : person.onLeave ? '#fca5a5' : 'grey.200',
        transition: 'all 0.15s',
        animation: isHighlighted ? 'pulse-highlight 1s ease-in-out infinite' : 'none',
        boxShadow: isHighlighted ? '0 0 12px rgba(234, 179, 8, 0.4)' : 'none',
        '@keyframes pulse-highlight': {
          '0%, 100%': { boxShadow: '0 0 12px rgba(234, 179, 8, 0.4)' },
          '50%': { boxShadow: '0 0 20px rgba(234, 179, 8, 0.6)' },
        },
        '&:hover': { bgcolor: isHighlighted ? '#fef08a' : person.onLeave ? '#fee2e2' : 'grey.100', borderColor: isHighlighted ? '#ca8a04' : person.onLeave ? '#f87171' : 'grey.300', '& .remove-btn': { opacity: 1 } },
      }}
    >
      <Stack direction="row" spacing={1} alignItems="center" sx={{ minWidth: 0, flex: 1 }}>
        <Typography
          variant="body2"
          sx={{ fontWeight: 700, color: 'primary.main', whiteSpace: 'nowrap', fontSize: '0.78rem', minWidth: 70 }}
        >
          {person.badgeId || '—'}
        </Typography>
        <Typography
          variant="body2"
          sx={{ color: 'text.primary', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: '0.78rem' }}
        >
          {person.personName}
        </Typography>
        {person.onLeave && (
          <Chip
            label={`${t('assignDuties.personnel.onLeave')} · ${person.leaveType?.replace(/_/g, ' ')} (${person.leaveDays}d)`}
            size="small"
            sx={{ height: 18, fontSize: '0.55rem', fontWeight: 700, bgcolor: '#fee2e2', color: '#dc2626', border: '1px solid #fca5a5' }}
          />
        )}
        {person.onLeave && reassignedTo && (
          <Chip
            label={t('assignDuties.personnel.reassignedTo', { badge: reassignedTo })}
            size="small"
            sx={{ height: 18, fontSize: '0.55rem', fontWeight: 700, bgcolor: '#dbeafe', color: '#1d4ed8', border: '1px solid #93c5fd' }}
          />
        )}
        {(person as any).onAdhocDuty && (
          <Chip
            label={t('assignDuties.personnel.adhocDuty', { name: (person as any).adhocDutyName, start: (person as any).adhocDutyStartTime, end: (person as any).adhocDutyEndTime })}
            size="small"
            sx={{ height: 18, fontSize: '0.55rem', fontWeight: 700, bgcolor: '#fef3c7', color: '#92400e', border: '1px solid #fcd34d' }}
          />
        )}
        {person.designation && (
          <Chip
            label={person.designation}
            size="small"
            sx={{ height: 18, fontSize: '0.6rem', fontWeight: 600, bgcolor: 'grey.200' }}
          />
        )}
      </Stack>
      <Stack direction="row" spacing={0.5} alignItems="center">
        {person.onLeave && onReassign && !reassignedTo && (
          <Button
            size="small"
            variant="outlined"
            onClick={(e) => { e.stopPropagation(); onReassign(person); }}
            sx={{
              fontSize: '0.6rem', fontWeight: 700, py: 0.2, px: 0.8,
              textTransform: 'none', borderColor: '#2563eb', color: '#2563eb',
              minWidth: 'auto', height: 22,
              '&:hover': { bgcolor: '#eff6ff', borderColor: '#1d4ed8' },
            }}
          >
            {t('assignDuties.reassignment.reassign')}
          </Button>
        )}
        {person.onLeave && onReassign && reassignedTo && (
          <Button
            size="small"
            variant="outlined"
            onClick={(e) => { e.stopPropagation(); onReassign(person); }}
            sx={{
              fontSize: '0.6rem', fontWeight: 700, py: 0.2, px: 0.8,
              textTransform: 'none', borderColor: '#059669', color: '#059669',
              minWidth: 'auto', height: 22,
              '&:hover': { bgcolor: '#ecfdf5', borderColor: '#047857' },
            }}
          >
            {t('app.edit')}
          </Button>
        )}
        <Tooltip title={t('assignDuties.personnel.removeFromDuty')}>
          <IconButton
            size="small"
            className="remove-btn"
            onClick={(e) => { e.stopPropagation(); onRemove(); }}
            sx={{ opacity: 0.3, transition: 'opacity 0.2s', p: 0.3 }}
          >
            <DeleteOutlineIcon sx={{ fontSize: 16, color: 'error.main' }} />
          </IconButton>
        </Tooltip>
      </Stack>
    </Box>
  );
};

// ===== Personnel Autocomplete =====
interface PersonnelAutocompleteProps {
  onSelect: (personnelId: number) => void;
  onCancel: () => void;
}

const PersonnelAutocomplete: React.FC<PersonnelAutocompleteProps> = ({ onSelect, onCancel }) => {
  const { t } = useTranslation();
  const [options, setOptions] = useState<PersonnelSearchResult[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [loading, setLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(true);
  const [focusedIndex, setFocusedIndex] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const searchPersonnel = useCallback(async (query: string) => {
    if (query.length < 2) {
      setOptions([]);
      return;
    }
    setLoading(true);
    try {
      const results = await sectionChartService.searchPersonnel(query, 10);
      setOptions(results);
    } catch {
      setOptions([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setInputValue(value);
    setIsOpen(true);
    setFocusedIndex(-1);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => searchPersonnel(value), 250);
  };

  const handleSelect = (person: PersonnelSearchResult) => {
    onSelect(person.id);
    setInputValue('');
    setOptions([]);
    setIsOpen(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      onCancel();
      return;
    }
    if (!isOpen || options.length === 0) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setFocusedIndex(prev => (prev < options.length - 1 ? prev + 1 : 0));
        break;
      case 'ArrowUp':
        e.preventDefault();
        setFocusedIndex(prev => (prev > 0 ? prev - 1 : options.length - 1));
        break;
      case 'Enter':
        e.preventDefault();
        if (focusedIndex >= 0 && focusedIndex < options.length) {
          handleSelect(options[focusedIndex]);
        }
        break;
    }
  };

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const hasResults = options.length > 0;
  const showDropdown = isOpen && inputValue.length >= 1;

  return (
    <Box sx={{ position: 'relative', width: '100%' }}>
      <Paper
        elevation={showDropdown && (loading || hasResults || inputValue.length >= 2) ? 2 : 0}
        sx={{
          borderRadius: showDropdown && (loading || hasResults || inputValue.length >= 2) ? '16px 16px 0 0' : '16px',
          border: '1px solid #e2e8f0',
          overflow: 'hidden',
          transition: 'all 0.15s',
        }}
      >
        {/* Search Input */}
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            px: 1.5,
            py: 0.75,
            bgcolor: '#fff',
          }}
        >
          <SearchIcon sx={{ color: '#9ca3af', fontSize: 18, mr: 1 }} />
          <input
            ref={inputRef}
            value={inputValue}
            onChange={handleInputChange}
            onKeyDown={handleKeyDown}
            placeholder={t('assignDuties.personnel.searchPlaceholder')}
            style={{
              flex: 1,
              border: 'none',
              outline: 'none',
              fontSize: '0.85rem',
              background: 'transparent',
            }}
          />
          {loading && <CircularProgress size={16} sx={{ color: '#9ca3af', mr: 0.5 }} />}
          <Box
            onClick={onCancel}
            sx={{
              cursor: 'pointer',
              px: 0.75,
              py: 0.25,
              borderRadius: 1,
              fontSize: '0.75rem',
              color: '#6b7280',
              '&:hover': { bgcolor: '#f1f5f9', color: '#374151' },
            }}
          >
            ✕
          </Box>
        </Box>
      </Paper>

      {/* Results Dropdown - Absolutely positioned to overlay content */}
      {showDropdown && (inputValue.length >= 2 || loading) && (
        <Paper
          elevation={4}
          sx={{
            position: 'absolute',
            top: '100%',
            left: 0,
            right: 0,
            zIndex: 1300,
            bgcolor: '#fff',
            maxHeight: 220,
            overflowY: 'auto',
            borderRadius: '0 0 16px 16px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
          }}
        >
          {inputValue.length < 2 ? (
            <Box sx={{ py: 1.5, px: 2 }}>
              <Typography sx={{ fontSize: '0.8rem', color: '#9ca3af' }}>
                {t('assignDuties.personnel.typeAtLeast')}
              </Typography>
            </Box>
          ) : loading ? (
            <Box sx={{ py: 2, display: 'flex', justifyContent: 'center' }}>
              <CircularProgress size={20} />
            </Box>
          ) : hasResults ? (
            <Box sx={{ py: 0.5 }}>
              {options.map((person, index) => (
                <Box
                  key={person.id}
                  onClick={() => handleSelect(person)}
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    px: 1.5,
                    py: 1,
                    cursor: 'pointer',
                    bgcolor: focusedIndex === index ? '#f1f5f9' : 'transparent',
                    '&:hover': { bgcolor: '#f1f5f9' },
                  }}
                >
                  <Box
                    sx={{
                      width: 24,
                      height: 24,
                      borderRadius: '50%',
                      bgcolor: '#ede9fe',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      mr: 1.5,
                      flexShrink: 0,
                    }}
                  >
                    <BadgeIcon sx={{ fontSize: 14, color: '#7c3aed' }} />
                  </Box>
                  <Box sx={{ flex: 1, minWidth: 0 }}>
                    <Typography sx={{ fontSize: '0.82rem', fontWeight: 500, color: '#1e293b' }}>
                      {person.personName}
                    </Typography>
                    <Typography sx={{ fontSize: '0.7rem', color: '#64748b' }}>
                      {person.badgeId || '—'} • {person.designation || 'No designation'}
                    </Typography>
                  </Box>
                  {person.designation && (
                    <Chip
                      label={person.designation}
                      size="small"
                      sx={{ height: 18, fontSize: '0.6rem', ml: 1 }}
                    />
                  )}
                </Box>
              ))}
            </Box>
          ) : (
            <Box sx={{ py: 1.5, px: 2 }}>
              <Typography sx={{ fontSize: '0.8rem', color: '#9ca3af', textAlign: 'center' }}>
                {t('assignDuties.personnel.noPersonnelFound')}
              </Typography>
            </Box>
          )}
        </Paper>
      )}
    </Box>
  );
};

// ===== Leave Type Mapping =====
const LEAVE_TYPE_MAP: Record<string, string> = {
  'CL (CASUAL LEAVE)': 'CASUAL_LEAVE',
  'CML (COMPENSATORY LEAVE)': 'COMPENSATORY_OFF',
  'PL (PRIVILEGE LEAVE)': 'PRIVILEGE_LEAVE',
  'EL (EARNED LEAVE)': 'EARNED_LEAVE',
  'ABSENT': 'ABSENT',
  'SUSPENSION': 'SUSPENSION',
  'PERMISSION / RH TO RPI, RSI AND': 'PERMISSION',
  'SICK': 'SICK_LEAVE',
  'WEEKLY OFF': 'WEEKLY_OFF',
};

const BACKEND_TO_DISPLAY: Record<string, string> = {
  'CASUAL_LEAVE': 'CL (CASUAL LEAVE)',
  'COMPENSATORY_OFF': 'CML (COMPENSATORY LEAVE)',
  'PRIVILEGE_LEAVE': 'PL (PRIVILEGE LEAVE)',
  'EARNED_LEAVE': 'EL (EARNED LEAVE)',
  'ABSENT': 'ABSENT',
  'SUSPENSION': 'SUSPENSION',
  'PERMISSION': 'PERMISSION / RH TO RPI, RSI AND',
  'SICK_LEAVE': 'SICK',
  'WEEKLY_OFF': 'WEEKLY OFF',
};

// ===== Leave Management Panel (Two-card layout matching Duty Management) =====
interface LeaveManagementPanelProps {
  sectionCode: string;
  sectionColor: string;
  sectionBgColor: string;
  chartData: SectionChartData;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  onAssign?: any;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  onUnassign?: any;
  onRefresh?: () => void;
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
  highlightedPersonId?: number | null;
}

const LeaveManagementPanel: React.FC<LeaveManagementPanelProps> = ({
  sectionCode, sectionColor, sectionBgColor,
  selectedCategory, onCategoryChange, chartData, highlightedPersonId,
}) => {
  const { t } = useTranslation();
  const [leaveRecords, setLeaveRecords] = useState<LeaveRequestDto[]>([]);
  const [loading, setLoading] = useState(false);
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState<{
    personnelId: number | null;
    startDate: string;
    endDate: string;
    reason: string;
  }>({ personnelId: null, startDate: '', endDate: '', reason: '' });

  // Close Leave state
  const [closeLeaveRecord, setCloseLeaveRecord] = useState<LeaveRequestDto | null>(null);
  const [closeLeaveEndDate, setCloseLeaveEndDate] = useState('');
  const [closeLeaveComments, setCloseLeaveComments] = useState('');

  // Add Leave Type state
  const [showAddLeaveType, setShowAddLeaveType] = useState(false);
  const [newLeaveTypeName, setNewLeaveTypeName] = useState('');
  const [addingLeaveType, setAddingLeaveType] = useState(false);

  // Build set of personnel IDs belonging to this section from chartData
  const sectionPersonnelIds = useMemo(() => {
    const ids = new Set<number>();
    if (chartData) {
      for (const card of chartData.dutyCards) {
        for (const p of card.personnel) { ids.add(p.id); }
        for (const sub of card.subDuties) {
          for (const p of sub.personnel) { ids.add(p.id); }
        }
      }
    }
    return ids;
  }, [chartData]);

  // Fetch active leave records on mount and filter by section
  const fetchLeaveRecords = useCallback(async () => {
    setLoading(true);
    try {
      const result = await leaveService.list(undefined, 0, 500);
      const today = new Date().toISOString().split('T')[0];
      
      // Filter for APPROVED leaves where today is between startDate and endDate (or endDate is null/undefined = ongoing)
      const activeLeaves = result.content.filter((lr) => {
        const isApproved = lr.status === 'APPROVED';
        const startOk = lr.startDate <= today;
        // Handle both null and undefined for open-ended leaves
        const endOk = !lr.endDate || lr.endDate >= today;
        return isApproved && startOk && endOk;
      });
      // Filter by section personnel IDs (if available)
      const sectionLeaves = sectionPersonnelIds.size > 0
        ? activeLeaves.filter((lr) => sectionPersonnelIds.has(lr.personnelId))
        : activeLeaves;
      
      setLeaveRecords(sectionLeaves);
    } catch {
      // Error fetching leave records
    } finally {
      setLoading(false);
    }
  }, [sectionPersonnelIds]);

  useEffect(() => {
    fetchLeaveRecords();
  }, [fetchLeaveRecords]);

  // Group leave records by display category
  const leaveGroups: Record<string, LeaveRequestDto[]> = {};
  LEAVE_CATEGORIES.forEach((cat) => { leaveGroups[cat.name] = []; });

  leaveRecords.forEach((lr) => {
    const displayName = BACKEND_TO_DISPLAY[lr.leaveType] || lr.leaveType;
    if (leaveGroups[displayName]) {
      leaveGroups[displayName].push(lr);
    } else {
      // Fallback: put in first category
      leaveGroups[LEAVE_CATEGORIES[0].name]?.push(lr);
    }
  });

  const totalLeavePersonnel = leaveRecords.length;
  const selectedCategoryData = LEAVE_CATEGORIES.find((c) => c.name === selectedCategory);
  const selectedRecords = leaveGroups[selectedCategory] || [];

  // Handle adding a new leave type
  const handleAddLeaveType = async () => {
    if (!newLeaveTypeName.trim()) return;
    setAddingLeaveType(true);
    try {
      await api.post('/api/section-chart/add-leave-type', { name: newLeaveTypeName.trim() });
      setNewLeaveTypeName('');
      setShowAddLeaveType(false);
      // Add to local LEAVE_CATEGORIES so it shows immediately without page reload
      const upperName = newLeaveTypeName.trim().toUpperCase();
      if (!LEAVE_CATEGORIES.find(c => c.name === upperName)) {
        // For dynamically added categories, use the name as display (no translation key)
        LEAVE_CATEGORIES.push({ name: upperName, nameKey: '', descKey: '' });
      }
    } catch {
      // Error adding leave type
    } finally {
      setAddingLeaveType(false);
    }
  };

  // Handle adding a leave record
  const handleSubmitLeave = async () => {
    // Allow all leave types to be submitted without end date (open-ended)
    if (!formData.personnelId || !formData.startDate) return;
    setSaving(true);
    try {
      const backendLeaveType = LEAVE_TYPE_MAP[selectedCategory] || 'CASUAL_LEAVE';
      await leaveService.submit({
        personnelId: formData.personnelId,
        leaveType: backendLeaveType,
        startDate: formData.startDate,
        endDate: formData.endDate || undefined,
        reason: formData.reason || undefined,
      });
      setAddDialogOpen(false);
      setFormData({ personnelId: null, startDate: '', endDate: '', reason: '' });
      fetchLeaveRecords();
    } catch {
      // Error submitting leave
    } finally {
      setSaving(false);
    }
  };

  // Handle closing an open-ended leave
  const handleCloseLeaveConfirm = async () => {
    if (!closeLeaveRecord || !closeLeaveEndDate) return;
    setSaving(true);
    try {
      await leaveService.close(closeLeaveRecord.id, closeLeaveEndDate, closeLeaveComments);
      setCloseLeaveRecord(null);
      setCloseLeaveEndDate('');
      setCloseLeaveComments('');
      fetchLeaveRecords();
    } catch {
      // Error closing leave
    } finally {
      setSaving(false);
    }
  };

  // Handle canceling a leave
  const handleCancelLeave = async (id: number) => {
    setSaving(true);
    try {
      await leaveService.cancel(id);
      fetchLeaveRecords();
    } catch {
      // Error canceling leave
    } finally {
      setSaving(false);
    }
  };

  // Calculate days between two dates
  const calculateDays = (start: string, end: string | null): number | string => {
    if (!end) {
      // Open-ended (sick leave) — calculate from start to today
      const startMs = new Date(start).getTime();
      const todayMs = new Date().getTime();
      return Math.floor((todayMs - startMs) / (1000 * 60 * 60 * 24)) + 1;
    }
    const startMs = new Date(start).getTime();
    const endMs = new Date(end).getTime();
    return Math.floor((endMs - startMs) / (1000 * 60 * 60 * 24)) + 1;
  };

  return (
    <Box sx={{ display: 'flex', gap: 2, alignItems: 'flex-start' }}>
      {/* LEFT SIDEBAR: Leave Categories */}
      <Paper
        elevation={0}
        sx={{
          width: { xs: 200, sm: 240, md: 280 },
          flexShrink: 0,
          border: '1px solid',
          borderColor: 'divider',
          borderRadius: '12px',
          display: 'flex',
          flexDirection: 'column',
          position: 'sticky',
          top: 16,
        }}
      >
        {/* Sidebar Header */}
        <Box sx={{ px: 2, py: 1.5, bgcolor: sectionBgColor, borderBottom: '1px solid', borderColor: 'divider' }}>
          <Typography variant="subtitle2" sx={{ fontWeight: 700, color: sectionColor }}>
            {t('assignDuties.leavePanel.title')}
          </Typography>
          <Typography variant="caption" color="text.secondary">
            {LEAVE_CATEGORIES.length} {t('assignDuties.leavePanel.types')} • {totalLeavePersonnel} {t('assignDuties.dutyPanel.personnel')}
          </Typography>
        </Box>

        {/* Leave Category List */}
        <Box>
          <List dense disablePadding>
            {LEAVE_CATEGORIES.map((cat) => {
              const count = leaveGroups[cat.name]?.length || 0;
              return (
                <ListItemButton
                  key={cat.name}
                  selected={selectedCategory === cat.name}
                  onClick={() => onCategoryChange(cat.name)}
                  sx={{
                    px: 2, py: 1,
                    borderLeft: selectedCategory === cat.name ? `3px solid ${sectionColor}` : '3px solid transparent',
                    '&.Mui-selected': { bgcolor: `${sectionColor}08` },
                    '&.Mui-selected:hover': { bgcolor: `${sectionColor}12` },
                  }}
                >
                  <ListItemText
                    primary={
                      <Stack direction="row" spacing={0.5} alignItems="center">
                        <Typography
                          variant="caption"
                          sx={{
                            fontWeight: selectedCategory === cat.name ? 700 : 500,
                            fontSize: '0.7rem',
                            textTransform: 'uppercase',
                            letterSpacing: '0.3px',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap',
                            flex: 1,
                          }}
                        >
                          {cat.nameKey ? t(cat.nameKey) : cat.name}
                        </Typography>
                        <Chip
                          label={count}
                          size="small"
                          sx={{
                            height: 18, fontSize: '0.6rem', fontWeight: 700,
                            bgcolor: count > 0 ? `${sectionColor}15` : 'grey.100',
                            color: count > 0 ? sectionColor : 'text.disabled',
                          }}
                        />
                      </Stack>
                    }
                  />
                </ListItemButton>
              );
            })}
          </List>
        </Box>

        {/* Add Leave Type */}
        <Box sx={{ px: 2, py: 1, borderTop: '1px solid', borderColor: 'divider' }}>
          {showAddLeaveType ? (
            <Stack spacing={1}>
              <TextField
                size="small"
                placeholder={t('assignDuties.leavePanel.leaveTypeName')}
                value={newLeaveTypeName}
                onChange={(e) => setNewLeaveTypeName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && newLeaveTypeName.trim()) {
                    handleAddLeaveType();
                  } else if (e.key === 'Escape') {
                    setShowAddLeaveType(false);
                    setNewLeaveTypeName('');
                  }
                }}
                autoFocus
                fullWidth
                sx={{ '& .MuiInputBase-input': { fontSize: '0.75rem' } }}
              />
              <Stack direction="row" spacing={0.5}>
                <Button
                  size="small"
                  variant="contained"
                  disabled={!newLeaveTypeName.trim() || addingLeaveType}
                  onClick={handleAddLeaveType}
                  sx={{ fontSize: '0.65rem', textTransform: 'none', flex: 1 }}
                >
                  {addingLeaveType ? t('assignDuties.leavePanel.adding') : t('app.add')}
                </Button>
                <Button
                  size="small"
                  onClick={() => { setShowAddLeaveType(false); setNewLeaveTypeName(''); }}
                  sx={{ fontSize: '0.65rem', textTransform: 'none' }}
                >
                  {t('app.cancel')}
                </Button>
              </Stack>
            </Stack>
          ) : (
            <Button
              size="small"
              startIcon={<AddCircleOutlineIcon sx={{ fontSize: 14 }} />}
              onClick={() => setShowAddLeaveType(true)}
              sx={{ fontSize: '0.7rem', textTransform: 'none', color: sectionColor }}
            >
              {t('assignDuties.leavePanel.addLeaveType')}
            </Button>
          )}
        </Box>
      </Paper>

      {/* RIGHT: Detail Panel for selected leave category */}
      <Box sx={{ flex: 1, minWidth: 0, alignSelf: 'stretch' }}>
        {selectedCategoryData ? (
          <Paper
            elevation={0}
            sx={{ border: '1px solid', borderColor: 'divider', borderRadius: '12px', height: '100%', display: 'flex', flexDirection: 'column' }}
          >
            {/* Header */}
            <Box sx={{ px: 3, py: 2, bgcolor: sectionBgColor, borderBottom: '1px solid', borderColor: 'divider' }}>
              <Stack direction="row" spacing={1.5} alignItems="center" justifyContent="space-between">
                <Stack direction="row" spacing={1.5} alignItems="center">
                  <Typography variant="h6" sx={{ fontWeight: 700, color: sectionColor, textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                    {t(selectedCategoryData.nameKey)}
                  </Typography>
                  <Chip
                    label={`${selectedRecords.length} ${t('assignDuties.dutyPanel.personnel')}`}
                    size="small"
                    sx={{ fontWeight: 600, bgcolor: `${sectionColor}15`, color: sectionColor }}
                  />
                </Stack>
                <Button
                  size="small"
                  variant="contained"
                  startIcon={<PersonAddIcon sx={{ fontSize: 16 }} />}
                  onClick={() => setAddDialogOpen(true)}
                  sx={{ textTransform: 'none' }}
                >
                  {t('assignDuties.leavePanel.addPersonOnLeave')}
                </Button>
              </Stack>
              <Typography variant="caption" color="text.secondary">
                {t(selectedCategoryData.descKey)}
              </Typography>
            </Box>

            {/* Leave Records Table */}
            <Box sx={{ flex: 1, overflowY: 'auto', p: 2 }}>
              {loading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
                  <CircularProgress size={24} />
                </Box>
              ) : selectedRecords.length > 0 ? (
                <Box sx={{ overflowX: 'auto' }}>
                  <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.82rem' }}>
                    <thead>
                      <tr style={{ borderBottom: '2px solid #e0e0e0' }}>
                        <th style={{ textAlign: 'left', padding: '8px 12px', fontWeight: 700, fontSize: '0.75rem', textTransform: 'uppercase', color: '#666' }}>{t('assignDuties.leavePanel.tableHeaders.badgeId')}</th>
                        <th style={{ textAlign: 'left', padding: '8px 12px', fontWeight: 700, fontSize: '0.75rem', textTransform: 'uppercase', color: '#666' }}>{t('assignDuties.leavePanel.tableHeaders.name')}</th>
                        <th style={{ textAlign: 'left', padding: '8px 12px', fontWeight: 700, fontSize: '0.75rem', textTransform: 'uppercase', color: '#666' }}>{t('assignDuties.leavePanel.tableHeaders.startDate')}</th>
                        <th style={{ textAlign: 'left', padding: '8px 12px', fontWeight: 700, fontSize: '0.75rem', textTransform: 'uppercase', color: '#666' }}>{t('assignDuties.leavePanel.tableHeaders.endDate')}</th>
                        <th style={{ textAlign: 'center', padding: '8px 12px', fontWeight: 700, fontSize: '0.75rem', textTransform: 'uppercase', color: '#666' }}>{t('assignDuties.leavePanel.tableHeaders.days')}</th>
                        <th style={{ textAlign: 'left', padding: '8px 12px', fontWeight: 700, fontSize: '0.75rem', textTransform: 'uppercase', color: '#666' }}>{t('assignDuties.leavePanel.tableHeaders.reason')}</th>
                        <th style={{ textAlign: 'center', padding: '8px 12px', fontWeight: 700, fontSize: '0.75rem', textTransform: 'uppercase', color: '#666' }}>{t('assignDuties.leavePanel.tableHeaders.actions')}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedRecords.map((record) => {
                        const isHighlighted = highlightedPersonId === record.personnelId;
                        return (
                        <tr 
                          key={record.id} 
                          style={{ 
                            borderBottom: '1px solid #f0f0f0',
                            backgroundColor: isHighlighted ? '#fef9c3' : undefined,
                            boxShadow: isHighlighted ? '0 0 12px rgba(234, 179, 8, 0.4)' : undefined,
                          }}
                          className={isHighlighted ? 'highlight-pulse' : undefined}
                        >
                          <td style={{ padding: '8px 12px', fontWeight: 600, color: '#1976d2' }}>{record.badgeId || '—'}</td>
                          <td style={{ padding: '8px 12px' }}>{record.personnelName}</td>
                          <td style={{ padding: '8px 12px' }}>{record.startDate}</td>
                          <td style={{ padding: '8px 12px' }}>{record.endDate || t('assignDuties.leavePanel.ongoing')}</td>
                          <td style={{ padding: '8px 12px', textAlign: 'center', fontWeight: 600 }}>{calculateDays(record.startDate, record.endDate)}</td>
                          <td style={{ padding: '8px 12px', maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{record.reason || '—'}</td>
                          <td style={{ padding: '8px 12px', textAlign: 'center' }}>
                            <Box sx={{ display: 'inline-flex', gap: 0.5 }}>
                              {/* Close Leave button - only for leaves without end date */}
                              {!record.endDate && (
                                <Tooltip title={t('assignDuties.leavePanel.closeLeave')}>
                                  <IconButton
                                    size="small"
                                    onClick={() => { setCloseLeaveRecord(record); setCloseLeaveEndDate(''); setCloseLeaveComments(''); }}
                                    disabled={saving}
                                    sx={{ color: '#1d4ed8' }}
                                  >
                                    <EventAvailableIcon sx={{ fontSize: 16 }} />
                                  </IconButton>
                                </Tooltip>
                              )}
                              <Tooltip title={t('assignDuties.leavePanel.cancelLeave')}>
                                <IconButton
                                  size="small"
                                  onClick={() => handleCancelLeave(record.id)}
                                  disabled={saving}
                                  sx={{ color: 'error.main' }}
                                >
                                  <DeleteOutlineIcon sx={{ fontSize: 16 }} />
                                </IconButton>
                              </Tooltip>
                            </Box>
                          </td>
                        </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </Box>
              ) : (
                <Typography variant="body2" color="text.secondary" sx={{ py: 2 }}>
                  {t('assignDuties.leavePanel.noActiveRecords')}
                </Typography>
              )}
            </Box>
          </Paper>
        ) : (
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', opacity: 0.5 }}>
            <Typography variant="body2" color="text.secondary">
              {t('assignDuties.leavePanel.selectLeaveType')}
            </Typography>
          </Box>
        )}
      </Box>

      {/* Add Leave Dialog */}
      <Dialog open={addDialogOpen} onClose={() => setAddDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>{t('assignDuties.leavePanel.addPersonOnLeave')} — {t(LEAVE_CATEGORIES.find(c => c.name === selectedCategory)?.nameKey || '')}</DialogTitle>
        <DialogContent>
          <Stack spacing={2.5} sx={{ mt: 1 }}>
            <Box>
              <Typography variant="caption" color="text.secondary" sx={{ mb: 0.5, display: 'block' }}>
                {t('app.person')}
              </Typography>
              <PersonnelAutocomplete
                onSelect={(personnelId) => setFormData((prev) => ({ ...prev, personnelId }))}
                onCancel={() => setFormData((prev) => ({ ...prev, personnelId: null }))}
              />
            </Box>
            <TextField
              label={t('leave.startDate')}
              type="date"
              size="small"
              fullWidth
              InputLabelProps={{ shrink: true }}
              value={formData.startDate}
              onChange={(e) => setFormData((prev) => ({ ...prev, startDate: e.target.value }))}
            />
            <TextField
              label={t('leave.endDate')}
              type="date"
              size="small"
              fullWidth
              InputLabelProps={{ shrink: true }}
              value={formData.endDate}
              onChange={(e) => setFormData((prev) => ({ ...prev, endDate: e.target.value }))}
              helperText={t('assignDuties.leavePanel.leaveBlankForOpenEnded')}
            />
            <TextField
              label={t('leave.reason')}
              size="small"
              fullWidth
              multiline
              rows={2}
              value={formData.reason}
              onChange={(e) => setFormData((prev) => ({ ...prev, reason: e.target.value }))}
            />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => { setAddDialogOpen(false); setFormData({ personnelId: null, startDate: '', endDate: '', reason: '' }); }}>
            {t('app.cancel')}
          </Button>
          <Button
            variant="contained"
            onClick={handleSubmitLeave}
            disabled={saving || !formData.personnelId || !formData.startDate}
          >
            {saving ? <CircularProgress size={18} /> : t('app.submit')}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Close Leave Dialog */}
      <Dialog open={closeLeaveRecord !== null} onClose={() => setCloseLeaveRecord(null)} maxWidth="xs" fullWidth>
        <DialogTitle sx={{ color: '#1d4ed8' }}>{t('assignDuties.closeLeaveDialog.title')}</DialogTitle>
        <DialogContent>
          {closeLeaveRecord && (
            <Stack spacing={2} sx={{ mt: 1 }}>
              <Box sx={{ bgcolor: '#f9fafb', borderRadius: 1, p: 1.5, border: '1px solid #e5e7eb' }}>
                <Typography variant="caption" color="text.secondary">{t('assignDuties.closeLeaveDialog.personnel')}</Typography>
                <Typography variant="body2" fontWeight={600}>{closeLeaveRecord.personnelName}</Typography>
                <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>{t('assignDuties.closeLeaveDialog.leaveType')}</Typography>
                <Typography variant="body2">{closeLeaveRecord.leaveType.replace(/_/g, ' ')}</Typography>
                <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>{t('assignDuties.closeLeaveDialog.startDate')}</Typography>
                <Typography variant="body2">{closeLeaveRecord.startDate}</Typography>
              </Box>
              <TextField
                label={t('assignDuties.closeLeaveDialog.endDate')}
                type="date"
                size="small"
                fullWidth
                required
                InputLabelProps={{ shrink: true }}
                inputProps={{ min: closeLeaveRecord.startDate }}
                value={closeLeaveEndDate}
                onChange={(e) => setCloseLeaveEndDate(e.target.value)}
              />
              <TextField
                label={t('assignDuties.closeLeaveDialog.comments')}
                size="small"
                fullWidth
                multiline
                rows={2}
                value={closeLeaveComments}
                onChange={(e) => setCloseLeaveComments(e.target.value)}
                placeholder={t('assignDuties.closeLeaveDialog.commentsPlaceholder')}
              />
            </Stack>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setCloseLeaveRecord(null)}>{t('app.cancel')}</Button>
          <Button
            variant="contained"
            onClick={handleCloseLeaveConfirm}
            disabled={saving || !closeLeaveEndDate}
            sx={{ bgcolor: '#1d4ed8', '&:hover': { bgcolor: '#1e40af' } }}
          >
            {saving ? <CircularProgress size={18} /> : t('assignDuties.closeLeaveDialog.closeLeave')}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default AssignDutiesPage;

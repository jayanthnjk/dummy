package com.policescheduler.report.generator;

import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.PageSize;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.policescheduler.entity.LeaveRequest;
import com.policescheduler.entity.Personnel;
import com.policescheduler.report.PdfReportGenerator;
import com.policescheduler.report.PdfStyleHelper;
import com.policescheduler.report.ReportGenerationException;
import com.policescheduler.report.ReportLocalizationService;
import com.policescheduler.report.ReportRequest;
import com.policescheduler.repository.LeaveRequestRepository;
import com.policescheduler.repository.PersonnelRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import jakarta.persistence.criteria.Predicate;
import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class LeaveStatementReportGenerator implements PdfReportGenerator {

    private static final Logger log = LoggerFactory.getLogger(LeaveStatementReportGenerator.class);
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    private static final Color HEADER_BG = new Color(211, 211, 211);
    private static final Font HEADER_FONT = new Font(Font.HELVETICA, 8, Font.BOLD, Color.BLACK);
    private static final Font CELL_FONT = new Font(Font.HELVETICA, 7.5f, Font.NORMAL, Color.BLACK);
    private static final Font SECTION_FONT = new Font(Font.HELVETICA, 8, Font.BOLD, Color.BLACK);
    private static final Font TITLE_FONT = new Font(Font.HELVETICA, 12, Font.BOLD, Color.BLACK);

    private static final Color[] SECTION_COLORS = {
            new Color(255, 235, 156),  // Light yellow
            new Color(198, 224, 180),  // Light green
            new Color(189, 215, 238),  // Light blue
            new Color(248, 203, 173),  // Light orange
            new Color(217, 196, 236),  // Light purple
            new Color(255, 199, 206),  // Light pink
            new Color(191, 225, 212),  // Light teal
            new Color(255, 217, 179),  // Light peach
            new Color(204, 204, 255),  // Light lavender
            new Color(204, 255, 204),  // Light mint
    };

    private final LeaveRequestRepository leaveRequestRepository;
    private final PersonnelRepository personnelRepository;
    private final PdfStyleHelper pdfStyleHelper;
    private final ReportLocalizationService localizationService;

    public LeaveStatementReportGenerator(LeaveRequestRepository leaveRequestRepository,
                                          PersonnelRepository personnelRepository,
                                          PdfStyleHelper pdfStyleHelper,
                                          ReportLocalizationService localizationService) {
        this.leaveRequestRepository = leaveRequestRepository;
        this.personnelRepository = personnelRepository;
        this.pdfStyleHelper = pdfStyleHelper;
        this.localizationService = localizationService;
    }

    @Override
    public String getReportType() {
        return "leave_statement";
    }

    @Override
    public byte[] generate(ReportRequest request) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            Document document = new Document(PageSize.A4.rotate(), 10, 10, 10, 10);
            PdfWriter.getInstance(document, baos);
            document.open();

            String locale = request.getLocale() != null ? request.getLocale() : "en";

            // Title
            String titleText = "LEAVE STATEMENT";
            if (request.getStartDate() != null && request.getEndDate() != null) {
                titleText += " (" + request.getStartDate().format(DATE_FORMAT)
                        + " TO " + request.getEndDate().format(DATE_FORMAT) + ")";
            }
            PdfPTable titleTable = new PdfPTable(1);
            titleTable.setWidthPercentage(100);
            PdfPCell titleCell = new PdfPCell(new Phrase(titleText, TITLE_FONT));
            titleCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            titleCell.setBorder(0);
            titleCell.setPaddingBottom(8);
            titleTable.addCell(titleCell);
            document.add(titleTable);

            // Generation date
            PdfPTable dateTable = new PdfPTable(1);
            dateTable.setWidthPercentage(100);
            PdfPCell dateCell = new PdfPCell(new Phrase(
                    "Generated: " + LocalDate.now().format(DATE_FORMAT), CELL_FONT));
            dateCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
            dateCell.setBorder(0);
            dateCell.setPaddingBottom(6);
            dateTable.addCell(dateCell);
            document.add(dateTable);

            // Query leave requests with filters
            Specification<LeaveRequest> spec = buildSpecification(request);
            List<LeaveRequest> leaveRequests = leaveRequestRepository.findAll(spec);

            // Load personnel for names
            List<Long> personnelIds = leaveRequests.stream()
                    .map(LeaveRequest::getPersonnelId)
                    .distinct()
                    .collect(Collectors.toList());
            Map<Long, Personnel> personnelMap = personnelRepository.findAllById(personnelIds)
                    .stream().collect(Collectors.toMap(Personnel::getId, p -> p));

            // Group by leave type
            Map<String, List<LeaveRequest>> byType = leaveRequests.stream()
                    .collect(Collectors.groupingBy(
                            lr -> lr.getLeaveType() != null ? lr.getLeaveType() : "UNKNOWN",
                            LinkedHashMap::new,
                            Collectors.toList()));

            if (byType.isEmpty()) {
                PdfPTable emptyTable = new PdfPTable(1);
                emptyTable.setWidthPercentage(100);
                PdfPCell emptyCell = new PdfPCell(new Phrase("No leave records found for the selected date range.", CELL_FONT));
                emptyCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                emptyCell.setPadding(10);
                emptyTable.addCell(emptyCell);
                document.add(emptyTable);
            } else {
                // Summary counts for footer
                Map<String, Integer> typeCounts = new LinkedHashMap<>();
                int colorIndex = 0;

                for (Map.Entry<String, List<LeaveRequest>> entry : byType.entrySet()) {
                    String leaveType = entry.getKey();
                    List<LeaveRequest> leaves = entry.getValue();
                    typeCounts.put(leaveType, leaves.size());

                    // Section header with color
                    Color sectionColor = SECTION_COLORS[colorIndex % SECTION_COLORS.length];
                    colorIndex++;

                    PdfPTable sectionHeader = new PdfPTable(1);
                    sectionHeader.setWidthPercentage(100);
                    sectionHeader.setSpacingBefore(6);
                    PdfPCell secCell = new PdfPCell(new Phrase(
                            formatLeaveType(leaveType) + " (" + leaves.size() + ")", SECTION_FONT));
                    secCell.setBackgroundColor(sectionColor);
                    secCell.setPadding(4);
                    secCell.setBorderWidth(0.5f);
                    sectionHeader.addCell(secCell);
                    document.add(sectionHeader);

                    // Data table: SL.NO | Badge ID / Name | Designation | From | To | Days | Reason
                    PdfPTable table = new PdfPTable(7);
                    table.setWidthPercentage(100);
                    table.setWidths(new float[]{6, 22, 12, 12, 12, 8, 28});

                    // Header row
                    String[] headers = {"SL.NO", "Badge ID / Name", "Designation", "From", "To", "Days", "Reason"};
                    for (String header : headers) {
                        PdfPCell hCell = new PdfPCell(new Phrase(header, HEADER_FONT));
                        hCell.setBackgroundColor(HEADER_BG);
                        hCell.setPadding(3);
                        hCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                        hCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                        hCell.setBorderWidth(0.5f);
                        table.addCell(hCell);
                    }

                    int slNo = 1;
                    for (LeaveRequest lr : leaves) {
                        Personnel p = personnelMap.get(lr.getPersonnelId());

                        // SL.NO
                        table.addCell(createDataCell(String.valueOf(slNo++), Element.ALIGN_CENTER));

                        // Badge ID / Name
                        String badgeName = "";
                        if (p != null) {
                            badgeName = (p.getBadgeId() != null ? p.getBadgeId() : "") + " / "
                                    + (p.getPersonName() != null ? p.getPersonName() : "");
                        }
                        table.addCell(createDataCell(badgeName, Element.ALIGN_LEFT));

                        // Designation
                        table.addCell(createDataCell(
                                p != null && p.getDesignation() != null ? p.getDesignation() : "", Element.ALIGN_CENTER));

                        // From
                        table.addCell(createDataCell(
                                lr.getStartDate() != null ? lr.getStartDate().format(DATE_FORMAT) : "", Element.ALIGN_CENTER));

                        // To
                        table.addCell(createDataCell(
                                lr.getEndDate() != null ? lr.getEndDate().format(DATE_FORMAT) : "", Element.ALIGN_CENTER));

                        // Days
                        long days = 0;
                        if (lr.getStartDate() != null && lr.getEndDate() != null) {
                            days = ChronoUnit.DAYS.between(lr.getStartDate(), lr.getEndDate()) + 1;
                        }
                        table.addCell(createDataCell(String.valueOf(days), Element.ALIGN_CENTER));

                        // Reason
                        table.addCell(createDataCell(
                                lr.getReason() != null ? lr.getReason() : "", Element.ALIGN_LEFT));
                    }

                    document.add(table);
                }

                // Summary table at the end
                document.add(new Phrase("\n"));
                PdfPTable summaryHeader = new PdfPTable(1);
                summaryHeader.setWidthPercentage(100);
                summaryHeader.setSpacingBefore(10);
                PdfPCell summaryTitleCell = new PdfPCell(new Phrase("SUMMARY", SECTION_FONT));
                summaryTitleCell.setBackgroundColor(HEADER_BG);
                summaryTitleCell.setPadding(4);
                summaryTitleCell.setBorderWidth(0.5f);
                summaryTitleCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                summaryHeader.addCell(summaryTitleCell);
                document.add(summaryHeader);

                PdfPTable summaryTable = new PdfPTable(2);
                summaryTable.setWidthPercentage(50);
                summaryTable.setHorizontalAlignment(Element.ALIGN_LEFT);
                summaryTable.setWidths(new float[]{70, 30});

                // Header
                PdfPCell sTypeHeader = new PdfPCell(new Phrase("Leave Type", HEADER_FONT));
                sTypeHeader.setBackgroundColor(HEADER_BG);
                sTypeHeader.setPadding(3);
                sTypeHeader.setBorderWidth(0.5f);
                summaryTable.addCell(sTypeHeader);

                PdfPCell sCountHeader = new PdfPCell(new Phrase("Count", HEADER_FONT));
                sCountHeader.setBackgroundColor(HEADER_BG);
                sCountHeader.setPadding(3);
                sCountHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
                sCountHeader.setBorderWidth(0.5f);
                summaryTable.addCell(sCountHeader);

                int totalCount = 0;
                for (Map.Entry<String, Integer> entry : typeCounts.entrySet()) {
                    summaryTable.addCell(createDataCell(formatLeaveType(entry.getKey()), Element.ALIGN_LEFT));
                    summaryTable.addCell(createDataCell(String.valueOf(entry.getValue()), Element.ALIGN_CENTER));
                    totalCount += entry.getValue();
                }

                // Total row
                PdfPCell totalLabelCell = new PdfPCell(new Phrase("TOTAL", HEADER_FONT));
                totalLabelCell.setBackgroundColor(HEADER_BG);
                totalLabelCell.setPadding(3);
                totalLabelCell.setBorderWidth(0.5f);
                summaryTable.addCell(totalLabelCell);

                PdfPCell totalValueCell = new PdfPCell(new Phrase(String.valueOf(totalCount), HEADER_FONT));
                totalValueCell.setBackgroundColor(HEADER_BG);
                totalValueCell.setPadding(3);
                totalValueCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                totalValueCell.setBorderWidth(0.5f);
                summaryTable.addCell(totalValueCell);

                document.add(summaryTable);
            }

            document.close();
            return baos.toByteArray();
        } catch (Exception e) {
            log.error("Failed to generate leave statement report", e);
            throw new ReportGenerationException("leave_statement",
                    "Failed to generate leave statement report", e);
        }
    }

    private PdfPCell createDataCell(String text, int alignment) {
        PdfPCell cell = new PdfPCell(new Phrase(text, CELL_FONT));
        cell.setPadding(2);
        cell.setHorizontalAlignment(alignment);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setBorderWidth(0.5f);
        return cell;
    }

    private String formatLeaveType(String leaveType) {
        if (leaveType == null) return "Unknown";
        // Convert SICK_LEAVE -> Sick Leave, CASUAL_LEAVE -> Casual Leave, etc.
        return java.util.Arrays.stream(leaveType.split("_"))
                .map(word -> word.charAt(0) + word.substring(1).toLowerCase())
                .collect(Collectors.joining(" "));
    }

    private Specification<LeaveRequest> buildSpecification(ReportRequest request) {
        return (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (request.getLeaveStatus() != null && !request.getLeaveStatus().isBlank()) {
                predicates.add(cb.equal(root.get("status"), request.getLeaveStatus()));
            }
            if (request.getLeaveType() != null && !request.getLeaveType().isBlank()) {
                predicates.add(cb.equal(root.get("leaveType"), request.getLeaveType()));
            }
            // Date range filter: leaves that overlap with the given range
            if (request.getStartDate() != null) {
                predicates.add(cb.greaterThanOrEqualTo(root.get("startDate"), request.getStartDate()));
            }
            if (request.getEndDate() != null) {
                predicates.add(cb.lessThanOrEqualTo(root.get("startDate"), request.getEndDate()));
            }

            return cb.and(predicates.toArray(new Predicate[0]));
        };
    }
}

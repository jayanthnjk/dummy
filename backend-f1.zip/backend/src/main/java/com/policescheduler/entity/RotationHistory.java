package com.policescheduler.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "rotation_history")
public class RotationHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "cycle_id", nullable = false)
    private Long cycleId;

    @Column(name = "platoon_id", nullable = false)
    private Long platoonId;

    @Column(name = "previous_section_id")
    private Long previousSectionId;

    @Column(name = "new_section_id", nullable = false)
    private Long newSectionId;

    @Column(name = "personnel_count", nullable = false)
    private Integer personnelCount = 0;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getCycleId() { return cycleId; }
    public void setCycleId(Long cycleId) { this.cycleId = cycleId; }

    public Long getPlatoonId() { return platoonId; }
    public void setPlatoonId(Long platoonId) { this.platoonId = platoonId; }

    public Long getPreviousSectionId() { return previousSectionId; }
    public void setPreviousSectionId(Long previousSectionId) { this.previousSectionId = previousSectionId; }

    public Long getNewSectionId() { return newSectionId; }
    public void setNewSectionId(Long newSectionId) { this.newSectionId = newSectionId; }

    public Integer getPersonnelCount() { return personnelCount; }
    public void setPersonnelCount(Integer personnelCount) { this.personnelCount = personnelCount; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}

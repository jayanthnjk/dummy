package com.policescheduler.repository;

import com.policescheduler.entity.PlatoonQrtAssignment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PlatoonQrtAssignmentRepository extends JpaRepository<PlatoonQrtAssignment, Long> {

    List<PlatoonQrtAssignment> findByPlatoonIdAndIsActiveTrue(Long platoonId);

    List<PlatoonQrtAssignment> findByIsActiveTrue();
}

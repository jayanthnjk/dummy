import React, { useRef, useEffect } from 'react';
import { Box, Typography, Avatar, keyframes } from '@mui/material';
import ResponseRenderer from './chat/ResponseRenderer';

import type { TableResponseData, FormResponseData, ConfirmationResponseData, SuggestionsResponseData } from '@/types';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  responseType?: 'text' | 'table' | 'form' | 'confirmation' | 'suggestions';
  data?: TableResponseData | FormResponseData | ConfirmationResponseData | SuggestionsResponseData;
}

interface ChatConversationProps {
  messages: ChatMessage[];
  userName?: string;
  loading?: boolean;
  onFormSubmit: (formId: string, submitAction: string, fields: Record<string, string>) => Promise<boolean>;
  onSuggestionClick: (suggestion: string) => void;
}

const bounce = keyframes`
  0%, 80%, 100% { transform: scale(0); }
  40% { transform: scale(1); }
`;

const ChatConversation: React.FC<ChatConversationProps> = ({ messages, userName, loading, onFormSubmit, onSuggestionClick }) => {
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  return (
    <Box sx={{ flex: 1, overflowY: 'auto', overflowX: 'hidden', px: { xs: 2, md: 3 }, py: 2, display: 'flex', flexDirection: 'column', gap: 2.5 }}>
      {messages.map((msg) => {
        const isUser = msg.role === 'user';
        return (
          <Box key={msg.id} sx={{ display: 'flex', gap: 1.5, flexDirection: isUser ? 'row-reverse' : 'row', alignItems: 'flex-start', maxWidth: '100%', overflow: 'hidden' }}>
            {/* Avatar */}
            {isUser ? (
              <Avatar sx={{ width: 30, height: 30, bgcolor: '#312e81', fontSize: '0.7rem', fontWeight: 700, color: '#0d9488', flexShrink: 0 }}>
                {userName?.charAt(0)?.toUpperCase() || 'U'}
              </Avatar>
            ) : (
              <Avatar sx={{ width: 30, height: 30, borderRadius: 1.5, flexShrink: 0, p: 0, bgcolor: 'transparent' }} src="/ksplogo.png" alt="KSP" />
            )}

            {/* Bubble */}
            {(() => {
              const isStructured = !isUser && msg.responseType && msg.responseType !== 'text';
              return (
            <Box sx={{
              maxWidth: isUser ? '70%' : (isStructured ? '95%' : '70%'),
              minWidth: 0,
              overflow: 'hidden',
              wordBreak: 'break-word',
              overflowWrap: 'break-word',
              ...(isStructured
                ? { p: 0, borderRadius: 2, color: '#374151' }
                : {
                    px: 2, py: 1.5,
                    borderRadius: isUser ? '16px 16px 4px 16px' : '16px 16px 16px 4px',
                    bgcolor: isUser ? '#312e81' : '#f8f9fa',
                    color: isUser ? '#ffffff' : '#374151',
                    border: isUser ? 'none' : '1px solid #f0ede6',
                  }),
            }}>
              {isUser ? (
                <Typography sx={{ fontSize: '0.85rem', lineHeight: 1.6, whiteSpace: 'pre-wrap', wordBreak: 'break-word', overflowWrap: 'break-word' }}>
                  {msg.content}
                </Typography>
              ) : (
                <ResponseRenderer
                  content={msg.content}
                  responseType={msg.responseType}
                  data={msg.data}
                  onFormSubmit={onFormSubmit}
                  onSuggestionClick={onSuggestionClick}
                />
              )}
            </Box>
              );
            })()}
          </Box>
        );
      })}
      {/* Typing indicator */}
      {loading && (
        <Box sx={{ display: 'flex', gap: 1.5, alignItems: 'flex-start' }}>
          <Avatar sx={{ width: 30, height: 30, borderRadius: 1.5, flexShrink: 0, p: 0, bgcolor: 'transparent' }} src="/ksplogo.png" alt="KSP" />
          <Box sx={{
            px: 2, py: 1.5,
            borderRadius: '16px 16px 16px 4px',
            bgcolor: '#f8f9fa',
            border: '1px solid #f0ede6',
            display: 'flex',
            alignItems: 'center',
            gap: 0.6,
          }}>
            <Box sx={{
              width: 8, height: 8, borderRadius: '50%', bgcolor: '#6b7280',
              animation: `${bounce} 1.4s infinite ease-in-out both`,
              animationDelay: '0s',
            }} />
            <Box sx={{
              width: 8, height: 8, borderRadius: '50%', bgcolor: '#6b7280',
              animation: `${bounce} 1.4s infinite ease-in-out both`,
              animationDelay: '0.16s',
            }} />
            <Box sx={{
              width: 8, height: 8, borderRadius: '50%', bgcolor: '#6b7280',
              animation: `${bounce} 1.4s infinite ease-in-out both`,
              animationDelay: '0.32s',
            }} />
            <Typography sx={{ ml: 1, fontSize: '0.78rem', color: '#9ca3af', fontStyle: 'italic' }}>
              Processing...
            </Typography>
          </Box>
        </Box>
      )}
      <div ref={endRef} />
    </Box>
  );
};

export default ChatConversation;

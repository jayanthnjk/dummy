package com.policescheduler.report.generator;

import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.policescheduler.entity.Personnel;
import com.policescheduler.report.PdfReportGenerator;
import com.policescheduler.report.ReportGenerationException;
import com.policescheduler.report.ReportRequest;
import com.policescheduler.repository.PersonnelRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Complete Personnel List Report - combines both CAR and MT units.
 * Includes: SNo, Name, Designation, DOB, Date of Joining, KGID No, Blood Group,
 * Qualification, Permanent Address, Present Address, Contact No, Native Police Station
 */
@Service
public class CompletePersonnelListPdfGenerator implements PdfReportGenerator {

    private static final Logger log = LoggerFactory.getLogger(CompletePersonnelListPdfGenerator.class);

    // Using same styles as existing PersonnelListReportGenerator
    private static final Color HEADER_BG = new Color(211, 211, 211);
    private static final Font HEADER_FONT = new Font(Font.HELVETICA, 7, Font.BOLD, Color.BLACK);
    private static final Font CELL_FONT = new Font(Font.HELVETICA, 6.5f, Font.NORMAL, Color.BLACK);
    private static final Font TITLE_FONT = new Font(Font.HELVETICA, 12, Font.BOLD, Color.BLACK);
    
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    private static final String REPORT_TITLE = "Complete Personnel List";
    private static final String REPORT_SUBTITLE = "CAR and MT Units Combined";

    // Designation priority order for sorting
    private static final Map<String, Integer> DESIGNATION_PRIORITY = Map.of(
            "DCP", 1,
            "ACP", 2,
            "RPI", 3,
            "RSI", 4,
            "ARSI", 5,
            "AHC", 6,
            "APC", 7
    );

    private final PersonnelRepository personnelRepository;

    public CompletePersonnelListPdfGenerator(PersonnelRepository personnelRepository) {
        this.personnelRepository = personnelRepository;
    }

    @Override
    public String getReportType() {
        return "complete_personnel_list";
    }

    @Override
    public byte[] generate(ReportRequest request) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            // Use landscape A4 for wider table
            Document document = new Document(PageSize.A4.rotate(), 15, 15, 20, 20);
            PdfWriter.getInstance(document, baos);
            document.open();

            // Title
            Paragraph title = new Paragraph(REPORT_TITLE, TITLE_FONT);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);

            // Subtitle
            Font subtitleFont = new Font(Font.HELVETICA, 9, Font.NORMAL, Color.DARK_GRAY);
            Paragraph subtitle = new Paragraph(REPORT_SUBTITLE + " | Generated on " + 
                    LocalDate.now().format(DATE_FORMAT), subtitleFont);
            subtitle.setAlignment(Element.ALIGN_CENTER);
            subtitle.setSpacingAfter(10);
            document.add(subtitle);

            // Fetch all active personnel from both CAR and MT units
            List<Personnel> allPersonnel = personnelRepository.findAll().stream()
                    .filter(p -> Boolean.TRUE.equals(p.getIsActive()))
                    .collect(Collectors.toList());

            // Sort by unit (CAR first, then MT), then by designation priority, then by badge_id
            allPersonnel.sort(Comparator
                    .<Personnel, Integer>comparing(p -> "MT".equalsIgnoreCase(p.getUnit()) ? 1 : 0)
                    .thenComparing(p -> DESIGNATION_PRIORITY.getOrDefault(
                            p.getDesignation() != null ? p.getDesignation().toUpperCase() : "", 99))
                    .thenComparing(p -> p.getBadgeId() != null ? p.getBadgeId() : ""));

            // Table with 12 columns
            int numCols = 12;
            PdfPTable table = new PdfPTable(numCols);
            table.setWidthPercentage(100);
            // SNo, Name, Desig, DOB, DOJ, KGID, Blood, Qual, PermAddr, PresAddr, Contact, NativePS
            table.setWidths(new float[]{4, 12, 6, 8, 8, 8, 5, 10, 13, 13, 8, 10});

            // Column headers - using same style as existing reports
            String[] headers = {
                "S.No", "Name", "Desig", "Date of Birth", "Date of Joining", 
                "KGID No.", "Blood Group", "Qualification", "Permanent Address", 
                "Present Address", "Contact No.", "Native Police Station"
            };
            
            for (String header : headers) {
                PdfPCell headerCell = new PdfPCell(new Phrase(header, HEADER_FONT));
                headerCell.setBackgroundColor(HEADER_BG);
                headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                headerCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                headerCell.setPadding(3);
                table.addCell(headerCell);
            }

            // Data rows
            int slNo = 1;
            for (Personnel p : allPersonnel) {
                table.addCell(createDataCell(String.valueOf(slNo++), Element.ALIGN_CENTER));
                table.addCell(createDataCell(safe(p.getPersonName()), Element.ALIGN_LEFT));
                table.addCell(createDataCell(safe(p.getDesignation()), Element.ALIGN_CENTER));
                table.addCell(createDataCell(formatDate(p.getDateOfBirth()), Element.ALIGN_CENTER));
                table.addCell(createDataCell(formatDate(p.getDateOfJoining()), Element.ALIGN_CENTER));
                table.addCell(createDataCell(safe(p.getBadgeId()), Element.ALIGN_CENTER));
                table.addCell(createDataCell(safe(p.getBloodGroup()), Element.ALIGN_CENTER));
                table.addCell(createWrappedCell(safe(p.getQualification())));
                table.addCell(createWrappedCell(safe(p.getPermanentAddress())));
                table.addCell(createWrappedCell(safe(p.getPresentAddress())));
                table.addCell(createDataCell(safe(p.getPhoneNumber()), Element.ALIGN_CENTER));
                table.addCell(createWrappedCell(safe(p.getNativePoliceStation())));
            }

            if (allPersonnel.isEmpty()) {
                PdfPCell noDataCell = new PdfPCell(new Phrase("No personnel found", CELL_FONT));
                noDataCell.setColspan(numCols);
                noDataCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                noDataCell.setPadding(8);
                table.addCell(noDataCell);
            }

            document.add(table);

            // Add Abstract Table - Count by Designation
            document.add(new Paragraph("\n")); // spacing
            
            Font abstractTitleFont = new Font(Font.HELVETICA, 10, Font.BOLD, Color.BLACK);
            Paragraph abstractTitle = new Paragraph("Abstract - Personnel Count by Designation", abstractTitleFont);
            abstractTitle.setSpacingBefore(10);
            abstractTitle.setSpacingAfter(5);
            document.add(abstractTitle);

            // Calculate counts by designation
            Map<String, Long> designationCounts = allPersonnel.stream()
                    .collect(Collectors.groupingBy(
                            p -> p.getDesignation() != null && !p.getDesignation().isBlank() 
                                    ? p.getDesignation().toUpperCase() : "UNASSIGNED",
                            Collectors.counting()));

            // Create abstract table
            PdfPTable abstractTable = new PdfPTable(2);
            abstractTable.setWidthPercentage(40);
            abstractTable.setHorizontalAlignment(Element.ALIGN_LEFT);
            abstractTable.setWidths(new float[]{60, 40});

            // Abstract table headers
            PdfPCell desigHeaderCell = new PdfPCell(new Phrase("Designation", HEADER_FONT));
            desigHeaderCell.setBackgroundColor(HEADER_BG);
            desigHeaderCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            desigHeaderCell.setPadding(4);
            abstractTable.addCell(desigHeaderCell);

            PdfPCell countHeaderCell = new PdfPCell(new Phrase("Count", HEADER_FONT));
            countHeaderCell.setBackgroundColor(HEADER_BG);
            countHeaderCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            countHeaderCell.setPadding(4);
            abstractTable.addCell(countHeaderCell);

            // Add rows in designation priority order
            String[] designationOrder = {"DCP", "ACP", "RPI", "RSI", "ARSI", "AHC", "APC"};
            long totalCount = 0;
            
            for (String desig : designationOrder) {
                long count = designationCounts.getOrDefault(desig, 0L);
                if (count > 0) {
                    abstractTable.addCell(createDataCell(desig, Element.ALIGN_LEFT));
                    abstractTable.addCell(createDataCell(String.valueOf(count), Element.ALIGN_CENTER));
                    totalCount += count;
                }
            }

            // Add any other designations not in the standard list
            for (Map.Entry<String, Long> entry : designationCounts.entrySet()) {
                String desig = entry.getKey();
                if (!Arrays.asList(designationOrder).contains(desig)) {
                    abstractTable.addCell(createDataCell(desig, Element.ALIGN_LEFT));
                    abstractTable.addCell(createDataCell(String.valueOf(entry.getValue()), Element.ALIGN_CENTER));
                    totalCount += entry.getValue();
                }
            }

            // Total row
            Font totalFont = new Font(Font.HELVETICA, 7, Font.BOLD, Color.BLACK);
            PdfPCell totalLabelCell = new PdfPCell(new Phrase("TOTAL", totalFont));
            totalLabelCell.setBackgroundColor(HEADER_BG);
            totalLabelCell.setHorizontalAlignment(Element.ALIGN_LEFT);
            totalLabelCell.setPadding(4);
            abstractTable.addCell(totalLabelCell);

            PdfPCell totalCountCell = new PdfPCell(new Phrase(String.valueOf(totalCount), totalFont));
            totalCountCell.setBackgroundColor(HEADER_BG);
            totalCountCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            totalCountCell.setPadding(4);
            abstractTable.addCell(totalCountCell);

            document.add(abstractTable);

            document.close();
            return baos.toByteArray();
        } catch (Exception e) {
            log.error("Failed to generate complete personnel list report", e);
            throw new ReportGenerationException("complete_personnel_list",
                    "Failed to generate complete personnel list report", e);
        }
    }

    private PdfPCell createDataCell(String text, int alignment) {
        PdfPCell cell = new PdfPCell(new Phrase(text, CELL_FONT));
        cell.setHorizontalAlignment(alignment);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(2);
        return cell;
    }

    /**
     * Creates a cell with word wrap support for long text
     */
    private PdfPCell createWrappedCell(String text) {
        PdfPCell cell = new PdfPCell(new Phrase(text, CELL_FONT));
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(2);
        cell.setNoWrap(false); // Enable word wrap
        return cell;
    }

    private String formatDate(LocalDate date) {
        if (date == null) return "-";
        return date.format(DATE_FORMAT);
    }

    private String safe(String value) {
        return value != null && !value.isBlank() ? value : "-";
    }
}

package com.policescheduler.repository;

import com.policescheduler.entity.AdhocDutyAssignment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface AdhocDutyAssignmentRepository extends JpaRepository<AdhocDutyAssignment, Long> {
    List<AdhocDutyAssignment> findByAdhocDutyId(Long adhocDutyId);
    List<AdhocDutyAssignment> findByPersonIdAndStatus(Long personId, String status);
    List<AdhocDutyAssignment> findByAdhocDutyIdAndStatus(Long adhocDutyId, String status);

    /**
     * Find adhoc duty assignments for a person on a specific date.
     * Joins with adhoc_duties to filter by date.
     */
    @Query("SELECT ada FROM AdhocDutyAssignment ada " +
           "JOIN AdhocDuty ad ON ada.adhocDutyId = ad.id " +
           "WHERE ada.personId = :personId AND ad.date = :date AND ada.status = 'ASSIGNED'")
    List<AdhocDutyAssignment> findByPersonIdAndDate(@Param("personId") Long personId, @Param("date") LocalDate date);

    /**
     * Find all adhoc duty assignments for a specific date (for batch processing).
     */
    @Query("SELECT ada FROM AdhocDutyAssignment ada " +
           "JOIN AdhocDuty ad ON ada.adhocDutyId = ad.id " +
           "WHERE ad.date = :date AND ada.status = 'ASSIGNED'")
    List<AdhocDutyAssignment> findAllByDate(@Param("date") LocalDate date);
}

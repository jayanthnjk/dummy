# Future Roadmap
## KSP WorkBoard — Planned Enhancements

| Field | Details |
|-------|---------|
| **Version** | 1.0.0 |
| **Date** | June 2026 |
| **Planning Horizon** | 12 months |

---

## 1. Roadmap Overview

```mermaid
gantt
    title KSP WorkBoard Feature Roadmap
    dateFormat YYYY-MM
    section v1.1 (Q3 2026)
    Multi-turn Chat Context     :2026-07, 2026-08
    Leave Balance System        :2026-07, 2026-09
    Auto Cycle Completion       :2026-08, 2026-08
    section v1.2 (Q4 2026)
    Mobile PWA                  :2026-09, 2026-11
    Real-time Notifications     :2026-10, 2026-11
    Attendance Tracking         :2026-10, 2026-12
    section v2.0 (Q1 2027)
    Multi-Station Support       :2026-12, 2027-02
    Advanced Analytics          :2027-01, 2027-03
    Duty Swap Workflow          :2027-01, 2027-02
```

---

## 2. Version 1.1 — Planned (Q3 2026)

### 2.1 Multi-Turn Chat Context
- **Priority:** High
- **Description:** Pass sliding window of last 5 messages to LLM for contextual understanding
- **Benefit:** Users can say "show their leave details" after asking about a person
- **Effort:** Medium (modify FunctionCallingService to include history)

### 2.2 Leave Balance System
- **Priority:** High
- **Description:** Track leave quotas per type per financial year; prevent over-utilization
- **Benefit:** Automated leave balance enforcement, no manual checking
- **Effort:** High (new tables: leave_balances, leave_policies)

### 2.3 Auto Cycle Completion
- **Priority:** Medium
- **Description:** Scheduled job to mark cycles as COMPLETED when end_date passes
- **Benefit:** Automatic lifecycle management without manual intervention
- **Effort:** Low (add @Scheduled method in CycleService)

### 2.4 Database Migrations (Flyway)
- **Priority:** Medium
- **Description:** Replace manual DDL with versioned Flyway migrations
- **Benefit:** Safe, repeatable schema changes across environments
- **Effort:** Medium (create V1__initial_schema.sql from existing)

### 2.5 Chat History UI
- **Priority:** Low
- **Description:** Add page to browse/search past chat conversations
- **Benefit:** Officers can reference previous queries
- **Effort:** Low (new page + existing data)

---

## 3. Version 1.2 — Planned (Q4 2026)

### 3.1 Progressive Web App (PWA)
- **Priority:** High
- **Description:** Add service worker, manifest, offline-capable shell
- **Benefit:** Install on mobile home screen, faster load, basic offline mode
- **Effort:** Medium (Vite PWA plugin)

### 3.2 Real-Time Notifications (WebSocket)
- **Priority:** High
- **Description:** Push notifications for leave approvals, duty reassignments, cycle changes
- **Benefit:** Officers notified instantly without refreshing
- **Effort:** High (Spring WebSocket + frontend subscription)

### 3.3 Attendance Check-In/Check-Out
- **Priority:** Medium
- **Description:** Officers mark attendance via mobile; geofence validation against duty type location
- **Benefit:** Actual vs assigned duty tracking, accountability
- **Effort:** High (new module, GPS integration)

### 3.4 Advanced Report Templates
- **Priority:** Medium
- **Description:** Customizable report templates, header/footer branding, official letterhead
- **Benefit:** Professional reports matching station's official format
- **Effort:** Medium (template engine)

### 3.5 Bulk Personnel Import
- **Priority:** Medium
- **Description:** CSV/Excel upload for bulk personnel onboarding
- **Benefit:** Saves hours during initial setup or transfers
- **Effort:** Medium (file parsing + validation)

---

## 4. Version 2.0 — Planned (Q1 2027)

### 4.1 Multi-Station Deployment
- **Priority:** High
- **Description:** Support multiple police stations with district-level aggregation
- **Benefit:** Scale to entire district, cross-station transfers
- **Effort:** Very High (multi-tenancy, data isolation, shared reporting)

### 4.2 Advanced Analytics Dashboard
- **Priority:** Medium
- **Description:** Graphical dashboards with charts: leave trends, duty distribution, personnel strength over time
- **Benefit:** Data-driven decision making for station leadership
- **Effort:** High (chart library, aggregation queries)

### 4.3 Duty Swap Workflow
- **Priority:** Medium
- **Description:** Officers request to swap duties with each other; supervisor approves
- **Benefit:** Flexibility, reduced reassignment workload for admins
- **Effort:** Medium (new swap_requests table, approval workflow)

### 4.4 Hindi Language Support
- **Priority:** Low
- **Description:** Full Hindi translation for UI and chat responses
- **Benefit:** Wider accessibility for Hindi-speaking officers
- **Effort:** Medium (translation work + chat response formatting)

### 4.5 API Rate Limiting (Redis-based)
- **Priority:** Medium
- **Description:** Migrate from in-memory rate limiting to Redis for multi-instance support
- **Benefit:** Consistent rate limiting across multiple EC2 instances
- **Effort:** Low-Medium (Redis client + sliding window algorithm)

---

## 5. Backlog (Unscheduled)

| # | Feature | Priority | Effort | Notes |
|---|---------|----------|--------|-------|
| BK-01 | Two-factor authentication (TOTP) | Medium | Medium | For admin accounts |
| BK-02 | Email/SMS notifications | Low | Medium | Requires SMTP/SMS gateway |
| BK-03 | Biometric integration | Low | High | Hardware dependency |
| BK-04 | CCTNS integration | Low | High | External govt system |
| BK-05 | Mobile native app (React Native) | Low | Very High | PWA may suffice |
| BK-06 | Configurable platoon count | Low | Medium | Currently hard-coded to 5 |
| BK-07 | Password complexity enforcement | Medium | Low | Regex validation |
| BK-08 | Login attempt audit log | Medium | Low | New table + filter |
| BK-09 | Automated backup scheduling | Medium | Low | Cron job |
| BK-10 | Dark mode (backend themes) | Low | Low | Frontend only change |
| BK-11 | Document search (RAG improvements) | Medium | Medium | Better chunking + retrieval |
| BK-12 | Export chat history to PDF | Low | Low | Chat messages report |
| BK-13 | Webhook integrations | Low | Medium | External system notifications |
| BK-14 | Load testing & benchmarking | Medium | Low | k6 or JMeter scripts |
| BK-15 | Accessibility (WCAG 2.1) | Medium | Medium | MUI aria improvements |

---

## 6. Technical Debt

| # | Item | Priority | Effort | Impact if Ignored |
|---|------|----------|--------|-------------------|
| TD-01 | Add Flyway migrations | High | Medium | Manual schema management becomes error-prone |
| TD-02 | Add OpenAPI/Swagger documentation | Medium | Low | API discovery depends on this document |
| TD-03 | Increase test coverage to 80%+ | Medium | High | Regressions in critical paths |
| TD-04 | Add request/response logging middleware | Low | Low | Debugging production issues harder |
| TD-05 | Refactor DomainDbMcpServer (too large) | Medium | Medium | Maintenance difficulty grows |
| TD-06 | Add connection pool monitoring | Low | Low | Connection leaks undetected |
| TD-07 | Migrate to Spring Boot 3.5+ | Low | Low | Stay current with security patches |

---

*End of Document — Future Roadmap v1.0.0*

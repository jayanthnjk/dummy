package com.policescheduler.service;

import com.policescheduler.entity.*;
import com.policescheduler.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Scheduled service for:
 * 1. Marking expired cycles as COMPLETED (runs daily at 1:00 AM)
 * 2. Archiving completed cycle assignments (runs daily at 2:00 AM)
 * 3. Capturing daily duty history snapshots (runs daily at 11:30 PM)
 */
@Service
public class DutyHistorySchedulerService {

    private static final Logger log = LoggerFactory.getLogger(DutyHistorySchedulerService.class);

    /** Identifier for the duty history snapshot scheduler - used to distinguish from other callers */
    public static final String DUTY_HISTORY_SNAPSHOT_SCHEDULER = "DUTY_HISTORY_SNAPSHOT_SCHEDULER";

    private final ScheduleCycleRepository scheduleCycleRepository;
    private final CycleDutyAssignmentRepository cycleDutyAssignmentRepository;
    private final ArchivedCycleDutyAssignmentRepository archivedCycleDutyAssignmentRepository;
    private final PersonnelRepository personnelRepository;
    private final AdhocDutyRepository adhocDutyRepository;
    private final AdhocDutyAssignmentRepository adhocDutyAssignmentRepository;
    private final LeaveRequestRepository leaveRequestRepository;
    private final DutyHistoryRepository dutyHistoryRepository;
    private final CycleAuditService cycleAuditService;

    public DutyHistorySchedulerService(
            ScheduleCycleRepository scheduleCycleRepository,
            CycleDutyAssignmentRepository cycleDutyAssignmentRepository,
            ArchivedCycleDutyAssignmentRepository archivedCycleDutyAssignmentRepository,
            PersonnelRepository personnelRepository,
            AdhocDutyRepository adhocDutyRepository,
            AdhocDutyAssignmentRepository adhocDutyAssignmentRepository,
            LeaveRequestRepository leaveRequestRepository,
            DutyHistoryRepository dutyHistoryRepository,
            CycleAuditService cycleAuditService) {
        this.scheduleCycleRepository = scheduleCycleRepository;
        this.cycleDutyAssignmentRepository = cycleDutyAssignmentRepository;
        this.archivedCycleDutyAssignmentRepository = archivedCycleDutyAssignmentRepository;
        this.personnelRepository = personnelRepository;
        this.adhocDutyRepository = adhocDutyRepository;
        this.adhocDutyAssignmentRepository = adhocDutyAssignmentRepository;
        this.leaveRequestRepository = leaveRequestRepository;
        this.dutyHistoryRepository = dutyHistoryRepository;
        this.cycleAuditService = cycleAuditService;
    }

    // =========================================================================
    // SCHEDULER 1: Mark Expired Cycles as COMPLETED (Runs daily at 1:00 AM)
    // =========================================================================

    /**
     * Marks all ACTIVE cycles whose end date has passed as COMPLETED.
     * Runs daily at 1:00 AM.
     */
    @Scheduled(cron = "0 0 1 * * ?")
    public void markExpiredCyclesAsCompleted() {
        log.info("Starting scheduled job: markExpiredCyclesAsCompleted");

        try {
            LocalDate today = LocalDate.now();
            List<ScheduleCycle> expiredCycles = scheduleCycleRepository.findExpiredActiveCycles(today);

            if (expiredCycles.isEmpty()) {
                log.info("No expired cycles found");
                return;
            }

            int completedCount = 0;
            for (ScheduleCycle cycle : expiredCycles) {
                try {
                    markSingleCycleAsCompleted(cycle);
                    completedCount++;
                    log.info("Marked cycle #{} as COMPLETED (end date: {})", cycle.getId(), cycle.getEndDate());
                } catch (Exception e) {
                    log.error("Failed to mark cycle #{} as COMPLETED: {}", cycle.getId(), e.getMessage(), e);
                }
            }

            log.info("Completed markExpiredCyclesAsCompleted: {} cycles marked as COMPLETED", completedCount);
        } catch (Exception e) {
            log.error("markExpiredCyclesAsCompleted job failed: {}", e.getMessage(), e);
        }
    }

    @Transactional
    protected void markSingleCycleAsCompleted(ScheduleCycle cycle) {
        String oldStatus = cycle.getStatus();
        cycle.setStatus("COMPLETED");
        scheduleCycleRepository.save(cycle);

        cycleAuditService.log(cycle.getId(), "CYCLE_AUTO_COMPLETED",
                "Cycle automatically marked as COMPLETED by scheduler (end date: " + cycle.getEndDate() + ")",
                "status=" + oldStatus, "status=COMPLETED");
    }

    // =========================================================================
    // SCHEDULER 2: Archive Completed Cycle Assignments (Runs daily at 2:00 AM)
    // =========================================================================

    /**
     * Moves cycle_duty_assignments for COMPLETED cycles to archived_cycle_duty_assignments.
     * After archiving, deletes the records from the original table.
     * Runs daily at 2:00 AM (after cycle completion job at 1:00 AM).
     */
    @Scheduled(cron = "0 0 2 * * ?")
    public void archiveCompletedCycleAssignments() {
        log.info("Starting scheduled job: archiveCompletedCycleAssignments");

        try {
            // Get all COMPLETED cycles
            List<ScheduleCycle> completedCycles = scheduleCycleRepository.findByStatus("COMPLETED");

            if (completedCycles.isEmpty()) {
                log.info("No completed cycles found to archive");
                return;
            }

            int totalArchived = 0;
            int cyclesProcessed = 0;

            for (ScheduleCycle cycle : completedCycles) {
                try {
                    int archivedCount = archiveCycleAssignments(cycle.getId());
                    if (archivedCount > 0) {
                        totalArchived += archivedCount;
                        cyclesProcessed++;
                        log.info("Archived {} assignments for cycle #{}", archivedCount, cycle.getId());
                    }
                } catch (Exception e) {
                    log.error("Failed to archive cycle #{}: {}", cycle.getId(), e.getMessage(), e);
                }
            }

            log.info("Completed archiveCompletedCycleAssignments: {} records archived from {} cycles", 
                     totalArchived, cyclesProcessed);
        } catch (Exception e) {
            log.error("archiveCompletedCycleAssignments job failed: {}", e.getMessage(), e);
        }
    }

    /**
     * Archives all assignments for a specific cycle.
     * 
     * @param cycleId The cycle ID to archive
     * @return Number of records archived
     */
    @Transactional
    public int archiveCycleAssignments(Long cycleId) {
        // Check if already archived
        if (archivedCycleDutyAssignmentRepository.existsByCycleId(cycleId)) {
            log.info("Cycle #{} already archived, skipping", cycleId);
            return 0;
        }

        // Get all assignments for this cycle
        List<CycleDutyAssignment> assignments = cycleDutyAssignmentRepository.findByCycleId(cycleId);

        if (assignments.isEmpty()) {
            log.info("No assignments found for cycle #{}", cycleId);
            return 0;
        }

        // Convert to archived entities
        List<ArchivedCycleDutyAssignment> archivedRecords = assignments.stream()
                .map(ArchivedCycleDutyAssignment::fromCycleDutyAssignment)
                .collect(Collectors.toList());

        // Save to archive table
        archivedCycleDutyAssignmentRepository.saveAll(archivedRecords);

        // Delete from original table
        cycleDutyAssignmentRepository.deleteByCycleId(cycleId);

        // Audit log
        cycleAuditService.log(cycleId, "CYCLE_ARCHIVED",
                "Archived " + assignments.size() + " duty assignments to archive table",
                null, null);

        return assignments.size();
    }

    // =========================================================================
    // SCHEDULER 3: Capture Daily Duty History Snapshot (Runs daily at 11:30 PM)
    // =========================================================================

    /**
     * Captures a snapshot of all personnel's duty status for the current day.
     * Stores records in duty_history table for historical queries.
     * Runs daily at 11:30 PM.
     */
    @Scheduled(cron = "0 30 23 * * ?")
    public void captureDailyDutyHistorySnapshot() {
        log.info("Starting scheduled job: captureDailyDutyHistorySnapshot");

        LocalDate today = LocalDate.now();

        try {
            int recordsCreated = captureDutyHistoryForDate(today);
            log.info("Completed captureDailyDutyHistorySnapshot: {} records created for date {}", 
                     recordsCreated, today);
        } catch (Exception e) {
            log.error("captureDailyDutyHistorySnapshot job failed for {}: {}", today, e.getMessage(), e);
        }
    }

    /**
     * Captures duty history for a specific date.
     * Can be called manually or by scheduler.
     * 
     * @param date The date to capture history for
     * @return Number of records created
     */
    @Transactional
    public int captureDutyHistoryForDate(LocalDate date) {
        log.info("Capturing duty history for date: {}", date);

        // 1. Get all active personnel
        List<Personnel> allPersonnel = personnelRepository.findByIsActiveTrue();
        if (allPersonnel.isEmpty()) {
            log.warn("No active personnel found");
            return 0;
        }

        // 2. Build lookup maps for efficient processing
        Map<Long, Personnel> personnelMap = allPersonnel.stream()
                .collect(Collectors.toMap(Personnel::getId, p -> p));

        // 3. Get cycle duty assignments for today
        Map<Long, CycleDutyAssignment> cycleAssignmentsByPerson = getCycleAssignmentsForDate(date);

        // 4. Get adhoc duty assignments for today
        Map<Long, AdhocDutyInfo> adhocDutiesByPerson = getAdhocDutiesForDate(date);

        // 5. Get approved leaves for today
        Map<Long, String> leavesByPerson = getLeavesForDate(date);

        // 6. Create duty history records
        List<DutyHistory> historyRecords = new ArrayList<>();
        
        for (Personnel person : allPersonnel) {
            DutyHistory history = createDutyHistoryRecord(
                    person, date, 
                    cycleAssignmentsByPerson.get(person.getId()),
                    adhocDutiesByPerson.get(person.getId()),
                    leavesByPerson.get(person.getId()));
            historyRecords.add(history);
        }

        // 7. Save all records (simple insert - no duplicate check needed)
        int savedCount = 0;
        for (DutyHistory record : historyRecords) {
            try {
                dutyHistoryRepository.save(record);
                savedCount++;
            } catch (Exception e) {
                log.error("Failed to save duty history for person {}: {}", 
                         record.getPersonId(), e.getMessage());
            }
        }

        log.info("Saved {} duty history records for date {}", savedCount, date);
        return savedCount;
    }

    /**
     * Get cycle duty assignments for a specific date, mapped by person ID.
     */
    private Map<Long, CycleDutyAssignment> getCycleAssignmentsForDate(LocalDate date) {
        // Find active cycle for this date
        List<ScheduleCycle> activeCycles = scheduleCycleRepository.findActiveCycleForDate(date);
        
        if (activeCycles.isEmpty()) {
            log.info("No active cycle found for date {}", date);
            return Collections.emptyMap();
        }

        ScheduleCycle cycle = activeCycles.get(0);
        List<CycleDutyAssignment> assignments = cycleDutyAssignmentRepository
                .findByCycleIdAndDate(cycle.getId(), date);

        return assignments.stream()
                .collect(Collectors.toMap(
                        CycleDutyAssignment::getPersonId,
                        a -> a,
                        (a1, a2) -> a1  // Keep first if duplicate
                ));
    }

    /**
     * Get adhoc duty assignments for a specific date, mapped by person ID.
     */
    private Map<Long, AdhocDutyInfo> getAdhocDutiesForDate(LocalDate date) {
        List<AdhocDutyAssignment> adhocAssignments = adhocDutyAssignmentRepository.findAllByDate(date);
        
        if (adhocAssignments.isEmpty()) {
            return Collections.emptyMap();
        }

        // Get adhoc duty details
        Set<Long> adhocDutyIds = adhocAssignments.stream()
                .map(AdhocDutyAssignment::getAdhocDutyId)
                .collect(Collectors.toSet());
        
        Map<Long, AdhocDuty> adhocDutyMap = adhocDutyRepository.findAllById(adhocDutyIds).stream()
                .collect(Collectors.toMap(AdhocDuty::getId, ad -> ad));

        Map<Long, AdhocDutyInfo> result = new HashMap<>();
        for (AdhocDutyAssignment assignment : adhocAssignments) {
            AdhocDuty duty = adhocDutyMap.get(assignment.getAdhocDutyId());
            if (duty != null) {
                result.put(assignment.getPersonId(), new AdhocDutyInfo(duty.getDutyName(), duty.getLocation()));
            }
        }

        return result;
    }

    /**
     * Get approved leaves for a specific date, mapped by person ID to leave type.
     */
    private Map<Long, String> getLeavesForDate(LocalDate date) {
        List<LeaveRequest> leaves = leaveRequestRepository.findAllApprovedLeavesForDate(date);
        
        return leaves.stream()
                .collect(Collectors.toMap(
                        LeaveRequest::getPersonnelId,
                        LeaveRequest::getLeaveType,
                        (l1, l2) -> l1  // Keep first if duplicate
                ));
    }

    /**
     * Create a DutyHistory record from personnel and their assignments.
     */
    private DutyHistory createDutyHistoryRecord(
            Personnel person,
            LocalDate date,
            CycleDutyAssignment cycleAssignment,
            AdhocDutyInfo adhocDuty,
            String leaveType) {

        DutyHistory history = new DutyHistory();
        history.setPersonId(person.getId());
        history.setBadgeId(person.getBadgeId());
        history.setPersonName(person.getPersonName());
        history.setDesignation(person.getDesignation());
        history.setRecordDate(date);
        history.setSection(person.getSection());
        history.setWorksAt(person.getLocation());  // location column

        // Set duty type and location from personnel (base assignment)
        history.setDutyType(person.getDutyType());
        history.setDutyLocation(person.getDutyLocation());

        // Override with cycle assignment if available
        if (cycleAssignment != null) {
            if (cycleAssignment.getDutyType() != null) {
                history.setDutyType(cycleAssignment.getDutyType());
            }
            if (cycleAssignment.getDutyLocationField() != null) {
                history.setDutyLocation(cycleAssignment.getDutyLocationField());
            }
            history.setShiftType(cycleAssignment.getShiftType());
            history.setStatus(cycleAssignment.getStatus() != null ? cycleAssignment.getStatus() : "ACTIVE");
        }

        // Set adhoc duty if assigned
        if (adhocDuty != null) {
            history.setAdhocDuty(adhocDuty.dutyName);
            history.setStatus("ADHOC");
        }

        // Set leave type if on leave
        if (leaveType != null) {
            history.setLeaveType(leaveType);
            history.setStatus("ON_LEAVE");
        }

        // Default status if not set
        if (history.getStatus() == null) {
            history.setStatus("ACTIVE");
        }

        return history;
    }

    /**
     * Helper class to hold adhoc duty information.
     */
    private static class AdhocDutyInfo {
        final String dutyName;
        final String location;

        AdhocDutyInfo(String dutyName, String location) {
            this.dutyName = dutyName;
            this.location = location;
        }
    }

    // =========================================================================
    // MANUAL TRIGGER METHODS (for testing/admin purposes)
    // =========================================================================

    /**
     * Manually trigger cycle completion check.
     * Can be called via API for testing.
     */
    public int manuallyCheckAndCompleteCycles() {
        log.info("Manual trigger: checkAndCompleteCycles");
        
        LocalDate today = LocalDate.now();
        List<ScheduleCycle> expiredCycles = scheduleCycleRepository.findExpiredActiveCycles(today);

        int completedCount = 0;
        for (ScheduleCycle cycle : expiredCycles) {
            cycle.setStatus("COMPLETED");
            scheduleCycleRepository.save(cycle);
            cycleAuditService.log(cycle.getId(), "CYCLE_MANUAL_COMPLETED",
                    "Cycle manually marked as COMPLETED (end date: " + cycle.getEndDate() + ")",
                    null, null);
            completedCount++;
        }

        return completedCount;
    }

    /**
     * Manually trigger duty history capture for a specific date.
     * Can be called via API for testing or backfilling.
     */
    public int manuallyCaptureDutyHistory(LocalDate date) {
        log.info("Manual trigger: captureDutyHistory for date {}", date);
        return captureDutyHistoryForDate(date);
    }

    /**
     * Manually trigger archive for a specific cycle.
     * Can be called via API for testing.
     */
    public int manuallyArchiveCycle(Long cycleId) {
        log.info("Manual trigger: archiveCycle for cycle #{}", cycleId);
        return archiveCycleAssignments(cycleId);
    }

    /**
     * Manually trigger archive for all completed cycles.
     * Can be called via API for testing.
     */
    public Map<String, Object> manuallyArchiveAllCompletedCycles() {
        log.info("Manual trigger: archiveAllCompletedCycles");
        
        List<ScheduleCycle> completedCycles = scheduleCycleRepository.findByStatus("COMPLETED");
        
        int totalArchived = 0;
        int cyclesProcessed = 0;
        
        for (ScheduleCycle cycle : completedCycles) {
            int archived = archiveCycleAssignments(cycle.getId());
            if (archived > 0) {
                totalArchived += archived;
                cyclesProcessed++;
            }
        }
        
        return Map.of(
                "cyclesProcessed", cyclesProcessed,
                "totalRecordsArchived", totalArchived
        );
    }
}

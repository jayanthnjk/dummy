import { describe, it, expect } from 'vitest';
import {
  getWeekRange,
  getDayRange,
  getMonthRange,
  navigateNext,
  navigatePrev,
  navigateToday,
  getDayColumns,
  formatDateRangeLabel,
} from '../dateNavigation';

describe('getWeekRange', () => {
  it('returns Monday-Sunday range for a Wednesday', () => {
    const wednesday = new Date(2026, 5, 17); // June 17, 2026 (Wednesday)
    const range = getWeekRange(wednesday);
    expect(range.start).toBe('2026-06-15'); // Monday
    expect(range.end).toBe('2026-06-21');   // Sunday
  });

  it('returns Monday-Sunday range for a Monday', () => {
    const monday = new Date(2026, 5, 15); // June 15, 2026 (Monday)
    const range = getWeekRange(monday);
    expect(range.start).toBe('2026-06-15');
    expect(range.end).toBe('2026-06-21');
  });

  it('returns Monday-Sunday range for a Sunday', () => {
    const sunday = new Date(2026, 5, 21); // June 21, 2026 (Sunday)
    const range = getWeekRange(sunday);
    expect(range.start).toBe('2026-06-15');
    expect(range.end).toBe('2026-06-21');
  });

  it('handles month boundaries correctly', () => {
    const thursday = new Date(2026, 0, 1); // January 1, 2026 (Thursday)
    const range = getWeekRange(thursday);
    expect(range.start).toBe('2025-12-29'); // Monday of that week
    expect(range.end).toBe('2026-01-04');   // Sunday
  });
});

describe('getDayRange', () => {
  it('returns same start and end for a single day', () => {
    const date = new Date(2026, 5, 15);
    const range = getDayRange(date);
    expect(range.start).toBe('2026-06-15');
    expect(range.end).toBe('2026-06-15');
  });
});

describe('getMonthRange', () => {
  it('returns first to last day of the month', () => {
    const date = new Date(2026, 5, 15); // June 15, 2026
    const range = getMonthRange(date);
    expect(range.start).toBe('2026-06-01');
    expect(range.end).toBe('2026-06-30');
  });

  it('handles February correctly in a non-leap year', () => {
    const date = new Date(2025, 1, 10); // February 10, 2025
    const range = getMonthRange(date);
    expect(range.start).toBe('2025-02-01');
    expect(range.end).toBe('2025-02-28');
  });

  it('handles February correctly in a leap year', () => {
    const date = new Date(2024, 1, 10); // February 10, 2024 (leap year)
    const range = getMonthRange(date);
    expect(range.start).toBe('2024-02-01');
    expect(range.end).toBe('2024-02-29');
  });
});

describe('navigateNext', () => {
  it('advances by 1 day in day mode', () => {
    const date = new Date(2026, 5, 15);
    const result = navigateNext(date, 'day');
    expect(result.getFullYear()).toBe(2026);
    expect(result.getMonth()).toBe(5);
    expect(result.getDate()).toBe(16);
  });

  it('advances by 7 days in week mode', () => {
    const date = new Date(2026, 5, 15);
    const result = navigateNext(date, 'week');
    expect(result.getFullYear()).toBe(2026);
    expect(result.getMonth()).toBe(5);
    expect(result.getDate()).toBe(22);
  });

  it('advances by 1 month in month mode', () => {
    const date = new Date(2026, 5, 15);
    const result = navigateNext(date, 'month');
    expect(result.getFullYear()).toBe(2026);
    expect(result.getMonth()).toBe(6);
    expect(result.getDate()).toBe(15);
  });

  it('handles month boundary crossing in day mode', () => {
    const date = new Date(2026, 5, 30); // June 30
    const result = navigateNext(date, 'day');
    expect(result.getMonth()).toBe(6); // July
    expect(result.getDate()).toBe(1);
  });
});

describe('navigatePrev', () => {
  it('goes back by 1 day in day mode', () => {
    const date = new Date(2026, 5, 15);
    const result = navigatePrev(date, 'day');
    expect(result.getDate()).toBe(14);
  });

  it('goes back by 7 days in week mode', () => {
    const date = new Date(2026, 5, 15);
    const result = navigatePrev(date, 'week');
    expect(result.getDate()).toBe(8);
  });

  it('goes back by 1 month in month mode', () => {
    const date = new Date(2026, 5, 15);
    const result = navigatePrev(date, 'month');
    expect(result.getMonth()).toBe(4); // May
    expect(result.getDate()).toBe(15);
  });
});

describe('navigateToday', () => {
  it('returns a Date object representing today', () => {
    const today = new Date();
    const result = navigateToday();
    expect(result.getFullYear()).toBe(today.getFullYear());
    expect(result.getMonth()).toBe(today.getMonth());
    expect(result.getDate()).toBe(today.getDate());
  });
});

describe('getDayColumns', () => {
  it('returns 1 column in day mode', () => {
    const range = { start: '2026-06-15', end: '2026-06-15', label: '' };
    const columns = getDayColumns(range, 'day');
    expect(columns).toHaveLength(1);
    expect(columns[0].dayName).toBe('Mon');
    expect(columns[0].date).toBe('2026-06-15');
  });

  it('returns 7 columns in week mode', () => {
    const range = { start: '2026-06-15', end: '2026-06-21', label: '' };
    const columns = getDayColumns(range, 'week');
    expect(columns).toHaveLength(7);
    expect(columns[0].dayName).toBe('Mon');
    expect(columns[0].date).toBe('2026-06-15');
    expect(columns[6].dayName).toBe('Sun');
    expect(columns[6].date).toBe('2026-06-21');
  });

  it('returns correct number of days in month mode', () => {
    const range = { start: '2026-06-01', end: '2026-06-30', label: '' };
    const columns = getDayColumns(range, 'month');
    expect(columns).toHaveLength(30);
  });

  it('returns 28 days for February in a non-leap year', () => {
    const range = { start: '2025-02-01', end: '2025-02-28', label: '' };
    const columns = getDayColumns(range, 'month');
    expect(columns).toHaveLength(28);
  });

  it('returns 29 days for February in a leap year', () => {
    const range = { start: '2024-02-01', end: '2024-02-29', label: '' };
    const columns = getDayColumns(range, 'month');
    expect(columns).toHaveLength(29);
  });
});

describe('formatDateRangeLabel', () => {
  it('formats same day range', () => {
    const label = formatDateRangeLabel({ start: '2026-06-15', end: '2026-06-15', label: '' });
    expect(label).toBe('Jun 15, 2026');
  });

  it('formats same month range', () => {
    const label = formatDateRangeLabel({ start: '2026-06-15', end: '2026-06-21', label: '' });
    expect(label).toBe('Jun 15 - 21, 2026');
  });

  it('formats different months same year range', () => {
    const label = formatDateRangeLabel({ start: '2026-06-28', end: '2026-07-04', label: '' });
    expect(label).toBe('Jun 28 - Jul 4, 2026');
  });

  it('formats different years range', () => {
    const label = formatDateRangeLabel({ start: '2025-12-29', end: '2026-01-04', label: '' });
    expect(label).toBe('Dec 29, 2025 - Jan 4, 2026');
  });
});

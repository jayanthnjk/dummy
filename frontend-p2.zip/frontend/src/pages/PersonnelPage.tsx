import React, { useEffect, useState } from 'react';
import {
  Box, Typography, Button, Alert, Skeleton,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import PeopleIcon from '@mui/icons-material/People';
import PersonIcon from '@mui/icons-material/Person';
import EventBusyIcon from '@mui/icons-material/EventBusy';

import { useTranslation } from 'react-i18next';
import DataTable, { type Column } from '@/components/DataTable';
import PageHeader from '@/components/common/PageHeader';
import DisplayCard from '@/components/common/DisplayCard';
import StatusBadge from '@/components/common/StatusBadge';
import { personnelService } from '@/services/personnelService';
import { sectionService } from '@/services/sectionService';
import type { PersonnelDto } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

const PersonnelPage: React.FC = () => {
  const { t } = useTranslation();
  const { role } = useAuth();
  const navigate = useNavigate();
  const [data, setData] = useState<PersonnelDto[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [sectionCodes, setSectionCodes] = useState<string[]>([]);

  const canEdit = role === 'ADMIN' || role === 'HIGHER_OFFICER';

  const fetchData = async () => {
    setLoading(true);
    try {
      const [result, sections] = await Promise.all([
        personnelService.list(undefined, 0, 500),
        sectionService.list(),
      ]);
      setData(result.content);
      setSectionCodes(sections.map(s => s.code));
    } catch {
      setError(t('app.error'));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const columns: Column<PersonnelDto>[] = [
    { id: 'badgeId', labelKey: 'personnel.badgeId', filterable: true, width: 100 },
    {
      id: 'personName', labelKey: 'personnel.personName', filterable: true, minWidth: 180,
      render: (row) => (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.2 }}>
          <Box
            component="img"
            src="/police-avatar.svg"
            alt=""
            sx={{
              width: 32, height: 32, borderRadius: '50%',
              flexShrink: 0,
            }}
          />
          <Box>
            <Typography sx={{ fontSize: '0.85rem', fontWeight: 500, color: '#111827', lineHeight: 1.2 }}>{row.personName}</Typography>
            {row.email && <Typography sx={{ fontSize: '0.72rem', color: '#9ca3af' }}>{row.email}</Typography>}
          </Box>
        </Box>
      ),
    },
    {
      id: 'designation', labelKey: 'personnel.designation', filterable: true,
      filterType: 'select', filterOptions: ['DCP', 'ACP', 'RPI', 'RSI', 'ARSI', 'AHC', 'APC'],
      render: (row) => row.designation ? (
        <Box sx={{
          display: 'inline-block', px: 1.2, py: 0.3, borderRadius: 1,
          bgcolor: row.designation === 'DCP' || row.designation === 'ACP' ? '#ede9fe' :
                   row.designation === 'RSI' || row.designation === 'RPI' ? '#dbeafe' : '#f0fdf4',
          color: row.designation === 'DCP' || row.designation === 'ACP' ? '#6d28d9' :
                 row.designation === 'RSI' || row.designation === 'RPI' ? '#1d4ed8' : '#166534',
          fontSize: '0.75rem', fontWeight: 600,
        }}>
          {row.designation}
        </Box>
      ) : null,
    },
    { id: 'dutyType', labelKey: 'personnel.dutyType', filterable: true },
    {
      id: 'section', labelKey: 'personnel.section', filterable: true,
      filterType: 'select', filterOptions: sectionCodes,
    },
    { id: 'location', labelKey: 'personnel.location' },
    {
      id: 'isActive', labelKey: 'personnel.active',
      render: (row) => (
        <StatusBadge
          status={row.isActive ? 'Active' : 'On Leave'}
          size="small"
          showDot
        />
      ),
    },
  ];

  const totalCount = data.length;
  const activeCount = data.filter(p => p.isActive).length;
  const onLeaveCount = data.filter(p => !p.isActive).length;

  const breadcrumbs = [
    { label: 'Home', path: '/' },
    { label: 'Personnel' },
  ];

  const actions = canEdit
    ? [
        {
          label: t('personnel.addPerson'),
          variant: 'primary' as const,
          icon: <AddIcon />,
          onClick: () => navigate('/personnel/add'),
        },
      ]
    : undefined;

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', bgcolor: 'background.default' }}>
      {/* PageHeader replaces gradient banner */}
      <PageHeader
        title={t('personnel.title')}
        breadcrumbs={breadcrumbs}
        actions={actions}
      />

      {/* Main Content */}
      <Box sx={{ flex: 1, p: 3 }}>
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

        {/* Summary Metric Cards */}
        <Box sx={{
          display: 'grid',
          gridTemplateColumns: { xs: '1fr', sm: 'repeat(3, 1fr)' },
          gap: 2,
          mb: 3,
        }}>
          <DisplayCard
            loading={loading}
            icon={<PeopleIcon sx={{ color: '#312e81', fontSize: 24 }} />}
            metric={{
              value: totalCount,
              label: t('personnel.total', 'Total Personnel'),
            }}
            staggerIndex={0}
          />
          <DisplayCard
            loading={loading}
            icon={<PersonIcon sx={{ color: '#059669', fontSize: 24 }} />}
            metric={{
              value: activeCount,
              label: t('personnel.activeCount', 'Active'),
            }}
            staggerIndex={1}
          />
          <DisplayCard
            loading={loading}
            icon={<EventBusyIcon sx={{ color: '#d97706', fontSize: 24 }} />}
            metric={{
              value: onLeaveCount,
              label: t('personnel.onLeaveCount', 'On Leave'),
            }}
            staggerIndex={2}
          />
        </Box>

        {/* Data Table with skeleton loading and empty state */}
        {loading ? (
          <Box>
            {/* Table skeleton */}
            <Skeleton variant="rectangular" width="100%" height={48} sx={{ borderRadius: 2, mb: 1 }} />
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} variant="rectangular" width="100%" height={40} sx={{ borderRadius: 1, mb: 0.5 }} />
            ))}
          </Box>
        ) : data.length === 0 ? (
          <Box sx={{
            display: 'flex', flexDirection: 'column', alignItems: 'center',
            justifyContent: 'center', py: 8, color: '#9ca3af',
          }}>
            <PeopleIcon sx={{ fontSize: 48, mb: 2, opacity: 0.5 }} />
            <Typography sx={{ fontSize: '1rem', fontWeight: 500 }}>
              {t('personnel.noRecords', 'No personnel records found')}
            </Typography>
            <Typography sx={{ fontSize: '0.85rem', mt: 0.5, color: '#b0b0b0' }}>
              {t('personnel.noRecordsHint', 'Add personnel to get started')}
            </Typography>
          </Box>
        ) : (
          <DataTable<PersonnelDto>
            columns={columns}
            data={data}
            keyField="id"
            searchable
            searchPlaceholderKey="personnel.searchPlaceholder"
            dense
            actions={(row) => (
              <Button size="small" onClick={() => navigate(`/personnel/${row.badgeId}`)}
                sx={{
                  textTransform: 'none', fontSize: '0.78rem', fontWeight: 500,
                  color: '#312e81', '&:hover': { bgcolor: '#f0f0ff' },
                }}>
                {t('app.view', 'View')}
              </Button>
            )}
          />
        )}
      </Box>
    </Box>
  );
};

export default PersonnelPage;

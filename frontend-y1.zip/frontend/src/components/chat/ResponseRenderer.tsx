import React from 'react';
import { Typography, Box } from '@mui/material';
import TableWidget from './TableWidget';
import FormWidget from './FormWidget';
import ConfirmationWidget from './ConfirmationWidget';
import SuggestionsWidget from './SuggestionsWidget';
import type { TableResponseData, FormResponseData, ConfirmationResponseData, SuggestionsResponseData } from '@/types';

interface ResponseRendererProps {
  content: string;
  responseType?: string;
  data?: TableResponseData | FormResponseData | ConfirmationResponseData | SuggestionsResponseData;
  onFormSubmit: (formId: string, submitAction: string, fields: Record<string, string>) => Promise<boolean>;
  onSuggestionClick: (suggestion: string) => void;
}

const ResponseRenderer: React.FC<ResponseRendererProps> = ({ content, responseType, data, onFormSubmit, onSuggestionClick }) => {
  switch (responseType) {
    case 'table':
      return (
        <>
          {content && (
            <Typography sx={{ fontSize: '0.85rem', lineHeight: 1.6, whiteSpace: 'pre-wrap', mb: 1.5, color: '#374151' }}>
              {content}
            </Typography>
          )}
          <TableWidget {...(data as TableResponseData)} />
        </>
      );
    case 'form':
      return <FormWidget {...(data as FormResponseData)} onSubmit={onFormSubmit} />;
    case 'confirmation':
      return <ConfirmationWidget {...(data as ConfirmationResponseData)} />;
    case 'suggestions':
      return <SuggestionsWidget {...(data as SuggestionsResponseData)} onSuggestionClick={onSuggestionClick} />;
    case 'text':
    default:
      return (
        <Typography sx={{ fontSize: '0.85rem', lineHeight: 1.6, whiteSpace: 'pre-wrap' }}>
          {content}
        </Typography>
      );
  }
};

export default ResponseRenderer;

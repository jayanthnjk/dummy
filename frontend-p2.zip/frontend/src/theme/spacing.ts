/**
 * Spacing constants for the KSP WorkBoard layout system.
 * All values are in pixels.
 */

/** Horizontal padding for page content areas */
export const PAGE_PADDING_HORIZONTAL = 24;

/** Vertical padding for page content areas */
export const PAGE_PADDING_VERTICAL = 16;

/** Gap between cards in grid/flex layouts */
export const CARD_GAP = 16;

/** Vertical spacing between page sections */
export const SECTION_SPACING = 24;

import React from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import { ShiftBlockProps } from '../../types/schedule';
import { formatTimeRange } from '../../utils/scheduleFormatting';

/**
 * Shift color scheme mapping — soft enterprise colors with left border accent.
 * Returns background color, text color, and border color for each shift type.
 */
function getShiftPillColors(shiftType: string): {
  bg: string;
  text: string;
  border: string;
} {
  const normalized = shiftType.toLowerCase();

  if (normalized.includes('morning')) {
    return { bg: '#DBEAFE', text: '#1E40AF', border: '#1E40AF' };
  }
  if (normalized.includes('afternoon')) {
    return { bg: '#D1FAE5', text: '#065F46', border: '#065F46' };
  }
  if (normalized.includes('night')) {
    return { bg: '#FEF3C7', text: '#92400E', border: '#92400E' };
  }
  if (normalized.includes('special')) {
    return { bg: '#EDE9FE', text: '#5B21B6', border: '#5B21B6' };
  }

  // Default fallback — neutral gray
  return { bg: '#F3F4F6', text: '#374151', border: '#6B7280' };
}

/**
 * Gets an abbreviated shift type label for display on the pill.
 */
function getShiftLabel(shiftType: string): string {
  const normalized = shiftType.toLowerCase();
  if (normalized.includes('morning')) return 'Morning';
  if (normalized.includes('afternoon')) return 'Afternoon';
  if (normalized.includes('night')) return 'Night';
  if (normalized.includes('special')) return 'Special';
  return shiftType;
}

/**
 * ShiftBlock renders a compact, enterprise-styled pill representing a scheduled shift.
 * Shows duty type name and time range. Clickable for shift detail popup.
 * Features a 3px left border accent, soft background, and compact sizing.
 */
const ShiftBlock: React.FC<ShiftBlockProps> = ({ shift, onClick }) => {
  const colors = getShiftPillColors(shift.shiftType);
  const label = getShiftLabel(shift.shiftType);

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onClick) {
      onClick(shift);
    }
  };

  return (
    <Box
      onClick={handleClick}
      sx={{
        backgroundColor: colors.bg,
        color: colors.text,
        borderRadius: '10px',
        borderLeft: `3px solid ${colors.border}`,
        padding: '2px 8px',
        marginBottom: '3px',
        whiteSpace: 'nowrap',
        display: 'inline-flex',
        alignItems: 'center',
        maxWidth: '100%',
        cursor: onClick ? 'pointer' : 'default',
        transition: 'box-shadow 0.15s ease, transform 0.1s ease',
        '&:hover': onClick
          ? {
              boxShadow: '0 1px 4px rgba(0,0,0,0.12)',
              transform: 'translateY(-1px)',
            }
          : {},
      }}
    >
      <Typography
        variant="caption"
        sx={{
          color: 'inherit',
          fontSize: '0.625rem',
          fontWeight: 600,
          lineHeight: 1.4,
          letterSpacing: '0.01em',
        }}
      >
        {label}
      </Typography>
      <Typography
        variant="caption"
        sx={{
          color: 'inherit',
          fontSize: '0.5625rem',
          fontWeight: 400,
          lineHeight: 1.4,
          ml: 0.5,
          opacity: 0.8,
        }}
      >
        {formatTimeRange(shift.startTime, shift.endTime)}
      </Typography>
    </Box>
  );
};

export default ShiftBlock;

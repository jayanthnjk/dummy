package com.policescheduler.report.generator;

import com.policescheduler.entity.Personnel;
import com.policescheduler.entity.Platoon;
import com.policescheduler.entity.PlatoonQrtAssignment;
import com.policescheduler.entity.PlatoonRotationState;
import com.policescheduler.entity.ScheduleCycle;
import com.policescheduler.entity.CyclePlatoonSection;
import com.policescheduler.entity.Section;
import com.policescheduler.report.ReportGenerationException;
import com.policescheduler.repository.CyclePlatoonSectionRepository;
import com.policescheduler.repository.PersonnelRepository;
import com.policescheduler.repository.PlatoonQrtAssignmentRepository;
import com.policescheduler.repository.PlatoonRepository;
import com.policescheduler.repository.PlatoonRotationStateRepository;
import com.policescheduler.repository.ScheduleCycleRepository;
import com.policescheduler.repository.SectionRepository;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class PlatoonChartExcelGenerator {

    private static final Logger log = LoggerFactory.getLogger(PlatoonChartExcelGenerator.class);
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    private static final int NUM_ROTATION_PERIODS = 5;
    private static final int ROTATION_DAYS = 15;

    // Column order matches desired report: GUARD-I, PRISON/VIP, GUARD-II, STRIKING, CHECK POINT
    private static final List<String> DUTY_COLUMNS = List.of(
            "GUARD-I", "PRISON / VIP ESCORT/OUT", "GUARD-II", "STRIKING FORCE/HELP", "CHECK POINT"
    );

    // Section codes in the matching order: C, F, D, G, E
    private static final List<String> ALL_SECTIONS = List.of("C", "F", "D", "G", "E");

    private final PersonnelRepository personnelRepository;
    private final PlatoonRepository platoonRepository;
    private final PlatoonRotationStateRepository rotationStateRepository;
    private final PlatoonQrtAssignmentRepository qrtAssignmentRepository;
    private final ScheduleCycleRepository scheduleCycleRepository;
    private final CyclePlatoonSectionRepository cyclePlatoonSectionRepository;
    private final SectionRepository sectionRepository;
    private final com.policescheduler.service.ReassignmentResolverService reassignmentResolverService;

    public PlatoonChartExcelGenerator(PersonnelRepository personnelRepository,
                                       PlatoonRepository platoonRepository,
                                       PlatoonRotationStateRepository rotationStateRepository,
                                       PlatoonQrtAssignmentRepository qrtAssignmentRepository,
                                       ScheduleCycleRepository scheduleCycleRepository,
                                       CyclePlatoonSectionRepository cyclePlatoonSectionRepository,
                                       SectionRepository sectionRepository,
                                       com.policescheduler.service.ReassignmentResolverService reassignmentResolverService) {
        this.personnelRepository = personnelRepository;
        this.platoonRepository = platoonRepository;
        this.rotationStateRepository = rotationStateRepository;
        this.qrtAssignmentRepository = qrtAssignmentRepository;
        this.scheduleCycleRepository = scheduleCycleRepository;
        this.cyclePlatoonSectionRepository = cyclePlatoonSectionRepository;
        this.sectionRepository = sectionRepository;
        this.reassignmentResolverService = reassignmentResolverService;
    }

    public byte[] generate() {
        try {
            PlatoonRotationState state = rotationStateRepository.findAll().stream()
                    .findFirst().orElse(null);
            List<Platoon> platoons = platoonRepository.findAllByOrderByBaseOffsetAsc();
            List<Personnel> allPersonnel = personnelRepository.findAll().stream()
                    .filter(p -> p.getIsActive() != null && p.getIsActive())
                    .filter(p -> p.getPlatoonId() != null)
                    .filter(p -> ALL_SECTIONS.contains(p.getSection()))
                    .collect(Collectors.toList());

            // Apply reassignment resolution per section
            List<Personnel> resolvedPersonnel = new java.util.ArrayList<>();
            for (String sec : ALL_SECTIONS) {
                List<Personnel> secPersonnel = allPersonnel.stream()
                        .filter(p -> sec.equals(p.getSection()))
                        .collect(java.util.stream.Collectors.toList());
                resolvedPersonnel.addAll(reassignmentResolverService.resolveForSection(secPersonnel, sec, java.time.LocalDate.now()));
            }
            allPersonnel = resolvedPersonnel;

            // Load QRT assignments
            List<PlatoonQrtAssignment> qrtAssignments = qrtAssignmentRepository.findByIsActiveTrue();
            Map<Long, Personnel> personnelById = personnelRepository.findAll().stream()
                    .collect(Collectors.toMap(Personnel::getId, p -> p, (a, b) -> a));

            Map<Long, List<Personnel>> qrtPrimaryByPlatoon = new HashMap<>();
            Map<Long, List<Personnel>> qrtSecondaryByPlatoon = new HashMap<>();
            for (PlatoonQrtAssignment qrt : qrtAssignments) {
                Personnel p = personnelById.get(qrt.getPersonnelId());
                if (p == null) continue;
                if ("PRIMARY".equals(qrt.getQrtGroup())) {
                    qrtPrimaryByPlatoon.computeIfAbsent(qrt.getPlatoonId(), k -> new ArrayList<>()).add(p);
                } else {
                    qrtSecondaryByPlatoon.computeIfAbsent(qrt.getPlatoonId(), k -> new ArrayList<>()).add(p);
                }
            }

            int currentCycle = state != null ? state.getCurrentCycleIndex() : 0;
            LocalDate anchorStart = state != null && state.getLastRotationDate() != null
                    ? state.getLastRotationDate() : LocalDate.now();

            // Build section ID to duty index mapping
            Map<Long, Integer> sectionIdToDutyIndex = new HashMap<>();
            for (int i = 0; i < ALL_SECTIONS.size(); i++) {
                String sectionCode = ALL_SECTIONS.get(i);
                Optional<Section> section = sectionRepository.findByCode(sectionCode);
                if (section.isPresent()) {
                    sectionIdToDutyIndex.put(section.get().getId(), i);
                }
            }

            // Load schedule cycles
            List<ScheduleCycle> allCycles = scheduleCycleRepository.findByStatusNotOrderByStartDateDesc("DELETED");
            Collections.reverse(allCycles);

            List<ScheduleCycle> displayCycles = null;
            if (!allCycles.isEmpty()) {
                LocalDate today = LocalDate.now();
                int currentIdx = -1;
                for (int i = 0; i < allCycles.size(); i++) {
                    ScheduleCycle c = allCycles.get(i);
                    if (!today.isBefore(c.getStartDate()) && !today.isAfter(c.getEndDate())) {
                        currentIdx = i;
                        break;
                    }
                }
                if (currentIdx == -1) {
                    for (int i = 0; i < allCycles.size(); i++) {
                        if (allCycles.get(i).getStartDate().isAfter(today)) {
                            currentIdx = i;
                            break;
                        }
                    }
                }
                if (currentIdx == -1) currentIdx = allCycles.size() - 1;

                int windowStart = currentIdx - 2;
                int windowEnd = currentIdx + 2;
                if (windowStart < 0) {
                    windowEnd = Math.min(allCycles.size() - 1, windowEnd + (-windowStart));
                    windowStart = 0;
                }
                if (windowEnd >= allCycles.size()) {
                    windowStart = Math.max(0, windowStart - (windowEnd - allCycles.size() + 1));
                    windowEnd = allCycles.size() - 1;
                }
                displayCycles = allCycles.subList(windowStart, Math.min(windowEnd + 1, allCycles.size()));
            }

            try (XSSFWorkbook workbook = new XSSFWorkbook()) {
                Sheet sheet = workbook.createSheet("Section C");

                CellStyle headerStyle = createHeaderStyle(workbook);
                CellStyle dataStyle = createDataStyle(workbook);
                CellStyle dateStyle = createDateStyle(workbook);

                // Red bold font for QRT lines
                XSSFFont qrtFont = workbook.createFont();
                qrtFont.setBold(true);
                qrtFont.setColor(IndexedColors.RED.getIndex());
                qrtFont.setFontHeightInPoints((short) 8);

                XSSFFont normalFont = workbook.createFont();
                normalFont.setFontHeightInPoints((short) 8);

                int rowIndex = 0;

                // Title row
                Row titleRow = sheet.createRow(rowIndex++);
                Cell titleCell = titleRow.createCell(0);
                titleCell.setCellValue("SECTION C");
                titleCell.setCellStyle(headerStyle);

                // Header row
                Row headerRow = sheet.createRow(rowIndex++);
                Cell dateHeaderCell = headerRow.createCell(0);
                dateHeaderCell.setCellValue("DATE");
                dateHeaderCell.setCellStyle(headerStyle);

                for (int dutyIdx = 0; dutyIdx < DUTY_COLUMNS.size(); dutyIdx++) {
                    Long platoonAtDuty = null;
                    for (Platoon p : platoons) {
                        int idx = (p.getBaseOffset() + currentCycle) % 5;
                        if (idx == dutyIdx) {
                            platoonAtDuty = p.getId();
                            break;
                        }
                    }
                    long ahc = 0, apc = 0;
                    if (platoonAtDuty != null) {
                        Long pid = platoonAtDuty;
                        ahc = allPersonnel.stream()
                                .filter(per -> pid.equals(per.getPlatoonId()) && "AHC".equals(per.getDesignation()))
                                .count();
                        apc = allPersonnel.stream()
                                .filter(per -> pid.equals(per.getPlatoonId()) && "APC".equals(per.getDesignation()))
                                .count();
                    }
                    String headerText = DUTY_COLUMNS.get(dutyIdx) + "\n" + String.format("%02d AHC, %d APC, TOTAL=%d", ahc, apc, ahc + apc);
                    Cell cell = headerRow.createCell(dutyIdx + 1);
                    cell.setCellValue(headerText);
                    cell.setCellStyle(headerStyle);
                }

                // Data rows
                int numPeriods = displayCycles != null ? displayCycles.size() : NUM_ROTATION_PERIODS;
                for (int period = 0; period < numPeriods; period++) {
                    Row dataRow = sheet.createRow(rowIndex++);

                    String dateRange;
                    Map<Integer, Long> dutyToPlatoon = new HashMap<>();

                    if (displayCycles != null) {
                        ScheduleCycle cycle = displayCycles.get(period);
                        dateRange = cycle.getStartDate().format(DATE_FORMAT) + " TO " + cycle.getEndDate().format(DATE_FORMAT);

                        // Build duty-to-platoon from CyclePlatoonSection
                        List<CyclePlatoonSection> mappings = cyclePlatoonSectionRepository.findByCycleId(cycle.getId());
                        for (CyclePlatoonSection mapping : mappings) {
                            Integer dutyIdx = sectionIdToDutyIndex.get(mapping.getSectionId());
                            if (dutyIdx != null) {
                                dutyToPlatoon.put(dutyIdx, mapping.getPlatoonId());
                            }
                        }
                    } else {
                        LocalDate periodStart = anchorStart.plusDays((long) period * ROTATION_DAYS);
                        LocalDate periodEnd = periodStart.plusDays(ROTATION_DAYS);
                        dateRange = periodStart.format(DATE_FORMAT) + " TO " + periodEnd.format(DATE_FORMAT);
                    }

                    Cell dateCellVal = dataRow.createCell(0);
                    dateCellVal.setCellValue(dateRange);
                    dateCellVal.setCellStyle(dateStyle);

                    for (int dutyIdx = 0; dutyIdx < DUTY_COLUMNS.size(); dutyIdx++) {
                        Long platoonId = dutyToPlatoon.get(dutyIdx);

                        if (platoonId == null) {
                            int cycleForPeriod = displayCycles != null
                                    ? allCycles.indexOf(displayCycles.get(period))
                                    : currentCycle + period;
                            for (Platoon p : platoons) {
                                int idx = (p.getBaseOffset() + cycleForPeriod) % 5;
                                if (idx == dutyIdx) {
                                    platoonId = p.getId();
                                    break;
                                }
                            }
                        }

                        // Build cell content with platoon label + badges + QRT
                        String platoonLabel = "";
                        String badgeIds = "";
                        String qrtPrimaryText = "";
                        String qrtSecondaryText = "";

                        if (platoonId != null) {
                            Long pid = platoonId;
                            Platoon matchedPlatoon = platoons.stream()
                                    .filter(p -> p.getId().equals(pid))
                                    .findFirst().orElse(null);
                            if (matchedPlatoon != null) {
                                platoonLabel = "PLATOON-" + matchedPlatoon.getName().replace("Platoon ", "");
                            }

                            List<Personnel> platoonPersonnel = allPersonnel.stream()
                                    .filter(per -> pid.equals(per.getPlatoonId()))
                                    .collect(Collectors.toList());
                            if (!platoonPersonnel.isEmpty()) {
                                badgeIds = formatBadgeIds(platoonPersonnel);
                            }

                            List<Personnel> primaryQrt = qrtPrimaryByPlatoon.getOrDefault(pid, Collections.emptyList());
                            if (!primaryQrt.isEmpty()) {
                                qrtPrimaryText = "QRT: " + formatBadgeIds(primaryQrt);
                            }
                            List<Personnel> secondaryQrt = qrtSecondaryByPlatoon.getOrDefault(pid, Collections.emptyList());
                            if (!secondaryQrt.isEmpty()) {
                                qrtSecondaryText = "QRT : " + formatBadgeIds(secondaryQrt);
                            }
                        }

                        // Build rich text with QRT in red bold
                        String fullText = platoonLabel + "\n" + badgeIds;
                        if (!qrtPrimaryText.isEmpty()) {
                            fullText += "\n" + qrtPrimaryText;
                        }
                        if (!qrtSecondaryText.isEmpty()) {
                            fullText += "\n" + qrtSecondaryText;
                        }

                        XSSFRichTextString richText = new XSSFRichTextString(fullText);

                        // Apply red bold to QRT portions
                        int qrtStart = fullText.indexOf("QRT");
                        if (qrtStart >= 0) {
                            richText.applyFont(0, qrtStart, normalFont);
                            richText.applyFont(qrtStart, fullText.length(), qrtFont);
                        }

                        Cell cell = dataRow.createCell(dutyIdx + 1);
                        cell.setCellValue(richText);
                        cell.setCellStyle(dataStyle);
                    }
                }

                // Column widths
                sheet.setColumnWidth(0, 5000);
                for (int i = 1; i <= 5; i++) {
                    sheet.setColumnWidth(i, 12000);
                }

                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                workbook.write(baos);
                return baos.toByteArray();
            }
        } catch (Exception e) {
            log.error("Failed to generate Section C Excel report", e);
            throw new ReportGenerationException("platoon_chart_excel", "Failed to generate Section C Excel report", e);
        }
    }

    private String formatBadgeIds(List<Personnel> personnel) {
        StringBuilder sb = new StringBuilder();
        List<Personnel> ahcList = personnel.stream()
                .filter(p -> "AHC".equals(p.getDesignation()))
                .collect(Collectors.toList());
        List<Personnel> apcList = personnel.stream()
                .filter(p -> "APC".equals(p.getDesignation()))
                .collect(Collectors.toList());

        if (!ahcList.isEmpty()) {
            sb.append("AHC-");
            sb.append(ahcList.stream()
                    .map(p -> extractBadgeNumber(p.getBadgeId()))
                    .collect(Collectors.joining(", ")));
        }
        if (!apcList.isEmpty()) {
            if (sb.length() > 0) sb.append(" ");
            sb.append("APC-");
            sb.append(apcList.stream()
                    .map(p -> extractBadgeNumber(p.getBadgeId()))
                    .collect(Collectors.joining(", ")));
        }
        return sb.toString();
    }

    private String extractBadgeNumber(String badgeId) {
        if (badgeId != null && badgeId.contains("-")) {
            return badgeId.substring(badgeId.lastIndexOf('-') + 1);
        }
        return badgeId != null ? badgeId : "";
    }

    private CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 9);
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        style.setWrapText(true);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    private CellStyle createDataStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 8);
        style.setFont(font);
        style.setVerticalAlignment(VerticalAlignment.TOP);
        style.setWrapText(true);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    private CellStyle createDateStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 8);
        font.setBold(true);
        style.setFont(font);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        style.setWrapText(true);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }
}

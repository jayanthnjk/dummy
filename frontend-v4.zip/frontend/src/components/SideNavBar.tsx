import React, { useState } from 'react';
import {
  Drawer, List, ListItem, ListItemButton, ListItemIcon, ListItemText,
  Box, Typography, IconButton, Collapse,
} from '@mui/material';
import HomeIcon from '@mui/icons-material/Home';
import PeopleIcon from '@mui/icons-material/People';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import EventBusyIcon from '@mui/icons-material/EventBusy';
import SettingsIcon from '@mui/icons-material/Settings';
import DescriptionIcon from '@mui/icons-material/Description';
import SecurityIcon from '@mui/icons-material/Security';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ExpandLess from '@mui/icons-material/ExpandLess';
import ExpandMore from '@mui/icons-material/ExpandMore';
import AssignmentIcon from '@mui/icons-material/Assignment';
import { useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuth } from '@/contexts/AuthContext';

const DRAWER_WIDTH = 220;
const COLLAPSED_WIDTH = 64;

interface NavItem {
  labelKey: string;
  path: string;
  icon: React.ReactNode;
  adminOnly?: boolean;
}

interface NavGroupItem {
  labelKey: string;
  icon: React.ReactNode;
  adminOnly?: boolean;
  children: { labelKey: string; path: string; icon: React.ReactNode }[];
}

const navItems: NavItem[] = [
  { labelKey: 'nav.home', path: '/', icon: <HomeIcon sx={{ fontSize: 20 }} /> },
  { labelKey: 'nav.schedules', path: '/schedules', icon: <CalendarMonthIcon sx={{ fontSize: 20 }} /> },
  { labelKey: 'nav.personnel', path: '/personnel', icon: <PeopleIcon sx={{ fontSize: 20 }} /> },
  { labelKey: 'nav.leaveRequests', path: '/leave-requests', icon: <EventBusyIcon sx={{ fontSize: 20 }} /> },
  { labelKey: 'nav.reports', path: '/reports', icon: <DescriptionIcon sx={{ fontSize: 20 }} /> },
];

const adminGroup: NavGroupItem = {
  labelKey: 'nav.adminConfig',
  icon: <SettingsIcon sx={{ fontSize: 20 }} />,
  adminOnly: true,
  children: [
    { labelKey: 'nav.dutySections', path: '/admin/duty-sections', icon: <AssignmentIcon sx={{ fontSize: 18 }} /> },
  ],
};

interface SideNavBarProps {
  mobileOpen: boolean;
  onClose: () => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
}

const SideNavBar: React.FC<SideNavBarProps> = ({ mobileOpen, onClose, collapsed, onToggleCollapse }) => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();
  const { role } = useAuth();

  const [adminOpen, setAdminOpen] = useState(() => location.pathname.startsWith('/admin'));

  const isAdminUser = role === 'ADMIN' || role === 'HIGHER_OFFICER';

  const isAdminChildActive = adminGroup.children.some(
    (child) => location.pathname === child.path
  );
  const isAdminGroupActive = isAdminChildActive || location.pathname.startsWith('/admin');

  const handleAdminClick = () => {
    if (collapsed) {
      // When collapsed, navigate to first child
      navigate(adminGroup.children[0].path);
      onClose();
    } else {
      setAdminOpen((prev) => !prev);
    }
  };

  const width = collapsed ? COLLAPSED_WIDTH : DRAWER_WIDTH;

  const activeStyles = (isActive: boolean) => ({
    borderRadius: 1.5,
    py: 0.9,
    px: collapsed ? 1.5 : 1.5,
    justifyContent: collapsed ? 'center' : 'flex-start',
    position: 'relative' as const,
    color: isActive ? '#1a1e4a' : '#6b7280',
    bgcolor: isActive ? '#f0f0ff' : 'transparent',
    '&:hover': { bgcolor: isActive ? '#f0f0ff' : '#f9fafb' },
    '&::before': isActive ? {
      content: '""', position: 'absolute', left: 0, top: '20%', bottom: '20%',
      width: 3, borderRadius: 2, bgcolor: '#1a1e4a',
    } : {},
  });

  const drawerContent = (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Logo */}
      <Box sx={{ px: collapsed ? 1 : 2, py: 1.8, display: 'flex', alignItems: 'center', gap: 1.2, minHeight: 52 }}>
        <Box sx={{
          width: 32, height: 32, borderRadius: 1.5, bgcolor: '#1a1e4a', flexShrink: 0,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <SecurityIcon sx={{ fontSize: 18, color: '#c4a44a' }} />
        </Box>
        {!collapsed && (
          <Box>
            <Typography sx={{ fontWeight: 700, fontSize: '0.85rem', color: '#1a1e4a', lineHeight: 1.1 }}>KSP WorkBoard</Typography>
            <Typography sx={{ fontSize: '0.62rem', color: '#9ca3af', lineHeight: 1.2 }}>CAR Unit</Typography>
          </Box>
        )}
      </Box>

      {/* Nav items */}
      <List sx={{ flex: 1, px: 0.8, pt: 0.5 }}>
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <ListItem key={item.path} disablePadding sx={{ mb: 0.3 }}>
              <ListItemButton
                onClick={() => { navigate(item.path); onClose(); }}
                sx={activeStyles(isActive)}
              >
                <ListItemIcon sx={{
                  minWidth: collapsed ? 0 : 32,
                  color: isActive ? '#1a1e4a' : '#9ca3af',
                  justifyContent: 'center',
                }}>
                  {item.icon}
                </ListItemIcon>
                {!collapsed && (
                  <ListItemText
                    primary={t(item.labelKey)}
                    primaryTypographyProps={{
                      fontSize: '0.82rem',
                      fontWeight: isActive ? 600 : 400,
                    }}
                  />
                )}
              </ListItemButton>
            </ListItem>
          );
        })}

        {/* Admin Configuration expandable group */}
        {isAdminUser && (
          <>
            <ListItem disablePadding sx={{ mb: 0.3 }}>
              <ListItemButton
                onClick={handleAdminClick}
                sx={activeStyles(isAdminGroupActive)}
              >
                <ListItemIcon sx={{
                  minWidth: collapsed ? 0 : 32,
                  color: isAdminGroupActive ? '#1a1e4a' : '#9ca3af',
                  justifyContent: 'center',
                }}>
                  {adminGroup.icon}
                </ListItemIcon>
                {!collapsed && (
                  <>
                    <ListItemText
                      primary={t(adminGroup.labelKey, 'Admin Configuration')}
                      primaryTypographyProps={{
                        fontSize: '0.82rem',
                        fontWeight: isAdminGroupActive ? 600 : 400,
                      }}
                    />
                    {adminOpen ? <ExpandLess sx={{ fontSize: 18 }} /> : <ExpandMore sx={{ fontSize: 18 }} />}
                  </>
                )}
              </ListItemButton>
            </ListItem>

            {/* Collapsible sub-items */}
            {!collapsed && (
              <Collapse in={adminOpen} timeout="auto" unmountOnExit>
                <List component="div" disablePadding>
                  {adminGroup.children.map((child) => {
                    const isChildActive = location.pathname === child.path;
                    return (
                      <ListItem key={child.path} disablePadding sx={{ mb: 0.2 }}>
                        <ListItemButton
                          onClick={() => { navigate(child.path); onClose(); }}
                          sx={{
                            borderRadius: 1.5,
                            py: 0.7,
                            pl: 4.5,
                            pr: 1.5,
                            color: isChildActive ? '#1a1e4a' : '#6b7280',
                            bgcolor: isChildActive ? '#f0f0ff' : 'transparent',
                            '&:hover': { bgcolor: isChildActive ? '#f0f0ff' : '#f9fafb' },
                          }}
                        >
                          <ListItemIcon sx={{
                            minWidth: 28,
                            color: isChildActive ? '#1a1e4a' : '#9ca3af',
                            justifyContent: 'center',
                          }}>
                            {child.icon}
                          </ListItemIcon>
                          <ListItemText
                            primary={t(child.labelKey, child.labelKey)}
                            primaryTypographyProps={{
                              fontSize: '0.78rem',
                              fontWeight: isChildActive ? 600 : 400,
                            }}
                          />
                        </ListItemButton>
                      </ListItem>
                    );
                  })}
                </List>
              </Collapse>
            )}
          </>
        )}
      </List>
    </Box>
  );

  return (
    <>
      <Box component="nav" sx={{ width: { md: width }, flexShrink: { md: 0 }, position: 'relative' }}>
        {/* Mobile */}
        <Drawer variant="temporary" open={mobileOpen} onClose={onClose}
          ModalProps={{ keepMounted: true }}
          sx={{ display: { xs: 'block', md: 'none' }, '& .MuiDrawer-paper': { width: DRAWER_WIDTH, borderRight: 'none' } }}>
          {drawerContent}
        </Drawer>
        {/* Desktop */}
        <Drawer variant="permanent" open
          sx={{
            display: { xs: 'none', md: 'block' },
            '& .MuiDrawer-paper': {
              width, borderRight: 'none', transition: 'width 0.2s ease',
              boxShadow: '1px 0 0 #f0ede6', overflow: 'hidden',
            },
          }}>
          {drawerContent}
        </Drawer>
      </Box>

      {/* Collapse toggle — centered vertically on the sidebar edge */}
      <Box sx={{
        display: { xs: 'none', md: 'flex' },
        position: 'fixed', left: width - 12, top: '50%', transform: 'translateY(-50%)',
        zIndex: 1201,
      }}>
        <IconButton onClick={onToggleCollapse} size="small"
          sx={{
            width: 24, height: 24, bgcolor: '#fff', border: '1px solid #e5e7eb',
            boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
            '&:hover': { bgcolor: '#f9fafb' },
            transition: 'left 0.2s ease',
          }}>
          <ChevronLeftIcon sx={{
            fontSize: 14, color: '#6b7280',
            transform: collapsed ? 'rotate(180deg)' : 'none',
            transition: 'transform 0.2s',
          }} />
        </IconButton>
      </Box>
    </>
  );
};

export default SideNavBar;
export { DRAWER_WIDTH, COLLAPSED_WIDTH };

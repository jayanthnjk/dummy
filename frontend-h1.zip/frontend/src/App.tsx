import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { AdminRoute } from '@/components/AdminRoute';
import { SupportAdminRoute } from '@/components/SupportAdminRoute';
import InactivityDialog from '@/components/InactivityDialog';
import LoginPage from '@/pages/LoginPage';
import HomePage from '@/pages/HomePage';
import PersonnelPage from '@/pages/PersonnelPage';
import AddPersonPage from '@/pages/AddPersonPage';
import DailyRosterPage from '@/pages/DailyRosterPage';
import PersonnelProfilePage from '@/pages/PersonnelProfilePage';
import SchedulesPage from '@/pages/SchedulesPage';
import RotationManagementPage from '@/pages/RotationManagementPage';
import CycleManagementPage from '@/pages/CycleManagementPage';
import LeaveRequestsPage from '@/pages/LeaveRequestsPage';

import CycleActivitiesPage from '@/pages/CycleActivitiesPage';
import DutySectionsPage from '@/pages/DutySectionsPage';
import ReportsPage from '@/pages/ReportsPage';
import ContactSupportPage from '@/pages/ContactSupportPage';
import AdhocDutyPage from '@/pages/AdhocDutyPage';
import CreateAdhocDutyPage from '@/pages/CreateAdhocDutyPage';
import AssignDutiesPage from '@/pages/AssignDutiesPage';
import ChangePasswordPage from '@/pages/ChangePasswordPage';
import SupportAdminPage from '@/pages/SupportAdminPage';
import ReportEmailConfigPage from '@/pages/ReportEmailConfigPage';

const App: React.FC = () => {
  return (
    <BrowserRouter>
      <InactivityDialog />
      <Routes>
        <Route path="/login" element={<LoginPage />} />

        {/* Support Admin dedicated portal - outside normal AppShell */}
        <Route element={<SupportAdminRoute />}>
          <Route path="/support-admin" element={<SupportAdminPage />} />
        </Route>

        {/* Protected routes - require authentication */}
        <Route element={<ProtectedRoute />}>
          <Route path="/" element={<HomePage />} />
          <Route path="/personnel" element={<PersonnelPage />} />
          <Route path="/personnel/add" element={<AddPersonPage />} />
          <Route path="/personnel/daily-roster" element={<DailyRosterPage />} />
          <Route path="/personnel/:badgeId" element={<PersonnelProfilePage />} />
          <Route path="/schedules" element={<SchedulesPage />} />
          <Route path="/schedules/rotation" element={<RotationManagementPage />} />
          <Route path="/schedules/cycles" element={<CycleManagementPage />} />
          <Route path="/schedules/activities" element={<CycleActivitiesPage />} />
          <Route path="/schedules/adhoc/create" element={<CreateAdhocDutyPage />} />
          <Route path="/schedules/adhoc" element={<AdhocDutyPage />} />
          <Route path="/assign-duties" element={<AssignDutiesPage />} />
          <Route path="/leave-requests" element={<LeaveRequestsPage />} />
          <Route path="/reports" element={<ReportsPage />} />
          <Route path="/contact-support" element={<ContactSupportPage />} />
          <Route path="/change-password" element={<ChangePasswordPage />} />
          <Route path="/admin/duty-sections" element={<DutySectionsPage />} />

          {/* Admin-only routes */}
          <Route element={<AdminRoute />}>
            <Route path="/admin/configuration" element={<ReportEmailConfigPage />} />
          </Route>
        </Route>

        {/* Catch-all redirect */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;

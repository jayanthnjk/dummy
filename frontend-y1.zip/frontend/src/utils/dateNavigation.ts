import { DateRange, ViewMode } from '../types/schedule';

/**
 * Formats a Date to an ISO date string "YYYY-MM-DD".
 */
function toISODate(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Parses an ISO date string "YYYY-MM-DD" to a Date (at midnight local time).
 */
function parseDate(isoDate: string): Date {
  const [year, month, day] = isoDate.split('-').map(Number);
  return new Date(year, month - 1, day);
}

/**
 * Short month names for formatting.
 */
const MONTH_NAMES_SHORT = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
];

/**
 * Day names for column headers.
 */
const DAY_NAMES = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

/**
 * Returns the Monday-start week range containing the given anchor date.
 * Week runs from Monday to Sunday.
 */
export function getWeekRange(anchorDate: Date): DateRange {
  const day = anchorDate.getDay(); // 0=Sun, 1=Mon, ..., 6=Sat
  // Calculate offset to Monday: if Sunday (0), go back 6 days; otherwise go back (day - 1)
  const mondayOffset = day === 0 ? -6 : 1 - day;

  const monday = new Date(anchorDate.getFullYear(), anchorDate.getMonth(), anchorDate.getDate() + mondayOffset);
  const sunday = new Date(monday.getFullYear(), monday.getMonth(), monday.getDate() + 6);

  const start = toISODate(monday);
  const end = toISODate(sunday);
  const label = formatDateRangeLabel({ start, end, label: '' });

  return { start, end, label };
}

/**
 * Returns the date range for a single day.
 */
export function getDayRange(anchorDate: Date): DateRange {
  const isoDate = toISODate(anchorDate);
  const label = formatDateRangeLabel({ start: isoDate, end: isoDate, label: '' });
  return { start: isoDate, end: isoDate, label };
}

/**
 * Returns the date range for the full month containing the anchor date.
 */
export function getMonthRange(anchorDate: Date): DateRange {
  const year = anchorDate.getFullYear();
  const month = anchorDate.getMonth();

  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0); // day 0 of next month = last day of current month

  const start = toISODate(firstDay);
  const end = toISODate(lastDay);
  const label = formatDateRangeLabel({ start, end, label: '' });

  return { start, end, label };
}

/**
 * Advances the anchor date by one period based on the view mode.
 * Returns a new Date (does not mutate the input).
 */
export function navigateNext(anchorDate: Date, viewMode: ViewMode): Date {
  const year = anchorDate.getFullYear();
  const month = anchorDate.getMonth();
  const day = anchorDate.getDate();

  switch (viewMode) {
    case 'day':
      return new Date(year, month, day + 1);
    case 'week':
      return new Date(year, month, day + 7);
    case 'month':
      return new Date(year, month + 1, day);
    default:
      return new Date(year, month, day);
  }
}

/**
 * Moves the anchor date back by one period based on the view mode.
 * Returns a new Date (does not mutate the input).
 */
export function navigatePrev(anchorDate: Date, viewMode: ViewMode): Date {
  const year = anchorDate.getFullYear();
  const month = anchorDate.getMonth();
  const day = anchorDate.getDate();

  switch (viewMode) {
    case 'day':
      return new Date(year, month, day - 1);
    case 'week':
      return new Date(year, month, day - 7);
    case 'month':
      return new Date(year, month - 1, day);
    default:
      return new Date(year, month, day);
  }
}

/**
 * Returns today's date. Pure in the sense it takes no arguments
 * and always returns the current date without side effects on external state.
 */
export function navigateToday(): Date {
  return new Date();
}

/**
 * Returns an array of day column descriptors for the given date range and view mode.
 * - Day mode: 1 column
 * - Week mode: 7 columns (Mon–Sun)
 * - Month mode: all days in the month
 */
export function getDayColumns(
  dateRange: DateRange,
  viewMode: ViewMode
): { dayName: string; date: string; isToday: boolean }[] {
  const today = toISODate(new Date());
  const startDate = parseDate(dateRange.start);

  switch (viewMode) {
    case 'day': {
      const dayIndex = (startDate.getDay() + 6) % 7; // Convert to 0=Mon, ..., 6=Sun
      return [{
        dayName: DAY_NAMES[dayIndex],
        date: dateRange.start,
        isToday: dateRange.start === today,
      }];
    }
    case 'week': {
      const columns: { dayName: string; date: string; isToday: boolean }[] = [];
      for (let i = 0; i < 7; i++) {
        const current = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate() + i);
        const isoDate = toISODate(current);
        columns.push({
          dayName: DAY_NAMES[i],
          date: isoDate,
          isToday: isoDate === today,
        });
      }
      return columns;
    }
    case 'month': {
      const columns: { dayName: string; date: string; isToday: boolean }[] = [];
      const endDate = parseDate(dateRange.end);
      const totalDays = Math.round((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1;

      for (let i = 0; i < totalDays; i++) {
        const current = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate() + i);
        const dayIndex = (current.getDay() + 6) % 7; // 0=Mon, ..., 6=Sun
        const isoDate = toISODate(current);
        columns.push({
          dayName: DAY_NAMES[dayIndex],
          date: isoDate,
          isToday: isoDate === today,
        });
      }
      return columns;
    }
    default:
      return [];
  }
}

/**
 * Generates a display label for a date range.
 * - Same day: "Jun 15, 2026"
 * - Same month: "Jun 15 - 21, 2026"
 * - Same year, different months: "Jun 15 - Jul 21, 2026"
 * - Different years: "Dec 28, 2025 - Jan 3, 2026"
 */
export function formatDateRangeLabel(dateRange: DateRange): string {
  const startDate = parseDate(dateRange.start);
  const endDate = parseDate(dateRange.end);

  const startMonth = MONTH_NAMES_SHORT[startDate.getMonth()];
  const startDay = startDate.getDate();
  const startYear = startDate.getFullYear();

  const endMonth = MONTH_NAMES_SHORT[endDate.getMonth()];
  const endDay = endDate.getDate();
  const endYear = endDate.getFullYear();

  // Same day
  if (dateRange.start === dateRange.end) {
    return `${startMonth} ${startDay}, ${startYear}`;
  }

  // Different years
  if (startYear !== endYear) {
    return `${startMonth} ${startDay}, ${startYear} - ${endMonth} ${endDay}, ${endYear}`;
  }

  // Same year, same month
  if (startDate.getMonth() === endDate.getMonth()) {
    return `${startMonth} ${startDay} - ${endDay}, ${startYear}`;
  }

  // Same year, different months
  return `${startMonth} ${startDay} - ${endMonth} ${endDay}, ${startYear}`;
}

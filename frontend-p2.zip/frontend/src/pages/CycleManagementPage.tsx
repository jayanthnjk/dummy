import React, { useState, useCallback } from 'react';
import { Box } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { useNavigate } from 'react-router-dom';

import CycleListView from '@/components/cycle/CycleListView';
import CycleDetailView from '@/components/cycle/CycleDetailView';
import CycleForm from '@/components/cycle/CycleForm';
import ReassignModal from '@/components/cycle/ReassignModal';
import PageHeader from '@/components/common/PageHeader';
import type { ActionButtonConfig } from '@/components/common/PageHeader';
import type { AssignmentResponse } from '@/services/cycleService';

type ViewState = 'list' | 'detail';

/**
 * CycleManagementPage — Full page for managing platoon rotation cycles.
 *
 * State machine:
 *  - 'list': shows CycleListView + "Create Cycle" button
 *  - 'detail': shows CycleDetailView with back navigation
 *
 * Integrates CycleForm (dialog) for creation and ReassignModal for leave-conflict reassignment.
 *
 * Implements Requirements 4.3, 4.4.
 */
const CycleManagementPage: React.FC = () => {
  const navigate = useNavigate();
  // View state machine
  const [view, setView] = useState<ViewState>('list');
  const [selectedCycleId, setSelectedCycleId] = useState<number | null>(null);

  // CycleForm dialog state
  const [cycleFormOpen, setCycleFormOpen] = useState(false);

  // ReassignModal state
  const [reassignOpen, setReassignOpen] = useState(false);
  const [reassignAssignment, setReassignAssignment] = useState<AssignmentResponse | null>(null);

  // Key to force CycleListView remount (refresh) after creation
  const [listKey, setListKey] = useState(0);
  // Key to force CycleDetailView remount (refresh) after reassignment
  const [detailKey, setDetailKey] = useState(0);

  // Navigate to cycle detail
  const handleCycleSelect = useCallback((cycleId: number) => {
    setSelectedCycleId(cycleId);
    setView('detail');
  }, []);

  // Navigate back to list
  const handleBack = useCallback(() => {
    setView('list');
    setSelectedCycleId(null);
  }, []);

  // Open CycleForm
  const handleOpenCycleForm = useCallback(() => {
    setCycleFormOpen(true);
  }, []);

  // On successful cycle creation, close form and refresh list
  const handleCycleCreated = useCallback(() => {
    setCycleFormOpen(false);
    setListKey((prev) => prev + 1);
  }, []);

  // Open ReassignModal when CycleDetailView emits onReassign
  const handleReassign = useCallback((assignment: AssignmentResponse) => {
    setReassignAssignment(assignment);
    setReassignOpen(true);
  }, []);

  // On successful reassignment, close modal and refresh detail view
  const handleReassignSuccess = useCallback(() => {
    setReassignOpen(false);
    setReassignAssignment(null);
    setDetailKey((prev) => prev + 1);
  }, []);

  const handleReassignClose = useCallback(() => {
    setReassignOpen(false);
    setReassignAssignment(null);
  }, []);

  const headerActions: ActionButtonConfig[] = [
    {
      label: 'Back to Schedules',
      variant: 'ghost',
      icon: <ArrowBackIcon />,
      onClick: () => navigate('/schedules'),
    },
    ...(view === 'list'
      ? [
          {
            label: 'Create Cycle',
            variant: 'primary' as const,
            icon: <AddIcon />,
            onClick: handleOpenCycleForm,
          },
        ]
      : []),
  ];

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        flex: 1,
        overflow: 'hidden',
        bgcolor: 'background.default',
      }}
    >
      <PageHeader
        title="Platoon Cycle Management"
        breadcrumbs={[
          { label: 'Home', path: '/' },
          { label: 'Schedules', path: '/schedules' },
          { label: 'Cycle Management' },
        ]}
        actions={headerActions}
      />

      {/* Page Content */}
      <Box sx={{ flex: 1, overflow: 'auto', p: { xs: 2, md: 3 } }}>
        {view === 'list' && (
          <CycleListView key={listKey} onCycleSelect={handleCycleSelect} />
        )}

        {view === 'detail' && selectedCycleId !== null && (
          <CycleDetailView
            key={detailKey}
            cycleId={selectedCycleId}
            onBack={handleBack}
            onReassign={handleReassign}
          />
        )}
      </Box>

      {/* CycleForm Dialog */}
      <CycleForm
        open={cycleFormOpen}
        onClose={() => setCycleFormOpen(false)}
        onSuccess={handleCycleCreated}
      />

      {/* ReassignModal */}
      <ReassignModal
        open={reassignOpen}
        onClose={handleReassignClose}
        onSuccess={handleReassignSuccess}
        assignmentId={reassignAssignment?.id ?? null}
        assignmentDate={reassignAssignment?.date ?? ''}
        currentPersonName={
          reassignAssignment ? `Person ${reassignAssignment.personId}` : ''
        }
      />
    </Box>
  );
};

export default CycleManagementPage;

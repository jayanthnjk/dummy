// ===== Auth =====
export interface LoginRequest {
  username: string;
  password: string;
  loginType?: string;
}

export interface AuthResponse {
  token: string;
  role: string;
  displayName: string;
  locale: string;
  units?: string;
}

export interface ChangePasswordRequest {
  oldPassword: string;
  newPassword: string;
}

// ===== Personnel =====
export interface PersonnelDto {
  id: number;
  badgeId: string;
  personName: string;
  dutyType: string;
  location: string;
  phoneNumber: string;
  email: string;
  designation: string;
  section: string;
  dateOfJoining: string;
  dateOfBirth?: string;
  bloodGroup?: string;
  qualification?: string;
  permanentAddress?: string;
  presentAddress?: string;
  nativePoliceStation?: string;
  vehicleNumber?: string;
  dutyLocation?: string;
  pdms?: string;
  licenceType?: string;
  typeOfVehicle?: string;
  deployedFrom?: string;
  platoonId?: number;
  unit?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CreatePersonnelRequest {
  badgeId: string;
  personName: string;
  dutyType?: string;
  location?: string;
  phoneNumber?: string;
  email?: string;
  designation?: string;
  section: string;
  dateOfJoining?: string;
  dateOfBirth?: string;
  bloodGroup?: string;
  qualification?: string;
  permanentAddress?: string;
  presentAddress?: string;
  nativePoliceStation?: string;
  vehicleNumber?: string;
  dutyLocation?: string;
  pdms?: string;
  licenceType?: string;
  typeOfVehicle?: string;
  deployedFrom?: string;
  platoonId?: number;
  isActive?: boolean;
  unit?: string;
}

export interface UpdatePersonnelRequest {
  badgeId?: string;
  personName?: string;
  dutyType?: string;
  location?: string;
  phoneNumber?: string;
  email?: string;
  designation?: string;
  section?: string;
  dateOfJoining?: string;
  dateOfBirth?: string;
  bloodGroup?: string;
  qualification?: string;
  permanentAddress?: string;
  presentAddress?: string;
  nativePoliceStation?: string;
  vehicleNumber?: string;
  dutyLocation?: string;
  pdms?: string;
  licenceType?: string;
  typeOfVehicle?: string;
  deployedFrom?: string;
  platoonId?: number;
  isActive?: boolean;
  unit?: string;
}

export interface PersonnelFilter {
  search?: string;
  section?: string;
  dutyType?: string;
  designation?: string;
  isActive?: boolean;
}

// ===== Schedule =====
export interface DutyAssignmentDto {
  id: number;
  personnelId: number;
  personnelName: string;
  badgeId: string;
  dutyTypeId: number;
  dutyTypeName: string;
  section: string;
  effectiveDate: string;
  endDate?: string;
  shift?: string;
  subAssignment?: string;
  isCurrent: boolean;
}

export interface UpdateAssignmentRequest {
  personnelId?: number;
  dutyTypeId?: number;
  section?: string;
  effectiveDate?: string;
  endDate?: string;
  shift?: string;
  subAssignment?: string;
  isCurrent?: boolean;
}

export interface PlatoonDutyMapping {
  platoonId: number;
  platoonName: string;
  baseOffset: number;
  currentDutyType: string;
}

export interface PlatoonRotationDto {
  currentCycleIndex: number;
  lastRotationDate: string;
  nextRotationDate: string;
  platoonMappings: PlatoonDutyMapping[];
}

export interface SectionCData {
  rotation: PlatoonRotationDto;
  assignments: DutyAssignmentDto[];
}

export interface SectionOverview {
  sectionA: DutyAssignmentDto[];
  sectionB: DutyAssignmentDto[];
  sectionC: SectionCData;
}

// ===== Leave =====
export interface LeaveRequestDto {
  id: number;
  personnelId: number;
  personnelName: string;
  badgeId: string;
  leaveType: string;
  startDate: string;
  endDate: string | null;
  status: string;
  reason: string;
  approvedBy?: number;
  rejectionReason?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateLeaveRequest {
  personnelId: number;
  leaveType: string;
  startDate: string;
  endDate?: string;
  reason?: string;
}

export interface LeaveFilter {
  status?: string;
  leaveType?: string;
  personnelId?: number;
  startDate?: string;
  endDate?: string;
}

// ===== Chat =====
export interface ChatRequest {
  message: string;
}

export interface ColumnDef {
  key: string;
  label: string;
}

export interface TableResponseData {
  columns: ColumnDef[];
  rows: Record<string, unknown>[];
  totalCount: number;
  meta?: Record<string, unknown>;
}

export interface FieldDef {
  name: string;
  label: string;
  type: 'text' | 'select' | 'date' | 'number' | 'multi-select' | 'time' | 'textarea' | 'switch' | 'chip-select' | 'designation-counts' | 'personnel-list' | 'hidden';
  required: boolean;
  value?: string;
  options?: string[];
  placeholder?: string;
  helperText?: string;
  group?: string; // For grouping fields (e.g., 'basic', 'personal', 'contact', 'driver')
}

export interface FormResponseData {
  formId: string;
  title: string;
  fields: FieldDef[];
  submitAction: string;
  submitLabel?: string;
}

export interface ConfirmationResponseData {
  success: boolean;
  message: string;
  details?: Record<string, string>;
}

export interface SuggestionsResponseData {
  message: string;
  suggestions: string[];
}

export interface ChatResponse {
  response: string;
  commandType?: string;
  responseType?: 'text' | 'table' | 'form' | 'confirmation' | 'suggestions';
  data?: TableResponseData | FormResponseData | ConfirmationResponseData | SuggestionsResponseData;
}

// ===== i18n =====
export interface TranslationEntry {
  translationKey: string;
  locale: string;
  translationValue: string;
  category?: string;
}

// ===== Admin =====
export interface SystemConfig {
  [key: string]: string;
}

// ===== Common =====
export interface ErrorResponse {
  error: {
    code: string;
    message: string;
    timestamp: string;
  };
}

export interface Page<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  size: number;
  number: number;
  first: boolean;
  last: boolean;
}

export type UserRole = 'ADMIN' | 'HIGHER_OFFICER' | 'GENERAL_USER' | 'SUPPORT_ADMIN';
export type LeaveType = 'CASUAL_LEAVE' | 'SICK_LEAVE' | 'EARNED_LEAVE' | 'WEEKLY_OFF' | 'COMMUTED_LEAVE' | 'PATERNITY_LEAVE' | 'ABSENT';
export type LeaveStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'CANCELLED' | 'COMPLETED';
export type Locale = 'en' | 'kn';

// ===== Duty History =====
export interface DutyHistoryDto {
  id: number;
  personId: number;
  badgeId: string;
  personName: string;
  designation: string | null;
  recordDate: string;
  section: string | null;
  dutyType: string | null;
  dutyLocation: string | null;
  worksAt: string | null;
  adhocDuty: string | null;
  leaveType: string | null;
  shiftType: string | null;
  status: string | null;
  createdAt: string;
}

// ===== Strength Metrics =====
export interface SanctionedStrengthDto {
  id: number;
  designation: string;
  displayOrder: number;
  sanctionedCount: number;
}

export interface StrengthMetricsDto {
  designations: string[];
  sanctionedStrength: Record<string, number>;
  presentStrength: Record<string, number>;
  vacancy: Record<string, number>;
  totalSanctioned: number;
  totalPresent: number;
  totalVacancy: number;
}

export interface UpdateSanctionedStrengthRequest {
  designation: string;
  sanctionedCount: number;
}

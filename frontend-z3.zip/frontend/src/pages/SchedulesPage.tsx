import React, { useEffect, useState, useMemo, useCallback } from 'react';
import {
  Alert,
  Box,
  Button,
  ButtonGroup,
  Chip,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  MenuItem,
  Select,
  Skeleton,
  Snackbar,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import TodayIcon from '@mui/icons-material/Today';
import SearchIcon from '@mui/icons-material/Search';
import PeopleIcon from '@mui/icons-material/People';
import InputAdornment from '@mui/material/InputAdornment';
import { useNavigate } from 'react-router-dom';

import PageHeader from '@/components/common/PageHeader';
import type { ActionButtonConfig } from '@/components/common/PageHeader';

import CycleForm from '@/components/cycle/CycleForm';
import ReassignModal from '@/components/cycle/ReassignModal';
import {
  cycleService,
  type AssignmentResponse,
  type CycleResponse,
  type SectionInfo,
} from '@/services/cycleService';
import { personnelService } from '@/services/personnelService';
import type { PersonnelDto } from '@/types';

type ViewMode = 'day' | 'week' | 'month';

/** Predefined platoon names keyed by ID */
const PLATOON_NAMES: Record<number, string> = {
  1: 'Platoon I',
  2: 'Platoon II',
  3: 'Platoon III',
  4: 'Platoon IV',
  5: 'Platoon V',
};

/** Color palette for sections — dynamically assigned by section ID */
const SECTION_COLORS: Record<number, { bg: string; text: string; border: string }> = {
  3: { bg: '#E8F5E9', text: '#2E7D32', border: '#4CAF50' },
  4: { bg: '#E3F2FD', text: '#1565C0', border: '#2196F3' },
  5: { bg: '#FFF3E0', text: '#E65100', border: '#FF9800' },
  6: { bg: '#F3E5F5', text: '#6A1B9A', border: '#9C27B0' },
  7: { bg: '#FFEBEE', text: '#C62828', border: '#F44336' },
  8: { bg: '#E0F7FA', text: '#00695C', border: '#00BCD4' },
  9: { bg: '#FFF9C4', text: '#F57F17', border: '#FFEB3B' },
  10: { bg: '#F1F8E9', text: '#33691E', border: '#8BC34A' },
};

/** Fallback color rotation for unknown section IDs */
const FALLBACK_COLORS = [
  { bg: '#EDE7F6', text: '#4527A0', border: '#7E57C2' },
  { bg: '#FCE4EC', text: '#AD1457', border: '#EC407A' },
  { bg: '#E8EAF6', text: '#283593', border: '#5C6BC0' },
];

function getSectionColor(sectionId: number) {
  if (SECTION_COLORS[sectionId]) return SECTION_COLORS[sectionId];
  const idx = sectionId % FALLBACK_COLORS.length;
  return FALLBACK_COLORS[idx];
}

const DAY_LABELS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

/** Get Monday of the week containing the given date */
function getWeekStart(dateStr: string): Date {
  const d = new Date(dateStr + 'T00:00:00');
  const day = d.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  const monday = new Date(d);
  monday.setDate(d.getDate() + diff);
  return monday;
}

/** Get the first day of the month */
function getMonthStart(dateStr: string): Date {
  const d = new Date(dateStr + 'T00:00:00');
  return new Date(d.getFullYear(), d.getMonth(), 1);
}

/** Format date to YYYY-MM-DD */
function formatDateISO(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/** Format date for display */
function formatDateDisplay(date: Date): string {
  return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

/** Get all dates in a week starting from Monday */
function getWeekDates(monday: Date): Date[] {
  const dates: Date[] = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    dates.push(d);
  }
  return dates;
}

/** Get all dates in a month */
function getMonthDates(monthStart: Date): Date[] {
  const dates: Date[] = [];
  const year = monthStart.getFullYear();
  const month = monthStart.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  for (let i = 1; i <= daysInMonth; i++) {
    dates.push(new Date(year, month, i));
  }
  return dates;
}

/**
 * SchedulesPage — Colorful Calendar Grid for platoon cycle duty assignments.
 * Supports Day, Week, and Month views with color-coded section chips and leave alerts.
 */
const SchedulesPage: React.FC = () => {

  const navigate = useNavigate();

  // View mode
  const [viewMode, setViewMode] = useState<ViewMode>('week');
  const [currentDate, setCurrentDate] = useState<string>(
    new Date().toISOString().split('T')[0],
  );

  // Cycle + assignment state
  const [cycles, setCycles] = useState<CycleResponse[]>([]);
  const [selectedCycleId, setSelectedCycleId] = useState<number | ''>('');
  const [assignments, setAssignments] = useState<AssignmentResponse[]>([]);
  const [personnelMap, setPersonnelMap] = useState<Record<number, PersonnelDto>>({});
  const [sectionsMap, setSectionsMap] = useState<Record<number, SectionInfo>>({});

  // Loading states
  const [loadingCycles, setLoadingCycles] = useState(true);
  const [loadingAssignments, setLoadingAssignments] = useState(false);

  // Dialog states
  const [cycleFormOpen, setCycleFormOpen] = useState(false);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [selectedAssignment, setSelectedAssignment] = useState<AssignmentResponse | null>(null);

  // Pagination & search state
  const [searchQuery, setSearchQuery] = useState('');
  const [rowsPerPage, setRowsPerPage] = useState(20);
  const [currentPage, setCurrentPage] = useState(0);
  const [reassignModalOpen, setReassignModalOpen] = useState(false);

  // Leave alert dialog state
  const [leaveAlertOpen, setLeaveAlertOpen] = useState(false);
  const [autoReassignLoading, setAutoReassignLoading] = useState(false);

  // Feedback
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Derived: selected cycle object
  const selectedCycle = useMemo(
    () => cycles.find((c) => c.id === selectedCycleId) ?? null,
    [cycles, selectedCycleId],
  );

  // Derived: leave conflict count
  const leaveConflictCount = useMemo(
    () => assignments.filter((a) => a.onLeave).length,
    [assignments],
  );

  // Computed date range for current view (clamped to cycle range for month view)
  const dateRange = useMemo(() => {
    if (viewMode === 'day') {
      return { start: currentDate, end: currentDate };
    } else if (viewMode === 'week') {
      const monday = getWeekStart(currentDate);
      const sunday = new Date(monday);
      sunday.setDate(monday.getDate() + 6);
      return { start: formatDateISO(monday), end: formatDateISO(sunday) };
    } else {
      const monthStart = getMonthStart(currentDate);
      const lastDay = new Date(monthStart.getFullYear(), monthStart.getMonth() + 1, 0);
      // Clamp to cycle range so we only fetch assignments within the cycle
      const start = selectedCycle
        ? (formatDateISO(monthStart) < selectedCycle.startDate ? selectedCycle.startDate : formatDateISO(monthStart))
        : formatDateISO(monthStart);
      const end = selectedCycle
        ? (formatDateISO(lastDay) > selectedCycle.endDate ? selectedCycle.endDate : formatDateISO(lastDay))
        : formatDateISO(lastDay);
      return { start, end };
    }
  }, [viewMode, currentDate, selectedCycle]);

  // Date navigation display label
  const dateLabel = useMemo(() => {
    if (viewMode === 'day') {
      const d = new Date(currentDate + 'T00:00:00');
      return d.toLocaleDateString(undefined, {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      });
    } else if (viewMode === 'week') {
      const monday = getWeekStart(currentDate);
      const sunday = new Date(monday);
      sunday.setDate(monday.getDate() + 6);
      const startLabel = formatDateDisplay(monday);
      const endLabel = sunday.toLocaleDateString(undefined, {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      });
      return `${startLabel} – ${endLabel}`;
    } else {
      const d = new Date(currentDate + 'T00:00:00');
      return d.toLocaleDateString(undefined, { month: 'long', year: 'numeric' });
    }
  }, [viewMode, currentDate]);

  // Load active cycles on mount
  useEffect(() => {
    const fetchCycles = async () => {
      setLoadingCycles(true);
      setError(null);
      try {
        const data = await cycleService.getCycles('ACTIVE');
        setCycles(data);
        if (data.length > 0) {
          // Prefer the cycle that contains today's date (current cycle)
          const today = new Date().toISOString().split('T')[0];
          const currentCycle = data.find(c => today >= c.startDate && today <= c.endDate);
          const selected = currentCycle || data.reduce((latest, c) =>
            new Date(c.createdAt) > new Date(latest.createdAt) ? c : latest,
          );
          setSelectedCycleId(selected.id);
          // If today is outside the selected cycle's date range, navigate to its start date
          if (today < selected.startDate || today > selected.endDate) {
            setCurrentDate(selected.startDate);
          }
        }
      } catch (err: unknown) {
        const message = err instanceof Error ? err.message : 'Failed to load cycles';
        setError(message);
      } finally {
        setLoadingCycles(false);
      }
    };
    fetchCycles();
  }, []);

  // Load personnel for fallback name lookup
  useEffect(() => {
    const fetchPersonnel = async () => {
      try {
        const page = await personnelService.list(undefined, 0, 1000);
        const map: Record<number, PersonnelDto> = {};
        page.content.forEach((p) => {
          map[p.id] = p;
        });
        setPersonnelMap(map);
      } catch (err) {
        console.warn('[SchedulesPage] Failed to fetch personnel for fallback lookup:', err);
      }
    };
    fetchPersonnel();
  }, []);

  // Load sections for dynamic name display
  useEffect(() => {
    const fetchSections = async () => {
      try {
        const sections = await cycleService.getSections();
        const map: Record<number, SectionInfo> = {};
        sections.forEach((s) => {
          map[s.id] = s;
        });
        setSectionsMap(map);
      } catch (err) {
        console.warn('[SchedulesPage] Failed to fetch sections:', err);
      }
    };
    fetchSections();
  }, []);

  // Fetch assignments when cycle or date range changes
  useEffect(() => {
    if (!selectedCycleId) {
      setAssignments([]);
      return;
    }
    const fetchAssignments = async () => {
      setLoadingAssignments(true);
      try {
        let data: AssignmentResponse[];
        if (viewMode === 'day') {
          data = await cycleService.getAssignments(selectedCycleId as number, currentDate);
        } else {
          data = await cycleService.getAssignmentsByRange(
            selectedCycleId as number,
            dateRange.start,
            dateRange.end,
          );
        }
        setAssignments(data);
      } catch (err: unknown) {
        const message = err instanceof Error ? err.message : 'Failed to load assignments';
        setError(message);
      } finally {
        setLoadingAssignments(false);
      }
    };
    fetchAssignments();
  }, [selectedCycleId, viewMode, currentDate, dateRange.start, dateRange.end]);

  // Navigation handlers
  const handlePrevious = () => {
    const d = new Date(currentDate + 'T00:00:00');
    if (viewMode === 'day') {
      d.setDate(d.getDate() - 1);
    } else if (viewMode === 'week') {
      d.setDate(d.getDate() - 7);
    } else {
      d.setMonth(d.getMonth() - 1);
    }
    setCurrentDate(formatDateISO(d));
  };

  const handleNext = () => {
    const d = new Date(currentDate + 'T00:00:00');
    if (viewMode === 'day') {
      d.setDate(d.getDate() + 1);
    } else if (viewMode === 'week') {
      d.setDate(d.getDate() + 7);
    } else {
      d.setMonth(d.getMonth() + 1);
    }
    setCurrentDate(formatDateISO(d));
  };

  const handleToday = () => {
    setCurrentDate(new Date().toISOString().split('T')[0]);
  };

  // Cycle change handler
  const handleCycleChange = (cycleId: number) => {
    setSelectedCycleId(cycleId);
    const cycle = cycles.find((c) => c.id === cycleId);
    if (cycle) {
      const today = new Date().toISOString().split('T')[0];
      if (today >= cycle.startDate && today <= cycle.endDate) {
        setCurrentDate(today);
      } else {
        setCurrentDate(cycle.startDate);
      }
    }
  };

  // Get person display name — prefer from assignment response, fallback to personnelMap
  const getPersonName = useCallback(
    (assignment: AssignmentResponse) => {
      // Check assignment's personName field (from backend join)
      if (assignment.personName && assignment.personName.trim() !== '' && assignment.personName !== 'Unknown') {
        return assignment.personName;
      }
      // Fallback to personnel map
      const person = personnelMap[assignment.personId];
      if (person?.personName) return person.personName;
      // Last resort
      return `Person #${assignment.personId}`;
    },
    [personnelMap],
  );

  // Get person name by ID (for detail dialog fallback)
  const getPersonNameById = useCallback(
    (personId: number) => personnelMap[personId]?.personName ?? `Person #${personId}`,
    [personnelMap],
  );

  // Get section display name — prefer from sectionsMap, fallback to code
  const getSectionName = useCallback(
    (sectionId: number) => {
      const section = sectionsMap[sectionId];
      if (section) return section.name;
      return `Section ${sectionId}`;
    },
    [sectionsMap],
  );

  // Get badge ID for a person
  const getPersonBadge = useCallback(
    (personId: number) => personnelMap[personId]?.badgeId ?? '',
    [personnelMap],
  );

  // Row/cell click → open detail dialog
  const handleAssignmentClick = (assignment: AssignmentResponse) => {
    setSelectedAssignment(assignment);
    setDetailDialogOpen(true);
  };

  // Reassign from detail dialog — if on leave, show leave alert first
  const handleOpenReassign = () => {
    setDetailDialogOpen(false);
    if (selectedAssignment?.onLeave) {
      setLeaveAlertOpen(true);
    } else {
      setReassignModalOpen(true);
    }
  };

  // Handle manual reassign from leave alert
  const handleManualFromLeaveAlert = () => {
    setLeaveAlertOpen(false);
    setReassignModalOpen(true);
  };

  // Handle auto reassign from leave alert
  const handleAutoFromLeaveAlert = async () => {
    if (!selectedAssignment) return;
    setAutoReassignLoading(true);
    try {
      const result = await cycleService.autoReassign(selectedAssignment.id);
      setLeaveAlertOpen(false);
      setSuccessMsg(
        `Duty reassigned to ${result.newPersonName} (${result.newPersonBadgeId}) from Platoon ${result.newPersonPlatoonId}`,
      );
      // Refresh assignments
      if (selectedCycleId) {
        if (viewMode === 'day') {
          cycleService.getAssignments(selectedCycleId as number, currentDate).then(setAssignments);
        } else {
          cycleService
            .getAssignmentsByRange(selectedCycleId as number, dateRange.start, dateRange.end)
            .then(setAssignments);
        }
      }
      setSelectedAssignment(null);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Auto-reassign failed';
      setError(message);
      setLeaveAlertOpen(false);
    } finally {
      setAutoReassignLoading(false);
    }
  };

  // After reassign success, refresh assignments
  const handleReassignSuccess = () => {
    setReassignModalOpen(false);
    setSelectedAssignment(null);
    setSuccessMsg('Duty reassigned successfully.');
    if (selectedCycleId) {
      if (viewMode === 'day') {
        cycleService.getAssignments(selectedCycleId as number, currentDate).then(setAssignments);
      } else {
        cycleService
          .getAssignmentsByRange(selectedCycleId as number, dateRange.start, dateRange.end)
          .then(setAssignments);
      }
    }
  };


  // Week view data: group assignments by personId → Map<dateString, assignment>
  const weekGridData = useMemo(() => {
    if (viewMode !== 'week') return new Map<number, Map<string, AssignmentResponse>>();
    const grouped = new Map<number, Map<string, AssignmentResponse>>();
    assignments.forEach((a) => {
      if (!grouped.has(a.personId)) {
        grouped.set(a.personId, new Map());
      }
      grouped.get(a.personId)!.set(a.date, a);
    });
    return grouped;
  }, [assignments, viewMode]);

  // Filtered and paginated week grid entries
  const filteredWeekEntries = useMemo(() => {
    const entries = Array.from(weekGridData.entries());
    if (!searchQuery.trim()) return entries;
    const query = searchQuery.toLowerCase().trim();
    return entries.filter(([personId, dateMap]) => {
      // Check person name from any assignment in the row
      const firstAssignment = Array.from(dateMap.values())[0];
      const personName = firstAssignment?.personName?.toLowerCase() ?? '';
      const badgeId = personnelMap[personId]?.badgeId?.toLowerCase() ?? '';
      const fullName = personnelMap[personId]?.personName?.toLowerCase() ?? '';
      return personName.includes(query) || badgeId.includes(query) || fullName.includes(query);
    });
  }, [weekGridData, searchQuery, personnelMap]);

  const totalFilteredPersonnel = filteredWeekEntries.length;
  const totalPages = Math.max(1, Math.ceil(totalFilteredPersonnel / rowsPerPage));
  const paginatedWeekEntries = useMemo(() => {
    const start = currentPage * rowsPerPage;
    return filteredWeekEntries.slice(start, start + rowsPerPage);
  }, [filteredWeekEntries, currentPage, rowsPerPage]);

  // Reset page when search or rowsPerPage changes
  useEffect(() => { setCurrentPage(0); }, [searchQuery, rowsPerPage, selectedCycleId, viewMode]);

  // Month view data: group assignments by date → summary
  const monthGridData = useMemo(() => {
    if (viewMode !== 'month') return new Map<string, { total: number; conflicts: number }>();
    const grouped = new Map<string, { total: number; conflicts: number }>();
    assignments.forEach((a) => {
      if (!grouped.has(a.date)) {
        grouped.set(a.date, { total: 0, conflicts: 0 });
      }
      const entry = grouped.get(a.date)!;
      entry.total++;
      if (a.onLeave) entry.conflicts++;
    });
    return grouped;
  }, [assignments, viewMode]);

  // Week dates for columns
  const weekDates = useMemo(() => {
    if (viewMode !== 'week') return [];
    const monday = getWeekStart(currentDate);
    return getWeekDates(monday);
  }, [viewMode, currentDate]);

  // Month dates for rows — filtered to only show dates within the selected cycle's range
  const monthDates = useMemo(() => {
    if (viewMode !== 'month' || !selectedCycle) return [];
    const monthStart = getMonthStart(currentDate);
    const allDates = getMonthDates(monthStart);
    // Filter to only dates within the cycle's range
    return allDates.filter((date) => {
      const dateStr = formatDateISO(date);
      return dateStr >= selectedCycle.startDate && dateStr <= selectedCycle.endDate;
    });
  }, [viewMode, currentDate, selectedCycle]);

  // Switch to day view for a specific date (from month view click)
  const handleMonthDateClick = (date: Date) => {
    setCurrentDate(formatDateISO(date));
    setViewMode('day');
  };

  // View mode button styles
  const viewButtonSx = (mode: ViewMode) => ({
    textTransform: 'none' as const,
    fontWeight: viewMode === mode ? 700 : 500,
    fontSize: '0.82rem',
    px: 2,
    backgroundColor: viewMode === mode ? '#312e81' : 'transparent',
    color: viewMode === mode ? '#ffffff' : '#4B5563',
    borderColor: '#D1D5DB',
    '&:hover': {
      backgroundColor: viewMode === mode ? '#4338ca' : '#F3F4F6',
      color: viewMode === mode ? '#ffffff' : '#4B5563',
      borderColor: '#D1D5DB',
    },
  });

  /** Renders a colored section chip for the week/day grid */
  const renderSectionChip = (assignment: AssignmentResponse) => {
    const colors = getSectionColor(assignment.sectionId);
    const sectionName = getSectionName(assignment.sectionId);

    // COVERED_BY_ADHOC: show strikethrough original + orange adhoc chip
    if (assignment.status === 'COVERED_BY_ADHOC' && assignment.adhocDutyName) {
      return (
        <Tooltip title={`Original: ${sectionName} • ${assignment.shiftType} → ADHOC: ${assignment.adhocDutyName} (${assignment.adhocDutyTime || ''})`} arrow>
          <Box
            sx={{
              display: 'inline-flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: 0.3,
              px: 1,
              py: 0.4,
              borderRadius: '8px',
              backgroundColor: '#FFF3E0',
              border: '2px solid #FF9800',
              cursor: 'pointer',
              transition: 'all 0.15s ease',
              '&:hover': {
                transform: 'scale(1.05)',
                boxShadow: '0 2px 8px rgba(255,152,0,0.3)',
              },
            }}
          >
            <Typography
              variant="caption"
              sx={{
                fontWeight: 500,
                color: '#9E9E9E',
                fontSize: '0.6rem',
                lineHeight: 1.1,
                textDecoration: 'line-through',
              }}
            >
              {sectionName}
            </Typography>
            <Typography
              variant="caption"
              sx={{ fontWeight: 700, color: '#E65100', fontSize: '0.68rem', lineHeight: 1.1 }}
            >
              ADHOC: {assignment.adhocDutyName}
            </Typography>
          </Box>
        </Tooltip>
      );
    }

    if (assignment.onLeave) {
      return (
        <Tooltip title={`${sectionName} — ON LEAVE`} arrow>
          <Box
            sx={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 0.5,
              px: 1.2,
              py: 0.5,
              borderRadius: '8px',
              backgroundColor: '#FFEBEE',
              border: '2px solid #EF5350',
              cursor: 'pointer',
              transition: 'all 0.15s ease',
              '&:hover': {
                transform: 'scale(1.05)',
                boxShadow: '0 2px 8px rgba(239,83,80,0.3)',
              },
            }}
          >
            <WarningAmberIcon sx={{ fontSize: 13, color: '#D32F2F' }} />
            <Typography
              variant="caption"
              sx={{ fontWeight: 600, color: '#C62828', fontSize: '0.7rem', lineHeight: 1.2 }}
            >
              ON LEAVE
            </Typography>
          </Box>
        </Tooltip>
      );
    }

    return (
      <Tooltip title={`${sectionName} • ${assignment.shiftType}`} arrow>
        <Box
          sx={{
            display: 'inline-flex',
            alignItems: 'center',
            px: 1.2,
            py: 0.5,
            borderRadius: '8px',
            backgroundColor: colors.bg,
            border: `1.5px solid ${colors.border}`,
            cursor: 'pointer',
            transition: 'all 0.15s ease',
            '&:hover': {
              transform: 'scale(1.05)',
              boxShadow: `0 2px 8px ${colors.border}40`,
            },
          }}
        >
          <Typography
            variant="caption"
            sx={{ fontWeight: 600, color: colors.text, fontSize: '0.72rem', lineHeight: 1.2 }}
          >
            {sectionName}
          </Typography>
        </Box>
      </Tooltip>
    );
  };

  // PageHeader actions
  const headerActions: ActionButtonConfig[] = [
    {
      label: 'Cycles',
      variant: 'ghost',
      onClick: () => navigate('/schedules/cycles'),
    },
    {
      label: 'Activities',
      variant: 'ghost',
      onClick: () => navigate('/schedules/activities'),
    },
    {
      label: 'Create Cycle',
      variant: 'primary',
      icon: <AddIcon />,
      onClick: () => setCycleFormOpen(true),
    },
  ];

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        flex: 1,
        overflow: 'hidden',
        backgroundColor: '#F9FAFB',
      }}
    >
      {/* PageHeader — replaces gradient banner */}
      <PageHeader
        title="Schedules"
        breadcrumbs={[
          { label: 'Home', path: '/' },
          { label: 'Schedules' },
        ]}
        actions={headerActions}
      />

      {/* Cycle Selection & Details */}
      <Box sx={{ px: { xs: 2, md: 3 }, pt: 2, pb: 1, flexShrink: 0 }}>
        {loadingCycles ? (
          <Skeleton variant="rectangular" height={60} sx={{ borderRadius: '12px' }} />
        ) : cycles.length > 0 ? (
          <Box sx={{
            p: 2, borderRadius: '12px',
            background: 'linear-gradient(135deg, #f0fdf4 0%, #ecfdf5 50%, #f0fdfa 100%)',
            border: '1px solid #d1fae5',
          }}>
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={2} alignItems={{ md: 'center' }}>
              {/* Dropdown */}
              <FormControl size="small" sx={{ minWidth: 260, bgcolor: '#fff', borderRadius: '8px' }}>
                <Select
                  value={selectedCycleId}
                  onChange={(e) => handleCycleChange(e.target.value as number)}
                  displayEmpty
                  sx={{ borderRadius: '8px', fontWeight: 600, fontSize: '0.85rem' }}
                >
                  {[...cycles]
                    .sort((a, b) => (a.startDate > b.startDate ? -1 : 1))
                    .map((cycle) => {
                      const today = new Date().toISOString().split('T')[0];
                      const isCurrent = today >= cycle.startDate && today <= cycle.endDate;
                      return (
                        <MenuItem key={cycle.id} value={cycle.id}>
                          <Stack direction="row" spacing={1} alignItems="center">
                            <Typography fontWeight={600} fontSize="0.82rem">Cycle #{cycle.id}</Typography>
                            {isCurrent && (
                              <Box sx={{ px: 0.6, py: 0.1, borderRadius: '4px', bgcolor: '#059669', color: '#fff', fontSize: '0.55rem', fontWeight: 700 }}>
                                ACTIVE
                              </Box>
                            )}
                            <Typography fontSize="0.72rem" color="text.secondary">
                              {cycle.startDate} – {cycle.endDate}
                            </Typography>
                          </Stack>
                        </MenuItem>
                      );
                    })}
                </Select>
              </FormControl>

              {/* Cycle Info */}
              {selectedCycle && (() => {
                const today = new Date().toISOString().split('T')[0];
                const isCurrent = today >= selectedCycle.startDate && today <= selectedCycle.endDate;
                return (
                  <Stack direction="row" spacing={2} alignItems="center" sx={{ flex: 1, flexWrap: 'wrap', gap: 1 }}>
                    {/* Date & Duration */}
                    <Stack direction="row" spacing={0.5} alignItems="center">
                      <TodayIcon sx={{ fontSize: 16, color: '#059669' }} />
                      <Typography variant="body2" fontWeight={600} color="#1f2937">
                        {selectedCycle.startDate} → {selectedCycle.endDate}
                      </Typography>
                      <Chip
                        label={`${selectedCycle.rotationDays}d`}
                        size="small"
                        sx={{ height: 20, fontSize: '0.62rem', fontWeight: 700, bgcolor: '#d1fae5', color: '#065f46' }}
                      />
                      {isCurrent && (
                        <Chip
                          label="ACTIVE"
                          size="small"
                          sx={{ height: 20, fontSize: '0.6rem', fontWeight: 700, bgcolor: '#059669', color: '#fff' }}
                        />
                      )}
                    </Stack>

                    {/* Platoon Mappings */}
                    {selectedCycle.platoonSections && selectedCycle.platoonSections.length > 0 && (
                      <Stack direction="row" spacing={0.5} sx={{ flexWrap: 'wrap', gap: 0.5 }}>
                        {selectedCycle.platoonSections.map((mapping) => {
                          const sectionName = mapping.sectionIds.map((sId) => {
                            const sec = sectionsMap[sId];
                            return sec ? sec.name : `Sec ${sId}`;
                          }).join(', ');
                          const platoonPersonnel = new Set(
                            assignments.filter((a) => a.platoonId === mapping.platoonId).map((a) => a.personId)
                          ).size;
                          return (
                            <Chip
                              key={mapping.platoonId}
                              label={`P${mapping.platoonId} · ${sectionName}${platoonPersonnel ? ` (${platoonPersonnel})` : ''}`}
                              size="small"
                              variant="outlined"
                              sx={{ fontSize: '0.65rem', fontWeight: 500, height: 22, borderColor: '#a7f3d0', bgcolor: '#fff' }}
                            />
                          );
                        })}
                      </Stack>
                    )}
                  </Stack>
                );
              })()}
            </Stack>
          </Box>
        ) : null}
      </Box>

      {/* Controls Bar: View Mode + Date Navigation */}
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          gap: 2,
          px: { xs: 2, md: 3 },
          py: 1.5,
          backgroundColor: '#FFFFFF',
          borderBottom: '1px solid #E5E7EB',
          flexWrap: 'wrap',
          flexShrink: 0,
        }}
      >
        {/* View mode toggle */}
        <ButtonGroup size="small" sx={{ borderRadius: '20px', overflow: 'hidden' }}>
          <Button onClick={() => setViewMode('day')} sx={viewButtonSx('day')}>
            Day
          </Button>
          <Button onClick={() => setViewMode('week')} sx={viewButtonSx('week')}>
            Week
          </Button>
          <Button onClick={() => setViewMode('month')} sx={viewButtonSx('month')}>
            Month
          </Button>
        </ButtonGroup>

        {/* Date navigation */}
        <Stack direction="row" alignItems="center" spacing={0.5}>
          <Button size="small" onClick={handlePrevious} sx={{ minWidth: 32, px: 0.5 }}>
            <ChevronLeftIcon fontSize="small" />
          </Button>
          <Typography
            variant="body2"
            fontWeight={600}
            sx={{ minWidth: 180, textAlign: 'center', userSelect: 'none' }}
          >
            {dateLabel}
          </Typography>
          <Button size="small" onClick={handleNext} sx={{ minWidth: 32, px: 0.5 }}>
            <ChevronRightIcon fontSize="small" />
          </Button>
        </Stack>

        <Button
          size="small"
          variant="outlined"
          startIcon={<TodayIcon sx={{ fontSize: 16 }} />}
          onClick={handleToday}
          sx={{ textTransform: 'none', fontWeight: 500, borderRadius: 2 }}
        >
          Today
        </Button>

        {loadingAssignments && <CircularProgress size={18} sx={{ ml: 1 }} />}
      </Box>

      {/* Leave Conflict Alert Banner */}
      {leaveConflictCount > 0 && (
        <Alert
          severity="warning"
          icon={<WarningAmberIcon />}
          sx={{ mx: { xs: 2, md: 3 }, mt: 1.5, flexShrink: 0, borderRadius: '8px' }}
        >
          ⚠️ {leaveConflictCount} personnel {leaveConflictCount === 1 ? 'is' : 'are'} on leave
          {viewMode === 'day' ? ' today' : ' in this period'}. Click on their assignments to
          reassign.
        </Alert>
      )}

      {/* Error banner */}
      {error && (
        <Alert
          severity="error"
          onClose={() => setError(null)}
          sx={{ mx: { xs: 2, md: 3 }, mt: 1.5, flexShrink: 0, borderRadius: '8px' }}
        >
          {error}
        </Alert>
      )}

      {/* Main Content Area */}
      <Box sx={{ flex: 1, overflow: 'auto', px: { xs: 2, md: 3 }, py: 2, maxWidth: '100%' }}>
        {/* Empty state: no cycles */}
        {!loadingCycles && cycles.length === 0 && (
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              py: 10,
            }}
          >
            <Typography variant="h6" sx={{ color: '#6B7280', mb: 1, fontWeight: 500 }}>
              No active cycles
            </Typography>
            <Typography variant="body2" sx={{ color: '#9CA3AF', mb: 2 }}>
              Create one to get started.
            </Typography>
            <Button variant="contained" onClick={() => setCycleFormOpen(true)}>
              Create Cycle
            </Button>
          </Box>
        )}

        {/* Loading cycles — skeleton loading for calendar area */}
        {loadingCycles && (
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <Skeleton variant="rectangular" width="100%" height={48} sx={{ borderRadius: 2 }} />
            <Skeleton variant="rectangular" width="100%" height={300} sx={{ borderRadius: 2 }} />
          </Box>
        )}

        {/* ============ DAY VIEW ============ */}
        {!loadingCycles && selectedCycleId && viewMode === 'day' && (
          <>
            {!loadingAssignments && assignments.length === 0 && (
              <Box sx={{ textAlign: 'center', py: 8 }}>
                <Typography variant="body1" color="text.secondary">
                  No assignments found for this date.
                </Typography>
              </Box>
            )}
            {assignments.length > 0 && (
              <TableContainer
                sx={{
                  backgroundColor: '#FFFFFF',
                  borderRadius: '12px',
                  border: '1px solid #E5E7EB',
                  boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
                }}
              >
                <Table size="small">
                  <TableHead>
                    <TableRow sx={{ backgroundColor: '#F9FAFB' }}>
                      <TableCell sx={{ fontWeight: 700, fontSize: '0.8rem' }}>Personnel</TableCell>
                      <TableCell sx={{ fontWeight: 700, fontSize: '0.8rem' }}>Badge</TableCell>
                      <TableCell sx={{ fontWeight: 700, fontSize: '0.8rem' }}>Platoon</TableCell>
                      <TableCell sx={{ fontWeight: 700, fontSize: '0.8rem' }}>Section</TableCell>
                      <TableCell sx={{ fontWeight: 700, fontSize: '0.8rem' }}>Shift</TableCell>
                      <TableCell sx={{ fontWeight: 700, fontSize: '0.8rem' }}>Status</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {assignments.map((assignment, idx) => {
                      const colors = getSectionColor(assignment.sectionId);
                      return (
                        <TableRow
                          key={assignment.id}
                          hover
                          onClick={() => handleAssignmentClick(assignment)}
                          sx={{
                            cursor: 'pointer',
                            backgroundColor: idx % 2 === 0 ? '#FFFFFF' : '#FAFBFC',
                            ...(assignment.onLeave && {
                              borderLeft: '4px solid #EF4444',
                              backgroundColor: 'rgba(239, 68, 68, 0.04)',
                            }),
                            '&:hover': {
                              backgroundColor: assignment.onLeave
                                ? 'rgba(239, 68, 68, 0.08)'
                                : '#F0F4FF',
                            },
                          }}
                        >
                          <TableCell>
                            <Typography variant="body2" fontWeight={600} sx={{ color: '#1F2937' }}>
                              {getPersonName(assignment)}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Typography variant="caption" sx={{ color: '#6B7280' }}>
                              {getPersonBadge(assignment.personId)}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Typography variant="body2" sx={{ color: '#374151' }}>
                              {PLATOON_NAMES[assignment.platoonId] ?? `Platoon ${assignment.platoonId}`}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Box
                              sx={{
                                display: 'inline-flex',
                                px: 1.2,
                                py: 0.4,
                                borderRadius: '6px',
                                backgroundColor: colors.bg,
                                border: `1.5px solid ${colors.border}`,
                              }}
                            >
                              <Typography
                                variant="caption"
                                sx={{ fontWeight: 700, color: colors.text, fontSize: '0.72rem' }}
                              >
                                {getSectionName(assignment.sectionId)}
                              </Typography>
                            </Box>
                          </TableCell>
                          <TableCell>
                            <Typography variant="body2" sx={{ color: '#4B5563' }}>
                              {assignment.shiftType}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            {assignment.onLeave ? (
                              <Chip
                                icon={<WarningAmberIcon sx={{ fontSize: 14 }} />}
                                label="On Leave"
                                size="small"
                                color="error"
                              />
                            ) : assignment.isOverride ? (
                              <Chip label="Override" size="small" color="warning" variant="outlined" />
                            ) : (
                              <Chip label="Active" size="small" color="success" variant="outlined" />
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </>
        )}

        {/* ============ WEEK VIEW — Colorful Calendar Grid ============ */}
        {!loadingCycles && selectedCycleId && viewMode === 'week' && (
          <>
            {!loadingAssignments && weekGridData.size === 0 && (
              <Box sx={{ textAlign: 'center', py: 8 }}>
                <Typography variant="body1" color="text.secondary">
                  No assignments found for this week.
                </Typography>
              </Box>
            )}
            {weekGridData.size > 0 && (
              <>
                {/* Search bar + Rows per page toolbar */}
                <Box
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    mb: 1.5,
                    gap: 2,
                    flexWrap: 'wrap',
                  }}
                >
                  {/* Search bar (left) */}
                  <TextField
                    size="small"
                    placeholder="Search by name or badge ID..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    sx={{ minWidth: 280 }}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <SearchIcon sx={{ fontSize: 18, color: '#9CA3AF' }} />
                        </InputAdornment>
                      ),
                    }}
                  />
                  {/* Rows per page + pagination info (right) */}
                  <Stack direction="row" alignItems="center" spacing={1.5}>
                    <Typography variant="caption" sx={{ color: '#6B7280' }}>
                      {totalFilteredPersonnel} personnel
                    </Typography>
                    <TextField
                      select
                      size="small"
                      value={rowsPerPage}
                      onChange={(e) => setRowsPerPage(Number(e.target.value))}
                      sx={{ minWidth: 90 }}
                      label="Rows"
                    >
                      <MenuItem value={20}>20</MenuItem>
                      <MenuItem value={30}>30</MenuItem>
                      <MenuItem value={50}>50</MenuItem>
                      <MenuItem value={100}>100</MenuItem>
                    </TextField>
                    <Stack direction="row" alignItems="center" spacing={0.5}>
                      <Button
                        size="small"
                        disabled={currentPage === 0}
                        onClick={() => setCurrentPage((p) => Math.max(0, p - 1))}
                        sx={{ minWidth: 32 }}
                      >
                        <ChevronLeftIcon fontSize="small" />
                      </Button>
                      <Typography variant="caption" sx={{ color: '#374151', fontWeight: 600 }}>
                        {currentPage + 1} / {totalPages}
                      </Typography>
                      <Button
                        size="small"
                        disabled={currentPage >= totalPages - 1}
                        onClick={() => setCurrentPage((p) => Math.min(totalPages - 1, p + 1))}
                        sx={{ minWidth: 32 }}
                      >
                        <ChevronRightIcon fontSize="small" />
                      </Button>
                    </Stack>
                  </Stack>
                </Box>
              <TableContainer
                sx={{
                  backgroundColor: '#FFFFFF',
                  borderRadius: '12px',
                  border: '1px solid #E5E7EB',
                  boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
                  maxWidth: '100%',
                  overflow: 'auto',
                }}
              >
                <Table size="small" stickyHeader sx={{ minWidth: 900 }}>
                  <TableHead>
                    <TableRow>
                      <TableCell
                        sx={{
                          fontWeight: 700,
                          backgroundColor: '#F8FAFC',
                          position: 'sticky',
                          left: 0,
                          zIndex: 3,
                          minWidth: 180,
                          borderRight: '2px solid #E5E7EB',
                          fontSize: '0.8rem',
                        }}
                      >
                        Personnel
                      </TableCell>
                      {weekDates.map((date, idx) => {
                        const isToday = formatDateISO(date) === new Date().toISOString().split('T')[0];
                        return (
                          <TableCell
                            key={idx}
                            align="center"
                            sx={{
                              fontWeight: 600,
                              backgroundColor: isToday ? '#EEF2FF' : '#F8FAFC',
                              minWidth: 120,
                              borderBottom: isToday ? '3px solid #4F46E5' : undefined,
                            }}
                          >
                            <Typography
                              variant="caption"
                              display="block"
                              fontWeight={700}
                              sx={{ color: isToday ? '#4F46E5' : '#374151' }}
                            >
                              {DAY_LABELS[idx]}
                            </Typography>
                            <Typography
                              variant="caption"
                              sx={{ color: isToday ? '#4F46E5' : '#9CA3AF', fontSize: '0.7rem' }}
                            >
                              {formatDateDisplay(date)}
                            </Typography>
                          </TableCell>
                        );
                      })}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {paginatedWeekEntries.map(([personId, dateMap]) => {
                      // Get person name from any assignment in the row
                      const firstAssignment = Array.from(dateMap.values())[0];
                      const personName = firstAssignment
                        ? getPersonName(firstAssignment)
                        : getPersonNameById(personId);
                      const badgeId = getPersonBadge(personId);
                      // Ensure we always show something meaningful
                      const displayName = personName && personName !== `Person #${personId}` 
                        ? personName 
                        : (personnelMap[personId]?.personName || badgeId || `Person #${personId}`);

                      return (
                        <TableRow key={personId}>
                          <TableCell
                            sx={{
                              position: 'sticky',
                              left: 0,
                              backgroundColor: '#FFFFFF',
                              zIndex: 1,
                              borderRight: '2px solid #E5E7EB',
                              py: 1.5,
                            }}
                          >
                            <Typography
                              variant="body2"
                              fontWeight={600}
                              sx={{ color: '#1F2937', lineHeight: 1.3 }}
                            >
                              {displayName}
                            </Typography>
                            {badgeId && displayName !== badgeId && (
                              <Typography
                                variant="caption"
                                sx={{ color: '#9CA3AF', fontSize: '0.68rem' }}
                              >
                                {badgeId}
                              </Typography>
                            )}
                          </TableCell>
                          {weekDates.map((date, idx) => {
                            const dateStr = formatDateISO(date);
                            const assignment = dateMap.get(dateStr);
                            const isToday =
                              dateStr === new Date().toISOString().split('T')[0];
                            return (
                              <TableCell
                                key={idx}
                                align="center"
                                onClick={() => assignment && handleAssignmentClick(assignment)}
                                sx={{
                                  cursor: assignment ? 'pointer' : 'default',
                                  backgroundColor: isToday
                                    ? 'rgba(79, 70, 229, 0.03)'
                                    : 'transparent',
                                  borderRight: '1px solid #F3F4F6',
                                  py: 1.2,
                                  verticalAlign: 'middle',
                                }}
                              >
                                {assignment ? (
                                  renderSectionChip(assignment)
                                ) : (
                                  <Typography
                                    variant="caption"
                                    sx={{ color: '#D1D5DB', fontSize: '1rem' }}
                                  >
                                    —
                                  </Typography>
                                )}
                              </TableCell>
                            );
                          })}
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
              </>
            )}
          </>
        )}

        {/* ============ MONTH VIEW ============ */}
        {!loadingCycles && selectedCycleId && viewMode === 'month' && (
          <>
            {!loadingAssignments && monthGridData.size === 0 && (
              <Box sx={{ textAlign: 'center', py: 8 }}>
                <Typography variant="body1" color="text.secondary">
                  No assignments found for this month.
                </Typography>
              </Box>
            )}
            {monthGridData.size > 0 && (
              <TableContainer
                sx={{
                  backgroundColor: '#FFFFFF',
                  borderRadius: '12px',
                  border: '1px solid #E5E7EB',
                  boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
                }}
              >
                <Table size="small">
                  <TableHead>
                    <TableRow sx={{ backgroundColor: '#F8FAFC' }}>
                      <TableCell sx={{ fontWeight: 700, fontSize: '0.8rem' }}>Date</TableCell>
                      <TableCell sx={{ fontWeight: 700, fontSize: '0.8rem' }}>Day</TableCell>
                      <TableCell sx={{ fontWeight: 700, fontSize: '0.8rem', textAlign: 'center' }}>
                        Assignments
                      </TableCell>
                      <TableCell sx={{ fontWeight: 700, fontSize: '0.8rem', textAlign: 'center' }}>
                        Conflicts
                      </TableCell>
                      <TableCell sx={{ fontWeight: 700, fontSize: '0.8rem' }}>Status</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {monthDates.map((date, idx) => {
                      const dateStr = formatDateISO(date);
                      const summary = monthGridData.get(dateStr);
                      const hasConflicts = (summary?.conflicts ?? 0) > 0;
                      const isToday = dateStr === new Date().toISOString().split('T')[0];
                      return (
                        <TableRow
                          key={dateStr}
                          hover
                          onClick={() => handleMonthDateClick(date)}
                          sx={{
                            cursor: 'pointer',
                            backgroundColor: isToday
                              ? 'rgba(79, 70, 229, 0.04)'
                              : hasConflicts
                                ? 'rgba(239, 68, 68, 0.03)'
                                : idx % 2 === 0
                                  ? '#FFFFFF'
                                  : '#FAFBFC',
                            '&:hover': { backgroundColor: '#F0F4FF' },
                            ...(isToday && { borderLeft: '3px solid #4F46E5' }),
                          }}
                        >
                          <TableCell>
                            <Typography variant="body2" fontWeight={isToday ? 700 : 500}>
                              {date.toLocaleDateString(undefined, {
                                month: 'short',
                                day: 'numeric',
                              })}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Typography variant="body2" color="text.secondary">
                              {date.toLocaleDateString(undefined, { weekday: 'short' })}
                            </Typography>
                          </TableCell>
                          <TableCell align="center">
                            <Box
                              sx={{
                                display: 'inline-flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                width: 32,
                                height: 32,
                                borderRadius: '50%',
                                backgroundColor:
                                  (summary?.total ?? 0) > 0 ? '#E8F5E9' : '#F3F4F6',
                                fontWeight: 700,
                                fontSize: '0.82rem',
                                color: (summary?.total ?? 0) > 0 ? '#2E7D32' : '#9CA3AF',
                              }}
                            >
                              {summary?.total ?? 0}
                            </Box>
                          </TableCell>
                          <TableCell align="center">
                            {hasConflicts ? (
                              <Chip
                                icon={<WarningAmberIcon sx={{ fontSize: 14 }} />}
                                label={`${summary!.conflicts}`}
                                size="small"
                                color="error"
                                variant="outlined"
                                sx={{ fontWeight: 700 }}
                              />
                            ) : (
                              <Typography variant="body2" sx={{ color: '#D1D5DB' }}>
                                0
                              </Typography>
                            )}
                          </TableCell>
                          <TableCell>
                            {(summary?.total ?? 0) > 0 ? (
                              <Chip
                                label="Scheduled"
                                size="small"
                                sx={{
                                  backgroundColor: '#E8F5E9',
                                  color: '#2E7D32',
                                  fontWeight: 600,
                                  border: '1px solid #A5D6A7',
                                }}
                              />
                            ) : (
                              <Chip
                                label="No Data"
                                size="small"
                                sx={{
                                  backgroundColor: '#F3F4F6',
                                  color: '#9CA3AF',
                                  fontWeight: 500,
                                }}
                              />
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </>
        )}
      </Box>

      {/* Assignment Detail Dialog */}
      <Dialog
        open={detailDialogOpen}
        onClose={() => setDetailDialogOpen(false)}
        maxWidth="xs"
        fullWidth
        aria-labelledby="assignment-detail-title"
        PaperProps={{
          sx: { borderRadius: '12px' },
        }}
      >
        <DialogTitle
          id="assignment-detail-title"
          sx={{ fontWeight: 700, pb: 0.5, fontSize: '1.1rem' }}
        >
          Assignment Details
        </DialogTitle>
        <DialogContent>
          {selectedAssignment && (
            <Stack spacing={2} sx={{ mt: 1.5 }}>
              <Box
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 1.5,
                  p: 1.5,
                  borderRadius: '10px',
                  backgroundColor: '#F8FAFC',
                  border: '1px solid #E5E7EB',
                }}
              >
                <Box
                  sx={{
                    width: 40,
                    height: 40,
                    borderRadius: '50%',
                    backgroundColor: '#E8EAF6',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontWeight: 700,
                    color: '#3F51B5',
                    fontSize: '0.9rem',
                  }}
                >
                  {getPersonName(selectedAssignment).charAt(0).toUpperCase()}
                </Box>
                <Box>
                  <Typography variant="body2" fontWeight={700} sx={{ color: '#1F2937' }}>
                    {getPersonName(selectedAssignment)}
                  </Typography>
                  <Typography variant="caption" sx={{ color: '#6B7280' }}>
                    {getPersonBadge(selectedAssignment.personId)}
                  </Typography>
                </Box>
              </Box>

              <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1.5 }}>
                <Box>
                  <Typography variant="caption" color="text.secondary" fontWeight={500}>
                    Date
                  </Typography>
                  <Typography variant="body2" fontWeight={600}>
                    {new Date(selectedAssignment.date + 'T00:00:00').toLocaleDateString(undefined, {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric',
                    })}
                  </Typography>
                </Box>
                <Box>
                  <Typography variant="caption" color="text.secondary" fontWeight={500}>
                    Platoon
                  </Typography>
                  <Typography variant="body2" fontWeight={600}>
                    {PLATOON_NAMES[selectedAssignment.platoonId] ??
                      `Platoon ${selectedAssignment.platoonId}`}
                  </Typography>
                </Box>
                <Box>
                  <Typography variant="caption" color="text.secondary" fontWeight={500}>
                    Section
                  </Typography>
                  <Box sx={{ mt: 0.3 }}>
                    {(() => {
                      const colors = getSectionColor(selectedAssignment.sectionId);
                      return (
                        <Box
                          sx={{
                            display: 'inline-flex',
                            px: 1,
                            py: 0.3,
                            borderRadius: '6px',
                            backgroundColor: colors.bg,
                            border: `1.5px solid ${colors.border}`,
                          }}
                        >
                          <Typography
                            variant="caption"
                            sx={{ fontWeight: 700, color: colors.text }}
                          >
                            {getSectionName(selectedAssignment.sectionId)}
                          </Typography>
                        </Box>
                      );
                    })()}
                  </Box>
                </Box>
                <Box>
                  <Typography variant="caption" color="text.secondary" fontWeight={500}>
                    Shift
                  </Typography>
                  <Typography variant="body2" fontWeight={600}>
                    {selectedAssignment.shiftType}
                  </Typography>
                </Box>
              </Box>

              {/* Duty Type & Duty Location */}
              <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1.5 }}>
                <Box>
                  <Typography variant="caption" color="text.secondary" fontWeight={500}>
                    Duty Type
                  </Typography>
                  <Typography variant="body2" fontWeight={600}>
                    {personnelMap[selectedAssignment.personId]?.dutyType || selectedAssignment.dutyName || '—'}
                  </Typography>
                </Box>
                <Box>
                  <Typography variant="caption" color="text.secondary" fontWeight={500}>
                    Duty Location
                  </Typography>
                  <Typography variant="body2" fontWeight={600}>
                    {personnelMap[selectedAssignment.personId]?.dutyLocation || '—'}
                  </Typography>
                </Box>
              </Box>

              <Box>
                <Typography variant="caption" color="text.secondary" fontWeight={500}>
                  Status
                </Typography>
                <Box sx={{ mt: 0.5 }}>
                  {selectedAssignment.status === 'COVERED_BY_ADHOC' ? (
                    <Chip label="Covered by Adhoc Duty" size="small" color="warning" variant="filled" />
                  ) : selectedAssignment.isOverride ? (
                    <Chip label="Override" size="small" color="warning" variant="outlined" />
                  ) : (
                    <Chip label="Normal" size="small" color="default" variant="outlined" />
                  )}
                </Box>
              </Box>

              {/* Adhoc Duty Details */}
              {selectedAssignment.status === 'COVERED_BY_ADHOC' && selectedAssignment.adhocDutyName && (
                <Box sx={{
                  p: 1.5, borderRadius: '10px',
                  backgroundColor: '#FFF3E0',
                  border: '1.5px solid #FF9800',
                }}>
                  <Typography variant="caption" color="text.secondary" fontWeight={600} sx={{ mb: 0.5, display: 'block' }}>
                    🟠 Active Adhoc Duty
                  </Typography>
                  <Typography variant="body2" fontWeight={700} sx={{ color: '#E65100' }}>
                    {selectedAssignment.adhocDutyName}
                  </Typography>
                  {selectedAssignment.adhocDutyTime && (
                    <Typography variant="caption" sx={{ color: '#F57C00' }}>
                      Time: {selectedAssignment.adhocDutyTime}
                    </Typography>
                  )}
                  <Box sx={{ mt: 1, pt: 1, borderTop: '1px dashed #FFB74D' }}>
                    <Typography variant="caption" color="text.secondary" fontWeight={500}>
                      Original Duty (Inactive)
                    </Typography>
                    <Typography variant="body2" sx={{ color: '#9E9E9E', textDecoration: 'line-through' }}>
                      {getSectionName(selectedAssignment.sectionId)} — {selectedAssignment.shiftType}
                    </Typography>
                  </Box>
                </Box>
              )}

              {selectedAssignment.onLeave && (
                <Alert severity="warning" sx={{ borderRadius: '8px' }}>
                  This person is on approved leave for this date. Consider reassigning.
                </Alert>
              )}
            </Stack>
          )}
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2.5 }}>
          <Button onClick={() => setDetailDialogOpen(false)} sx={{ textTransform: 'none' }}>
            Close
          </Button>
          <Button
            variant="contained"
            color="primary"
            onClick={handleOpenReassign}
            sx={{ textTransform: 'none', fontWeight: 600, borderRadius: 2 }}
          >
            Reassign
          </Button>
        </DialogActions>
      </Dialog>

      {/* Leave Alert Dialog — shown when clicking reassign on a leave conflict */}
      <Dialog
        open={leaveAlertOpen}
        onClose={() => {
          if (!autoReassignLoading) {
            setLeaveAlertOpen(false);
            setSelectedAssignment(null);
          }
        }}
        maxWidth="xs"
        fullWidth
        PaperProps={{ sx: { borderRadius: '12px' } }}
      >
        <DialogTitle sx={{ fontWeight: 700, pb: 0.5 }}>
          Leave Conflict
        </DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <Alert severity="warning" sx={{ borderRadius: '8px' }}>
              This person is on leave. Choose an action:
            </Alert>
            {selectedAssignment && (
              <Box sx={{ pl: 1 }}>
                <Typography variant="body2" color="text.secondary">
                  <strong>Person:</strong> {getPersonName(selectedAssignment)}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  <strong>Date:</strong>{' '}
                  {new Date(selectedAssignment.date + 'T00:00:00').toLocaleDateString(undefined, {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                  })}
                </Typography>
              </Box>
            )}
          </Stack>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2.5, justifyContent: 'center', gap: 1 }}>
          <Button
            variant="outlined"
            onClick={handleManualFromLeaveAlert}
            disabled={autoReassignLoading}
            sx={{ textTransform: 'none', fontWeight: 600, borderRadius: 2 }}
          >
            Manual Reassign
          </Button>
          <Button
            variant="contained"
            color="secondary"
            onClick={handleAutoFromLeaveAlert}
            disabled={autoReassignLoading}
            startIcon={autoReassignLoading ? <CircularProgress size={16} color="inherit" /> : undefined}
            sx={{ textTransform: 'none', fontWeight: 600, borderRadius: 2 }}
          >
            {autoReassignLoading ? 'Reassigning...' : 'Auto Reassign'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Reassign Modal */}
      <ReassignModal
        open={reassignModalOpen}
        onClose={() => {
          setReassignModalOpen(false);
          setSelectedAssignment(null);
        }}
        onSuccess={handleReassignSuccess}
        assignmentId={selectedAssignment?.id ?? null}
        assignmentDate={selectedAssignment?.date ?? ''}
        currentPersonName={
          selectedAssignment ? getPersonName(selectedAssignment) : ''
        }
        showAutoOption={selectedAssignment?.onLeave ?? false}
      />

      {/* Cycle Form Dialog (Publish Schedule) */}
      <CycleForm
        open={cycleFormOpen}
        onClose={() => setCycleFormOpen(false)}
        onSuccess={() => {
          setCycleFormOpen(false);
          setSuccessMsg('Cycle created successfully!');
          cycleService.getCycles('ACTIVE').then((data) => {
            setCycles(data);
            if (data.length > 0) {
              const mostRecent = data.reduce((latest, c) =>
                new Date(c.createdAt) > new Date(latest.createdAt) ? c : latest,
              );
              setSelectedCycleId(mostRecent.id);
            }
          });
        }}
      />

      {/* Success Snackbar */}
      <Snackbar
        open={!!successMsg}
        autoHideDuration={5000}
        onClose={() => setSuccessMsg(null)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert
          onClose={() => setSuccessMsg(null)}
          severity="success"
          variant="filled"
          sx={{ width: '100%', borderRadius: '8px' }}
        >
          {successMsg}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default SchedulesPage;

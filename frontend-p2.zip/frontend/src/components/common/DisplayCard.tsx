import React from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Skeleton,
} from '@mui/material';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import { useEntranceAnimation } from '../../hooks/useEntranceAnimation';

/**
 * Props for the DisplayCard component
 */
export interface DisplayCardProps {
  /** Card title — single line, truncated with ellipsis */
  title?: string;
  /** Card subtitle — max 2 lines, truncated */
  subtitle?: string;
  /** Icon rendered in the header leading slot */
  icon?: React.ReactNode;
  /** Action menu rendered in the header trailing slot */
  actionMenu?: React.ReactNode;
  /** Metric variant: displays a large value, label, and optional trend */
  metric?: {
    value: string | number;
    label: string;
    trend?: { direction: 'up' | 'down'; percentage: number };
  };
  /** Compact mode — reduces padding and font sizes for metric cards */
  compact?: boolean;
  /** Show skeleton loading state */
  loading?: boolean;
  /** Enable entrance animation with Intersection Observer (default: true) */
  animateEntrance?: boolean;
  /** Index of this card among siblings — used for stagger delay (index * 100ms) */
  staggerIndex?: number;
  /** Additional content rendered below the header/metric area */
  children?: React.ReactNode;
}

/**
 * DisplayCard — A styled card component for dashboards and list pages.
 *
 * Features:
 * - 14px border-radius, 1px border, no shadow default state
 * - Hover: translateY(-2px), teal border, elevated shadow, 250ms transition
 * - Header slot with title truncation, subtitle max 2 lines, icon/action menu
 * - Metric variant: 2rem value, label, optional trend arrow + percentage
 * - Skeleton loading state matching card structure
 *
 * Validates: Requirements 5.1–5.4, 5.6
 */
const DisplayCard: React.FC<DisplayCardProps> = ({
  title,
  subtitle,
  icon,
  actionMenu,
  metric,
  compact = false,
  loading = false,
  animateEntrance = true,
  staggerIndex = 0,
  children,
}) => {
  const { ref, style: entranceStyle } = useEntranceAnimation({
    index: staggerIndex,
    enabled: animateEntrance && !loading,
  });
  if (loading) {
    return (
      <Card
        sx={{
          borderRadius: '14px',
          border: '1px solid',
          borderColor: 'divider',
          boxShadow: 'none',
        }}
      >
        <CardContent>
          {/* Header skeleton */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1.5 }}>
            <Skeleton variant="circular" width={24} height={24} />
            <Skeleton variant="text" width="60%" height={24} />
          </Box>
          {/* Content skeleton */}
          <Skeleton variant="rectangular" width="100%" height={48} sx={{ borderRadius: 1 }} />
          {/* Action area skeleton */}
          <Box sx={{ mt: 1.5 }}>
            <Skeleton variant="text" width="40%" height={20} />
          </Box>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card
      ref={ref as React.Ref<HTMLDivElement>}
      style={entranceStyle}
      sx={{
        borderRadius: '14px',
        border: '1px solid',
        borderColor: 'divider',
        boxShadow: 'none',
        transition: 'transform 250ms ease, border-color 250ms ease, box-shadow 250ms ease',
        '&:hover': {
          transform: 'translateY(-2px)',
          borderColor: '#0d9488',
          boxShadow: '0 4px 20px rgba(13,148,136,0.15)',
        },
        '@media (prefers-reduced-motion: reduce)': {
          transition: 'none',
          '&:hover': {
            transform: 'none',
          },
        },
      }}
    >
      <CardContent sx={compact ? { p: 1.5, '&:last-child': { pb: 1.5 } } : undefined}>
        {/* Header slot */}
        {(title || subtitle || icon || actionMenu) && (
          <Box
            sx={{
              display: 'flex',
              alignItems: 'flex-start',
              gap: 1,
              mb: metric || children ? 1.5 : 0,
            }}
          >
            {icon && (
              <Box sx={{ flexShrink: 0, display: 'flex', alignItems: 'center' }}>
                {icon}
              </Box>
            )}

            <Box sx={{ flex: 1, minWidth: 0 }}>
              {title && (
                <Typography
                  variant="subtitle1"
                  sx={{
                    fontWeight: 600,
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                  }}
                >
                  {title}
                </Typography>
              )}
              {subtitle && (
                <Typography
                  variant="body2"
                  color="text.secondary"
                  sx={{
                    display: '-webkit-box',
                    WebkitLineClamp: 2,
                    WebkitBoxOrient: 'vertical',
                    overflow: 'hidden',
                  }}
                >
                  {subtitle}
                </Typography>
              )}
            </Box>

            {actionMenu && (
              <Box sx={{ flexShrink: 0, ml: 'auto' }}>
                {actionMenu}
              </Box>
            )}
          </Box>
        )}

        {/* Metric variant */}
        {metric && (
          <Box>
            <Typography
              sx={{
                fontSize: compact ? '1.5rem' : '2rem',
                fontWeight: 700,
                lineHeight: 1.2,
              }}
            >
              {metric.value}
            </Typography>
            <Typography
              variant="body2"
              color="text.secondary"
              sx={{ mt: 0.5 }}
            >
              {metric.label}
            </Typography>
            {metric.trend && (
              <Box
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 0.5,
                  mt: 0.5,
                }}
              >
                {metric.trend.direction === 'up' ? (
                  <ArrowUpwardIcon
                    sx={{ fontSize: 16, color: '#059669' }}
                  />
                ) : (
                  <ArrowDownwardIcon
                    sx={{ fontSize: 16, color: '#e11d48' }}
                  />
                )}
                <Typography
                  variant="caption"
                  sx={{
                    fontWeight: 600,
                    color: metric.trend.direction === 'up' ? '#059669' : '#e11d48',
                  }}
                >
                  {metric.trend.percentage}%
                </Typography>
              </Box>
            )}
          </Box>
        )}

        {/* Children content */}
        {children}
      </CardContent>
    </Card>
  );
};

export default DisplayCard;

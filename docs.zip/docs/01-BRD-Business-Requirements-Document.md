# Business Requirements Document (BRD)
## KSP WorkBoard — Police Station Management System

| Field | Details |
|-------|---------|
| **Document Title** | Business Requirements Document (BRD) |
| **Application Name** | KSP WorkBoard |
| **Organization** | City Armed Reserve (CAR) Police Station, Mangalore |
| **Version** | 1.0.0 |
| **Date** | June 2026 |
| **Classification** | Internal — Restricted |
| **Status** | Final |

---

## 1. Executive Summary

### 1.1 Overview

KSP WorkBoard is an enterprise-grade, AI-powered police station management system designed and built exclusively for the City Armed Reserve (CAR) Police Station, Mangalore, Karnataka, India. The system digitizes and automates the complete operational workflow of the police station, encompassing personnel management, duty scheduling, platoon rotation cycles, leave management, ad-hoc special duty assignments, and comprehensive report generation.

The application introduces an innovative AI-powered conversational interface that enables police officers to interact with the system using natural language commands in English, Kannada (ಕನ್ನಡ), Hindi, or mixed-language inputs. This chat-first approach eliminates the need for complex navigation and allows officers — many of whom may not be technically proficient — to perform all operational tasks through simple text or voice commands.

### 1.2 Business Context

The CAR Police Station manages approximately 200+ personnel organized into multiple sections and platoons. Prior to this system, all scheduling, duty assignments, leave tracking, and reporting were handled manually using paper registers and spreadsheets. This led to:

- Frequent scheduling conflicts where personnel were double-assigned
- Delayed leave processing due to manual approval chains
- Inability to quickly generate daily strength reports (Form 168)
- No audit trail for duty reassignments
- Difficulty in managing the complex 5-platoon circular rotation system
- Time-consuming preparation of official reports required by higher authorities
- Language barriers for officers who primarily communicate in Kannada

KSP WorkBoard addresses every one of these challenges through automation, AI-assisted operations, and comprehensive digitization.

### 1.3 Business Objectives

| # | Objective | Success Metric |
|---|-----------|----------------|
| BO-1 | Eliminate manual scheduling errors | Zero double-assignment incidents per cycle |
| BO-2 | Reduce daily report generation time | From 2+ hours to under 5 minutes |
| BO-3 | Enable multilingual system access | Full Kannada + English support for all features |
| BO-4 | Provide complete audit trail | 100% traceability of all duty changes |
| BO-5 | Automate platoon rotation | Zero-touch cycle creation with auto-assignments |
| BO-6 | Streamline leave management | Same-day processing with conflict detection |
| BO-7 | Enable voice-based operations | Officers can query/operate system via voice |
| BO-8 | Generate all official reports digitally | PDF + Excel for all 6 standard report types |

---

## 2. Scope

### 2.1 In-Scope

The following functional areas are fully implemented and covered by this BRD:

1. **User Authentication & Authorization** — JWT-based login, role-based access control, session management, inactivity auto-logout
2. **Personnel Management** — Complete CRUD operations for police personnel records including badge IDs, designations, sections, duty types, contact information, vehicle details, and platoon assignments
3. **Duty Type & Section Management** — Hierarchical duty type configuration with geolocation (latitude/longitude/radius), section structure (A through G, MT, PMT)
4. **Platoon Rotation Cycle Management** — Create, update, delete rotation cycles; auto-generate platoon-to-section mappings using circular rotation algorithm; compute end dates; generate daily duty assignments
5. **Duty Assignment Engine** — Auto-generate duty assignments from cycles; manual reassignment with leave conflict validation; auto-reassignment from other platoons
6. **Leave Management** — Submit leave requests with 5 leave types; approve/reject workflow; leave conflict detection against duty assignments; cancellation support
7. **Adhoc/Special Duty Management** — Create bandobast/special duties with personnel auto-selection; preview available personnel; respect minimum strength constraints; generate duty-specific PDF/Excel reports
8. **AI Chat Interface** — Natural language interaction in English/Kannada/Hindi; LLM function calling with 30+ registered tools; voice input via STT; PDF document upload and RAG; form-based data entry through chat
9. **Report Generation** — Six standard report types in both PDF and Excel formats (Platoon Chart, Form 168, Section A, Section B, MT Section, Leave Statement)
10. **Schedule Grid View** — Calendar-based schedule visualization with shift types, open shifts, and group views
11. **Audit & Activity Logging** — Complete audit trail for cycle changes, duty reassignments, and all chat interactions
12. **Internationalization** — Server-side translation system with English and Kannada locale support
13. **System Configuration** — Admin-configurable system parameters, duty section management, holiday management

### 2.2 Out-of-Scope

The following items are NOT part of the current system:

1. Mobile native application (iOS/Android) — system is web-only (responsive)
2. Biometric attendance integration
3. GPS/real-time location tracking of personnel
4. Integration with external police databases (CCTNS, etc.)
5. Payroll or salary management
6. Court case management
7. FIR/complaint management
8. Weapon/armory inventory management
9. Vehicle fleet GPS tracking (vehicle numbers are stored but not tracked)
10. Multi-station deployment (single station only)
11. Public-facing portal for citizens

---

## 3. Stakeholders

### 3.1 Stakeholder Matrix

| Stakeholder | Role | Interest | Influence |
|-------------|------|----------|-----------|
| Station DCP (Deputy Commissioner of Police) | Primary Sponsor | Strategic oversight, report review | High |
| Station ACP (Assistant Commissioner of Police) | Secondary Sponsor | Operational decisions, leave approvals | High |
| RSI (Reserve Sub-Inspector) | Operations Manager | Day-to-day scheduling, cycle management | High |
| AHC (Assistant Head Constable) | Shift Supervisors | Duty execution, strength verification | Medium |
| APC (Armed Police Constable) | End Users | View schedules, request leave, check duties | Medium |
| IT Support Team | Technical Support | System maintenance, deployment | Medium |
| Higher Officers (HIGHER_OFFICER role) | Approval Authority | Personnel changes, leave approvals | High |
| Admin Users (ADMIN role) | System Administrators | Full system configuration, user management | High |

### 3.2 User Roles and Access Levels

| Role | System Access | Key Capabilities |
|------|--------------|------------------|
| **ADMIN** | Full system access | All CRUD operations, user management, system configuration, platoon rotation, duty section management, personnel delete |
| **HIGHER_OFFICER** | Elevated access | Personnel create/update, leave approve/reject, view all reports, schedule management |
| **GENERAL_USER** | Standard access | View personnel, view schedules, submit leave, view reports, use AI chat, contact support |

---

## 4. Functional Requirements

### 4.1 Module FR-01: Authentication & Session Management

#### FR-01.1: User Login
- The system SHALL provide a login page accepting username and password credentials.
- The system SHALL support a `loginType` parameter to distinguish different login methods.
- Upon successful authentication, the system SHALL return a JWT token, user role, display name, and preferred locale.
- The system SHALL hash all passwords using BCrypt encryption before storage.
- The system SHALL reject login attempts with invalid credentials and return an appropriate error message.

#### FR-01.2: Session Management
- The system SHALL use stateless JWT tokens with a configurable expiration (default: 24 hours / 86,400,000 ms).
- The system SHALL provide an inactivity detection dialog on the frontend that warns users before auto-logout.
- The system SHALL automatically redirect unauthenticated users to the login page.
- The system SHALL invalidate tokens on explicit logout.

#### FR-01.3: Password Management
- The system SHALL provide a change password functionality accepting old password and new password.
- The system SHALL validate the old password before allowing password change.

#### FR-01.4: Authorization
- The system SHALL enforce role-based access control on all API endpoints.
- Public endpoints: `/api/auth/login`, `/api/health/**`
- ADMIN-only endpoints: `/api/admin/**`, `POST /api/schedules/platoons/rotate`
- Method-level security: Personnel create/update requires ADMIN or HIGHER_OFFICER.
- Personnel delete requires ADMIN only.

---

### 4.2 Module FR-02: Personnel Management

#### FR-02.1: Personnel Data Model
Each personnel record SHALL contain the following attributes:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| id | Long | Auto | System-generated unique identifier |
| badgeId | String(50) | Yes | Unique badge ID in format PREFIX-NUMBER (e.g., AHC-2649) |
| personName | String(200) | Yes | Full name of the personnel |
| dutyType | String(100) | No | Current duty type assignment |
| dutyTypeId | Long | No | FK to duty_types table |
| location | String(200) | No | Assigned location |
| phoneNumber | String(20) | No | Contact phone number |
| email | String(200) | No | Email address |
| designation | String(100) | No | Rank/designation (DCP, ACP, RPI, RSI, ARSI, AHC, APC) |
| section | String(5) | Yes | Section assignment (A, B, C, D, E, F, G, MT, PMT) |
| dateOfJoining | LocalDate | No | Date of joining service |
| vehicleNumber | String(50) | No | Assigned vehicle number (MT section) |
| dutyLocation | String(200) | No | Specific duty location |
| pdms | String(100) | No | PDMS certification status (DONE, NOT DONE) |
| licenceType | String(50) | No | Driving licence type (LMV, HMV, LMV&HMV) |
| deployedFrom | String(200) | No | Original deployment unit |
| platoonId | Long | No | FK to platoons table |
| isActive | Boolean | Yes | Active/inactive status (default: true) |
| createdAt | DateTime | Auto | Record creation timestamp |
| updatedAt | DateTime | Auto | Last modification timestamp |

#### FR-02.2: Personnel List & Search
- The system SHALL provide a paginated personnel listing with configurable page size (default: 20).
- The system SHALL support filtering by: search text (name/badge/phone/email), section, duty type, designation, active status.
- The system SHALL support sorting on any column.
- The frontend SHALL render personnel in a table with search bar and filter dropdowns.

#### FR-02.3: Personnel Profile
- The system SHALL provide a detailed profile page for each personnel accessed via `/personnel/:badgeId`.
- The profile SHALL display all personnel attributes in a structured layout.
- The profile SHALL be accessible by clicking a personnel row in the list page.

#### FR-02.4: Add Personnel
- The system SHALL provide a dedicated form page at `/personnel/add` for creating new personnel records.
- Required fields: personName, badgeId, section.
- The system SHALL validate badge ID uniqueness before creation.
- Only users with ADMIN or HIGHER_OFFICER role SHALL be allowed to create personnel.

#### FR-02.5: Update Personnel
- The system SHALL allow partial updates to personnel records identified by badge ID.
- Only users with ADMIN or HIGHER_OFFICER role SHALL be allowed to update personnel.
- The system SHALL update the `updatedAt` timestamp on every modification.

#### FR-02.6: Delete Personnel
- The system SHALL support soft-delete or hard-delete of personnel records.
- Only users with ADMIN role SHALL be allowed to delete personnel.
- The system SHALL return HTTP 204 on successful deletion.

---

### 4.3 Module FR-03: Section & Duty Type Management

#### FR-03.1: Section Structure
The system SHALL organize personnel into the following sections:

| Section Code | Section Name | Type | Description |
|--------------|-------------|------|-------------|
| A | Section A | Fixed | Essential/Static duties — Guards, Chamber Sentry, Gunman, Dog Squad |
| B | Section B | Fixed | Office/Support duties — Writers, Canteen, Police Lane |
| C | Section C | Rotational | Platoon rotational duty |
| D | Section D | Rotational | Platoon rotational duty |
| E | Section E | Rotational | Platoon rotational duty |
| F | Section F | Rotational | Platoon rotational duty |
| G | Section G | Rotational | Platoon rotational duty |
| MT | Motor Transport | Fixed | Drivers and vehicle-related personnel |
| PMT | Present Strength | Fixed | Present strength tracking |

#### FR-03.2: Duty Type Hierarchy
- The system SHALL support hierarchical duty types with parent-child relationships.
- Each duty type SHALL belong to a specific section.
- Duty types SHALL have a configurable sort order for display purposes.
- Duty types SHALL optionally contain geolocation data (latitude, longitude, radius in meters).
- The default geofence radius SHALL be 500 meters.

#### FR-03.3: Duty Type CRUD (Admin)
- The system SHALL provide a DutySectionsPage at `/admin/duty-sections` accessible only to ADMIN and HIGHER_OFFICER roles.
- The page SHALL display duty types organized by section with drag-and-drop reordering capability.
- Admin users SHALL be able to create, update, and delete duty types.
- The system SHALL support Leaflet map integration for setting duty type geolocation.

---

### 4.4 Module FR-04: Platoon Rotation & Cycle Management

#### FR-04.1: Platoon Structure
- The system SHALL maintain exactly 5 platoons.
- Each platoon SHALL have a name, base offset value, and ordered position.
- Personnel in rotational sections (C-G) SHALL be assigned to exactly one platoon via `platoonId`.

#### FR-04.2: Rotation Cycle Creation
- The system SHALL allow creation of rotation cycles specifying: start date, rotation days (duration), and platoon-to-section mappings.
- When a cycle is created, the system SHALL automatically compute the end date as `startDate + rotationDays - 1`.
- The system SHALL auto-generate daily duty assignments for all personnel in the mapped platoons for the entire cycle duration.
- The system SHALL provide a "next available date" API that returns the day after the latest ACTIVE cycle ends.

#### FR-04.3: Auto-Generation of Platoon-Section Mappings
- The system SHALL implement a circular rotation algorithm where each platoon shifts to the next section in order: C→D→E→F→G→C.
- When creating a new cycle, the system SHALL look at the most recent cycle's mappings and shift each platoon by +1 section.
- If no previous cycle exists, the system SHALL use the default mapping: Platoon 1→Section C, Platoon 2→Section D, etc.
- The system SHALL expose a `/api/cycles/auto-generate` endpoint that returns the suggested next mappings.

#### FR-04.4: Cycle Lifecycle States
- Cycles SHALL have one of three statuses: ACTIVE, COMPLETED, DELETED.
- DELETE operation SHALL be a soft-delete (status set to DELETED, data preserved).
- The system SHALL support listing cycles filtered by status.

#### FR-04.5: Cycle Updates
- The system SHALL support both partial update (PATCH) and full replacement (PUT) of cycles.
- If platoon-section mappings are changed during an update, the system SHALL regenerate all duty assignments.
- All cycle modifications SHALL be recorded in the audit log.

#### FR-04.6: Cycle Management UI
- The system SHALL provide a CycleManagementPage at `/schedules/cycles`.
- The page SHALL display existing cycles in a list/table format.
- A cycle creation form SHALL present: start date field, rotation days field, and 5 platoon-to-section dropdown selectors pre-filled with auto-generated suggestions.
- The page SHALL support editing and deleting cycles.

---

### 4.5 Module FR-05: Duty Assignment & Reassignment

#### FR-05.1: Auto-Generated Assignments
- When a cycle is created, the system SHALL generate one CycleDutyAssignment record per personnel per day for the cycle duration.
- Each assignment SHALL contain: cycle ID, person ID, platoon ID, section ID, date, and override flag.

#### FR-05.2: Manual Reassignment
- The system SHALL allow manual reassignment of a specific duty assignment to a different person.
- Before reassignment, the system SHALL validate:
  - The replacement person exists in the system
  - The replacement person is NOT on approved leave for that date
  - The replacement person does NOT already have a duty assignment for the same cycle, date, and section
- If validation fails, the system SHALL return a clear error message explaining the conflict.
- Successful reassignment SHALL set the `isOverride` flag to true and update the timestamp.

#### FR-05.3: Auto-Reassignment
- The system SHALL provide an auto-reassignment feature that requires only the assignment ID.
- The system SHALL automatically find a suitable replacement by:
  1. Filtering active personnel from OTHER platoons (not the current assignment's platoon)
  2. Excluding the original person
  3. Excluding personnel already assigned for the same date in the same cycle
  4. Excluding personnel on approved leave for that date
  5. Randomly selecting from the remaining candidates
- If no candidates are available, the system SHALL return a failure message.

---

### 4.6 Module FR-06: Leave Management

#### FR-06.1: Leave Types
The system SHALL support the following leave types:

| Leave Type Code | Display Name | Description |
|-----------------|-------------|-------------|
| CASUAL_LEAVE | Casual Leave | General purpose short leave |
| SICK_LEAVE | Sick Leave | Medical/health-related leave |
| EARNED_LEAVE | Earned Leave | Accumulated service leave |
| WEEKLY_OFF | Weekly Off | Regular weekly rest day |
| COMPENSATORY_OFF | Compensatory Off | Compensation for extra duty |

#### FR-06.2: Leave Submission
- The system SHALL allow any authenticated user to submit leave requests.
- Required fields: personnelId, leaveType, startDate, endDate.
- Optional field: reason.
- The system SHALL validate that start date is not after end date.
- The system SHALL detect conflicts with existing duty assignments and notify the user.

#### FR-06.3: Leave Approval Workflow
- Leave requests SHALL have the following statuses: PENDING, APPROVED, REJECTED, CANCELLED.
- New leave requests SHALL be created in PENDING status.
- Only ADMIN and HIGHER_OFFICER users SHALL be allowed to approve or reject leave.
- Rejection SHALL require a rejection reason.
- The system SHALL track who approved/rejected each request.

#### FR-06.4: Leave Cancellation
- Personnel SHALL be able to cancel their own pending leave requests.
- Approved leave SHALL be cancellable by the requesting user or by ADMIN/HIGHER_OFFICER.

#### FR-06.5: Leave UI
- The system SHALL provide a LeaveRequestsPage at `/leave-requests`.
- The page SHALL display leave requests in a filterable, paginated table.
- Filters SHALL include: status, leave type, personnel ID, date range.

---

### 4.7 Module FR-07: Adhoc/Special Duty Management

#### FR-07.1: Adhoc Duty Creation
- The system SHALL allow creation of special/bandobast duties with the following attributes:
  - Duty name (required)
  - Date (required)
  - Start time and end time (required)
  - Required personnel count (required)
  - Location (optional)
  - Pick-from strategy: ALL_PLATOONS or SPECIFIC_PLATOONS (default: ALL_PLATOONS)
  - Specific platoon IDs (when strategy is SPECIFIC_PLATOONS)
  - Minimum strength check flag (default: true)

#### FR-07.2: Auto-Assignment of Personnel
- When an adhoc duty is created, the system SHALL automatically select and assign available personnel.
- Selection criteria:
  - Personnel must be active
  - Personnel must NOT be on approved leave for the duty date
  - Personnel must NOT already be assigned to another adhoc duty at overlapping times
  - If pick-from is SPECIFIC_PLATOONS, only personnel from specified platoons are considered
  - If minimum strength check is enabled, the system SHALL ensure pulling personnel doesn't reduce section strength below minimum
- The system SHALL track both `requiredCount` and `actualCount` (actual assigned).

#### FR-07.3: Personnel Preview
- The system SHALL provide a preview endpoint that shows available personnel for given parameters (date, time, count, pick-from strategy) WITHOUT creating the duty.
- This allows officers to verify availability before committing.

#### FR-07.4: Adhoc Duty Cancellation
- The system SHALL allow cancellation of adhoc duties.
- Cancellation SHALL release all assigned personnel back to their normal duties.
- Cancelled duties SHALL retain their data for audit purposes.

#### FR-07.5: Adhoc Duty Reports
- The system SHALL generate individual PDF and Excel reports for each adhoc duty.
- Reports SHALL include: duty details, assigned personnel list, timing information.

#### FR-07.6: Adhoc Duty UI
- The system SHALL provide an AdhocDutyPage at `/schedules/adhoc`.
- The page SHALL list existing adhoc duties filterable by date and status.
- The page SHALL provide a creation form with all required fields.

---

### 4.8 Module FR-08: AI Chat Interface

#### FR-08.1: Chat Architecture (MCP Pattern)
The AI chat system SHALL implement a Model Context Protocol (MCP) architecture consisting of:

1. **Input Gateway** — Receives user messages, sanitizes input, detects language, builds processing context
2. **Function Calling Service** — Sends user message to LLM with tool definitions; LLM returns tool name + parameters
3. **MCP Host** — Routes tool calls to appropriate MCP Server
4. **MCP Servers** — Execute domain-specific operations:
   - DomainDbMcpServer (personnel, leave, schedules, duty types, reports)
   - CycleMcpServer (cycle CRUD, reassignment, audit)
   - AdhocMcpServer (adhoc duty operations)
   - DocumentMcpServer (PDF upload, RAG queries)
   - ReportMcpServer (PDF/Excel generation)
5. **Response Builder** — Formats tool results into structured chat responses

#### FR-08.2: Input Processing
- The system SHALL sanitize all chat inputs to detect and block prompt injection attempts.
- The system SHALL detect the input language (English, Kannada, Hindi, or mixed).
- The system SHALL translate Kannada/Hindi inputs to canonical English for tool parameter extraction.
- The system SHALL respond in the user's detected language.

#### FR-08.3: Supported Chat Tools (30+)
The following tools SHALL be available through the chat interface:

**Personnel Tools:**
- `search_personnel` — Search by name, badge, keyword
- `search_by_duty_type` — Filter by duty type
- `search_by_designation` — Filter by rank
- `list_section_personnel` — List all in a section
- `get_person_by_badge` — Get person details (accepts badge ID OR name)
- `filter_personnel` — Combined criteria filter
- `add_person` — Add new personnel
- `update_personnel` — Update personnel fields
- `get_strength_summary` — Personnel counts by designation
- `search_drivers` — MT section driver search with PDMS/licence filters

**Leave Tools:**
- `create_leave` — Create leave request
- `get_leave_details` — Detailed leave list with filters
- `get_leave_count` — Leave summary by status

**Schedule Tools:**
- `get_schedule_overview` — Current deployment overview
- `get_platoon_rotation` — Platoon-to-duty mapping
- `get_today_duties` — Today's assignments by type/section

**Cycle Tools:**
- `create_cycle` — Create rotation cycle
- `list_cycles` — List cycles with status filter
- `get_cycle_details` — Cycle details by ID
- `update_cycle` — Update cycle
- `delete_cycle` — Soft-delete cycle
- `reassign_duty` — Manual reassignment
- `auto_reassign_duty` — Auto-reassignment
- `get_cycle_activities` — Audit log

**Adhoc Duty Tools:**
- `create_adhoc_duty` — Create special duty
- `list_adhoc_duties` — List adhoc duties
- `get_adhoc_duty_details` — Get details
- `cancel_adhoc_duty` — Cancel duty

**Duty Type Tools:**
- `get_duty_types` — List duty types
- `add_duty_type` — Create duty type
- `update_duty_type` — Update duty type
- `delete_duty_type` — Delete duty type

**Report Tools:**
- `generate_mt_section_pdf` — MT Section report
- `generate_section_a_pdf` — Section A report
- `generate_leave_statement_pdf` — Leave Statement report
- `generate_form_168_pdf` — Daily Statement (Form 168) report
- `generate_platoon_chart_pdf` — Platoon Chart report

#### FR-08.4: Chat Response Types
The system SHALL support the following structured response types:

| Type | Description | UI Rendering |
|------|-------------|--------------|
| `text` | Plain text message | Text bubble |
| `table` | Tabular data with columns and rows | Rendered data table |
| `form` | Interactive form with fields | Form with inputs, dropdowns, date pickers |
| `confirmation` | Success/failure notification with details | Status card with details |
| `suggestions` | Message with clickable suggestion buttons | Text + chip buttons |

#### FR-08.5: Voice Input
- The system SHALL support voice message input via audio file upload.
- Audio SHALL be transcribed using Speech-to-Text service (Groq Whisper API).
- Transcribed text SHALL be processed identically to typed text messages.
- If STT is unavailable (circuit breaker open), the system SHALL return a graceful fallback message.

#### FR-08.6: Document Upload
- The system SHALL support PDF document upload through the chat.
- Uploaded PDFs SHALL be parsed, chunked, and embedded for RAG (Retrieval-Augmented Generation).
- Users SHALL be able to query uploaded documents through natural language.

#### FR-08.7: Form Submission via Chat
- When the chat returns a form response, users SHALL be able to fill and submit it.
- Supported form actions: `create_person`, `create_leave`, `create_cycle`, `create_adhoc_duty`.
- The system SHALL validate all form submissions and return confirmation or error responses.

#### FR-08.8: Badge ID Intelligence
- The system SHALL recognize badge IDs in format PREFIX-NUMBER (e.g., AHC-2649, APC-168).
- The system SHALL normalize variations: "AHC 2649" → "AHC-2649".
- The system SHALL distinguish between designation searches ("all AHC") and badge lookups ("AHC 2649").
- The system SHALL accept person names in place of badge IDs and auto-resolve.

#### FR-08.9: Rate Limiting
- The system SHALL enforce rate limits on chat endpoints:
  - General chat: 30 requests per user per window (configurable)
  - LLM calls: 20 requests per user per window (configurable)

#### FR-08.10: Chat History
- The system SHALL persist all chat messages (user input + AI response + command type) to the database.
- Chat history SHALL be queryable per user.

---

### 4.9 Module FR-09: Report Generation

#### FR-09.1: Report Types
The system SHALL generate the following official reports:

| Report | Endpoint | Formats | Description |
|--------|----------|---------|-------------|
| Platoon Chart | `/api/reports/platoon-chart` | PDF, Excel | Current platoon rotation and duty assignments for sections C-G |
| Form 168 (Daily Statement) | `/api/reports/form-168` | PDF, Excel | Daily personnel strength and duty deployment statement |
| Section A Report | `/api/reports/section-a` | PDF, Excel | Personnel and duties in Section A (static/essential) |
| Section B Report | `/api/reports/section-b` | PDF, Excel | Personnel and duties in Section B (office/support) |
| MT Section Report | `/api/reports/mt-section` | PDF, Excel | Motor Transport section — drivers, vehicles, licence details |
| Leave Statement | `/api/reports/leave-statement` | PDF, Excel | Leave requests and status summary |
| Personnel List | `/api/reports/personnel` | PDF | Filterable personnel roster |
| Section A&B Combined | `/api/reports/section-ab` | PDF | Combined static sections report |
| Schedule Report | `/api/reports/schedules` | PDF | Current schedule overview |

#### FR-09.2: Report Parameters
- Platoon Chart SHALL accept optional date and section filter (C, D, E, F, G).
- Form 168 SHALL accept optional date (defaults to today).
- Leave Statement SHALL accept optional status and leave type filters.
- Personnel report SHALL accept section, designation, duty type, and active status filters.
- All reports SHALL accept a locale parameter (en/kn) for language selection.

#### FR-09.3: Report Generation Technology
- PDF generation SHALL use OpenPDF library.
- Excel generation SHALL use Apache POI library.
- PDF text extraction (for uploads) SHALL use Apache PDFBox.

#### FR-09.4: Report UI
- The system SHALL provide a ReportsPage at `/reports`.
- The page SHALL display all available report types with download buttons.
- Downloads SHALL trigger browser file download with appropriate filenames including date.
- Filename format: `{ReportType}_{dd-MM-yyyy}.{pdf|xlsx}`

---

### 4.10 Module FR-10: Schedule Visualization

#### FR-10.1: Schedule Overview
- The system SHALL provide a SchedulesPage at `/schedules` showing current duty deployment.
- The overview SHALL display personnel counts and assignments for Section A, Section B, and Section C (rotational).

#### FR-10.2: Rotation Management
- The system SHALL provide a RotationManagementPage at `/schedules/rotation`.
- This page SHALL display the current platoon-to-duty mapping and allow rotation operations.

#### FR-10.3: Cycle Activities/Audit
- The system SHALL provide a CycleActivitiesPage at `/schedules/activities`.
- This page SHALL display the complete audit log of all cycle-related changes.
- Each log entry SHALL show: cycle ID, action type, description, and timestamp.
- Entries SHALL be sorted by most recent first with a limit of 20 visible.

---

### 4.11 Module FR-11: Internationalization (i18n)

#### FR-11.1: Supported Locales
- The system SHALL support two locales: English (`en`) and Kannada (`kn`).
- The user's preferred locale SHALL be stored in their user profile.
- The locale SHALL be returned in the authentication response.

#### FR-11.2: Translation System
- The system SHALL maintain translations in a database table with key-value pairs.
- Each translation entry SHALL contain: translationKey, locale, translationValue, category.
- The frontend SHALL use i18next library with server-fetched translations.
- All navigation labels, form labels, and system messages SHALL be translatable.

#### FR-11.3: Chat Language Support
- The AI chat SHALL understand Kannada terms and respond in Kannada when the user inputs Kannada.
- Key Kannada terms SHALL be mapped: ರಜೆ=leave, ಸಿಬ್ಬಂದಿ=personnel, ವೇಳಾಪಟ್ಟಿ=schedule, ಕರ್ತವ್ಯ=duty, ವರದಿ=report, ಚಾಲಕರು=drivers, ಪ್ಲಟೂನ್=platoon

---

### 4.12 Module FR-12: System Administration

#### FR-12.1: Admin Dashboard
- ADMIN users SHALL have access to the Admin Configuration section in the navigation.
- The admin section SHALL be expandable/collapsible in the sidebar.

#### FR-12.2: Duty Sections Management
- The system SHALL provide a DutySectionsPage at `/admin/duty-sections` for managing duty types per section.
- This page SHALL be accessible only to ADMIN and HIGHER_OFFICER roles.

#### FR-12.3: System Configuration
- The system SHALL provide admin APIs for managing key-value system configuration.
- Configuration SHALL be modifiable without code deployment.

#### FR-12.4: Holiday Management
- The system SHALL maintain a holidays table for tracking public/gazetted holidays.
- Holidays MAY affect duty scheduling calculations.

---

## 5. Non-Functional Requirements

### 5.1 Performance (NFR-PERF)

| # | Requirement | Target |
|---|-------------|--------|
| NFR-PERF-01 | API response time for list endpoints | < 500ms (p95) |
| NFR-PERF-02 | API response time for single record retrieval | < 200ms (p95) |
| NFR-PERF-03 | Chat response time (including LLM call) | < 5 seconds (p95) |
| NFR-PERF-04 | PDF report generation | < 10 seconds |
| NFR-PERF-05 | Concurrent users supported | 50+ simultaneous |
| NFR-PERF-06 | Database query optimization | Indexed columns on all filter fields |
| NFR-PERF-07 | Response caching for repeated queries | Caffeine in-memory cache |

### 5.2 Security (NFR-SEC)

| # | Requirement | Implementation |
|---|-------------|----------------|
| NFR-SEC-01 | Authentication | JWT with configurable expiration (default 24h) |
| NFR-SEC-02 | Password storage | BCrypt hashing |
| NFR-SEC-03 | API security | All endpoints require authentication except login/health |
| NFR-SEC-04 | CORS | Configurable allowed origins |
| NFR-SEC-05 | CSRF | Disabled (stateless JWT architecture) |
| NFR-SEC-06 | Input sanitization | Prompt injection detection on all chat inputs |
| NFR-SEC-07 | PII protection | PiiFilter applied after JWT auth filter |
| NFR-SEC-08 | Rate limiting | 30 general / 20 LLM requests per user per window |
| NFR-SEC-09 | Session management | Stateless, no server-side sessions |
| NFR-SEC-10 | Role enforcement | Method-level @PreAuthorize annotations |

### 5.3 Reliability (NFR-REL)

| # | Requirement | Implementation |
|---|-------------|----------------|
| NFR-REL-01 | AI service fallback | Circuit breaker (Resilience4j) on all LLM/STT calls |
| NFR-REL-02 | Graceful degradation | Chat falls back to suggestions if LLM unavailable |
| NFR-REL-03 | Data integrity | Soft-delete for cycles (no data loss) |
| NFR-REL-04 | Audit trail | All cycle changes logged to audit table |
| NFR-REL-05 | Error handling | Structured error responses with code, message, timestamp |

### 5.4 Scalability (NFR-SCALE)

| # | Requirement | Detail |
|---|-------------|--------|
| NFR-SCALE-01 | Database | PostgreSQL with connection pooling |
| NFR-SCALE-02 | Stateless backend | Horizontal scaling possible via load balancer |
| NFR-SCALE-03 | Cache invalidation | Domain-specific cache invalidation on mutations |

### 5.5 Usability (NFR-USE)

| # | Requirement | Implementation |
|---|-------------|----------------|
| NFR-USE-01 | Responsive design | Material UI responsive breakpoints (xs, md) |
| NFR-USE-02 | Mobile navigation | Drawer-based mobile navigation |
| NFR-USE-03 | Collapsible sidebar | Desktop sidebar toggle (220px ↔ 64px) |
| NFR-USE-04 | Natural language access | AI chat for all operations |
| NFR-USE-05 | Voice access | Speech-to-text for hands-free operation |
| NFR-USE-06 | Bilingual UI | Complete English + Kannada translation |

### 5.6 Availability (NFR-AVAIL)

| # | Requirement | Target |
|---|-------------|--------|
| NFR-AVAIL-01 | System uptime | 99.5% (excluding planned maintenance) |
| NFR-AVAIL-02 | Health check endpoint | `/api/health` returns system status |
| NFR-AVAIL-03 | AI health check | `/api/health/ai` returns AI connectivity status |

---

## 6. Business Rules

### BR-01: Platoon Rotation
- There are exactly 5 platoons and 5 rotational sections (C, D, E, F, G).
- Rotation follows a circular pattern: each platoon advances to the next section in sequence.
- No platoon SHALL be assigned the same section in consecutive cycles.

### BR-02: Badge ID Format
- Badge IDs follow the format: `PREFIX-NUMBER` (e.g., AHC-2649, APC-168, RSI-01).
- Valid prefixes: DCP, ACP, RPI, RSI, ARSI, AHC, APC.
- Badge IDs must be unique across all personnel.

### BR-03: Leave Conflict Resolution
- If a person is on approved leave and has a duty assignment for the same date, the duty SHALL be reassigned.
- Auto-reassignment SHALL pick from OTHER platoons (never the same platoon).
- A person cannot be reassigned to a duty if they are on leave for that date.

### BR-04: Section Assignment Constraints
- Personnel in sections C through G MUST have a platoonId assigned.
- Personnel in sections A, B, MT do NOT participate in platoon rotation.

### BR-05: Adhoc Duty Minimum Strength
- When pulling personnel for adhoc duties, the system SHALL check that the source section/platoon maintains minimum operational strength.
- This check can be disabled per adhoc duty via the `minStrengthCheck` flag.

### BR-06: Cycle Date Continuity
- New cycles SHALL start the day after the previous ACTIVE cycle ends.
- The system SHALL prevent overlapping ACTIVE cycles.

### BR-07: Soft Delete Policy
- Cycles are soft-deleted (status = DELETED), preserving all historical data.
- Adhoc duties when cancelled retain their assignment data for audit purposes.

---

## 7. System Context Diagram

```mermaid
graph TB
    subgraph "Users"
        ADMIN[Admin User]
        HO[Higher Officer]
        GU[General User]
    end

    subgraph "KSP WorkBoard"
        FE[React Frontend<br>Vite + MUI + MobX]
        BE[Spring Boot Backend<br>Java 17]
        DB[(PostgreSQL<br>+ pgvector)]
        CACHE[Caffeine Cache]
    end

    subgraph "External Services"
        GROQ[Groq API<br>LLama 3.3 70B]
        BEDROCK[AWS Bedrock<br>Amazon Nova Lite]
        STT[Groq Whisper<br>Speech-to-Text]
    end

    ADMIN --> FE
    HO --> FE
    GU --> FE
    FE -->|REST API + JWT| BE
    BE --> DB
    BE --> CACHE
    BE -->|Function Calling| GROQ
    BE -->|Function Calling| BEDROCK
    BE -->|Audio Transcription| STT
```

---

## 8. Business Process Flows

### 8.1 Platoon Cycle Creation Flow

```mermaid
sequenceDiagram
    participant User as Officer/Admin
    participant UI as Frontend
    participant API as CycleController
    participant SVC as CycleService
    participant DB as PostgreSQL

    User->>UI: Navigate to Cycle Management
    UI->>API: GET /api/cycles/auto-generate
    API->>DB: Fetch last cycle mappings
    DB-->>API: Previous mappings
    API-->>UI: Suggested mappings (shifted +1)
    UI-->>User: Pre-filled form

    User->>UI: Adjust dates/mappings & submit
    UI->>API: POST /api/cycles
    API->>SVC: createCycle(request)
    SVC->>DB: INSERT schedule_cycles
    SVC->>DB: INSERT cycle_platoon_sections (5 rows)
    SVC->>SVC: Generate daily assignments
    SVC->>DB: BULK INSERT cycle_duty_assignments
    SVC->>DB: INSERT cycle_audit_logs
    DB-->>SVC: Success
    SVC-->>API: CycleResponse
    API-->>UI: 201 Created + response
    UI-->>User: Success confirmation
```

### 8.2 Chat Message Processing Flow

```mermaid
sequenceDiagram
    participant User as Police Officer
    participant FE as React Frontend
    participant GW as InputGatewayService
    participant SAN as InputSanitizer
    participant LANG as LanguageDetector
    participant FC as FunctionCallingService
    participant LLM as Groq/Bedrock LLM
    participant MCP as McpHost
    participant SRV as MCP Server
    participant RB as ResponseBuilder
    participant DB as Database

    User->>FE: Types message (English/Kannada)
    FE->>GW: POST /api/chat/message
    GW->>SAN: sanitize(message)
    SAN-->>GW: SanitizeResult (safe/injection)

    alt Prompt Injection Detected
        GW-->>FE: "Cannot process" error
    end

    GW->>LANG: detect(sanitizedText)
    LANG-->>GW: language + canonicalEnglish

    GW->>FC: resolveIntent(message, context)
    FC->>LLM: Chat completion with 30+ tool defs
    LLM-->>FC: tool_call(name, params)
    FC-->>GW: ActionPlan(toolName, params)

    alt Direct Response (greeting/clarification)
        GW-->>FE: Text/Suggestions response
    else Tool Selected
        GW->>MCP: dispatch(actionPlan, context)
        MCP->>SRV: executeTool(name, params, context)
        SRV->>DB: Query/Insert/Update
        DB-->>SRV: Result data
        SRV-->>MCP: McpToolResult
        MCP-->>GW: ToolExecutionResult
    end

    GW->>RB: buildResponse(results, context)
    RB-->>GW: ChatResponse (table/form/confirmation)
    GW->>DB: Save chat message to history
    GW-->>FE: Structured ChatResponse
    FE-->>User: Rendered response (table/form/text)
```

### 8.3 Leave Request with Conflict Detection Flow

```mermaid
sequenceDiagram
    participant User as Officer
    participant UI as Frontend
    participant API as LeaveController
    participant SVC as LeaveService
    participant LCD as LeaveConflictDetector
    participant DB as Database

    User->>UI: Submit leave request
    UI->>API: POST /api/leave-requests
    API->>SVC: submit(request)
    SVC->>DB: Validate personnel exists
    SVC->>DB: Check for duplicate leaves
    SVC->>LCD: checkConflicts(personnelId, dates)
    LCD->>DB: Find duty assignments in date range
    DB-->>LCD: Conflicting assignments

    alt Conflicts Found
        LCD-->>SVC: Conflict list
        SVC-->>API: Leave created with warning
        Note over SVC: Leave still created, conflicts logged
    else No Conflicts
        SVC->>DB: INSERT leave_request (PENDING)
        DB-->>SVC: Created
        SVC-->>API: LeaveRequestDto
    end

    API-->>UI: Response
    UI-->>User: Confirmation/Warning
```

### 8.4 Adhoc Duty Auto-Assignment Flow

```mermaid
sequenceDiagram
    participant User as Officer
    participant API as AdhocDutyController
    participant SVC as AdhocDutyService
    participant DB as Database

    User->>API: POST /api/adhoc-duties
    API->>SVC: createAdhocDuty(request)
    SVC->>DB: Fetch active personnel by platoon
    SVC->>DB: Check leave status for duty date
    SVC->>DB: Check existing adhoc assignments
    SVC->>SVC: Filter available candidates
    SVC->>SVC: Apply minimum strength check

    alt Sufficient Personnel Available
        SVC->>DB: INSERT adhoc_duties
        SVC->>DB: BULK INSERT adhoc_duty_assignments
        SVC-->>API: AdhocDutyResponse (actualCount/requiredCount)
    else Insufficient Personnel
        SVC->>DB: INSERT adhoc_duties (partial fill)
        SVC-->>API: Response with actualCount < requiredCount
    end

    API-->>User: Response with assignment details
```

---

## 9. Data Flow Diagram

```mermaid
flowchart LR
    subgraph "Data Sources"
        UI_INPUT[User Input<br>Text/Voice/Form]
        PDF_UPLOAD[PDF Documents]
    end

    subgraph "Processing Layer"
        SANITIZE[Input Sanitization]
        LANG_DETECT[Language Detection]
        LLM_INTENT[LLM Intent Resolution]
        TOOL_EXEC[Tool Execution<br>MCP Servers]
        RESPONSE[Response Builder]
    end

    subgraph "Data Store"
        PG[(PostgreSQL)]
        CACHE_STORE[Caffeine Cache]
        VECTOR[pgvector<br>Embeddings]
    end

    subgraph "Outputs"
        CHAT_RESP[Chat Response<br>Table/Form/Text]
        PDF_OUT[PDF Reports]
        EXCEL_OUT[Excel Reports]
    end

    UI_INPUT --> SANITIZE --> LANG_DETECT --> LLM_INTENT --> TOOL_EXEC
    PDF_UPLOAD --> VECTOR
    TOOL_EXEC --> PG
    TOOL_EXEC --> CACHE_STORE
    TOOL_EXEC --> RESPONSE
    RESPONSE --> CHAT_RESP
    PG --> PDF_OUT
    PG --> EXCEL_OUT
```

---

## 10. Constraints

### 10.1 Technical Constraints
- Java 17 runtime required (toolchain enforced in build.gradle)
- PostgreSQL database with pgvector extension required
- LLM provider required (either Groq API key or AWS Bedrock access)
- Server port configurable (default: 8080)
- Frontend dev server on port 5173 (Vite default)
- Maximum file upload size: 10MB

### 10.2 Business Constraints
- System designed for single police station (CAR, Mangalore) only
- Exactly 5 platoons in the rotation system
- Exactly 5 rotational sections (C through G)
- All times are in IST (Indian Standard Time)
- Badge ID format is fixed: PREFIX-NUMBER
- Designations are fixed: DCP, ACP, RPI, RSI, ARSI, AHC, APC

### 10.3 Regulatory/Compliance
- Personnel data is sensitive — PII filter applied to API responses
- Audit trail maintained for all duty changes (non-deletable)
- Chat history preserved for accountability

---

## 11. Assumptions

The following assumptions are evident from the codebase:

1. All users have been pre-created by an admin; there is no self-registration.
2. Personnel records are managed centrally; individual officers cannot edit their own profiles.
3. The platoon rotation pattern is strictly circular (C→D→E→F→G→C) with no exceptions.
4. One person belongs to exactly one platoon (or no platoon for fixed sections).
5. The LLM provider (Groq or Bedrock) is always available during normal operations; circuit breakers handle temporary outages.
6. Voice input audio files are in a format supported by Groq Whisper API.
7. All dates are in ISO format (yyyy-MM-dd) in the database and API layer.
8. The system operates in a single timezone (IST).
9. Internet connectivity is available for LLM API calls.
10. The PostgreSQL database has the pgvector extension installed for document embeddings.

---

## 12. Dependencies

### 12.1 External Dependencies

| Dependency | Purpose | Criticality |
|-----------|---------|-------------|
| Groq API | LLM function calling (dev) | High (chat feature) |
| AWS Bedrock | LLM function calling (prod) | High (chat feature) |
| Groq Whisper | Speech-to-text | Medium (voice feature) |
| PostgreSQL | Primary data store | Critical |
| pgvector extension | Document embeddings | Low (RAG feature) |

### 12.2 Library Dependencies (Backend)

| Library | Version | Purpose |
|---------|---------|---------|
| Spring Boot | 3.4.4 | Application framework |
| Spring Security | (managed) | Authentication/Authorization |
| Spring Data JPA | (managed) | Database access |
| JJWT | 0.12.6 | JWT token management |
| Apache POI | 5.4.0 | Excel report generation |
| OpenPDF | 2.0.3 | PDF report generation |
| PDFBox | 3.0.1 | PDF text extraction |
| Resilience4j | 2.2.0 | Circuit breakers |
| Caffeine | 3.1.8 | In-memory caching |
| pgvector | 0.1.6 | Vector embeddings |
| AWS SDK (Bedrock) | 2.25.60 | AI inference |
| Lombok | (managed) | Code generation |

### 12.3 Library Dependencies (Frontend)

| Library | Purpose |
|---------|---------|
| React 19 | UI framework |
| MUI Material 6 | Component library |
| MobX | State management |
| React Router 7 | Navigation/routing |
| Axios | HTTP client |
| i18next | Internationalization |
| Leaflet | Map visualization |
| Vite 6 | Build tool |

---

## 13. Glossary

| Term | Definition |
|------|-----------|
| CAR | City Armed Reserve — the specific police unit this system serves |
| Badge ID | Unique identifier for police personnel in format PREFIX-NUMBER |
| Platoon | A group of personnel (one of 5) that rotates through duty sections |
| Cycle | A defined period of time during which platoons are assigned to specific sections |
| Rotation | The process of moving platoons from one section to the next |
| Section | An organizational grouping of duties (A through G, MT, PMT) |
| Adhoc Duty | A one-time special duty assignment (e.g., bandobast for events) |
| Form 168 | Official daily strength statement format used by police |
| MCP | Model Context Protocol — architecture pattern for AI tool execution |
| PDMS | Professional Development Management System — driver certification status |
| LMV/HMV | Light Motor Vehicle / Heavy Motor Vehicle — licence categories |
| Bandobast | Hindi/Kannada term for special security deployment |
| STT | Speech-to-Text — audio transcription service |
| RAG | Retrieval-Augmented Generation — AI technique using uploaded documents |
| pgvector | PostgreSQL extension for vector similarity search |

---

## 14. Document Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0.0 | June 2026 | System Generated from Codebase Analysis | Initial complete BRD |

---

## 15. Approval

| Role | Name | Signature | Date |
|------|------|-----------|------|
| Project Sponsor | _____________ | _____________ | _____________ |
| Business Owner | _____________ | _____________ | _____________ |
| Technical Lead | _____________ | _____________ | _____________ |

---

*End of Document — BRD v1.0.0*

import React, { useEffect, useState } from 'react';
import {
  Box, Typography, Card, CardContent, Avatar, IconButton, Button,
  CircularProgress, Alert, Chip, Switch, FormControlLabel, MenuItem,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import EditIcon from '@mui/icons-material/Edit';
import SaveIcon from '@mui/icons-material/Save';
import CancelIcon from '@mui/icons-material/Cancel';
import CameraAltIcon from '@mui/icons-material/CameraAlt';
import EmailIcon from '@mui/icons-material/Email';
import PhoneIcon from '@mui/icons-material/Phone';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import BadgeIcon from '@mui/icons-material/Badge';
import { useTranslation } from 'react-i18next';
import { useNavigate, useParams } from 'react-router-dom';
import FormField from '@/components/FormField';
import { personnelService } from '@/services/personnelService';
import { sectionService, type SectionDto } from '@/services/sectionService';
import type { PersonnelDto, UpdatePersonnelRequest } from '@/types';

const TABS = ['details', 'contact'];
const DESIGNATIONS = ['DCP', 'ACP', 'RPI', 'RSI', 'ARSI', 'AHC', 'APC'];

const PersonnelProfilePage: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { badgeId } = useParams<{ badgeId: string }>();
  const [person, setPerson] = useState<PersonnelDto | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [sections, setSections] = useState<SectionDto[]>([]);
  const [activeTab, setActiveTab] = useState('details');
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<UpdatePersonnelRequest>({});

  useEffect(() => {
    if (!badgeId) return;
    setLoading(true);
    Promise.all([
      personnelService.getByBadgeId(badgeId),
      sectionService.list(),
    ])
      .then(([data, secs]) => { setPerson(data); setForm(data); setSections(secs); })
      .catch(() => setError('Personnel not found'))
      .finally(() => setLoading(false));
  }, [badgeId]);

  const handleSave = async () => {
    if (!badgeId) return;
    setSaving(true);
    try {
      const updated = await personnelService.update(badgeId, form);
      setPerson(updated);
      setEditing(false);
    } catch { setError(t('errors.serverError')); }
    finally { setSaving(false); }
  };

  const updateField = (field: keyof UpdatePersonnelRequest, value: string | boolean) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  if (loading) return <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}><CircularProgress /></Box>;
  if (error || !person) return (
    <Box sx={{ p: 3 }}>
      <Alert severity="error">{error || 'Not found'}</Alert>
      <Button onClick={() => navigate('/personnel')} sx={{ mt: 2 }}>Back to Personnel</Button>
    </Box>
  );

  return (
    <Box sx={{ p: 3, maxWidth: 1000, mx: 'auto' }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
        <IconButton onClick={() => navigate('/personnel')}
          sx={{ bgcolor: '#f5f2ec', '&:hover': { bgcolor: '#ede8dc' } }}>
          <ArrowBackIcon sx={{ fontSize: 20, color: '#1a1e4a' }} />
        </IconButton>
        <Typography sx={{ flex: 1, fontSize: '1.3rem', fontWeight: 700, color: '#111827' }}>
          Personnel Profile
        </Typography>
        {!editing ? (
          <Button startIcon={<EditIcon sx={{ fontSize: 16 }} />} onClick={() => setEditing(true)}
            sx={{ textTransform: 'none', fontWeight: 600, fontSize: '0.82rem', color: '#1a1e4a', bgcolor: '#f5f2ec', borderRadius: 2, px: 2, '&:hover': { bgcolor: '#ede8dc' } }}>
            Edit
          </Button>
        ) : (
          <Box sx={{ display: 'flex', gap: 1 }}>
            <Button startIcon={<CancelIcon sx={{ fontSize: 16 }} />} onClick={() => { setEditing(false); setForm(person); }}
              sx={{ textTransform: 'none', fontSize: '0.82rem', color: '#6b6b80' }}>
              Cancel
            </Button>
            <Button startIcon={saving ? <CircularProgress size={14} /> : <SaveIcon sx={{ fontSize: 16 }} />}
              onClick={handleSave} disabled={saving}
              sx={{ textTransform: 'none', fontWeight: 600, fontSize: '0.82rem', bgcolor: '#1a1e4a', color: '#fff', borderRadius: 2, px: 2, '&:hover': { bgcolor: '#0b0e2a' } }}>
              Save
            </Button>
          </Box>
        )}
      </Box>

      {/* Profile Header Card */}
      <Card variant="outlined" sx={{ borderRadius: 3, borderColor: '#f0ede6', mb: 3, overflow: 'visible' }}>
        <Box sx={{ height: 100, bgcolor: 'linear-gradient(135deg, #1a1e4a, #2a2e6a)', background: 'linear-gradient(135deg, #1a1e4a, #2a2e6a)', borderRadius: '12px 12px 0 0' }} />
        <CardContent sx={{ pt: 0, px: 3, pb: 3 }}>
          <Box sx={{ display: 'flex', gap: 3, mt: -5, flexWrap: { xs: 'wrap', sm: 'nowrap' } }}>
            {/* Avatar */}
            <Box sx={{ position: 'relative' }}>
              <Avatar sx={{
                width: 88, height: 88, bgcolor: '#c4a44a', color: '#fff',
                fontSize: '2rem', fontWeight: 700, border: '4px solid #fff',
                boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
              }}>
                {person.personName?.charAt(0)?.toUpperCase()}
              </Avatar>
              {editing && (
                <IconButton size="small" sx={{
                  position: 'absolute', bottom: 0, right: 0,
                  bgcolor: '#1a1e4a', color: '#fff', width: 28, height: 28,
                  '&:hover': { bgcolor: '#0b0e2a' },
                }}>
                  <CameraAltIcon sx={{ fontSize: 14 }} />
                </IconButton>
              )}
            </Box>
            {/* Info */}
            <Box sx={{ pt: 5, flex: 1 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 0.5 }}>
                <Typography sx={{ fontSize: '1.3rem', fontWeight: 700, color: '#111827' }}>
                  {person.personName}
                </Typography>
                <Chip label={person.designation || 'N/A'} size="small" sx={{
                  bgcolor: '#ede9fe', color: '#6d28d9', fontWeight: 600, fontSize: '0.72rem',
                }} />
                <Chip label={person.isActive ? 'Active' : 'Inactive'} size="small" sx={{
                  bgcolor: person.isActive ? '#f0fdf4' : '#fef2f2',
                  color: person.isActive ? '#166534' : '#dc2626',
                  fontWeight: 600, fontSize: '0.72rem',
                }} />
              </Box>
              <Box sx={{ display: 'flex', gap: 3, flexWrap: 'wrap', color: '#6b6b80', fontSize: '0.82rem' }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                  <BadgeIcon sx={{ fontSize: 16 }} /> {person.badgeId}
                </Box>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                  <LocationOnIcon sx={{ fontSize: 16 }} /> Section {person.section}
                </Box>
                {person.location && (
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    <LocationOnIcon sx={{ fontSize: 16 }} /> {person.location}
                  </Box>
                )}
              </Box>
            </Box>
          </Box>
        </CardContent>
      </Card>

      {/* Tabs */}
      <Box sx={{ display: 'inline-flex', gap: 0.5, p: 0.5, mb: 3, bgcolor: '#f5f2ec', borderRadius: 3 }}>
        {TABS.map(tab => (
          <Box key={tab} onClick={() => setActiveTab(tab)}
            sx={{
              px: 2.5, py: 0.8, borderRadius: 2.5, cursor: 'pointer',
              fontSize: '0.82rem', fontWeight: activeTab === tab ? 600 : 400,
              color: activeTab === tab ? '#1a1e4a' : '#6b6b80',
              bgcolor: activeTab === tab ? '#fff' : 'transparent',
              boxShadow: activeTab === tab ? '0 1px 3px rgba(0,0,0,0.08)' : 'none',
              textTransform: 'capitalize', transition: 'all 0.2s',
            }}>
            {tab}
          </Box>
        ))}
      </Box>

      {/* Tab Content */}
      {activeTab === 'details' && (
        <Card variant="outlined" sx={{ borderRadius: 3, borderColor: '#f0ede6' }}>
          <CardContent sx={{ p: 3 }}>
            <Typography sx={{ fontWeight: 600, fontSize: '0.95rem', color: '#111827', mb: 3 }}>Basic Information</Typography>
            <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr' }, gap: 2 }}>
              {editing ? (
                <>
                  <FormField labelKey="personnel.badgeId" value={form.badgeId || ''} onChange={e => updateField('badgeId', e.target.value)} />
                  <FormField labelKey="personnel.personName" value={form.personName || ''} onChange={e => updateField('personName', e.target.value)} />
                  <FormField labelKey="personnel.designation" select value={form.designation || ''} onChange={e => updateField('designation', e.target.value)}>
                    {DESIGNATIONS.map(d => <MenuItem key={d} value={d}>{d}</MenuItem>)}
                  </FormField>
                  <FormField labelKey="personnel.section" select value={form.section || ''} onChange={e => updateField('section', e.target.value)}>
                    {sections.map(s => <MenuItem key={s.code} value={s.code}>{s.name}</MenuItem>)}
                  </FormField>
                  <FormField labelKey="personnel.dutyType" value={form.dutyType || ''} onChange={e => updateField('dutyType', e.target.value)} />
                  <FormField labelKey="personnel.location" value={form.location || ''} onChange={e => updateField('location', e.target.value)} />
                  <FormField labelKey="personnel.dateOfJoining" type="date" value={form.dateOfJoining || ''} onChange={e => updateField('dateOfJoining', e.target.value)} InputLabelProps={{ shrink: true }} />
                </>
              ) : (
                <>
                  {[
                    { label: 'Name', value: person.personName },
                    { label: 'Designation', value: person.designation },
                    { label: 'Section', value: `Section ${person.section}` },
                    { label: 'Duty Type', value: person.dutyType },
                    { label: 'Location', value: person.location },
                    { label: 'Date of Joining', value: person.dateOfJoining },
                  ].map(item => (
                    <Box key={item.label}>
                      <Typography sx={{ fontSize: '0.72rem', fontWeight: 600, color: '#9ca3af', textTransform: 'uppercase', mb: 0.3 }}>{item.label}</Typography>
                      <Typography sx={{ fontSize: '0.88rem', color: '#111827', fontWeight: 500 }}>{item.value || '—'}</Typography>
                    </Box>
                  ))}
                </>
              )}
            </Box>
            {editing && (
              <FormControlLabel sx={{ mt: 2 }}
                control={<Switch checked={form.isActive !== false} onChange={e => updateField('isActive', e.target.checked)} />}
                label={<Typography sx={{ fontSize: '0.85rem' }}>Active</Typography>}
              />
            )}
          </CardContent>
        </Card>
      )}

      {activeTab === 'contact' && (
        <Card variant="outlined" sx={{ borderRadius: 3, borderColor: '#f0ede6' }}>
          <CardContent sx={{ p: 3 }}>
            <Typography sx={{ fontWeight: 600, fontSize: '0.95rem', color: '#111827', mb: 3 }}>Contact Information</Typography>
            {editing ? (
              <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 2 }}>
                <FormField labelKey="personnel.phoneNumber" value={form.phoneNumber || ''} onChange={e => updateField('phoneNumber', e.target.value)} />
                <FormField labelKey="personnel.email" value={form.email || ''} onChange={e => updateField('email', e.target.value)} />
              </Box>
            ) : (
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 2, borderRadius: 2, bgcolor: '#f9fafb', border: '1px solid #f0ede6' }}>
                  <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: '#dbeafe', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <PhoneIcon sx={{ fontSize: 20, color: '#1d4ed8' }} />
                  </Box>
                  <Box sx={{ flex: 1 }}>
                    <Typography sx={{ fontSize: '0.72rem', color: '#9ca3af', textTransform: 'uppercase', fontWeight: 600 }}>Phone</Typography>
                    <Typography sx={{ fontSize: '0.88rem', color: '#111827', fontWeight: 500 }}>{person.phoneNumber || '—'}</Typography>
                  </Box>
                  {person.phoneNumber && (
                    <Button size="small" sx={{ textTransform: 'none', fontSize: '0.78rem', color: '#1a1e4a' }}>
                      Message
                    </Button>
                  )}
                </Box>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 2, borderRadius: 2, bgcolor: '#f9fafb', border: '1px solid #f0ede6' }}>
                  <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: '#fef3c7', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <EmailIcon sx={{ fontSize: 20, color: '#d97706' }} />
                  </Box>
                  <Box sx={{ flex: 1 }}>
                    <Typography sx={{ fontSize: '0.72rem', color: '#9ca3af', textTransform: 'uppercase', fontWeight: 600 }}>Email</Typography>
                    <Typography sx={{ fontSize: '0.88rem', color: '#111827', fontWeight: 500 }}>{person.email || '—'}</Typography>
                  </Box>
                  {person.email && (
                    <Button size="small" sx={{ textTransform: 'none', fontSize: '0.78rem', color: '#1a1e4a' }}
                      onClick={() => window.open(`mailto:${person.email}`)}>
                      Send Email
                    </Button>
                  )}
                </Box>
              </Box>
            )}
          </CardContent>
        </Card>
      )}


    </Box>
  );
};

export default PersonnelProfilePage;

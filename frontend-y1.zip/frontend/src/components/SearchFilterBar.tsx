import React from 'react';
import { observer } from 'mobx-react-lite';
import {
  TextField,
  Select,
  MenuItem,
  Button,
  InputAdornment,
  FormControl,
  Box,
  type SelectChangeEvent,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import TableChartIcon from '@mui/icons-material/TableChart';
import CircularProgress from '@mui/material/CircularProgress';
import { useTranslation } from 'react-i18next';
import { dutySectionStore } from '@/stores/dutySectionStore';
import { dutyTypeService, dutySectionApiService } from '@/services/dutySectionService';
import { exportDutyTypesPdf, exportDutyTypesExcel } from '@/utils/dutyReportExport';

/** Common police/paramilitary ranks used in Karnataka State Police */
const RANK_OPTIONS = ['DySP', 'Inspector', 'SI', 'ASI', 'HC', 'PC', 'Driver'];

/**
 * SearchFilterBar — Compact single-row filter bar.
 * Search left (flex:1), Rank dropdown, Location dropdown, PDF button, Excel button.
 */
const SearchFilterBar: React.FC = observer(() => {
  const { t } = useTranslation();
  const [exporting, setExporting] = React.useState<'pdf' | 'excel' | null>(null);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    dutySectionStore.setSearchQuery(e.target.value);
  };

  const handleRankChange = (e: SelectChangeEvent<string>) => {
    const value = e.target.value;
    dutySectionStore.setRankFilter(value === '' ? null : value);
  };

  const handleLocationChange = (e: SelectChangeEvent<string>) => {
    dutySectionStore.setLocationFilter(e.target.value as 'all' | 'pinned' | 'unpinned');
  };

  const handleExportPdf = async () => {
    setExporting('pdf');
    try {
      const [allDutyTypes, allSections] = await Promise.all([
        dutyTypeService.list(),
        dutySectionApiService.listActive(),
      ]);
      // Filter sections based on selected unit
      const unitSections = allSections.filter((s) => {
        if (dutySectionStore.selectedUnit === 'MT') return s.code === 'MT';
        return s.code !== 'MT' && s.code !== 'PMT';
      });
      const sections = unitSections.map((s) => ({ code: s.code, name: s.name }));
      // Filter duty types to only those in the unit's sections
      const sectionCodes = new Set(sections.map((s) => s.code));
      const filteredDutyTypes = allDutyTypes.filter((dt) => sectionCodes.has(dt.section));
      exportDutyTypesPdf(filteredDutyTypes, sections, null);
    } catch (err) {
      console.error('PDF export failed:', err);
    } finally {
      setExporting(null);
    }
  };

  const handleExportExcel = async () => {
    setExporting('excel');
    try {
      const [allDutyTypes, allSections] = await Promise.all([
        dutyTypeService.list(),
        dutySectionApiService.listActive(),
      ]);
      // Filter sections based on selected unit
      const unitSections = allSections.filter((s) => {
        if (dutySectionStore.selectedUnit === 'MT') return s.code === 'MT';
        return s.code !== 'MT' && s.code !== 'PMT';
      });
      const sections = unitSections.map((s) => ({ code: s.code, name: s.name }));
      // Filter duty types to only those in the unit's sections
      const sectionCodes = new Set(sections.map((s) => s.code));
      const filteredDutyTypes = allDutyTypes.filter((dt) => sectionCodes.has(dt.section));
      exportDutyTypesExcel(filteredDutyTypes, sections, null);
    } catch (err) {
      console.error('Excel export failed:', err);
    } finally {
      setExporting(null);
    }
  };

  return (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        gap: 1.5,
        px: 2,
        py: 1.25,
        backgroundColor: 'white',
        borderRadius: 2,
        border: '1px solid',
        borderColor: '#E2E8F0',
        boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
      }}
    >
      {/* Search TextField — flex:1 to fill space */}
      <TextField
        size="small"
        variant="outlined"
        placeholder={t('admin.dutySections.searchPlaceholder', 'Search name or ID...')}
        value={dutySectionStore.searchQuery}
        onChange={handleSearchChange}
        sx={{
          flex: 1,
          minWidth: 180,
          '& .MuiOutlinedInput-root': {
            borderRadius: 2,
            backgroundColor: '#F8FAFC',
            height: 38,
            '&:hover': { backgroundColor: '#F1F5F9' },
            '&.Mui-focused': { backgroundColor: 'white' },
          },
        }}
        slotProps={{
          input: {
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon fontSize="small" sx={{ color: '#94A3B8' }} />
              </InputAdornment>
            ),
          },
        }}
      />

      {/* Rank Select */}
      <FormControl size="small" sx={{ minWidth: 120 }}>
        <Select
          displayEmpty
          value={dutySectionStore.rankFilter ?? ''}
          onChange={handleRankChange}
          sx={{
            borderRadius: 2,
            height: 38,
            backgroundColor: '#F8FAFC',
            '& .MuiSelect-select': { py: 1 },
            '&:hover': { backgroundColor: '#F1F5F9' },
          }}
        >
          <MenuItem value="">
            {t('admin.dutySections.allRanks', 'All Ranks')}
          </MenuItem>
          {RANK_OPTIONS.map((rank) => (
            <MenuItem key={rank} value={rank}>
              {rank}
            </MenuItem>
          ))}
        </Select>
      </FormControl>

      {/* Location Select */}
      <FormControl size="small" sx={{ minWidth: 130 }}>
        <Select
          displayEmpty
          value={dutySectionStore.locationFilter}
          onChange={handleLocationChange}
          sx={{
            borderRadius: 2,
            height: 38,
            backgroundColor: '#F8FAFC',
            '& .MuiSelect-select': { py: 1 },
            '&:hover': { backgroundColor: '#F1F5F9' },
          }}
        >
          <MenuItem value="all">
            {t('admin.dutySections.allLocations', 'All Locations')}
          </MenuItem>
          <MenuItem value="pinned">{t('admin.dutySections.pinned', 'Pinned')}</MenuItem>
          <MenuItem value="unpinned">{t('admin.dutySections.unpinned', 'Unpinned')}</MenuItem>
        </Select>
      </FormControl>

      {/* PDF Download Button */}
      <Button
        variant="contained"
        size="small"
        startIcon={exporting === 'pdf' ? <CircularProgress size={14} color="inherit" /> : <PictureAsPdfIcon sx={{ fontSize: 16 }} />}
        onClick={handleExportPdf}
        disabled={exporting !== null}
        sx={{
          height: 38,
          borderRadius: 2,
          textTransform: 'none',
          fontSize: '0.8rem',
          fontWeight: 600,
          backgroundColor: '#DC2626',
          boxShadow: 'none',
          px: 2,
          '&:hover': { backgroundColor: '#B91C1C', boxShadow: '0 2px 6px rgba(220,38,38,0.3)' },
        }}
      >
        PDF
      </Button>

      {/* Excel Download Button */}
      <Button
        variant="contained"
        size="small"
        startIcon={exporting === 'excel' ? <CircularProgress size={14} color="inherit" /> : <TableChartIcon sx={{ fontSize: 16 }} />}
        onClick={handleExportExcel}
        disabled={exporting !== null}
        sx={{
          height: 38,
          borderRadius: 2,
          textTransform: 'none',
          fontSize: '0.8rem',
          fontWeight: 600,
          backgroundColor: '#16A34A',
          boxShadow: 'none',
          px: 2,
          '&:hover': { backgroundColor: '#15803D', boxShadow: '0 2px 6px rgba(22,163,74,0.3)' },
        }}
      >
        Excel
      </Button>
    </Box>
  );
});

export default SearchFilterBar;

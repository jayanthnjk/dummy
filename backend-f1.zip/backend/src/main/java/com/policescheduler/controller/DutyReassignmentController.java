package com.policescheduler.controller;

import com.policescheduler.entity.DutyReassignment;
import com.policescheduler.entity.Personnel;
import com.policescheduler.repository.DutyReassignmentRepository;
import com.policescheduler.repository.PersonnelRepository;
import com.policescheduler.service.ReassignmentResolverService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

/**
 * REST controller for duty reassignments.
 * When a person goes on leave, another person can be reassigned to cover their duty.
 */
@RestController
@RequestMapping("/api/duty-reassignments")
public class DutyReassignmentController {

    private final DutyReassignmentRepository reassignmentRepository;
    private final PersonnelRepository personnelRepository;
    private final ReassignmentResolverService reassignmentResolverService;

    public DutyReassignmentController(DutyReassignmentRepository reassignmentRepository,
                                       PersonnelRepository personnelRepository,
                                       ReassignmentResolverService reassignmentResolverService) {
        this.reassignmentRepository = reassignmentRepository;
        this.personnelRepository = personnelRepository;
        this.reassignmentResolverService = reassignmentResolverService;
    }

    /**
     * POST /api/duty-reassignments/expire
     * Expires all ACTIVE reassignments whose endDate has passed.
     * Called from the frontend when the user lands on the Conversation/Home page.
     */
    @PostMapping("/expire")
    public ResponseEntity<Map<String, Object>> expireOverdue() {
        int count = reassignmentResolverService.expireOverdueReassignments();
        return ResponseEntity.ok(Map.of("expiredCount", count));
    }

    /**
     * GET /api/duty-reassignments?sectionCode=A
     * Returns active reassignments for a section (where today is within date range).
     */
    @GetMapping
    public ResponseEntity<List<Map<String, Object>>> getActiveReassignments(
            @RequestParam String sectionCode) {
        LocalDate today = LocalDate.now();
        List<DutyReassignment> active = reassignmentRepository.findActiveBySectionAndDate(sectionCode, today);
        List<Map<String, Object>> result = active.stream()
                .map(this::toDto)
                .collect(Collectors.toList());
        return ResponseEntity.ok(result);
    }

    /**
     * GET /api/duty-reassignments/all?sectionCode=A
     * Returns ALL active reassignments for a section (for history view).
     */
    @GetMapping("/all")
    public ResponseEntity<List<Map<String, Object>>> getAllReassignments(
            @RequestParam String sectionCode) {
        List<DutyReassignment> all = reassignmentRepository.findBySectionCodeAndStatus(sectionCode, "ACTIVE");
        List<Map<String, Object>> result = all.stream()
                .map(this::toDto)
                .collect(Collectors.toList());
        return ResponseEntity.ok(result);
    }

    /**
     * POST /api/duty-reassignments
     * Creates a new reassignment.
     * Body: { leavePersonId, replacementPersonId, leaveRequestId, sectionCode,
     *         dutyType, dutyLocation, startDate, endDate }
     */
    @PostMapping
    public ResponseEntity<?> createReassignment(@RequestBody Map<String, Object> request) {
        Long leavePersonId = toLong(request.get("leavePersonId"));
        Long replacementPersonId = toLong(request.get("replacementPersonId"));
        Long leaveRequestId = request.get("leaveRequestId") != null ? toLong(request.get("leaveRequestId")) : null;
        String sectionCode = (String) request.get("sectionCode");
        String dutyType = (String) request.get("dutyType");
        String dutyLocation = (String) request.get("dutyLocation");
        String startDateStr = (String) request.get("startDate");
        String endDateStr = (String) request.get("endDate");

        if (leavePersonId == null || replacementPersonId == null || sectionCode == null
                || startDateStr == null || endDateStr == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Missing required fields"));
        }

        LocalDate startDate = LocalDate.parse(startDateStr);
        LocalDate endDate = LocalDate.parse(endDateStr);

        if (endDate.isBefore(startDate)) {
            return ResponseEntity.badRequest().body(Map.of("error", "End date cannot be before start date"));
        }

        // Validate personnel exist
        Personnel leavePerson = personnelRepository.findById(leavePersonId).orElse(null);
        Personnel replacementPerson = personnelRepository.findById(replacementPersonId).orElse(null);
        if (leavePerson == null || replacementPerson == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Personnel not found"));
        }

        // Validation: For sections C, D, E, F, G — replacement person cannot be from Section A or B
        String sectionUpper = sectionCode.toUpperCase().trim();
        if (Set.of("C", "D", "E", "F", "G").contains(sectionUpper)) {
            String replacementSection = replacementPerson.getSection() != null ? replacementPerson.getSection().toUpperCase().trim() : "";
            if ("A".equals(replacementSection) || "B".equals(replacementSection)
                    || replacementSection.contains("SECTION A") || replacementSection.contains("SECTION B")) {
                return ResponseEntity.badRequest().body(Map.of("error",
                        "Cannot assign Section A or Section B personnel as replacement in Section " + sectionUpper
                                + ". Only personnel from sections C, D, E, F, G can be used as replacements."));
            }
        }

        DutyReassignment reassignment = new DutyReassignment();
        reassignment.setLeavePersonId(leavePersonId);
        reassignment.setReplacementPersonId(replacementPersonId);
        reassignment.setLeaveRequestId(leaveRequestId);
        reassignment.setSectionCode(sectionCode);
        reassignment.setDutyType(dutyType);
        reassignment.setDutyLocation(dutyLocation);
        reassignment.setStartDate(startDate);
        reassignment.setEndDate(endDate);
        reassignment.setStatus("ACTIVE");

        DutyReassignment saved = reassignmentRepository.save(reassignment);
        return ResponseEntity.status(HttpStatus.CREATED).body(toDto(saved));
    }

    /**
     * DELETE /api/duty-reassignments/{id}
     * Cancels a reassignment (sets status to CANCELLED).
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> cancelReassignment(@PathVariable Long id) {
        DutyReassignment reassignment = reassignmentRepository.findById(id).orElse(null);
        if (reassignment == null) {
            return ResponseEntity.notFound().build();
        }
        reassignment.setStatus("CANCELLED");
        reassignmentRepository.save(reassignment);
        return ResponseEntity.ok(Map.of("message", "Reassignment cancelled", "id", id));
    }

    /**
     * PUT /api/duty-reassignments/{id}
     * Updates an existing reassignment (change replacement person and/or dates).
     * Body: { replacementPersonId, startDate, endDate }
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> updateReassignment(@PathVariable Long id, @RequestBody Map<String, Object> request) {
        DutyReassignment reassignment = reassignmentRepository.findById(id).orElse(null);
        if (reassignment == null) {
            return ResponseEntity.notFound().build();
        }

        if (!"ACTIVE".equals(reassignment.getStatus())) {
            return ResponseEntity.badRequest().body(Map.of("error", "Can only edit active reassignments"));
        }

        Long replacementPersonId = request.get("replacementPersonId") != null ? toLong(request.get("replacementPersonId")) : null;
        String startDateStr = (String) request.get("startDate");
        String endDateStr = (String) request.get("endDate");

        if (replacementPersonId != null) {
            Personnel replacementPerson = personnelRepository.findById(replacementPersonId).orElse(null);
            if (replacementPerson == null) {
                return ResponseEntity.badRequest().body(Map.of("error", "Replacement personnel not found"));
            }

            // Validation: For sections C, D, E, F, G — replacement person cannot be from Section A or B
            String sectionUpper = reassignment.getSectionCode() != null ? reassignment.getSectionCode().toUpperCase().trim() : "";
            if (Set.of("C", "D", "E", "F", "G").contains(sectionUpper)) {
                String replacementSection = replacementPerson.getSection() != null ? replacementPerson.getSection().toUpperCase().trim() : "";
                if ("A".equals(replacementSection) || "B".equals(replacementSection)
                        || replacementSection.contains("SECTION A") || replacementSection.contains("SECTION B")) {
                    return ResponseEntity.badRequest().body(Map.of("error",
                            "Cannot assign Section A or Section B personnel as replacement in Section " + sectionUpper
                                    + ". Only personnel from sections C, D, E, F, G can be used as replacements."));
                }
            }

            reassignment.setReplacementPersonId(replacementPersonId);
        }

        if (startDateStr != null) {
            reassignment.setStartDate(LocalDate.parse(startDateStr));
        }
        if (endDateStr != null) {
            reassignment.setEndDate(LocalDate.parse(endDateStr));
        }

        if (reassignment.getEndDate().isBefore(reassignment.getStartDate())) {
            return ResponseEntity.badRequest().body(Map.of("error", "End date cannot be before start date"));
        }

        DutyReassignment saved = reassignmentRepository.save(reassignment);
        return ResponseEntity.ok(toDto(saved));
    }

    private Map<String, Object> toDto(DutyReassignment r) {
        Map<String, Object> dto = new LinkedHashMap<>();
        dto.put("id", r.getId());
        dto.put("leavePersonId", r.getLeavePersonId());
        dto.put("replacementPersonId", r.getReplacementPersonId());
        dto.put("leaveRequestId", r.getLeaveRequestId());
        dto.put("sectionCode", r.getSectionCode());
        dto.put("dutyType", r.getDutyType());
        dto.put("dutyLocation", r.getDutyLocation());
        dto.put("startDate", r.getStartDate().toString());
        dto.put("endDate", r.getEndDate().toString());
        dto.put("days", ChronoUnit.DAYS.between(r.getStartDate(), r.getEndDate()) + 1);
        dto.put("status", r.getStatus());
        dto.put("createdAt", r.getCreatedAt() != null ? r.getCreatedAt().toString() : null);

        // Resolve person names
        Personnel leavePerson = personnelRepository.findById(r.getLeavePersonId()).orElse(null);
        Personnel replacementPerson = personnelRepository.findById(r.getReplacementPersonId()).orElse(null);
        dto.put("leavePersonName", leavePerson != null ? leavePerson.getPersonName() : null);
        dto.put("leavePersonBadgeId", leavePerson != null ? leavePerson.getBadgeId() : null);
        dto.put("replacementPersonName", replacementPerson != null ? replacementPerson.getPersonName() : null);
        dto.put("replacementPersonBadgeId", replacementPerson != null ? replacementPerson.getBadgeId() : null);

        return dto;
    }

    private Long toLong(Object obj) {
        if (obj == null) return null;
        if (obj instanceof Number) return ((Number) obj).longValue();
        try { return Long.parseLong(obj.toString()); } catch (NumberFormatException e) { return null; }
    }
}

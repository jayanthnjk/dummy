import React, { useEffect, useState, useCallback } from 'react';
import {
  Box, Typography, Alert, CircularProgress, Button, Card, CardContent,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Paper, Chip, TextField, MenuItem, Select, FormControl, InputLabel,
  IconButton, Tooltip, Fade, alpha, Snackbar, Dialog, DialogTitle,
  DialogContent, DialogContentText, DialogActions,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import RotateRightIcon from '@mui/icons-material/RotateRight';
import SearchIcon from '@mui/icons-material/Search';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import api from '@/services/api';

// ===== Constants =====
const PRIMARY = '#312e81';
const ACCENT = '#0d9488';

const PLATOON_COLORS: Record<string, string> = {
  'Platoon I': '#1565c0',
  'Platoon II': '#2e7d32',
  'Platoon III': '#e65100',
  'Platoon IV': '#6a1b9a',
  'Platoon V': '#c62828',
};

const PLATOON_OPTIONS = [
  { id: 1, name: 'Platoon I' },
  { id: 2, name: 'Platoon II' },
  { id: 3, name: 'Platoon III' },
  { id: 4, name: 'Platoon IV' },
  { id: 5, name: 'Platoon V' },
];

const DUTY_LABELS = ['Guard I', 'Guard II', 'Check Post', 'Escort', 'Strike Force'] as const;
const DUTY_KEYS = ['guard1', 'guard2', 'checkpoint', 'escort', 'strikeforce'] as const;

// ===== Types =====
interface PlatoonAssignment {
  platoonId: number;
  platoonName: string;
}

interface RotationSchedule {
  id: number;
  startDate: string;
  endDate: string;
  cycleNumber: number;
  guard1: PlatoonAssignment;
  guard2: PlatoonAssignment;
  checkpoint: PlatoonAssignment;
  escort: PlatoonAssignment;
  strikeforce: PlatoonAssignment;
  isCurrent: boolean;
}

// ===== Helpers =====
const formatDate = (dateStr: string): string => {
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
};

const getPlatoonColor = (name: string): string => PLATOON_COLORS[name] || PRIMARY;

const PlatoonChip: React.FC<{ name: string }> = ({ name }) => {
  const color = getPlatoonColor(name);
  return (
    <Chip
      label={name}
      size="small"
      sx={{
        bgcolor: alpha(color, 0.12),
        color,
        fontWeight: 700,
        fontSize: '0.75rem',
        border: `1px solid ${alpha(color, 0.3)}`,
        height: 26,
      }}
    />
  );
};

// ===== Current Rotation Card =====
const CurrentRotationCard: React.FC<{ schedule: RotationSchedule | null; loading: boolean }> = ({ schedule, loading }) => {
  const { t } = useTranslation();

  if (loading) {
    return (
      <Card sx={{ borderRadius: 3, mb: 3, border: `2px solid ${ACCENT}`, boxShadow: `0 4px 20px ${alpha(ACCENT, 0.15)}` }}>
        <CardContent sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
          <CircularProgress sx={{ color: ACCENT }} />
        </CardContent>
      </Card>
    );
  }

  if (!schedule) {
    return (
      <Card sx={{ borderRadius: 3, mb: 3, border: `1px solid ${alpha(PRIMARY, 0.12)}` }}>
        <CardContent sx={{ textAlign: 'center', py: 4 }}>
          <Typography color="text.secondary">{t('rotation.noCurrentRotation', 'No active rotation for today')}</Typography>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card
      sx={{
        borderRadius: 3,
        mb: 3,
        border: `2px solid ${ACCENT}`,
        boxShadow: `0 4px 20px ${alpha(ACCENT, 0.15)}`,
        background: `linear-gradient(135deg, ${alpha(PRIMARY, 0.02)} 0%, ${alpha(ACCENT, 0.04)} 100%)`,
      }}
    >
      <CardContent sx={{ p: 3 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2.5, flexWrap: 'wrap', gap: 1 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
            <RotateRightIcon sx={{ color: ACCENT, fontSize: 28 }} />
            <Typography variant="h6" sx={{ fontWeight: 700, color: PRIMARY }}>
              {t('rotation.currentRotation', 'Current Rotation')} — {t('rotation.cycle', 'Cycle')} #{schedule.cycleNumber}
            </Typography>
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
            <Chip
              icon={<CheckCircleIcon sx={{ fontSize: 16 }} />}
              label={t('rotation.active', 'ACTIVE')}
              size="small"
              sx={{
                bgcolor: alpha('#2e7d32', 0.12),
                color: '#2e7d32',
                fontWeight: 700,
                fontSize: '0.75rem',
                '& .MuiChip-icon': { color: '#2e7d32' },
              }}
            />
            <Typography variant="body2" sx={{ color: 'text.secondary', fontWeight: 500 }}>
              {formatDate(schedule.startDate)} — {formatDate(schedule.endDate)}
            </Typography>
          </Box>
        </Box>

        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: { xs: 'repeat(2, 1fr)', sm: 'repeat(3, 1fr)', md: 'repeat(5, 1fr)' },
            gap: 2,
          }}
        >
          {DUTY_KEYS.map((key, idx) => {
            const assignment = schedule[key];
            const color = getPlatoonColor(assignment.platoonName);
            return (
              <Box
                key={key}
                sx={{
                  textAlign: 'center',
                  p: 2,
                  borderRadius: 2,
                  bgcolor: alpha(color, 0.06),
                  border: `1px solid ${alpha(color, 0.2)}`,
                }}
              >
                <Typography sx={{ fontSize: '0.72rem', fontWeight: 600, color: 'text.secondary', textTransform: 'uppercase', mb: 0.5, letterSpacing: 0.5 }}>
                  {DUTY_LABELS[idx]}
                </Typography>
                <Typography sx={{ fontWeight: 700, color, fontSize: '0.95rem' }}>
                  {assignment.platoonName}
                </Typography>
              </Box>
            );
          })}
        </Box>
      </CardContent>
    </Card>
  );
};

// ===== Add New Rotation Form =====
interface NewRotationForm {
  startDate: string;
  endDate: string;
  guard1PlatoonId: number;
  guard2PlatoonId: number;
  checkpointPlatoonId: number;
  escortPlatoonId: number;
  strikeforcePlatoonId: number;
}

const INITIAL_FORM: NewRotationForm = {
  startDate: '',
  endDate: '',
  guard1PlatoonId: 1,
  guard2PlatoonId: 2,
  checkpointPlatoonId: 3,
  escortPlatoonId: 4,
  strikeforcePlatoonId: 5,
};

const FORM_FIELDS: { key: keyof NewRotationForm; label: string }[] = [
  { key: 'guard1PlatoonId', label: 'Guard I Platoon' },
  { key: 'guard2PlatoonId', label: 'Guard II Platoon' },
  { key: 'checkpointPlatoonId', label: 'Check Post Platoon' },
  { key: 'escortPlatoonId', label: 'Escort Platoon' },
  { key: 'strikeforcePlatoonId', label: 'Strike Force Platoon' },
];

const AddRotationCard: React.FC<{ onCreated: () => void }> = ({ onCreated }) => {
  const { t } = useTranslation();
  const [form, setForm] = useState<NewRotationForm>({ ...INITIAL_FORM });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleChange = (key: keyof NewRotationForm, value: string | number) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleSubmit = async () => {
    if (!form.startDate || !form.endDate) {
      setError(t('rotation.datesRequired', 'Start date and end date are required'));
      return;
    }
    if (form.startDate > form.endDate) {
      setError(t('rotation.invalidDateRange', 'Start date must be before end date'));
      return;
    }
    setSubmitting(true);
    setError('');
    try {
      await api.post('/api/rotation-schedules', form);
      setSuccess(true);
      setForm({ ...INITIAL_FORM });
      onCreated();
    } catch (err: any) {
      setError(err?.response?.data?.message || t('rotation.createError', 'Failed to create rotation'));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Card sx={{ borderRadius: 3, mb: 3, border: `1px solid ${alpha(PRIMARY, 0.12)}` }}>
      <CardContent sx={{ p: 3 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 2.5 }}>
          <AddCircleOutlineIcon sx={{ color: ACCENT, fontSize: 24 }} />
          <Typography variant="h6" sx={{ fontWeight: 700, color: PRIMARY }}>
            {t('rotation.addNew', 'Add New Rotation')}
          </Typography>
        </Box>

        {error && <Alert severity="error" sx={{ mb: 2, borderRadius: 2 }} onClose={() => setError('')}>{error}</Alert>}

        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 2, mb: 2.5 }}>
          <TextField
            label={t('rotation.startDate', 'Start Date')}
            type="date"
            value={form.startDate}
            onChange={(e) => handleChange('startDate', e.target.value)}
            InputLabelProps={{ shrink: true }}
            fullWidth
            size="small"
            sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }}
          />
          <TextField
            label={t('rotation.endDate', 'End Date')}
            type="date"
            value={form.endDate}
            onChange={(e) => handleChange('endDate', e.target.value)}
            InputLabelProps={{ shrink: true }}
            fullWidth
            size="small"
            sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }}
          />
        </Box>

        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: 'repeat(3, 1fr)', md: 'repeat(5, 1fr)' }, gap: 2, mb: 2.5 }}>
          {FORM_FIELDS.map(({ key, label }) => (
            <FormControl key={key} size="small" fullWidth>
              <InputLabel>{label}</InputLabel>
              <Select
                value={form[key]}
                label={label}
                onChange={(e) => handleChange(key, Number(e.target.value))}
                sx={{ borderRadius: 2 }}
              >
                {PLATOON_OPTIONS.map((p) => (
                  <MenuItem key={p.id} value={p.id}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Box sx={{ width: 10, height: 10, borderRadius: '50%', bgcolor: getPlatoonColor(p.name) }} />
                      {p.name}
                    </Box>
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          ))}
        </Box>

        <Button
          variant="contained"
          onClick={handleSubmit}
          disabled={submitting}
          startIcon={submitting ? <CircularProgress size={18} sx={{ color: 'white' }} /> : <AddCircleOutlineIcon />}
          sx={{
            bgcolor: PRIMARY,
            borderRadius: 2,
            textTransform: 'none',
            fontWeight: 600,
            px: 3,
            '&:hover': { bgcolor: alpha(PRIMARY, 0.85) },
          }}
        >
          {submitting ? t('rotation.creating', 'Creating...') : t('rotation.createRotation', 'Create Rotation')}
        </Button>

        <Snackbar
          open={success}
          autoHideDuration={3000}
          onClose={() => setSuccess(false)}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
        >
          <Alert severity="success" onClose={() => setSuccess(false)} sx={{ borderRadius: 2 }}>
            {t('rotation.createSuccess', 'Rotation created successfully!')}
          </Alert>
        </Snackbar>
      </CardContent>
    </Card>
  );
};

// ===== Date Lookup Card =====
const DateLookupCard: React.FC = () => {
  const { t } = useTranslation();
  const [lookupDate, setLookupDate] = useState('');
  const [result, setResult] = useState<RotationSchedule | null>(null);
  const [noResult, setNoResult] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleLookup = useCallback(async (date: string) => {
    if (!date) return;
    setLoading(true);
    setNoResult(false);
    setResult(null);
    try {
      const res = await api.get(`/api/rotation-schedules/by-date`, { params: { date } });
      if (res.data?.id) {
        setResult(res.data);
      } else {
        setNoResult(true);
      }
    } catch {
      setNoResult(true);
    } finally {
      setLoading(false);
    }
  }, []);

  return (
    <Card sx={{ borderRadius: 3, mb: 3, border: `1px solid ${alpha(PRIMARY, 0.12)}` }}>
      <CardContent sx={{ p: 3 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 2 }}>
          <SearchIcon sx={{ color: ACCENT, fontSize: 24 }} />
          <Typography variant="h6" sx={{ fontWeight: 700, color: PRIMARY }}>
            {t('rotation.dateLookup', 'Date Lookup')}
          </Typography>
        </Box>

        <Typography variant="body2" sx={{ color: 'text.secondary', mb: 2 }}>
          {t('rotation.dateLookupDesc', 'Select a date to see which rotation is scheduled')}
        </Typography>

        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
          <TextField
            type="date"
            value={lookupDate}
            onChange={(e) => {
              setLookupDate(e.target.value);
              handleLookup(e.target.value);
            }}
            InputLabelProps={{ shrink: true }}
            size="small"
            sx={{ minWidth: 200, '& .MuiOutlinedInput-root': { borderRadius: 2 } }}
          />
          {loading && <CircularProgress size={20} sx={{ color: ACCENT }} />}
        </Box>

        {noResult && lookupDate && (
          <Alert severity="info" sx={{ borderRadius: 2 }}>
            {t('rotation.noRotationForDate', 'No rotation scheduled for this date')}
          </Alert>
        )}

        {result && (
          <Fade in>
            <Box
              sx={{
                display: 'grid',
                gridTemplateColumns: { xs: 'repeat(2, 1fr)', sm: 'repeat(3, 1fr)', md: 'repeat(5, 1fr)' },
                gap: 2,
                mt: 1,
                p: 2,
                borderRadius: 2,
                bgcolor: alpha(PRIMARY, 0.02),
                border: `1px solid ${alpha(PRIMARY, 0.08)}`,
              }}
            >
              <Box sx={{ gridColumn: '1 / -1', display: 'flex', alignItems: 'center', gap: 1.5, mb: 0.5 }}>
                <CalendarTodayIcon sx={{ color: ACCENT, fontSize: 18 }} />
                <Typography sx={{ fontWeight: 600, color: PRIMARY, fontSize: '0.9rem' }}>
                  {t('rotation.cycle', 'Cycle')} #{result.cycleNumber} — {formatDate(result.startDate)} to {formatDate(result.endDate)}
                </Typography>
                {result.isCurrent && (
                  <Chip label={t('rotation.active', 'ACTIVE')} size="small" sx={{ bgcolor: alpha('#2e7d32', 0.12), color: '#2e7d32', fontWeight: 700, fontSize: '0.7rem' }} />
                )}
              </Box>
              {DUTY_KEYS.map((key, idx) => {
                const assignment = result[key];
                const color = getPlatoonColor(assignment.platoonName);
                return (
                  <Box key={key} sx={{ textAlign: 'center', p: 1.5, borderRadius: 2, bgcolor: alpha(color, 0.06), border: `1px solid ${alpha(color, 0.15)}` }}>
                    <Typography sx={{ fontSize: '0.68rem', fontWeight: 600, color: 'text.secondary', textTransform: 'uppercase', mb: 0.3, letterSpacing: 0.5 }}>
                      {DUTY_LABELS[idx]}
                    </Typography>
                    <Typography sx={{ fontWeight: 700, color, fontSize: '0.85rem' }}>
                      {assignment.platoonName}
                    </Typography>
                  </Box>
                );
              })}
            </Box>
          </Fade>
        )}
      </CardContent>
    </Card>
  );
};

// ===== All Schedules Table =====
interface SchedulesTableProps {
  schedules: RotationSchedule[];
  loading: boolean;
  isAdmin: boolean;
  onDelete: (id: number) => void;
}

const SchedulesTable: React.FC<SchedulesTableProps> = ({ schedules, loading, isAdmin, onDelete }) => {
  const { t } = useTranslation();
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [deleting, setDeleting] = useState(false);

  const handleConfirmDelete = async () => {
    if (deleteId === null) return;
    setDeleting(true);
    try {
      await api.delete(`/api/rotation-schedules/${deleteId}`);
      onDelete(deleteId);
    } catch {
      // silent fail
    } finally {
      setDeleting(false);
      setDeleteId(null);
    }
  };

  if (loading) {
    return (
      <Card sx={{ borderRadius: 3, border: `1px solid ${alpha(PRIMARY, 0.12)}` }}>
        <CardContent sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
          <CircularProgress sx={{ color: ACCENT }} />
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card sx={{ borderRadius: 3, border: `1px solid ${alpha(PRIMARY, 0.12)}`, overflow: 'hidden' }}>
        <CardContent sx={{ p: 3, pb: 1 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 2 }}>
            <CalendarTodayIcon sx={{ color: ACCENT, fontSize: 24 }} />
            <Typography variant="h6" sx={{ fontWeight: 700, color: PRIMARY }}>
              {t('rotation.allSchedules', 'All Rotation Schedules')}
            </Typography>
            <Chip
              label={schedules.length}
              size="small"
              sx={{ bgcolor: alpha(ACCENT, 0.15), color: PRIMARY, fontWeight: 700, fontSize: '0.75rem', height: 24 }}
            />
          </Box>
        </CardContent>

        {schedules.length === 0 ? (
          <Box sx={{ textAlign: 'center', py: 4, px: 3 }}>
            <Typography color="text.secondary">{t('rotation.noSchedules', 'No rotation schedules found')}</Typography>
          </Box>
        ) : (
          <TableContainer component={Paper} elevation={0} sx={{ borderRadius: 0 }}>
            <Table size="small">
              <TableHead>
                <TableRow>
                  {[
                    t('rotation.colCycle', 'Cycle #'),
                    t('rotation.colStart', 'Start Date'),
                    t('rotation.colEnd', 'End Date'),
                    'Guard I',
                    'Guard II',
                    t('rotation.colCheckPost', 'Check Post'),
                    t('rotation.colEscort', 'Escort'),
                    t('rotation.colStrikeForce', 'Strike Force'),
                    t('rotation.colStatus', 'Status'),
                    ...(isAdmin ? [t('rotation.colActions', 'Actions')] : []),
                  ].map((col) => (
                    <TableCell
                      key={col}
                      sx={{
                        fontWeight: 700,
                        color: PRIMARY,
                        bgcolor: alpha(PRIMARY, 0.04),
                        fontSize: '0.78rem',
                        whiteSpace: 'nowrap',
                        borderBottom: `2px solid ${alpha(PRIMARY, 0.1)}`,
                      }}
                    >
                      {col}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {schedules.map((s) => (
                  <TableRow
                    key={s.id}
                    sx={{
                      bgcolor: s.isCurrent ? alpha(ACCENT, 0.06) : 'transparent',
                      '&:hover': { bgcolor: s.isCurrent ? alpha(ACCENT, 0.1) : alpha(PRIMARY, 0.02) },
                      transition: 'background-color 0.15s',
                    }}
                  >
                    <TableCell sx={{ fontWeight: 700, color: PRIMARY, fontSize: '0.85rem' }}>
                      #{s.cycleNumber}
                    </TableCell>
                    <TableCell sx={{ fontSize: '0.82rem' }}>{formatDate(s.startDate)}</TableCell>
                    <TableCell sx={{ fontSize: '0.82rem' }}>{formatDate(s.endDate)}</TableCell>
                    <TableCell><PlatoonChip name={s.guard1.platoonName} /></TableCell>
                    <TableCell><PlatoonChip name={s.guard2.platoonName} /></TableCell>
                    <TableCell><PlatoonChip name={s.checkpoint.platoonName} /></TableCell>
                    <TableCell><PlatoonChip name={s.escort.platoonName} /></TableCell>
                    <TableCell><PlatoonChip name={s.strikeforce.platoonName} /></TableCell>
                    <TableCell>
                      {s.isCurrent ? (
                        <Chip
                          icon={<CheckCircleIcon sx={{ fontSize: 14 }} />}
                          label={t('rotation.active', 'ACTIVE')}
                          size="small"
                          sx={{
                            bgcolor: alpha('#2e7d32', 0.12),
                            color: '#2e7d32',
                            fontWeight: 700,
                            fontSize: '0.7rem',
                            '& .MuiChip-icon': { color: '#2e7d32' },
                          }}
                        />
                      ) : (
                        <Chip
                          label={t('rotation.scheduled', 'Scheduled')}
                          size="small"
                          sx={{
                            bgcolor: alpha(PRIMARY, 0.06),
                            color: 'text.secondary',
                            fontWeight: 600,
                            fontSize: '0.7rem',
                          }}
                        />
                      )}
                    </TableCell>
                    {isAdmin && (
                      <TableCell>
                        <Tooltip title={t('rotation.delete', 'Delete')}>
                          <IconButton
                            size="small"
                            onClick={() => setDeleteId(s.id)}
                            sx={{ color: '#c62828', '&:hover': { bgcolor: alpha('#c62828', 0.08) } }}
                          >
                            <DeleteOutlineIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </TableCell>
                    )}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </Card>

      {/* Delete confirmation dialog */}
      <Dialog open={deleteId !== null} onClose={() => setDeleteId(null)}>
        <DialogTitle sx={{ fontWeight: 700, color: PRIMARY }}>
          {t('rotation.confirmDelete', 'Delete Rotation?')}
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
            {t('rotation.confirmDeleteDesc', 'This will deactivate the rotation schedule. This action can be undone by an administrator.')}
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setDeleteId(null)} disabled={deleting} sx={{ textTransform: 'none' }}>
            {t('app.cancel', 'Cancel')}
          </Button>
          <Button
            onClick={handleConfirmDelete}
            disabled={deleting}
            variant="contained"
            color="error"
            sx={{ textTransform: 'none', fontWeight: 600 }}
          >
            {deleting ? <CircularProgress size={18} sx={{ color: 'white' }} /> : t('rotation.delete', 'Delete')}
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

// ===== Main Page Component =====
const RotationManagementPage: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { isAdmin } = useAuth();

  const [schedules, setSchedules] = useState<RotationSchedule[]>([]);
  const [currentRotation, setCurrentRotation] = useState<RotationSchedule | null>(null);
  const [loadingAll, setLoadingAll] = useState(true);
  const [loadingCurrent, setLoadingCurrent] = useState(true);
  const [error, setError] = useState('');

  const fetchAll = useCallback(async () => {
    setLoadingAll(true);
    try {
      const res = await api.get('/api/rotation-schedules');
      setSchedules(res.data);
    } catch {
      setError(t('rotation.fetchError', 'Failed to load rotation schedules'));
    } finally {
      setLoadingAll(false);
    }
  }, [t]);

  const fetchCurrent = useCallback(async () => {
    setLoadingCurrent(true);
    try {
      const res = await api.get('/api/rotation-schedules/current');
      if (res.data?.id) {
        setCurrentRotation(res.data);
      } else {
        setCurrentRotation(null);
      }
    } catch {
      setCurrentRotation(null);
    } finally {
      setLoadingCurrent(false);
    }
  }, []);

  useEffect(() => {
    fetchAll();
    fetchCurrent();
  }, [fetchAll, fetchCurrent]);

  const handleCreated = () => {
    fetchAll();
    fetchCurrent();
  };

  const handleDelete = (id: number) => {
    setSchedules((prev) => prev.filter((s) => s.id !== id));
    if (currentRotation?.id === id) {
      fetchCurrent();
    }
  };

  return (
    <Fade in timeout={400}>
      <Box sx={{ maxWidth: 1200, mx: 'auto', px: { xs: 2, sm: 3 }, py: 3 }}>
        {/* Header */}
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
          <Tooltip title={t('rotation.backToSchedules', 'Back to Schedules')}>
            <IconButton
              onClick={() => navigate('/schedules')}
              sx={{
                bgcolor: alpha(PRIMARY, 0.06),
                '&:hover': { bgcolor: alpha(PRIMARY, 0.12) },
              }}
            >
              <ArrowBackIcon sx={{ color: PRIMARY }} />
            </IconButton>
          </Tooltip>
          <Box>
            <Typography variant="h5" sx={{ fontWeight: 800, color: PRIMARY }}>
              {t('rotation.title', 'Rotation Management')}
            </Typography>
            <Typography variant="body2" sx={{ color: 'text.secondary' }}>
              {t('rotation.subtitle', 'Manage platoon duty rotation cycles')}
            </Typography>
          </Box>
        </Box>

        {error && <Alert severity="error" sx={{ mb: 2, borderRadius: 2 }} onClose={() => setError('')}>{error}</Alert>}

        {/* Section 1: Current Rotation */}
        <CurrentRotationCard schedule={currentRotation} loading={loadingCurrent} />

        {/* Section 2: Add New Rotation (admin only) */}
        {isAdmin && <AddRotationCard onCreated={handleCreated} />}

        {/* Section 3: Date Lookup */}
        <DateLookupCard />

        {/* Section 4: All Schedules Table */}
        <SchedulesTable
          schedules={schedules}
          loading={loadingAll}
          isAdmin={!!isAdmin}
          onDelete={handleDelete}
        />
      </Box>
    </Fade>
  );
};

export default RotationManagementPage;

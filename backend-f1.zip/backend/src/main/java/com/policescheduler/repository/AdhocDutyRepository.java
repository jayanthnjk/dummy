package com.policescheduler.repository;

import com.policescheduler.entity.AdhocDuty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Repository
public interface AdhocDutyRepository extends JpaRepository<AdhocDuty, Long> {
    List<AdhocDuty> findByDateAndStatusNot(LocalDate date, String status);
    List<AdhocDuty> findByStatus(String status);
    List<AdhocDuty> findByDateBetweenAndStatusNot(LocalDate start, LocalDate end, String status);
    List<AdhocDuty> findAllByOrderByDateDescCreatedAtDesc();
    List<AdhocDuty> findByDateAndStatus(LocalDate date, String status);
    
    /**
     * Find all active adhoc duties that have expired (date < today, or date = today and endTime < now)
     */
    @Query("SELECT a FROM AdhocDuty a WHERE a.status = 'ACTIVE' AND " +
           "(a.date < :today OR (a.date = :today AND a.endTime < :currentTime))")
    List<AdhocDuty> findExpiredActiveDuties(@Param("today") LocalDate today, @Param("currentTime") LocalTime currentTime);
}

import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import AppShell from './AppShell';

export const ProtectedRoute: React.FC = () => {
  const { isAuthenticated, role } = useAuth();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // Support admin gets a dedicated layout — redirect to their portal
  if (role === 'SUPPORT_ADMIN') {
    return <Navigate to="/support-admin" replace />;
  }

  return (
    <AppShell>
      <Outlet />
    </AppShell>
  );
};

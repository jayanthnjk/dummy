import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import en from './en.json';
import kn from './kn.json';

const LANGUAGE_STORAGE_KEY = 'ksp-workboard-language';

const savedLanguage = localStorage.getItem(LANGUAGE_STORAGE_KEY) || 'en';

i18n.use(initReactI18next).init({
  resources: {
    en: { translation: en },
    kn: { translation: kn },
  },
  lng: savedLanguage,
  fallbackLng: 'en',
  interpolation: {
    escapeValue: false,
  },
  missingKeyHandler: (_lngs, _ns, key) => {
    console.warn(`[i18n] Missing translation key: ${key}`);
  },
});

export default i18n;
export { LANGUAGE_STORAGE_KEY };

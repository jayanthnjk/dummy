package com.policescheduler.repository;

import com.policescheduler.entity.ReportEmailConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReportEmailConfigRepository extends JpaRepository<ReportEmailConfig, Long> {

    List<ReportEmailConfig> findByIsActiveTrue();

    List<ReportEmailConfig> findAllByOrderByCreatedAtDesc();

    /**
     * Find all active email configs that have a specific report type in their selected_reports.
     * This is used by the scheduler to find all recipients for a particular report.
     */
    @Query("SELECT r FROM ReportEmailConfig r WHERE r.isActive = true " +
           "AND r.selectedReports LIKE %:reportType%")
    List<ReportEmailConfig> findActiveConfigsWithReportType(@Param("reportType") String reportType);
}

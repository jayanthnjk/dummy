import React, { useState } from 'react';
import {
  AppBar, Toolbar, Typography, IconButton, Menu, MenuItem, Box,
  Divider, Dialog, DialogTitle, DialogContent, DialogActions,
  Button, Chip, Avatar, Badge,
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import NotificationsNoneIcon from '@mui/icons-material/NotificationsNone';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguageContext } from '@/contexts/LanguageContext';
import { authService } from '@/services/authService';
import FormField from './FormField';

interface TopNavBarProps {
  onMenuToggle: () => void;
  drawerWidth: number;
}

const TopNavBar: React.FC<TopNavBarProps> = ({ onMenuToggle, drawerWidth }) => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { logout, displayName, role } = useAuth();
  const { locale, toggleLanguage } = useLanguageContext();
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [pwdOpen, setPwdOpen] = useState(false);
  const [oldPwd, setOldPwd] = useState('');
  const [newPwd, setNewPwd] = useState('');
  const [pwdError, setPwdError] = useState('');

  const handleLogout = async () => {
    setAnchorEl(null);
    try { await authService.logout(); } catch { /* ignore */ }
    logout();
    navigate('/login');
  };

  const handleChangePassword = async () => {
    setPwdError('');
    try {
      await authService.changePassword({ oldPassword: oldPwd, newPassword: newPwd });
      setPwdOpen(false); setOldPwd(''); setNewPwd('');
    } catch { setPwdError(t('errors.serverError')); }
  };

  return (
    <>
      <AppBar position="fixed" elevation={0} sx={{
        width: { md: `calc(100% - ${drawerWidth}px)` },
        ml: { md: `${drawerWidth}px` },
        bgcolor: '#ffffff',
        borderBottom: '1px solid #f0ede6',
        transition: 'width 0.2s ease, margin-left 0.2s ease',
      }}>
        <Toolbar variant="dense" sx={{ minHeight: 52, px: { xs: 1.5, md: 2.5 } }}>
          <IconButton edge="start" onClick={onMenuToggle} sx={{ mr: 1, display: { md: 'none' }, color: '#374151' }}>
            <MenuIcon />
          </IconButton>

          <Box sx={{ flexGrow: 1 }} />

          {/* Language toggle */}
          <Chip
            label={locale === 'en' ? 'ಕನ್ನಡ' : 'English'}
            onClick={toggleLanguage}
            size="small"
            sx={{
              mr: 1.5, fontWeight: 600, fontSize: '0.72rem', cursor: 'pointer', height: 28,
              bgcolor: '#f5f3ee', color: '#6b5e3e', border: '1px solid #e8dcc8',
              '&:hover': { bgcolor: '#ede8dc' },
            }}
          />

          {/* User */}
          <Box onClick={(e) => setAnchorEl(e.currentTarget as HTMLElement)}
            sx={{
              display: 'flex', alignItems: 'center', gap: 1, cursor: 'pointer',
              px: 1, py: 0.5, borderRadius: 2, '&:hover': { bgcolor: '#f9fafb' },
            }}>
            <Avatar sx={{ width: 30, height: 30, bgcolor: '#1a1e4a', color: '#c4a44a', fontSize: '0.75rem', fontWeight: 700 }}>
              {displayName?.charAt(0)?.toUpperCase() || 'A'}
            </Avatar>
            <Box sx={{ display: { xs: 'none', sm: 'block' } }}>
              <Typography sx={{ fontSize: '0.78rem', fontWeight: 600, color: '#111827', lineHeight: 1.2 }}>
                {displayName || 'System'}
              </Typography>
              <Typography sx={{ fontSize: '0.62rem', color: '#9ca3af' }}>
                {role === 'ADMIN' ? 'Admin' : role === 'HIGHER_OFFICER' ? 'Officer' : 'User'}
              </Typography>
            </Box>
          </Box>

          <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={() => setAnchorEl(null)}
            PaperProps={{ sx: { borderRadius: 2, mt: 0.5, minWidth: 180 } }}>
            <MenuItem disabled><Typography variant="body2" sx={{ fontWeight: 500 }}>{displayName}</Typography></MenuItem>
            <Divider />
            <MenuItem onClick={() => { setAnchorEl(null); setPwdOpen(true); }} sx={{ fontSize: '0.85rem' }}>{t('nav.changePassword')}</MenuItem>
            <MenuItem onClick={() => { setAnchorEl(null); navigate('/contact-support'); }} sx={{ fontSize: '0.85rem' }}>{t('nav.contactSupport')}</MenuItem>
            <Divider />
            <MenuItem onClick={handleLogout} sx={{ fontSize: '0.85rem', color: '#dc2626' }}>{t('nav.logout')}</MenuItem>
          </Menu>
        </Toolbar>
      </AppBar>

      <Dialog open={pwdOpen} onClose={() => setPwdOpen(false)} maxWidth="xs" fullWidth>
        <DialogTitle>{t('changePassword.title')}</DialogTitle>
        <DialogContent>
          {pwdError && <Typography color="error" variant="body2" sx={{ mb: 1 }}>{pwdError}</Typography>}
          <FormField labelKey="changePassword.oldPassword" type="password" value={oldPwd} onChange={(e) => setOldPwd(e.target.value)} />
          <FormField labelKey="changePassword.newPassword" type="password" value={newPwd} onChange={(e) => setNewPwd(e.target.value)} />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setPwdOpen(false)}>{t('app.cancel')}</Button>
          <Button variant="contained" onClick={handleChangePassword} disabled={!oldPwd || !newPwd}>{t('app.save')}</Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default TopNavBar;

package com.policescheduler.report;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import jakarta.annotation.PostConstruct;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Map;

@Service
public class S3ReportStorageService {

    private static final Logger log = LoggerFactory.getLogger(S3ReportStorageService.class);
    private static final DateTimeFormatter DATE_PATH_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @Value("${app.s3.bucket}")
    private String bucket;

    @Value("${app.s3.region}")
    private String region;

    private S3Client s3Client;

    // Mapping of report types to their S3 folder names for scheduled reports
    // Format: dailyReports/{folderName}/{date}/{filename}
    private static final Map<String, String> REPORT_FOLDER_NAMES = Map.of(
            "form_168", "form168",
            "platoon_chart", "platoonChartC",
            "section_ab", "platoonChartAB",
            "mt_section", "mtSection",
            "leave_statement", "leaveStatement",
            "personnel_list", "personnelList"
    );

    @PostConstruct
    public void init() {
        this.s3Client = S3Client.builder()
                .region(Region.of(region))
                .credentialsProvider(DefaultCredentialsProvider.create())
                .build();
    }

    /**
     * Uploads report bytes to S3.
     * Key format: reports/{reportType}/{yyyy-MM-dd}/{filename}
     *
     * @return the S3 key of the uploaded object
     */
    public String upload(String reportType, String filename, byte[] data, String contentType) {
        String s3Key = buildKey(reportType, filename);

        PutObjectRequest request = PutObjectRequest.builder()
                .bucket(bucket)
                .key(s3Key)
                .contentType(contentType)
                .contentLength((long) data.length)
                .build();

        s3Client.putObject(request, RequestBody.fromBytes(data));
        log.info("Uploaded report to S3: {}", s3Key);
        return s3Key;
    }

    /**
     * Uploads scheduled report bytes to S3 with organized folder structure.
     * Key format: dailyReports/{folderName}/{yyyy-MM-dd}/{filename}
     * 
     * Example:
     * - form_168 -> dailyReports/form168/2026-07-27/Form168_27-07-2026.pdf
     * - platoon_chart -> dailyReports/platoonChartC/2026-07-27/PlatoonChartC_27-07-2026.pdf
     *
     * @param reportType The report type code (from database)
     * @param filename The filename for the report
     * @param data The report data as byte array
     * @param contentType The MIME content type
     * @return the S3 key of the uploaded object
     */
    public String uploadScheduledReport(String reportType, String filename, byte[] data, String contentType) {
        String s3Key = buildScheduledReportKey(reportType, filename);

        PutObjectRequest request = PutObjectRequest.builder()
                .bucket(bucket)
                .key(s3Key)
                .contentType(contentType)
                .contentLength((long) data.length)
                .build();

        s3Client.putObject(request, RequestBody.fromBytes(data));
        log.info("Uploaded scheduled report to S3: {}", s3Key);
        return s3Key;
    }

    /**
     * Downloads a report from S3 by its key.
     */
    public byte[] download(String s3Key) {
        GetObjectRequest request = GetObjectRequest.builder()
                .bucket(bucket)
                .key(s3Key)
                .build();

        return s3Client.getObjectAsBytes(request).asByteArray();
    }

    private String buildKey(String reportType, String filename) {
        String datePart = LocalDate.now().format(DATE_PATH_FMT);
        return String.format("reports/%s/%s/%s", reportType, datePart, filename);
    }

    /**
     * Builds S3 key for scheduled reports with organized folder structure.
     * Format: dailyReports/{folderName}/{date}/{filename}
     */
    private String buildScheduledReportKey(String reportType, String filename) {
        String folderName = REPORT_FOLDER_NAMES.getOrDefault(reportType, reportType);
        String datePart = LocalDate.now().format(DATE_PATH_FMT);
        return String.format("dailyReports/%s/%s/%s", folderName, datePart, filename);
    }

    /**
     * Gets the folder name for a report type.
     */
    public String getFolderNameForReportType(String reportType) {
        return REPORT_FOLDER_NAMES.getOrDefault(reportType, reportType);
    }
}

import React, { useEffect, useState } from 'react';
import {
  Alert,
  Box,
  Button,
  Chip,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  MenuItem,
  Snackbar,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { cycleService, type CycleResponse, type CycleStatus } from '@/services/cycleService';

interface CycleListViewProps {
  /** Callback when a cycle row is clicked */
  onCycleSelect?: (cycleId: number) => void;
}

const STATUS_OPTIONS: { value: CycleStatus | 'ALL'; label: string }[] = [
  { value: 'ACTIVE', label: 'Active' },
  { value: 'COMPLETED', label: 'Completed' },
  { value: 'DELETED', label: 'Deleted' },
  { value: 'ALL', label: 'All' },
];

const STATUS_CHIP_COLORS: Record<CycleStatus, 'success' | 'info' | 'error'> = {
  ACTIVE: 'success',
  COMPLETED: 'info',
  DELETED: 'error',
};

/**
 * CycleListView — Displays a table of platoon rotation cycles with status filtering.
 * Includes Edit and Delete actions per row.
 */
const CycleListView: React.FC<CycleListViewProps> = ({ onCycleSelect }) => {
  const [cycles, setCycles] = useState<CycleResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<CycleStatus | 'ALL'>('ACTIVE');

  // Delete confirmation
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [deleting, setDeleting] = useState(false);

  // Edit dialog
  const [editCycle, setEditCycle] = useState<CycleResponse | null>(null);
  const [editStartDate, setEditStartDate] = useState('');
  const [editRotationDays, setEditRotationDays] = useState(0);
  const [editStatus, setEditStatus] = useState<string>('');
  const [saving, setSaving] = useState(false);

  // Snackbar
  const [snackbar, setSnackbar] = useState<{ open: boolean; message: string; severity: 'success' | 'error' }>({
    open: false, message: '', severity: 'success'
  });

  useEffect(() => {
    fetchCycles();
  }, [statusFilter]);

  const fetchCycles = async () => {
    setLoading(true);
    setError(null);
    try {
      const status = statusFilter === 'ALL' ? undefined : statusFilter;
      const data = await cycleService.getCycles(status);
      setCycles(data);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to load cycles';
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusFilterChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setStatusFilter(event.target.value as CycleStatus | 'ALL');
  };

  const handleRowClick = (cycleId: number) => {
    onCycleSelect?.(cycleId);
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    setDeleting(true);
    try {
      await cycleService.deleteCycle(deleteId);
      setSnackbar({ open: true, message: 'Cycle deleted successfully', severity: 'success' });
      setDeleteId(null);
      fetchCycles();
    } catch (err) {
      setSnackbar({ open: true, message: 'Failed to delete cycle', severity: 'error' });
    } finally {
      setDeleting(false);
    }
  };

  const handleEditOpen = (cycle: CycleResponse) => {
    setEditCycle(cycle);
    setEditStartDate(cycle.startDate);
    setEditRotationDays(cycle.rotationDays);
    setEditStatus(cycle.status);
  };

  const handleEditSave = async () => {
    if (!editCycle) return;
    setSaving(true);
    try {
      const updates: Record<string, unknown> = {};
      if (editStartDate !== editCycle.startDate) updates.startDate = editStartDate;
      if (editRotationDays !== editCycle.rotationDays) updates.rotationDays = editRotationDays;
      if (editStatus !== editCycle.status) updates.status = editStatus;

      await cycleService.updateCycle(editCycle.id, updates as any);
      setSnackbar({ open: true, message: 'Cycle updated successfully', severity: 'success' });
      setEditCycle(null);
      fetchCycles();
    } catch (err: any) {
      setSnackbar({ open: true, message: err.response?.data?.message || 'Failed to update cycle', severity: 'error' });
    } finally {
      setSaving(false);
    }
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <Box sx={{ width: '100%' }}>
      {/* Filter toolbar */}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
        <Typography variant="h6" fontWeight={600}>
          Rotation Cycles
        </Typography>
        <TextField
          select
          size="small"
          label="Status"
          value={statusFilter}
          onChange={handleStatusFilterChange}
          sx={{ minWidth: 160 }}
        >
          {STATUS_OPTIONS.map((option) => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </TextField>
      </Box>

      {/* Loading state */}
      {loading && (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
          <CircularProgress size={36} />
        </Box>
      )}

      {/* Error state */}
      {!loading && error && (
        <Typography color="error" sx={{ textAlign: 'center', py: 4 }}>
          {error}
        </Typography>
      )}

      {/* Empty state */}
      {!loading && !error && cycles.length === 0 && (
        <Box sx={{ textAlign: 'center', py: 6 }}>
          <Typography variant="body1" color="text.secondary">
            No cycles found.
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
            Create a new rotation cycle to get started.
          </Typography>
        </Box>
      )}

      {/* Data table */}
      {!loading && !error && cycles.length > 0 && (
        <TableContainer>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell sx={{ fontWeight: 600 }}>Start Date</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>End Date</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Rotation Days</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Status</TableCell>
                <TableCell sx={{ fontWeight: 600 }} align="center">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {cycles.map((cycle) => (
                <TableRow
                  key={cycle.id}
                  hover
                  sx={{ cursor: onCycleSelect ? 'pointer' : 'default' }}
                >
                  <TableCell onClick={() => handleRowClick(cycle.id)}>{formatDate(cycle.startDate)}</TableCell>
                  <TableCell onClick={() => handleRowClick(cycle.id)}>{formatDate(cycle.endDate)}</TableCell>
                  <TableCell onClick={() => handleRowClick(cycle.id)}>{cycle.rotationDays}</TableCell>
                  <TableCell onClick={() => handleRowClick(cycle.id)}>
                    <Chip
                      label={cycle.status}
                      size="small"
                      color={STATUS_CHIP_COLORS[cycle.status]}
                      variant="outlined"
                    />
                  </TableCell>
                  <TableCell align="center">
                    <Stack direction="row" spacing={0.5} justifyContent="center">
                      {cycle.status !== 'DELETED' && (
                        <>
                          <Tooltip title="Edit Cycle">
                            <IconButton
                              size="small"
                              color="primary"
                              onClick={(e) => { e.stopPropagation(); handleEditOpen(cycle); }}
                            >
                              <EditIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Delete Cycle">
                            <IconButton
                              size="small"
                              color="error"
                              onClick={(e) => { e.stopPropagation(); setDeleteId(cycle.id); }}
                            >
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        </>
                      )}
                    </Stack>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteId !== null} onClose={() => setDeleteId(null)}>
        <DialogTitle>Delete Cycle</DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to delete this cycle? This will soft-delete it (status set to DELETED).
            All assignments will be preserved but the cycle will no longer appear in active views.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteId(null)}>Cancel</Button>
          <Button variant="contained" color="error" onClick={handleDelete} disabled={deleting}>
            {deleting ? <CircularProgress size={20} /> : 'Delete'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={editCycle !== null} onClose={() => setEditCycle(null)} maxWidth="sm" fullWidth>
        <DialogTitle>Edit Cycle #{editCycle?.id}</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField
              type="date"
              label="Start Date"
              value={editStartDate}
              onChange={(e) => setEditStartDate(e.target.value)}
              InputLabelProps={{ shrink: true }}
              fullWidth
            />
            <TextField
              type="number"
              label="Rotation Days"
              value={editRotationDays}
              onChange={(e) => setEditRotationDays(parseInt(e.target.value) || 1)}
              inputProps={{ min: 1 }}
              fullWidth
            />
            <TextField
              select
              label="Status"
              value={editStatus}
              onChange={(e) => setEditStatus(e.target.value)}
              fullWidth
            >
              <MenuItem value="ACTIVE">Active</MenuItem>
              <MenuItem value="COMPLETED">Completed</MenuItem>
            </TextField>
            {editCycle && (
              <Typography variant="body2" color="text.secondary">
                End Date (calculated): {editStartDate && editRotationDays > 0
                  ? formatDate(new Date(new Date(editStartDate).getTime() + (editRotationDays - 1) * 86400000).toISOString().split('T')[0])
                  : '-'}
              </Typography>
            )}
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditCycle(null)}>Cancel</Button>
          <Button variant="contained" onClick={handleEditSave} disabled={saving}>
            {saving ? <CircularProgress size={20} /> : 'Save Changes'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar */}
      <Snackbar open={snackbar.open} autoHideDuration={4000} onClose={() => setSnackbar(s => ({ ...s, open: false }))}>
        <Alert severity={snackbar.severity}>{snackbar.message}</Alert>
      </Snackbar>
    </Box>
  );
};

export default CycleListView;

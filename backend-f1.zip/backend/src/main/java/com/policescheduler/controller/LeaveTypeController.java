package com.policescheduler.controller;

import com.policescheduler.entity.LeaveType;
import com.policescheduler.repository.LeaveTypeRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/leave-types")
public class LeaveTypeController {

    private final LeaveTypeRepository leaveTypeRepository;

    public LeaveTypeController(LeaveTypeRepository leaveTypeRepository) {
        this.leaveTypeRepository = leaveTypeRepository;
    }

    /**
     * GET /api/leave-types
     * Returns all active leave types ordered by sort_order.
     */
    @GetMapping
    public ResponseEntity<List<LeaveType>> listAll() {
        return ResponseEntity.ok(leaveTypeRepository.findByIsActiveTrueOrderBySortOrderAsc());
    }

    /**
     * POST /api/leave-types
     * Create a new leave type.
     * Body: { "code": "NEW_LEAVE", "displayName": "New Leave Type" }
     */
    @PostMapping
    public ResponseEntity<?> create(@RequestBody Map<String, Object> request) {
        String code = (String) request.get("code");
        String displayName = (String) request.get("displayName");

        if (code == null || code.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Leave type code is required"));
        }
        if (displayName == null || displayName.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Display name is required"));
        }

        String normalizedCode = code.trim().toUpperCase().replace(" ", "_");

        if (leaveTypeRepository.existsByCode(normalizedCode)) {
            return ResponseEntity.badRequest().body(Map.of("error", "Leave type already exists: " + normalizedCode));
        }

        // Get the next sort order
        List<LeaveType> existing = leaveTypeRepository.findByIsActiveTrueOrderBySortOrderAsc();
        int nextSort = existing.isEmpty() ? 1 : existing.get(existing.size() - 1).getSortOrder() + 1;

        LeaveType leaveType = new LeaveType();
        leaveType.setCode(normalizedCode);
        leaveType.setDisplayName(displayName.trim());
        leaveType.setSortOrder(nextSort);
        leaveType.setIsActive(true);

        LeaveType saved = leaveTypeRepository.save(leaveType);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    /**
     * DELETE /api/leave-types/{id}
     * Soft-delete a leave type (sets is_active = false).
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        LeaveType leaveType = leaveTypeRepository.findById(id).orElse(null);
        if (leaveType == null) {
            return ResponseEntity.notFound().build();
        }
        leaveType.setIsActive(false);
        leaveTypeRepository.save(leaveType);
        return ResponseEntity.ok(Map.of("success", true, "message", "Leave type deleted: " + leaveType.getDisplayName()));
    }

    /**
     * PUT /api/leave-types/{id}
     * Update display name of a leave type.
     * Body: { "displayName": "NEW DISPLAY NAME" }
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody Map<String, Object> request) {
        LeaveType leaveType = leaveTypeRepository.findById(id).orElse(null);
        if (leaveType == null) {
            return ResponseEntity.notFound().build();
        }
        String displayName = (String) request.get("displayName");
        if (displayName == null || displayName.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Display name is required"));
        }
        leaveType.setDisplayName(displayName.trim());
        leaveTypeRepository.save(leaveType);
        return ResponseEntity.ok(leaveType);
    }
}

package com.policescheduler.report.model;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
@Builder
public class Form168ReportModel {
    private LocalDate reportDate;
    private StrengthTableModel strengthTable;
    private List<SectionModel> sections; // Sections A-G (7 items)
    private OfficerDutyModel officerDuty;
    private LeaveStatementModel leaveStatement;
}

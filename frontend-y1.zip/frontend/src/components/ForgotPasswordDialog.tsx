import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Alert,
  CircularProgress,
  Typography,
  Box,
  InputAdornment,
  Link,
} from '@mui/material';
import EmailOutlinedIcon from '@mui/icons-material/EmailOutlined';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import PinOutlinedIcon from '@mui/icons-material/PinOutlined';
import { useTranslation } from 'react-i18next';
import { authService } from '@/services/authService';

type Step = 'email' | 'otp' | 'reset';

interface ForgotPasswordDialogProps {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

/** Shared TextField sx matching LoginPage styling */
const textFieldSx = {
  '& .MuiOutlinedInput-root': {
    borderRadius: '12px',
    bgcolor: '#f8fafc',
    fontSize: '0.85rem',
    transition: 'all 0.25s cubic-bezier(0.4, 0, 0.2, 1)',
    '& fieldset': { borderColor: '#e2e8f0', transition: 'all 0.25s' },
    '&:hover fieldset': { borderColor: '#0d9488' },
    '&.Mui-focused': {
      bgcolor: '#fff',
      boxShadow: '0 0 0 3px rgba(13,148,136,0.12)',
      '& fieldset': { borderColor: '#0d9488', borderWidth: 2 },
    },
  },
};

/** Primary gradient button sx matching LoginPage */
const primaryButtonSx = {
  textTransform: 'none',
  fontWeight: 600,
  borderRadius: '12px',
  background: 'linear-gradient(135deg, #312e81 0%, #4338ca 50%, #0d9488 100%)',
  color: '#fff',
  py: 1.1,
  fontSize: '0.85rem',
  boxShadow: '0 4px 14px rgba(49,46,129,0.25), 0 2px 6px rgba(13,148,136,0.15)',
  transition: 'all 0.25s cubic-bezier(0.4, 0, 0.2, 1)',
  '&:hover': {
    background: 'linear-gradient(135deg, #1e1b4b 0%, #312e81 50%, #0f766e 100%)',
    boxShadow: '0 6px 20px rgba(49,46,129,0.35), 0 4px 12px rgba(13,148,136,0.2)',
    transform: 'translateY(-1px)',
  },
  '&.Mui-disabled': {
    background: '#e2e8f0',
    color: '#94a3b8',
    boxShadow: 'none',
  },
};

const ForgotPasswordDialog: React.FC<ForgotPasswordDialogProps> = ({
  open,
  onClose,
  onSuccess,
}) => {
  const { t } = useTranslation();

  // Step state
  const [step, setStep] = useState<Step>('email');

  // Form fields
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [resetToken, setResetToken] = useState('');

  // UI state
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');

  // Resend cooldown
  const [resendCooldown, setResendCooldown] = useState(0);

  // Cooldown timer effect
  useEffect(() => {
    if (resendCooldown <= 0) return;
    const timer = setInterval(() => {
      setResendCooldown((prev) => (prev <= 1 ? 0 : prev - 1));
    }, 1000);
    return () => clearInterval(timer);
  }, [resendCooldown]);

  // Reset state when dialog closes
  useEffect(() => {
    if (!open) {
      setStep('email');
      setEmail('');
      setOtp('');
      setNewPassword('');
      setConfirmPassword('');
      setResetToken('');
      setLoading(false);
      setError('');
      setInfo('');
      setResendCooldown(0);
    }
  }, [open]);

  const handleEmailSubmit = async () => {
    setError('');
    setLoading(true);
    try {
      await authService.forgotPasswordRequest(email);
      setInfo(t('forgotPassword.otpSentMessage'));
      setStep('otp');
      setResendCooldown(60);
    } catch (err: unknown) {
      const axiosErr = err as { response?: { status?: number; data?: { message?: string; error?: string } } };
      if (axiosErr.response?.status === 429) {
        setError(t('forgotPassword.errors.rateLimited'));
      } else if (axiosErr.response?.status === 400) {
        setError(axiosErr.response?.data?.message || axiosErr.response?.data?.error || t('forgotPassword.errors.invalidEmail'));
      } else if (axiosErr.response?.status === 500) {
        setError(t('forgotPassword.errors.sendFailed'));
      } else {
        setError(t('forgotPassword.errors.genericError'));
      }
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async () => {
    setError('');
    setLoading(true);
    try {
      const response = await authService.forgotPasswordVerifyOtp(email, otp);
      setResetToken(response.resetToken);
      setStep('reset');
      setInfo('');
    } catch (err: unknown) {
      const axiosErr = err as { response?: { status?: number } };
      if (axiosErr.response?.status === 400) {
        setError(t('forgotPassword.errors.invalidOtp'));
      } else {
        setError(t('forgotPassword.errors.genericError'));
      }
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async () => {
    setError('');

    // Client-side validation
    if (newPassword.length < 8) {
      setError(t('forgotPassword.errors.passwordTooShort'));
      return;
    }
    if (newPassword !== confirmPassword) {
      setError(t('forgotPassword.errors.passwordMismatch'));
      return;
    }

    setLoading(true);
    try {
      await authService.forgotPasswordReset(resetToken, newPassword);
      onSuccess();
    } catch (err: unknown) {
      const axiosErr = err as { response?: { status?: number; data?: { error?: string } } };
      if (axiosErr.response?.status === 400) {
        const msg = axiosErr.response?.data?.error;
        if (msg?.includes('token') || msg?.includes('expired')) {
          setError(t('forgotPassword.errors.tokenExpired'));
        } else {
          setError(msg || t('forgotPassword.errors.genericError'));
        }
      } else {
        setError(t('forgotPassword.errors.genericError'));
      }
    } finally {
      setLoading(false);
    }
  };

  const handleResendOtp = async () => {
    if (resendCooldown > 0) return;
    setError('');
    setLoading(true);
    try {
      await authService.forgotPasswordRequest(email);
      setInfo(t('forgotPassword.otpSentMessage'));
      setResendCooldown(60);
    } catch (err: unknown) {
      const axiosErr = err as { response?: { status?: number } };
      if (axiosErr.response?.status === 429) {
        setError(t('forgotPassword.errors.rateLimited'));
      } else {
        setError(t('forgotPassword.errors.genericError'));
      }
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    setError('');
    setInfo('');
    if (step === 'otp') {
      setStep('email');
      setOtp('');
    }
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="xs"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: '20px',
          overflow: 'hidden',
        },
      }}
    >
      {/* Top accent bar matching LoginPage card */}
      <Box
        sx={{
          height: 3,
          background:
            'linear-gradient(90deg, #312e81, #4338ca, #0d9488, #14b8a6, #312e81)',
          backgroundSize: '200% 100%',
        }}
      />

      <DialogTitle
        sx={{
          textAlign: 'center',
          fontWeight: 700,
          color: '#0f172a',
          fontSize: '1.2rem',
          letterSpacing: '-0.02em',
          pb: 0,
          pt: 3,
        }}
      >
        {t('forgotPassword.title')}
      </DialogTitle>

      <DialogContent sx={{ px: 3, pt: 2, pb: 1 }}>
        {/* Error alert */}
        {error && (
          <Alert
            severity="error"
            sx={{
              mb: 2,
              borderRadius: '12px',
              fontSize: '0.8rem',
              border: '1px solid #fecdd3',
              bgcolor: '#fff1f2',
            }}
            onClose={() => setError('')}
          >
            {error}
          </Alert>
        )}

        {/* Info alert */}
        {info && (
          <Alert
            severity="info"
            sx={{
              mb: 2,
              borderRadius: '12px',
              fontSize: '0.8rem',
              border: '1px solid #bae6fd',
              bgcolor: '#f0f9ff',
            }}
          >
            {info}
          </Alert>
        )}

        {/* Step 1: Email */}
        {step === 'email' && (
          <Box>
            <Typography
              component="label"
              sx={{
                display: 'block',
                fontWeight: 500,
                color: '#334155',
                fontSize: '0.78rem',
                mb: 0.6,
              }}
            >
              {t('forgotPassword.emailLabel')}
            </Typography>
            <TextField
              placeholder={t('forgotPassword.emailPlaceholder')}
              fullWidth
              size="small"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoFocus
              slotProps={{
                input: {
                  startAdornment: (
                    <InputAdornment position="start">
                      <EmailOutlinedIcon sx={{ fontSize: 18, color: '#94a3b8' }} />
                    </InputAdornment>
                  ),
                },
              }}
              sx={textFieldSx}
            />
          </Box>
        )}

        {/* Step 2: OTP */}
        {step === 'otp' && (
          <Box>
            <Typography
              component="label"
              sx={{
                display: 'block',
                fontWeight: 500,
                color: '#334155',
                fontSize: '0.78rem',
                mb: 0.6,
              }}
            >
              {t('forgotPassword.otpLabel')}
            </Typography>
            <TextField
              placeholder={t('forgotPassword.otpPlaceholder')}
              fullWidth
              size="small"
              value={otp}
              onChange={(e) => {
                const val = e.target.value.replace(/\D/g, '').slice(0, 6);
                setOtp(val);
              }}
              autoFocus
              slotProps={{
                input: {
                  startAdornment: (
                    <InputAdornment position="start">
                      <PinOutlinedIcon sx={{ fontSize: 18, color: '#94a3b8' }} />
                    </InputAdornment>
                  ),
                },
                htmlInput: { maxLength: 6 },
              }}
              sx={textFieldSx}
            />
            <Box sx={{ mt: 1.5, textAlign: 'right' }}>
              {resendCooldown > 0 ? (
                <Typography sx={{ fontSize: '0.75rem', color: '#94a3b8' }}>
                  {t('forgotPassword.resendIn', { seconds: resendCooldown })}
                </Typography>
              ) : (
                <Link
                  component="button"
                  onClick={handleResendOtp}
                  underline="none"
                  disabled={loading}
                  sx={{
                    fontSize: '0.75rem',
                    color: '#0d9488',
                    fontWeight: 500,
                    cursor: 'pointer',
                    '&:hover': { color: '#0f766e' },
                  }}
                >
                  {t('forgotPassword.resendOtp')}
                </Link>
              )}
            </Box>
          </Box>
        )}

        {/* Step 3: Reset Password */}
        {step === 'reset' && (
          <Box>
            <Typography
              component="label"
              sx={{
                display: 'block',
                fontWeight: 500,
                color: '#334155',
                fontSize: '0.78rem',
                mb: 0.6,
              }}
            >
              {t('forgotPassword.newPassword')}
            </Typography>
            <TextField
              placeholder={t('forgotPassword.newPasswordPlaceholder')}
              fullWidth
              size="small"
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              autoFocus
              slotProps={{
                input: {
                  startAdornment: (
                    <InputAdornment position="start">
                      <LockOutlinedIcon sx={{ fontSize: 18, color: '#94a3b8' }} />
                    </InputAdornment>
                  ),
                },
              }}
              sx={{ ...textFieldSx, mb: 2 }}
            />

            <Typography
              component="label"
              sx={{
                display: 'block',
                fontWeight: 500,
                color: '#334155',
                fontSize: '0.78rem',
                mb: 0.6,
              }}
            >
              {t('forgotPassword.confirmPassword')}
            </Typography>
            <TextField
              placeholder={t('forgotPassword.confirmPasswordPlaceholder')}
              fullWidth
              size="small"
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              slotProps={{
                input: {
                  startAdornment: (
                    <InputAdornment position="start">
                      <LockOutlinedIcon sx={{ fontSize: 18, color: '#94a3b8' }} />
                    </InputAdornment>
                  ),
                },
              }}
              sx={textFieldSx}
            />
          </Box>
        )}
      </DialogContent>

      <DialogActions sx={{ px: 3, pb: 3, pt: 1.5, gap: 1 }}>
        {/* Cancel / Back button */}
        {step === 'email' && (
          <Button
            onClick={onClose}
            variant="outlined"
            sx={{
              textTransform: 'none',
              fontWeight: 500,
              borderRadius: '12px',
              borderColor: '#e2e8f0',
              color: '#64748b',
              fontSize: '0.85rem',
              '&:hover': {
                borderColor: '#cbd5e1',
                bgcolor: '#f8fafc',
              },
            }}
          >
            {t('forgotPassword.cancel')}
          </Button>
        )}
        {step === 'otp' && (
          <Button
            onClick={handleBack}
            variant="outlined"
            sx={{
              textTransform: 'none',
              fontWeight: 500,
              borderRadius: '12px',
              borderColor: '#e2e8f0',
              color: '#64748b',
              fontSize: '0.85rem',
              '&:hover': {
                borderColor: '#cbd5e1',
                bgcolor: '#f8fafc',
              },
            }}
          >
            {t('forgotPassword.back')}
          </Button>
        )}

        {/* Primary action button */}
        {step === 'email' && (
          <Button
            onClick={handleEmailSubmit}
            variant="contained"
            disabled={loading || !email}
            sx={primaryButtonSx}
          >
            {loading ? (
              <CircularProgress size={20} sx={{ color: '#14b8a6' }} />
            ) : (
              t('forgotPassword.submitEmail')
            )}
          </Button>
        )}
        {step === 'otp' && (
          <Button
            onClick={handleVerifyOtp}
            variant="contained"
            disabled={loading || otp.length !== 6}
            sx={primaryButtonSx}
          >
            {loading ? (
              <CircularProgress size={20} sx={{ color: '#14b8a6' }} />
            ) : (
              t('forgotPassword.verifyOtp')
            )}
          </Button>
        )}
        {step === 'reset' && (
          <Button
            onClick={handleResetPassword}
            variant="contained"
            disabled={loading || !newPassword || !confirmPassword}
            fullWidth
            sx={primaryButtonSx}
          >
            {loading ? (
              <CircularProgress size={20} sx={{ color: '#14b8a6' }} />
            ) : (
              t('forgotPassword.resetPassword')
            )}
          </Button>
        )}
      </DialogActions>
    </Dialog>
  );
};

export default ForgotPasswordDialog;

# Architecture Diagrams
## KSP WorkBoard — Police Station Management System

| Field | Details |
|-------|---------|
| **Document Title** | Architecture Diagrams Compendium |
| **Application Name** | KSP WorkBoard |
| **Version** | 1.0.0 |
| **Date** | June 2026 |
| **Diagram Tool** | Mermaid |
| **Status** | Final |

---

## 1. System Context Diagram (C4 Level 1)

Shows the system boundary and external actors/systems.

```mermaid
graph TB
    subgraph "External Actors"
        ADMIN_USER[👤 Admin<br>System Administrator]
        HO_USER[👤 Higher Officer<br>ACP/RSI]
        GEN_USER[👤 General User<br>APC/AHC Constables]
    end

    subgraph "KSP WorkBoard System"
        KSP[🏢 KSP WorkBoard<br>Police Station Management<br>Web Application]
    end

    subgraph "External Systems"
        GROQ[☁️ Groq API<br>LLM Provider<br>Development]
        BEDROCK[☁️ AWS Bedrock<br>LLM Provider<br>Production]
        WHISPER[🎤 Groq Whisper<br>Speech-to-Text]
    end

    ADMIN_USER -->|"Manages system,<br>configures duties,<br>approves leaves"| KSP
    HO_USER -->|"Manages personnel,<br>creates cycles,<br>approves leaves"| KSP
    GEN_USER -->|"Views schedule,<br>requests leave,<br>uses chat"| KSP

    KSP -->|"Function calling<br>Tool resolution"| GROQ
    KSP -->|"Function calling<br>Tool resolution"| BEDROCK
    KSP -->|"Audio transcription"| WHISPER
```

---

## 2. Container Diagram (C4 Level 2)

Shows the major containers (deployable units) and their communication.

```mermaid
graph TB
    subgraph "Client Device"
        BROWSER[🌐 Web Browser<br>Chrome/Firefox/Safari]
    end

    subgraph "AWS Cloud Infrastructure"
        subgraph "Frontend Hosting"
            CDN[CloudFront CDN<br>HTTPS Distribution]
            S3[S3 Bucket<br>React Build Assets<br>HTML/JS/CSS/SVG]
        end

        subgraph "Backend Server (EC2)"
            SPRINGBOOT[Spring Boot 3.4.4<br>Java 17 Runtime<br>Port 8080]
        end

        subgraph "Database Server"
            POSTGRES[(PostgreSQL 15+<br>with pgvector<br>22 Tables)]
        end
    end

    subgraph "External AI Services"
        AI_GROQ[Groq API<br>llama-3.3-70b-versatile<br>OpenAI-compatible]
        AI_BEDROCK[AWS Bedrock<br>amazon.nova-lite-v1:0<br>SDK-based]
    end

    BROWSER -->|"HTTPS<br>Static Assets"| CDN
    CDN --> S3
    BROWSER -->|"HTTPS REST<br>Authorization: Bearer JWT<br>JSON/Multipart"| SPRINGBOOT
    SPRINGBOOT -->|"JDBC<br>PostgreSQL Protocol"| POSTGRES
    SPRINGBOOT -->|"HTTPS REST<br>API Key Auth"| AI_GROQ
    SPRINGBOOT -->|"AWS SDK<br>IAM Role Auth"| AI_BEDROCK
```

---

## 3. Component Diagram — Backend Application

```mermaid
graph TB
    subgraph "Spring Boot Application"
        subgraph "Security Layer"
            JWT_FILTER[JwtAuthFilter<br>Token Validation]
            PII_FILTER[PiiFilter<br>Access Logging]
            SEC_CONFIG[SecurityConfig<br>Filter Chain + CORS]
        end

        subgraph "REST API Layer (18 Controllers)"
            AUTH_CTL[AuthController<br>/api/auth]
            PERS_CTL[PersonnelController<br>/api/personnel]
            LEAVE_CTL[LeaveController<br>/api/leave-requests]
            CYCLE_CTL[CycleController<br>/api/cycles]
            ADHOC_CTL[AdhocDutyController<br>/api/adhoc-duties]
            CHAT_CTL[ChatController<br>/api/chat]
            REPORT_CTL[ReportController<br>/api/reports]
            SCHED_CTL[ScheduleController<br>/api/schedules]
            DT_CTL[DutyTypeController<br>/api/duty-types]
            SEC_CTL[SectionController<br>/api/sections]
            HEALTH_CTL[HealthController<br>/api/health]
            OTHER_CTL[7 Other Controllers]
        end

        subgraph "Business Logic Layer (18 Services)"
            AUTH_SVC[AuthService]
            PERS_SVC[PersonnelService]
            LEAVE_SVC[LeaveService]
            CYCLE_SVC[CycleService]
            ADHOC_SVC[AdhocDutyService]
            SCHED_SVC[ScheduleService]
            DT_SVC[DutyTypeService]
            ASSIGN_SVC[AssignmentGenerationService]
            CONFLICT_SVC[LeaveConflictDetector]
            AUDIT_SVC[CycleAuditService]
            VALIDATOR[CycleValidator]
            REASSIGN_SVC[ReassignmentService]
        end

        subgraph "AI/Chat Pipeline"
            GATEWAY[InputGatewayService<br>Entry Point]
            SANITIZER[InputSanitizerService<br>Prompt Injection Detection]
            LANG_DET[LanguageDetectorService<br>EN/KN/HI Detection]
            FC[FunctionCallingService<br>LLM Tool Resolution]
            MCP_HOST[McpHost<br>Tool Registry + Router]
            MCP_1[DomainDbMcpServer<br>18 tools]
            MCP_2[CycleMcpServer<br>8 tools]
            MCP_3[AdhocMcpServer<br>4 tools]
            MCP_4[DocumentMcpServer<br>2 tools]
            MCP_5[ReportMcpServer<br>5 tools]
            RESP_BUILD[ResponseBuilderService]
            CB_MGR[CircuitBreakerManager<br>Resilience4j]
            CACHE[ResponseCacheService<br>Caffeine]
        end

        subgraph "Report Engine"
            PDF_GEN[6 PDF Generators<br>OpenPDF]
            EXCEL_GEN[5 Excel Generators<br>Apache POI]
            REPORT_FILE[ReportFileService<br>Storage]
        end

        subgraph "Data Access Layer (25 Repositories)"
            REPOS[(JPA Repositories<br>Spring Data)]
        end

        subgraph "Infrastructure"
            LLM_IF[LlmClient Interface]
            GROQ_IMPL[GroqLlmClient<br>REST + API Key]
            BEDROCK_IMPL[BedrockLlmClient<br>AWS SDK]
        end
    end

    %% Connections
    JWT_FILTER --> AUTH_CTL
    JWT_FILTER --> PERS_CTL
    JWT_FILTER --> CHAT_CTL

    AUTH_CTL --> AUTH_SVC
    PERS_CTL --> PERS_SVC
    LEAVE_CTL --> LEAVE_SVC
    CYCLE_CTL --> CYCLE_SVC
    ADHOC_CTL --> ADHOC_SVC
    CHAT_CTL --> GATEWAY
    REPORT_CTL --> PDF_GEN
    REPORT_CTL --> EXCEL_GEN

    CYCLE_SVC --> ASSIGN_SVC
    CYCLE_SVC --> VALIDATOR
    CYCLE_SVC --> AUDIT_SVC
    LEAVE_SVC --> CONFLICT_SVC

    GATEWAY --> SANITIZER
    GATEWAY --> LANG_DET
    GATEWAY --> FC
    GATEWAY --> MCP_HOST
    GATEWAY --> RESP_BUILD
    FC --> LLM_IF
    LLM_IF --> GROQ_IMPL
    LLM_IF --> BEDROCK_IMPL
    MCP_HOST --> MCP_1
    MCP_HOST --> MCP_2
    MCP_HOST --> MCP_3
    MCP_HOST --> MCP_4
    MCP_HOST --> MCP_5

    PERS_SVC --> REPOS
    LEAVE_SVC --> REPOS
    CYCLE_SVC --> REPOS
    ADHOC_SVC --> REPOS
    ASSIGN_SVC --> REPOS
```

---

## 4. Deployment Diagram

```mermaid
graph TB
    subgraph "Internet"
        CLIENT[👤 Police Officers<br>Various Devices]
    end

    subgraph "AWS Region: us-east-1"
        subgraph "VPC"
            subgraph "Public Subnet"
                ALB[Application Load Balancer<br>HTTPS Termination<br>Port 443]
            end

            subgraph "Private Subnet - App"
                EC2[EC2 Instance<br>t3.medium<br>Amazon Linux 2]
                JAVA_APP[Java 17 + Spring Boot<br>ksp-workboard.jar<br>systemd managed]
            end

            subgraph "Private Subnet - DB"
                PG_DB[(PostgreSQL 15<br>pgvector extension<br>Port 5432)]
            end
        end

        subgraph "CDN"
            CF_DIST[CloudFront Distribution<br>Edge Locations]
            S3_BUCKET[S3 Bucket<br>ksp-frontend-assets<br>React Build]
        end

        subgraph "AI Services"
            BEDROCK_SVC[AWS Bedrock<br>amazon.nova-lite-v1:0]
        end
    end

    subgraph "External (Internet)"
        GROQ_SVC[Groq Cloud<br>api.groq.com<br>LLama 3.3 + Whisper]
    end

    CLIENT -->|HTTPS :443| ALB
    CLIENT -->|HTTPS| CF_DIST
    CF_DIST --> S3_BUCKET
    ALB --> EC2
    EC2 --> JAVA_APP
    JAVA_APP -->|JDBC :5432| PG_DB
    JAVA_APP -->|AWS SDK| BEDROCK_SVC
    JAVA_APP -->|HTTPS REST| GROQ_SVC
```

---

## 5. Data Flow Diagram — Complete System

```mermaid
flowchart LR
    subgraph "Input Sources"
        TEXT[Text Message<br>English/Kannada/Hindi]
        VOICE[Voice Audio<br>WAV/MP3]
        FORM[Form Submission<br>JSON Fields]
        PDF[PDF Upload<br>Document]
        UI_ACTION[UI Action<br>Button Click]
    end

    subgraph "Frontend Processing"
        REACT[React SPA<br>Route to Service]
        AXIOS[Axios HTTP Client<br>JWT Injection]
    end

    subgraph "Backend Processing"
        SECURITY[Security Filter Chain<br>JWT + CORS + PII]
        CONTROLLER[Controller Layer<br>Validate + Route]
        SERVICE[Service Layer<br>Business Logic]
        CHAT_PIPE[Chat Pipeline<br>Sanitize→Detect→LLM→MCP]
        REPORT_ENG[Report Engine<br>PDF/Excel Generation]
    end

    subgraph "Data Stores"
        PG[(PostgreSQL<br>22 Tables)]
        CACHE_MEM[Caffeine Cache<br>500 entries, 60s TTL]
        VECTOR_DB[pgvector<br>Document Embeddings]
    end

    subgraph "External APIs"
        LLM[LLM API<br>Groq/Bedrock]
        STT_API[STT API<br>Whisper]
    end

    subgraph "Outputs"
        JSON_RESP[JSON Response<br>Table/Form/Confirmation]
        PDF_OUT[PDF Report<br>Binary Download]
        EXCEL_OUT[Excel Report<br>Binary Download]
    end

    TEXT --> REACT
    VOICE --> REACT
    FORM --> REACT
    PDF --> REACT
    UI_ACTION --> REACT
    REACT --> AXIOS --> SECURITY --> CONTROLLER

    CONTROLLER --> SERVICE --> PG
    CONTROLLER --> CHAT_PIPE
    CONTROLLER --> REPORT_ENG

    CHAT_PIPE --> LLM
    CHAT_PIPE --> CACHE_MEM
    CHAT_PIPE --> SERVICE
    VOICE --> STT_API

    PDF --> VECTOR_DB

    SERVICE --> JSON_RESP
    REPORT_ENG --> PDF_OUT
    REPORT_ENG --> EXCEL_OUT
    CHAT_PIPE --> JSON_RESP
```

---

## 6. Sequence Diagram — Full Chat Message Processing

```mermaid
sequenceDiagram
    participant U as 👤 User
    participant FE as React Frontend
    participant CC as ChatController
    participant GW as InputGatewayService
    participant SAN as InputSanitizerService
    participant LD as LanguageDetectorService
    participant FC as FunctionCallingService
    participant LLM as Groq/Bedrock LLM
    participant MH as McpHost
    participant MS as MCP Server
    participant DB as PostgreSQL
    participant RB as ResponseBuilderService
    participant CACHE as ResponseCacheService

    U->>FE: Types "ರಜೆ ಪಟ್ಟಿ ತೋರಿಸು" (Show leave list)
    FE->>CC: POST /api/chat/message
    CC->>CC: resolveUser(auth) → User{id:1, role:ADMIN}
    CC->>GW: processTextMessage(1, "ADMIN", message)

    GW->>SAN: sanitize(message)
    SAN-->>GW: {safe: true, sanitizedText: "ರಜೆ ಪಟ್ಟಿ ತೋರಿಸು"}

    GW->>LD: detect(sanitizedText)
    LD-->>GW: {language: "kn", responseLanguage: "kn", canonicalEnglish: "show leave list"}

    GW->>GW: Build ProcessingContext{userId:1, lang:"kn", normalized:"show leave list"}

    GW->>FC: resolveIntent(message, context)
    FC->>FC: buildMessages() → [system_prompt + user_message + "[RESPOND IN KANNADA]"]
    FC->>FC: buildToolDefinitions() → 37 tool specs
    FC->>LLM: POST /chat/completions {messages, tools, tool_choice:"auto"}
    LLM-->>FC: {choices:[{message:{tool_calls:[{function:{name:"get_leave_details", arguments:"{}"}}]}}]}
    FC->>FC: parseToolCallResponse() → ActionPlan{tool:"get_leave_details", params:{}}
    FC-->>GW: ActionPlan

    GW->>CACHE: get(actionPlan)
    CACHE-->>GW: Optional.empty (cache miss)

    GW->>MH: dispatch(actionPlan, context)
    MH->>MH: toolToServer.get("get_leave_details") → DomainDbMcpServer
    MH->>MS: executeTool("get_leave_details", {}, context)
    MS->>DB: SELECT from leave_requests JOIN personnel
    DB-->>MS: Leave data rows
    MS->>MS: Build TableResponseData{columns, rows, totalCount}
    MS-->>MH: McpToolResult.success(tableData)
    MH-->>GW: ToolExecutionResult.success

    GW->>CACHE: put(actionPlan, result)

    GW->>RB: buildResponse(results, context)
    RB->>RB: Format table, translate descriptions to Kannada
    RB-->>GW: ChatResponse{responseType:"table", data:TableResponseData}

    GW->>DB: INSERT chat_messages(userId, message, response, "GET_LEAVE_DETAILS")

    GW-->>CC: ChatResponse
    CC-->>FE: HTTP 200 + JSON
    FE->>FE: Detect responseType="table" → render DataTable
    FE-->>U: Displays leave requests in table format (Kannada headers)
```

---

## 7. Sequence Diagram — Leave Creation with Conflict Detection

```mermaid
sequenceDiagram
    participant U as 👤 Officer
    participant FE as Frontend
    participant LC as LeaveController
    participant LS as LeaveService
    participant PR as PersonnelRepo
    participant LR as LeaveRequestRepo
    participant CDAR as CycleDutyAssignmentRepo
    participant DB as Database

    U->>FE: Submit leave form (personnelId, SICK_LEAVE, 2026-06-25, 2026-06-26)
    FE->>LC: POST /api/leave-requests
    LC->>LS: submit(request)

    LS->>PR: findById(personnelId)
    PR->>DB: SELECT * FROM personnel WHERE id = ?
    DB-->>PR: Personnel record
    PR-->>LS: Personnel entity

    LS->>LR: findOverlapping(personnelId, startDate, endDate)
    LR->>DB: SELECT * FROM leave_requests WHERE personnel_id=? AND start_date<=? AND end_date>=? AND status!='CANCELLED'
    DB-->>LR: [] (no overlap)
    LR-->>LS: Empty list ✓

    LS->>DB: INSERT INTO leave_requests (personnel_id, leave_type, start_date, end_date, status='PENDING')
    DB-->>LS: LeaveRequest{id:42}

    LS-->>LC: LeaveRequestDto{id:42, status:PENDING}

    LC->>LS: findDutyConflicts(personnelId, startDate, endDate)
    LS->>CDAR: findByPersonIdAndDate(personnelId, 2026-06-25)
    CDAR->>DB: SELECT * FROM cycle_duty_assignments WHERE person_id=? AND date=?
    DB-->>CDAR: [Assignment{id:500, shiftType:DAY, platoonId:2}]
    LS->>CDAR: findByPersonIdAndDate(personnelId, 2026-06-26)
    DB-->>CDAR: [Assignment{id:501, shiftType:NIGHT, platoonId:2}]
    LS-->>LC: conflicts=[{assignmentId:500, date:2026-06-25}, {assignmentId:501, date:2026-06-26}]

    LC-->>FE: 201 Created {leave: LeaveDto, dutyConflicts: [...]}
    FE-->>U: Shows leave created + ⚠️ warning: 2 duty conflicts found
```

---

## 8. Sequence Diagram — Adhoc Duty Creation with Auto-Assignment

```mermaid
sequenceDiagram
    participant U as Officer
    participant AC as AdhocDutyController
    participant AS as AdhocDutyService
    participant PR as PersonnelRepo
    participant LCD as LeaveConflictDetector
    participant ADR as AdhocDutyRepo
    participant ADAR as AdhocDutyAssignmentRepo
    participant DB as Database

    U->>AC: POST /api/adhoc-duties {name:"VIP Escort", date:2026-07-01, count:10, pickFrom:"ALL_PLATOONS"}
    AC->>AS: createAdhocDuty(request)

    AS->>PR: findByIsActiveTrue()
    PR->>DB: SELECT * FROM personnel WHERE is_active = true
    DB-->>PR: 200+ personnel records

    AS->>AS: Filter by platoon membership (must have platoon_id)

    loop For each candidate
        AS->>LCD: isOnLeave(personId, 2026-07-01)
        LCD->>DB: SELECT FROM leave_requests WHERE personnel_id=? AND status='APPROVED' AND start_date<=date AND end_date>=date
        LCD-->>AS: true/false
    end

    AS->>AS: Filter out already-assigned to other adhoc duties
    AS->>AS: Apply minimum strength check
    AS->>AS: Select top 10 from available candidates

    AS->>ADR: save(AdhocDuty{requiredCount:10, actualCount:10})
    ADR->>DB: INSERT INTO adhoc_duties
    DB-->>ADR: AdhocDuty{id:8}

    loop For each selected person (10)
        AS->>ADAR: save(AdhocDutyAssignment{adhocDutyId:8, personId:X})
    end

    AS-->>AC: AdhocDutyResponse{id:8, actualCount:10, requiredCount:10}
    AC-->>U: 201 Created + response JSON
```

---

## 9. Sequence Diagram — Report PDF Generation

```mermaid
sequenceDiagram
    participant U as User
    participant FE as Frontend
    participant RC as ReportController
    participant GEN as PlatoonChartPdfGenerator
    participant DB as Database
    participant PDF as OpenPDF Library

    U->>FE: Click "Download Platoon Chart"
    FE->>RC: GET /api/reports/platoon-chart?date=2026-06-21&locale=en

    RC->>RC: Validate section param (C/D/E/F/G or null)
    RC->>RC: Build ReportRequest{type:"platoon_chart", date, section, locale}
    RC->>GEN: generate(reportRequest)

    GEN->>DB: Fetch active cycles for date
    GEN->>DB: Fetch cycle_duty_assignments for date
    GEN->>DB: Fetch personnel details for assigned IDs
    GEN->>DB: Fetch section/platoon names

    GEN->>PDF: Create Document
    GEN->>PDF: Add header (station name, date)
    GEN->>PDF: Create table (platoon columns × duty rows)
    GEN->>PDF: Fill personnel names per cell
    GEN->>PDF: Close document → byte[]
    GEN-->>RC: byte[] PDF data

    RC->>RC: Build response headers
    RC-->>FE: HTTP 200, Content-Type: application/pdf, Content-Disposition: attachment; filename="Section_C_21-06-2026.pdf"
    FE-->>U: Browser downloads PDF file
```

---

## 10. State Machine — Platoon Rotation (Circular)

```mermaid
stateDiagram-v2
    direction LR

    state "Cycle N" as CN {
        P1_C: Platoon 1 → Section C
        P2_D: Platoon 2 → Section D
        P3_E: Platoon 3 → Section E
        P4_F: Platoon 4 → Section F
        P5_G: Platoon 5 → Section G
    }

    state "Cycle N+1" as CN1 {
        P1_D: Platoon 1 → Section D
        P2_E: Platoon 2 → Section E
        P3_F: Platoon 3 → Section F
        P4_G: Platoon 4 → Section G
        P5_C: Platoon 5 → Section C
    }

    state "Cycle N+2" as CN2 {
        P1_E: Platoon 1 → Section E
        P2_F: Platoon 2 → Section F
        P3_G: Platoon 3 → Section G
        P4_C: Platoon 4 → Section C
        P5_D: Platoon 5 → Section D
    }

    CN --> CN1 : Rotate +1
    CN1 --> CN2 : Rotate +1
    CN2 --> CN : After 5 cycles, back to original
```

---

## 11. State Machine — Three-Shift Rotation Pattern

```mermaid
stateDiagram-v2
    direction LR

    state "Day 1 (index%3=0)" as D1 {
        A1: Group A → DAY
        B1: Group B → AFTERNOON
        C1: Group C → NIGHT
    }

    state "Day 2 (index%3=1)" as D2 {
        A2: Group A → NIGHT
        B2: Group B → DAY
        C2: Group C → AFTERNOON
    }

    state "Day 3 (index%3=2)" as D3 {
        A3: Group A → AFTERNOON
        B3: Group B → NIGHT
        C3: Group C → DAY
    }

    D1 --> D2 : Next day
    D2 --> D3 : Next day
    D3 --> D1 : Pattern repeats
```

---

## 12. Entity Relationship Diagram — Full Schema

```mermaid
erDiagram
    USERS {
        bigint id PK
        varchar username UK
        varchar password_hash
        varchar role
        varchar display_name
        varchar locale
        bigint personnel_id FK
        timestamp created_at
        timestamp updated_at
    }

    PERSONNEL {
        bigint id PK
        varchar badge_id UK
        varchar person_name
        varchar duty_type
        bigint duty_type_id FK
        varchar location
        varchar phone_number
        varchar email
        varchar designation
        varchar section
        date date_of_joining
        varchar vehicle_number
        varchar duty_location
        varchar pdms
        varchar licence_type
        varchar deployed_from
        bigint platoon_id FK
        boolean is_active
        timestamp created_at
        timestamp updated_at
    }

    PLATOONS {
        bigint id PK
        varchar name
        int base_offset
        timestamp created_at
    }

    SECTIONS {
        bigint id PK
        varchar code UK
        varchar name
        varchar description
        int sort_order
        boolean is_active
    }

    DUTY_TYPES {
        bigint id PK
        varchar name
        varchar section
        int sort_order
        double latitude
        double longitude
        int radius_meters
        bigint parent_id FK
    }

    SCHEDULE_CYCLES {
        bigint id PK
        date start_date
        date end_date
        int rotation_days
        varchar status
        bigint created_by
        timestamp created_at
        timestamp updated_at
    }

    CYCLE_PLATOON_SECTIONS {
        bigint id PK
        bigint cycle_id FK
        bigint platoon_id FK
        bigint section_id FK
    }

    CYCLE_DUTY_ASSIGNMENTS {
        bigint id PK
        bigint cycle_id FK
        date date
        bigint platoon_id FK
        bigint section_id FK
        bigint person_id FK
        varchar shift_type
        boolean is_override
        varchar group_index
        varchar status
        bigint adhoc_duty_id FK
        varchar duty_name
        timestamp updated_at
    }

    CYCLE_AUDIT_LOG {
        bigint id PK
        bigint cycle_id FK
        varchar action
        text description
        text old_value
        text new_value
        bigint performed_by
        timestamp created_at
    }

    LEAVE_REQUESTS {
        bigint id PK
        bigint personnel_id FK
        varchar leave_type
        date start_date
        date end_date
        varchar status
        varchar reason
        bigint approved_by FK
        varchar rejection_reason
        timestamp created_at
        timestamp updated_at
    }

    ADHOC_DUTIES {
        bigint id PK
        varchar duty_name
        date date
        time start_time
        time end_time
        int required_count
        int actual_count
        varchar pick_from
        jsonb platoon_ids
        varchar location
        boolean min_strength_check
        varchar status
        bigint created_by
        timestamp created_at
        timestamp updated_at
    }

    ADHOC_DUTY_ASSIGNMENTS {
        bigint id PK
        bigint adhoc_duty_id FK
        bigint person_id FK
    }

    CHAT_MESSAGES {
        bigint id PK
        bigint user_id FK
        text user_message
        text ai_response
        varchar command_type
        timestamp created_at
    }

    SHIFT_GROUPS {
        bigint id PK
        bigint cycle_id FK
        bigint section_id FK
        bigint platoon_id FK
        varchar group_name
        text personnel_ids
    }

    DOCUMENT_CHUNKS {
        bigint id PK
        bigint upload_id FK
        text content
        vector embedding
    }

    TRANSLATIONS {
        bigint id PK
        varchar translation_key
        varchar locale
        text translation_value
        varchar category
    }

    %% Relationships
    USERS ||--o| PERSONNEL : "personnel_id"
    PERSONNEL }o--o| DUTY_TYPES : "duty_type_id"
    PERSONNEL }o--o| PLATOONS : "platoon_id"
    DUTY_TYPES ||--o{ DUTY_TYPES : "parent_id (self-ref)"
    SCHEDULE_CYCLES ||--|{ CYCLE_PLATOON_SECTIONS : "cycle_id"
    CYCLE_PLATOON_SECTIONS }o--|| PLATOONS : "platoon_id"
    CYCLE_PLATOON_SECTIONS }o--|| SECTIONS : "section_id"
    SCHEDULE_CYCLES ||--|{ CYCLE_DUTY_ASSIGNMENTS : "cycle_id"
    CYCLE_DUTY_ASSIGNMENTS }o--|| PERSONNEL : "person_id"
    SCHEDULE_CYCLES ||--|{ CYCLE_AUDIT_LOG : "cycle_id"
    SCHEDULE_CYCLES ||--|{ SHIFT_GROUPS : "cycle_id"
    LEAVE_REQUESTS }o--|| PERSONNEL : "personnel_id"
    ADHOC_DUTIES ||--|{ ADHOC_DUTY_ASSIGNMENTS : "adhoc_duty_id"
    ADHOC_DUTY_ASSIGNMENTS }o--|| PERSONNEL : "person_id"
    CHAT_MESSAGES }o--|| USERS : "user_id"
```

---

## 13. Activity Diagram — User Login Flow

```mermaid
flowchart TD
    START([User opens application]) --> CHECK{Stored JWT token?}
    CHECK -->|Yes| VALIDATE[Validate token expiry]
    VALIDATE -->|Valid| HOME[Navigate to Home]
    VALIDATE -->|Expired| LOGIN_PAGE[Show Login Page]
    CHECK -->|No| LOGIN_PAGE

    LOGIN_PAGE --> ENTER[User enters credentials]
    ENTER --> SUBMIT[Submit login form]
    SUBMIT --> API_CALL[POST /api/auth/login]
    API_CALL --> SERVER{Server validates}
    SERVER -->|Invalid| ERROR[Show error message]
    ERROR --> ENTER
    SERVER -->|Valid| TOKEN[Receive JWT + role + locale]
    TOKEN --> STORE[Store token in MobX AuthStore]
    STORE --> HOME
    HOME --> ACTIVITY{User active?}
    ACTIVITY -->|Inactive 15min| DIALOG[Show Inactivity Dialog]
    DIALOG --> EXTEND{User responds?}
    EXTEND -->|Yes| HOME
    EXTEND -->|Timeout| LOGOUT[Clear token → Login Page]
```

---

## 14. Activity Diagram — Cycle Management Workflow

```mermaid
flowchart TD
    START([Officer needs new rotation]) --> NAV[Navigate to /schedules/cycles]
    NAV --> CLICK[Click "Create Cycle"]
    CLICK --> AUTO[System calls GET /api/cycles/auto-generate]
    AUTO --> FORM[Display pre-filled form<br>Start Date + Rotation Days + 5 Platoon Selectors]
    FORM --> ADJUST{Officer adjusts?}
    ADJUST -->|Yes| MODIFY[Change dates or platoon mappings]
    MODIFY --> FORM
    ADJUST -->|No| SUBMIT_FORM[Click "Create Cycle"]
    SUBMIT_FORM --> API[POST /api/cycles]
    API --> VALIDATE{Overlapping cycle?}
    VALIDATE -->|Yes| ERROR_MSG[Show error: dates overlap with cycle #X]
    ERROR_MSG --> FORM
    VALIDATE -->|No| CREATE[Create cycle + mappings]
    CREATE --> GENERATE[Generate ~3000 duty assignments]
    GENERATE --> AUDIT[Log to cycle_audit_log]
    AUDIT --> SUCCESS[Show success confirmation]
    SUCCESS --> LIST[Update cycle list]
    LIST --> END([Done])
```

---

## 15. Component Interaction — Frontend Navigation

```mermaid
flowchart TD
    subgraph "SideNavBar Component"
        NAV_HOME[🏠 Home]
        NAV_SCHED[📅 Schedules]
        NAV_PERS[👥 Personnel]
        NAV_LEAVE[📋 Leave Requests]
        NAV_REPORT[📄 Reports]
        NAV_ADMIN[⚙️ Admin Config]
        NAV_DUTY[└─ Duty Sections]
    end

    subgraph "Schedule Sub-Navigation"
        SCHED_MAIN[Schedule Overview]
        SCHED_ROT[Rotation Management]
        SCHED_CYC[Cycle Management]
        SCHED_ACT[Activities/Audit]
        SCHED_ADHOC[Adhoc Duties]
    end

    subgraph "Personnel Sub-Navigation"
        PERS_LIST[Personnel List]
        PERS_ADD[Add Person]
        PERS_PROFILE[Person Profile]
    end

    NAV_HOME --> |"/"| HOME_PAGE
    NAV_SCHED --> |"/schedules"| SCHED_MAIN
    SCHED_MAIN --> |"/schedules/rotation"| SCHED_ROT
    SCHED_MAIN --> |"/schedules/cycles"| SCHED_CYC
    SCHED_MAIN --> |"/schedules/activities"| SCHED_ACT
    SCHED_MAIN --> |"/schedules/adhoc"| SCHED_ADHOC
    NAV_PERS --> |"/personnel"| PERS_LIST
    PERS_LIST --> |"/personnel/add"| PERS_ADD
    PERS_LIST --> |"/personnel/:badgeId"| PERS_PROFILE
    NAV_LEAVE --> |"/leave-requests"| LEAVE_PAGE
    NAV_REPORT --> |"/reports"| REPORT_PAGE
    NAV_ADMIN --> NAV_DUTY
    NAV_DUTY --> |"/admin/duty-sections"| DUTY_PAGE
```

---

## 16. Security Architecture — Request Processing Pipeline

```mermaid
flowchart LR
    REQ[Incoming HTTP Request] --> CORS{CORS Check}
    CORS -->|Allowed Origin| JWT_CHECK{JWT Token Present?}
    CORS -->|Blocked Origin| REJECT_CORS[403 Forbidden]

    JWT_CHECK -->|No Token| PUBLIC{Public Endpoint?}
    PUBLIC -->|/api/auth/login<br>/api/health/**| ALLOW_PUBLIC[Process Request]
    PUBLIC -->|Other| REJECT_AUTH[401 Unauthorized]

    JWT_CHECK -->|Token Present| PARSE[Parse & Validate JWT]
    PARSE -->|Invalid/Expired| REJECT_AUTH
    PARSE -->|Valid| LOAD_USER[Load User from DB]
    LOAD_USER --> SET_AUTH[Set SecurityContext]
    SET_AUTH --> PII_LOG[PiiFilter: Log Access]
    PII_LOG --> ROLE_CHECK{Role Check}

    ROLE_CHECK -->|/api/admin/** & not ADMIN| REJECT_ROLE[403 Forbidden]
    ROLE_CHECK -->|Method @PreAuthorize fail| REJECT_ROLE
    ROLE_CHECK -->|Authorized| CONTROLLER[Execute Controller Method]

    CONTROLLER --> RESPONSE[Return Response]
```

---

## 17. Circuit Breaker State Diagram

```mermaid
stateDiagram-v2
    [*] --> CLOSED

    CLOSED : Requests flow normally
    CLOSED : Tracks failure rate in sliding window (10 calls)
    CLOSED --> OPEN : failure_rate >= 50% (min 3 calls)

    OPEN : All requests fail-fast with fallback
    OPEN : Timer: 60 seconds
    OPEN --> HALF_OPEN : After 60s timeout

    HALF_OPEN : Allows 2 probe requests
    HALF_OPEN --> CLOSED : Both probes succeed
    HALF_OPEN --> OPEN : Any probe fails
```

---

## 18. Cache Flow Diagram

```mermaid
flowchart TD
    REQ[Tool Execution Request] --> WRITE_CHECK{Is Write Tool?}
    WRITE_CHECK -->|Yes<br>add_person, create_leave<br>create_cycle, etc.| EXECUTE_WRITE[Execute Tool Directly]
    EXECUTE_WRITE --> INVALIDATE[Invalidate Related Cache Entries]
    INVALIDATE --> RETURN_RESULT[Return Result]

    WRITE_CHECK -->|No<br>search_personnel<br>get_leave_details, etc.| CACHE_CHECK{Cache Hit?}
    CACHE_CHECK -->|Hit| RETURN_CACHED[Return Cached Result<br>0ms latency]
    CACHE_CHECK -->|Miss| EXECUTE_READ[Execute Tool]
    EXECUTE_READ --> STORE_CACHE[Store in Cache<br>Key: toolName:sortedParams<br>TTL: 60s]
    STORE_CACHE --> RETURN_RESULT
```

---

## 19. MCP Tool Routing Diagram

```mermaid
flowchart TD
    LLM_RESULT[LLM Returns Tool Call<br>e.g., "get_leave_details"] --> MCP_HOST[McpHost.dispatch]
    MCP_HOST --> LOOKUP{toolToServer.get<br>toolName}

    LOOKUP -->|"search_personnel"<br>"get_leave_details"<br>"get_duty_types"<br>...18 tools| DOMAIN[DomainDbMcpServer]
    LOOKUP -->|"create_cycle"<br>"list_cycles"<br>"reassign_duty"<br>...8 tools| CYCLE[CycleMcpServer]
    LOOKUP -->|"create_adhoc_duty"<br>"list_adhoc_duties"<br>...4 tools| ADHOC[AdhocMcpServer]
    LOOKUP -->|"query_document"<br>"upload_document"| DOC[DocumentMcpServer]
    LOOKUP -->|"generate_*_pdf"<br>...5 tools| REPORT[ReportMcpServer]
    LOOKUP -->|Not found| ERROR[ToolExecutionResult.failure<br>"TOOL_NOT_FOUND"]

    DOMAIN --> RESULT[McpToolResult]
    CYCLE --> RESULT
    ADHOC --> RESULT
    DOC --> RESULT
    REPORT --> RESULT
```

---

## 20. Network Topology Diagram

```mermaid
graph LR
    subgraph "User Network"
        DEVICE[Officer's Device<br>Laptop/Mobile/Desktop]
    end

    subgraph "Internet"
        DNS[DNS Resolution<br>domain.police.gov.in]
    end

    subgraph "AWS Edge"
        CF[CloudFront POP<br>Nearest Edge Location]
    end

    subgraph "AWS VPC (us-east-1)"
        subgraph "Public Subnet (10.0.1.0/24)"
            ALB[ALB<br>:443 HTTPS]
        end
        subgraph "Private Subnet (10.0.2.0/24)"
            EC2_APP[EC2<br>:8080 HTTP]
        end
        subgraph "Private Subnet (10.0.3.0/24)"
            RDS_PG[PostgreSQL<br>:5432]
        end
    end

    DEVICE -->|HTTPS| DNS
    DNS --> CF
    DNS --> ALB
    CF -->|S3 Origin| S3_ORIGIN[S3: Frontend Assets]
    ALB -->|HTTP :8080| EC2_APP
    EC2_APP -->|TCP :5432| RDS_PG
    EC2_APP -->|HTTPS| GROQ_EXT[api.groq.com]
    EC2_APP -->|AWS SDK| BEDROCK_EXT[bedrock.us-east-1]
```

---

## 21. Observations

1. All diagrams are generated strictly from the codebase analysis — no assumed components.
2. The MCP architecture is a custom implementation, not the standard Anthropic MCP protocol.
3. The 3-shift rotation ensures fair duty distribution without same-shift on consecutive days.
4. The circular platoon rotation (5 platoons × 5 sections) completes a full cycle every 5 rotations.
5. Circuit breakers protect only external AI/STT calls — internal DB operations do not use circuit breakers.
6. The cache layer sits between the InputGatewayService and McpHost dispatch — not at the repository level.

---

## 22. Document Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0.0 | June 2026 | Generated from Codebase | Initial complete diagram set |

---

*End of Document — Architecture Diagrams v1.0.0*

# Application Handover Document
## KSP WorkBoard — Police Station Management System

| Field | Details |
|-------|---------|
| **Document Title** | Application Handover Document |
| **Version** | 1.0.0 |
| **Date** | June 2026 |
| **Purpose** | Complete knowledge transfer for system maintenance and operations |

---

## 1. Application Summary

| Attribute | Value |
|-----------|-------|
| Application Name | KSP WorkBoard |
| Purpose | Police station management (personnel, scheduling, leave, AI chat) |
| Organization | CAR Police Station, Mangalore |
| Backend Technology | Spring Boot 3.4.4, Java 17 |
| Frontend Technology | React 19, TypeScript, Vite 6 |
| Database | PostgreSQL 15+ with pgvector |
| AI Provider (Dev) | Groq API (llama-3.3-70b-versatile) |
| AI Provider (Prod) | AWS Bedrock (Amazon Nova Lite v1) |
| Total API Endpoints | 86 |
| Total Database Tables | 22 |
| Total Chat Tools | 37 |
| Total Frontend Pages | 14 |

---

## 2. Repository Structure

```
KSP/
├── backend/                         # Spring Boot Java application
│   ├── src/main/java/com/policescheduler/
│   │   ├── config/                  # Security, LLM client, RestTemplate
│   │   ├── controller/              # 18 REST controllers
│   │   ├── service/                 # 18 business logic services
│   │   ├── repository/              # 25 JPA repositories
│   │   ├── entity/                  # 25 JPA entities
│   │   ├── dto/                     # 39+ DTOs
│   │   ├── chat/                    # AI chat pipeline (MCP architecture)
│   │   ├── report/                  # Report generators (PDF + Excel)
│   │   ├── security/                # JWT filter, PII filter
│   │   └── exception/               # Custom exceptions
│   ├── src/main/resources/
│   │   └── application.yml          # Configuration
│   ├── deploy/aws/                  # Deployment scripts
│   ├── build.gradle                 # Dependencies
│   ├── .env.example                 # Environment template
│   └── gradlew / gradlew.bat       # Gradle wrapper
├── frontend/                        # React SPA
│   ├── src/
│   │   ├── pages/                   # 14 page components
│   │   ├── components/              # Shared UI components
│   │   ├── services/                # API client layer
│   │   ├── contexts/                # Auth, Theme contexts
│   │   ├── types/                   # TypeScript interfaces
│   │   └── i18n/                    # Internationalization
│   ├── package.json                 # Dependencies
│   ├── vite.config.ts               # Build config
│   └── .env.example                 # Frontend env template
└── docs/                            # This documentation set (20 documents)
```

---

## 3. Key Technical Contacts

| Role | Name | Contact | Responsibilities |
|------|------|---------|------------------|
| Developer | _____________ | _____________ | Code changes, bug fixes |
| DevOps | _____________ | _____________ | Deployment, infrastructure |
| DBA | _____________ | _____________ | Database management |
| Product Owner | _____________ | _____________ | Feature decisions |

---

## 4. Access Credentials & Accounts

### 4.1 AWS Account

| Item | Details |
|------|---------|
| AWS Account ID | _____________ |
| IAM Admin User | ksp-admin |
| Region | us-east-1 |
| EC2 Key Pair | ksp-key.pem (stored securely) |

### 4.2 Application Users

| Username | Role | Purpose |
|----------|------|---------|
| admin | ADMIN | System administration |
| _____________ | HIGHER_OFFICER | Officer operations |
| _____________ | GENERAL_USER | General access |

### 4.3 External Services

| Service | Account | API Key Location |
|---------|---------|-----------------|
| Groq (dev) | console.groq.com | .env file / systemd env |
| AWS Bedrock (prod) | Via IAM role (ksp-ec2-role) | No static key needed |

---

## 5. Build & Deploy Procedures

### 5.1 Local Development

```bash
# Backend
cd backend && cp .env.example .env  # Configure once
./gradlew bootRun                    # http://localhost:8080

# Frontend
cd frontend && npm install
npm run dev                          # http://localhost:5173
```

### 5.2 Production Deployment

```bash
# Full deploy (backend + frontend)
bash backend/deploy/aws/deploy.sh <EC2-IP>

# Backend only
bash backend/deploy/aws/deploy-backend.sh <EC2-IP>

# Frontend only
bash backend/deploy/aws/deploy-frontend.sh
```

### 5.3 Service Management

```bash
sudo systemctl start ksp-backend
sudo systemctl stop ksp-backend
sudo systemctl restart ksp-backend
sudo systemctl status ksp-backend
sudo journalctl -u ksp-backend -f    # Live logs
```

---

## 6. Database Management

### 6.1 Connection Details

| Environment | Host | Port | Database | User |
|-------------|------|------|----------|------|
| Local | localhost | 5432 | ksp_workboard | postgres |
| Production | RDS endpoint | 5432 | ksp_workboard | ksp_admin |

### 6.2 Backup Procedure

```bash
pg_dump -h <host> -U <user> -d ksp_workboard -Fc -f backup_$(date +%Y%m%d).dump
```

### 6.3 Required Extensions

```sql
CREATE EXTENSION IF NOT EXISTS vector;   -- For document embeddings
CREATE EXTENSION IF NOT EXISTS pg_trgm;  -- For fuzzy text search
```

---

## 7. Configuration Files

| File | Location | Purpose |
|------|----------|---------|
| application.yml | backend/src/main/resources/ | Spring Boot config |
| .env | backend/ (not in git) | Local environment variables |
| ksp-backend.service | /etc/systemd/system/ (EC2) | Production service config |
| .env.production | frontend/ | Frontend production API URL |
| vite.config.ts | frontend/ | Build configuration |
| package.json | frontend/ | Dependencies & scripts |
| build.gradle | backend/ | Java dependencies & build |

---

## 8. Monitoring & Alerting

### 8.1 Health Endpoints

| Endpoint | Purpose | Expected |
|----------|---------|----------|
| GET /api/health | System status | `{"status":"UP"}` |
| GET /api/health/ai | AI connectivity | `{"connected":true}` |

### 8.2 Log Locations

| Environment | Location | Command |
|-------------|----------|---------|
| Production | journald | `sudo journalctl -u ksp-backend` |
| Local | Console stdout | Visible in terminal |

### 8.3 Key Metrics to Monitor

- API response times (watch for > 5s on chat endpoints)
- Database connection pool usage
- LLM API error rate (circuit breaker state)
- Disk space on EC2 (/opt/ksp/logs)
- RDS storage utilization

---

## 9. Common Operational Tasks

### 9.1 Add New User

```sql
INSERT INTO users (username, password_hash, role, display_name, locale)
VALUES ('newuser', '$2a$10$...', 'GENERAL_USER', 'Display Name', 'en');
-- Generate hash: BCryptPasswordEncoder.encode("password")
```

### 9.2 Reset User Password

```sql
UPDATE users SET password_hash = '$2a$10$...' WHERE username = 'target_user';
```

### 9.3 Create Initial Data After Fresh Deploy

The `DataInitializer.java` auto-seeds sections, platoons, and default admin user if tables are empty.

### 9.4 Clear Chat History (if needed)

```sql
DELETE FROM chat_messages WHERE created_at < NOW() - INTERVAL '90 days';
```

### 9.5 Fix Stuck Cycle (ACTIVE past end date)

```sql
UPDATE schedule_cycles SET status = 'COMPLETED' WHERE status = 'ACTIVE' AND end_date < CURRENT_DATE;
```

---

## 10. Disaster Recovery

### 10.1 Scenario: EC2 Instance Failure

1. Launch new EC2 instance (same AMI/specs)
2. Run `setup-ec2.sh`
3. Deploy backend: `bash deploy-backend.sh <new-IP>`
4. Update CloudFront/ALB to point to new IP
5. Verify: `curl http://new-ip:8080/api/health`

### 10.2 Scenario: Database Corruption

1. Stop backend: `sudo systemctl stop ksp-backend`
2. Restore from latest backup: `pg_restore -d ksp_workboard backup.dump`
3. Re-enable extensions: `CREATE EXTENSION IF NOT EXISTS vector`
4. Restart: `sudo systemctl start ksp-backend`

### 10.3 Scenario: AI Provider Outage

- Circuit breaker auto-activates (60s open state)
- Chat returns fallback suggestions
- Non-chat features (UI, API, reports) continue working normally
- Switch provider: change `AI_PROVIDER` in systemd and restart

---

## 11. Documentation Set

| # | Document | File |
|---|----------|------|
| 1 | Business Requirements (BRD) | 01-BRD-Business-Requirements-Document.md |
| 2 | Software Requirements (SRS) | 02-SRS-Software-Requirements-Specification.md |
| 3 | High-Level Design (HLD) | 03-HLD-High-Level-Design.md |
| 4 | Low-Level Design (LLD) | 04-LLD-Low-Level-Design.md |
| 5 | Architecture Diagrams | 05-Architecture-Diagrams.md |
| 6 | API Documentation | 06-API-Documentation.md |
| 7 | Database Documentation | 07-Database-Documentation.md |
| 8 | Deployment Guide | 08-Deployment-Guide.md |
| 9 | Environment Configuration | 09-Environment-Configuration.md |
| 10 | Release Notes | 10-Release-Notes.md |
| 11 | User Manual | 11-User-Manual.md |
| 12 | Admin Guide | 12-Admin-Guide.md |
| 13 | Test Strategy & Report | 13-Test-Strategy-Report.md |
| 14 | UAT Test Cases | 14-UAT-Test-Cases.md |
| 15 | Chat Test Scenarios (310) | 15-Chat-Test-Scenarios.md |
| 16 | Feature List / Changelog | 16-Feature-List-Changelog.md |
| 17 | Known Issues & Limitations | 17-Known-Issues-Limitations.md |
| 18 | Future Roadmap | 18-Future-Roadmap.md |
| 19 | Application Handover | 19-Application-Handover-Document.md |
| 20 | Infrastructure Deep Dive | 20-Infrastructure-Deep-Dive.md |

---

## 12. Handover Checklist

| # | Item | Status |
|---|------|--------|
| 1 | Source code access granted | ☐ |
| 2 | AWS account access granted | ☐ |
| 3 | EC2 key pair transferred securely | ☐ |
| 4 | Database credentials shared | ☐ |
| 5 | Groq API key shared (if dev needed) | ☐ |
| 6 | All 20 documents reviewed | ☐ |
| 7 | Deployment run-through completed | ☐ |
| 8 | Health checks verified | ☐ |
| 9 | Backup procedure tested | ☐ |
| 10 | Emergency contacts documented | ☐ |

---

**Handover Completed By:** _________________ Date: _________  
**Received By:** _________________ Date: _________

---

*End of Document — Application Handover v1.0.0*

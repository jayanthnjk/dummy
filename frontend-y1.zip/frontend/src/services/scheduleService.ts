import api from './api';
import type {
  SectionOverview,
  DutyAssignmentDto,
  SectionCData,
  PlatoonRotationDto,
  UpdateAssignmentRequest,
} from '@/types';
import type {
  TeamMemberSchedule,
  OpenShift,
  ShiftType,
  Shift,
  CreateShiftRequest,
  PublishScheduleRequest,
} from '../types/schedule';

/** Computes duration in hours between two HH:mm time strings */
function computeHours(startTime: string, endTime: string): number {
  if (!startTime || !endTime) return 8;
  const [sh, sm] = startTime.split(':').map(Number);
  const [eh, em] = endTime.split(':').map(Number);
  let diff = (eh * 60 + em) - (sh * 60 + sm);
  if (diff <= 0) diff += 24 * 60; // overnight shift
  return Math.round((diff / 60) * 10) / 10;
}

// ===== V2 Types =====
export interface SectionPersonnelItem {
  id: number;
  badgeId: string;
  personName: string;
  designation: string;
  dutyType: string;
  location: string;
  vehicleNumber?: string;
  isActive: boolean;
  platoonId?: number;
}

export interface SectionPersonnelResponse {
  sectionCode: string;
  sectionName: string;
  totalCount: number;
  dutyGroups: Record<string, SectionPersonnelItem[]>;
}

export interface PlatoonMember {
  badgeId: string;
  personName: string;
  designation: string;
  section: string;
  dutyType: string;
}

export interface PlatoonChartResponse {
  platoons: Record<string, PlatoonMember[]>;
  currentRotation: Record<string, string>;
  totalPersonnel: number;
}

export const scheduleService = {
  // ===== Existing V1 methods =====
  getSectionsOverview: () =>
    api.get<SectionOverview>('/api/schedules/sections').then((r) => r.data),

  getSectionA: () =>
    api.get<DutyAssignmentDto[]>('/api/schedules/section-a').then((r) => r.data),

  getSectionB: () =>
    api.get<DutyAssignmentDto[]>('/api/schedules/section-b').then((r) => r.data),

  getSectionC: () =>
    api.get<SectionCData>('/api/schedules/section-c').then((r) => r.data),

  getPlatoonRotation: () =>
    api.get<PlatoonRotationDto>('/api/schedules/platoons').then((r) => r.data),

  rotatePlatoons: () =>
    api.post<PlatoonRotationDto>('/api/schedules/platoons/rotate').then((r) => r.data),

  updateAssignment: (id: number, data: UpdateAssignmentRequest) =>
    api.put<DutyAssignmentDto>(`/api/schedules/assignments/${id}`, data).then((r) => r.data),

  // ===== V2 methods =====
  getSectionPersonnel: (code: string) =>
    api.get<SectionPersonnelResponse>(`/api/schedules/v2/section/${code}`).then((r) => r.data),

  getPlatoonChart: () =>
    api.get<PlatoonChartResponse>('/api/schedules/v2/platoon-chart').then((r) => r.data),

  // ===== V3 methods (Schedule Page Redesign) =====

  /** Fetches all team member schedules for the given date range */
  fetchScheduleGrid: (start: string, end: string) =>
    api
      .get('/api/schedules/v3/grid', { params: { start, end } })
      .then((r) => {
        // Map backend DTO field names to frontend types
        return (r.data as any[]).map((item: any) => ({
          member: {
            id: item.id,
            badgeId: item.badgeId || '',
            name: item.name || '',
            avatar: undefined,
            role: item.designation || '',
            group: item.group || item.section || '',
            email: `${(item.badgeId || '').toLowerCase()}@ksp.gov.in`,
          },
          shifts: (item.shifts || []).map((s: any) => ({
            id: s.id,
            personnelId: item.id,
            date: s.date,
            startTime: s.startTime,
            endTime: s.endTime,
            shiftType: s.shiftTypeName || s.shiftType || 'Unknown',
            durationHours: computeHours(s.startTime, s.endTime),
          })),
          timeOffs: [],
          totalHours: 0, // Will be computed on the frontend
        })) as TeamMemberSchedule[];
      }),

  /** Fetches open (unassigned) shifts for the given date range */
  fetchOpenShifts: (start: string, end: string) =>
    api
      .get('/api/schedules/v3/open-shifts', { params: { start, end } })
      .then((r) => {
        return (r.data as any[]).map((s: any) => ({
          id: s.id,
          date: s.date,
          startTime: s.startTime,
          endTime: s.endTime,
          shiftType: s.shiftTypeName || s.shiftType || 'Unknown',
          durationHours: computeHours(s.startTime, s.endTime),
        })) as OpenShift[];
      }),

  /** Returns available shift types with their color configuration */
  fetchShiftTypes: () =>
    api.get<ShiftType[]>('/api/schedules/v3/shift-types').then((r) => r.data),

  /** Returns available groups/sections for filtering */
  fetchGroups: () =>
    api.get<string[]>('/api/schedules/v3/groups').then((r) => r.data),

  /** Creates a new shift assignment */
  createShift: (request: CreateShiftRequest) =>
    api.post<Shift>('/api/schedules/v3/shifts', request).then((r) => r.data),

  /** Publishes the schedule for a date range */
  publishSchedule: (request: PublishScheduleRequest) =>
    api.post<void>('/api/schedules/v3/publish', request).then((r) => r.data),

  /** Exports the schedule as a downloadable file (CSV or PDF) */
  exportSchedule: (start: string, end: string, format: 'csv' | 'pdf') =>
    api
      .get<Blob>('/api/schedules/v3/export', {
        params: { start, end, format },
        responseType: 'blob',
      })
      .then((r) => r.data),
};

import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { AdminRoute } from '@/components/AdminRoute';
import InactivityDialog from '@/components/InactivityDialog';
import LoginPage from '@/pages/LoginPage';
import HomePage from '@/pages/HomePage';
import PersonnelPage from '@/pages/PersonnelPage';
import AddPersonPage from '@/pages/AddPersonPage';
import PersonnelProfilePage from '@/pages/PersonnelProfilePage';
import SchedulesPage from '@/pages/SchedulesPage';
import RotationManagementPage from '@/pages/RotationManagementPage';
import CycleManagementPage from '@/pages/CycleManagementPage';
import LeaveRequestsPage from '@/pages/LeaveRequestsPage';

import CycleActivitiesPage from '@/pages/CycleActivitiesPage';
import DutySectionsPage from '@/pages/DutySectionsPage';
import ReportsPage from '@/pages/ReportsPage';
import ContactSupportPage from '@/pages/ContactSupportPage';

const App: React.FC = () => {
  return (
    <BrowserRouter>
      <InactivityDialog />
      <Routes>
        <Route path="/login" element={<LoginPage />} />

        {/* Protected routes - require authentication */}
        <Route element={<ProtectedRoute />}>
          <Route path="/" element={<HomePage />} />
          <Route path="/personnel" element={<PersonnelPage />} />
          <Route path="/personnel/add" element={<AddPersonPage />} />
          <Route path="/personnel/:badgeId" element={<PersonnelProfilePage />} />
          <Route path="/schedules" element={<SchedulesPage />} />
          <Route path="/schedules/rotation" element={<RotationManagementPage />} />
          <Route path="/schedules/cycles" element={<CycleManagementPage />} />
          <Route path="/schedules/activities" element={<CycleActivitiesPage />} />
          <Route path="/leave-requests" element={<LeaveRequestsPage />} />
          <Route path="/reports" element={<ReportsPage />} />
          <Route path="/contact-support" element={<ContactSupportPage />} />

          {/* Admin-only routes */}
          <Route element={<AdminRoute />}>
            <Route path="/admin/duty-sections" element={<DutySectionsPage />} />
          </Route>
        </Route>

        {/* Catch-all redirect */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;

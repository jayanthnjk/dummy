import React, { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  TextField,
  Button,
  Alert,
  CircularProgress,
  Typography,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import PageHeader from '@/components/common/PageHeader';
import api from '@/services/api';

const ChangePasswordPage: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!currentPassword || !newPassword || !confirmPassword) {
      setError('All fields are required');
      return;
    }
    if (newPassword !== confirmPassword) {
      setError('New password and confirmation do not match');
      return;
    }
    if (newPassword.length < 6) {
      setError('New password must be at least 6 characters');
      return;
    }

    setLoading(true);
    try {
      await api.post('/api/auth/change-password', { currentPassword, newPassword });
      setSuccess('Password changed successfully');
      setTimeout(() => navigate(-1), 1500);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to change password');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', bgcolor: 'background.default' }}>
      <PageHeader
        title={t('nav.changePassword', 'Change Password')}
        breadcrumbs={[
          { label: t('nav.home', 'Home'), path: '/' },
          { label: t('nav.changePassword', 'Change Password') },
        ]}
      />

      <Box sx={{ flex: 1, display: 'flex', justifyContent: 'center', px: { xs: 2, md: 4 }, py: 4 }}>
        <Card
          sx={{
            maxWidth: 480,
            width: '100%',
            alignSelf: 'flex-start',
            borderRadius: 2,
            border: (theme) => `1px solid ${theme.palette.divider}`,
          }}
          elevation={0}
        >
          <CardContent sx={{ p: 3 }}>
            <Typography variant="h6" fontWeight={600} sx={{ mb: 2 }}>
              {t('nav.changePassword', 'Change Password')}
            </Typography>

            {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
            {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}

            <Box
              component="form"
              onSubmit={handleSubmit}
              sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}
            >
              <TextField
                label={t('auth.currentPassword', 'Current Password')}
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                fullWidth
                required
                autoFocus
              />
              <TextField
                label={t('auth.newPassword', 'New Password')}
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                fullWidth
                required
                helperText={newPassword && newPassword.length < 6 ? 'Minimum 6 characters' : ''}
                error={!!newPassword && newPassword.length < 6}
              />
              <TextField
                label={t('auth.confirmPassword', 'Confirm New Password')}
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                fullWidth
                required
                helperText={confirmPassword && newPassword !== confirmPassword ? 'Passwords do not match' : ''}
                error={!!confirmPassword && newPassword !== confirmPassword}
              />

              <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1.5, mt: 1 }}>
                <Button
                  onClick={() => navigate(-1)}
                  disabled={loading}
                >
                  {t('common.cancel', 'Cancel')}
                </Button>
                <Button
                  type="submit"
                  variant="contained"
                  disabled={loading || !currentPassword.trim() || !newPassword.trim() || !confirmPassword.trim() || newPassword !== confirmPassword || newPassword.length < 6}
                  startIcon={loading ? <CircularProgress size={16} /> : undefined}
                >
                  {loading ? t('common.saving', 'Saving...') : t('common.save', 'Save')}
                </Button>
              </Box>
            </Box>
          </CardContent>
        </Card>
      </Box>
    </Box>
  );
};

export default ChangePasswordPage;

import React, { useState, useRef, useCallback } from 'react';
import {
  Alert,
  Box,
  Button,
  Chip,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  IconButton,
  InputLabel,
  MenuItem,
  Paper,
  Select,
  Snackbar,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import PreviewIcon from '@mui/icons-material/Preview';
import RemoveCircleOutlineIcon from '@mui/icons-material/RemoveCircleOutline';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import { useNavigate } from 'react-router-dom';
import {
  cycleService,
  type AdhocAssigneeInfo,
  type CreateAdhocDutyRequest,
} from '@/services/cycleService';
import TimePickerField from '@/components/common/TimePickerField';
import CounterInput from '@/components/common/CounterInput';
import PageHeader from '@/components/common/PageHeader';

const PLATOON_NAMES: Record<number, string> = {
  1: 'Platoon I',
  2: 'Platoon II',
  3: 'Platoon III',
  4: 'Platoon IV',
  5: 'Platoon V',
};

type SelectedPerson = AdhocAssigneeInfo & { manuallyAdded?: boolean };

const CreateAdhocDutyPage: React.FC = () => {
  const navigate = useNavigate();

  // Form state
  const [createForm, setCreateForm] = useState<CreateAdhocDutyRequest>({
    dutyName: '', date: '', startTime: '', endTime: '', requiredCount: 1,
  });
  const [pickFrom, setPickFrom] = useState('ALL_PLATOONS');
  const [selectedPlatoons, setSelectedPlatoons] = useState<number[]>([]);

  // Preview & personnel state
  const [selectedPersonnel, setSelectedPersonnel] = useState<SelectedPerson[]>([]);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewTriggered, setPreviewTriggered] = useState(false);
  const [creating, setCreating] = useState(false);

  // Search dialog state
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<AdhocAssigneeInfo[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const searchDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Snackbar
  const [snackbar, setSnackbar] = useState<{ open: boolean; message: string; severity: 'success' | 'error' }>({
    open: false, message: '', severity: 'success',
  });

  const todayStr = new Date().toISOString().split('T')[0];

  const handlePreview = useCallback(async () => {
    if (!createForm.date || !createForm.startTime || !createForm.endTime || !createForm.requiredCount) return;
    setPreviewLoading(true);
    setPreviewTriggered(true);
    try {
      const data = await cycleService.previewAdhocPersonnel(
        createForm.date, createForm.startTime, createForm.endTime,
        createForm.requiredCount, pickFrom,
        pickFrom === 'SPECIFIC_PLATOONS' ? selectedPlatoons : undefined
      );
      setSelectedPersonnel(data.map(p => ({ ...p, manuallyAdded: false })));
    } catch {
      setSnackbar({ open: true, message: 'Failed to preview personnel', severity: 'error' });
    } finally {
      setPreviewLoading(false);
    }
  }, [createForm, pickFrom, selectedPlatoons]);

  const handleRemovePersonnel = (personId: number) => {
    setSelectedPersonnel(prev => prev.filter(p => p.personId !== personId));
  };

  const handleAddPersonnel = (person: AdhocAssigneeInfo) => {
    if (selectedPersonnel.some(p => p.personId === person.personId)) return;
    setSelectedPersonnel(prev => [...prev, { ...person, manuallyAdded: true }]);
  };

  // Search with debounce
  const handleSearchQueryChange = (value: string) => {
    setSearchQuery(value);
    if (searchDebounceRef.current) {
      clearTimeout(searchDebounceRef.current);
    }
    if (value.length >= 2) {
      searchDebounceRef.current = setTimeout(() => {
        performSearch(value);
      }, 300);
    } else {
      setSearchResults([]);
    }
  };

  const performSearch = async (query: string) => {
    if (!createForm.date || !createForm.startTime || !createForm.endTime) return;
    setSearchLoading(true);
    try {
      const results = await cycleService.searchAdhocPersonnel(
        query, createForm.date, createForm.startTime, createForm.endTime
      );
      setSearchResults(results);
    } catch {
      setSnackbar({ open: true, message: 'Search failed', severity: 'error' });
    } finally {
      setSearchLoading(false);
    }
  };

  // Form validation
  const isToday = createForm.date === new Date().toISOString().split('T')[0];
  const nowTime = new Date().getHours().toString().padStart(2, '0') + ':' + new Date().getMinutes().toString().padStart(2, '0');
  
  const startTimeError = isToday && createForm.startTime && createForm.startTime < nowTime 
    ? 'Start time cannot be in the past' : '';
  const endTimeError = createForm.startTime && createForm.endTime && createForm.endTime <= createForm.startTime 
    ? 'End time must be after start time' : '';
  
  const formIsValid = !!(
    createForm.dutyName.trim() &&
    createForm.date &&
    createForm.startTime &&
    createForm.endTime &&
    createForm.requiredCount >= 1 &&
    !startTimeError &&
    !endTimeError
  );

  const handleCreate = async () => {
    if (!formIsValid) {
      setSnackbar({ open: true, message: 'Please fix form errors before submitting', severity: 'error' });
      return;
    }
    setCreating(true);
    try {
      const request: CreateAdhocDutyRequest = {
        ...createForm,
        pickFrom,
        platoonIds: pickFrom === 'SPECIFIC_PLATOONS' ? selectedPlatoons : undefined,
        personnelIds: selectedPersonnel.map(p => p.personId),
      };
      await cycleService.createAdhocDuty(request);
      setSnackbar({ open: true, message: 'Adhoc duty created successfully', severity: 'success' });
      // Navigate back after short delay so snackbar shows
      setTimeout(() => navigate('/schedules/adhoc'), 1000);
    } catch (err: any) {
      setSnackbar({ open: true, message: err.response?.data?.message || 'Failed to create', severity: 'error' });
    } finally {
      setCreating(false);
    }
  };

  const selectedCount = selectedPersonnel.length;
  const requiredCount = createForm.requiredCount;
  const countMatches = selectedCount === requiredCount;

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box sx={{ mb: 3 }}>
        <PageHeader
          title="Create Adhoc Duty"
          breadcrumbs={[
            { label: 'Home', path: '/' },
            { label: 'Adhoc Duties', path: '/schedules/adhoc' },
            { label: 'Create Adhoc Duty' },
          ]}
          actions={[
            {
              label: 'Back to Adhoc Duties',
              variant: 'ghost',
              icon: <ArrowBackIcon />,
              onClick: () => navigate('/schedules/adhoc'),
            },
          ]}
        />
      </Box>

      {/* Form */}
      <Paper sx={{ p: 3 }}>
        <Stack spacing={3}>
          {/* Duty Name */}
          <TextField
            label="Duty Name"
            value={createForm.dutyName}
            required
            fullWidth
            onChange={(e) => setCreateForm({ ...createForm, dutyName: e.target.value })}
          />

          {/* Date + Time Row */}
          <Stack direction="row" spacing={2}>
            <TextField
              type="date"
              label="Date"
              value={createForm.date}
              required
              fullWidth
              InputLabelProps={{ shrink: true }}
              inputProps={{ min: todayStr }}
              onChange={(e) => setCreateForm({ ...createForm, date: e.target.value })}
            />
            <TimePickerField
              label="Start Time"
              value={createForm.startTime}
              onChange={(val) => setCreateForm({ ...createForm, startTime: val })}
              selectedDate={createForm.date}
              error={!!startTimeError}
              helperText={startTimeError}
            />
            <TimePickerField
              label="End Time"
              value={createForm.endTime}
              onChange={(val) => setCreateForm({ ...createForm, endTime: val })}
              selectedDate={createForm.date}
              error={!!endTimeError}
              helperText={endTimeError}
            />
          </Stack>

          {/* Location + Required Count */}
          <Stack direction="row" spacing={2} alignItems="flex-end">
            <TextField
              label="Location"
              value={createForm.location || ''}
              fullWidth
              onChange={(e) => setCreateForm({ ...createForm, location: e.target.value })}
            />
            <CounterInput
              label="Required Count"
              value={createForm.requiredCount}
              onChange={(val) => setCreateForm({ ...createForm, requiredCount: val })}
              min={1}
            />
          </Stack>

          {/* Pick From + Platoons + Preview */}
          <Stack direction="row" spacing={2} alignItems="center" flexWrap="wrap">
            <FormControl sx={{ width: 200 }}>
              <InputLabel>Pick From</InputLabel>
              <Select value={pickFrom} label="Pick From" onChange={(e) => setPickFrom(e.target.value)}>
                <MenuItem value="ALL_PLATOONS">All Platoons</MenuItem>
                <MenuItem value="SPECIFIC_PLATOONS">Specific Platoons</MenuItem>
              </Select>
            </FormControl>
            {pickFrom === 'SPECIFIC_PLATOONS' && (
              <Stack direction="row" spacing={1} flexWrap="wrap">
                {[1, 2, 3, 4, 5].map((id) => (
                  <Chip
                    key={id}
                    label={PLATOON_NAMES[id]}
                    color={selectedPlatoons.includes(id) ? 'primary' : 'default'}
                    onClick={() =>
                      setSelectedPlatoons((prev) =>
                        prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id]
                      )
                    }
                  />
                ))}
              </Stack>
            )}
            <Button
              variant="outlined"
              startIcon={<PreviewIcon />}
              onClick={handlePreview}
              disabled={!formIsValid}
            >
              Auto-Pick Personnel
            </Button>
          </Stack>

          {previewLoading && (
            <Box sx={{ display: 'flex', justifyContent: 'center' }}>
              <CircularProgress size={24} />
            </Box>
          )}

          {/* Selected Personnel Table */}
          {previewTriggered && selectedPersonnel.length > 0 && (
            <Box>
              {selectedPersonnel.length < createForm.requiredCount && (
                <Alert severity="warning" sx={{ mb: 1 }}>
                  Only {selectedPersonnel.length} of {createForm.requiredCount} personnel selected
                </Alert>
              )}
              <TableContainer component={Paper} variant="outlined" sx={{ maxHeight: 300, overflow: 'auto' }}>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      <TableCell>Name</TableCell>
                      <TableCell>Badge ID</TableCell>
                      <TableCell>Section</TableCell>
                      <TableCell>Current Shift</TableCell>
                      <TableCell>Current Duty</TableCell>
                      <TableCell align="center">Disruption (min)</TableCell>
                      <TableCell>Source</TableCell>
                      <TableCell align="center">Actions</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {selectedPersonnel.map((p) => (
                      <TableRow key={p.personId}>
                        <TableCell>{p.personName}</TableCell>
                        <TableCell>{p.badgeId}</TableCell>
                        <TableCell>{p.section}</TableCell>
                        <TableCell>
                          <Chip
                            size="small"
                            label={p.originalShift}
                            sx={{
                              bgcolor:
                                p.originalShift === 'DAY'
                                  ? '#E8F5E9'
                                  : p.originalShift === 'AFTERNOON'
                                    ? '#F3E5F5'
                                    : '#E3F2FD',
                            }}
                          />
                        </TableCell>
                        <TableCell>{p.originalDutyName}</TableCell>
                        <TableCell align="center">{p.disruptionScore}</TableCell>
                        <TableCell>
                          <Chip
                            size="small"
                            label={p.manuallyAdded ? 'Manual' : 'Auto'}
                            color={p.manuallyAdded ? 'secondary' : 'default'}
                            variant="outlined"
                          />
                        </TableCell>
                        <TableCell align="center">
                          <Tooltip title="Remove">
                            <IconButton size="small" color="error" onClick={() => handleRemovePersonnel(p.personId)}>
                              <RemoveCircleOutlineIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
              <Button variant="outlined" startIcon={<PersonAddIcon />} onClick={() => setSearchOpen(true)} sx={{ mt: 1 }}>
                Add Manually
              </Button>
            </Box>
          )}

          {/* Empty state after preview triggered */}
          {previewTriggered && !previewLoading && selectedPersonnel.length === 0 && (
            <Box>
              <Alert severity="info">
                No personnel selected. Use &apos;Preview Personnel&apos; to auto-pick or &apos;Add Manually&apos; to search.
              </Alert>
              <Button variant="outlined" startIcon={<PersonAddIcon />} onClick={() => setSearchOpen(true)} sx={{ mt: 1 }}>
                Add Manually
              </Button>
            </Box>
          )}

          {/* Count indicator + Create button */}
          <Stack direction="row" spacing={2} alignItems="center" justifyContent="flex-end">
            {previewTriggered && (
              <Typography
                variant="body2"
                sx={{
                  color: countMatches ? 'success.main' : 'warning.main',
                  fontWeight: 'bold',
                }}
              >
                {selectedCount}/{requiredCount} selected
              </Typography>
            )}
            <Button onClick={() => navigate('/schedules/adhoc')} sx={{ mr: 1 }}>
              Cancel
            </Button>
            <Button
              variant="contained"
              onClick={handleCreate}
              disabled={creating || !formIsValid || selectedPersonnel.length !== createForm.requiredCount || selectedPersonnel.length === 0}
              sx={{ bgcolor: 'primary.main', color: '#ffffff', '&:hover': { bgcolor: 'primary.dark' } }}
            >
              {creating ? <CircularProgress size={20} /> : 'Confirm & Create'}
            </Button>
          </Stack>
        </Stack>
      </Paper>

      {/* Search Personnel Dialog */}
      <Dialog open={searchOpen} onClose={() => { setSearchOpen(false); setSearchQuery(''); setSearchResults([]); }} maxWidth="sm" fullWidth>
        <DialogTitle>Search Personnel</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField
              label="Search by name or badge ID"
              value={searchQuery}
              onChange={(e) => handleSearchQueryChange(e.target.value)}
              placeholder="Type at least 2 characters..."
              autoFocus
            />
            {searchLoading && <CircularProgress size={24} sx={{ alignSelf: 'center' }} />}
            {searchResults.length > 0 && (
              <TableContainer component={Paper} variant="outlined" sx={{ maxHeight: 300 }}>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      <TableCell>Name</TableCell>
                      <TableCell>Badge ID</TableCell>
                      <TableCell>Section</TableCell>
                      <TableCell>Shift</TableCell>
                      <TableCell align="center">Action</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {searchResults.map((person) => {
                      const alreadySelected = selectedPersonnel.some(p => p.personId === person.personId);
                      return (
                        <TableRow key={person.personId}>
                          <TableCell>{person.personName}</TableCell>
                          <TableCell>{person.badgeId}</TableCell>
                          <TableCell>{person.section}</TableCell>
                          <TableCell>{person.originalShift}</TableCell>
                          <TableCell align="center">
                            {alreadySelected ? (
                              <Chip size="small" label="Already selected" color="default" />
                            ) : (
                              <Button size="small" variant="outlined" onClick={() => handleAddPersonnel(person)}>
                                Add
                              </Button>
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
            {!searchLoading && searchQuery.length >= 2 && searchResults.length === 0 && (
              <Typography variant="body2" color="text.secondary" align="center">
                No results found
              </Typography>
            )}
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => { setSearchOpen(false); setSearchQuery(''); setSearchResults([]); }}>Close</Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar */}
      <Snackbar open={snackbar.open} autoHideDuration={4000} onClose={() => setSnackbar(s => ({ ...s, open: false }))}>
        <Alert severity={snackbar.severity}>{snackbar.message}</Alert>
      </Snackbar>
    </Box>
  );
};

export default CreateAdhocDutyPage;

import React, { createContext, useContext, useState, useCallback, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { LANGUAGE_STORAGE_KEY } from '@/i18n';
import type { Locale } from '@/types';

interface LanguageContextValue {
  locale: Locale;
  toggleLanguage: () => void;
}

const LanguageContext = createContext<LanguageContextValue>({
  locale: 'en',
  toggleLanguage: () => {},
});

export const useLanguageContext = () => useContext(LanguageContext);

export const LanguageContextProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { i18n } = useTranslation();

  const [locale, setLocale] = useState<Locale>(() => {
    const stored = localStorage.getItem(LANGUAGE_STORAGE_KEY);
    return (stored === 'en' || stored === 'kn') ? stored : 'en';
  });

  const toggleLanguage = useCallback(() => {
    const newLocale: Locale = locale === 'en' ? 'kn' : 'en';
    setLocale(newLocale);
    i18n.changeLanguage(newLocale);
    localStorage.setItem(LANGUAGE_STORAGE_KEY, newLocale);
  }, [locale, i18n]);

  const value = useMemo(() => ({ locale, toggleLanguage }), [locale, toggleLanguage]);

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};

import React, { useCallback, useEffect, useState } from 'react';
import {
  Box, Typography, Button, Alert, Skeleton, CircularProgress, alpha,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import PeopleIcon from '@mui/icons-material/People';
import PersonIcon from '@mui/icons-material/Person';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import GridOnIcon from '@mui/icons-material/GridOn';

import { useTranslation } from 'react-i18next';
import DataTable, { type Column } from '@/components/DataTable';
import PageHeader from '@/components/common/PageHeader';
import StatusBadge from '@/components/common/StatusBadge';
import { personnelService } from '@/services/personnelService';
import { sectionService } from '@/services/sectionService';
import api from '@/services/api';
import type { PersonnelDto } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

const PersonnelPage: React.FC = () => {
  const { t } = useTranslation();
  const { role } = useAuth();
  const navigate = useNavigate();
  const [data, setData] = useState<PersonnelDto[]>([]);
  const [filteredData, setFilteredData] = useState<PersonnelDto[]>([]);
  const [totalFromServer, setTotalFromServer] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [sectionCodes, setSectionCodes] = useState<string[]>([]);

  const canEdit = role === 'ADMIN' || role === 'HIGHER_OFFICER';
  const [selectedUnit, setSelectedUnit] = useState<'CAR' | 'MT'>('CAR');

  const fetchData = async () => {
    setLoading(true);
    try {
      const [result, sections] = await Promise.all([
        personnelService.list(undefined, 0, 2000),
        sectionService.list(),
      ]);
      setData(result.content);
      setFilteredData(result.content);
      setTotalFromServer(result.totalElements);
      setSectionCodes(sections.map(s => s.code));
    } catch {
      setError(t('app.error'));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const columns: Column<PersonnelDto>[] = [
    { id: 'badgeId', labelKey: 'personnel.badgeId', filterable: true, width: 100 },
    {
      id: 'personName', labelKey: 'personnel.personName', filterable: true, minWidth: 180,
      render: (row) => (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.2 }}>
          <Box
            component="img"
            src="/police-avatar.svg"
            alt=""
            sx={{
              width: 32, height: 32, borderRadius: '50%',
              flexShrink: 0,
            }}
          />
          <Box>
            <Typography sx={{ fontSize: '0.85rem', fontWeight: 500, color: '#111827', lineHeight: 1.2 }}>{row.personName}</Typography>
            {row.email && <Typography sx={{ fontSize: '0.72rem', color: '#9ca3af' }}>{row.email}</Typography>}
          </Box>
        </Box>
      ),
    },
    {
      id: 'designation', labelKey: 'personnel.designation', filterable: true,
      filterType: 'select', filterOptions: ['DCP', 'ACP', 'RPI', 'RSI', 'ARSI', 'AHC', 'APC'],
      render: (row) => row.designation ? (
        <Box sx={{
          display: 'inline-block', px: 1.2, py: 0.3, borderRadius: 1,
          bgcolor: row.designation === 'DCP' || row.designation === 'ACP' ? '#ede9fe' :
                   row.designation === 'RSI' || row.designation === 'RPI' ? '#dbeafe' : '#f0fdf4',
          color: row.designation === 'DCP' || row.designation === 'ACP' ? '#6d28d9' :
                 row.designation === 'RSI' || row.designation === 'RPI' ? '#1d4ed8' : '#166534',
          fontSize: '0.75rem', fontWeight: 600,
        }}>
          {row.designation}
        </Box>
      ) : null,
    },
    { id: 'dutyType', labelKey: 'personnel.dutyType', filterable: true },
    {
      id: 'section', labelKey: 'personnel.section', filterable: true,
      filterType: 'select', filterOptions: sectionCodes,
    },
    { id: 'location', labelKey: 'personnel.location' },
    {
      id: 'isActive', labelKey: 'personnel.active',
      render: (row) => (
        <StatusBadge
          status={row.isActive ? 'Active' : 'On Leave'}
          size="small"
          showDot
        />
      ),
    },
  ];

  const handleFilteredDataChange = useCallback((filtered: PersonnelDto[]) => {
    setFilteredData(filtered);
  }, []);

  const carCompanyCount = data.filter(p => !p.unit || p.unit.toUpperCase() === 'CAR').length;
  const mtPersonsCount = data.filter(p => p.unit && p.unit.toUpperCase() === 'MT').length;

  // Data filtered by selected unit for the table
  const unitFilteredData = data.filter(p => {
    if (selectedUnit === 'MT') return p.unit && p.unit.toUpperCase() === 'MT';
    return !p.unit || p.unit.toUpperCase() === 'CAR';
  });

  const [downloading, setDownloading] = useState<string | null>(null);

  const handleDownloadReport = async (endpoint: string, filename: string) => {
    setDownloading(endpoint);
    try {
      const response = await api.get(endpoint, { responseType: 'blob' });
      const url = window.URL.createObjectURL(response.data);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      link.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Download failed:', error);
    } finally {
      setDownloading(null);
    }
  };

  const breadcrumbs = [
    { label: 'Home', path: '/' },
    { label: 'Personnel' },
  ];

  const actions = canEdit
    ? [
        {
          label: t('personnel.addPerson'),
          variant: 'primary' as const,
          icon: <AddIcon />,
          onClick: () => navigate('/personnel/add'),
        },
      ]
    : undefined;

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', bgcolor: 'background.default' }}>
      {/* PageHeader replaces gradient banner */}
      <PageHeader
        title={t('personnel.title')}
        breadcrumbs={breadcrumbs}
        actions={actions}
      />

      {/* Main Content */}
      <Box sx={{ flex: 1, p: 3 }}>
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

        {/* Summary Metric Cards with Download Buttons */}
        <Box sx={{
          display: 'grid',
          gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)' },
          gap: 2,
          mb: 3,
        }}>
          {/* C.A.R COMPANY Card */}
          <Box
            onClick={() => setSelectedUnit('CAR')}
            sx={{
              border: selectedUnit === 'CAR' ? '2px solid #312e81' : '1px solid #e5e7eb',
              borderRadius: 2, p: 2, bgcolor: selectedUnit === 'CAR' ? '#f5f3ff' : '#fff',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              cursor: 'pointer', transition: 'all 0.2s',
              '&:hover': { borderColor: '#312e81', bgcolor: '#f5f3ff' },
            }}
          >
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
              <PeopleIcon sx={{ color: '#312e81', fontSize: 28 }} />
              <Box>
                <Typography sx={{ fontSize: '1.75rem', fontWeight: 700, color: '#111827', lineHeight: 1.1 }}>{carCompanyCount}</Typography>
                <Typography sx={{ fontSize: '0.8rem', color: '#6b7280' }}>C.A.R COMPANY</Typography>
              </Box>
            </Box>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Button
                size="small"
                variant="outlined"
                startIcon={downloading === '/api/reports/personnel' ? <CircularProgress size={16} /> : <PictureAsPdfIcon />}
                disabled={!!downloading}
                onClick={() => handleDownloadReport('/api/reports/personnel', 'CAR MANGALURU CITY (COMPANY).pdf')}
                sx={{
                  borderRadius: 2, textTransform: 'none', fontWeight: 600,
                  borderColor: '#16a34a', color: '#16a34a',
                  '&:hover': { bgcolor: alpha('#16a34a', 0.08), borderColor: '#16a34a' },
                }}
              >
                PDF
              </Button>
              <Button
                size="small"
                variant="outlined"
                startIcon={downloading === '/api/reports/personnel/excel' ? <CircularProgress size={16} /> : <GridOnIcon />}
                disabled={!!downloading}
                onClick={() => handleDownloadReport('/api/reports/personnel/excel', 'CAR MANGALURU CITY (COMPANY).xlsx')}
                sx={{
                  borderRadius: 2, textTransform: 'none', fontWeight: 600,
                  borderColor: '#16a34a', color: '#16a34a',
                  '&:hover': { bgcolor: alpha('#16a34a', 0.08), borderColor: '#16a34a' },
                }}
              >
                Excel
              </Button>
            </Box>
          </Box>

          {/* MT Persons Card */}
          <Box
            onClick={() => setSelectedUnit('MT')}
            sx={{
              border: selectedUnit === 'MT' ? '2px solid #059669' : '1px solid #e5e7eb',
              borderRadius: 2, p: 2, bgcolor: selectedUnit === 'MT' ? '#ecfdf5' : '#fff',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              cursor: 'pointer', transition: 'all 0.2s',
              '&:hover': { borderColor: '#059669', bgcolor: '#ecfdf5' },
            }}
          >
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
              <PersonIcon sx={{ color: '#059669', fontSize: 28 }} />
              <Box>
                <Typography sx={{ fontSize: '1.75rem', fontWeight: 700, color: '#111827', lineHeight: 1.1 }}>{mtPersonsCount}</Typography>
                <Typography sx={{ fontSize: '0.8rem', color: '#6b7280' }}>MT Persons</Typography>
              </Box>
            </Box>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Button
                size="small"
                variant="outlined"
                startIcon={downloading === '/api/reports/mt-section' ? <CircularProgress size={16} /> : <PictureAsPdfIcon />}
                disabled={!!downloading}
                onClick={() => handleDownloadReport('/api/reports/mt-section', 'MT_Section.pdf')}
                sx={{
                  borderRadius: 2, textTransform: 'none', fontWeight: 600,
                  borderColor: '#0891b2', color: '#0891b2',
                  '&:hover': { bgcolor: alpha('#0891b2', 0.08), borderColor: '#0891b2' },
                }}
              >
                PDF
              </Button>
              <Button
                size="small"
                variant="outlined"
                startIcon={downloading === '/api/reports/mt-section/excel' ? <CircularProgress size={16} /> : <GridOnIcon />}
                disabled={!!downloading}
                onClick={() => handleDownloadReport('/api/reports/mt-section/excel', 'MT_Section.xlsx')}
                sx={{
                  borderRadius: 2, textTransform: 'none', fontWeight: 600,
                  borderColor: '#0891b2', color: '#0891b2',
                  '&:hover': { bgcolor: alpha('#0891b2', 0.08), borderColor: '#0891b2' },
                }}
              >
                Excel
              </Button>
            </Box>
          </Box>
        </Box>

        {/* Data Table with skeleton loading and empty state */}
        {loading ? (
          <Box>
            {/* Table skeleton */}
            <Skeleton variant="rectangular" width="100%" height={48} sx={{ borderRadius: 2, mb: 1 }} />
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} variant="rectangular" width="100%" height={40} sx={{ borderRadius: 1, mb: 0.5 }} />
            ))}
          </Box>
        ) : data.length === 0 ? (
          <Box sx={{
            display: 'flex', flexDirection: 'column', alignItems: 'center',
            justifyContent: 'center', py: 8, color: '#9ca3af',
          }}>
            <PeopleIcon sx={{ fontSize: 48, mb: 2, opacity: 0.5 }} />
            <Typography sx={{ fontSize: '1rem', fontWeight: 500 }}>
              {t('personnel.noRecords', 'No personnel records found')}
            </Typography>
            <Typography sx={{ fontSize: '0.85rem', mt: 0.5, color: '#b0b0b0' }}>
              {t('personnel.noRecordsHint', 'Add personnel to get started')}
            </Typography>
          </Box>
        ) : (
          <DataTable<PersonnelDto>
            columns={columns}
            data={unitFilteredData}
            keyField="id"
            searchable
            searchPlaceholderKey="personnel.searchPlaceholder"
            dense
            onFilteredDataChange={handleFilteredDataChange}
            actions={(row) => (
              <Button size="small" onClick={() => navigate(`/personnel/${row.badgeId}`)}
                sx={{
                  textTransform: 'none', fontSize: '0.78rem', fontWeight: 500,
                  color: '#312e81', '&:hover': { bgcolor: '#f0f0ff' },
                }}>
                {t('app.view', 'View')}
              </Button>
            )}
          />
        )}
      </Box>
    </Box>
  );
};

export default PersonnelPage;

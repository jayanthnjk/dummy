package com.policescheduler.dto;

import com.policescheduler.entity.DutyHistory;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * DTO for duty history records.
 */
public record DutyHistoryDto(
    Long id,
    Long personId,
    String badgeId,
    String personName,
    String designation,
    LocalDate recordDate,
    String section,
    String dutyType,
    String dutyLocation,
    String worksAt,
    String adhocDuty,
    String leaveType,
    String shiftType,
    String status,
    LocalDateTime createdAt
) {
    /**
     * Factory method to create DTO from entity.
     */
    public static DutyHistoryDto fromEntity(DutyHistory entity) {
        return new DutyHistoryDto(
            entity.getId(),
            entity.getPersonId(),
            entity.getBadgeId(),
            entity.getPersonName(),
            entity.getDesignation(),
            entity.getRecordDate(),
            entity.getSection(),
            entity.getDutyType(),
            entity.getDutyLocation(),
            entity.getWorksAt(),
            entity.getAdhocDuty(),
            entity.getLeaveType(),
            entity.getShiftType(),
            entity.getStatus(),
            entity.getCreatedAt()
        );
    }
}

package com.policescheduler.report.generator;

import com.policescheduler.entity.*;
import com.policescheduler.repository.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Generates Form 168 Excel report for a specific cycle.
 * Structure matches the PDF version exactly:
 * S.NO | HEADS | ACP | RPI | RSI | ARSI | AHC | APC | SWP | TOTAL | PERSONNEL DETAILS
 * Grouped by: Section → Parent Duty (header) → Sub-duty rows → Totals
 */
@Service
public class CycleForm168ExcelGenerator {

    private static final Logger log = LoggerFactory.getLogger(CycleForm168ExcelGenerator.class);
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    private final CycleDutyAssignmentRepository cycleDutyAssignmentRepository;
    private final ScheduleCycleRepository scheduleCycleRepository;
    private final CyclePlatoonSectionRepository cyclePlatoonSectionRepository;
    private final PersonnelRepository personnelRepository;
    private final SectionRepository sectionRepository;
    private final PlatoonRepository platoonRepository;

    public CycleForm168ExcelGenerator(CycleDutyAssignmentRepository cycleDutyAssignmentRepository,
                                      ScheduleCycleRepository scheduleCycleRepository,
                                      CyclePlatoonSectionRepository cyclePlatoonSectionRepository,
                                      PersonnelRepository personnelRepository,
                                      SectionRepository sectionRepository,
                                      PlatoonRepository platoonRepository) {
        this.cycleDutyAssignmentRepository = cycleDutyAssignmentRepository;
        this.scheduleCycleRepository = scheduleCycleRepository;
        this.cyclePlatoonSectionRepository = cyclePlatoonSectionRepository;
        this.personnelRepository = personnelRepository;
        this.sectionRepository = sectionRepository;
        this.platoonRepository = platoonRepository;
    }

    public byte[] generate(Long cycleId) {
        ScheduleCycle cycle = scheduleCycleRepository.findById(cycleId)
                .orElseThrow(() -> new IllegalArgumentException("Cycle not found: " + cycleId));

        List<CycleDutyAssignment> assignments = cycleDutyAssignmentRepository
                .findByCycleIdAndDate(cycleId, cycle.getStartDate());

        if (assignments.isEmpty()) {
            throw new IllegalStateException("No assignments found for cycle " + cycleId);
        }

        List<Section> rotationSections = sectionRepository
                .findByIncludeInRotationTrueAndIsActiveTrueOrderByRotationOrder();
        Set<Long> rotationSectionIds = rotationSections.stream()
                .map(Section::getId).collect(Collectors.toSet());

        assignments = assignments.stream()
                .filter(a -> rotationSectionIds.contains(a.getSectionId()))
                .collect(Collectors.toList());

        Set<Long> personIds = assignments.stream().map(CycleDutyAssignment::getPersonId).collect(Collectors.toSet());
        Map<Long, Personnel> personnelMap = personnelRepository.findAllById(personIds).stream()
                .collect(Collectors.toMap(Personnel::getId, p -> p));

        Map<Long, Section> sectionMap = rotationSections.stream()
                .collect(Collectors.toMap(Section::getId, s -> s));
        Map<Long, Platoon> platoonMap = platoonRepository.findAll().stream()
                .collect(Collectors.toMap(Platoon::getId, p -> p));
        List<CyclePlatoonSection> mappings = cyclePlatoonSectionRepository.findByCycleId(cycleId);

        Map<Long, List<CycleDutyAssignment>> assignmentsBySection = assignments.stream()
                .collect(Collectors.groupingBy(CycleDutyAssignment::getSectionId));

        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Form 168 - Cycle #" + cycle.getCycleNumber());

            // Styles
            CellStyle titleStyle = createTitleStyle(workbook);
            CellStyle sectionHeaderStyle = createSectionHeaderStyle(workbook);
            CellStyle dutyHeaderStyle = createDutyHeaderStyle(workbook);
            CellStyle colHeaderStyle = createColHeaderStyle(workbook);
            CellStyle dataStyle = createDataStyle(workbook);
            CellStyle totalStyle = createTotalStyle(workbook);
            CellStyle personnelStyle = createPersonnelStyle(workbook);

            int rowIdx = 0;

            // Title
            Row titleRow = sheet.createRow(rowIdx++);
            Cell titleCell = titleRow.createCell(0);
            titleCell.setCellValue("FORM NO:168 — CYCLE #" + cycle.getCycleNumber());
            titleCell.setCellStyle(titleStyle);
            sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 10));

            Row dateRow = sheet.createRow(rowIdx++);
            Cell dateCell = dateRow.createCell(0);
            dateCell.setCellValue("Cycle: " + cycle.getStartDate().format(DATE_FMT) + " to " + cycle.getEndDate().format(DATE_FMT));
            dateCell.setCellStyle(titleStyle);
            sheet.addMergedRegion(new CellRangeAddress(1, 1, 0, 10));
            rowIdx++; // blank row

            // For each section
            for (Section section : rotationSections) {
                List<CycleDutyAssignment> sectionAssignments = assignmentsBySection
                        .getOrDefault(section.getId(), List.of());
                if (sectionAssignments.isEmpty()) continue;

                CyclePlatoonSection sMapping = mappings.stream()
                        .filter(m -> m.getSectionId().equals(section.getId()))
                        .findFirst().orElse(null);
                String platoonName = sMapping != null && platoonMap.containsKey(sMapping.getPlatoonId())
                        ? platoonMap.get(sMapping.getPlatoonId()).getName() : "—";

                // Section header
                Row secRow = sheet.createRow(rowIdx++);
                Cell secCell = secRow.createCell(0);
                secCell.setCellValue("SECTION " + section.getCode() + " — " + section.getName() + " (Platoon: " + platoonName + ")");
                secCell.setCellStyle(sectionHeaderStyle);
                sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 10));

                // Column headers
                Row hdrRow = sheet.createRow(rowIdx++);
                String[] headers = {"S.NO", "HEADS", "ACP", "RPI", "RSI", "ARSI", "AHC", "APC", "SWP", "TOTAL", "PERSONNEL DETAILS"};
                for (int i = 0; i < headers.length; i++) {
                    Cell c = hdrRow.createCell(i);
                    c.setCellValue(headers[i]);
                    c.setCellStyle(colHeaderStyle);
                }

                // Group by duty_type (parent)
                Map<String, List<CycleDutyAssignment>> byDutyType = sectionAssignments.stream()
                        .collect(Collectors.groupingBy(
                                a -> a.getDutyType() != null ? a.getDutyType() : "Unassigned",
                                LinkedHashMap::new, Collectors.toList()));

                int[] sectionTotals = new int[7];

                for (Map.Entry<String, List<CycleDutyAssignment>> dutyEntry : byDutyType.entrySet()) {
                    String dutyTypeName = dutyEntry.getKey();
                    List<CycleDutyAssignment> dutyAssignments = dutyEntry.getValue();

                    // Parent duty header
                    Row dutyHdrRow = sheet.createRow(rowIdx++);
                    Cell dutyHdrCell = dutyHdrRow.createCell(0);
                    dutyHdrCell.setCellValue(dutyTypeName);
                    dutyHdrCell.setCellStyle(dutyHeaderStyle);
                    sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 10));

                    // Group by duty_location (sub-duty)
                    Map<String, List<CycleDutyAssignment>> byLocation = dutyAssignments.stream()
                            .collect(Collectors.groupingBy(
                                    a -> a.getDutyLocationField() != null ? a.getDutyLocationField() : dutyTypeName,
                                    LinkedHashMap::new, Collectors.toList()));

                    int subSerial = 1;
                    int[] dutyTotals = new int[7];

                    for (Map.Entry<String, List<CycleDutyAssignment>> locEntry : byLocation.entrySet()) {
                        String locationName = locEntry.getKey();
                        List<CycleDutyAssignment> locAssignments = locEntry.getValue();

                        int[] counts = new int[7];
                        StringBuilder details = new StringBuilder();

                        for (CycleDutyAssignment a : locAssignments) {
                            Personnel p = personnelMap.get(a.getPersonId());
                            if (p == null) continue;
                            
                            // Skip DCP personnel in personnel details since there's no DCP column
                            String desig = p.getDesignation() != null ? p.getDesignation().toUpperCase().trim() : "";
                            if (desig.contains("DCP")) {
                                continue;
                            }
                            
                            int idx = getDesignationIndex(p.getDesignation());
                            if (idx >= 0) {
                                counts[idx]++;
                                dutyTotals[idx]++;
                                sectionTotals[idx]++;
                            }
                            if (details.length() > 0) details.append(", ");
                            details.append(formatPersonnel(p));
                        }

                        int total = Arrays.stream(counts).sum();

                        // Data row
                        Row dataRow2 = sheet.createRow(rowIdx++);
                        dataRow2.createCell(0).setCellValue(subSerial);
                        dataRow2.getCell(0).setCellStyle(dataStyle);
                        dataRow2.createCell(1).setCellValue(locationName);
                        dataRow2.getCell(1).setCellStyle(dataStyle);
                        for (int i = 0; i < 7; i++) {
                            Cell c = dataRow2.createCell(2 + i);
                            c.setCellValue(counts[i]);
                            c.setCellStyle(dataStyle);
                        }
                        Cell totalC = dataRow2.createCell(9);
                        totalC.setCellValue(total);
                        totalC.setCellStyle(dataStyle);
                        Cell detailC = dataRow2.createCell(10);
                        detailC.setCellValue(details.toString());
                        detailC.setCellStyle(personnelStyle);

                        subSerial++;
                    }

                    // Duty total row
                    Row dutyTotalRow = sheet.createRow(rowIdx++);
                    dutyTotalRow.createCell(1).setCellValue("TOTAL");
                    dutyTotalRow.getCell(1).setCellStyle(totalStyle);
                    for (int i = 0; i < 7; i++) {
                        Cell c = dutyTotalRow.createCell(2 + i);
                        c.setCellValue(dutyTotals[i]);
                        c.setCellStyle(totalStyle);
                    }
                    Cell dtCell = dutyTotalRow.createCell(9);
                    dtCell.setCellValue(Arrays.stream(dutyTotals).sum());
                    dtCell.setCellStyle(totalStyle);
                }

                // Section grand total
                Row grandRow = sheet.createRow(rowIdx++);
                grandRow.createCell(1).setCellValue("GRAND TOTAL");
                grandRow.getCell(1).setCellStyle(totalStyle);
                for (int i = 0; i < 7; i++) {
                    Cell c = grandRow.createCell(2 + i);
                    c.setCellValue(sectionTotals[i]);
                    c.setCellStyle(totalStyle);
                }
                Cell gtCell = grandRow.createCell(9);
                gtCell.setCellValue(Arrays.stream(sectionTotals).sum());
                gtCell.setCellStyle(totalStyle);

                rowIdx++; // blank between sections
            }

            // Set column widths
            sheet.setColumnWidth(0, 1500);  // S.NO
            sheet.setColumnWidth(1, 10000); // HEADS
            for (int i = 2; i <= 9; i++) sheet.setColumnWidth(i, 2000); // counts
            sheet.setColumnWidth(10, 15000); // PERSONNEL DETAILS

            ByteArrayOutputStream out = new ByteArrayOutputStream();
            workbook.write(out);
            return out.toByteArray();
        } catch (Exception e) {
            log.error("Failed to generate cycle Form 168 Excel: {}", e.getMessage(), e);
            throw new RuntimeException("Report generation failed", e);
        }
    }

    private String formatPersonnel(Personnel p) {
        if (p.getBadgeId() != null && !p.getBadgeId().isBlank() && !"-".equals(p.getBadgeId().trim())) {
            return p.getBadgeId().trim();
        }
        String desig = p.getDesignation() != null ? p.getDesignation() : "";
        String name = p.getPersonName() != null ? p.getPersonName() : "";
        return desig + " SRI " + name;
    }

    private int getDesignationIndex(String designation) {
        if (designation == null || designation.isBlank()) return -1;
        String upper = designation.toUpperCase().trim();
        if (upper.contains("ACP")) return 0;
        if (upper.contains("RPI")) return 1;
        if (upper.contains("ARSI")) return 3;
        if (upper.contains("RSI")) return 2;
        if (upper.contains("AHC")) return 4;
        if (upper.contains("APC")) return 5;
        return -1;
    }

    // ========== Styles ==========

    private CellStyle createTitleStyle(Workbook wb) {
        CellStyle style = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 12);
        font.setFontName("Arial");
        style.setFont(font);
        style.setAlignment(HorizontalAlignment.CENTER);
        return style;
    }

    private CellStyle createSectionHeaderStyle(Workbook wb) {
        CellStyle style = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 10);
        font.setFontName("Arial");
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.LIGHT_CORNFLOWER_BLUE.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        return style;
    }

    private CellStyle createDutyHeaderStyle(Workbook wb) {
        CellStyle style = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 9);
        font.setFontName("Arial");
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.LIGHT_YELLOW.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setBorderBottom(BorderStyle.THIN);
        return style;
    }

    private CellStyle createColHeaderStyle(Workbook wb) {
        CellStyle style = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 8);
        font.setFontName("Arial");
        style.setFont(font);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    private CellStyle createDataStyle(Workbook wb) {
        CellStyle style = wb.createCellStyle();
        Font font = wb.createFont();
        font.setFontHeightInPoints((short) 8);
        font.setFontName("Arial");
        style.setFont(font);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setAlignment(HorizontalAlignment.CENTER);
        return style;
    }

    private CellStyle createTotalStyle(Workbook wb) {
        CellStyle style = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 8);
        font.setFontName("Arial");
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setAlignment(HorizontalAlignment.CENTER);
        return style;
    }

    private CellStyle createPersonnelStyle(Workbook wb) {
        CellStyle style = wb.createCellStyle();
        Font font = wb.createFont();
        font.setFontHeightInPoints((short) 7);
        font.setFontName("Arial");
        style.setFont(font);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setWrapText(true);
        return style;
    }
}

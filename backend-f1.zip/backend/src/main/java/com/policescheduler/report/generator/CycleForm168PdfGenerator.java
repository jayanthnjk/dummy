package com.policescheduler.report.generator;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.policescheduler.entity.CycleDutyAssignment;
import com.policescheduler.entity.CyclePlatoonSection;
import com.policescheduler.entity.Personnel;
import com.policescheduler.entity.Platoon;
import com.policescheduler.entity.ScheduleCycle;
import com.policescheduler.entity.Section;
import com.policescheduler.report.Form168StyleHelper;
import com.policescheduler.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Generates a proper PDF Form 168 report for a specific cycle.
 * Reads from cycle_duty_assignments table.
 * Only includes rotation sections (C, D, E, F, G).
 * Uses same OpenPDF styles as the existing Form 168 generator.
 */
@Service
public class CycleForm168PdfGenerator {

    private static final Logger log = LoggerFactory.getLogger(CycleForm168PdfGenerator.class);
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    private static final String[] DESIG_COLS = {"ACP", "RPI", "RSI", "ARSI", "AHC", "APC", "SWP", "TOTAL"};

    private final Form168StyleHelper styleHelper;
    private final CycleDutyAssignmentRepository cycleDutyAssignmentRepository;
    private final ScheduleCycleRepository scheduleCycleRepository;
    private final CyclePlatoonSectionRepository cyclePlatoonSectionRepository;
    private final PersonnelRepository personnelRepository;
    private final SectionRepository sectionRepository;
    private final PlatoonRepository platoonRepository;

    public CycleForm168PdfGenerator(Form168StyleHelper styleHelper,
                                    CycleDutyAssignmentRepository cycleDutyAssignmentRepository,
                                    ScheduleCycleRepository scheduleCycleRepository,
                                    CyclePlatoonSectionRepository cyclePlatoonSectionRepository,
                                    PersonnelRepository personnelRepository,
                                    SectionRepository sectionRepository,
                                    PlatoonRepository platoonRepository) {
        this.styleHelper = styleHelper;
        this.cycleDutyAssignmentRepository = cycleDutyAssignmentRepository;
        this.scheduleCycleRepository = scheduleCycleRepository;
        this.cyclePlatoonSectionRepository = cyclePlatoonSectionRepository;
        this.personnelRepository = personnelRepository;
        this.sectionRepository = sectionRepository;
        this.platoonRepository = platoonRepository;
    }

    public byte[] generate(Long cycleId) {
        ScheduleCycle cycle = scheduleCycleRepository.findById(cycleId)
                .orElseThrow(() -> new IllegalArgumentException("Cycle not found: " + cycleId));

        // Get assignments for the first day (canonical)
        List<CycleDutyAssignment> assignments = cycleDutyAssignmentRepository
                .findByCycleIdAndDate(cycleId, cycle.getStartDate());

        if (assignments.isEmpty()) {
            throw new IllegalStateException("No assignments found for cycle " + cycleId);
        }

        // Get rotation sections
        List<Section> rotationSections = sectionRepository
                .findByIncludeInRotationTrueAndIsActiveTrueOrderByRotationOrder();
        Set<Long> rotationSectionIds = rotationSections.stream()
                .map(Section::getId).collect(Collectors.toSet());

        // Filter to rotation sections only
        assignments = assignments.stream()
                .filter(a -> rotationSectionIds.contains(a.getSectionId()))
                .collect(Collectors.toList());

        // Load personnel
        Set<Long> personIds = assignments.stream().map(CycleDutyAssignment::getPersonId).collect(Collectors.toSet());
        Map<Long, Personnel> personnelMap = personnelRepository.findAllById(personIds).stream()
                .collect(Collectors.toMap(Personnel::getId, p -> p));

        // Section/Platoon lookups
        Map<Long, Section> sectionMap = rotationSections.stream()
                .collect(Collectors.toMap(Section::getId, s -> s));
        Map<Long, Platoon> platoonMap = platoonRepository.findAll().stream()
                .collect(Collectors.toMap(Platoon::getId, p -> p));
        List<CyclePlatoonSection> mappings = cyclePlatoonSectionRepository.findByCycleId(cycleId);

        // Group by section
        Map<Long, List<CycleDutyAssignment>> assignmentsBySection = assignments.stream()
                .collect(Collectors.groupingBy(CycleDutyAssignment::getSectionId));

        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            Document document = new Document(PageSize.A4,
                    Form168StyleHelper.MARGIN_LEFT, Form168StyleHelper.MARGIN_RIGHT,
                    Form168StyleHelper.MARGIN_TOP, Form168StyleHelper.MARGIN_BOTTOM);
            PdfWriter.getInstance(document, baos);
            document.open();

            // Title
            Paragraph title = new Paragraph("FORM NO:168 — CYCLE #" + cycle.getCycleNumber(),
                    styleHelper.getTitleFont());
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);

            Paragraph dateP = new Paragraph("Cycle: " + cycle.getStartDate().format(DATE_FMT)
                    + " to " + cycle.getEndDate().format(DATE_FMT), styleHelper.getDataFont());
            dateP.setAlignment(Element.ALIGN_CENTER);
            dateP.setSpacingAfter(8f);
            document.add(dateP);

            // For each rotation section
            for (Section section : rotationSections) {
                List<CycleDutyAssignment> sectionAssignments = assignmentsBySection
                        .getOrDefault(section.getId(), List.of());
                if (sectionAssignments.isEmpty()) continue;

                // Find platoon for this section
                CyclePlatoonSection sMapping = mappings.stream()
                        .filter(m -> m.getSectionId().equals(section.getId()))
                        .findFirst().orElse(null);
                String platoonName = sMapping != null && platoonMap.containsKey(sMapping.getPlatoonId())
                        ? platoonMap.get(sMapping.getPlatoonId()).getName() : "—";

                renderSection(document, section, platoonName, sectionAssignments, personnelMap);
            }

            document.close();
            return baos.toByteArray();
        } catch (Exception e) {
            log.error("Failed to generate cycle Form 168 PDF: {}", e.getMessage(), e);
            throw new RuntimeException("PDF generation failed", e);
        }
    }

    private void renderSection(Document document, Section section, String platoonName,
                                List<CycleDutyAssignment> assignments, Map<Long, Personnel> personnelMap) throws DocumentException {
        // Section header
        PdfPTable headerTable = new PdfPTable(1);
        headerTable.setWidthPercentage(100);
        headerTable.setSpacingBefore(10f);
        PdfPCell sectionHeader = styleHelper.createSectionHeaderCell(
                "SECTION " + section.getCode() + " — " + section.getName() + " (Platoon: " + platoonName + ")", 1);
        headerTable.addCell(sectionHeader);
        document.add(headerTable);

        // Column headers
        float[] colWidths = {0.5f, 3f, 0.6f, 0.6f, 0.6f, 0.6f, 0.6f, 0.6f, 0.6f, 0.7f, 4f};
        PdfPTable table = new PdfPTable(colWidths.length);
        table.setWidthPercentage(100);
        table.setWidths(colWidths);

        String[] headers = {"S.NO", "HEADS", "ACP", "RPI", "RSI", "ARSI", "AHC", "APC", "SWP", "TOTAL", "PERSONNEL DETAILS"};
        for (String h : headers) {
            table.addCell(styleHelper.createHeaderCell(h));
        }

        // Group by duty_type (parent duty name)
        Map<String, List<CycleDutyAssignment>> byDutyType = assignments.stream()
                .collect(Collectors.groupingBy(
                        a -> a.getDutyType() != null ? a.getDutyType() : "Unassigned",
                        LinkedHashMap::new, Collectors.toList()));

        int serial = 1;
        int[] sectionTotals = new int[7];

        for (Map.Entry<String, List<CycleDutyAssignment>> dutyEntry : byDutyType.entrySet()) {
            String dutyTypeName = dutyEntry.getKey();
            List<CycleDutyAssignment> dutyAssignments = dutyEntry.getValue();

            // Duty type header (subsection)
            PdfPCell subHeader = styleHelper.createSubsectionHeaderCell(dutyTypeName, colWidths.length);
            table.addCell(subHeader);

            // Group by duty_location (sub-duty)
            Map<String, List<CycleDutyAssignment>> byLocation = dutyAssignments.stream()
                    .collect(Collectors.groupingBy(
                            a -> a.getDutyLocationField() != null ? a.getDutyLocationField() : dutyTypeName,
                            LinkedHashMap::new, Collectors.toList()));

            int subSerial = 1;
            int[] dutyTotals = new int[7];

            for (Map.Entry<String, List<CycleDutyAssignment>> locEntry : byLocation.entrySet()) {
                String locationName = locEntry.getKey();
                List<CycleDutyAssignment> locAssignments = locEntry.getValue();

                // Count designations and build personnel details (excluding DCP as there's no column)
                int[] counts = new int[7];
                StringBuilder personnelDetails = new StringBuilder();
                for (CycleDutyAssignment a : locAssignments) {
                    Personnel p = personnelMap.get(a.getPersonId());
                    if (p == null) continue;
                    
                    // Skip DCP personnel in personnel details since there's no DCP column
                    String desig = p.getDesignation() != null ? p.getDesignation().toUpperCase().trim() : "";
                    if (desig.contains("DCP")) {
                        continue;
                    }
                    
                    int idx = getDesignationIndex(p.getDesignation());
                    if (idx >= 0) {
                        counts[idx]++;
                        dutyTotals[idx]++;
                        sectionTotals[idx]++;
                    }
                    // Build personnel details string
                    if (personnelDetails.length() > 0) personnelDetails.append(", ");
                    personnelDetails.append(formatPersonnel(p));
                }
                int total = Arrays.stream(counts).sum();

                // Row
                table.addCell(styleHelper.createDataCell(String.valueOf(subSerial), Element.ALIGN_CENTER));
                table.addCell(styleHelper.createDataCell(locationName, Element.ALIGN_LEFT));
                for (int c : counts) {
                    table.addCell(styleHelper.createDataCell(String.valueOf(c), Element.ALIGN_CENTER));
                }
                table.addCell(styleHelper.createDataCell(String.valueOf(total), Element.ALIGN_CENTER));

                // Personnel details cell
                PdfPCell detailCell = new PdfPCell(new Phrase(personnelDetails.toString(), styleHelper.getPersonnelDetailsFont()));
                detailCell.setBorderWidth(Form168StyleHelper.BORDER_WIDTH);
                detailCell.setPadding(2f);
                table.addCell(detailCell);

                subSerial++;
            }

            // Duty total row
            table.addCell(styleHelper.createTotalCell("", Element.ALIGN_CENTER));
            table.addCell(styleHelper.createTotalCell("TOTAL", Element.ALIGN_RIGHT));
            for (int c : dutyTotals) {
                table.addCell(styleHelper.createTotalCell(String.valueOf(c), Element.ALIGN_CENTER));
            }
            int dutyTotal = Arrays.stream(dutyTotals).sum();
            table.addCell(styleHelper.createTotalCell(String.valueOf(dutyTotal), Element.ALIGN_CENTER));
            table.addCell(styleHelper.createTotalCell("", Element.ALIGN_LEFT));

            serial++;
        }

        // Grand total row
        table.addCell(styleHelper.createTotalCell("", Element.ALIGN_CENTER));
        table.addCell(styleHelper.createTotalCell("GRAND TOTAL", Element.ALIGN_RIGHT));
        for (int c : sectionTotals) {
            table.addCell(styleHelper.createTotalCell(String.valueOf(c), Element.ALIGN_CENTER));
        }
        int grandTotal = Arrays.stream(sectionTotals).sum();
        table.addCell(styleHelper.createTotalCell(String.valueOf(grandTotal), Element.ALIGN_CENTER));
        table.addCell(styleHelper.createTotalCell("", Element.ALIGN_LEFT));

        document.add(table);
    }

    private String formatPersonnel(Personnel p) {
        if (p.getBadgeId() != null && !p.getBadgeId().isBlank() && !"-".equals(p.getBadgeId().trim())) {
            // Badge ID already contains designation prefix (e.g., "APC-270"), use as-is
            return p.getBadgeId().trim();
        }
        // No badge — show "DESIGNATION SRI NAME"
        String desig = p.getDesignation() != null ? p.getDesignation() : "";
        String name = p.getPersonName() != null ? p.getPersonName() : "";
        return desig + " SRI " + name;
    }

    private int getDesignationIndex(String designation) {
        if (designation == null || designation.isBlank()) return -1;
        String upper = designation.toUpperCase().trim();
        if (upper.contains("ACP")) return 0;
        if (upper.contains("RPI")) return 1;
        if (upper.contains("ARSI")) return 3;
        if (upper.contains("RSI")) return 2;
        if (upper.contains("AHC")) return 4;
        if (upper.contains("APC")) return 5;
        return -1;
    }
}

import { makeAutoObservable, runInAction } from 'mobx';
import type { UserRole, AuthResponse } from '@/types';

const INACTIVITY_TIMEOUT = 5 * 60 * 1000; // 5 minutes
const DIALOG_COUNTDOWN = 60; // seconds

const SESSION_TOKEN = 'ksp-session-token';
const SESSION_ROLE = 'ksp-session-role';
const SESSION_NAME = 'ksp-session-name';
const SESSION_UNITS = 'ksp-session-units';

class AuthStore {
  token: string | null = null;
  role: UserRole | null = null;
  displayName: string | null = null;
  units: string | null = null;
  showInactivityDialog = false;
  inactivityCountdown = DIALOG_COUNTDOWN;

  private inactivityTimer: ReturnType<typeof setTimeout> | null = null;
  private countdownInterval: ReturnType<typeof setInterval> | null = null;
  private activityBound = false;

  constructor() {
    makeAutoObservable(this);

    // Clean up old localStorage tokens (migration)
    if (localStorage.getItem('ksp-workboard-token')) {
      localStorage.removeItem('ksp-workboard-token');
      localStorage.removeItem('ksp-workboard-role');
      localStorage.removeItem('ksp-workboard-name');
    }

    // Restore session from sessionStorage (survives refresh, clears on tab close)
    const savedToken = sessionStorage.getItem(SESSION_TOKEN);
    if (savedToken) {
      this.token = savedToken;
      this.role = sessionStorage.getItem(SESSION_ROLE) as UserRole | null;
      this.displayName = sessionStorage.getItem(SESSION_NAME);
      this.units = sessionStorage.getItem(SESSION_UNITS);
      this.startActivityTracking();
    }
  }

  get isAuthenticated(): boolean {
    return !!this.token;
  }

  get isAdmin(): boolean {
    return this.role === 'ADMIN';
  }

  get hasCAR(): boolean {
    return this.isAdmin || (this.units != null && this.units.includes('CAR'));
  }

  get hasMT(): boolean {
    return this.isAdmin || (this.units != null && this.units.includes('MT'));
  }

  get isCAROnly(): boolean {
    return !this.isAdmin && this.hasCAR && !this.units?.includes('MT');
  }

  get isMTOnly(): boolean {
    return !this.isAdmin && this.hasMT && !this.units?.includes('CAR');
  }

  login(authResponse: AuthResponse) {
    this.token = authResponse.token;
    this.role = authResponse.role as UserRole;
    this.displayName = authResponse.displayName;
    this.units = authResponse.units || 'CAR,MT';
    sessionStorage.setItem(SESSION_TOKEN, authResponse.token);
    sessionStorage.setItem(SESSION_ROLE, authResponse.role);
    sessionStorage.setItem(SESSION_NAME, authResponse.displayName);
    sessionStorage.setItem(SESSION_UNITS, authResponse.units || 'CAR,MT');
    this.startActivityTracking();
  }

  logout() {
    this.token = null;
    this.role = null;
    this.displayName = null;
    this.units = null;
    this.showInactivityDialog = false;
    this.inactivityCountdown = DIALOG_COUNTDOWN;
    sessionStorage.removeItem(SESSION_TOKEN);
    sessionStorage.removeItem(SESSION_ROLE);
    sessionStorage.removeItem(SESSION_NAME);
    sessionStorage.removeItem(SESSION_UNITS);
    sessionStorage.removeItem('ksp_chat_messages');
    this.stopActivityTracking();
  }

  staySignedIn() {
    this.showInactivityDialog = false;
    if (this.countdownInterval) {
      clearInterval(this.countdownInterval);
      this.countdownInterval = null;
    }
    this.inactivityCountdown = DIALOG_COUNTDOWN;
    this.resetInactivityTimer();
  }

  private resetInactivityTimer() {
    if (!this.token) return;
    if (this.showInactivityDialog) return;
    if (this.inactivityTimer) clearTimeout(this.inactivityTimer);
    this.inactivityTimer = setTimeout(() => {
      this.startCountdown();
    }, INACTIVITY_TIMEOUT);
  }

  private startCountdown() {
    runInAction(() => {
      this.inactivityCountdown = DIALOG_COUNTDOWN;
      this.showInactivityDialog = true;
    });
    this.countdownInterval = setInterval(() => {
      runInAction(() => {
        this.inactivityCountdown -= 1;
        if (this.inactivityCountdown <= 0) {
          this.logout();
        }
      });
    }, 1000);
  }

  private handleActivity = () => {
    this.resetInactivityTimer();
  };

  private startActivityTracking() {
    if (this.activityBound) return;
    const events = ['mousedown', 'keydown', 'scroll', 'touchstart', 'mousemove'];
    events.forEach((e) => window.addEventListener(e, this.handleActivity, { passive: true }));
    this.activityBound = true;
    this.resetInactivityTimer();
  }

  private stopActivityTracking() {
    if (this.inactivityTimer) { clearTimeout(this.inactivityTimer); this.inactivityTimer = null; }
    if (this.countdownInterval) { clearInterval(this.countdownInterval); this.countdownInterval = null; }
    if (this.activityBound) {
      const events = ['mousedown', 'keydown', 'scroll', 'touchstart', 'mousemove'];
      events.forEach((e) => window.removeEventListener(e, this.handleActivity));
      this.activityBound = false;
    }
  }
}

export const authStore = new AuthStore();

package com.policescheduler.report;

import com.policescheduler.entity.DutyType;
import com.policescheduler.entity.Personnel;
import com.policescheduler.report.dto.*;
import com.policescheduler.repository.DutyTypeRepository;
import com.policescheduler.repository.PersonnelRepository;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class ReportDataService {

    private static final List<String> DESIGNATION_COLUMNS =
            List.of("DCP", "ACP", "RPI", "RSI", "ARSI", "AHC", "APC");

    private final DutyTypeRepository dutyTypeRepository;
    private final PersonnelRepository personnelRepository;
    private final com.policescheduler.service.ReassignmentResolverService reassignmentResolverService;

    public ReportDataService(DutyTypeRepository dutyTypeRepository,
                             PersonnelRepository personnelRepository,
                             com.policescheduler.service.ReassignmentResolverService reassignmentResolverService) {
        this.dutyTypeRepository = dutyTypeRepository;
        this.personnelRepository = personnelRepository;
        this.reassignmentResolverService = reassignmentResolverService;
    }

    /**
     * Builds section report data.
     * Logic: filter personnel by unit=CAR + section code, group by duty_type and duty_location.
     */
    public SectionReportData buildSectionData(String section) {
        List<DutyType> topLevelTypes = dutyTypeRepository.findBySectionAndParentIsNullOrderBySortOrderAsc(section);

        // Get personnel: filter by section (support both 'A' and 'SECTION A') and unit=CAR
        List<Personnel> sectionPersonnel = new ArrayList<>();
        List<Personnel> byCode = personnelRepository.findBySectionAndIsActiveTrue(section);
        sectionPersonnel.addAll(byCode);
        if (section.length() <= 2) {
            List<Personnel> byFullName = personnelRepository.findBySectionAndIsActiveTrue("SECTION " + section);
            Set<Long> existingIds = sectionPersonnel.stream().map(Personnel::getId).collect(Collectors.toSet());
            for (Personnel p : byFullName) {
                if (!existingIds.contains(p.getId())) {
                    sectionPersonnel.add(p);
                }
            }
        }

        // Filter to CAR unit only (exclude MT personnel)
        sectionPersonnel = sectionPersonnel.stream()
                .filter(p -> !"MT".equalsIgnoreCase(p.getUnit()))
                .collect(Collectors.toList());

        // Apply reassignment resolution: show effective duty holders
        sectionPersonnel = reassignmentResolverService.resolveForSection(sectionPersonnel, section, java.time.LocalDate.now());

        // Group personnel by duty_type text (case-insensitive)
        Map<String, List<Personnel>> personnelByDutyType = sectionPersonnel.stream()
                .filter(p -> p.getDutyType() != null && !p.getDutyType().isBlank())
                .collect(Collectors.groupingBy(p -> p.getDutyType().toUpperCase().trim()));

        // Track assigned personnel to prevent duplicates
        Set<Long> assignedPersonnelIds = new HashSet<>();

        List<DutyCategoryRow> rows = new ArrayList<>();
        int[] grandTotals = new int[7];
        int serialNumber = 1;

        for (DutyType category : topLevelTypes) {
            String categoryName = category.getName().toUpperCase().trim();

            // Get children (sub-duty types from duty_types table)
            List<DutyType> children = dutyTypeRepository.findByParentIdOrderBySortOrderAsc(category.getId());

            // Find all personnel for this category:
            // Match by duty_type text = category name
            List<Personnel> categoryPersonnel = new ArrayList<>(
                    personnelByDutyType.getOrDefault(categoryName, List.of()));

            // Also match by duty_type_id FK
            for (Personnel p : sectionPersonnel) {
                if (p.getDutyTypeEntity() != null && p.getDutyTypeEntity().getId().equals(category.getId())) {
                    if (!categoryPersonnel.stream().anyMatch(cp -> cp.getId().equals(p.getId()))) {
                        categoryPersonnel.add(p);
                    }
                }
                // Also match if FK points to a child of this category
                for (DutyType child : children) {
                    if (p.getDutyTypeEntity() != null && p.getDutyTypeEntity().getId().equals(child.getId())) {
                        if (!categoryPersonnel.stream().anyMatch(cp -> cp.getId().equals(p.getId()))) {
                            categoryPersonnel.add(p);
                        }
                    }
                }
            }

            // Special: for designation-based category names like "DCP, ACP, RPI"
            // match personnel by their designation OR duty_type if category name contains comma-separated designations
            if (categoryName.contains(",") && !categoryName.contains("/") && !categoryName.contains("OFFICE")
                    && !categoryName.contains("TEAM")
                    && categoryName.length() < 25) {
                String[] parts = categoryName.split(",");
                Set<String> designationParts = new HashSet<>();
                for (String part : parts) {
                    String trimmed = part.trim().replaceAll("[^A-Z]", "");
                    if (!trimmed.isEmpty()) designationParts.add(trimmed);
                }
                for (Personnel p : sectionPersonnel) {
                    if (categoryPersonnel.stream().anyMatch(cp -> cp.getId().equals(p.getId()))) continue;
                    String pDesig = p.getDesignation() != null ? p.getDesignation().toUpperCase().trim() : "";
                    String pDutyType = p.getDutyType() != null ? p.getDutyType().toUpperCase().trim() : "";
                    // Match if designation matches one of the parts
                    if (!pDesig.isEmpty() && designationParts.contains(pDesig)) {
                        categoryPersonnel.add(p);
                    }
                    // Also match if duty_type text itself is a designation match (e.g., duty_type='DCP')
                    else if (!pDutyType.isEmpty() && designationParts.contains(pDutyType)) {
                        categoryPersonnel.add(p);
                    }
                }
            }

            // Special: for parenthetical category names like "RSI(DUTY OFFICER), ARSI (ADO)"
            // match by designation = key part before parentheses AND duty_location = part inside parentheses
            if (categoryName.contains("(")) {
                for (Personnel p : sectionPersonnel) {
                    if (categoryPersonnel.stream().anyMatch(cp -> cp.getId().equals(p.getId()))) continue;
                    String pDesig = p.getDesignation() != null ? p.getDesignation().toUpperCase().trim() : "";
                    String pDutyType = p.getDutyType() != null ? p.getDutyType().toUpperCase().trim() : "";
                    String pLocation = p.getDutyLocation() != null ? p.getDutyLocation().toUpperCase().trim() : "";
                    // Check "RSI(DUTY OFFICER)" — designation=RSI and duty_location contains DUTY OFFICER
                    String[] segments = categoryName.split(",");
                    for (String segment : segments) {
                        segment = segment.trim();
                        if (segment.contains("(")) {
                            String desigPart = segment.split("\\(")[0].trim().replaceAll("[^A-Z]", "");
                            String locationPart = segment.replaceAll(".*\\(", "").replaceAll("\\).*", "").trim();
                            if (!desigPart.isEmpty() && (pDesig.equals(desigPart) || pDutyType.equals(desigPart))) {
                                if (locationPart.isEmpty() || pLocation.contains(locationPart) || pDutyType.contains(locationPart)) {
                                    categoryPersonnel.add(p);
                                    break;
                                }
                            }
                        }
                    }
                }
            }

            // Remove already assigned (to prevent duplicates across categories)
            categoryPersonnel = categoryPersonnel.stream()
                    .filter(p -> !assignedPersonnelIds.contains(p.getId()))
                    .collect(Collectors.toList());

            // Mark as assigned
            for (Personnel p : categoryPersonnel) {
                assignedPersonnelIds.add(p.getId());
            }

            List<SubDutyRow> subRows = new ArrayList<>();
            int[] categoryCounts = new int[7];

            if (children.isEmpty()) {
                // No sub-categories from duty_types table.
                // Group by duty_location instead (sub-duty = duty_location)
                Map<String, List<Personnel>> byLocation = new LinkedHashMap<>();
                List<Personnel> noLocation = new ArrayList<>();

                for (Personnel p : categoryPersonnel) {
                    String loc = p.getDutyLocation();
                    if (loc != null && !loc.isBlank()) {
                        byLocation.computeIfAbsent(loc.trim(), k -> new ArrayList<>()).add(p);
                    } else {
                        noLocation.add(p);
                    }
                }

                if (byLocation.isEmpty()) {
                    // No sub-duties at all — flat list
                    for (Personnel p : categoryPersonnel) {
                        incrementDesignationCount(categoryCounts, p.getDesignation());
                    }
                    List<PersonnelEntry> entries = categoryPersonnel.stream()
                            .map(this::toPersonnelEntry).collect(Collectors.toList());
                    rows.add(new DutyCategoryRow(serialNumber, category.getName(), entries, categoryCounts, subRows));
                } else {
                    // Has duty_location sub-groups
                    for (Map.Entry<String, List<Personnel>> entry : byLocation.entrySet()) {
                        int[] subCounts = new int[7];
                        for (Personnel p : entry.getValue()) {
                            incrementDesignationCount(subCounts, p.getDesignation());
                            incrementDesignationCount(categoryCounts, p.getDesignation());
                        }
                        List<PersonnelEntry> subEntries = entry.getValue().stream()
                                .map(this::toPersonnelEntry).collect(Collectors.toList());
                        subRows.add(new SubDutyRow(entry.getKey(), subEntries, subCounts));
                    }
                    // Also add personnel without location
                    for (Personnel p : noLocation) {
                        incrementDesignationCount(categoryCounts, p.getDesignation());
                    }
                    List<PersonnelEntry> parentEntries = noLocation.stream()
                            .map(this::toPersonnelEntry).collect(Collectors.toList());
                    rows.add(new DutyCategoryRow(serialNumber, category.getName(), parentEntries, categoryCounts, subRows));
                }
            } else {
                // Has sub-categories from duty_types table — group personnel by duty_location matching child names
                // Personnel under this parent are already collected. Now split them by duty_location = child name.
                Map<String, List<Personnel>> byChildName = new LinkedHashMap<>();
                List<Personnel> unmatched = new ArrayList<>();

                for (DutyType child : children) {
                    byChildName.put(child.getName().toUpperCase().trim(), new ArrayList<>());
                }

                for (Personnel p : categoryPersonnel) {
                    String loc = p.getDutyLocation() != null ? p.getDutyLocation().toUpperCase().trim() : "";
                    boolean placed = false;
                    // Match by duty_location = child name
                    for (DutyType child : children) {
                        String childName = child.getName().toUpperCase().trim();
                        if (loc.equals(childName) || loc.contains(childName) || childName.contains(loc) && !loc.isEmpty()) {
                            byChildName.get(childName).add(p);
                            placed = true;
                            break;
                        }
                        // Also match by FK
                        if (p.getDutyTypeEntity() != null && p.getDutyTypeEntity().getId().equals(child.getId())) {
                            byChildName.get(childName).add(p);
                            placed = true;
                            break;
                        }
                    }
                    if (!placed) {
                        // Try exact duty_location match with any child
                        if (!loc.isEmpty()) {
                            // Put under a sub-row with the duty_location as name
                            byChildName.computeIfAbsent(p.getDutyLocation().trim(), k -> new ArrayList<>()).add(p);
                        } else {
                            unmatched.add(p);
                        }
                    }
                }

                for (Map.Entry<String, List<Personnel>> entry : byChildName.entrySet()) {
                    if (entry.getValue().isEmpty()) continue; // Skip empty sub-categories
                    int[] subCounts = new int[7];
                    for (Personnel p : entry.getValue()) {
                        incrementDesignationCount(subCounts, p.getDesignation());
                        incrementDesignationCount(categoryCounts, p.getDesignation());
                    }
                    List<PersonnelEntry> subEntries = entry.getValue().stream()
                            .map(this::toPersonnelEntry).collect(Collectors.toList());
                    // Find display name: use original case from DutyType entity if available
                    String displayName = entry.getKey();
                    for (DutyType child : children) {
                        if (child.getName().toUpperCase().trim().equals(entry.getKey())) {
                            displayName = child.getName();
                            break;
                        }
                    }
                    subRows.add(new SubDutyRow(displayName, subEntries, subCounts));
                }

                // Unmatched personnel (no duty_location, no FK to child)
                for (Personnel p : unmatched) {
                    incrementDesignationCount(categoryCounts, p.getDesignation());
                }
                List<PersonnelEntry> parentEntries = unmatched.stream()
                        .map(this::toPersonnelEntry).collect(Collectors.toList());
                rows.add(new DutyCategoryRow(serialNumber, category.getName(), parentEntries, categoryCounts, subRows));
            }

            // Add to grand totals
            for (int i = 0; i < 7; i++) {
                grandTotals[i] += categoryCounts[i];
            }
            serialNumber++;
        }

        return new SectionReportData("SECTION " + section, rows, grandTotals);
    }

    private PersonnelEntry toPersonnelEntry(Personnel p) {
        String displayName;
        if (p.getBadgeId() != null && !p.getBadgeId().isBlank() && !"-".equals(p.getBadgeId().trim())) {
            // Badge ID exists — show badge ID only
            displayName = p.getBadgeId().trim();
        } else if (p.getPersonName() != null && !p.getPersonName().isBlank()) {
            // No badge ID — show name only
            displayName = p.getPersonName();
        } else {
            displayName = "";
        }
        return new PersonnelEntry(displayName, p.getDesignation());
    }

    private void incrementDesignationCount(int[] counts, String designation) {
        if (designation == null) return;
        String normalized = normalizeDesignation(designation);
        int index = DESIGNATION_COLUMNS.indexOf(normalized);
        if (index >= 0) {
            counts[index]++;
        }
    }

    private String normalizeDesignation(String designation) {
        if (designation == null) return "";
        String upper = designation.toUpperCase().trim();
        if (upper.contains("DCP")) return "DCP";
        if (upper.contains("ACP")) return "ACP";
        if (upper.contains("RPI")) return "RPI";
        if (upper.contains("ARSI")) return "ARSI";
        if (upper.contains("RSI")) return "RSI";
        if (upper.contains("AHC")) return "AHC";
        if (upper.contains("APC")) return "APC";
        return upper;
    }
}

# Low-Level Design (LLD)
## KSP WorkBoard — Police Station Management System

| Field | Details |
|-------|---------|
| **Document Title** | Low-Level Design Document (LLD) |
| **Application Name** | KSP WorkBoard |
| **Version** | 1.0.0 |
| **Date** | June 2026 |
| **Based On** | HLD v1.0.0 |
| **Status** | Final |

---

## 1. Overview

### 1.1 Purpose

This Low-Level Design document provides class-level detail for every component in the KSP WorkBoard system. It describes the internal structure of each service, the algorithms used, method signatures, data flow within methods, and the exact database schema with column definitions. This is the implementation-level design that a developer would use to understand or modify the system.

### 1.2 Scope

This LLD covers:
- Complete class hierarchy and method signatures
- Internal algorithms (rotation, assignment generation, cache invalidation)
- Database schema with CREATE TABLE specifications
- Repository query methods
- DTO mappings
- Chat pipeline internal data flow
- Frontend component specifications

---

## 2. Backend Package Structure

```
com.policescheduler/
├── config/                          # Configuration & Infrastructure
│   ├── SecurityConfig.java          # Spring Security filter chain
│   ├── LlmClient.java              # LLM abstraction interface
│   ├── LlmClientConfig.java        # Provider factory
│   ├── GroqLlmClient.java          # Groq implementation
│   ├── BedrockLlmClient.java       # AWS Bedrock implementation
│   ├── RestTemplateConfig.java      # HTTP client config
│   ├── DataInitializer.java         # Seed data on startup
│   └── EnvironmentConfig.java       # Environment variable bindings
├── security/                        # Security Components
│   ├── JwtAuthFilter.java           # JWT validation filter
│   └── PiiFilter.java              # PII access logging filter
├── controller/ (18 classes)         # REST API Layer
├── service/ (18 classes)            # Business Logic Layer
├── repository/ (25 interfaces)      # Data Access Layer
├── entity/ (25 classes)             # JPA Entity Definitions
├── dto/ (39 classes)                # Request/Response DTOs
├── exception/                       # Custom Exceptions
│   └── ResourceNotFoundException.java
├── report/                          # Report Generation
│   ├── PdfReportGenerator.java      # Interface
│   ├── ReportRequest.java           # Report parameters
│   ├── ReportFileService.java       # Generated file storage
│   ├── ReportGenerationException.java
│   └── generator/ (6 PDF + 5 Excel generators)
└── chat/                            # AI Chat Pipeline
    ├── gateway/                     # Input processing
    │   ├── InputGatewayService.java
    │   ├── InputSanitizerService.java
    │   ├── LanguageDetectorService.java
    │   ├── SttService.java
    │   ├── SttException.java
    │   └── DocumentProcessorService.java
    ├── router/                      # Intent resolution
    │   └── FunctionCallingService.java
    ├── executor/                    # Tool execution
    │   ├── McpHost.java
    │   ├── McpServer.java (interface)
    │   ├── McpToolDefinition.java (record)
    │   ├── McpToolResult.java (record)
    │   ├── DomainDbMcpServer.java
    │   ├── CycleMcpServer.java
    │   ├── AdhocMcpServer.java
    │   ├── DocumentMcpServer.java
    │   └── ReportMcpServer.java
    ├── model/                       # Chat data models
    │   ├── ActionPlan.java (record)
    │   ├── ProcessingContext.java
    │   ├── ToolExecutionResult.java (record)
    │   └── ChatAuditRecord.java
    ├── response/                    # Response formatting
    │   └── ResponseBuilderService.java
    ├── resilience/                  # Fault tolerance
    │   ├── CircuitBreakerManager.java
    │   └── ResponseCacheService.java
    └── audit/
        └── AuditLogService.java
```

---

## 3. Core Data Models (Records & DTOs)

### 3.1 ActionPlan (Chat Intent Resolution Output)

```java
public record ActionPlan(
    String intent,              // e.g., "search_personnel", "create_leave"
    String toolName,            // MCP tool to invoke
    Map<String, Object> parameters,  // Tool parameters from LLM
    double confidenceScore,     // 0.0 - 1.0
    String routingType,         // "deterministic" | "llm" | "rag"
    boolean ragRequired,        // Whether RAG lookup needed
    List<ActionPlan> subPlans,  // For multi-tool orchestration
    String rawInput,            // Original user message
    String normalizedInput      // English-normalized input
) {
    // Factory methods
    static ActionPlan unknown(rawInput, normalizedInput)  // No tool matched
    static ActionPlan of(intent, toolName, params, rawInput, normalizedInput)  // Confidence=1.0
}
```

### 3.2 ProcessingContext (Per-Request Context)

```java
@Data @Builder
public class ProcessingContext {
    private Long userId;              // Authenticated user ID
    private String userRole;          // ADMIN, HIGHER_OFFICER, GENERAL_USER
    private String sessionId;         // UUID per request
    private String detectedLanguage;  // "en" or "kn"
    private String responseLanguage;  // Language for response
    private String originalInput;     // Raw user message
    private String normalizedInput;   // English canonical form
    private List<String> conversationHistory;  // Prior messages
}
```

### 3.3 ToolExecutionResult (MCP Output)

```java
public record ToolExecutionResult(
    String toolName,        // Which tool was executed
    boolean success,        // Success/failure flag
    Object data,            // Result data (varies by tool)
    String errorType,       // Error category if failed
    String errorMessage,    // Human-readable error
    long latencyMs          // Execution time in ms
) {
    static ToolExecutionResult success(toolName, data, latencyMs)
    static ToolExecutionResult failure(toolName, errorType, errorMessage, latencyMs)
}
```

### 3.4 McpToolDefinition & McpToolResult

```java
public record McpToolDefinition(
    String toolName,
    String description,
    Map<String, Object> inputSchema
) {}

public record McpToolResult(
    boolean success,
    Object data,           // Structured response (TableResponseData, FormResponseData, etc.)
    String errorType,
    String errorMessage
) {
    static McpToolResult success(Object data)
    static McpToolResult failure(String errorType, String errorMessage)
}
```

---

## 4. Entity Class Specifications

### 4.1 User Entity

```java
@Entity @Table(name = "users")
public class User {
    @Id @GeneratedValue(IDENTITY) Long id;
    @Column(unique=true, length=100) String username;
    @Column(name="password_hash", length=255) String passwordHash;
    @Enumerated(STRING) @Column(length=20) Role role;  // ADMIN, HIGHER_OFFICER, GENERAL_USER
    @Column(name="display_name", length=200) String displayName;
    @Column(length=5) String locale = "en";
    @Column(name="personnel_id") Long personnelId;  // Nullable FK
    LocalDateTime createdAt, updatedAt;  // @PrePersist/@PreUpdate auto-managed
}
```

### 4.2 Personnel Entity

```java
@Entity @Table(name = "personnel")
public class Personnel {
    @Id @GeneratedValue(IDENTITY) Long id;
    @Column(name="badge_id", unique=true, length=50) String badgeId;
    @Column(name="person_name", length=200) String personName;
    @Column(name="duty_type", length=100) String dutyType;
    @ManyToOne(LAZY) @JoinColumn(name="duty_type_id") DutyType dutyTypeEntity;
    @Column(length=200) String location;
    @Column(name="phone_number", length=20) String phoneNumber;
    @Column(length=200) String email;
    @Column(length=100) String designation;
    @Column(length=5) String section;  // Required
    LocalDate dateOfJoining;
    @Column(name="vehicle_number", length=50) String vehicleNumber;
    @Column(name="duty_location", length=200) String dutyLocation;
    @Column(length=100) String pdms;
    @Column(name="licence_type", length=50) String licenceType;
    @Column(name="deployed_from", length=200) String deployedFrom;
    @Column(name="platoon_id") Long platoonId;  // Nullable FK
    @Column(name="is_active") Boolean isActive = true;
    LocalDateTime createdAt, updatedAt;
}
```

### 4.3 ScheduleCycle Entity

```java
@Entity @Table(name = "schedule_cycles")
public class ScheduleCycle {
    @Id @GeneratedValue(IDENTITY) Long id;
    @Column(name="start_date") LocalDate startDate;
    @Column(name="end_date") LocalDate endDate;
    @Column(name="rotation_days") Integer rotationDays;
    @Column(length=20) String status = "ACTIVE";  // ACTIVE, COMPLETED, DELETED
    @Column(name="created_by") Long createdBy;
    LocalDateTime createdAt, updatedAt;
}
```

### 4.4 CycleDutyAssignment Entity

```java
@Entity @Table(name = "cycle_duty_assignments")
public class CycleDutyAssignment {
    @Id @GeneratedValue(IDENTITY) Long id;
    @Column(name="cycle_id") Long cycleId;
    LocalDate date;
    @Column(name="platoon_id") Long platoonId;
    @Column(name="section_id") Long sectionId;
    @Column(name="person_id") Long personId;
    @Column(name="shift_type", length=10) String shiftType = "DAY";  // DAY, AFTERNOON, NIGHT
    @Column(name="is_override") Boolean isOverride = false;
    @Column(name="group_index", length=1) String groupIndex;  // A, B, C
    @Column(length=20) String status;  // ACTIVE, ON_LEAVE, COVERED_BY_ADHOC
    @Column(name="adhoc_duty_id") Long adhocDutyId;  // Nullable
    @Column(name="duty_name", length=100) String dutyName;  // Section name
    LocalDateTime updatedAt;
}
```

### 4.5 LeaveRequest Entity

```java
@Entity @Table(name = "leave_requests")
public class LeaveRequest {
    @Id @GeneratedValue(IDENTITY) Long id;
    @Column(name="personnel_id") Long personnelId;
    @Column(name="leave_type", length=30) String leaveType;
    LocalDate startDate, endDate;
    @Column(length=20) String status = "PENDING";
    @Column(length=500) String reason;
    @Column(name="approved_by") Long approvedBy;
    @Column(name="rejection_reason", length=500) String rejectionReason;
    LocalDateTime createdAt, updatedAt;
}
```

### 4.6 AdhocDuty Entity

```java
@Entity @Table(name = "adhoc_duties")
@Data @NoArgsConstructor @AllArgsConstructor
public class AdhocDuty {
    @Id @GeneratedValue(IDENTITY) Long id;
    @Column(name="duty_name", length=200) String dutyName;
    LocalDate date;
    @Column(name="start_time") LocalTime startTime;
    @Column(name="end_time") LocalTime endTime;
    @Column(name="required_count") Integer requiredCount;
    @Column(name="actual_count") Integer actualCount = 0;
    @Column(name="pick_from", length=50) String pickFrom = "ALL_PLATOONS";
    @Column(name="platoon_ids", columnDefinition="jsonb") @JdbcTypeCode(JSON) String platoonIds;
    @Column(length=300) String location;
    @Column(name="min_strength_check") Boolean minStrengthCheck = true;
    @Column(length=20) String status = "ACTIVE";
    @Column(name="created_by") Long createdBy;
    LocalDateTime createdAt, updatedAt;
}
```

### 4.7 DutyType Entity (Hierarchical)

```java
@Entity @Table(name = "duty_types")
public class DutyType {
    @Id @GeneratedValue(IDENTITY) Long id;
    @Column(length=100) String name;
    @Column(length=5) String section;
    @Column(name="sort_order") Integer sortOrder = 0;
    Double latitude, longitude;
    @Column(name="radius_meters") Integer radiusMeters = 500;
    @ManyToOne(LAZY) @JoinColumn(name="parent_id") DutyType parent;
    @OneToMany(mappedBy="parent", LAZY) @OrderBy("sortOrder ASC") List<DutyType> children;
}
```

### 4.8 Supporting Entities

```java
// CyclePlatoonSection — Maps platoons to sections within a cycle
@Entity @Table(name = "cycle_platoon_sections")
{ Long id; Long cycleId; Long platoonId; Long sectionId; }

// CycleAuditLog — Immutable audit trail
@Entity @Table(name = "cycle_audit_log")
{ Long id; Long cycleId; String action; String description;
  String oldValue; String newValue; Long performedBy; LocalDateTime createdAt; }

// Platoon — 5 fixed platoons
@Entity @Table(name = "platoons")
{ Long id; String name; Integer baseOffset; LocalDateTime createdAt; }

// Section — Organizational units
@Entity @Table(name = "sections")
{ Long id; String code(UK); String name; String description;
  Integer sortOrder; Boolean isActive; LocalDateTime createdAt, updatedAt; }

// ChatMessage — Chat history
@Entity @Table(name = "chat_messages")
{ Long id; Long userId; String userMessage(TEXT); String aiResponse(TEXT);
  String commandType(50); LocalDateTime createdAt; }
```

---

## 5. Service Layer Algorithms

### 5.1 CycleService.createCycle() — Complete Algorithm

```
FUNCTION createCycle(request: CycleCreateRequest) → CycleResponse:
    INPUT: { startDate, rotationDays, platoonSections[] }

    1. endDate = cycleValidator.validateAndCalculateEndDate(request)
       // endDate = startDate + rotationDays - 1
       // Validates: startDate not null, rotationDays > 0

    2. overlapping = scheduleCycleRepository.findOverlappingActiveCycles(startDate, endDate)
       // Query: WHERE status='ACTIVE' AND start_date <= endDate AND end_date >= startDate
       IF overlapping NOT EMPTY:
           THROW IllegalStateException("Cycle dates overlap with existing cycle #ID...")

    3. cycle = new ScheduleCycle(startDate, endDate, rotationDays, status="ACTIVE")
       savedCycle = scheduleCycleRepository.save(cycle)

    4. FOR EACH mapping IN platoonSections:
           FOR EACH sectionId IN mapping.sectionIds:
               entity = new CyclePlatoonSection(cycleId, platoonId, sectionId)
               SAVE entity
       // Persists 5 mappings (1 per platoon)

    5. assignmentGenerationService.generateAssignments(cycleId, startDate, endDate, mappings)
       // See Algorithm 5.2 below — generates N×D assignments (N=personnel, D=days)

    6. cycleAuditService.log(cycleId, "CYCLE_CREATED", description, null, null)

    7. RETURN buildCycleResponse(savedCycle, savedMappings)
```

### 5.2 AssignmentGenerationService.generateAssignments() — Complete Algorithm

```
FUNCTION generateAssignments(cycleId, startDate, endDate, mappings[]) → List<Assignment>:
    assignments = []

    FOR EACH mapping IN mappings:
        // Get active personnel for this platoon
        personnel = personnelRepository.findByPlatoonIdAndIsActiveTrue(mapping.platoonId)
        SORT personnel BY id ASC  // Deterministic ordering

        IF personnel IS EMPTY: CONTINUE

        // Get section name for duty_name field
        dutyName = sectionRepository.findById(mapping.sectionId).map(Section::getName)

        // Divide into 3 groups (A, B, C)
        total = personnel.size()
        groupSize = total / 3
        remainder = total % 3
        groupASize = groupSize + (remainder >= 1 ? 1 : 0)
        groupBSize = groupSize + (remainder >= 2 ? 1 : 0)
        groupCSize = total - groupASize - groupBSize

        groupA = personnel[0 .. groupASize-1]
        groupB = personnel[groupASize .. groupASize+groupBSize-1]
        groupC = personnel[groupASize+groupBSize .. end]

        // Save shift groups for reference
        saveShiftGroup(cycleId, sectionId, platoonId, "A", groupA)
        saveShiftGroup(cycleId, sectionId, platoonId, "B", groupB)
        saveShiftGroup(cycleId, sectionId, platoonId, "C", groupC)

        // Generate daily assignments with shift rotation
        totalDays = ChronoUnit.DAYS.between(startDate, endDate) + 1
        FOR dayIndex = 0 TO totalDays-1:
            date = startDate + dayIndex days
            pattern = dayIndex % 3

            // Rotation matrix:
            // pattern=0: A→DAY,       B→AFTERNOON, C→NIGHT
            // pattern=1: A→NIGHT,     B→DAY,       C→AFTERNOON
            // pattern=2: A→AFTERNOON, B→NIGHT,     C→DAY

            shifts = ROTATION[pattern]  // [groupAShift, groupBShift, groupCShift]

            FOR person IN groupA:
                assignments.add(newAssignment(cycleId, date, mapping, person, shifts[0], "A", dutyName))
            FOR person IN groupB:
                assignments.add(newAssignment(cycleId, date, mapping, person, shifts[1], "B", dutyName))
            FOR person IN groupC:
                assignments.add(newAssignment(cycleId, date, mapping, person, shifts[2], "C", dutyName))

    RETURN cycleDutyAssignmentRepository.saveAll(assignments)
    // Typically generates: 5 platoons × ~40 personnel × 15 days = ~3000 assignments
```

### 5.3 Auto-Reassignment Algorithm (CycleMcpServer)

```
FUNCTION executeAutoReassignDuty(params) → ConfirmationResponseData:
    INPUT: { assignment_id }

    1. assignment = findById(assignmentId) OR RETURN failure("Not found")

    2. currentPlatoonId = assignment.platoonId
       date = assignment.date

    3. // Get all already-assigned person IDs for this date in this cycle
       existingAssignments = findByCycleIdAndDate(cycleId, date)
       alreadyAssignedIds = SET(existingAssignments.map(personId))

    4. // Find candidates from OTHER platoons
       candidates = personnelRepository.findByIsActiveTrue()
           .FILTER(p → p.platoonId != null AND p.platoonId != currentPlatoonId)
           .FILTER(p → p.id != assignment.personId)
           .FILTER(p → p.id NOT IN alreadyAssignedIds)
           .FILTER(p → NOT leaveConflictDetector.isOnLeave(p.id, date))

    5. IF candidates IS EMPTY:
           RETURN failure("No available personnel from other platoons")

    6. // Random selection
       chosen = candidates[random.nextInt(candidates.size())]

    7. // Perform reassignment
       assignment.personId = chosen.id
       assignment.isOverride = true
       assignment.updatedAt = now()
       SAVE assignment

    8. RETURN success("Duty auto-reassigned from X to Y on date")
```

### 5.4 Leave Conflict Detection Algorithm

```
FUNCTION findDutyConflicts(personnelId, startDate, endDate) → List<Map>:
    conflicts = []
    current = startDate
    WHILE current <= endDate:
        dayAssignments = cycleDutyAssignmentRepository.findByPersonIdAndDate(personnelId, current)
        FOR EACH assignment IN dayAssignments:
            conflicts.add({
                assignmentId: assignment.id,
                date: assignment.date,
                dutyName: assignment.shiftType,
                platoonId: assignment.platoonId
            })
        current = current + 1 day
    RETURN conflicts
```

### 5.5 Circular Rotation Algorithm (Auto-Generate Mappings)

```
FUNCTION autoGenerateMappings() → Map:
    sectionIds = [3, 4, 5, 6, 7]  // C, D, E, F, G
    platoonIds = [1, 2, 3, 4, 5]

    lastCycle = getMostRecentNonDeletedCycle()

    IF lastCycle IS NULL:
        // Default first rotation
        RETURN {P1→3, P2→4, P3→5, P4→6, P5→7}

    lastMappings = getCyclePlatoonSections(lastCycle.id)
    lastPlatoonToSection = MAP(platoonId → sectionId)

    // Shift each platoon to NEXT section in circular order
    newMappings = []
    FOR i = 0 TO 4:
        platoonId = platoonIds[i]
        lastSection = lastPlatoonToSection.getOrDefault(platoonId, sectionIds[i])
        lastIndex = sectionIds.indexOf(lastSection)
        nextIndex = (lastIndex + 1) % 5
        newMappings.add({platoonId, sectionIds[nextIndex]})

    RETURN newMappings
```

### 5.6 Response Cache Invalidation Logic

```
WRITE_TOOLS = {add_person, create_leave, create_cycle, update_cycle, delete_cycle,
               reassign_duty, auto_reassign_duty, add_duty_type, update_duty_type,
               delete_duty_type, update_personnel, create_adhoc_duty, cancel_adhoc_duty}

INVALIDATION_MAP:
    add_person → invalidates [search_personnel, search_by_duty_type, ...]
    create_leave → invalidates [get_leave_count, get_leave_details]
    create_cycle → invalidates [list_cycles, get_cycle_details, get_schedule_overview]
    update_personnel → invalidates [search_personnel, get_person_by_badge, list_section_personnel]
    ...

FUNCTION get(actionPlan):
    IF actionPlan.toolName IN WRITE_TOOLS: RETURN empty  // Never cache writes
    key = toolName + ":" + JSON.stringify(sortedParams)
    RETURN cache.getIfPresent(key)

FUNCTION put(actionPlan, result):
    IF actionPlan.toolName IN WRITE_TOOLS: RETURN  // Don't cache
    key = toolName + ":" + JSON.stringify(sortedParams)
    cache.put(key, result)  // TTL = 60s, maxSize = 500

FUNCTION invalidateForDomain(writeToolName):
    relatedReadTools = INVALIDATION_MAP[writeToolName]
    cache.removeIf(key → key.startsWith(anyOf(relatedReadTools) + ":"))
```

---

## 6. Chat Pipeline Detailed Flow

### 6.1 InputGatewayService.processTextMessage() — Step by Step

```mermaid
flowchart TD
    A[processTextMessage<br>userId, userRole, message] --> B[1. sanitizerService.sanitize]
    B --> C{Injection Detected?}
    C -->|Yes| D[Return error response]
    C -->|No| E[2. languageDetectorService.detect]
    E --> F[3. Build ProcessingContext]
    F --> G[4. functionCallingService.resolveIntent]
    G --> H{ActionPlan Type?}
    H -->|subPlans exist| I[mcpHost.dispatchAll]
    H -->|direct_response| J[Wrap as Suggestions]
    H -->|toolName present| K[mcpHost.dispatch]
    H -->|toolName null| L[Fallback suggestions]
    I --> M[5. responseBuilderService.buildResponse]
    J --> M
    K --> M
    L --> M
    M --> N[6. saveChatMessage to DB]
    N --> O[Return ChatResponse]
```

### 6.2 FunctionCallingService.resolveIntent() — Internal Flow

```
1. buildMessages(userMessage, context):
     messages = [
       { role: "system", content: SYSTEM_PROMPT (200+ lines) },
       ...conversationHistory.map(msg → { role: "user", content: msg }),
       { role: "user", content: userMessage + langHint }
     ]

2. buildToolDefinitions():
     tools = [37 tool definitions in OpenAI format]
     Each tool: { type: "function", function: { name, description, parameters: { type, properties, required } } }

3. llmClient.chatCompletion(null, messages, tools, "auto")
     → Sends to Groq/Bedrock
     → Returns OpenAI-compatible JSON response

4. parseToolCallResponse(responseBody):
     Extract choices[0].message.tool_calls[0]:
       toolName = function.name
       argsJson = function.arguments
     Parse argsJson into Map<String, Object>
     RETURN ActionPlan.of(toolName, toolName, params, rawInput, normalizedInput)

5. ERROR HANDLING (Groq-specific):
     If 400 error with failed_generation field:
       Parse "<function=name{args}</function>" format
       Extract tool name and JSON args
       RETURN ActionPlan if parseable
```

---

## 7. Repository Layer Specifications

### 7.1 Key Repository Methods (Custom Queries)

| Repository | Method | Query Logic |
|-----------|--------|-------------|
| PersonnelRepository | `findByBadgeId(String)` | `WHERE badge_id = ?` |
| PersonnelRepository | `existsByBadgeId(String)` | EXISTS check |
| PersonnelRepository | `findByPlatoonIdAndIsActiveTrue(Long)` | `WHERE platoon_id = ? AND is_active = true` |
| PersonnelRepository | `findByIsActiveTrue()` | `WHERE is_active = true` |
| LeaveRequestRepository | `findOverlapping(Long, LocalDate, LocalDate)` | `WHERE personnel_id = ? AND start_date <= ? AND end_date >= ? AND status != 'CANCELLED'` |
| ScheduleCycleRepository | `findOverlappingActiveCycles(LocalDate, LocalDate)` | `WHERE status = 'ACTIVE' AND start_date <= ? AND end_date >= ?` |
| ScheduleCycleRepository | `findByStatusNotOrderByStartDateDesc(String)` | `WHERE status != ? ORDER BY start_date DESC` |
| ScheduleCycleRepository | `findActiveCyclesOrderByEndDateDesc()` | `WHERE status = 'ACTIVE' ORDER BY end_date DESC` |
| CyclePlatoonSectionRepository | `findByCycleId(Long)` | `WHERE cycle_id = ?` |
| CyclePlatoonSectionRepository | `deleteByCycleId(Long)` | `DELETE WHERE cycle_id = ?` |
| CycleDutyAssignmentRepository | `findByCycleIdAndDate(Long, LocalDate)` | `WHERE cycle_id = ? AND date = ?` |
| CycleDutyAssignmentRepository | `findByPersonIdAndDate(Long, LocalDate)` | `WHERE person_id = ? AND date = ?` |
| CycleDutyAssignmentRepository | `findByCycleIdAndDateAndSectionIdAndPersonId(...)` | 4-column composite lookup |
| CycleDutyAssignmentRepository | `deleteByCycleId(Long)` | `DELETE WHERE cycle_id = ?` |
| UserRepository | `findByUsername(String)` | `WHERE username = ?` |
| PlatoonRepository | `findAllByOrderByBaseOffsetAsc()` | `ORDER BY base_offset ASC` |

### 7.2 Specification Pattern (Dynamic Queries)

The system uses JPA Specification pattern for dynamic filtering:

```java
// PersonnelService builds dynamic WHERE clauses:
Specification<Personnel> spec = (root, query, cb) -> {
    List<Predicate> predicates = new ArrayList<>();
    if (filter.search != null) {
        predicates.add(cb.or(
            cb.like(cb.lower(root.get("badgeId")), "%search%"),
            cb.like(cb.lower(root.get("personName")), "%search%"),
            // ... 6 more fields
        ));
    }
    if (filter.section != null) predicates.add(cb.equal(root.get("section"), section));
    if (filter.dutyType != null) predicates.add(cb.equal(lower(root.get("dutyType")), dutyType));
    if (filter.designation != null) predicates.add(cb.equal(root.get("designation"), designation));
    if (filter.isActive != null) predicates.add(cb.equal(root.get("isActive"), isActive));
    return cb.and(predicates.toArray(new Predicate[0]));
};
```

---

## 8. Frontend Detailed Design

### 8.1 Directory Structure

```
src/
├── App.tsx                    # Router configuration
├── main.tsx                   # Entry point
├── pages/ (14 pages)          # Route-level components
├── components/                # Shared UI components
│   ├── SideNavBar.tsx         # Navigation drawer
│   ├── ProtectedRoute.tsx     # Auth guard (redirects to /login)
│   ├── AdminRoute.tsx         # Role guard (ADMIN/HIGHER_OFFICER)
│   ├── InactivityDialog.tsx   # Auto-logout warning
│   └── cycle/
│       └── CycleForm.tsx      # Cycle creation form
├── services/                  # API client layer
│   ├── api.ts                 # Axios instance with interceptors
│   ├── chatService.ts         # Chat API calls
│   ├── personnelService.ts    # Personnel API calls
│   ├── scheduleService.ts     # Schedule API calls
│   └── leaveService.ts        # Leave API calls
├── contexts/                  # React Contexts
│   ├── AuthContext.tsx         # Auth state (MobX)
│   └── ThemeContext.tsx        # Dark/light mode
├── types/
│   └── index.ts               # All TypeScript interfaces (250+ lines)
├── i18n/
│   └── config.ts              # i18next configuration
└── stores/
    └── authStore.ts            # MobX observable store
```

### 8.2 API Service Pattern

```typescript
// services/api.ts — Axios instance
const api = axios.create({ baseURL: import.meta.env.VITE_API_URL });

// Request interceptor: attach JWT token
api.interceptors.request.use(config => {
    const token = authStore.token;
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
});

// Response interceptor: handle 401
api.interceptors.response.use(
    response => response,
    error => {
        if (error.response?.status === 401) {
            authStore.logout();
            window.location.href = '/login';
        }
        return Promise.reject(error);
    }
);
```

### 8.3 Chat Service API Interface

```typescript
export const chatService = {
    sendMessage: (message: string) =>
        api.post<ChatResponse>('/api/chat/message', { message }),

    uploadPdf: (file: File) => {
        const formData = new FormData();
        formData.append('file', file);
        return api.post<ChatResponse>('/api/chat/upload-pdf', formData,
            { headers: { 'Content-Type': 'multipart/form-data' } });
    },

    submitForm: (formId, submitAction, fields) =>
        api.post<ChatResponse>('/api/chat/form-submit', { formId, submitAction, fields }),

    checkAiStatus: () =>
        api.get<{ connected: boolean; reason?: string }>('/api/health/ai'),
};
```

### 8.4 Route Guard Implementation

```typescript
// ProtectedRoute.tsx
export const ProtectedRoute = () => {
    const { isAuthenticated } = useAuth();
    if (!isAuthenticated) return <Navigate to="/login" replace />;
    return <Outlet />;  // Renders child routes within MainLayout
};

// AdminRoute.tsx
export const AdminRoute = () => {
    const { role } = useAuth();
    if (role !== 'ADMIN' && role !== 'HIGHER_OFFICER')
        return <Navigate to="/" replace />;
    return <Outlet />;
};
```

---

## 9. Sequence Diagrams (Detailed Internal)

### 9.1 Cycle Creation — Full Internal Sequence

```mermaid
sequenceDiagram
    participant UI as CycleForm
    participant API as CycleController
    participant SVC as CycleService
    participant VAL as CycleValidator
    participant REPO as ScheduleCycleRepository
    participant CPS as CyclePlatoonSectionRepo
    participant AGS as AssignmentGenerationService
    participant PR as PersonnelRepository
    participant CDAR as CycleDutyAssignmentRepo
    participant SGR as ShiftGroupRepository
    participant AUD as CycleAuditService

    UI->>API: POST /api/cycles {startDate, rotationDays, platoonSections}
    API->>SVC: createCycle(request)
    SVC->>VAL: validateAndCalculateEndDate(request)
    VAL-->>SVC: endDate = startDate + rotationDays - 1

    SVC->>REPO: findOverlappingActiveCycles(startDate, endDate)
    REPO-->>SVC: [] (no overlap)

    SVC->>REPO: save(new ScheduleCycle)
    REPO-->>SVC: savedCycle (id=5)

    loop For each platoonSection mapping (5 times)
        SVC->>CPS: save(CyclePlatoonSection)
    end

    SVC->>AGS: generateAssignments(cycleId=5, startDate, endDate, mappings)

    loop For each mapping (5 platoons)
        AGS->>PR: findByPlatoonIdAndIsActiveTrue(platoonId)
        PR-->>AGS: List<Personnel> (e.g., 40 people)
        AGS->>AGS: Divide into groups A(14), B(13), C(13)
        AGS->>SGR: save(ShiftGroup A)
        AGS->>SGR: save(ShiftGroup B)
        AGS->>SGR: save(ShiftGroup C)

        loop For each day (15 days)
            AGS->>AGS: Calculate shifts by dayIndex % 3
            AGS->>AGS: Create 40 CycleDutyAssignment records
        end
    end

    AGS->>CDAR: saveAll(~3000 assignments)
    CDAR-->>AGS: saved

    SVC->>AUD: log(cycleId, "CYCLE_CREATED", description)
    SVC-->>API: CycleResponse
    API-->>UI: 201 Created + JSON
```

### 9.2 Chat with Form Submission — Full Flow

```mermaid
sequenceDiagram
    participant USER as Officer
    participant FE as React ChatPanel
    participant CC as ChatController
    participant GW as InputGatewayService
    participant FC as FunctionCallingService
    participant LLM as Groq LLM
    participant MCP as CycleMcpServer
    participant RB as ResponseBuilderService

    USER->>FE: Types "create platoon"
    FE->>CC: POST /api/chat/message {message: "create platoon"}
    CC->>GW: processTextMessage(userId, "ADMIN", "create platoon")
    GW->>GW: Sanitize → Safe
    GW->>GW: Detect language → EN
    GW->>FC: resolveIntent("create platoon", context)
    FC->>LLM: chatCompletion(messages, 37 tools, "auto")
    LLM-->>FC: tool_call: create_cycle, params: {}
    FC-->>GW: ActionPlan(toolName="create_cycle", params={})
    GW->>MCP: dispatch(plan, context)
    MCP->>MCP: executeCreateCycle(params={})
    Note over MCP: Params incomplete → generate form
    MCP->>MCP: Auto-generate platoon mappings
    MCP->>MCP: Build FormResponseData with pre-filled fields
    MCP-->>GW: McpToolResult.success(FormResponseData)
    GW->>RB: buildResponse(results, context)
    RB-->>GW: ChatResponse(responseType="form", data=FormResponseData)
    GW->>GW: saveChatMessage(...)
    GW-->>CC: ChatResponse
    CC-->>FE: JSON response
    FE-->>USER: Renders interactive form

    USER->>FE: Fills form & clicks "Create Cycle"
    FE->>CC: POST /api/chat/form-submit {submitAction:"create_cycle", fields:{...}}
    CC->>GW: processFormSubmission(userId, "ADMIN", request)
    GW->>GW: handleCreateCycle(request)
    GW->>GW: Parse startDate, rotationDays, 5 platoon sections
    GW->>GW: cycleService.createCycle(request)
    GW-->>CC: ChatResponse(responseType="confirmation", success=true)
    CC-->>FE: JSON confirmation
    FE-->>USER: Shows success card with cycle details
```

---

## 10. Database Schema (CREATE TABLE Specifications)

### 10.1 Core Tables

```sql
CREATE TABLE users (
    id              BIGSERIAL PRIMARY KEY,
    username        VARCHAR(100) NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    role            VARCHAR(20) NOT NULL CHECK (role IN ('ADMIN','HIGHER_OFFICER','GENERAL_USER')),
    display_name    VARCHAR(200),
    locale          VARCHAR(5) NOT NULL DEFAULT 'en',
    personnel_id    BIGINT REFERENCES personnel(id),
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE personnel (
    id              BIGSERIAL PRIMARY KEY,
    badge_id        VARCHAR(50) NOT NULL UNIQUE,
    person_name     VARCHAR(200) NOT NULL,
    duty_type       VARCHAR(100),
    duty_type_id    BIGINT REFERENCES duty_types(id),
    location        VARCHAR(200),
    phone_number    VARCHAR(20),
    email           VARCHAR(200),
    designation     VARCHAR(100),
    section         VARCHAR(5) NOT NULL,
    date_of_joining DATE,
    vehicle_number  VARCHAR(50),
    duty_location   VARCHAR(200),
    pdms            VARCHAR(100),
    licence_type    VARCHAR(50),
    deployed_from   VARCHAR(200),
    platoon_id      BIGINT REFERENCES platoons(id),
    is_active       BOOLEAN NOT NULL DEFAULT true,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE duty_types (
    id              BIGSERIAL PRIMARY KEY,
    name            VARCHAR(100) NOT NULL,
    section         VARCHAR(5) NOT NULL,
    sort_order      INTEGER NOT NULL DEFAULT 0,
    latitude        DOUBLE PRECISION,
    longitude       DOUBLE PRECISION,
    radius_meters   INTEGER DEFAULT 500,
    parent_id       BIGINT REFERENCES duty_types(id)
);

CREATE TABLE sections (
    id              BIGSERIAL PRIMARY KEY,
    code            VARCHAR(5) NOT NULL UNIQUE,
    name            VARCHAR(100) NOT NULL,
    description     VARCHAR(500),
    sort_order      INTEGER NOT NULL DEFAULT 0,
    is_active       BOOLEAN NOT NULL DEFAULT true,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE platoons (
    id              BIGSERIAL PRIMARY KEY,
    name            VARCHAR(50) NOT NULL,
    base_offset     INTEGER NOT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);
```

### 10.2 Cycle Management Tables

```sql
CREATE TABLE schedule_cycles (
    id              BIGSERIAL PRIMARY KEY,
    start_date      DATE NOT NULL,
    end_date        DATE NOT NULL,
    rotation_days   INTEGER NOT NULL,
    status          VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    created_by      BIGINT,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE cycle_platoon_sections (
    id              BIGSERIAL PRIMARY KEY,
    cycle_id        BIGINT NOT NULL REFERENCES schedule_cycles(id),
    platoon_id      BIGINT NOT NULL REFERENCES platoons(id),
    section_id      BIGINT NOT NULL REFERENCES sections(id)
);

CREATE TABLE cycle_duty_assignments (
    id              BIGSERIAL PRIMARY KEY,
    cycle_id        BIGINT NOT NULL REFERENCES schedule_cycles(id),
    date            DATE NOT NULL,
    platoon_id      BIGINT NOT NULL,
    section_id      BIGINT NOT NULL,
    person_id       BIGINT NOT NULL REFERENCES personnel(id),
    shift_type      VARCHAR(10) NOT NULL DEFAULT 'DAY',
    is_override     BOOLEAN NOT NULL DEFAULT false,
    group_index     VARCHAR(1),
    status          VARCHAR(20),
    adhoc_duty_id   BIGINT,
    duty_name       VARCHAR(100),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE cycle_audit_log (
    id              BIGSERIAL PRIMARY KEY,
    cycle_id        BIGINT NOT NULL,
    action          VARCHAR(50) NOT NULL,
    description     TEXT NOT NULL,
    old_value       TEXT,
    new_value       TEXT,
    performed_by    BIGINT,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE shift_groups (
    id              BIGSERIAL PRIMARY KEY,
    cycle_id        BIGINT NOT NULL,
    section_id      BIGINT NOT NULL,
    platoon_id      BIGINT NOT NULL,
    group_name      VARCHAR(1) NOT NULL,
    personnel_ids   TEXT
);
```

### 10.3 Leave & Adhoc Tables

```sql
CREATE TABLE leave_requests (
    id              BIGSERIAL PRIMARY KEY,
    personnel_id    BIGINT NOT NULL REFERENCES personnel(id),
    leave_type      VARCHAR(30) NOT NULL,
    start_date      DATE NOT NULL,
    end_date        DATE NOT NULL,
    status          VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    reason          VARCHAR(500),
    approved_by     BIGINT,
    rejection_reason VARCHAR(500),
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE adhoc_duties (
    id              BIGSERIAL PRIMARY KEY,
    duty_name       VARCHAR(200) NOT NULL,
    date            DATE NOT NULL,
    start_time      TIME NOT NULL,
    end_time        TIME NOT NULL,
    required_count  INTEGER NOT NULL,
    actual_count    INTEGER DEFAULT 0,
    pick_from       VARCHAR(50) DEFAULT 'ALL_PLATOONS',
    platoon_ids     JSONB,
    location        VARCHAR(300),
    min_strength_check BOOLEAN DEFAULT true,
    status          VARCHAR(20) DEFAULT 'ACTIVE',
    created_by      BIGINT,
    created_at      TIMESTAMP DEFAULT NOW(),
    updated_at      TIMESTAMP DEFAULT NOW()
);

CREATE TABLE adhoc_duty_assignments (
    id              BIGSERIAL PRIMARY KEY,
    adhoc_duty_id   BIGINT NOT NULL REFERENCES adhoc_duties(id),
    person_id       BIGINT NOT NULL REFERENCES personnel(id)
);
```

### 10.4 Chat & Support Tables

```sql
CREATE TABLE chat_messages (
    id              BIGSERIAL PRIMARY KEY,
    user_id         BIGINT NOT NULL REFERENCES users(id),
    user_message    TEXT NOT NULL,
    ai_response     TEXT,
    command_type    VARCHAR(50),
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE document_chunks (
    id              BIGSERIAL PRIMARY KEY,
    upload_id       BIGINT REFERENCES pdf_uploads(id),
    content         TEXT NOT NULL,
    embedding       vector(1536)
);

CREATE TABLE pdf_uploads (
    id              BIGSERIAL PRIMARY KEY,
    user_id         BIGINT NOT NULL,
    filename        VARCHAR(255),
    uploaded_at     TIMESTAMP DEFAULT NOW()
);

CREATE TABLE support_tickets (
    id              BIGSERIAL PRIMARY KEY,
    user_id         BIGINT NOT NULL,
    subject         VARCHAR(200) NOT NULL,
    description     TEXT,
    status          VARCHAR(20) DEFAULT 'OPEN',
    created_at      TIMESTAMP DEFAULT NOW()
);
```

### 10.5 Configuration Tables

```sql
CREATE TABLE translations (
    id                  BIGSERIAL PRIMARY KEY,
    translation_key     VARCHAR(200) NOT NULL,
    locale              VARCHAR(5) NOT NULL,
    translation_value   TEXT NOT NULL,
    category            VARCHAR(50),
    UNIQUE(translation_key, locale)
);

CREATE TABLE system_config (
    id              BIGSERIAL PRIMARY KEY,
    config_key      VARCHAR(100) NOT NULL UNIQUE,
    config_value    TEXT
);

CREATE TABLE holidays (
    id              BIGSERIAL PRIMARY KEY,
    date            DATE NOT NULL,
    name            VARCHAR(200) NOT NULL,
    type            VARCHAR(50)
);
```

### 10.6 Recommended Indexes

```sql
-- Personnel lookup performance
CREATE INDEX idx_personnel_badge_id ON personnel(badge_id);
CREATE INDEX idx_personnel_section ON personnel(section);
CREATE INDEX idx_personnel_platoon_id ON personnel(platoon_id);
CREATE INDEX idx_personnel_is_active ON personnel(is_active);
CREATE INDEX idx_personnel_designation ON personnel(designation);
CREATE INDEX idx_personnel_name_lower ON personnel(LOWER(person_name));

-- Cycle duty assignment lookups
CREATE INDEX idx_cda_cycle_date ON cycle_duty_assignments(cycle_id, date);
CREATE INDEX idx_cda_person_date ON cycle_duty_assignments(person_id, date);
CREATE INDEX idx_cda_cycle_date_section_person ON cycle_duty_assignments(cycle_id, date, section_id, person_id);

-- Leave request lookups
CREATE INDEX idx_leave_personnel_id ON leave_requests(personnel_id);
CREATE INDEX idx_leave_status ON leave_requests(status);
CREATE INDEX idx_leave_dates ON leave_requests(start_date, end_date);

-- Schedule cycle lookups
CREATE INDEX idx_cycle_status ON schedule_cycles(status);
CREATE INDEX idx_cycle_dates ON schedule_cycles(start_date, end_date);

-- Chat message history
CREATE INDEX idx_chat_user_id ON chat_messages(user_id);
CREATE INDEX idx_chat_created_at ON chat_messages(created_at DESC);

-- Audit log
CREATE INDEX idx_audit_cycle_id ON cycle_audit_log(cycle_id);
CREATE INDEX idx_audit_created_at ON cycle_audit_log(created_at DESC);

-- Duty types
CREATE INDEX idx_duty_types_section ON duty_types(section);
CREATE INDEX idx_duty_types_parent ON duty_types(parent_id);

-- Adhoc duties
CREATE INDEX idx_adhoc_date ON adhoc_duties(date);
CREATE INDEX idx_adhoc_status ON adhoc_duties(status);
```

---

## 11. Error Handling Design

### 11.1 Exception Hierarchy

```
RuntimeException
├── ResourceNotFoundException          → HTTP 404
├── EntityNotFoundException (JPA)      → HTTP 404
├── IllegalStateException              → HTTP 400 (business rule violation)
├── IllegalArgumentException           → HTTP 400 (validation failure)
├── AccessDeniedException (Spring)     → HTTP 403
├── ReportGenerationException          → HTTP 500
└── SttException                       → Handled via circuit breaker fallback
```

### 11.2 Global Exception Handler Pattern

```java
@ExceptionHandler(EntityNotFoundException.class)
→ 404 with { error: { code, message, timestamp } }

@ExceptionHandler(IllegalStateException.class)
→ 400 with { error: { code, message, timestamp } }

@ExceptionHandler(MethodArgumentNotValidException.class)
→ 400 with field-level validation errors

@ExceptionHandler(ReportGenerationException.class)
→ 500 with { error: message }
```

---

## 12. Configuration Management

### 12.1 Spring Profiles

| Profile | Purpose | AI Provider |
|---------|---------|-------------|
| local | Development on developer machine | Groq |
| prod | Production on AWS EC2 | Bedrock |

### 12.2 Configuration Properties Hierarchy

```yaml
spring:
  datasource:
    url: ${DB_URL}        # JDBC PostgreSQL URL
    username: ${DB_USERNAME}
    password: ${DB_PASSWORD}
  jpa:
    hibernate.ddl-auto: none   # Manual schema management
    open-in-view: false         # Prevent N+1 lazy loading issues
  servlet.multipart:
    max-file-size: 10MB
    max-request-size: 10MB

app:
  jwt:
    secret: ${JWT_SECRET}
    expiration-ms: 86400000     # 24 hours
  ai-provider: ${AI_PROVIDER:groq}
  groq:
    api-key: ${GROQ_API_KEY}
    model: llama-3.3-70b-versatile
  bedrock:
    region: us-east-1
    model-id: amazon.nova-lite-v1:0
  cors.allowed-origins: ${CORS_ALLOWED_ORIGINS:http://localhost:5173}

chat.rate-limit:
  general: 30
  llm: 20
```

---

## 13. Testing Design

### 13.1 Testing Framework

| Layer | Framework | Runner |
|-------|-----------|--------|
| Backend Unit | JUnit 5 + Mockito | JUnit Platform |
| Backend Property | jqwik 1.9.2 | JUnit Platform |
| Backend Integration | Spring Boot Test | JUnit Platform |
| Frontend Unit | Vitest 3.0.5 | Vitest |
| Frontend Property | fast-check 4.1.1 | Vitest |

### 13.2 Test Categories

| Category | Scope | Example |
|----------|-------|---------|
| Unit (Service) | Single class with mocked dependencies | PersonnelService.create() with mocked repo |
| Unit (Controller) | API layer with MockMvc | POST /api/personnel returns 201 |
| Integration | Full Spring context + test DB | Cycle creation end-to-end |
| Property | Invariant verification | Badge ID format always matches PREFIX-NUMBER |

---

## 14. Document Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0.0 | June 2026 | Generated from Codebase | Initial complete LLD |

---

*End of Document — LLD v1.0.0*

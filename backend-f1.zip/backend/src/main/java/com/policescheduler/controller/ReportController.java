package com.policescheduler.controller;

import com.policescheduler.entity.PlatoonRotationState;
import com.policescheduler.entity.ReportHistory;
import com.policescheduler.report.PdfReportGenerator;
import com.policescheduler.report.ReportFileService;
import com.policescheduler.report.ReportGenerationException;
import com.policescheduler.report.ReportRequest;
import com.policescheduler.report.S3ReportStorageService;
import com.policescheduler.report.generator.DailyStatementExcelGenerator;
import com.policescheduler.report.generator.LeaveStatementExcelGenerator;
import com.policescheduler.report.generator.MtSectionExcelGenerator;
import com.policescheduler.report.generator.PersonnelListExcelGenerator;
import com.policescheduler.report.generator.CompletePersonnelListExcelGenerator;
import com.policescheduler.report.generator.PlatoonChartExcelGenerator;
import com.policescheduler.report.generator.SectionABExcelGenerator;
import com.policescheduler.report.generator.CycleForm168ExcelGenerator;
import com.policescheduler.report.generator.CycleForm168PdfGenerator;
import com.policescheduler.repository.PlatoonRotationStateRepository;
import com.policescheduler.repository.ReportHistoryRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("/api/reports")
public class ReportController {

    private static final Logger log = LoggerFactory.getLogger(ReportController.class);

    private final Map<String, PdfReportGenerator> generatorsByType;
    private final ReportFileService reportFileService;
    private final SectionABExcelGenerator sectionABExcelGenerator;
    private final PlatoonChartExcelGenerator platoonChartExcelGenerator;
    private final MtSectionExcelGenerator mtSectionExcelGenerator;
    private final DailyStatementExcelGenerator dailyStatementExcelGenerator;
    private final LeaveStatementExcelGenerator leaveStatementExcelGenerator;
    private final PersonnelListExcelGenerator personnelListExcelGenerator;
    private final CompletePersonnelListExcelGenerator completePersonnelListExcelGenerator;
    private final S3ReportStorageService s3ReportStorageService;
    private final ReportHistoryRepository reportHistoryRepository;
    private final PlatoonRotationStateRepository platoonRotationStateRepository;
    private final CycleForm168ExcelGenerator cycleForm168ExcelGenerator;
    private final CycleForm168PdfGenerator cycleForm168PdfGenerator;

    public ReportController(List<PdfReportGenerator> generators, ReportFileService reportFileService,
                            SectionABExcelGenerator sectionABExcelGenerator,
                            PlatoonChartExcelGenerator platoonChartExcelGenerator,
                            MtSectionExcelGenerator mtSectionExcelGenerator,
                            DailyStatementExcelGenerator dailyStatementExcelGenerator,
                            LeaveStatementExcelGenerator leaveStatementExcelGenerator,
                            PersonnelListExcelGenerator personnelListExcelGenerator,
                            CompletePersonnelListExcelGenerator completePersonnelListExcelGenerator,
                            S3ReportStorageService s3ReportStorageService,
                            ReportHistoryRepository reportHistoryRepository,
                            PlatoonRotationStateRepository platoonRotationStateRepository,
                            CycleForm168ExcelGenerator cycleForm168ExcelGenerator,
                            CycleForm168PdfGenerator cycleForm168PdfGenerator) {
        this.reportFileService = reportFileService;
        this.sectionABExcelGenerator = sectionABExcelGenerator;
        this.platoonChartExcelGenerator = platoonChartExcelGenerator;
        this.mtSectionExcelGenerator = mtSectionExcelGenerator;
        this.dailyStatementExcelGenerator = dailyStatementExcelGenerator;
        this.leaveStatementExcelGenerator = leaveStatementExcelGenerator;
        this.personnelListExcelGenerator = personnelListExcelGenerator;
        this.completePersonnelListExcelGenerator = completePersonnelListExcelGenerator;
        this.s3ReportStorageService = s3ReportStorageService;
        this.reportHistoryRepository = reportHistoryRepository;
        this.platoonRotationStateRepository = platoonRotationStateRepository;
        this.cycleForm168ExcelGenerator = cycleForm168ExcelGenerator;
        this.cycleForm168PdfGenerator = cycleForm168PdfGenerator;
        this.generatorsByType = new HashMap<>();
        for (PdfReportGenerator generator : generators) {
            this.generatorsByType.put(generator.getReportType(), generator);
        }
    }

    private static final Set<String> VALID_PLATOON_SECTIONS = Set.of("C", "D", "E", "F", "G");

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    @GetMapping("/platoon-chart")
    public ResponseEntity<byte[]> generatePlatoonChart(
            @RequestParam(required = false) LocalDate date,
            @RequestParam(required = false) String section,
            @RequestParam(required = false, defaultValue = "en") String locale) {
        // Validate section parameter if provided
        if (section != null) {
            String upper = section.toUpperCase();
            if (!VALID_PLATOON_SECTIONS.contains(upper)) {
                return ResponseEntity.badRequest().build();
            }
            section = upper;
        }
        ReportRequest request = ReportRequest.builder()
                .reportType("platoon_chart")
                .date(date != null ? date : LocalDate.now())
                .section(section)
                .locale(locale)
                .build();
        byte[] pdf = generatorsByType.get("platoon_chart").generate(request);
        String filename = buildPlatoonChartCFilename(".pdf");
        storeReportAsync("platoon_chart", filename, pdf, "application/pdf");
        return pdfResponse(pdf, filename);
    }

    @GetMapping("/form-168")
    public ResponseEntity<byte[]> generateForm168(
            @RequestParam(required = false) LocalDate date,
            @RequestParam(required = false, defaultValue = "en") String locale) {
        LocalDate reportDate = date != null ? date : LocalDate.now();
        ReportRequest request = ReportRequest.builder()
                .reportType("form_168")
                .date(reportDate)
                .locale(locale)
                .build();
        byte[] pdf = generatorsByType.get("form_168").generate(request);
        String filename = "Statement (Form 168) - " + reportDate.format(DATE_FMT) + ".pdf";
        storeReportAsync("form_168", filename, pdf, "application/pdf");
        return pdfResponse(pdf, filename);
    }

    @GetMapping("/section-a")
    public ResponseEntity<byte[]> generateSectionA(
            @RequestParam(required = false, defaultValue = "en") String locale) {
        ReportRequest request = ReportRequest.builder()
                .reportType("section_ab")
                .section("A")
                .locale(locale)
                .build();
        byte[] pdf = generatorsByType.get("section_ab").generate(request);
        String filename = "PLATOON CHART A&B - " + LocalDate.now().format(DATE_FMT) + ".pdf";
        storeReportAsync("section_a", filename, pdf, "application/pdf");
        return pdfResponse(pdf, filename);
    }

    @GetMapping("/section-b")
    public ResponseEntity<byte[]> generateSectionB(
            @RequestParam(required = false, defaultValue = "en") String locale) {
        ReportRequest request = ReportRequest.builder()
                .reportType("section_ab")
                .section("B")
                .locale(locale)
                .build();
        byte[] pdf = generatorsByType.get("section_ab").generate(request);
        String filename = "PLATOON CHART A&B - " + LocalDate.now().format(DATE_FMT) + ".pdf";
        storeReportAsync("section_b", filename, pdf, "application/pdf");
        return pdfResponse(pdf, filename);
    }

    @GetMapping("/section-ab")
    public ResponseEntity<byte[]> generateSectionAB(
            @RequestParam(required = false, defaultValue = "en") String locale) {
        ReportRequest request = ReportRequest.builder()
                .reportType("section_ab")
                .combined(true)
                .locale(locale)
                .build();
        byte[] pdf = generatorsByType.get("section_ab").generate(request);
        String filename = "PLATOON CHART A&B - " + LocalDate.now().format(DATE_FMT) + ".pdf";
        storeReportAsync("section_ab", filename, pdf, "application/pdf");
        return pdfResponse(pdf, filename);
    }

    @GetMapping("/mt-section")
    public ResponseEntity<byte[]> generateMtSection(
            @RequestParam(required = false, defaultValue = "en") String locale) {
        ReportRequest request = ReportRequest.builder()
                .reportType("mt_section")
                .locale(locale)
                .build();
        byte[] pdf = generatorsByType.get("mt_section").generate(request);
        String filename = "MT_Section_" + LocalDate.now().format(DATE_FMT) + ".pdf";
        storeReportAsync("mt_section", filename, pdf, "application/pdf");
        return pdfResponse(pdf, filename);
    }

    @GetMapping("/personnel")
    public ResponseEntity<byte[]> generatePersonnelReport(
            @RequestParam(required = false) String section,
            @RequestParam(required = false) String designation,
            @RequestParam(required = false) String dutyType,
            @RequestParam(required = false) Boolean isActive,
            @RequestParam(required = false, defaultValue = "en") String locale) {
        ReportRequest request = ReportRequest.builder()
                .reportType("personnel_list")
                .section(section)
                .designation(designation)
                .dutyType(dutyType)
                .isActive(isActive)
                .locale(locale)
                .build();
        byte[] pdf = generatorsByType.get("personnel_list").generate(request);
        String filename = "CAR MANGALURU CITY (COMPANY).pdf";
        storeReportAsync("personnel_list", filename, pdf, "application/pdf");
        return pdfResponse(pdf, filename);
    }

    @GetMapping("/leave-statement")
    public ResponseEntity<byte[]> generateLeaveStatement(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String leaveType,
            @RequestParam(required = false) LocalDate startDate,
            @RequestParam(required = false) LocalDate endDate,
            @RequestParam(required = false, defaultValue = "en") String locale) {
        ReportRequest request = ReportRequest.builder()
                .reportType("leave_statement")
                .leaveStatus(status)
                .leaveType(leaveType)
                .startDate(startDate)
                .endDate(endDate)
                .locale(locale)
                .build();
        byte[] pdf = generatorsByType.get("leave_statement").generate(request);
        String filename = buildLeaveStatementFilename(startDate, endDate, ".pdf");
        storeReportAsync("leave_statement", filename, pdf, "application/pdf");
        return pdfResponse(pdf, filename);
    }

    // Backward-compatible alias: frontend calls /leave-requests
    @GetMapping("/leave-requests")
    public ResponseEntity<byte[]> generateLeaveRequests(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String leaveType,
            @RequestParam(required = false) LocalDate startDate,
            @RequestParam(required = false) LocalDate endDate,
            @RequestParam(required = false, defaultValue = "en") String locale) {
        return generateLeaveStatement(status, leaveType, startDate, endDate, locale);
    }

    // Schedule report: generates the Section A&B combined report as the "schedule" view
    @GetMapping("/schedules")
    public ResponseEntity<byte[]> generateScheduleReport(
            @RequestParam(required = false, defaultValue = "en") String locale) {
        ReportRequest request = ReportRequest.builder()
                .reportType("section_ab")
                .combined(true)
                .locale(locale)
                .build();
        byte[] pdf = generatorsByType.get("section_ab").generate(request);
        String filename = "PLATOON CHART A&B - " + LocalDate.now().format(DATE_FMT) + ".pdf";
        storeReportAsync("schedule", filename, pdf, "application/pdf");
        return pdfResponse(pdf, filename);
    }

    @GetMapping("/download/{fileId}")
    public ResponseEntity<byte[]> downloadReport(@PathVariable String fileId) {
        byte[] pdf = reportFileService.retrieve(fileId);
        if (pdf == null) {
            return ResponseEntity.notFound().build();
        }
        return pdfResponse(pdf, fileId + ".pdf");
    }

    @GetMapping("/section-a/excel")
    public ResponseEntity<byte[]> generateSectionAExcel() {
        byte[] excel = sectionABExcelGenerator.generate("A");
        String filename = "PLATOON CHART A&B - " + LocalDate.now().format(DATE_FMT) + ".xlsx";
        storeReportAsync("section_a", filename, excel, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        return excelResponse(excel, filename);
    }

    @GetMapping("/section-b/excel")
    public ResponseEntity<byte[]> generateSectionBExcel() {
        byte[] excel = sectionABExcelGenerator.generate("B");
        String filename = "PLATOON CHART A&B - " + LocalDate.now().format(DATE_FMT) + ".xlsx";
        storeReportAsync("section_b", filename, excel, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        return excelResponse(excel, filename);
    }

    @GetMapping("/section-ab/excel")
    public ResponseEntity<byte[]> generateSectionABExcel() {
        byte[] excel = sectionABExcelGenerator.generateCombined();
        String filename = "PLATOON CHART A&B - " + LocalDate.now().format(DATE_FMT) + ".xlsx";
        storeReportAsync("section_ab", filename, excel, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        return excelResponse(excel, filename);
    }

    @GetMapping("/platoon-chart/excel")
    public ResponseEntity<byte[]> generatePlatoonChartExcel() {
        byte[] excel = platoonChartExcelGenerator.generate();
        String filename = buildPlatoonChartCFilename(".xlsx");
        storeReportAsync("platoon_chart", filename, excel, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        return excelResponse(excel, filename);
    }

    @GetMapping("/mt-section/excel")
    public ResponseEntity<byte[]> generateMtSectionExcel() {
        byte[] excel = mtSectionExcelGenerator.generate();
        String filename = "MT_Section_" + LocalDate.now().format(DATE_FMT) + ".xlsx";
        storeReportAsync("mt_section", filename, excel, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        return excelResponse(excel, filename);
    }

    @GetMapping("/form-168/excel")
    public ResponseEntity<byte[]> generateDailyStatementExcel(
            @RequestParam(required = false) LocalDate date) {
        LocalDate reportDate = date != null ? date : LocalDate.now();
        byte[] excel = dailyStatementExcelGenerator.generate(reportDate);
        String filename = "Statement (Form 168) - " + reportDate.format(DATE_FMT) + ".xlsx";
        storeReportAsync("form_168", filename, excel, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        return excelResponse(excel, filename);
    }

    /**
     * Generates Form 168 Excel for a specific cycle (platoon rotation sections only).
     * Reads from cycle_duty_assignments table. Completely separate from existing Form 168.
     */
    @GetMapping("/cycle-form168/{cycleId}/excel")
    public ResponseEntity<byte[]> generateCycleForm168Excel(@PathVariable Long cycleId) {
        byte[] excel = cycleForm168ExcelGenerator.generate(cycleId);
        String filename = "Cycle_Form168_Cycle" + cycleId + "_" + LocalDate.now().format(DATE_FMT) + ".xlsx";
        return excelResponse(excel, filename);
    }

    /**
     * Generates Form 168 PDF for a specific cycle (platoon rotation sections only).
     * Reads from cycle_duty_assignments table. Uses OpenPDF with same styling as existing Form 168.
     */
    @GetMapping("/cycle-form168/{cycleId}/pdf")
    public ResponseEntity<byte[]> generateCycleForm168Pdf(@PathVariable Long cycleId) {
        byte[] pdf = cycleForm168PdfGenerator.generate(cycleId);
        String filename = "Cycle_Form168_Cycle" + cycleId + "_" + LocalDate.now().format(DATE_FMT) + ".pdf";
        return pdfResponse(pdf, filename);
    }

    @GetMapping("/section-form168/{sectionCode}")
    public ResponseEntity<byte[]> generateSectionForm168Pdf(@PathVariable String sectionCode,
            @RequestParam(required = false, defaultValue = "en") String locale) {
        String section = sectionCode.toUpperCase().trim();
        ReportRequest request = ReportRequest.builder()
                .reportType("section_ab")
                .section(section)
                .locale(locale)
                .build();
        byte[] pdf = generatorsByType.get("section_ab").generate(request);
        String filename = "Section_" + section + "_Form168_" + LocalDate.now().format(DATE_FMT) + ".pdf";
        storeReportAsync("section_form168", filename, pdf, "application/pdf");
        return pdfResponse(pdf, filename);
    }

    @GetMapping("/section-form168/{sectionCode}/excel")
    public ResponseEntity<byte[]> generateSectionForm168Excel(@PathVariable String sectionCode) {
        String section = sectionCode.toUpperCase().trim();
        byte[] excel = sectionABExcelGenerator.generate(section);
        String filename = "Section_" + section + "_Form168_" + LocalDate.now().format(DATE_FMT) + ".xlsx";
        storeReportAsync("section_form168", filename, excel, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        return excelResponse(excel, filename);
    }

    @GetMapping("/leave-statement/excel")
    public ResponseEntity<byte[]> generateLeaveStatementExcel(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String leaveType,
            @RequestParam(required = false) LocalDate startDate,
            @RequestParam(required = false) LocalDate endDate) {
        byte[] excel = leaveStatementExcelGenerator.generate(status, leaveType, startDate, endDate);
        String filename = buildLeaveStatementFilename(startDate, endDate, ".xlsx");
        storeReportAsync("leave_statement", filename, excel, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        return excelResponse(excel, filename);
    }

    @GetMapping("/personnel/excel")
    public ResponseEntity<byte[]> generatePersonnelExcel(
            @RequestParam(required = false) String section,
            @RequestParam(required = false) String designation,
            @RequestParam(required = false) Boolean isActive) {
        byte[] excel = personnelListExcelGenerator.generate(section, designation, isActive);
        String filename = "CAR MANGALURU CITY (COMPANY).xlsx";
        storeReportAsync("personnel_list", filename, excel, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        return excelResponse(excel, filename);
    }

    /**
     * Complete Personnel List PDF - combines both CAR and MT units
     */
    @GetMapping("/complete-personnel")
    public ResponseEntity<byte[]> generateCompletePersonnelReport(
            @RequestParam(required = false, defaultValue = "en") String locale) {
        ReportRequest request = ReportRequest.builder()
                .reportType("complete_personnel_list")
                .locale(locale)
                .build();
        byte[] pdf = generatorsByType.get("complete_personnel_list").generate(request);
        String filename = "Complete Personnel List - " + LocalDate.now().format(DATE_FMT) + ".pdf";
        storeReportAsync("complete_personnel_list", filename, pdf, "application/pdf");
        return pdfResponse(pdf, filename);
    }

    /**
     * Complete Personnel List Excel - combines both CAR and MT units
     */
    @GetMapping("/complete-personnel/excel")
    public ResponseEntity<byte[]> generateCompletePersonnelExcel() {
        byte[] excel = completePersonnelListExcelGenerator.generate();
        String filename = "Complete Personnel List - " + LocalDate.now().format(DATE_FMT) + ".xlsx";
        storeReportAsync("complete_personnel_list", filename, excel, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        return excelResponse(excel, filename);
    }

    @ExceptionHandler(ReportGenerationException.class)
    public ResponseEntity<Map<String, String>> handleReportError(ReportGenerationException ex) {
        return ResponseEntity.status(500)
                .body(Map.of("error", ex.getMessage()));
    }

    private ResponseEntity<byte[]> excelResponse(byte[] data, String filename) {
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .body(data);
    }

    private ResponseEntity<byte[]> pdfResponse(byte[] pdf, String filename) {
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdf);
    }

    private String getDateStr() {
        return LocalDate.now().format(DATE_FMT);
    }

    /**
     * Builds the Platoon Chart C filename using rotation state dates.
     * Format: "PLATOON CHART C {start_date} to {end_date}.ext"
     * Uses lastRotationDate as start and lastRotationDate + (5 * rotationDays - 1) as end.
     * If no rotation state, uses current date as start and +74 days as end.
     */
    private String buildPlatoonChartCFilename(String extension) {
        LocalDate startDate;
        LocalDate endDate;
        try {
            List<PlatoonRotationState> states = platoonRotationStateRepository.findAll();
            if (!states.isEmpty()) {
                PlatoonRotationState state = states.get(0);
                startDate = state.getLastRotationDate() != null ? state.getLastRotationDate() : LocalDate.now();
                // Default rotation is 15 days, 5 cycles = 75 days total, so end = start + 74
                endDate = startDate.plusDays(74);
            } else {
                startDate = LocalDate.now();
                endDate = startDate.plusDays(74);
            }
        } catch (Exception e) {
            log.warn("Could not load rotation state for filename, using defaults: {}", e.getMessage());
            startDate = LocalDate.now();
            endDate = startDate.plusDays(74);
        }
        return "PLATOON CHART C " + startDate.format(DATE_FMT) + " to " + endDate.format(DATE_FMT) + extension;
    }

    /**
     * Builds the Leave Statement filename.
     * Format: "Leave Statement- {startDate} - {endDate}.ext" (DD-MM-YYYY)
     * If no dates provided: "Leave Statement- {current date}.ext"
     */
    private String buildLeaveStatementFilename(LocalDate startDate, LocalDate endDate, String extension) {
        if (startDate != null && endDate != null) {
            return "Leave Statement- " + startDate.format(DATE_FMT) + " - " + endDate.format(DATE_FMT) + extension;
        }
        return "Leave Statement- " + LocalDate.now().format(DATE_FMT) + extension;
    }

    private void storeReportAsync(String reportType, String filename, byte[] data, String contentType) {
        CompletableFuture.runAsync(() -> {
            try {
                String s3Key = s3ReportStorageService.upload(reportType, filename, data, contentType);
                ReportHistory history = new ReportHistory();
                history.setReportName(filename);
                history.setReportType(reportType);
                history.setS3Key(s3Key);
                history.setFileSize((long) data.length);
                history.setContentType(contentType);
                reportHistoryRepository.save(history);
            } catch (Exception e) {
                log.warn("Failed to store report in S3: {}", e.getMessage());
            }
        });
    }
}

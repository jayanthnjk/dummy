import React, { useState } from 'react';
import { Button, CircularProgress } from '@mui/material';
import DownloadIcon from '@mui/icons-material/Download';
import { useTranslation } from 'react-i18next';

interface DownloadButtonProps {
  labelKey: string;
  onDownload: () => Promise<void>;
  size?: 'small' | 'medium' | 'large';
  variant?: 'text' | 'outlined' | 'contained';
}

const DownloadButton: React.FC<DownloadButtonProps> = ({
  labelKey,
  onDownload,
  size = 'small',
  variant = 'outlined',
}) => {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(false);

  const handleClick = async () => {
    setLoading(true);
    try {
      await onDownload();
    } catch {
      // Error handled by caller
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button
      variant={variant}
      size={size}
      startIcon={loading ? <CircularProgress size={16} /> : <DownloadIcon />}
      onClick={handleClick}
      disabled={loading}
    >
      {loading ? t('report.generating') : t(labelKey)}
    </Button>
  );
};

export default DownloadButton;

package com.policescheduler.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Entity for archived cycle duty assignments.
 * Same structure as CycleDutyAssignment with additional archived_at timestamp.
 * Records are moved here when their cycle is marked COMPLETED.
 */
@Entity
@Table(name = "archived_cycle_duty_assignments")
public class ArchivedCycleDutyAssignment {

    @Id
    private Long id;  // Keep original ID, no auto-generate

    @Column(name = "cycle_id", nullable = false)
    private Long cycleId;

    @Column(nullable = false)
    private LocalDate date;

    @Column(name = "platoon_id", nullable = false)
    private Long platoonId;

    @Column(name = "section_id", nullable = false)
    private Long sectionId;

    @Column(name = "person_id", nullable = false)
    private Long personId;

    @Column(name = "shift_type", nullable = false, length = 10)
    private String shiftType = "DAY";

    @Column(name = "is_override", nullable = false)
    private Boolean isOverride = false;

    @Column(name = "group_index", length = 1)
    private String groupIndex;

    @Column(name = "status", length = 20)
    private String status;

    @Column(name = "adhoc_duty_id")
    private Long adhocDutyId;

    @Column(name = "duty_name", length = 100)
    private String dutyName;

    @Column(name = "duty_type", length = 200)
    private String dutyType;

    @Column(name = "duty_location", length = 200)
    private String dutyLocation;

    @Column(name = "location", length = 200)
    private String location;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    @Column(name = "archived_at", nullable = false)
    private LocalDateTime archivedAt;

    @PrePersist
    protected void onCreate() {
        if (archivedAt == null) {
            archivedAt = LocalDateTime.now();
        }
    }

    public ArchivedCycleDutyAssignment() {}

    /**
     * Create archived record from original CycleDutyAssignment.
     */
    public static ArchivedCycleDutyAssignment fromCycleDutyAssignment(CycleDutyAssignment original) {
        ArchivedCycleDutyAssignment archived = new ArchivedCycleDutyAssignment();
        archived.setId(original.getId());
        archived.setCycleId(original.getCycleId());
        archived.setDate(original.getDate());
        archived.setPlatoonId(original.getPlatoonId());
        archived.setSectionId(original.getSectionId());
        archived.setPersonId(original.getPersonId());
        archived.setShiftType(original.getShiftType());
        archived.setIsOverride(original.getIsOverride());
        archived.setGroupIndex(original.getGroupIndex());
        archived.setStatus(original.getStatus());
        archived.setAdhocDutyId(original.getAdhocDutyId());
        archived.setDutyName(original.getDutyName());
        archived.setDutyType(original.getDutyType());
        archived.setDutyLocation(original.getDutyLocationField());
        archived.setLocation(original.getLocation());
        archived.setUpdatedAt(original.getUpdatedAt());
        archived.setArchivedAt(LocalDateTime.now());
        return archived;
    }

    // Getters and Setters

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getCycleId() { return cycleId; }
    public void setCycleId(Long cycleId) { this.cycleId = cycleId; }

    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }

    public Long getPlatoonId() { return platoonId; }
    public void setPlatoonId(Long platoonId) { this.platoonId = platoonId; }

    public Long getSectionId() { return sectionId; }
    public void setSectionId(Long sectionId) { this.sectionId = sectionId; }

    public Long getPersonId() { return personId; }
    public void setPersonId(Long personId) { this.personId = personId; }

    public String getShiftType() { return shiftType; }
    public void setShiftType(String shiftType) { this.shiftType = shiftType; }

    public Boolean getIsOverride() { return isOverride; }
    public void setIsOverride(Boolean isOverride) { this.isOverride = isOverride; }

    public String getGroupIndex() { return groupIndex; }
    public void setGroupIndex(String groupIndex) { this.groupIndex = groupIndex; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Long getAdhocDutyId() { return adhocDutyId; }
    public void setAdhocDutyId(Long adhocDutyId) { this.adhocDutyId = adhocDutyId; }

    public String getDutyName() { return dutyName; }
    public void setDutyName(String dutyName) { this.dutyName = dutyName; }

    public String getDutyType() { return dutyType; }
    public void setDutyType(String dutyType) { this.dutyType = dutyType; }

    public String getDutyLocation() { return dutyLocation; }
    public void setDutyLocation(String dutyLocation) { this.dutyLocation = dutyLocation; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }

    public LocalDateTime getArchivedAt() { return archivedAt; }
    public void setArchivedAt(LocalDateTime archivedAt) { this.archivedAt = archivedAt; }
}

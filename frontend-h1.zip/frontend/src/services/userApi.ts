import api from './api';

export interface UserDto {
  id: number;
  username: string;
  displayName: string;
  email: string | null;
  role: string;
  units: string | null;
  personnelId: number | null;
  locale: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateUserRequest {
  username: string;
  password: string;
  displayName: string;
  email?: string;
  role: string;
  units?: string;
  personnelId?: number | null;
  locale?: string;
}

export const userApi = {
  getAll: () => api.get<UserDto[]>('/api/users').then((r) => r.data),

  getById: (id: number) => api.get<UserDto>(`/api/users/${id}`).then((r) => r.data),

  create: (request: CreateUserRequest) => api.post<UserDto>('/api/users', request).then((r) => r.data),

  update: (id: number, request: CreateUserRequest) => api.put<UserDto>(`/api/users/${id}`, request).then((r) => r.data),

  delete: (id: number) => api.delete(`/api/users/${id}`).then((r) => r.data),

  getRoles: () => api.get<string[]>('/api/users/roles').then((r) => r.data),
};

import api from './api';

export interface ReportHistoryItem {
  id: number;
  reportName: string;
  reportType: string;
  s3Key: string;
  fileSize: number;
  contentType: string;
  generatedAt: string;
  generatedBy: string | null;
}

export interface ReportHistoryPage {
  content: ReportHistoryItem[];
  totalElements: number;
  totalPages: number;
  number: number;
  size: number;
}

export interface ReportHistoryParams {
  reportType?: string;
  fromDate?: string;
  toDate?: string;
  page?: number;
  size?: number;
}

const downloadBlob = (data: Blob, filename: string) => {
  const url = window.URL.createObjectURL(data);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.click();
  window.URL.revokeObjectURL(url);
};

export const reportService = {
  downloadForm168: async (date?: string) => {
    const response = await api.get('/api/reports/form-168', {
      params: date ? { date } : undefined,
      responseType: 'blob',
    });
    downloadBlob(response.data, `form-168-${date || 'today'}.pdf`);
  },

  downloadPersonnelReport: async () => {
    const response = await api.get('/api/reports/personnel', { responseType: 'blob' });
    downloadBlob(response.data, 'personnel-report.pdf');
  },

  downloadSectionAReport: async () => {
    const response = await api.get('/api/reports/section-a', { responseType: 'blob' });
    downloadBlob(response.data, 'section-a-report.pdf');
  },

  downloadSectionBReport: async () => {
    const response = await api.get('/api/reports/section-b', { responseType: 'blob' });
    downloadBlob(response.data, 'section-b-report.pdf');
  },

  downloadSectionAExcel: async () => {
    const response = await api.get('/api/reports/section-a/excel', { responseType: 'blob' });
    downloadBlob(response.data, 'section-a.xlsx');
  },

  downloadSectionBExcel: async () => {
    const response = await api.get('/api/reports/section-b/excel', { responseType: 'blob' });
    downloadBlob(response.data, 'section-b.xlsx');
  },

  downloadPlatoonChart: async () => {
    const response = await api.get('/api/reports/platoon-chart', { responseType: 'blob' });
    downloadBlob(response.data, 'platoon-chart.pdf');
  },

  downloadPlatoonChartExcel: async () => {
    const response = await api.get('/api/reports/platoon-chart/excel', { responseType: 'blob' });
    downloadBlob(response.data, 'section-c.xlsx');
  },

  downloadMtSection: async () => {
    const response = await api.get('/api/reports/mt-section', { responseType: 'blob' });
    downloadBlob(response.data, 'mt-section-report.pdf');
  },

  downloadLeaveStatement: async () => {
    const response = await api.get('/api/reports/leave-statement', { responseType: 'blob' });
    downloadBlob(response.data, 'leave-statement.pdf');
  },

  // Keep backward-compatible aliases
  downloadScheduleReport: async () => {
    const response = await api.get('/api/reports/schedules', { responseType: 'blob' });
    downloadBlob(response.data, 'schedule-report.pdf');
  },

  downloadLeaveReport: async () => {
    const response = await api.get('/api/reports/leave-requests', { responseType: 'blob' });
    downloadBlob(response.data, 'leave-report.pdf');
  },

  // Report history API (S3-stored reports)
  getReportHistory: async (params: ReportHistoryParams): Promise<ReportHistoryPage> => {
    const response = await api.get('/api/reports/history', { params });
    return response.data;
  },

  downloadStoredReport: async (id: number): Promise<void> => {
    const response = await api.get(`/api/reports/history/${id}/download`, { responseType: 'blob' });
    const contentDisposition = response.headers['content-disposition'];
    let filename = 'report';
    if (contentDisposition) {
      const match = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
      if (match && match[1]) {
        filename = match[1].replace(/['"]/g, '');
      }
    }
    downloadBlob(response.data, filename);
  },
};

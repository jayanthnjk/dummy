# Infrastructure Deep Dive Guide
## KSP WorkBoard — Complete Infrastructure Documentation

| Field | Details |
|-------|---------|
| **Document Title** | Infrastructure Setup & Deep Dive |
| **Version** | 1.0.0 |
| **Date** | June 2026 |
| **Cloud Provider** | AWS (Amazon Web Services) |

---

## 1. Infrastructure Architecture

```mermaid
graph TB
    subgraph "Internet"
        USER[Police Officers<br>Various Devices]
    end

    subgraph "AWS Account"
        subgraph "IAM"
            IAM_USER[IAM User: ksp-admin<br>Programmatic + Console]
            IAM_ROLE[IAM Role: ksp-ec2-role<br>Attached to EC2]
        end

        subgraph "VPC: ksp-vpc (10.0.0.0/16)"
            subgraph "Public Subnet A (10.0.1.0/24)"
                EC2_INST[EC2: ksp-backend<br>t3.medium<br>Amazon Linux 2]
            end
            subgraph "Public Subnet B (10.0.2.0/24)"
                direction TB
            end
            subgraph "Private Subnet A (10.0.3.0/24)"
                RDS_INST[RDS: ksp-postgres<br>db.t3.micro<br>PostgreSQL 15]
            end
            subgraph "Private Subnet B (10.0.4.0/24)"
                direction TB
            end
        end

        subgraph "CDN"
            CF[CloudFront Distribution<br>HTTPS + Custom Domain]
            S3[S3: ksp-frontend-assets<br>React Build]
        end

        subgraph "AI Service"
            BEDROCK[AWS Bedrock<br>Amazon Nova Lite v1<br>us-east-1]
        end
    end

    subgraph "External"
        GROQ_EXT[Groq Cloud API<br>Development Only]
    end

    USER --> CF
    USER --> EC2_INST
    CF --> S3
    EC2_INST --> RDS_INST
    EC2_INST --> BEDROCK
    EC2_INST --> GROQ_EXT
    IAM_ROLE --> EC2_INST
```

---

## 2. AWS Services Used

| Service | Resource Name | Specification | Purpose | Monthly Cost |
|---------|-------------|---------------|---------|--------------|
| EC2 | ksp-backend | t3.medium (2 vCPU, 4GB RAM) | Application server | ~$30 |
| RDS | ksp-postgres | db.t3.micro (1 vCPU, 1GB) | PostgreSQL database | ~$15 (or free tier) |
| S3 | ksp-frontend-assets | Standard bucket | Frontend static files | ~$1 |
| CloudFront | dtszoaal8ujla.cloudfront.net | Global CDN | HTTPS + caching | ~$1 |
| Bedrock | amazon.nova-lite-v1:0 | AI model invocation | LLM for chat | ~$5-30 (usage) |
| IAM | ksp-ec2-role | EC2 instance role | Bedrock + CloudWatch access | Free |
| VPC | ksp-vpc | 10.0.0.0/16 | Network isolation | Free |

**Total estimated: ~$50-80/month**

---

## 3. Network Configuration

### 3.1 VPC Design

| Component | CIDR | AZ | Purpose |
|-----------|------|-----|---------|
| VPC | 10.0.0.0/16 | — | Main VPC |
| Public Subnet A | 10.0.1.0/24 | us-east-1a | EC2 instance |
| Public Subnet B | 10.0.2.0/24 | us-east-1b | Failover (unused) |
| Private Subnet A | 10.0.3.0/24 | us-east-1a | RDS primary |
| Private Subnet B | 10.0.4.0/24 | us-east-1b | RDS standby (multi-AZ) |

### 3.2 Security Groups

**ksp-backend-sg (EC2):**
| Type | Protocol | Port | Source | Purpose |
|------|----------|------|--------|---------|
| Inbound | TCP | 8080 | 0.0.0.0/0 (or CloudFront IPs) | API access |
| Inbound | TCP | 22 | Your IP /32 | SSH access |
| Outbound | All | All | 0.0.0.0/0 | Internet (LLM APIs, package repos) |

**ksp-db-sg (RDS):**
| Type | Protocol | Port | Source | Purpose |
|------|----------|------|--------|---------|
| Inbound | TCP | 5432 | ksp-backend-sg | DB from backend only |
| Outbound | None | — | — | No outbound needed |

### 3.3 Route Tables

| Route | Target | Purpose |
|-------|--------|---------|
| 10.0.0.0/16 | local | VPC internal |
| 0.0.0.0/0 | Internet Gateway | Public subnet internet |

---

## 4. EC2 Instance Configuration

### 4.1 Instance Details

| Attribute | Value |
|-----------|-------|
| Instance Type | t3.medium |
| AMI | Amazon Linux 2 (latest) |
| vCPU | 2 |
| Memory | 4 GB |
| Storage | 20 GB gp3 EBS |
| Key Pair | ksp-key (RSA, PEM format) |
| IAM Role | ksp-ec2-role |
| Security Group | ksp-backend-sg |
| Subnet | Public Subnet A |
| Public IP | Elastic IP (recommended) or auto-assign |

### 4.2 Installed Software

| Software | Version | Installed By |
|----------|---------|-------------|
| Java (Amazon Corretto) | 17 | setup-ec2.sh |
| PostgreSQL Client | 16 | setup-ec2.sh |
| CloudWatch Agent | Latest | setup-ec2.sh |
| Git | Latest | setup-ec2.sh |
| systemd | (system) | OS default |

### 4.3 Directory Structure on EC2

```
/opt/ksp/
├── ksp-workboard.jar          # Application JAR (~80MB)
└── logs/                       # Application logs (if file appender configured)

/etc/systemd/system/
└── ksp-backend.service        # Service definition with env vars
```

### 4.4 JVM Configuration

```
-Xms256m                        # Initial heap size
-Xmx512m                        # Maximum heap size
--spring.profiles.active=prod   # Production profile
```

**Memory budget (4GB EC2):**
- OS + system: ~500MB
- JVM heap: 512MB
- JVM metaspace/threads: ~200MB
- Available buffer: ~2.8GB

---

## 5. RDS Configuration

### 5.1 Instance Details

| Attribute | Value |
|-----------|-------|
| Engine | PostgreSQL 15 |
| Instance Class | db.t3.micro (or t3.small for more capacity) |
| Storage | 20 GB gp3 |
| Multi-AZ | No (cost saving; enable for HA) |
| Backup Retention | 7 days (automated) |
| Maintenance Window | Sun 03:00-04:00 UTC |
| Security Group | ksp-db-sg |
| Subnet Group | Private subnets A & B |
| Database Name | ksp_workboard |
| Master Username | ksp_admin |
| Port | 5432 |

### 5.2 Extensions Required

```sql
CREATE EXTENSION IF NOT EXISTS vector;    -- pgvector for embeddings
CREATE EXTENSION IF NOT EXISTS pg_trgm;   -- Trigram for fuzzy search
```

### 5.3 Connection String

```
jdbc:postgresql://ksp-postgres.cxyz.us-east-1.rds.amazonaws.com:5432/ksp_workboard
```

### 5.4 Performance Parameters

| Parameter | Value | Purpose |
|-----------|-------|---------|
| max_connections | 100 (default) | Sufficient for single app server |
| shared_buffers | 25% of RAM | Query cache |
| work_mem | 4MB | Sort/hash operations |
| maintenance_work_mem | 64MB | VACUUM, CREATE INDEX |

---

## 6. S3 + CloudFront Configuration

### 6.1 S3 Bucket

| Attribute | Value |
|-----------|-------|
| Bucket Name | ksp-frontend-assets |
| Region | us-east-1 |
| Access | Private (CloudFront OAC only) |
| Static Hosting | Enabled |
| Index Document | index.html |
| Error Document | index.html (SPA routing) |
| Versioning | Enabled (optional) |

### 6.2 CloudFront Distribution

| Attribute | Value |
|-----------|-------|
| Domain | dtszoaal8ujla.cloudfront.net |
| Origin | S3 bucket via OAC |
| Default Root | index.html |
| Price Class | Use Only North America & Europe (cost saving) |
| HTTP/2 | Enabled |
| HTTPS | Redirect HTTP to HTTPS |
| Custom Error Pages | 403→/index.html (200), 404→/index.html (200) |
| Cache TTL | 86400s (static assets), 0 for index.html |

### 6.3 Cache Behavior for API (Optional)

If routing API through CloudFront:
| Path Pattern | Origin | Caching |
|-------------|--------|---------|
| /api/* | EC2:8080 | No cache (pass-through) |
| Default (*) | S3 bucket | Cache enabled |

---

## 7. IAM Configuration

### 7.1 IAM User: ksp-admin

| Attribute | Value |
|-----------|-------|
| Access Type | Programmatic + Console |
| Policies | AdministratorAccess (for deployment) |
| MFA | Enabled (required) |

### 7.2 EC2 IAM Role: ksp-ec2-role

| Policy | Purpose |
|--------|---------|
| AmazonBedrockFullAccess | Invoke AI models |
| CloudWatchAgentServerPolicy | Push logs/metrics |
| (Optional) AmazonS3ReadOnlyAccess | If app reads from S3 |

### 7.3 Trust Policy

```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Principal": { "Service": "ec2.amazonaws.com" },
    "Action": "sts:AssumeRole"
  }]
}
```

---

## 8. Systemd Service Deep Dive

### 8.1 Service File: /etc/systemd/system/ksp-backend.service

```ini
[Unit]
Description=KSP Workboard Spring Boot Backend
After=network.target
Wants=network-online.target

[Service]
Type=simple
User=ec2-user
Group=ec2-user
WorkingDirectory=/opt/ksp
ExecStart=/usr/bin/java -Xms256m -Xmx512m -jar /opt/ksp/ksp-workboard.jar --spring.profiles.active=prod
Restart=always
RestartSec=10
SuccessExitStatus=143

# Environment variables (sensitive — file readable by root only)
Environment=DB_URL=jdbc:postgresql://<RDS-ENDPOINT>:5432/ksp_workboard
Environment=DB_USERNAME=ksp_admin
Environment=DB_PASSWORD=<STRONG-PASSWORD>
Environment=JWT_SECRET=<64-CHAR-SECRET>
Environment=AI_PROVIDER=bedrock
Environment=AWS_REGION=us-east-1
Environment=BEDROCK_MODEL_ID=amazon.nova-lite-v1:0
Environment=CORS_ALLOWED_ORIGINS=https://<CLOUDFRONT-DOMAIN>

StandardOutput=journal
StandardError=journal
SyslogIdentifier=ksp-backend

[Install]
WantedBy=multi-user.target
```

### 8.2 Service Management Commands

```bash
sudo systemctl daemon-reload        # After editing service file
sudo systemctl enable ksp-backend   # Enable on boot
sudo systemctl start ksp-backend    # Start
sudo systemctl stop ksp-backend     # Stop (SIGTERM, exit 143)
sudo systemctl restart ksp-backend  # Stop + Start
sudo systemctl status ksp-backend   # Current status
```

### 8.3 Auto-Restart Behavior

| Parameter | Value | Meaning |
|-----------|-------|---------|
| Restart=always | All exits | Restarts on any exit (crash, OOM, etc.) |
| RestartSec=10 | 10 seconds | Wait before restart |
| SuccessExitStatus=143 | SIGTERM | Treats graceful shutdown as success |

---

## 9. Deployment Pipeline

### 9.1 Backend Deployment Flow

```mermaid
flowchart LR
    A[Developer Machine] -->|1. gradlew build| B[JAR built]
    B -->|2. scp to EC2| C[/opt/ksp/ksp-workboard.jar]
    C -->|3. systemctl restart| D[Service Running]
    D -->|4. Health check| E[Verified UP]
```

### 9.2 Frontend Deployment Flow

```mermaid
flowchart LR
    A[Developer Machine] -->|1. npm run build| B[dist/ folder]
    B -->|2. aws s3 sync| C[S3 Bucket Updated]
    C -->|3. CloudFront invalidation| D[CDN Cache Cleared]
    D -->|4. Users see new version| E[Done]
```

### 9.3 Deploy Script Commands

```bash
# Full deploy
bash backend/deploy/aws/deploy.sh 54.123.45.67

# Backend only
bash backend/deploy/aws/deploy-backend.sh 54.123.45.67
# Internally: gradlew build → scp JAR → ssh systemctl restart

# Frontend only
bash backend/deploy/aws/deploy-frontend.sh
# Internally: npm build → aws s3 sync dist/ s3://bucket → aws cloudfront create-invalidation
```

---

## 10. Monitoring & Observability

### 10.1 Application Logs

```bash
# Real-time
sudo journalctl -u ksp-backend -f

# Last hour
sudo journalctl -u ksp-backend --since "1 hour ago"

# Search for errors
sudo journalctl -u ksp-backend | grep -i "error\|exception"

# Chat processing times
sudo journalctl -u ksp-backend | grep "Chat processed in"
```

### 10.2 Key Log Patterns

| Pattern | Meaning |
|---------|---------|
| `Chat processed in XXXms` | Chat request total time |
| `LLM resolved: tool=X` | Which tool LLM selected |
| `Circuit breaker 'X' triggered fallback` | External service failure |
| `Prompt injection detected` | Security event |
| `Tool execution failed` | MCP tool error |
| `Leave request {} approved by {}` | Business event |

### 10.3 CloudWatch (Optional)

If CloudWatch Agent is configured:
- Custom metrics: CPU, Memory, Disk
- Log groups: /ksp/backend/application
- Alarms: CPU > 80% for 5 min, Disk > 90%

---

## 11. Backup Strategy

### 11.1 Automated (RDS)

| Feature | Setting |
|---------|---------|
| Automated Backups | Enabled |
| Retention Period | 7 days |
| Backup Window | 03:00-04:00 UTC |
| Point-in-Time Recovery | Available within retention |

### 11.2 Manual Backup

```bash
# From EC2 (has psql client)
pg_dump -h <rds-endpoint> -U ksp_admin -d ksp_workboard -Fc -f /opt/ksp/backup_$(date +%Y%m%d).dump

# Upload to S3 for safekeeping
aws s3 cp /opt/ksp/backup_$(date +%Y%m%d).dump s3://ksp-backups/
```

### 11.3 Restore Procedure

```bash
# Create fresh database (if needed)
createdb -h <rds-endpoint> -U ksp_admin ksp_workboard_restored

# Restore
pg_restore -h <rds-endpoint> -U ksp_admin -d ksp_workboard_restored backup.dump

# Re-enable extensions
psql -h <rds-endpoint> -U ksp_admin -d ksp_workboard_restored -c "CREATE EXTENSION IF NOT EXISTS vector;"
```

---

## 12. Scaling Plan

### 12.1 Current (Single Instance)

```
Users → EC2 (single) → RDS (single)
```
Supports: ~50 concurrent users, ~30 chat requests/min

### 12.2 Future (Multi-Instance)

```
Users → ALB → EC2×2 → RDS (multi-AZ)
                   ↘ ElastiCache Redis (shared cache/sessions)
```

**Changes needed for scaling:**
| Component | Current | Scaled |
|-----------|---------|--------|
| Load Balancer | None | Application Load Balancer |
| EC2 | Single t3.medium | 2× t3.medium (auto-scaling group) |
| Cache | Caffeine (local) | Redis (ElastiCache) |
| Database | Single AZ | Multi-AZ RDS |
| Sessions | Stateless JWT | No change needed (already stateless) |

---

## 13. Security Hardening Checklist

| # | Item | Status | Priority |
|---|------|--------|----------|
| 1 | SSH key rotation | ☐ | High |
| 2 | Security group: restrict 8080 to CloudFront IPs only | ☐ | High |
| 3 | RDS: enforce SSL connections | ☐ | Medium |
| 4 | EC2: disable password SSH login | ☐ | High |
| 5 | Enable AWS CloudTrail | ☐ | Medium |
| 6 | Enable VPC Flow Logs | ☐ | Low |
| 7 | Set up AWS Config rules | ☐ | Low |
| 8 | Enable RDS encryption at rest | ☐ | Medium |
| 9 | S3 bucket policy: deny public access | ☐ | High |
| 10 | Regular dependency vulnerability scan | ☐ | Medium |

---

## 14. Cost Optimization

| Strategy | Savings | Implementation |
|----------|---------|----------------|
| Use Spot Instances for dev | 60-70% | AWS Spot for non-prod |
| Right-size EC2 | $10-15/mo | Monitor CPU; downgrade if < 30% avg |
| Reserved Instances (1yr) | 30-40% | If committed to production |
| Compress S3 assets | Negligible | Already optimized by Vite build |
| Bedrock usage monitoring | Variable | Monitor token usage via CloudWatch |
| Turn off dev resources nights/weekends | 60% | AWS Instance Scheduler |

---

*End of Document — Infrastructure Deep Dive v1.0.0*

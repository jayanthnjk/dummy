import React, { useState } from 'react';
import {
  Box, Card, CardContent, Typography, Button, TextField, Alert,
  CircularProgress, Chip, Link, keyframes, InputAdornment,
} from '@mui/material';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import CalendarMonthOutlinedIcon from '@mui/icons-material/CalendarMonthOutlined';
import GroupsOutlinedIcon from '@mui/icons-material/GroupsOutlined';
import BarChartOutlinedIcon from '@mui/icons-material/BarChartOutlined';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguageContext } from '@/contexts/LanguageContext';
import { authService } from '@/services/authService';

/* ── Animations ── */
const fadeInUp = keyframes`
  from { opacity: 0; transform: translateY(24px); }
  to   { opacity: 1; transform: translateY(0); }
`;
const glowPulse = keyframes`
  0%, 100% { box-shadow: 0 0 30px rgba(13,148,136,0.12), 0 0 60px rgba(67,56,202,0.06); }
  50%      { box-shadow: 0 0 40px rgba(13,148,136,0.22), 0 0 80px rgba(67,56,202,0.1); }
`;
const shimmer = keyframes`
  0%   { background-position: -200% 0; }
  100% { background-position: 200% 0; }
`;
const meshMove = keyframes`
  0%   { transform: translate(0, 0) scale(1); }
  33%  { transform: translate(30px, -20px) scale(1.05); }
  66%  { transform: translate(-20px, 15px) scale(0.95); }
  100% { transform: translate(0, 0) scale(1); }
`;
const meshMove2 = keyframes`
  0%   { transform: translate(0, 0) scale(1); }
  33%  { transform: translate(-25px, 25px) scale(1.08); }
  66%  { transform: translate(20px, -10px) scale(0.92); }
  100% { transform: translate(0, 0) scale(1); }
`;

const LoginPage: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { login } = useAuth();
  const { locale, toggleLanguage } = useLanguageContext();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const response = await authService.login({ username, password });
      login(response);
      navigate('/');
    } catch (err: unknown) {
      const axiosErr = err as { response?: { status?: number } };
      setError(axiosErr.response?.status === 401
        ? t('login.invalidCredentials') : t('login.loginFailed'));
    } finally { setLoading(false); }
  };

  return (
    <Box sx={{ position: 'fixed', inset: 0, display: 'flex', flexDirection: { xs: 'column', md: 'row' }, overflow: 'hidden' }}>

      {/* ═══════ LEFT PANEL — Deep Indigo Gradient with Mesh ═══════ */}
      <Box sx={{
        flex: { xs: 'none', md: '0 0 50%' },
        minHeight: { xs: 280, md: 'auto' },
        height: { md: '100%' },
        background: 'linear-gradient(155deg, #0f172a 0%, #1e1b4b 35%, #312e81 65%, #1e3a5f 100%)',
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center',
        p: { xs: 4, sm: 5, md: 6 },
        position: 'relative', overflow: 'hidden',
      }}>
        {/* Animated mesh gradient blobs */}
        <Box sx={{
          position: 'absolute', width: '70%', height: '70%', top: '-15%', left: '-20%',
          background: 'radial-gradient(circle, rgba(67,56,202,0.15) 0%, transparent 65%)',
          filter: 'blur(80px)', pointerEvents: 'none',
          animation: `${meshMove} 16s ease-in-out infinite`,
        }} />
        <Box sx={{
          position: 'absolute', width: '60%', height: '60%', bottom: '-10%', right: '-15%',
          background: 'radial-gradient(circle, rgba(13,148,136,0.12) 0%, transparent 65%)',
          filter: 'blur(80px)', pointerEvents: 'none',
          animation: `${meshMove2} 18s ease-in-out infinite`,
        }} />
        <Box sx={{
          position: 'absolute', width: '40%', height: '40%', top: '50%', left: '50%',
          background: 'radial-gradient(circle, rgba(20,184,166,0.08) 0%, transparent 60%)',
          filter: 'blur(50px)', pointerEvents: 'none',
          animation: `${meshMove} 12s ease-in-out infinite reverse`,
        }} />

        {/* Content */}
        <Box sx={{
          position: 'relative', zIndex: 1, textAlign: 'center', maxWidth: 420,
          animation: `${fadeInUp} 0.8s ease-out`,
        }}>
          {/* Logo */}
          <Box sx={{
            width: 130, height: 130, mx: 'auto', mb: 3.5,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Box component="img" src="/ksplogo.png" alt="KSP Logo" sx={{ width: 130, height: 130, borderRadius: '50%' }} />
          </Box>

          <Typography sx={{
            fontWeight: 800, mb: 1.2,
            fontSize: { xs: '1.75rem', sm: '2.1rem', md: '2.4rem' },
            letterSpacing: '-0.03em', lineHeight: 1.1,
            background: 'linear-gradient(135deg, #ffffff 0%, #14b8a6 60%, #ffffff 100%)',
            backgroundClip: 'text', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          }}>
            {t('login.title')}
          </Typography>

          <Typography sx={{
            color: 'rgba(255,255,255,0.45)', fontSize: { xs: '0.82rem', md: '0.9rem' },
            lineHeight: 1.7, mb: 5, px: 2, fontWeight: 400,
          }}>
            {t('login.description')}
          </Typography>

          {/* Feature pills */}
          <Box sx={{ display: 'flex', gap: 1.5, justifyContent: 'center', flexWrap: 'wrap' }}>
            {[
              { icon: <CalendarMonthOutlinedIcon sx={{ fontSize: 18 }} />, text: t('login.featureScheduling') },
              { icon: <GroupsOutlinedIcon sx={{ fontSize: 18 }} />, text: t('login.featurePersonnel') },
              { icon: <BarChartOutlinedIcon sx={{ fontSize: 18 }} />, text: t('login.featureReports') },
            ].map((f, i) => (
              <Box key={i} sx={{
                display: 'flex', alignItems: 'center', gap: 0.7,
                px: 2, py: 0.9, borderRadius: '24px',
                bgcolor: 'rgba(255,255,255,0.05)',
                border: '1px solid rgba(255,255,255,0.1)',
                backdropFilter: 'blur(8px)',
                color: 'rgba(255,255,255,0.6)', fontSize: '0.78rem', fontWeight: 500,
                transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                '&:hover': {
                  bgcolor: 'rgba(13,148,136,0.15)',
                  borderColor: 'rgba(20,184,166,0.35)',
                  color: 'rgba(255,255,255,0.85)',
                  transform: 'translateY(-2px)',
                },
              }}>
                {f.icon}{f.text}
              </Box>
            ))}
          </Box>
        </Box>
      </Box>

      {/* ═══════ RIGHT PANEL ═══════ */}
      <Box sx={{
        flex: 1, display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center',
        background: '#ffffff',
        p: { xs: 2, sm: 3, md: 5 }, position: 'relative',
        height: { md: '100%' },
        overflow: 'auto',
      }}>
        {/* Subtle radial background accent */}
        <Box sx={{
          position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
          background: 'radial-gradient(ellipse at 30% 20%, rgba(67,56,202,0.03) 0%, transparent 50%)',
          pointerEvents: 'none',
        }} />

        {/* Language toggle */}
        <Box sx={{ position: 'absolute', top: 20, right: 20, zIndex: 2 }}>
          <Chip
            label={locale === 'en' ? 'ಕನ್ನಡ' : 'English'}
            onClick={toggleLanguage}
            variant="outlined"
            size="small"
            sx={{
              fontWeight: 600, fontSize: '0.78rem', cursor: 'pointer',
              borderColor: '#0d9488', color: '#0f766e',
              bgcolor: 'rgba(13,148,136,0.06)',
              transition: 'all 0.2s ease',
              '&:hover': { bgcolor: 'rgba(13,148,136,0.12)', borderColor: '#0f766e' },
            }}
          />
        </Box>

        {/* ═══════ LOGIN CARD ═══════ */}
        <Card elevation={0} sx={{
          width: '100%', maxWidth: 400, borderRadius: '24px',
          bgcolor: '#ffffff', position: 'relative', overflow: 'hidden',
          border: '1px solid rgba(226,232,240,0.8)',
          boxShadow:
            '0 1px 2px rgba(15,23,42,0.02),' +
            '0 4px 8px rgba(15,23,42,0.03),' +
            '0 16px 32px rgba(49,46,129,0.06),' +
            '0 32px 64px rgba(49,46,129,0.08)',
          animation: `${fadeInUp} 0.6s ease-out 0.15s both`,
        }}>
          {/* Top accent shimmer bar */}
          <Box sx={{
            height: 3, borderRadius: '24px 24px 0 0',
            background: 'linear-gradient(90deg, #312e81, #4338ca, #0d9488, #14b8a6, #312e81)',
            backgroundSize: '200% 100%',
            animation: `${shimmer} 4s linear infinite`,
          }} />

          {/* Subtle inner glow */}
          <Box sx={{
            position: 'absolute', top: 4, left: '10%', right: '10%', height: 90,
            background: 'radial-gradient(ellipse at center, rgba(13,148,136,0.04) 0%, transparent 70%)',
            pointerEvents: 'none',
          }} />

          <CardContent sx={{ px: { xs: 3, sm: 4 }, py: { xs: 3.5, sm: 4 }, position: 'relative' }}>

            {/* Logo */}
            <Box sx={{ width: 48, height: 48, mx: 'auto', mb: 2.5 }}>
              <Box component="img" src="/ksplogo.png" alt="KSP Logo" sx={{ width: 48, height: 48 }} />
            </Box>

            <Typography sx={{
              fontWeight: 700, color: '#0f172a', textAlign: 'center', mb: 0.3,
              fontSize: { xs: '1.15rem', sm: '1.25rem' }, letterSpacing: '-0.02em',
            }}>
              {t('login.welcomeBack')}
            </Typography>
            <Typography sx={{
              color: '#94a3b8', fontSize: '0.82rem', textAlign: 'center', mb: 3.5,
            }}>
              {t('login.enterCredentials')}
            </Typography>

            {error && (
              <Alert severity="error" sx={{
                mb: 2.5, borderRadius: '12px', fontSize: '0.8rem',
                border: '1px solid #fecdd3', bgcolor: '#fff1f2',
              }}>
                {error}
              </Alert>
            )}

            <Box component="form" onSubmit={handleSubmit}>
              {/* Username */}
              <Typography component="label" sx={{
                display: 'block', fontWeight: 500, color: '#334155',
                fontSize: '0.78rem', mb: 0.6,
              }}>
                {t('login.username')}
              </Typography>
              <TextField
                placeholder={t('login.usernamePlaceholder')}
                fullWidth size="small" value={username}
                onChange={(e) => setUsername(e.target.value)}
                required autoFocus
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <PersonOutlineIcon sx={{ fontSize: 18, color: '#94a3b8' }} />
                    </InputAdornment>
                  ),
                }}
                sx={{
                  mb: 2.5,
                  '& .MuiOutlinedInput-root': {
                    borderRadius: '12px', bgcolor: '#f8fafc', fontSize: '0.85rem',
                    transition: 'all 0.25s cubic-bezier(0.4, 0, 0.2, 1)',
                    '& fieldset': { borderColor: '#e2e8f0', transition: 'all 0.25s' },
                    '&:hover fieldset': { borderColor: '#0d9488' },
                    '&.Mui-focused': {
                      bgcolor: '#fff',
                      boxShadow: '0 0 0 3px rgba(13,148,136,0.12)',
                      '& fieldset': { borderColor: '#0d9488', borderWidth: 2 },
                    },
                  },
                }}
              />

              {/* Password */}
              <Typography component="label" sx={{
                display: 'block', fontWeight: 500, color: '#334155',
                fontSize: '0.78rem', mb: 0.6,
              }}>
                {t('login.password')}
              </Typography>
              <TextField
                placeholder={t('login.passwordPlaceholder')}
                type="password" fullWidth size="small" value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <LockOutlinedIcon sx={{ fontSize: 18, color: '#94a3b8' }} />
                    </InputAdornment>
                  ),
                }}
                sx={{
                  mb: 1.2,
                  '& .MuiOutlinedInput-root': {
                    borderRadius: '12px', bgcolor: '#f8fafc', fontSize: '0.85rem',
                    transition: 'all 0.25s cubic-bezier(0.4, 0, 0.2, 1)',
                    '& fieldset': { borderColor: '#e2e8f0', transition: 'all 0.25s' },
                    '&:hover fieldset': { borderColor: '#0d9488' },
                    '&.Mui-focused': {
                      bgcolor: '#fff',
                      boxShadow: '0 0 0 3px rgba(13,148,136,0.12)',
                      '& fieldset': { borderColor: '#0d9488', borderWidth: 2 },
                    },
                  },
                }}
              />

              <Box sx={{ textAlign: 'right', mb: 3 }}>
                <Link href="#" underline="none" sx={{
                  fontSize: '0.75rem', color: '#0d9488', fontWeight: 500,
                  transition: 'color 0.2s', '&:hover': { color: '#0f766e' },
                }}>
                  {t('login.forgotPassword')}
                </Link>
              </Box>

              <Button
                type="submit" variant="contained" fullWidth size="large"
                disabled={loading || !username || !password}
                endIcon={!loading && <ArrowForwardIcon sx={{ fontSize: '18px !important' }} />}
                sx={{
                  textTransform: 'none', fontWeight: 600, borderRadius: '12px',
                  background: 'linear-gradient(135deg, #312e81 0%, #4338ca 50%, #0d9488 100%)',
                  color: '#fff', py: 1.3, fontSize: '0.9rem',
                  boxShadow: '0 4px 14px rgba(49,46,129,0.25), 0 2px 6px rgba(13,148,136,0.15)',
                  transition: 'all 0.25s cubic-bezier(0.4, 0, 0.2, 1)',
                  '&:hover': {
                    background: 'linear-gradient(135deg, #1e1b4b 0%, #312e81 50%, #0f766e 100%)',
                    boxShadow: '0 6px 20px rgba(49,46,129,0.35), 0 4px 12px rgba(13,148,136,0.2)',
                    transform: 'translateY(-1px)',
                  },
                  '&.Mui-disabled': {
                    background: '#e2e8f0', color: '#94a3b8', boxShadow: 'none',
                  },
                }}
              >
                {loading ? <CircularProgress size={20} sx={{ color: '#14b8a6' }} /> : t('login.loginButton')}
              </Button>
            </Box>
          </CardContent>
        </Card>

        {/* Footer */}
        <Typography sx={{
          color: '#94a3b8', fontSize: '0.72rem', mt: 3.5, letterSpacing: '0.01em',
          textAlign: 'center',
          animation: `${fadeInUp} 0.6s ease-out 0.4s both`,
        }}>
          CAR Police Station, Mangalore
        </Typography>
        <Typography sx={{
          color: '#cbd5e1', fontSize: '0.68rem', mt: 0.5,
          animation: `${fadeInUp} 0.6s ease-out 0.5s both`,
        }}>
          © 2026 {t('login.title')}. {t('login.allRightsReserved')}
        </Typography>
      </Box>
    </Box>
  );
};

export default LoginPage;

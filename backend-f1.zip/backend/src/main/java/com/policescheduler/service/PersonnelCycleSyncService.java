package com.policescheduler.service;

import com.policescheduler.entity.CycleDutyAssignment;
import com.policescheduler.entity.Personnel;
import com.policescheduler.entity.ScheduleCycle;
import com.policescheduler.entity.Section;
import com.policescheduler.repository.CycleDutyAssignmentRepository;
import com.policescheduler.repository.PersonnelRepository;
import com.policescheduler.repository.ScheduleCycleRepository;
import com.policescheduler.repository.SectionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Service responsible for synchronizing personnel records with cycle duty assignments.
 * 
 * Business Goal: The personnel table must always reflect the currently active cycle assignment.
 * Any screen that reads from personnel should automatically display the current operational state.
 */
@Service
public class PersonnelCycleSyncService {

    private static final Logger log = LoggerFactory.getLogger(PersonnelCycleSyncService.class);

    private final PersonnelRepository personnelRepository;
    private final CycleDutyAssignmentRepository cycleDutyAssignmentRepository;
    private final ScheduleCycleRepository scheduleCycleRepository;
    private final SectionRepository sectionRepository;

    public PersonnelCycleSyncService(PersonnelRepository personnelRepository,
                                     CycleDutyAssignmentRepository cycleDutyAssignmentRepository,
                                     ScheduleCycleRepository scheduleCycleRepository,
                                     SectionRepository sectionRepository) {
        this.personnelRepository = personnelRepository;
        this.cycleDutyAssignmentRepository = cycleDutyAssignmentRepository;
        this.scheduleCycleRepository = scheduleCycleRepository;
        this.sectionRepository = sectionRepository;
    }

    /**
     * Synchronizes personnel records after cycle creation.
     * ONLY updates personnel if the cycle is the currently active one
     * (today's date falls within the cycle's start and end date range).
     * 
     * If a future cycle is created in advance, personnel records remain
     * unchanged until that cycle becomes active. The login-time syncIfRequired()
     * will handle the transition when the cycle's start date arrives.
     * 
     * Called as part of the existing cycle creation flow.
     */
    @Transactional
    public void syncPersonnelForCycle(Long cycleId) {
        log.info("Checking if personnel sync is needed for cycle {}", cycleId);

        // Get the cycle
        ScheduleCycle cycle = scheduleCycleRepository.findById(cycleId).orElse(null);
        if (cycle == null) {
            log.warn("Cycle {} not found, skipping sync", cycleId);
            return;
        }

        // Only sync if today falls within this cycle's date range (it's the present/active cycle)
        LocalDate today = LocalDate.now();
        if (today.isBefore(cycle.getStartDate()) || today.isAfter(cycle.getEndDate())) {
            log.info("Cycle {} ({} to {}) is not the present cycle (today={}). " +
                    "Skipping personnel sync — will auto-sync when the cycle becomes active.",
                    cycleId, cycle.getStartDate(), cycle.getEndDate(), today);
            return;
        }

        log.info("Cycle {} is the present cycle, synchronizing personnel...", cycleId);

        // Get assignments for the first day of the cycle (canonical duty assignments)
        List<CycleDutyAssignment> assignments = cycleDutyAssignmentRepository
                .findByCycleIdAndDate(cycleId, cycle.getStartDate());

        if (assignments.isEmpty()) {
            log.warn("No assignments found for cycle {} on start date {}", cycleId, cycle.getStartDate());
            return;
        }

        // Build section code lookup: sectionId -> sectionCode
        Map<Long, String> sectionCodeMap = sectionRepository.findByIsActiveTrueOrderBySortOrder()
                .stream()
                .collect(Collectors.toMap(Section::getId, Section::getCode));

        // Update each personnel record
        int updatedCount = 0;
        for (CycleDutyAssignment assignment : assignments) {
            Personnel person = personnelRepository.findById(assignment.getPersonId()).orElse(null);
            if (person == null) continue;

            String sectionCode = sectionCodeMap.getOrDefault(assignment.getSectionId(), person.getSection());

            person.setCurrentCycleId(cycleId);
            person.setSection(sectionCode);
            person.setPlatoonId(assignment.getPlatoonId());
            // Use dutyName as the duty_type (this is the actual assigned duty from duty_types table)
            person.setDutyType(assignment.getDutyName());
            person.setDutyLocation(assignment.getDutyLocationField());
            person.setLocation(assignment.getLocation());
            personnelRepository.save(person);
            updatedCount++;
        }

        log.info("Synchronized {} personnel records for cycle {}", updatedCount, cycleId);
    }

    /**
     * Checks if personnel synchronization is needed and performs it if required.
     * Called after successful login.
     * 
     * Optimization: Only updates personnel where current_cycle_id != active_cycle_id or is NULL.
     */
    @Transactional
    public void syncIfRequired() {
        // 1. Determine the currently active cycle
        ScheduleCycle activeCycle = findActiveCycle();
        if (activeCycle == null) {
            log.debug("No active cycle found for current date, skipping sync");
            return;
        }

        Long activeCycleId = activeCycle.getId();

        // 2. Get participating operational sections (include_in_rotation = true)
        Set<String> rotatingSectionCodes = sectionRepository
                .findByIncludeInRotationTrueAndIsActiveTrueOrderByRotationOrder()
                .stream()
                .map(Section::getCode)
                .collect(Collectors.toSet());

        if (rotatingSectionCodes.isEmpty()) {
            log.debug("No rotating sections configured, skipping sync");
            return;
        }

        // 3. Check if any personnel in rotating sections are out of sync
        List<Personnel> outOfSyncPersonnel = personnelRepository.findByIsActiveTrue()
                .stream()
                .filter(p -> p.getSection() != null && rotatingSectionCodes.contains(p.getSection()))
                .filter(p -> p.getCurrentCycleId() == null || !p.getCurrentCycleId().equals(activeCycleId))
                .collect(Collectors.toList());

        if (outOfSyncPersonnel.isEmpty()) {
            log.debug("All personnel already synced with active cycle {}", activeCycleId);
            return;
        }

        log.info("Found {} personnel out of sync with active cycle {}, synchronizing...",
                outOfSyncPersonnel.size(), activeCycleId);

        // 4. Get assignments for the active cycle (first day)
        List<CycleDutyAssignment> assignments = cycleDutyAssignmentRepository
                .findByCycleIdAndDate(activeCycleId, activeCycle.getStartDate());

        if (assignments.isEmpty()) {
            log.warn("No assignments found for active cycle {} on start date {}", activeCycleId, activeCycle.getStartDate());
            return;
        }

        // Build lookup: personId -> assignment
        Map<Long, CycleDutyAssignment> assignmentByPerson = assignments.stream()
                .collect(Collectors.toMap(
                        CycleDutyAssignment::getPersonId,
                        a -> a,
                        (a1, a2) -> a1 // in case of duplicates, take first
                ));

        // Build section code lookup
        Map<Long, String> sectionCodeMap = sectionRepository.findByIsActiveTrueOrderBySortOrder()
                .stream()
                .collect(Collectors.toMap(Section::getId, Section::getCode));

        // 5. Update only out-of-sync personnel
        int updatedCount = 0;
        for (Personnel person : outOfSyncPersonnel) {
            CycleDutyAssignment assignment = assignmentByPerson.get(person.getId());
            if (assignment == null) {
                // Person is in a rotating section but has no assignment in this cycle
                // Just update the cycle_id to mark as checked
                continue;
            }

            String sectionCode = sectionCodeMap.getOrDefault(assignment.getSectionId(), person.getSection());

            person.setCurrentCycleId(activeCycleId);
            person.setSection(sectionCode);
            person.setPlatoonId(assignment.getPlatoonId());
            // Use dutyName as the duty_type (this is the actual assigned duty from duty_types table)
            person.setDutyType(assignment.getDutyName());
            person.setDutyLocation(assignment.getDutyLocationField());
            person.setLocation(assignment.getLocation());
            personnelRepository.save(person);
            updatedCount++;
        }

        log.info("Synchronized {} personnel records to active cycle {}", updatedCount, activeCycleId);
    }

    /**
     * Finds the currently active cycle based on today's date.
     * Active cycle = cycle whose date range contains today and status is ACTIVE.
     */
    private ScheduleCycle findActiveCycle() {
        LocalDate today = LocalDate.now();
        List<ScheduleCycle> overlapping = scheduleCycleRepository
                .findOverlappingActiveCycles(today, today);
        if (overlapping.isEmpty()) {
            return null;
        }
        // Return the first one (should be only one active for today)
        return overlapping.get(0);
    }
}

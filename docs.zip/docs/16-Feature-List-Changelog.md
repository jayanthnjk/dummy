# Feature List & Changelog
## KSP WorkBoard v1.0.0

| Field | Details |
|-------|---------|
| **Version** | 1.0.0 (Initial Release) |
| **Date** | June 2026 |

---

## Complete Feature List

### Authentication & Security
- [x] JWT-based login with username/password
- [x] Three user roles: ADMIN, HIGHER_OFFICER, GENERAL_USER
- [x] Role-based endpoint access control (@PreAuthorize)
- [x] Method-level security on sensitive operations
- [x] BCrypt password hashing
- [x] Password change functionality
- [x] Token expiry (configurable, default 24h)
- [x] Auto-logout on inactivity (frontend dialog)
- [x] CORS configuration (configurable origins)
- [x] CSRF disabled (stateless JWT)
- [x] PII access logging filter
- [x] Prompt injection detection on chat inputs
- [x] Rate limiting (30 general / 20 LLM per user)

### Personnel Management
- [x] Create personnel with validation (badge uniqueness, driver fields)
- [x] Read personnel (list with pagination, search, multi-filter)
- [x] Update personnel (partial update support)
- [x] Delete personnel (ADMIN only, hard-delete)
- [x] Profile view per badge ID
- [x] Full-text search across 8 fields
- [x] Filter by section, designation, duty type, active status
- [x] Sort by any column
- [x] Driver-specific validation (vehicle, PDMS, licence required)
- [x] Active/inactive status management

### Platoon Cycle Management
- [x] Create rotation cycle (start date + rotation days + platoon-section mappings)
- [x] Auto-calculate end date
- [x] Overlap prevention (blocks overlapping ACTIVE cycles)
- [x] Auto-generate platoon-section mappings (circular shift +1)
- [x] Next available date calculation
- [x] Partial update (PATCH) — only non-null fields
- [x] Full update (PUT) — complete replacement
- [x] Soft-delete (status → DELETED)
- [x] List with status filter
- [x] Cycle detail view with platoon mappings

### Duty Assignment Engine
- [x] Auto-generate daily assignments on cycle creation
- [x] Three-shift rotation (DAY/AFTERNOON/NIGHT)
- [x] Personnel divided into 3 groups (A/B/C)
- [x] No same shift on consecutive days guarantee
- [x] Manual reassignment with validation
- [x] Auto-reassignment from other platoons
- [x] Leave conflict check before reassignment
- [x] Duplicate assignment prevention
- [x] Override flag tracking
- [x] Assignment range query (for calendar views)
- [x] Available personnel lookup for reassignment

### Leave Management
- [x] Submit leave request (5 leave types)
- [x] Overlap detection (prevents duplicate leaves)
- [x] Duty conflict detection and reporting
- [x] Approve leave (ADMIN/HIGHER_OFFICER)
- [x] Reject leave with reason
- [x] Cancel leave (with date validation)
- [x] Role-based visibility (GENERAL_USER sees own only)
- [x] Filter by status, type, personnel, date range
- [x] Paginated listing

### Adhoc/Special Duty Management
- [x] Create adhoc duty with auto-assignment
- [x] Personnel auto-selection (respects leave/conflicts)
- [x] Preview available personnel before creation
- [x] ALL_PLATOONS or SPECIFIC_PLATOONS pick strategy
- [x] Minimum strength check
- [x] Cancel duty (releases personnel)
- [x] List with date/status filter
- [x] PDF report per duty
- [x] Excel report per duty

### AI Chat Interface
- [x] Natural language processing (English, Kannada, Hindi, mixed)
- [x] LLM function calling with 37 registered tools
- [x] MCP architecture (5 servers)
- [x] Structured responses (table, form, confirmation, suggestions)
- [x] Voice input via STT (Groq Whisper)
- [x] PDF document upload and RAG
- [x] Form submission through chat
- [x] Badge ID normalization (AHC 2649 → AHC-2649)
- [x] Name-based person lookup
- [x] Designation vs badge distinction
- [x] Direct response for greetings/clarifications
- [x] Fallback suggestions for unknown queries
- [x] Circuit breaker on LLM/STT failures
- [x] Response caching with domain invalidation
- [x] Chat history persistence
- [x] Rate limiting

### Report Generation
- [x] Platoon Chart (PDF + Excel)
- [x] Form 168 Daily Statement (PDF + Excel)
- [x] Section A Report (PDF + Excel)
- [x] Section B Report (PDF + Excel)
- [x] Section A&B Combined (PDF)
- [x] MT Section/Drivers (PDF + Excel)
- [x] Leave Statement (PDF + Excel)
- [x] Personnel List (PDF, filterable)
- [x] Schedule Report (PDF)
- [x] Adhoc Duty Report (PDF + Excel per duty)
- [x] Locale-aware (en/kn parameter)
- [x] Date-parameterized reports
- [x] Download by file ID (stored reports)

### Schedule Visualization
- [x] Section overview (A + B + C)
- [x] Section-specific views
- [x] Platoon rotation display
- [x] Rotation management page
- [x] Cycle management page
- [x] Activities/audit log page
- [x] Adhoc duty page

### Administration
- [x] Duty type CRUD with geolocation (Leaflet maps)
- [x] Hierarchical duty types (parent-child)
- [x] Section management (CRUD)
- [x] Bulk duty type reassignment between sections
- [x] System configuration (key-value admin settings)
- [x] Holiday management (CRUD)
- [x] Translation management (upsert, find missing)
- [x] Support ticket system (submit, respond, status)

### Internationalization
- [x] English (en) — 100% coverage
- [x] Kannada (kn) — 100% coverage
- [x] Server-side translation table
- [x] Frontend i18next integration
- [x] Chat language auto-detection
- [x] Response in detected language

### Infrastructure & Resilience
- [x] Dual AI provider support (Groq dev + Bedrock prod)
- [x] Circuit breaker pattern (Resilience4j)
- [x] In-memory caching (Caffeine, 500 entries, 60s TTL)
- [x] Graceful fallbacks on service failures
- [x] Audit trail (immutable cycle audit log)
- [x] systemd service management
- [x] AWS deployment scripts (EC2 + S3 + CloudFront)
- [x] Health check endpoints (system + AI)

---

## Changelog

### v1.0.0 — June 2026 (Initial Release)
- Complete system implementation from scratch
- All 12 modules fully functional
- 86 API endpoints
- 22 database tables
- 37 AI chat tools
- 14 frontend pages
- Production deployed on AWS

---

*End of Document — Feature List v1.0.0*

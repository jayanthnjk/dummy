import React, { useState } from 'react';
import { observer } from 'mobx-react-lite';
import {
  Box,
  Card,
  CardActionArea,
  Typography,
  Menu,
  MenuItem,
  ListItemIcon,
  ListItemText,
  Stack,
} from '@mui/material';
import SecurityIcon from '@mui/icons-material/Security';
import LocalPoliceIcon from '@mui/icons-material/LocalPolice';
import ShieldIcon from '@mui/icons-material/Shield';
import MilitaryTechIcon from '@mui/icons-material/MilitaryTech';
import GavelIcon from '@mui/icons-material/Gavel';
import AssignmentIndIcon from '@mui/icons-material/AssignmentInd';
import DirectionsCarIcon from '@mui/icons-material/DirectionsCar';
import GroupsIcon from '@mui/icons-material/Groups';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import SwapHorizIcon from '@mui/icons-material/SwapHoriz';
import InboxIcon from '@mui/icons-material/Inbox';
import { useTranslation } from 'react-i18next';
import { dutySectionStore } from '@/stores/dutySectionStore';

// Cycling icon set for duty type cards
const CARD_ICONS = [
  SecurityIcon,
  LocalPoliceIcon,
  ShieldIcon,
  MilitaryTechIcon,
  GavelIcon,
  AssignmentIndIcon,
  DirectionsCarIcon,
  GroupsIcon,
];

// Predefined palette of pastel/muted background colors
const CARD_COLORS = [
  '#E3F2FD', // light blue
  '#E8F5E9', // light green
  '#FFF3E0', // light orange
  '#F3E5F5', // light purple
  '#E0F7FA', // light cyan
  '#FBE9E7', // light deep orange
  '#E8EAF6', // light indigo
  '#F1F8E9', // light lime
  '#FCE4EC', // light pink
  '#FFFDE7', // light yellow
];

export interface DutyTypeCardsProps {
  onAddDutyType: () => void;
  onEditDutyType: (id: number) => void;
  onReassignDutyType: (id: number) => void;
}

const DutyTypeCards: React.FC<DutyTypeCardsProps> = observer(
  ({ onAddDutyType, onEditDutyType, onReassignDutyType }) => {
    const { t } = useTranslation();
    const { filteredDutyTypes, selectedDutyTypeId } = dutySectionStore;

    // Context menu state
    const [contextMenu, setContextMenu] = useState<{
      mouseX: number;
      mouseY: number;
      dutyTypeId: number;
    } | null>(null);

    const handleCardClick = (id: number) => {
      // Toggle selection: if already selected, deselect
      if (selectedDutyTypeId === id) {
        dutySectionStore.selectDutyType(null);
      } else {
        dutySectionStore.selectDutyType(id);
      }
    };

    const handleContextMenu = (event: React.MouseEvent, dutyTypeId: number) => {
      event.preventDefault();
      setContextMenu({
        mouseX: event.clientX + 2,
        mouseY: event.clientY - 6,
        dutyTypeId,
      });
    };

    const handleContextMenuClose = () => {
      setContextMenu(null);
    };

    const handleEdit = () => {
      if (contextMenu) {
        onEditDutyType(contextMenu.dutyTypeId);
      }
      handleContextMenuClose();
    };

    const handleReassign = () => {
      if (contextMenu) {
        onReassignDutyType(contextMenu.dutyTypeId);
      }
      handleContextMenuClose();
    };

    // Sort by sortOrder ASC
    const sortedDutyTypes = [...filteredDutyTypes].sort(
      (a, b) => a.sortOrder - b.sortOrder
    );

    // Empty state
    if (sortedDutyTypes.length === 0) {
      return (
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            py: 4,
            gap: 1,
          }}
        >
          <InboxIcon sx={{ fontSize: 48, color: 'text.disabled' }} />
          <Typography variant="body1" color="text.secondary">
            {t(
              'admin.dutySections.noDutyTypes',
              'No duty types found for this section.'
            )}
          </Typography>
          <Typography variant="body2" color="text.disabled">
            {t(
              'admin.dutySections.addDutyTypePrompt',
              'Click "Add Duty Type" to create one.'
            )}
          </Typography>
        </Box>
      );
    }

    return (
      <>
        <Stack
          direction="row"
          spacing={1.5}
          sx={{
            overflowX: 'auto',
            py: 1.5,
            px: 0.5,
            '&::-webkit-scrollbar': {
              height: 6,
            },
            '&::-webkit-scrollbar-thumb': {
              backgroundColor: 'action.disabled',
              borderRadius: 3,
            },
          }}
        >
          {sortedDutyTypes.map((dutyType, index) => {
            const IconComponent = CARD_ICONS[index % CARD_ICONS.length];
            const bgColor = CARD_COLORS[index % CARD_COLORS.length];
            const isSelected = selectedDutyTypeId === dutyType.id;

            return (
              <Card
                key={dutyType.id}
                elevation={isSelected ? 6 : 1}
                onContextMenu={(e) => handleContextMenu(e, dutyType.id)}
                sx={{
                  minWidth: 160,
                  flexShrink: 0,
                  backgroundColor: bgColor,
                  border: isSelected ? 2 : 1,
                  borderColor: isSelected ? 'primary.main' : 'divider',
                  borderRadius: 2,
                  transition: 'all 0.2s ease-in-out',
                  '&:hover': {
                    elevation: 4,
                    transform: 'translateY(-1px)',
                  },
                }}
              >
                <CardActionArea
                  onClick={() => handleCardClick(dutyType.id)}
                  sx={{ px: 2, py: 1.5 }}
                >
                  <Stack direction="row" spacing={1} alignItems="center">
                    <IconComponent
                      sx={{
                        fontSize: 24,
                        color: isSelected ? 'primary.main' : 'text.secondary',
                      }}
                    />
                    <Typography
                      variant="body2"
                      fontWeight={isSelected ? 'bold' : 'medium'}
                      noWrap
                      sx={{ maxWidth: 140 }}
                    >
                      {dutyType.name}
                    </Typography>
                  </Stack>
                </CardActionArea>
              </Card>
            );
          })}

          {/* Add Duty Type card */}
          <Card
            elevation={0}
            sx={{
              minWidth: 160,
              flexShrink: 0,
              border: '2px dashed',
              borderColor: 'action.disabled',
              borderRadius: 2,
              backgroundColor: 'transparent',
              '&:hover': {
                borderColor: 'primary.main',
                backgroundColor: 'action.hover',
              },
            }}
          >
            <CardActionArea
              onClick={onAddDutyType}
              sx={{ px: 2, py: 1.5 }}
            >
              <Stack direction="row" spacing={1} alignItems="center">
                <AddIcon sx={{ fontSize: 24, color: 'primary.main' }} />
                <Typography variant="body2" color="primary" fontWeight="medium">
                  {t('admin.dutySections.addDutyType', 'Add Duty Type')}
                </Typography>
              </Stack>
            </CardActionArea>
          </Card>
        </Stack>

        {/* Context menu */}
        <Menu
          open={contextMenu !== null}
          onClose={handleContextMenuClose}
          anchorReference="anchorPosition"
          anchorPosition={
            contextMenu !== null
              ? { top: contextMenu.mouseY, left: contextMenu.mouseX }
              : undefined
          }
        >
          <MenuItem onClick={handleEdit}>
            <ListItemIcon>
              <EditIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText>
              {t('admin.dutySections.editDutyType', 'Edit')}
            </ListItemText>
          </MenuItem>
          <MenuItem onClick={handleReassign}>
            <ListItemIcon>
              <SwapHorizIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText>
              {t('admin.dutySections.reassignDutyType', 'Reassign')}
            </ListItemText>
          </MenuItem>
        </Menu>
      </>
    );
  }
);

export default DutyTypeCards;

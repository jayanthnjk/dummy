package com.policescheduler.report.generator;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.PageSize;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.policescheduler.entity.CyclePlatoonSection;
import com.policescheduler.entity.Personnel;
import com.policescheduler.entity.Platoon;
import com.policescheduler.entity.PlatoonQrtAssignment;
import com.policescheduler.entity.PlatoonRotationState;
import com.policescheduler.entity.ScheduleCycle;
import com.policescheduler.entity.Section;
import com.policescheduler.report.PdfReportGenerator;
import com.policescheduler.report.PdfStyleHelper;
import com.policescheduler.report.ReportGenerationException;
import com.policescheduler.report.ReportLocalizationService;
import com.policescheduler.report.ReportRequest;
import com.policescheduler.repository.CyclePlatoonSectionRepository;
import com.policescheduler.repository.DutyTypeRepository;
import com.policescheduler.repository.PersonnelRepository;
import com.policescheduler.repository.PlatoonQrtAssignmentRepository;
import com.policescheduler.repository.PlatoonRepository;
import com.policescheduler.repository.PlatoonRotationStateRepository;
import com.policescheduler.repository.ScheduleCycleRepository;
import com.policescheduler.repository.SectionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class PlatoonChartReportGenerator implements PdfReportGenerator {

    private static final Logger log = LoggerFactory.getLogger(PlatoonChartReportGenerator.class);
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    // Section codes mapped to duty columns (order matches desired report)
    static final List<String> ALL_SECTIONS = List.of("C", "F", "D", "G", "E");

    // Column headers matching desired report order
    static final List<String> DUTY_COLUMNS = List.of(
            "GUARD-I", "PRISON / VIP ESCORT/OUT", "GUARD-II", "STRIKING FORCE/HELP", "CHECK POINT"
    );

    private static final Color HEADER_BG = new Color(211, 211, 211);
    private static final Font HEADER_FONT = new Font(Font.HELVETICA, 8, Font.BOLD, Color.BLACK);
    private static final Font CELL_FONT = new Font(Font.HELVETICA, 7.5f, Font.NORMAL, Color.BLACK);
    private static final Font QRT_FONT = new Font(Font.HELVETICA, 7.5f, Font.BOLD, Color.RED);
    private static final Font PLATOON_FONT = new Font(Font.HELVETICA, 8, Font.BOLD, Color.BLACK);
    private static final Font TITLE_FONT = new Font(Font.HELVETICA, 12, Font.BOLD, Color.BLACK);
    private static final Font DATE_FONT = new Font(Font.HELVETICA, 8, Font.BOLD, Color.BLACK);

    private static final int NUM_ROTATION_PERIODS = 5;
    private static final int ROTATION_DAYS = 15;

    private final PersonnelRepository personnelRepository;
    private final PlatoonRepository platoonRepository;
    private final PlatoonRotationStateRepository rotationStateRepository;
    private final DutyTypeRepository dutyTypeRepository;
    private final ScheduleCycleRepository scheduleCycleRepository;
    private final CyclePlatoonSectionRepository cyclePlatoonSectionRepository;
    private final SectionRepository sectionRepository;
    private final PlatoonQrtAssignmentRepository qrtAssignmentRepository;
    private final PdfStyleHelper pdfStyleHelper;
    private final ReportLocalizationService localizationService;
    private final com.policescheduler.service.ReassignmentResolverService reassignmentResolverService;

    public PlatoonChartReportGenerator(PersonnelRepository personnelRepository,
                                        PlatoonRepository platoonRepository,
                                        PlatoonRotationStateRepository rotationStateRepository,
                                        DutyTypeRepository dutyTypeRepository,
                                        ScheduleCycleRepository scheduleCycleRepository,
                                        CyclePlatoonSectionRepository cyclePlatoonSectionRepository,
                                        SectionRepository sectionRepository,
                                        PlatoonQrtAssignmentRepository qrtAssignmentRepository,
                                        PdfStyleHelper pdfStyleHelper,
                                        ReportLocalizationService localizationService,
                                        com.policescheduler.service.ReassignmentResolverService reassignmentResolverService) {
        this.personnelRepository = personnelRepository;
        this.platoonRepository = platoonRepository;
        this.rotationStateRepository = rotationStateRepository;
        this.dutyTypeRepository = dutyTypeRepository;
        this.scheduleCycleRepository = scheduleCycleRepository;
        this.cyclePlatoonSectionRepository = cyclePlatoonSectionRepository;
        this.sectionRepository = sectionRepository;
        this.qrtAssignmentRepository = qrtAssignmentRepository;
        this.pdfStyleHelper = pdfStyleHelper;
        this.localizationService = localizationService;
        this.reassignmentResolverService = reassignmentResolverService;
    }

    @Override
    public String getReportType() {
        return "platoon_chart";
    }

    @Override
    public byte[] generate(ReportRequest request) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            Document document = new Document(PageSize.A4.rotate(), 5, 5, 5, 5);
            PdfWriter.getInstance(document, baos);
            document.open();

            String locale = request.getLocale() != null ? request.getLocale() : "en";

            PlatoonRotationState state = rotationStateRepository.findAll().stream()
                    .findFirst().orElse(null);
            List<Platoon> platoons = platoonRepository.findAllByOrderByBaseOffsetAsc();
            List<Personnel> allPersonnel = personnelRepository.findAll().stream()
                    .filter(p -> p.getIsActive() != null && p.getIsActive())
                    .filter(p -> p.getPlatoonId() != null)
                    .filter(p -> ALL_SECTIONS.contains(p.getSection()))
                    .collect(Collectors.toList());

            // Apply reassignment resolution per section
            List<Personnel> resolvedPersonnel = new ArrayList<>();
            for (String sec : ALL_SECTIONS) {
                List<Personnel> secPersonnel = allPersonnel.stream()
                        .filter(p -> sec.equals(p.getSection()))
                        .collect(Collectors.toList());
                resolvedPersonnel.addAll(reassignmentResolverService.resolveForSection(secPersonnel, sec, java.time.LocalDate.now()));
            }
            allPersonnel = resolvedPersonnel;

            // Load QRT assignments
            List<PlatoonQrtAssignment> qrtAssignments = qrtAssignmentRepository.findByIsActiveTrue();
            Map<Long, Personnel> personnelById = personnelRepository.findAll().stream()
                    .collect(Collectors.toMap(Personnel::getId, p -> p, (a, b) -> a));

            generateCombinedGrid(document, locale, allPersonnel, platoons, state, qrtAssignments, personnelById);

            document.close();
            return baos.toByteArray();
        } catch (Exception e) {
            log.error("Failed to generate platoon chart report", e);
            throw new ReportGenerationException("platoon_chart", "Failed to generate platoon chart report", e);
        }
    }

    private void generateCombinedGrid(Document document, String locale,
                                       List<Personnel> allPersonnel,
                                       List<Platoon> platoons,
                                       PlatoonRotationState state,
                                       List<PlatoonQrtAssignment> qrtAssignments,
                                       Map<Long, Personnel> personnelById) throws DocumentException {

        // Compute strength per platoon
        Map<Long, long[]> platoonStrength = new HashMap<>();
        for (Platoon p : platoons) {
            long ahc = allPersonnel.stream()
                    .filter(per -> p.getId().equals(per.getPlatoonId()) && "AHC".equals(per.getDesignation()))
                    .count();
            long apc = allPersonnel.stream()
                    .filter(per -> p.getId().equals(per.getPlatoonId()) && "APC".equals(per.getDesignation()))
                    .count();
            platoonStrength.put(p.getId(), new long[]{ahc, apc, ahc + apc});
        }

        // Build QRT data per platoon
        Map<Long, List<Personnel>> qrtPrimaryByPlatoon = new HashMap<>();
        Map<Long, List<Personnel>> qrtSecondaryByPlatoon = new HashMap<>();
        for (PlatoonQrtAssignment qrt : qrtAssignments) {
            Personnel p = personnelById.get(qrt.getPersonnelId());
            if (p == null) continue;
            if ("PRIMARY".equals(qrt.getQrtGroup())) {
                qrtPrimaryByPlatoon.computeIfAbsent(qrt.getPlatoonId(), k -> new ArrayList<>()).add(p);
            } else {
                qrtSecondaryByPlatoon.computeIfAbsent(qrt.getPlatoonId(), k -> new ArrayList<>()).add(p);
            }
        }

        Map<Long, Integer> sectionIdToDutyIndex = buildSectionIdToDutyIndexMap();

        // Load schedule cycles
        List<ScheduleCycle> allCycles = scheduleCycleRepository.findByStatusNotOrderByStartDateDesc("DELETED");
        Collections.reverse(allCycles);

        List<ScheduleCycle> displayCycles;
        int currentCycleIndexInWindow;

        if (allCycles.isEmpty()) {
            displayCycles = null;
            currentCycleIndexInWindow = 0;
        } else {
            LocalDate today = LocalDate.now();
            int currentIdx = -1;
            for (int i = 0; i < allCycles.size(); i++) {
                ScheduleCycle c = allCycles.get(i);
                if (!today.isBefore(c.getStartDate()) && !today.isAfter(c.getEndDate())) {
                    currentIdx = i;
                    break;
                }
            }
            if (currentIdx == -1) {
                for (int i = 0; i < allCycles.size(); i++) {
                    if (allCycles.get(i).getStartDate().isAfter(today)) {
                        currentIdx = i;
                        break;
                    }
                }
            }
            if (currentIdx == -1) {
                currentIdx = allCycles.size() - 1;
            }

            int windowStart = currentIdx - 2;
            int windowEnd = currentIdx + 2;
            if (windowStart < 0) {
                windowEnd = Math.min(allCycles.size() - 1, windowEnd + (-windowStart));
                windowStart = 0;
            }
            if (windowEnd >= allCycles.size()) {
                windowStart = Math.max(0, windowStart - (windowEnd - allCycles.size() + 1));
                windowEnd = allCycles.size() - 1;
            }

            displayCycles = allCycles.subList(windowStart, Math.min(windowEnd + 1, allCycles.size()));
            currentCycleIndexInWindow = currentIdx - windowStart;
        }

        int currentCycle = state != null ? state.getCurrentCycleIndex() : 0;

        // 11 columns: DATE + (platoon_label + badge_ids) * 5
        float[] widths = {7f, 4f, 15f, 4f, 15f, 4f, 15f, 4f, 15f, 4f, 15f};
        PdfPTable table = new PdfPTable(11);
        table.setWidthPercentage(100);
        table.setWidths(widths);

        // Title row
        PdfPCell titleCell = new PdfPCell(new Phrase("SECTION C", TITLE_FONT));
        titleCell.setColspan(11);
        titleCell.setBackgroundColor(HEADER_BG);
        titleCell.setPadding(4);
        titleCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(titleCell);

        // Header row 1: DATE + duty column names
        PdfPCell dateHeader = new PdfPCell(new Phrase("DATE", HEADER_FONT));
        dateHeader.setBackgroundColor(HEADER_BG);
        dateHeader.setPadding(2);
        dateHeader.setRowspan(2);
        dateHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
        dateHeader.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table.addCell(dateHeader);

        for (int dutyIdx = 0; dutyIdx < DUTY_COLUMNS.size(); dutyIdx++) {
            PdfPCell cell = new PdfPCell(new Phrase(DUTY_COLUMNS.get(dutyIdx), HEADER_FONT));
            cell.setColspan(2);
            cell.setBackgroundColor(HEADER_BG);
            cell.setPadding(2);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            table.addCell(cell);
        }

        // Header row 2: strength counts
        Map<Integer, Long> strengthDutyToPlatoon = null;
        if (displayCycles != null && currentCycleIndexInWindow < displayCycles.size()) {
            ScheduleCycle currentDisplayCycle = displayCycles.get(currentCycleIndexInWindow);
            strengthDutyToPlatoon = buildDutyToPlatoonMap(currentDisplayCycle.getId(), sectionIdToDutyIndex);
        }

        for (int dutyIdx = 0; dutyIdx < DUTY_COLUMNS.size(); dutyIdx++) {
            Long platoonAtDuty = null;
            if (strengthDutyToPlatoon != null && strengthDutyToPlatoon.containsKey(dutyIdx)) {
                platoonAtDuty = strengthDutyToPlatoon.get(dutyIdx);
            } else {
                for (Platoon p : platoons) {
                    int idx = (p.getBaseOffset() + currentCycle) % 5;
                    if (idx == dutyIdx) {
                        platoonAtDuty = p.getId();
                        break;
                    }
                }
            }

            long ahc = 0, apc = 0, total = 0;
            if (platoonAtDuty != null && platoonStrength.containsKey(platoonAtDuty)) {
                long[] s = platoonStrength.get(platoonAtDuty);
                ahc = s[0]; apc = s[1]; total = s[2];
            }

            String countText = String.format("%02d AHC, %d APC, TOTAL=%d", ahc, apc, total);
            PdfPCell cell = new PdfPCell(new Phrase(countText, HEADER_FONT));
            cell.setColspan(2);
            cell.setBackgroundColor(HEADER_BG);
            cell.setPadding(2);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            table.addCell(cell);
        }

        // Data rows
        if (displayCycles != null) {
            for (int period = 0; period < displayCycles.size(); period++) {
                ScheduleCycle cycle = displayCycles.get(period);
                int cycleIndexInFullList = allCycles.indexOf(cycle);

                String dateRange = cycle.getStartDate().format(DATE_FORMAT)
                        + "\nTO\n" + cycle.getEndDate().format(DATE_FORMAT);

                PdfPCell dateCell = new PdfPCell(new Phrase(dateRange, DATE_FONT));
                dateCell.setPadding(2);
                dateCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                dateCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                dateCell.setRotation(90);
                table.addCell(dateCell);

                Map<Integer, Long> dutyToPlatoon = buildDutyToPlatoonMap(cycle.getId(), sectionIdToDutyIndex);

                for (int dutyIdx = 0; dutyIdx < DUTY_COLUMNS.size(); dutyIdx++) {
                    String platoonLabel = "";
                    Long platoonId = dutyToPlatoon.get(dutyIdx);

                    if (platoonId == null) {
                        // Fallback to rotation math
                        for (Platoon p : platoons) {
                            int idx = (p.getBaseOffset() + cycleIndexInFullList) % 5;
                            if (idx == dutyIdx) {
                                platoonId = p.getId();
                                break;
                            }
                        }
                    }

                    Platoon matchedPlatoon = null;
                    if (platoonId != null) {
                        Long pid = platoonId;
                        matchedPlatoon = platoons.stream()
                                .filter(p -> p.getId().equals(pid))
                                .findFirst().orElse(null);
                    }

                    if (matchedPlatoon != null) {
                        platoonLabel = "PLATOON-" + matchedPlatoon.getName().replace("Platoon ", "");
                    }

                    // Platoon label cell (rotated)
                    PdfPCell platoonCell = new PdfPCell(new Phrase(platoonLabel, PLATOON_FONT));
                    platoonCell.setPadding(1);
                    platoonCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                    platoonCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                    platoonCell.setRotation(90);
                    table.addCell(platoonCell);

                    // Badge IDs cell with QRT in bold red
                    PdfPCell badgeCell = buildBadgeCellWithQrt(
                            platoonId, allPersonnel, qrtPrimaryByPlatoon, qrtSecondaryByPlatoon);
                    table.addCell(badgeCell);
                }
            }
        } else {
            // Fallback: no cycles in DB
            LocalDate anchorStart = state != null && state.getLastRotationDate() != null
                    ? state.getLastRotationDate() : LocalDate.now();

            for (int period = 0; period < NUM_ROTATION_PERIODS; period++) {
                int cycleForPeriod = currentCycle + period;

                LocalDate periodStart = anchorStart.plusDays((long) period * ROTATION_DAYS);
                LocalDate periodEnd = periodStart.plusDays(ROTATION_DAYS);
                String dateRange = periodStart.format(DATE_FORMAT) + "\nTO\n" + periodEnd.format(DATE_FORMAT);

                PdfPCell dateCell = new PdfPCell(new Phrase(dateRange, DATE_FONT));
                dateCell.setPadding(2);
                dateCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                dateCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                dateCell.setRotation(90);
                table.addCell(dateCell);

                for (int dutyIdx = 0; dutyIdx < DUTY_COLUMNS.size(); dutyIdx++) {
                    String platoonLabel = "";
                    Long platoonId = null;

                    for (Platoon p : platoons) {
                        int idx = (p.getBaseOffset() + cycleForPeriod) % 5;
                        if (idx == dutyIdx) {
                            platoonId = p.getId();
                            platoonLabel = "PLATOON-" + p.getName().replace("Platoon ", "");
                            break;
                        }
                    }

                    PdfPCell platoonCell = new PdfPCell(new Phrase(platoonLabel, PLATOON_FONT));
                    platoonCell.setPadding(1);
                    platoonCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                    platoonCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                    platoonCell.setRotation(90);
                    table.addCell(platoonCell);

                    PdfPCell badgeCell = buildBadgeCellWithQrt(
                            platoonId, allPersonnel, qrtPrimaryByPlatoon, qrtSecondaryByPlatoon);
                    table.addCell(badgeCell);
                }
            }
        }

        document.add(table);
    }

    /**
     * Builds a PDF cell containing badge IDs + QRT lines in bold red.
     */
    private PdfPCell buildBadgeCellWithQrt(Long platoonId, List<Personnel> allPersonnel,
                                            Map<Long, List<Personnel>> qrtPrimary,
                                            Map<Long, List<Personnel>> qrtSecondary) {
        Phrase phrase = new Phrase();
        phrase.setLeading(10f); // Line spacing for readability

        if (platoonId != null) {
            List<Personnel> platoonPersonnel = allPersonnel.stream()
                    .filter(per -> platoonId.equals(per.getPlatoonId()))
                    .collect(Collectors.toList());

            if (!platoonPersonnel.isEmpty()) {
                phrase.add(new com.lowagie.text.Chunk(formatBadgeIds(platoonPersonnel), CELL_FONT));
            }

            // Add QRT PRIMARY line
            List<Personnel> primaryQrt = qrtPrimary.getOrDefault(platoonId, Collections.emptyList());
            if (!primaryQrt.isEmpty()) {
                phrase.add(new com.lowagie.text.Chunk("\n\nQRT: " + formatBadgeIds(primaryQrt), QRT_FONT));
            }

            // Add QRT SECONDARY line
            List<Personnel> secondaryQrt = qrtSecondary.getOrDefault(platoonId, Collections.emptyList());
            if (!secondaryQrt.isEmpty()) {
                phrase.add(new com.lowagie.text.Chunk("\nQRT : " + formatBadgeIds(secondaryQrt), QRT_FONT));
            }
        }

        PdfPCell cell = new PdfPCell(phrase);
        cell.setPadding(4);
        cell.setVerticalAlignment(Element.ALIGN_TOP);
        return cell;
    }

    /**
     * Builds a map from section ID to duty column index based on the desired column order.
     * Order: C=0 (GUARD-I), F=1 (PRISON/VIP), D=2 (GUARD-II), G=3 (STRIKING), E=4 (CHECK POINT)
     */
    private Map<Long, Integer> buildSectionIdToDutyIndexMap() {
        Map<Long, Integer> map = new HashMap<>();
        for (int i = 0; i < ALL_SECTIONS.size(); i++) {
            String sectionCode = ALL_SECTIONS.get(i);
            Optional<Section> section = sectionRepository.findByCode(sectionCode);
            if (section.isPresent()) {
                map.put(section.get().getId(), i);
            }
        }
        return map;
    }

    private Map<Integer, Long> buildDutyToPlatoonMap(Long cycleId, Map<Long, Integer> sectionIdToDutyIndex) {
        Map<Integer, Long> dutyToPlatoon = new HashMap<>();
        List<CyclePlatoonSection> mappings = cyclePlatoonSectionRepository.findByCycleId(cycleId);
        for (CyclePlatoonSection mapping : mappings) {
            Integer dutyIdx = sectionIdToDutyIndex.get(mapping.getSectionId());
            if (dutyIdx != null) {
                dutyToPlatoon.put(dutyIdx, mapping.getPlatoonId());
            }
        }
        return dutyToPlatoon;
    }

    String formatBadgeIds(List<Personnel> personnel) {
        StringBuilder sb = new StringBuilder();

        List<Personnel> ahcList = personnel.stream()
                .filter(p -> "AHC".equals(p.getDesignation()))
                .collect(Collectors.toList());
        List<Personnel> apcList = personnel.stream()
                .filter(p -> "APC".equals(p.getDesignation()))
                .collect(Collectors.toList());

        if (!ahcList.isEmpty()) {
            sb.append("AHC-");
            sb.append(ahcList.stream()
                    .map(p -> extractBadgeNumber(p.getBadgeId()))
                    .collect(Collectors.joining(", ")));
        }

        if (!apcList.isEmpty()) {
            if (sb.length() > 0) sb.append(" ");
            sb.append("APC-");
            sb.append(apcList.stream()
                    .map(p -> extractBadgeNumber(p.getBadgeId()))
                    .collect(Collectors.joining(", ")));
        }

        return sb.toString();
    }

    String extractBadgeNumber(String badgeId) {
        if (badgeId != null && badgeId.contains("-")) {
            return badgeId.substring(badgeId.lastIndexOf('-') + 1);
        }
        return badgeId != null ? badgeId : "";
    }
}

import api from './api';
import type { LeaveRequestDto, CreateLeaveRequest, LeaveFilter, Page } from '@/types';

export const leaveService = {
  list: (filter?: LeaveFilter, page = 0, size = 20) =>
    api.get<Page<LeaveRequestDto>>('/api/leave-requests', {
      params: { ...filter, page, size },
    }).then((r) => r.data),

  submit: (data: CreateLeaveRequest) =>
    api.post<LeaveRequestDto>('/api/leave-requests', data).then((r) => r.data),

  approve: (id: number) =>
    api.put<LeaveRequestDto>(`/api/leave-requests/${id}/approve`).then((r) => r.data),

  reject: (id: number, reason?: string) =>
    api.put<LeaveRequestDto>(`/api/leave-requests/${id}/reject`, { reason }).then((r) => r.data),

  cancel: (id: number) =>
    api.put<LeaveRequestDto>(`/api/leave-requests/${id}/cancel`).then((r) => r.data),
};

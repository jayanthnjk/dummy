import React, { useState } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Typography,
  Box,
  Chip,
} from '@mui/material';
import NavigateBeforeIcon from '@mui/icons-material/NavigateBefore';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import type { TableResponseData } from '@/types';

const PAGE_SIZE = 20; // Increased for detailed allocation views

const TableWidget: React.FC<TableResponseData> = ({ columns, rows, totalCount, meta }) => {
  const [page, setPage] = useState(0);

  const totalPages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
  const start = page * PAGE_SIZE;
  const end = Math.min(start + PAGE_SIZE, rows.length);
  const pageRows = rows.slice(start, end);

  // Derive title from column keys
  const hasPersonName = columns.some((c) => c.key === 'personName');
  const hasPlatoon = columns.some((c) => c.key === 'platoon');
  const hasCategory = columns.some((c) => c.key === 'category');
  const hasSection = columns.some((c) => c.key === 'section' && columns.some((cc) => cc.key === 'assignments'));
  const hasField = columns.some((c) => c.key === 'field');
  const hasRecordDate = columns.some((c) => c.key === 'recordDate');
  const tableTitle = hasRecordDate ? 'Duty History' : hasPersonName ? 'Personnel' : hasPlatoon ? 'Platoon Rotation' : hasCategory ? 'Leave Summary' : hasSection ? 'Schedule Overview' : hasField ? 'Personnel Allocation' : 'Results';

  // Check if this is a detailed field/value table (for personnel allocation)
  const isDetailView = hasField && columns.length === 2;

  // Helper to check if a row is a section header (field starts with emoji or is empty separator)
  const isSectionHeader = (row: Record<string, unknown>): boolean => {
    const fieldValue = String(row['field'] || '');
    const valueField = String(row['value'] || '');
    // Section headers have emoji at start and empty or no value
    return isDetailView && (
      (fieldValue.match(/^[📋📅🏠⚡🔄🏢🔴🟡🟢]/) && valueField === '') ||
      (fieldValue === '' && valueField === '')
    );
  };

  // Helper to check if row is an empty separator
  const isEmptySeparator = (row: Record<string, unknown>): boolean => {
    const fieldValue = String(row['field'] || '');
    const valueField = String(row['value'] || '');
    return isDetailView && fieldValue === '' && valueField === '';
  };

  return (
    <Box sx={{ width: '100%', borderRadius: 2, overflow: 'hidden', border: '1px solid #e5e7eb' }}>
      {/* Header bar */}
      <Box sx={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        px: 1.5, py: 1, bgcolor: '#f8fafc', borderBottom: '1px solid #e5e7eb',
      }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Typography sx={{ fontSize: '0.8rem', fontWeight: 600, color: '#1e293b' }}>
            {tableTitle}
          </Typography>
          {!isDetailView && (
            <Chip
              label={totalCount}
              size="small"
              sx={{
                height: 20, fontSize: '0.65rem', fontWeight: 700,
                bgcolor: '#312e81', color: '#fff',
              }}
            />
          )}
        </Box>
        {rows.length > PAGE_SIZE && (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
            <IconButton
              size="small"
              onClick={() => setPage((p) => p - 1)}
              disabled={page === 0}
              sx={{ width: 24, height: 24, color: '#64748b', '&.Mui-disabled': { color: '#cbd5e1' } }}
            >
              <NavigateBeforeIcon sx={{ fontSize: 18 }} />
            </IconButton>
            <Typography sx={{ fontSize: '0.65rem', color: '#64748b', minWidth: 40, textAlign: 'center' }}>
              {page + 1}/{totalPages}
            </Typography>
            <IconButton
              size="small"
              onClick={() => setPage((p) => p + 1)}
              disabled={page >= totalPages - 1}
              sx={{ width: 24, height: 24, color: '#64748b', '&.Mui-disabled': { color: '#cbd5e1' } }}
            >
              <NavigateNextIcon sx={{ fontSize: 18 }} />
            </IconButton>
          </Box>
        )}
      </Box>

      {/* Table */}
      <TableContainer>
        <Table size="small">
          {/* Hide table header for detailed field/value views */}
          {!isDetailView && (
            <TableHead>
              <TableRow sx={{ bgcolor: '#f1f5f9' }}>
                <TableCell sx={{
                  fontWeight: 700, fontSize: '0.7rem', color: '#475569',
                  textTransform: 'uppercase', letterSpacing: '0.05em',
                  py: 0.75, px: 1.5, borderBottom: '2px solid #e2e8f0',
                  whiteSpace: 'nowrap', width: 36,
                }}>
                  #
                </TableCell>
                {columns.map((col) => (
                  <TableCell
                    key={col.key}
                    sx={{
                      fontWeight: 700, fontSize: '0.7rem', color: '#475569',
                      textTransform: 'uppercase', letterSpacing: '0.05em',
                      py: 0.75, px: 1.5, borderBottom: '2px solid #e2e8f0',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {col.label}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
          )}
          <TableBody>
            {pageRows.map((row, idx) => {
              const sectionHeader = isSectionHeader(row);
              const emptySep = isEmptySeparator(row);

              // Skip rendering empty separator rows
              if (emptySep) {
                return (
                  <TableRow key={idx} sx={{ height: 8 }}>
                    <TableCell colSpan={columns.length + 1} sx={{ p: 0, border: 'none' }} />
                  </TableRow>
                );
              }

              // Section header styling
              if (sectionHeader) {
                const fieldValue = String(row['field'] || '');
                return (
                  <TableRow key={idx} sx={{ bgcolor: '#eef2ff' }}>
                    <TableCell
                      colSpan={isDetailView ? 2 : columns.length + 1}
                      sx={{
                        fontSize: '0.78rem',
                        fontWeight: 700,
                        color: '#4338ca',
                        py: 0.8,
                        px: 1.5,
                        borderBottom: '2px solid #c7d2fe',
                        letterSpacing: '0.02em',
                      }}
                    >
                      {fieldValue}
                    </TableCell>
                  </TableRow>
                );
              }

              // Regular row
              return (
                <TableRow
                  key={idx}
                  sx={{
                    '&:nth-of-type(even)': { bgcolor: isDetailView ? '#fafbfc' : '#fafbfc' },
                    '&:hover': { bgcolor: '#f0f4ff' },
                    transition: 'background-color 0.15s',
                  }}
                >
                  {/* Show row number only for non-detail views */}
                  {!isDetailView && (
                    <TableCell sx={{
                      fontSize: '0.72rem', py: 0.6, px: 1.5, color: '#94a3b8',
                      borderBottom: '1px solid #f1f5f9', fontWeight: 500,
                    }}>
                      {start + idx + 1}
                    </TableCell>
                  )}
                  {columns.map((col) => {
                    const val = row[col.key] != null ? String(row[col.key]) : '—';
                    const isStatus = col.key === 'status';
                    const isFieldColumn = col.key === 'field' && isDetailView;
                    const isValueColumn = col.key === 'value' && isDetailView;

                    // Status indicators in value column
                    const hasStatusIndicator = isValueColumn && (
                      val.includes('🔴') || val.includes('🟡') || val.includes('🟢')
                    );

                    return (
                      <TableCell
                        key={col.key}
                        sx={{
                          fontSize: '0.75rem',
                          py: isDetailView ? 0.5 : 0.6,
                          px: 1.5,
                          borderBottom: '1px solid #f1f5f9',
                          color: isFieldColumn ? '#64748b' : '#334155',
                          fontWeight: isFieldColumn ? 500 : (hasStatusIndicator ? 600 : 400),
                          whiteSpace: 'nowrap',
                          width: isFieldColumn ? '35%' : 'auto',
                        }}
                      >
                        {isStatus ? (
                          <Chip
                            label={val}
                            size="small"
                            sx={{
                              height: 20, fontSize: '0.65rem', fontWeight: 600,
                              bgcolor: val === 'Active' ? '#dcfce7' : '#fee2e2',
                              color: val === 'Active' ? '#166534' : '#991b1b',
                            }}
                          />
                        ) : hasStatusIndicator ? (
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                            <Typography sx={{
                              fontSize: '0.75rem',
                              fontWeight: 600,
                              color: val.includes('🔴') ? '#dc2626' : val.includes('🟡') ? '#d97706' : '#16a34a',
                            }}>
                              {val}
                            </Typography>
                          </Box>
                        ) : (
                          val
                        )}
                      </TableCell>
                    );
                  })}
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Meta info */}
      {meta && Object.keys(meta).length > 0 && (
        <Box sx={{
          px: 1.5, py: 1, bgcolor: '#eef2ff', borderTop: '1px solid #e5e7eb',
          display: 'flex', flexWrap: 'wrap', gap: 1.5, alignItems: 'center',
        }}>
          {Object.entries(meta).map(([key, value]) => (
            <Box key={key} sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
              <Typography sx={{ fontSize: '0.7rem', fontWeight: 600, color: '#6366f1' }}>
                {key}:
              </Typography>
              <Chip
                label={String(value)}
                size="small"
                sx={{
                  height: 22, fontSize: '0.7rem', fontWeight: 700,
                  bgcolor: '#fff', color: '#1e293b',
                  border: '1px solid #c7d2fe',
                }}
              />
            </Box>
          ))}
        </Box>
      )}

      {/* Footer - only show for non-detail views or if pagination is needed */}
      {(!isDetailView || rows.length > PAGE_SIZE) && (
        <Box sx={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          px: 1.5, py: 0.75, bgcolor: '#f8fafc', borderTop: '1px solid #e5e7eb',
        }}>
          <Typography sx={{ fontSize: '0.65rem', color: '#94a3b8' }}>
            {isDetailView ? '' : `Showing ${rows.length === 0 ? 0 : start + 1}–${end} of ${totalCount}`}
          </Typography>
        </Box>
      )}
    </Box>
  );
};

export default TableWidget;

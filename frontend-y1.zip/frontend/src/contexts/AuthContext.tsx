import React, { createContext, useContext } from 'react';
import { observer } from 'mobx-react-lite';
import { authStore } from '@/stores/authStore';
import type { UserRole, AuthResponse } from '@/types';

interface AuthContextValue {
  token: string | null;
  role: UserRole | null;
  displayName: string | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  login: (authResponse: AuthResponse) => void;
  logout: () => void;
  showInactivityDialog: boolean;
  inactivityCountdown: number;
  staySignedIn: () => void;
}

const AuthContext = createContext<AuthContextValue>(null!);

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = observer(({ children }) => {
  const value: AuthContextValue = {
    token: authStore.token,
    role: authStore.role,
    displayName: authStore.displayName,
    isAuthenticated: authStore.isAuthenticated,
    isAdmin: authStore.isAdmin,
    login: (auth) => authStore.login(auth),
    logout: () => authStore.logout(),
    showInactivityDialog: authStore.showInactivityDialog,
    inactivityCountdown: authStore.inactivityCountdown,
    staySignedIn: () => authStore.staySignedIn(),
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
});

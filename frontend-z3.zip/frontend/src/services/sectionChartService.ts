import api from './api';

// ===== Types =====
export interface ChartPersonnel {
  id: number;
  badgeId: string;
  personName: string;
  designation: string;
  dutyLocation: string | null;
  onLeave?: boolean;
  leaveType?: string;
  leaveStartDate?: string;
  leaveEndDate?: string;
  leaveDays?: number;
  leaveRequestId?: number;
}

export interface SubDutyGroup {
  subDutyName: string;
  personnel: ChartPersonnel[];
  personnelCount: number;
}

export interface DutyCard {
  dutyTypeId: number;
  dutyTypeName: string;
  sortOrder: number;
  subDuties: SubDutyGroup[];
  personnel: ChartPersonnel[]; // personnel without sub-duty (no duty_location)
  personnelCount: number;
}

export interface SectionChartData {
  sectionCode: string;
  dutyCards: DutyCard[];
  totalPersonnel: number;
}

// ===== Form 168 View Types =====
export interface Form168PersonnelDto {
  id: number;
  badgeId: string;
  personName: string;
  designation: string;
  displayText: string;
  leaveType?: string;
  leaveStartDate?: string;
  leaveEndDate?: string;
  leaveDays?: number;
}

export interface Form168DutyRow {
  serialNumber: number;
  subDutyName: string | null;
  counts: number[]; // [ACP, RPI, RSI, ARSI, AHC, APC, SWP, TOTAL]
  total: number;
  personnelByDesignation: Record<string, Form168PersonnelDto[]>;
  personnelDetails: string;
}

export interface Form168DutyCard {
  dutyTypeId: number;
  dutyTypeName: string;
  sortOrder: number;
  subDutyRows: Form168DutyRow[];
  counts: number[]; // [ACP, RPI, RSI, ARSI, AHC, APC, SWP, TOTAL]
  personnelCount: number;
}

export interface Form168LeaveRow {
  serialNumber: number;
  categoryName: string;
  counts: number[];
  total: number;
  personnelByDesignation: Record<string, Form168PersonnelDto[]>;
  personnelDetails: string;
}

export interface Form168LeaveSection {
  name: string;
  rows: Form168LeaveRow[];
  counts: number[];
  totalPersonnel: number;
}

export interface Form168ViewData {
  sectionCode: string;
  dutyCards: Form168DutyCard[];
  leaveSection: Form168LeaveSection;
  dutySubTotal: number[];
  grandTotal: number[];
  totalOnDuty: number;
  totalOnLeave: number;
  totalPersonnel: number;
}

export interface PersonnelSearchResult {
  id: number;
  badgeId: string;
  personName: string;
  designation: string;
  currentSection: string;
  currentDutyType: string;
  currentDutyLocation: string | null;
}

export interface AssignRequest {
  personnelId: number;
  dutyTypeId: number;
  sectionCode: string;
  subDuty?: string | null; // duty_location value
}

export interface UnassignRequest {
  personnelId: number;
}

// ===== Service =====
export const sectionChartService = {
  /** Fetch chart data for a section */
  getChart: (sectionCode: string) =>
    api.get<SectionChartData>(`/api/section-chart/${sectionCode}`).then((r) => r.data),

  /** Fetch Form 168-style view for a section (proper grouping, no leave in duties, designation counts) */
  getForm168View: (sectionCode: string) =>
    api.get<Form168ViewData>(`/api/section-chart/${sectionCode}/form168-view`).then((r) => r.data),

  /** Search personnel for autocomplete (badge or name) */
  searchPersonnel: (query: string, limit = 10) =>
    api.get<PersonnelSearchResult[]>('/api/section-chart/search-personnel', {
      params: { query, limit },
    }).then((r) => r.data),

  /** Assign a person to a duty type with optional sub-duty (duty_location) */
  assign: (request: AssignRequest) =>
    api.put('/api/section-chart/assign', request).then((r) => r.data),

  /** Unassign a person from their duty */
  unassign: (request: UnassignRequest) =>
    api.put('/api/section-chart/unassign', request).then((r) => r.data),

  /** Create a new parent duty type in the duty_types table */
  createDutyType: (data: { name: string; section: string; sortOrder: number; level: 'PARENT'; }) =>
    api.post('/api/duty-types', data).then((r) => r.data),

  /** Add a sub-duty (logical - validates parent exists) */
  addSubDuty: (data: { subDutyName: string; parentDutyTypeId: number }) =>
    api.post('/api/section-chart/add-sub-duty', data).then((r) => r.data),

  /** Delete a parent duty type (unassigns all personnel, removes from DB) */
  deleteDutyType: (dutyTypeId: number) =>
    api.delete(`/api/section-chart/duty-type/${dutyTypeId}`).then((r) => r.data),

  /** Delete a sub-duty (clears duty_location for all personnel under it) */
  deleteSubDuty: (parentDutyTypeId: number, subDutyName: string) =>
    api.delete('/api/section-chart/sub-duty', {
      params: { parentDutyTypeId, subDutyName },
    }).then((r) => r.data),
};

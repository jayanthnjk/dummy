import api from './api';
import type {
  PersonnelDto,
  CreatePersonnelRequest,
  UpdatePersonnelRequest,
  PersonnelFilter,
  Page,
} from '@/types';

export const personnelService = {
  list: (filter?: PersonnelFilter, page = 0, size = 20) =>
    api.get<Page<PersonnelDto>>('/api/personnel', {
      params: { ...filter, page, size },
    }).then((r) => r.data),

  getByBadgeId: (badgeId: string) =>
    api.get<PersonnelDto>(`/api/personnel/${badgeId}`).then((r) => r.data),

  create: (data: CreatePersonnelRequest) =>
    api.post<PersonnelDto>('/api/personnel', data).then((r) => r.data),

  update: (badgeId: string, data: UpdatePersonnelRequest) =>
    api.put<PersonnelDto>(`/api/personnel/${badgeId}`, data).then((r) => r.data),

  delete: (badgeId: string) =>
    api.delete<void>(`/api/personnel/${badgeId}`),
};

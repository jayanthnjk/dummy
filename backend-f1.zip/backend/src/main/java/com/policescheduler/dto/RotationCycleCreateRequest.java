package com.policescheduler.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;

/**
 * Simplified request DTO for creating a new rotation cycle.
 * Only requires start date and number of working days.
 * Optionally accepts platoon-section overrides and explicit end date.
 */
public record RotationCycleCreateRequest(
    @NotNull(message = "Start date is required")
    LocalDate startDate,

    @NotNull(message = "Working days is required")
    @Min(value = 1, message = "Working days must be at least 1")
    Integer workingDays,

    // Optional: user can override the auto-generated platoon-section mappings
    java.util.Map<Long, Long> platoonSectionOverrides,

    // Optional: explicit end date (for half-month fixed periods)
    // If provided, overrides the working-days-based calculation
    LocalDate endDate
) {}

package com.policescheduler.repository;

import com.policescheduler.entity.DutyReassignment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface DutyReassignmentRepository extends JpaRepository<DutyReassignment, Long> {

    /** Find all active reassignments for a section where today falls within the date range */
    @Query("SELECT r FROM DutyReassignment r WHERE r.sectionCode = :sectionCode " +
           "AND r.status = 'ACTIVE' AND r.startDate <= :date AND r.endDate >= :date")
    List<DutyReassignment> findActiveBySectionAndDate(
            @Param("sectionCode") String sectionCode, @Param("date") LocalDate date);

    /** Find all active reassignments for a section (regardless of date, for history) */
    List<DutyReassignment> findBySectionCodeAndStatus(String sectionCode, String status);

    /** Find all reassignments for a specific leave person */
    List<DutyReassignment> findByLeavePersonIdAndStatus(Long leavePersonId, String status);

    /** Find reassignment by leave request ID */
    List<DutyReassignment> findByLeaveRequestId(Long leaveRequestId);

    /** Find all ACTIVE reassignments whose endDate is strictly before the given date (expired) */
    @Query("SELECT r FROM DutyReassignment r WHERE r.status = 'ACTIVE' AND r.endDate < :date")
    List<DutyReassignment> findActiveExpiredBefore(@Param("date") LocalDate date);

    /** Find all ACTIVE reassignments where the given date falls within startDate and endDate */
    @Query("SELECT r FROM DutyReassignment r WHERE r.status = 'ACTIVE' " +
           "AND r.startDate <= :date AND r.endDate >= :date")
    List<DutyReassignment> findAllActiveOnDate(@Param("date") LocalDate date);
}

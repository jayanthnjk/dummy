package com.policescheduler.service;

import com.policescheduler.dto.AvailableReportDTO;
import com.policescheduler.dto.ReportEmailConfigDTO;
import com.policescheduler.dto.ReportSpecificEmailConfigDTO;
import com.policescheduler.entity.ReportEmailConfig;
import com.policescheduler.entity.ReportSpecificEmailConfig;
import com.policescheduler.repository.ReportEmailConfigRepository;
import com.policescheduler.repository.ReportSpecificEmailConfigRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Service for managing Report Email Configuration.
 * Handles both Generate Reports Configuration and Report Specific Email Configuration.
 */
@Service
public class ReportEmailConfigService {

    private static final Logger log = LoggerFactory.getLogger(ReportEmailConfigService.class);

    private final ReportEmailConfigRepository reportEmailConfigRepository;
    private final ReportSpecificEmailConfigRepository reportSpecificEmailConfigRepository;

    // Static list of available reports in the application
    private static final List<AvailableReportDTO> AVAILABLE_REPORTS = List.of(
            new AvailableReportDTO("section_ab", "Platoon Chart A & B", "Combined Section A and Section B personnel list with duty assignments"),
            new AvailableReportDTO("platoon_chart", "Platoon Chart C - Rotational Duties", "Combined Section C, D, E, F, G platoon rotation chart"),
            new AvailableReportDTO("form_168", "Daily Statement (Form 168)", "Official daily strength and duty abstract report"),
            new AvailableReportDTO("mt_section", "MT Section (Drivers)", "Motor Transport section with driver details"),
            new AvailableReportDTO("leave_statement", "Leave Statement", "Leave request summary with status and details"),
            new AvailableReportDTO("personnel_list", "Personnel List", "Complete personnel directory")
    );

    public ReportEmailConfigService(ReportEmailConfigRepository reportEmailConfigRepository,
                                    ReportSpecificEmailConfigRepository reportSpecificEmailConfigRepository) {
        this.reportEmailConfigRepository = reportEmailConfigRepository;
        this.reportSpecificEmailConfigRepository = reportSpecificEmailConfigRepository;
    }

    // ─── Available Reports ───────────────────────────────────────────────

    public List<AvailableReportDTO> getAvailableReports() {
        return AVAILABLE_REPORTS;
    }

    // ─── Generate Reports Configuration (CRUD) ───────────────────────────

    public List<ReportEmailConfigDTO> getAllReportEmailConfigs() {
        return reportEmailConfigRepository.findAllByOrderByCreatedAtDesc()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public Optional<ReportEmailConfigDTO> getReportEmailConfigById(Long id) {
        return reportEmailConfigRepository.findById(id).map(this::toDTO);
    }

    @Transactional
    public ReportEmailConfigDTO createReportEmailConfig(ReportEmailConfigDTO dto, String username) {
        validateReportEmailConfigDTO(dto);

        ReportEmailConfig entity = new ReportEmailConfig();
        entity.setSubjectTitle(dto.getSubjectTitle());
        entity.setEmailIds(String.join(",", dto.getEmailIds()));
        entity.setEmailBody(dto.getEmailBody());
        entity.setSelectedReports(String.join(",", dto.getSelectedReports()));
        entity.setIsActive(dto.getIsActive() != null ? dto.getIsActive() : true);
        entity.setCreatedBy(username);
        entity.setUpdatedBy(username);

        ReportEmailConfig saved = reportEmailConfigRepository.save(entity);
        log.info("Created report email config #{} by {}", saved.getId(), username);
        return toDTO(saved);
    }

    @Transactional
    public ReportEmailConfigDTO updateReportEmailConfig(Long id, ReportEmailConfigDTO dto, String username) {
        validateReportEmailConfigDTO(dto);

        ReportEmailConfig entity = reportEmailConfigRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Report email config not found: " + id));

        entity.setSubjectTitle(dto.getSubjectTitle());
        entity.setEmailIds(String.join(",", dto.getEmailIds()));
        entity.setEmailBody(dto.getEmailBody());
        entity.setSelectedReports(String.join(",", dto.getSelectedReports()));
        entity.setIsActive(dto.getIsActive() != null ? dto.getIsActive() : true);
        entity.setUpdatedBy(username);

        ReportEmailConfig saved = reportEmailConfigRepository.save(entity);
        log.info("Updated report email config #{} by {}", saved.getId(), username);
        return toDTO(saved);
    }

    @Transactional
    public void deleteReportEmailConfig(Long id, String username) {
        if (!reportEmailConfigRepository.existsById(id)) {
            throw new IllegalArgumentException("Report email config not found: " + id);
        }
        reportEmailConfigRepository.deleteById(id);
        log.info("Deleted report email config #{} by {}", id, username);
    }

    // ─── Report Specific Email Configuration (CRUD) ──────────────────────

    public List<ReportSpecificEmailConfigDTO> getAllReportSpecificEmailConfigs() {
        return reportSpecificEmailConfigRepository.findAllByOrderByReportNameAsc()
                .stream()
                .map(this::toSpecificDTO)
                .collect(Collectors.toList());
    }

    public Optional<ReportSpecificEmailConfigDTO> getReportSpecificEmailConfigById(Long id) {
        return reportSpecificEmailConfigRepository.findById(id).map(this::toSpecificDTO);
    }

    public Optional<ReportSpecificEmailConfigDTO> getReportSpecificEmailConfigByReportType(String reportType) {
        return reportSpecificEmailConfigRepository.findByReportType(reportType).map(this::toSpecificDTO);
    }

    @Transactional
    public ReportSpecificEmailConfigDTO createReportSpecificEmailConfig(ReportSpecificEmailConfigDTO dto, String username) {
        validateReportSpecificEmailConfigDTO(dto);

        // Check if config already exists for this report type
        if (reportSpecificEmailConfigRepository.existsByReportType(dto.getReportType())) {
            throw new IllegalArgumentException("Configuration already exists for report type: " + dto.getReportType());
        }

        ReportSpecificEmailConfig entity = new ReportSpecificEmailConfig();
        entity.setReportType(dto.getReportType());
        entity.setReportName(dto.getReportName());
        entity.setEmailSubject(dto.getEmailSubject());
        entity.setEmailBody(dto.getEmailBody());
        entity.setScheduleDays(dto.getScheduleDays() != null ? String.join(",", dto.getScheduleDays()) : null);
        entity.setScheduleTime(dto.getScheduleTime());
        entity.setIsScheduleEnabled(dto.getIsScheduleEnabled() != null ? dto.getIsScheduleEnabled() : false);
        entity.setCreatedBy(username);
        entity.setUpdatedBy(username);

        ReportSpecificEmailConfig saved = reportSpecificEmailConfigRepository.save(entity);
        log.info("Created report specific email config for {} by {}", dto.getReportType(), username);
        return toSpecificDTO(saved);
    }

    @Transactional
    public ReportSpecificEmailConfigDTO updateReportSpecificEmailConfig(Long id, ReportSpecificEmailConfigDTO dto, String username) {
        validateReportSpecificEmailConfigDTO(dto);

        ReportSpecificEmailConfig entity = reportSpecificEmailConfigRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Report specific email config not found: " + id));

        // If report type is changing, check for duplicates
        if (!entity.getReportType().equals(dto.getReportType())) {
            if (reportSpecificEmailConfigRepository.existsByReportType(dto.getReportType())) {
                throw new IllegalArgumentException("Configuration already exists for report type: " + dto.getReportType());
            }
        }

        entity.setReportType(dto.getReportType());
        entity.setReportName(dto.getReportName());
        entity.setEmailSubject(dto.getEmailSubject());
        entity.setEmailBody(dto.getEmailBody());
        entity.setScheduleDays(dto.getScheduleDays() != null ? String.join(",", dto.getScheduleDays()) : null);
        entity.setScheduleTime(dto.getScheduleTime());
        entity.setIsScheduleEnabled(dto.getIsScheduleEnabled() != null ? dto.getIsScheduleEnabled() : false);
        entity.setUpdatedBy(username);

        ReportSpecificEmailConfig saved = reportSpecificEmailConfigRepository.save(entity);
        log.info("Updated report specific email config #{} by {}", saved.getId(), username);
        return toSpecificDTO(saved);
    }

    @Transactional
    public void deleteReportSpecificEmailConfig(Long id, String username) {
        if (!reportSpecificEmailConfigRepository.existsById(id)) {
            throw new IllegalArgumentException("Report specific email config not found: " + id);
        }
        reportSpecificEmailConfigRepository.deleteById(id);
        log.info("Deleted report specific email config #{} by {}", id, username);
    }

    // ─── Validation ──────────────────────────────────────────────────────

    private void validateReportEmailConfigDTO(ReportEmailConfigDTO dto) {
        // Note: subjectTitle and emailBody are now auto-populated from report_specific_email_config
        // They are no longer mandatory fields
        if (dto.getEmailIds() == null || dto.getEmailIds().isEmpty()) {
            throw new IllegalArgumentException("At least one Email ID is mandatory");
        }
        // Validate email format
        for (String email : dto.getEmailIds()) {
            if (!isValidEmail(email)) {
                throw new IllegalArgumentException("Invalid email format: " + email);
            }
        }
        if (dto.getSelectedReports() == null || dto.getSelectedReports().isEmpty()) {
            throw new IllegalArgumentException("At least one report must be selected");
        }
    }

    private void validateReportSpecificEmailConfigDTO(ReportSpecificEmailConfigDTO dto) {
        if (dto.getReportType() == null || dto.getReportType().trim().isEmpty()) {
            throw new IllegalArgumentException("Report Name is mandatory");
        }
        if (dto.getEmailSubject() == null || dto.getEmailSubject().trim().isEmpty()) {
            throw new IllegalArgumentException("Email Subject is mandatory");
        }
        if (dto.getEmailBody() == null || dto.getEmailBody().trim().isEmpty()) {
            throw new IllegalArgumentException("Email Body is mandatory");
        }
    }

    private boolean isValidEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            return false;
        }
        // Simple email validation regex
        String emailRegex = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        return email.trim().matches(emailRegex);
    }

    // ─── Conversion Methods ──────────────────────────────────────────────

    private ReportEmailConfigDTO toDTO(ReportEmailConfig entity) {
        ReportEmailConfigDTO dto = new ReportEmailConfigDTO();
        dto.setId(entity.getId());
        dto.setSubjectTitle(entity.getSubjectTitle());
        dto.setEmailIds(parseCommaSeparated(entity.getEmailIds()));
        dto.setEmailBody(entity.getEmailBody());
        dto.setSelectedReports(parseCommaSeparated(entity.getSelectedReports()));
        dto.setIsActive(entity.getIsActive());
        dto.setCreatedAt(entity.getCreatedAt());
        dto.setUpdatedAt(entity.getUpdatedAt());
        dto.setCreatedBy(entity.getCreatedBy());
        dto.setUpdatedBy(entity.getUpdatedBy());
        return dto;
    }

    private ReportSpecificEmailConfigDTO toSpecificDTO(ReportSpecificEmailConfig entity) {
        ReportSpecificEmailConfigDTO dto = new ReportSpecificEmailConfigDTO();
        dto.setId(entity.getId());
        dto.setReportType(entity.getReportType());
        dto.setReportName(entity.getReportName());
        dto.setEmailSubject(entity.getEmailSubject());
        dto.setEmailBody(entity.getEmailBody());
        dto.setScheduleDays(parseCommaSeparated(entity.getScheduleDays()));
        dto.setScheduleTime(entity.getScheduleTime());
        dto.setIsScheduleEnabled(entity.getIsScheduleEnabled() != null ? entity.getIsScheduleEnabled() : false);
        dto.setCreatedAt(entity.getCreatedAt());
        dto.setUpdatedAt(entity.getUpdatedAt());
        dto.setCreatedBy(entity.getCreatedBy());
        dto.setUpdatedBy(entity.getUpdatedBy());
        return dto;
    }

    private List<String> parseCommaSeparated(String value) {
        if (value == null || value.trim().isEmpty()) {
            return Collections.emptyList();
        }
        return Arrays.stream(value.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toList());
    }

    // ─── Email Content Helper Methods ────────────────────────────────────

    /**
     * Get email subject for a specific report type.
     * First checks report_specific_email_config, falls back to default if not configured.
     * 
     * @param reportType The report type code
     * @return Email subject string
     */
    public String getEmailSubjectForReport(String reportType) {
        return reportSpecificEmailConfigRepository.findByReportType(reportType)
                .map(ReportSpecificEmailConfig::getEmailSubject)
                .orElseGet(() -> getReportName(reportType));
    }

    /**
     * Get email body for a specific report type.
     * First checks report_specific_email_config, falls back to default if not configured.
     * Default format: "Please find attached report for {Report Name} dated {date}.\n\nThanks and Regards"
     * 
     * @param reportType The report type code
     * @param date The date string to include in default body
     * @return Email body string
     */
    public String getEmailBodyForReport(String reportType, String date) {
        return reportSpecificEmailConfigRepository.findByReportType(reportType)
                .map(ReportSpecificEmailConfig::getEmailBody)
                .orElseGet(() -> generateDefaultEmailBody(reportType, date));
    }

    /**
     * Get the report name from available reports list.
     */
    private String getReportName(String reportType) {
        return AVAILABLE_REPORTS.stream()
                .filter(r -> r.getReportType().equals(reportType))
                .findFirst()
                .map(AvailableReportDTO::getReportName)
                .orElse(reportType);
    }

    /**
     * Generate default email body when no specific config exists.
     */
    private String generateDefaultEmailBody(String reportType, String date) {
        String reportName = getReportName(reportType);
        return String.format("Please find attached report for %s dated %s.\n\nThanks and Regards", reportName, date);
    }

    /**
     * DTO containing email content for a report.
     */
    public static class ReportEmailContent {
        private final String subject;
        private final String body;

        public ReportEmailContent(String subject, String body) {
            this.subject = subject;
            this.body = body;
        }

        public String getSubject() {
            return subject;
        }

        public String getBody() {
            return body;
        }
    }

    /**
     * Get both email subject and body for a specific report type.
     * 
     * @param reportType The report type code
     * @param date The date string to include in default body
     * @return ReportEmailContent containing subject and body
     */
    public ReportEmailContent getEmailContentForReport(String reportType, String date) {
        Optional<ReportSpecificEmailConfig> config = reportSpecificEmailConfigRepository.findByReportType(reportType);
        
        if (config.isPresent()) {
            return new ReportEmailContent(config.get().getEmailSubject(), config.get().getEmailBody());
        }
        
        // Return defaults
        String reportName = getReportName(reportType);
        String defaultSubject = reportName;
        String defaultBody = String.format("Please find attached report for %s dated %s.\n\nThanks and Regards", reportName, date);
        
        return new ReportEmailContent(defaultSubject, defaultBody);
    }
}

import React, { useState, useMemo } from 'react';
import { observer } from 'mobx-react-lite';
import {
  Box,
  TextField,
  InputAdornment,
  Typography,
  List,
  ListItemButton,
  ListItemText,
  Collapse,
  IconButton,
  Menu,
  MenuItem,
  ListItemIcon,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import EditIcon from '@mui/icons-material/Edit';
import SwapHorizIcon from '@mui/icons-material/SwapHoriz';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import InboxIcon from '@mui/icons-material/Inbox';
import { useTranslation } from 'react-i18next';
import { dutySectionStore } from '@/stores/dutySectionStore';
import type { DutyType } from '@/types/dutySections';

/** Section color palette */
const SECTION_COLORS: Record<string, string> = {
  A: '#3B82F6',
  B: '#10B981',
  C: '#8B5CF6',
  D: '#F97316',
  E: '#06B6D4',
  F: '#EC4899',
  G: '#EF4444',
};

function getSectionColor(code: string): string {
  const key = code.charAt(0).toUpperCase();
  return SECTION_COLORS[key] || '#6B7280';
}

export interface DutyTypeSidebarProps {
  onAddDutyType: () => void;
  onEditDutyType: (id: number) => void;
  onReassignDutyType: (id: number) => void;
}

/**
 * DutyTypeSidebar — Professional sidebar with colored section group headers,
 * larger touch targets, prominent personnel counts, and section-colored indicators.
 */
const DutyTypeSidebar: React.FC<DutyTypeSidebarProps> = observer(
  ({ onAddDutyType, onEditDutyType, onReassignDutyType }) => {
    const { t } = useTranslation();
    const { filteredDutyTypes, selectedDutyTypeId, activeSections, personnel } = dutySectionStore;

    const [sidebarSearch, setSidebarSearch] = useState('');
    const [collapsedSections, setCollapsedSections] = useState<Set<string>>(new Set());
    const [contextMenu, setContextMenu] = useState<{
      anchorEl: HTMLElement;
      dutyTypeId: number;
    } | null>(null);

    // Filter duty types by local sidebar search
    const searchFilteredDutyTypes = useMemo(() => {
      if (!sidebarSearch.trim()) return filteredDutyTypes;
      const query = sidebarSearch.toLowerCase().trim();
      return filteredDutyTypes.filter(
        (dt) =>
          dt.name.toLowerCase().includes(query) ||
          dt.section.toLowerCase().includes(query)
      );
    }, [filteredDutyTypes, sidebarSearch]);

    // Group duty types by section code
    const groupedBySection = useMemo(() => {
      const groups: Record<string, DutyType[]> = {};
      for (const dt of searchFilteredDutyTypes) {
        if (!groups[dt.section]) {
          groups[dt.section] = [];
        }
        groups[dt.section].push(dt);
      }
      for (const key of Object.keys(groups)) {
        groups[key].sort((a, b) => a.sortOrder - b.sortOrder);
      }
      return groups;
    }, [searchFilteredDutyTypes]);

    const getSectionName = (code: string): string => {
      const section = activeSections.find((s) => s.code === code);
      return section ? section.name : code;
    };

    const getPersonnelCount = (dutyTypeName: string): number => {
      return personnel.filter((p) => p.dutyType === dutyTypeName).length;
    };

    const toggleSection = (code: string) => {
      setCollapsedSections((prev) => {
        const next = new Set(prev);
        if (next.has(code)) next.delete(code);
        else next.add(code);
        return next;
      });
    };

    const handleItemClick = (id: number) => {
      dutySectionStore.selectDutyType(selectedDutyTypeId === id ? null : id);
    };

    const handleMenuOpen = (event: React.MouseEvent<HTMLElement>, dutyTypeId: number) => {
      event.stopPropagation();
      setContextMenu({ anchorEl: event.currentTarget, dutyTypeId });
    };

    const handleMenuClose = () => setContextMenu(null);

    const handleEdit = () => {
      if (contextMenu) onEditDutyType(contextMenu.dutyTypeId);
      handleMenuClose();
    };

    const handleReassign = () => {
      if (contextMenu) onReassignDutyType(contextMenu.dutyTypeId);
      handleMenuClose();
    };

    const sectionCodes = activeSections
      .map((s) => s.code)
      .filter((code) => groupedBySection[code] && groupedBySection[code].length > 0);

    const totalDutyTypes = searchFilteredDutyTypes.length;

    return (
      <Box
        sx={{
          width: 290,
          minWidth: 290,
          maxWidth: 290,
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          borderRight: '1px solid #E2E8F0',
          backgroundColor: '#FAFBFC',
          overflow: 'hidden',
        }}
      >
        {/* Search input */}
        <Box sx={{ px: 2, pt: 2, pb: 1.5 }}>
          <TextField
            size="small"
            variant="outlined"
            fullWidth
            placeholder={t('admin.dutySections.searchDutyTypes', 'Search duty types...')}
            value={sidebarSearch}
            onChange={(e) => setSidebarSearch(e.target.value)}
            slotProps={{
              input: {
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon fontSize="small" sx={{ color: '#94A3B8' }} />
                  </InputAdornment>
                ),
              },
            }}
            sx={{
              '& .MuiOutlinedInput-root': {
                borderRadius: 2,
                backgroundColor: 'white',
                height: 38,
                '&:hover': { backgroundColor: '#F8FAFC' },
              },
            }}
          />
        </Box>

        {/* Scrollable list */}
        <Box
          sx={{
            flex: 1,
            overflowY: 'auto',
            '&::-webkit-scrollbar': { width: 5 },
            '&::-webkit-scrollbar-thumb': {
              backgroundColor: '#CBD5E1',
              borderRadius: 3,
            },
          }}
        >
          {sectionCodes.length === 0 && searchFilteredDutyTypes.length === 0 ? (
            <Box
              sx={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                py: 6,
                gap: 1.5,
              }}
            >
              <InboxIcon sx={{ fontSize: 40, color: '#CBD5E1' }} />
              <Typography variant="body2" color="text.secondary" textAlign="center" sx={{ px: 3 }}>
                {t('admin.dutySections.noDutyTypes', 'No duty types found')}
              </Typography>
            </Box>
          ) : (
            <List disablePadding>
              {sectionCodes.map((sectionCode) => {
                const dutyTypes = groupedBySection[sectionCode];
                const isCollapsed = collapsedSections.has(sectionCode);
                const sectionColor = getSectionColor(sectionCode);
                const sectionName = getSectionName(sectionCode);

                return (
                  <React.Fragment key={sectionCode}>
                    {/* Section group header with colored left border */}
                    <ListItemButton
                      onClick={() => toggleSection(sectionCode)}
                      sx={{
                        py: 1.25,
                        px: 2,
                        borderLeft: `4px solid ${sectionColor}`,
                        backgroundColor: 'white',
                        borderBottom: '1px solid #F1F5F9',
                        '&:hover': { backgroundColor: '#F8FAFC' },
                      }}
                    >
                      {isCollapsed ? (
                        <ChevronRightIcon fontSize="small" sx={{ mr: 1, color: '#94A3B8' }} />
                      ) : (
                        <ExpandMoreIcon fontSize="small" sx={{ mr: 1, color: '#94A3B8' }} />
                      )}
                      <ListItemText
                        primary={
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <Typography variant="body2" fontWeight={700} sx={{ color: '#1E293B' }}>
                              {sectionName}
                            </Typography>
                          </Box>
                        }
                      />
                      {/* Count badge */}
                      <Box
                        sx={{
                          backgroundColor: `${sectionColor}15`,
                          color: sectionColor,
                          borderRadius: '12px',
                          px: 1,
                          py: 0.25,
                          fontSize: '0.7rem',
                          fontWeight: 700,
                          minWidth: 24,
                          textAlign: 'center',
                        }}
                      >
                        {dutyTypes.length}
                      </Box>
                    </ListItemButton>

                    {/* Duty type items */}
                    <Collapse in={!isCollapsed} timeout="auto" unmountOnExit>
                      <List disablePadding>
                        {dutyTypes.map((dt) => {
                          const isSelected = selectedDutyTypeId === dt.id;
                          const hasCoordinates = dt.latitude !== null && dt.longitude !== null;
                          const personnelCount = getPersonnelCount(dt.name);

                          return (
                            <ListItemButton
                              key={dt.id}
                              selected={isSelected}
                              onClick={() => handleItemClick(dt.id)}
                              onContextMenu={(e) => {
                                e.preventDefault();
                                handleMenuOpen(e, dt.id);
                              }}
                              sx={{
                                py: 1.25,
                                pl: 2.5,
                                pr: 1.5,
                                minHeight: 48,
                                borderLeft: isSelected
                                  ? `4px solid ${sectionColor}`
                                  : '4px solid transparent',
                                backgroundColor: isSelected ? `${sectionColor}08` : 'transparent',
                                transition: 'all 0.15s ease',
                                '&:hover': {
                                  backgroundColor: isSelected ? `${sectionColor}12` : '#F8FAFC',
                                },
                                '&.Mui-selected': {
                                  backgroundColor: `${sectionColor}08`,
                                  '&:hover': { backgroundColor: `${sectionColor}12` },
                                },
                              }}
                            >
                              {/* Section colored circle */}
                              <Box
                                sx={{
                                  width: 10,
                                  height: 10,
                                  borderRadius: '50%',
                                  backgroundColor: hasCoordinates ? sectionColor : '#CBD5E1',
                                  mr: 1.5,
                                  flexShrink: 0,
                                  boxShadow: hasCoordinates ? `0 0 0 2px ${sectionColor}25` : 'none',
                                }}
                              />
                              <ListItemText
                                primary={
                                  <Typography
                                    variant="body2"
                                    fontWeight={isSelected ? 700 : 500}
                                    noWrap
                                    sx={{
                                      color: '#1E293B',
                                      lineHeight: 1.3,
                                      fontSize: '0.85rem',
                                    }}
                                  >
                                    {dt.name}
                                  </Typography>
                                }
                                secondary={
                                  personnelCount > 0 ? (
                                    <Typography
                                      variant="caption"
                                      sx={{ color: '#64748B', fontSize: '0.72rem' }}
                                    >
                                      👥 {personnelCount} personnel
                                    </Typography>
                                  ) : null
                                }
                              />
                              {/* Personnel count prominent badge */}
                              {personnelCount > 0 && (
                                <Box
                                  sx={{
                                    backgroundColor: '#F1F5F9',
                                    color: '#475569',
                                    borderRadius: '10px',
                                    px: 0.75,
                                    py: 0.25,
                                    fontSize: '0.65rem',
                                    fontWeight: 700,
                                    minWidth: 20,
                                    textAlign: 'center',
                                    mr: 0.5,
                                  }}
                                >
                                  {personnelCount}
                                </Box>
                              )}
                              {/* More actions */}
                              <IconButton
                                size="small"
                                onClick={(e) => handleMenuOpen(e, dt.id)}
                                sx={{
                                  opacity: 0.4,
                                  '&:hover': { opacity: 1 },
                                  p: 0.5,
                                  color: '#94A3B8',
                                }}
                              >
                                <MoreVertIcon sx={{ fontSize: 16 }} />
                              </IconButton>
                            </ListItemButton>
                          );
                        })}
                      </List>
                    </Collapse>
                  </React.Fragment>
                );
              })}
            </List>
          )}
        </Box>

        {/* Bottom: total count footer */}
        <Box
          sx={{
            px: 2,
            py: 1.5,
            borderTop: '1px solid #E2E8F0',
            backgroundColor: 'white',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <Typography variant="caption" sx={{ color: '#64748B', fontWeight: 500 }}>
            {totalDutyTypes} {t('admin.dutySections.dutyTypesCount', 'duty types')}
          </Typography>
          <Box
            sx={{
              width: 6,
              height: 6,
              borderRadius: '50%',
              backgroundColor: '#10B981',
            }}
          />
        </Box>

        {/* Context menu */}
        <Menu
          open={contextMenu !== null}
          onClose={handleMenuClose}
          anchorEl={contextMenu?.anchorEl}
          slotProps={{
            paper: {
              sx: {
                borderRadius: 2,
                boxShadow: '0 4px 20px rgba(0,0,0,0.12)',
                border: '1px solid #E2E8F0',
              },
            },
          }}
        >
          <MenuItem onClick={handleEdit} sx={{ fontSize: '0.85rem', gap: 1 }}>
            <ListItemIcon sx={{ minWidth: '28px !important' }}>
              <EditIcon fontSize="small" sx={{ color: '#3B82F6' }} />
            </ListItemIcon>
            {t('admin.dutySections.editDutyType', 'Edit')}
          </MenuItem>
          <MenuItem onClick={handleReassign} sx={{ fontSize: '0.85rem', gap: 1 }}>
            <ListItemIcon sx={{ minWidth: '28px !important' }}>
              <SwapHorizIcon fontSize="small" sx={{ color: '#F97316' }} />
            </ListItemIcon>
            {t('admin.dutySections.reassignDutyType', 'Reassign')}
          </MenuItem>
        </Menu>
      </Box>
    );
  }
);

export default DutyTypeSidebar;

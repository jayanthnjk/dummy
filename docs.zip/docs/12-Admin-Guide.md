# Admin Guide
## KSP WorkBoard — System Administration Manual

| Field | Details |
|-------|---------|
| **Document Title** | Administrator Guide |
| **Version** | 1.0.0 |
| **Audience** | ADMIN role users |
| **Date** | June 2026 |

---

## 1. Admin Role Overview

As an ADMIN user, you have complete system access including:
- All standard user operations (chat, view schedules, view reports)
- Create, update, and delete personnel records
- Approve/reject leave requests
- Manage duty types and sections (add, edit, delete, reorder)
- Rotate platoons manually
- Manage system configuration
- Manage holidays
- Manage translations (i18n)
- Respond to support tickets
- Access admin-only configuration page

---

## 2. User Management

### 2.1 Creating Users

Users are created directly in the database (no self-registration UI):

```sql
INSERT INTO users (username, password_hash, role, display_name, locale, personnel_id)
VALUES (
    'officer_username',
    '$2a$10$...',  -- BCrypt hash of password
    'GENERAL_USER', -- or HIGHER_OFFICER, ADMIN
    'Officer Display Name',
    'en',  -- or 'kn'
    NULL   -- link to personnel record ID if applicable
);
```

**Generate password hash:**
```java
// In Java console or test:
BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
String hash = encoder.encode("newPassword123");
```

### 2.2 User Roles

| Role | Can Do | Cannot Do |
|------|--------|-----------|
| ADMIN | Everything | — |
| HIGHER_OFFICER | Personnel CRUD, Leave approve/reject, Reports, Chat | Delete personnel, System config, Admin page |
| GENERAL_USER | View data, Submit leave, Use chat, Download reports | Create/edit personnel, Approve leave, Admin |

### 2.3 Linking Users to Personnel

Set `personnel_id` on the user record to link them to their personnel profile. This is required for GENERAL_USER role-based leave filtering (they only see their own leaves).

---

## 3. Duty Type & Section Management

### 3.1 Accessing Admin Page

1. In the side navigation, expand **Admin Configuration**
2. Click **Duty Sections**
3. This page is available only to ADMIN and HIGHER_OFFICER roles

### 3.2 Managing Duty Types

**View:** All duty types are displayed organized by section tab

**Create:**
1. Click **Add Duty Type** on the relevant section tab
2. Enter: Name, Section, Sort Order
3. Optionally set: Latitude, Longitude, Radius (for geofencing)
4. Save

**Update:** Click edit icon on any duty type to modify

**Delete:** Click delete icon (fails with 409 if active assignments exist)

**Via Chat:**
- "Add duty type" → System shows a form
- "Delete duty type GUARD" → Removes it

### 3.3 Managing Sections

**API-based (no UI page — use Postman or chat):**
- Create: `POST /api/sections { code: "X", name: "Section X", sortOrder: 10 }`
- Update: `PUT /api/sections/{id} { name: "New Name" }`
- Bulk reassign duty types: `POST /api/sections/reassign`

### 3.4 Geolocation for Duty Types

Duty types can have latitude/longitude coordinates with a radius (default 500m). This is displayed on a Leaflet map in the admin page for visual verification.

---

## 4. Platoon Rotation Management

### 4.1 Creating Rotation Cycles

1. Navigate to **Schedules → Cycles**
2. Click **Create Cycle**
3. System auto-fills:
   - Start date = day after last cycle ends
   - Platoon mappings = shifted +1 from last cycle (circular rotation)
4. Adjust if needed
5. Click Create

**What happens internally:**
- Creates the cycle record (start_date, end_date, rotation_days)
- Creates 5 platoon-section mappings
- Auto-generates ~3000 duty assignments (all personnel × all days × 3 shifts)
- Logs creation to audit trail

### 4.2 Rotation Rules

- 5 platoons rotate through 5 sections (C, D, E, F, G) in circular order
- Each cycle, each platoon shifts to the next section: C→D→E→F→G→C
- No platoon gets the same section in consecutive cycles
- Within each platoon, personnel are divided into 3 shift groups (A, B, C)
- Shift pattern: DAY→NIGHT→AFTERNOON→DAY (no same shift on consecutive days)

### 4.3 Manual Platoon Rotation

Admin can trigger immediate rotation via:
- API: `POST /api/schedules/platoons/rotate` (ADMIN only)
- This updates the platoon rotation state

### 4.4 Handling Duty Reassignments

**When someone goes on leave:**
1. Navigate to the cycle's duty assignments
2. Find the person with "On Leave" flag
3. Click **Reassign** → Select replacement manually
4. Or click **Auto-Reassign** → System picks from other platoons

**Via Chat:**
- "Reassign duty assignment 1500 to person 45"
- "Auto reassign assignment 1500"

**Rules enforced:**
- Replacement must not be on leave for that date
- Replacement must not already have an assignment for same cycle/date/section
- Auto-reassign picks from OTHER platoons only

---

## 5. Leave Administration

### 5.1 Viewing All Leave Requests

As ADMIN, you see ALL leave requests across the station (not filtered by personnel).

### 5.2 Approval Workflow

1. Filter by status = PENDING
2. Review leave details (type, dates, reason, personnel info)
3. Click **Approve** to grant leave
4. Click **Reject** and provide a reason to deny

### 5.3 Duty Conflict Handling

When a leave is submitted and duty conflicts exist:
- The system still creates the leave (status=PENDING)
- It returns the list of conflicting duty assignments
- After approval, you should reassign those duties

---

## 6. System Configuration

### 6.1 Accessing Configuration

**API:** `GET /api/admin/config` (ADMIN only)

### 6.2 Configurable Parameters

| Key | Description | Default |
|-----|-------------|---------|
| min_section_strength | Minimum personnel required per section | 5 |
| rotation_cycle_default_days | Default cycle duration | 15 |

### 6.3 Updating Configuration

```bash
PUT /api/admin/config
Body: { "min_section_strength": "6", "rotation_cycle_default_days": "20" }
```

---

## 7. Holiday Management

### 7.1 Adding Holidays

1. Use API: `POST /api/holidays { date: "2026-08-15", name: "Independence Day", type: "NATIONAL" }`
2. Holidays affect scheduling calculations and leave conflict detection

### 7.2 Viewing Holidays

`GET /api/holidays?year=2026` — Returns all holidays for the year

---

## 8. Translation Management (i18n)

### 8.1 View Current Translations

`GET /api/i18n/translations/kn` — Returns all Kannada translations

### 8.2 Add/Update Translation

```bash
POST /api/i18n/translations
Body: {
    "translationKey": "nav.newFeature",
    "locale": "kn",
    "translationValue": "ಹೊಸ ವೈಶಿಷ್ಟ್ಯ",
    "category": "nav"
}
```

### 8.3 Find Missing Translations

`GET /api/i18n/missing?locale=kn` — Returns keys without Kannada translation

---

## 9. Support Ticket Management

### 9.1 Viewing Tickets

As ADMIN, `GET /api/support/tickets` returns ALL tickets from all users.

### 9.2 Responding to Tickets

```bash
PUT /api/support/tickets/{id}/respond
Body: { "response": "This issue has been fixed. Please try again." }
```

### 9.3 Updating Ticket Status

```bash
PUT /api/support/tickets/{id}/status
Body: { "status": "RESOLVED" }
```

Valid statuses: OPEN, IN_PROGRESS, RESOLVED, CLOSED

---

## 10. Monitoring & Health

### 10.1 System Health

```bash
curl /api/health
# {"status":"UP","aiProvider":"bedrock"}
```

### 10.2 AI Connectivity

```bash
curl /api/health/ai
# {"connected":true,"provider":"bedrock"}
```

### 10.3 Log Monitoring (Server)

```bash
sudo journalctl -u ksp-backend -f          # Real-time
sudo journalctl -u ksp-backend --since today # Today's logs
sudo journalctl -u ksp-backend -n 200       # Last 200 lines
```

### 10.4 Database Monitoring

```sql
-- Active connections
SELECT count(*) FROM pg_stat_activity WHERE datname = 'ksp_workboard';

-- Table sizes
SELECT relname, pg_size_pretty(pg_total_relation_size(relid))
FROM pg_catalog.pg_statio_user_tables ORDER BY pg_total_relation_size(relid) DESC;

-- Slow queries
SELECT query, calls, mean_exec_time FROM pg_stat_statements ORDER BY mean_exec_time DESC LIMIT 10;
```

---

## 11. Backup & Recovery

### 11.1 Database Backup

```bash
# Full backup
pg_dump -h <rds-endpoint> -U ksp_admin -d ksp_workboard -Fc -f backup_$(date +%Y%m%d).dump

# Restore
pg_restore -h <rds-endpoint> -U ksp_admin -d ksp_workboard backup_20260621.dump
```

### 11.2 Application Backup

The JAR file at `/opt/ksp/ksp-workboard.jar` can be backed up before deployment updates.

---

## 12. Security Best Practices

1. **Rotate JWT secret** quarterly or on any security incident
2. **Use strong DB passwords** — generate with `openssl rand -base64 32`
3. **Monitor audit logs** — Review cycle_audit_log for unexpected changes
4. **Review chat logs** — Check chat_messages for unusual patterns
5. **Keep dependencies updated** — Run `./gradlew dependencyUpdates` periodically
6. **Restrict SSH access** — Only your IP in security group
7. **Enable MFA** on AWS console access

---

*End of Document — Admin Guide v1.0.0*

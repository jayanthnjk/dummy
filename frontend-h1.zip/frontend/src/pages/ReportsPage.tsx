import React, { useState, useEffect } from 'react';
import {
  Box, Typography, Button, CircularProgress, alpha,
  Tabs, Tab, Checkbox, FormControlLabel, Collapse,
} from '@mui/material';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import GridOnIcon from '@mui/icons-material/GridOn';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import DescriptionIcon from '@mui/icons-material/Description';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import DirectionsCarIcon from '@mui/icons-material/DirectionsCar';
import EventBusyIcon from '@mui/icons-material/EventBusy';
import SecurityIcon from '@mui/icons-material/Security';
import PeopleIcon from '@mui/icons-material/People';
import GroupsIcon from '@mui/icons-material/Groups';

import { useTranslation } from 'react-i18next';
import api from '@/services/api';
import DownloadedReportsTab from '@/components/reports/DownloadedReportsTab';
import PageHeader from '@/components/common/PageHeader';
import DisplayCard from '@/components/common/DisplayCard';
import { useAuth } from '@/contexts/AuthContext';
import { dutyTypeService } from '@/services/dutySectionService';
import type { DutyType } from '@/types/dutySections';

interface ReportCard {
  title: string;
  description: string;
  endpoint: string;
  filename: string;
  excelEndpoint?: string;
  excelFilename?: string;
  icon: React.ReactNode;
  color: string;
  requiresDateRange?: boolean;
  requiresColumnSelection?: boolean;
  requiresDutyTypeSelection?: boolean;
}

/** Available columns for the Personnel List report */
const PERSONNEL_COLUMNS: { key: string; label: string }[] = [
  { key: 'personName', label: 'Name' },
  { key: 'designation', label: 'Designation' },
  { key: 'badgeId', label: 'KGID No.' },
  { key: 'section', label: 'Section' },
  { key: 'unit', label: 'Unit' },
  { key: 'dutyType', label: 'Duty Type' },
  { key: 'dutyLocation', label: 'Duty Location' },
  { key: 'location', label: 'Location' },
  { key: 'phoneNumber', label: 'Contact No.' },
  { key: 'email', label: 'Email' },
  { key: 'dateOfBirth', label: 'Date of Birth' },
  { key: 'dateOfJoining', label: 'Date of Joining' },
  { key: 'bloodGroup', label: 'Blood Group' },
  { key: 'qualification', label: 'Qualification' },
  { key: 'permanentAddress', label: 'Permanent Address' },
  { key: 'presentAddress', label: 'Present Address' },
  { key: 'nativePoliceStation', label: 'Native Police Station' },
  { key: 'vehicleNumber', label: 'Vehicle Number' },
  { key: 'typeOfVehicle', label: 'Type of Vehicle' },
  { key: 'pdms', label: 'PDMS' },
  { key: 'licenceType', label: 'Type of Licence' },
  { key: 'deployedFrom', label: 'Deployed From' },
];

const DEFAULT_SELECTED_COLUMNS = ['personName', 'phoneNumber', 'email'];

const ReportsPage: React.FC = () => {
  const { t } = useTranslation();
  const { isAdmin, isCAROnly, isMTOnly } = useAuth();
  const [downloading, setDownloading] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState(0);
  const [leaveStartDate, setLeaveStartDate] = useState<string>('');
  const [leaveEndDate, setLeaveEndDate] = useState<string>('');
  const [selectedColumns, setSelectedColumns] = useState<string[]>(DEFAULT_SELECTED_COLUMNS);
  const [columnsExpanded, setColumnsExpanded] = useState(false);
  const [selectedMtDutyTypes, setSelectedMtDutyTypes] = useState<string[]>([]);
  const [mtDutyTypesExpanded, setMtDutyTypesExpanded] = useState(false);
  const [mtDutyTypeOptions, setMtDutyTypeOptions] = useState<{ key: string; label: string }[]>([]);

  // Fetch MT section parent duty types from DB on mount
  useEffect(() => {
    dutyTypeService.listBySection('MT').then((dutyTypes: DutyType[]) => {
      const parentTypes = dutyTypes
        .filter(dt => dt.parentId === null && dt.level === 'PARENT')
        .map(dt => ({ key: dt.name, label: dt.name }));
      setMtDutyTypeOptions(parentTypes);
    }).catch(() => {
      // Fallback: empty list (user won't see options)
    });
  }, []);
  // Note: Status updates (duty reassignment expiry, adhoc duty completion) are now
  // handled by a scheduled backend job that runs daily at 3:00 AM.
  // See: StatusUpdateSchedulerService.java

  const reports: ReportCard[] = [
    {
      title: t('reports.platoonChartAB', 'Platoon Chart A & B'),
      description: t('reports.platoonChartABDesc', 'Combined Section A and Section B personnel list with duty assignments and designation counts'),
      endpoint: '/api/reports/section-ab',
      filename: 'PLATOON CHART A&B.pdf',
      excelEndpoint: '/api/reports/section-ab/excel',
      excelFilename: 'PLATOON CHART A&B.xlsx',
      icon: <SecurityIcon />,
      color: '#3b82f6',
    },
    {
      title: t('reports.platoonChartC', 'Platoon Chart C - Rotational Duties'),
      description: t('reports.platoonChartCDesc', 'Combined Section C, D, E, F, G platoon rotation chart with badge IDs'),
      endpoint: '/api/reports/platoon-chart',
      filename: 'PLATOON CHART C.pdf',
      excelEndpoint: '/api/reports/platoon-chart/excel',
      excelFilename: 'PLATOON CHART C.xlsx',
      icon: <CalendarMonthIcon />,
      color: '#059669',
    },
    {
      title: t('reports.dailyStatement', 'Daily Statement (Form 168)'),
      description: t('reports.dailyStatementDesc', 'Official daily strength and duty abstract report with designation breakdown'),
      endpoint: '/api/reports/form-168',
      filename: 'Statement (Form 168).pdf',
      excelEndpoint: '/api/reports/form-168/excel',
      excelFilename: 'Statement (Form 168).xlsx',
      icon: <DescriptionIcon />,
      color: '#e8722a',
    },
    {
      title: t('reports.mtSection', 'MT Section - Nominal Report'),
      description: t('reports.mtSectionDesc', 'CAR Motor Transport section with driver details, vehicle numbers, PDMS status'),
      endpoint: '/api/reports/mt-section',
      filename: 'mt-section-report.pdf',
      excelEndpoint: '/api/reports/mt-section/excel',
      excelFilename: 'mt-section.xlsx',
      icon: <DirectionsCarIcon />,
      color: '#0891b2',
    },
    {
      title: t('reports.mtDailyStatement', 'MT - Daily Statement (Form 168)'),
      description: t('reports.mtDailyStatementDesc', 'MT section daily duty deployment report with strength summary, vehicle assignments and leave statement'),
      endpoint: '/api/reports/mt-daily-statement',
      filename: 'MT Daily Statement (Form 168).pdf',
      excelEndpoint: '/api/reports/mt-daily-statement/excel',
      excelFilename: 'MT Daily Statement (Form 168).xlsx',
      icon: <DescriptionIcon />,
      color: '#d97706',
    },
    {
      title: t('reports.carMtSection', 'CAR MT Section Report'),
      description: t('reports.carMtSectionDesc', 'MT unit personnel list with duty, vehicle details, PDMS abstract and designation-wise strength'),
      endpoint: '/api/reports/car-mt-section',
      filename: 'CAR MT Section Report.pdf',
      excelEndpoint: '/api/reports/car-mt-section/excel',
      excelFilename: 'CAR MT Section Report.xlsx',
      icon: <DirectionsCarIcon />,
      color: '#0f766e',
    },
    {
      title: t('reports.mtDutyWise', 'MT Staff Details - Duty Wise Report'),
      description: t('reports.mtDutyWiseDesc', 'MT personnel filtered by selected duty types with vehicle and licence details'),
      endpoint: '/api/reports/mt-duty-wise',
      filename: 'MT Staff Duty Wise Report.pdf',
      excelEndpoint: '/api/reports/mt-duty-wise/excel',
      excelFilename: 'MT Staff Duty Wise Report.xlsx',
      icon: <DirectionsCarIcon />,
      color: '#b45309',
      requiresDutyTypeSelection: true,
    },
    {
      title: t('reports.leaveStatement', 'Leave Statement'),
      description: t('reports.leaveStatementDesc', 'Leave request summary with status, type, dates, and personnel details'),
      endpoint: '/api/reports/leave-statement',
      filename: 'Leave Statement.pdf',
      excelEndpoint: '/api/reports/leave-statement/excel',
      excelFilename: 'Leave Statement.xlsx',
      icon: <EventBusyIcon />,
      color: '#7c3aed',
      requiresDateRange: true,
    },
    {
      title: t('reports.personnelList', 'CITY ARMED RESERVE MANGALURU (C.A.R COMPANY) Personnel List'),
      description: t('reports.personnelListDesc', 'Complete personnel directory excluding drivers'),
      endpoint: '/api/reports/personnel',
      filename: 'CAR MANGALURU CITY (COMPANY).pdf',
      excelEndpoint: '/api/reports/personnel/excel',
      excelFilename: 'CAR MANGALURU CITY (COMPANY).xlsx',
      icon: <PeopleIcon />,
      color: '#16a34a',
    },
    {
      title: t('reports.completePersonnelList', 'Personnel List'),
      description: t('reports.completePersonnelListDesc', 'Complete personnel combining both CAR and MT units'),
      endpoint: '/api/reports/complete-personnel',
      filename: 'Complete Personnel List.pdf',
      excelEndpoint: '/api/reports/complete-personnel/excel',
      excelFilename: 'Complete Personnel List.xlsx',
      icon: <GroupsIcon />,
      color: '#8b5cf6',
      requiresColumnSelection: true,
    },
  ];

  // Filter reports based on user unit access
  // Admin: all | MT-only: MT report + MT Daily Statement + Leave | CAR-only: all except MT reports and Complete Personnel List
  const filteredReports = reports.filter((report) => {
    if (isAdmin) return true;
    if (isMTOnly) {
      return report.endpoint === '/api/reports/mt-section'
        || report.endpoint === '/api/reports/mt-daily-statement'
        || report.endpoint === '/api/reports/car-mt-section'
        || report.endpoint === '/api/reports/mt-duty-wise'
        || report.endpoint === '/api/reports/leave-statement';
    }
    if (isCAROnly) {
      return report.endpoint !== '/api/reports/mt-section'
        && report.endpoint !== '/api/reports/mt-daily-statement'
        && report.endpoint !== '/api/reports/car-mt-section'
        && report.endpoint !== '/api/reports/mt-duty-wise'
        && report.endpoint !== '/api/reports/complete-personnel';
    }
    return true;
  });

  const getEndpointWithColumns = (endpoint: string) => {
    if (selectedColumns.length > 0) {
      const params = selectedColumns.map(col => `columns=${encodeURIComponent(col)}`).join('&');
      return endpoint.includes('?') ? `${endpoint}&${params}` : `${endpoint}?${params}`;
    }
    return endpoint;
  };

  const getEndpointWithDutyTypes = (endpoint: string) => {
    if (selectedMtDutyTypes.length > 0) {
      const params = selectedMtDutyTypes.map(dt => `dutyTypes=${encodeURIComponent(dt)}`).join('&');
      return endpoint.includes('?') ? `${endpoint}&${params}` : `${endpoint}?${params}`;
    }
    return endpoint;
  };

  const getEndpointWithDates = (endpoint: string) => {
    if (leaveStartDate && leaveEndDate) {
      return `${endpoint}?startDate=${leaveStartDate}&endDate=${leaveEndDate}`;
    }
    return endpoint;
  };

  const handleDownload = async (report: ReportCard) => {
    let endpoint = report.endpoint;
    if (report.requiresDateRange) {
      endpoint = getEndpointWithDates(endpoint);
    }
    if (report.requiresColumnSelection) {
      endpoint = getEndpointWithColumns(endpoint);
    }
    if (report.requiresDutyTypeSelection) {
      endpoint = getEndpointWithDutyTypes(endpoint);
    }
    setDownloading(report.endpoint);
    try {
      const response = await api.get(endpoint, { responseType: 'blob' });
      const contentDisposition = response.headers['content-disposition'];
      let serverFilename = report.filename;
      if (contentDisposition) {
        const match = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
        if (match && match[1]) {
          serverFilename = match[1].replace(/['"]/g, '');
        }
      }
      const url = window.URL.createObjectURL(response.data);
      const link = document.createElement('a');
      link.href = url;
      link.download = serverFilename;
      link.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Download failed:', error);
    } finally {
      setDownloading(null);
    }
  };

  const handleExcelDownload = async (report: ReportCard) => {
    if (!report.excelEndpoint || !report.excelFilename) return;
    let endpoint = report.excelEndpoint;
    if (report.requiresDateRange) {
      endpoint = getEndpointWithDates(endpoint);
    }
    if (report.requiresColumnSelection) {
      endpoint = getEndpointWithColumns(endpoint);
    }
    if (report.requiresDutyTypeSelection) {
      endpoint = getEndpointWithDutyTypes(endpoint);
    }
    setDownloading(report.excelEndpoint);
    try {
      const response = await api.get(endpoint, { responseType: 'blob' });
      const contentDisposition = response.headers['content-disposition'];
      let serverFilename = report.excelFilename;
      if (contentDisposition) {
        const match = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
        if (match && match[1]) {
          serverFilename = match[1].replace(/['"]/g, '');
        }
      }
      const url = window.URL.createObjectURL(response.data);
      const link = document.createElement('a');
      link.href = url;
      link.download = serverFilename;
      link.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Excel download failed:', error);
    } finally {
      setDownloading(null);
    }
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', bgcolor: 'background.default' }}>
      {/* PageHeader replacing the gradient banner */}
      <PageHeader
        title={t('reports.title', 'Reports')}
        breadcrumbs={[
          { label: 'Home', path: '/' },
          { label: 'Reports' },
        ]}
      />

      {/* Tabs below header */}
      <Box sx={{ borderBottom: 1, borderColor: 'divider', bgcolor: 'white' }}>
        <Tabs
          value={activeTab}
          onChange={(_, newValue) => setActiveTab(newValue)}
          sx={{
            px: { xs: 2, md: 4 },
            '& .MuiTab-root': {
              textTransform: 'none',
              fontWeight: 500,
              color: 'text.secondary',
              '&.Mui-selected': {
                fontWeight: 700,
                color: 'primary.main',
              },
            },
            '& .MuiTabs-indicator': {
              backgroundColor: 'primary.main',
            },
          }}
        >
          <Tab label={t('reports.tab.reports', 'Reports')} />
          <Tab label={t('reports.tab.downloaded', 'Downloaded Reports')} />
        </Tabs>
      </Box>

      {/* Tab Content */}
      <Box sx={{ flex: 1, p: { xs: 2, md: 4 }, maxWidth: 1200, mx: 'auto', width: '100%' }}>
        {activeTab === 0 && (
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: {
                xs: '1fr',
                md: 'repeat(2, 1fr)',
                lg: 'repeat(3, 1fr)',
              },
              gap: 3,
            }}
          >
            {filteredReports.map((report, index) => (
              <DisplayCard
                key={report.endpoint}
                title={report.title}
                subtitle={report.description}
                icon={
                  <Box
                    sx={{
                      width: 40,
                      height: 40,
                      borderRadius: 2,
                      bgcolor: alpha(report.color, 0.1),
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      color: report.color,
                    }}
                  >
                    {report.icon}
                  </Box>
                }
                staggerIndex={index}
              >
                {/* Date range inputs for Leave Statement */}
                {report.requiresDateRange && (
                  <Box sx={{ mt: 2, mb: 1, display: 'flex', gap: 1.5, flexWrap: 'wrap' }}>
                    <Box sx={{ flex: 1, minWidth: 120 }}>
                      <Typography variant="caption" sx={{ color: 'text.secondary', fontSize: '0.7rem', mb: 0.5, display: 'block' }}>
                        {t('reports.startDate', 'Start Date')}
                      </Typography>
                      <input
                        type="date"
                        value={leaveStartDate}
                        onChange={(e) => setLeaveStartDate(e.target.value)}
                        style={{
                          width: '100%',
                          padding: '6px 8px',
                          borderRadius: '6px',
                          border: `1.5px solid ${report.color}`,
                          fontSize: '0.75rem',
                          outline: 'none',
                          fontFamily: 'inherit',
                        }}
                      />
                    </Box>
                    <Box sx={{ flex: 1, minWidth: 120 }}>
                      <Typography variant="caption" sx={{ color: 'text.secondary', fontSize: '0.7rem', mb: 0.5, display: 'block' }}>
                        {t('reports.endDate', 'End Date')}
                      </Typography>
                      <input
                        type="date"
                        value={leaveEndDate}
                        onChange={(e) => setLeaveEndDate(e.target.value)}
                        style={{
                          width: '100%',
                          padding: '6px 8px',
                          borderRadius: '6px',
                          border: `1.5px solid ${report.color}`,
                          fontSize: '0.75rem',
                          outline: 'none',
                          fontFamily: 'inherit',
                        }}
                      />
                    </Box>
                  </Box>
                )}

                {/* Column selection for Personnel List report */}
                {report.requiresColumnSelection && (
                  <Box sx={{ mt: 2, mb: 1 }}>
                    <Button
                      size="small"
                      onClick={() => setColumnsExpanded(!columnsExpanded)}
                      sx={{ textTransform: 'none', fontSize: '0.72rem', fontWeight: 600, color: report.color, mb: 0.5 }}
                    >
                      {columnsExpanded ? 'Hide Columns' : 'Select Columns'} ({selectedColumns.length}/8 selected)
                    </Button>
                    <Collapse in={columnsExpanded}>
                      <Box sx={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(2, 1fr)',
                        gap: 0,
                        maxHeight: 200,
                        overflowY: 'auto',
                        border: '1px solid',
                        borderColor: 'divider',
                        borderRadius: 1.5,
                        p: 1,
                        mt: 0.5,
                      }}>
                        {PERSONNEL_COLUMNS.map(col => (
                          <FormControlLabel
                            key={col.key}
                            control={
                              <Checkbox
                                size="small"
                                checked={selectedColumns.includes(col.key)}
                                disabled={!selectedColumns.includes(col.key) && selectedColumns.length >= 8}
                                onChange={(e) => {
                                  if (e.target.checked) {
                                    if (selectedColumns.length < 8) {
                                      setSelectedColumns(prev => [...prev, col.key]);
                                    }
                                  } else {
                                    setSelectedColumns(prev => prev.filter(k => k !== col.key));
                                  }
                                }}
                                sx={{ p: 0.3, color: report.color, '&.Mui-checked': { color: report.color } }}
                              />
                            }
                            label={<Typography sx={{ fontSize: '0.68rem' }}>{col.label}</Typography>}
                            sx={{ m: 0, minWidth: 0 }}
                          />
                        ))}
                      </Box>
                    </Collapse>
                  </Box>
                )}

                {/* Duty Type selection for MT Duty Wise report */}
                {report.requiresDutyTypeSelection && (
                  <Box sx={{ mt: 2, mb: 1 }}>
                    <Button
                      size="small"
                      onClick={() => setMtDutyTypesExpanded(!mtDutyTypesExpanded)}
                      sx={{ textTransform: 'none', fontSize: '0.72rem', fontWeight: 600, color: report.color, mb: 0.5 }}
                    >
                      {mtDutyTypesExpanded ? 'Hide Duty Types' : 'Select Duty Types'} ({selectedMtDutyTypes.length} selected)
                    </Button>
                    <Collapse in={mtDutyTypesExpanded}>
                      <Box sx={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(2, 1fr)',
                        gap: 0,
                        maxHeight: 220,
                        overflowY: 'auto',
                        border: '1px solid',
                        borderColor: 'divider',
                        borderRadius: 1.5,
                        p: 1,
                        mt: 0.5,
                      }}>
                        {mtDutyTypeOptions.map(dt => (
                          <FormControlLabel
                            key={dt.key}
                            control={
                              <Checkbox
                                size="small"
                                checked={selectedMtDutyTypes.includes(dt.key)}
                                onChange={(e) => {
                                  if (e.target.checked) {
                                    setSelectedMtDutyTypes(prev => [...prev, dt.key]);
                                  } else {
                                    setSelectedMtDutyTypes(prev => prev.filter(k => k !== dt.key));
                                  }
                                }}
                                sx={{ p: 0.3, color: report.color, '&.Mui-checked': { color: report.color } }}
                              />
                            }
                            label={<Typography sx={{ fontSize: '0.68rem' }}>{dt.label}</Typography>}
                            sx={{ m: 0, minWidth: 0 }}
                          />
                        ))}
                      </Box>
                    </Collapse>
                  </Box>
                )}

                {/* Download action buttons */}
                <Box sx={{ mt: report.requiresDateRange || report.requiresColumnSelection || report.requiresDutyTypeSelection ? 1 : 2 }}>
                  {report.requiresDutyTypeSelection && selectedMtDutyTypes.length === 0 ? (
                    <Typography variant="caption" sx={{ color: 'text.secondary', fontStyle: 'italic', fontSize: '0.7rem' }}>
                      Select at least one duty type to download
                    </Typography>
                  ) : report.requiresDateRange && (!leaveStartDate || !leaveEndDate) ? (
                    <Typography variant="caption" sx={{ color: 'text.secondary', fontStyle: 'italic', fontSize: '0.7rem' }}>
                      {t('reports.selectDates', 'Select both dates to download')}
                    </Typography>
                  ) : report.excelEndpoint ? (
                    <Box sx={{ display: 'flex', gap: 1 }}>
                      <Button
                        variant="outlined"
                        size="small"
                        startIcon={
                          downloading === report.endpoint ? (
                            <CircularProgress size={16} />
                          ) : (
                            <PictureAsPdfIcon />
                          )
                        }
                        disabled={!!downloading}
                        onClick={() => handleDownload(report)}
                        sx={{
                          borderRadius: 2,
                          textTransform: 'none',
                          fontWeight: 600,
                          borderColor: report.color,
                          color: report.color,
                          '&:hover': {
                            bgcolor: alpha(report.color, 0.08),
                            borderColor: report.color,
                          },
                        }}
                      >
                        {downloading === report.endpoint
                          ? t('reports.generating', 'Generating...')
                          : t('reports.pdf', 'PDF')}
                      </Button>
                      <Button
                        variant="outlined"
                        size="small"
                        startIcon={
                          downloading === report.excelEndpoint ? (
                            <CircularProgress size={16} />
                          ) : (
                            <GridOnIcon />
                          )
                        }
                        disabled={!!downloading}
                        onClick={() => handleExcelDownload(report)}
                        sx={{
                          borderRadius: 2,
                          textTransform: 'none',
                          fontWeight: 600,
                          borderColor: report.color,
                          color: report.color,
                          '&:hover': {
                            bgcolor: alpha(report.color, 0.08),
                            borderColor: report.color,
                          },
                        }}
                      >
                        {downloading === report.excelEndpoint
                          ? t('reports.generating', 'Generating...')
                          : t('reports.excel', 'Excel')}
                      </Button>
                    </Box>
                  ) : (
                    <Button
                      variant="outlined"
                      size="small"
                      startIcon={
                        downloading === report.endpoint ? (
                          <CircularProgress size={16} />
                        ) : (
                          <FileDownloadIcon />
                        )
                      }
                      disabled={downloading === report.endpoint}
                      onClick={() => handleDownload(report)}
                      sx={{
                        borderRadius: 2,
                        textTransform: 'none',
                        fontWeight: 600,
                        borderColor: report.color,
                        color: report.color,
                        '&:hover': {
                          bgcolor: alpha(report.color, 0.08),
                          borderColor: report.color,
                        },
                      }}
                    >
                      {downloading === report.endpoint
                        ? t('reports.generating', 'Generating...')
                        : t('reports.downloadPdf', 'Download PDF')}
                    </Button>
                  )}
                </Box>
              </DisplayCard>
            ))}
          </Box>
        )}

        {activeTab === 1 && <DownloadedReportsTab />}
      </Box>
    </Box>
  );
};

export default ReportsPage;

package com.policescheduler.repository;

import com.policescheduler.entity.LeaveRequest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface LeaveRequestRepository extends JpaRepository<LeaveRequest, Long>, JpaSpecificationExecutor<LeaveRequest> {

    Page<LeaveRequest> findByPersonnelId(Long personnelId, Pageable pageable);

    @Query("SELECT lr FROM LeaveRequest lr WHERE lr.personnelId = :personnelId " +
           "AND lr.status NOT IN ('REJECTED', 'CANCELLED') " +
           "AND lr.startDate <= :endDate AND (lr.endDate >= :startDate OR lr.endDate IS NULL)")
    List<LeaveRequest> findOverlapping(@Param("personnelId") Long personnelId,
                                       @Param("startDate") LocalDate startDate,
                                       @Param("endDate") LocalDate endDate);

    @Query("SELECT lr FROM LeaveRequest lr WHERE lr.personnelId = :personnelId " +
           "AND lr.status = 'APPROVED' " +
           "AND lr.startDate <= :endDate AND (lr.endDate >= :startDate OR lr.endDate IS NULL)")
    List<LeaveRequest> findApprovedOverlapping(@Param("personnelId") Long personnelId,
                                               @Param("startDate") LocalDate startDate,
                                               @Param("endDate") LocalDate endDate);

    /**
     * Find approved leave for a person on a specific date.
     * Used by duty history scheduler.
     */
    @Query("SELECT lr FROM LeaveRequest lr WHERE lr.personnelId = :personnelId " +
           "AND lr.status = 'APPROVED' " +
           "AND lr.startDate <= :date AND (lr.endDate >= :date OR lr.endDate IS NULL)")
    List<LeaveRequest> findApprovedLeaveForDate(@Param("personnelId") Long personnelId,
                                                 @Param("date") LocalDate date);

    /**
     * Find all approved leaves that are active on a specific date (for batch processing).
     */
    @Query("SELECT lr FROM LeaveRequest lr WHERE lr.status = 'APPROVED' " +
           "AND lr.startDate <= :date AND (lr.endDate >= :date OR lr.endDate IS NULL)")
    List<LeaveRequest> findAllApprovedLeavesForDate(@Param("date") LocalDate date);

    /**
     * Find all APPROVED leaves that have ended (endDate < today).
     * Only includes leaves WITH an end date (excludes open-ended leaves).
     * Used by scheduler to mark completed leaves.
     */
    @Query("SELECT lr FROM LeaveRequest lr WHERE lr.status = 'APPROVED' " +
           "AND lr.endDate IS NOT NULL AND lr.endDate < :today")
    List<LeaveRequest> findApprovedLeavesEndedBefore(@Param("today") LocalDate today);
}

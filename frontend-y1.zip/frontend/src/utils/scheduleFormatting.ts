import { Shift, TeamMemberSchedule } from '../types/schedule';

/**
 * Flat structure representing a single shift entry for export.
 */
export interface ExportDataRow {
  memberName: string;
  memberBadgeId: string;
  memberGroup: string;
  date: string;
  startTime: string;
  endTime: string;
  shiftType: string;
  durationHours: number;
}

/**
 * Formats a time range string from start and end times.
 * @param startTime - HH:mm format
 * @param endTime - HH:mm format
 * @returns Formatted string "{startTime} - {endTime}"
 */
export function formatTimeRange(startTime: string, endTime: string): string {
  return `${startTime} - ${endTime}`;
}

/**
 * Computes the total hours from a list of shifts by summing durationHours.
 * @param shifts - Array of Shift objects
 * @returns Sum of all shift durationHours values. Returns 0 for empty array.
 */
export function computeTotalHours(shifts: Shift[]): number {
  return shifts.reduce((sum, shift) => sum + shift.durationHours, 0);
}

/**
 * Generates export-ready data from team member schedules.
 * Maps each member's shifts into flat ExportDataRow objects — one entry per shift per member.
 * Every member and every shift is included in the export.
 * @param teamMemberSchedules - Array of TeamMemberSchedule objects
 * @returns Array of ExportDataRow objects
 */
export function generateExportData(teamMemberSchedules: TeamMemberSchedule[]): ExportDataRow[] {
  return teamMemberSchedules.flatMap((schedule) =>
    schedule.shifts.map((shift) => ({
      memberName: schedule.member.name,
      memberBadgeId: schedule.member.badgeId,
      memberGroup: schedule.member.group,
      date: shift.date,
      startTime: shift.startTime,
      endTime: shift.endTime,
      shiftType: shift.shiftType,
      durationHours: shift.durationHours,
    }))
  );
}

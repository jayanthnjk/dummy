import React from 'react';
import Box from '@mui/material/Box';
import IconButton from '@mui/material/IconButton';
import TableCell from '@mui/material/TableCell';
import AddIcon from '@mui/icons-material/Add';
import ShiftBlock from './ShiftBlock';
import TimeOffEntry from './TimeOffEntry';
import { Shift, TimeOff, ShiftType } from '../../types/schedule';

interface ShiftCellProps {
  memberId: number;
  date: string;
  shifts: Shift[];
  timeOffs: TimeOff[];
  showTimeOff: boolean;
  shiftTypes: ShiftType[];
  onAddShift: (memberId: number, date: string) => void;
  onShiftClick?: (shift: Shift) => void;
  isToday?: boolean;
}

/**
 * ShiftCell renders all shift blocks and time-off entries for a given team member
 * on a specific date. Shows a "+" add button on hover/focus.
 * Enterprise styling with proper vertical centering and subtle today highlight.
 */
const ShiftCell: React.FC<ShiftCellProps> = ({
  memberId,
  date,
  shifts,
  timeOffs,
  showTimeOff,
  onAddShift,
  onShiftClick,
  isToday = false,
}) => {
  const handleAddClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddShift(memberId, date);
  };

  return (
    <TableCell
      sx={{
        position: 'relative',
        p: '6px 8px',
        verticalAlign: 'middle',
        borderBottom: '1px solid #E5E7EB',
        borderRight: '1px solid #E5E7EB',
        backgroundColor: isToday ? '#EFF6FF' : 'inherit',
        minWidth: 100,
        '&:hover .shift-cell-add-btn, &:focus-within .shift-cell-add-btn': {
          opacity: 1,
        },
      }}
    >
      <Box
        sx={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'flex-start',
          justifyContent: 'center',
          minHeight: 40,
          gap: '2px',
        }}
      >
        {/* Render shift blocks */}
        {shifts.map((shift) => (
          <ShiftBlock
            key={shift.id}
            shift={shift}
            color=""
            textColor=""
            onClick={onShiftClick}
          />
        ))}

        {/* Render time-off entries when toggle is enabled */}
        {showTimeOff &&
          timeOffs.map((entry) => (
            <TimeOffEntry key={entry.id} entry={entry} />
          ))}
      </Box>

      {/* Add shift button — appears on hover/focus */}
      <IconButton
        className="shift-cell-add-btn"
        size="small"
        onClick={handleAddClick}
        aria-label={`Add shift for ${date}`}
        sx={{
          position: 'absolute',
          bottom: 2,
          right: 2,
          opacity: 0,
          transition: 'opacity 0.15s ease',
          width: 20,
          height: 20,
          backgroundColor: '#F3F4F6',
          border: '1px solid #E5E7EB',
          borderRadius: '6px',
          '&:hover': {
            backgroundColor: '#E5E7EB',
          },
        }}
      >
        <AddIcon sx={{ fontSize: 14, color: '#6B7280' }} />
      </IconButton>
    </TableCell>
  );
};

export default ShiftCell;

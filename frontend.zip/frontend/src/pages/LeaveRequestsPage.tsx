import React, { useEffect, useState, useCallback, useMemo } from 'react';
import {
  Box, Typography, Alert, Button, Chip, Stack,
  Dialog, DialogContent, DialogActions, MenuItem, TextField,
  IconButton, Tooltip, Select, FormControl, InputLabel, Snackbar, Skeleton,
  Autocomplete, ListItem, ListItemText, InputAdornment,
} from '@mui/material';
import CheckIcon from '@mui/icons-material/Check';
import CloseIcon from '@mui/icons-material/Close';
import CancelIcon from '@mui/icons-material/Cancel';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import EventBusyIcon from '@mui/icons-material/EventBusy';
import AddIcon from '@mui/icons-material/Add';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import CelebrationIcon from '@mui/icons-material/Celebration';
import PeopleIcon from '@mui/icons-material/People';
import VisibilityIcon from '@mui/icons-material/Visibility';
import SearchIcon from '@mui/icons-material/Search';
import EventAvailableIcon from '@mui/icons-material/EventAvailable';

import { useTranslation } from 'react-i18next';
import { useAuth } from '@/contexts/AuthContext';
import { leaveService } from '@/services/leaveService';
import { personnelService } from '@/services/personnelService';
import api from '@/services/api';
import PageHeader from '@/components/common/PageHeader';
import StatusBadge from '@/components/common/StatusBadge';
import DataTable, { type Column } from '@/components/DataTable';
import FormField from '@/components/FormField';
import type { LeaveRequestDto, CreateLeaveRequest, LeaveType, PersonnelDto } from '@/types';

interface Holiday { id: number; name: string; date: string; type: string; description?: string; }

const LEAVE_TYPES: { value: LeaveType; labelKey: string }[] = [
  { value: 'CASUAL_LEAVE', labelKey: 'leave.casualLeave' },
  { value: 'SICK_LEAVE', labelKey: 'leave.sickLeave' },
  { value: 'EARNED_LEAVE', labelKey: 'leave.earnedLeave' },
  { value: 'PATERNITY_LEAVE', labelKey: 'leave.privilegeLeave' },
  { value: 'WEEKLY_OFF', labelKey: 'leave.weeklyOff' },
  { value: 'COMMUTED_LEAVE', labelKey: 'leave.compensatoryOff' },
  { value: 'ABSENT', labelKey: 'leave.absent' },
];
const HOLIDAY_TYPES = ['NATIONAL', 'STATE', 'RESTRICTED', 'CUSTOM'];
const DAYS = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
const MONTH_KEYS = [
  'common.months.january', 'common.months.february', 'common.months.march',
  'common.months.april', 'common.months.may', 'common.months.june',
  'common.months.july', 'common.months.august', 'common.months.september',
  'common.months.october', 'common.months.november', 'common.months.december'
];
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

function getDaysInMonth(y: number, m: number) { return new Date(y, m + 1, 0).getDate(); }
function getFirstDay(y: number, m: number) { return new Date(y, m, 1).getDay(); }
function fmt(d: Date) { return d.toISOString().split('T')[0]; }
function isFutureOrToday(s: string) { return s >= fmt(new Date()); }

/** Maps backend status strings to StatusBadge display labels */
function mapStatusLabel(status: string): string {
  switch (status) {
    case 'PENDING': return 'Pending';
    case 'APPROVED': return 'Approved';
    case 'REJECTED': return 'Rejected';
    case 'CANCELLED': return 'Cancelled';
    case 'COMPLETED': return 'Completed';
    default: return status;
  }
}

const LeaveRequestsPage: React.FC = () => {
  const { t } = useTranslation();
  const { role } = useAuth();
  const [data, setData] = useState<LeaveRequestDto[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [toast, setToast] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [holidayDialogOpen, setHolidayDialogOpen] = useState(false);
  const [rejectDialogId, setRejectDialogId] = useState<number | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [cancelDialogRow, setCancelDialogRow] = useState<LeaveRequestDto | null>(null);
  const [saving, setSaving] = useState(false);
  const [personnelList, setPersonnelList] = useState<PersonnelDto[]>([]);
  const [holidays, setHolidays] = useState<Holiday[]>([]);
  const [holidayForm, setHolidayForm] = useState({ name: '', date: '', type: 'NATIONAL', description: '' });
  const [form, setForm] = useState<CreateLeaveRequest>({ personnelId: 0, leaveType: 'CASUAL_LEAVE', startDate: '', endDate: '', reason: '' });
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [viewRow, setViewRow] = useState<LeaveRequestDto | null>(null);
  const [closeLeaveRow, setCloseLeaveRow] = useState<LeaveRequestDto | null>(null);
  const [closeLeaveEndDate, setCloseLeaveEndDate] = useState('');
  const [closeLeaveComments, setCloseLeaveComments] = useState('');

  const today = new Date();
  const [calMonth, setCalMonth] = useState(today.getMonth());
  const [calYear, setCalYear] = useState(today.getFullYear());
  const [selectedDate, setSelectedDate] = useState<string>(fmt(today));

  const canApprove = role === 'ADMIN' || role === 'HIGHER_OFFICER';
  const canManageHolidays = role === 'ADMIN' || role === 'HIGHER_OFFICER';

  const fetchData = useCallback(async () => {
    setLoading(true);
    try { const r = await leaveService.list(undefined, 0, 500); setData(r.content); } catch { setError('Failed to load'); } finally { setLoading(false); }
  }, []);

  const fetchHolidays = useCallback(async () => {
    try { const r = await api.get<Holiday[]>('/api/holidays', { params: { year: calYear, month: calMonth + 1 } }); setHolidays(r.data); } catch { /* ignore */ }
  }, [calYear, calMonth]);

  useEffect(() => { fetchData(); }, [fetchData]);
  useEffect(() => { fetchHolidays(); }, [fetchHolidays]);
  useEffect(() => { if (dialogOpen && personnelList.length === 0) personnelService.list(undefined, 0, 1000).then(r => setPersonnelList(r.content)).catch(() => {}); }, [dialogOpen, personnelList.length]);

  const handleSubmit = async () => {
    setSaving(true); setError('');
    try { await leaveService.submit(form); setDialogOpen(false); setForm({ personnelId: 0, leaveType: 'CASUAL_LEAVE', startDate: '', endDate: '', reason: '' }); setToast('Leave request submitted'); fetchData(); }
    catch (err: unknown) { const e = err as { response?: { status?: number } }; setError(e.response?.status === 409 ? 'Overlapping leave exists' : 'Failed to submit'); }
    finally { setSaving(false); }
  };
  const handleApprove = async (id: number) => { try { await leaveService.approve(id); setToast('Approved'); fetchData(); } catch { setError('Failed'); } };
  const handleReject = async () => { if (!rejectDialogId) return; try { await leaveService.reject(rejectDialogId, rejectReason); setRejectDialogId(null); setRejectReason(''); setToast('Rejected'); fetchData(); } catch { setError('Failed'); } };
  const handleCancelConfirm = async () => { 
    if (!cancelDialogRow) return; 
    try { 
      await leaveService.cancel(cancelDialogRow.id); 
      setCancelDialogRow(null);
      setToast('Leave request cancelled'); 
      fetchData(); 
    } catch { 
      setError('Cannot cancel leave request'); 
    } 
  };

  const handleCloseLeaveConfirm = async () => {
    if (!closeLeaveRow || !closeLeaveEndDate) return;
    setSaving(true);
    try {
      await leaveService.close(closeLeaveRow.id, closeLeaveEndDate, closeLeaveComments);
      setCloseLeaveRow(null);
      setCloseLeaveEndDate('');
      setCloseLeaveComments('');
      setToast('Leave closed successfully');
      fetchData();
    } catch {
      setError('Failed to close leave');
    } finally {
      setSaving(false);
    }
  };

  const handleAddHoliday = async () => {
    try { await api.post('/api/holidays', holidayForm); setHolidayDialogOpen(false); setHolidayForm({ name: '', date: '', type: 'NATIONAL', description: '' }); setToast(t('leave.holidayAdded', 'Holiday added')); fetchHolidays(); }
    catch { setError(t('leave.failedAddHoliday', 'Failed to add holiday')); }
  };
  const handleDeleteHoliday = async (id: number) => {
    try { await api.delete(`/api/holidays/${id}`); setToast('Holiday removed'); fetchHolidays(); } catch { setError('Failed'); }
  };

  // Calendar helpers
  const leaveDays = useMemo(() => {
    const s = new Set<string>();
    data.forEach(r => { 
      if (r.status === 'APPROVED' || r.status === 'PENDING') { 
        const st = new Date(r.startDate + 'T00:00:00'); 
        // For open-ended sick leave (null endDate), use a far future date for calendar display
        const endDateStr = r.endDate || '2099-12-31';
        const en = new Date(endDateStr + 'T00:00:00'); 
        for (let d = new Date(st); d <= en; d.setDate(d.getDate() + 1)) s.add(fmt(d)); 
      } 
    });
    return s;
  }, [data]);
  const holidayDates = useMemo(() => new Set(holidays.map(h => h.date)), [holidays]);
  const leavesOnDate = useMemo(() => data.filter(r => (r.status === 'APPROVED' || r.status === 'PENDING') && r.startDate <= selectedDate && (r.endDate === null || r.endDate >= selectedDate)), [data, selectedDate]);

  const daysInMonth = getDaysInMonth(calYear, calMonth);
  const firstDay = getFirstDay(calYear, calMonth);
  const prevMonth = () => { if (calMonth === 0) { setCalMonth(11); setCalYear(y => y - 1); } else setCalMonth(m => m - 1); };
  const nextMonth = () => { if (calMonth === 11) { setCalMonth(0); setCalYear(y => y + 1); } else setCalMonth(m => m + 1); };

  // DataTable columns
  const columns: Column<LeaveRequestDto>[] = [
    {
      id: 'badgeId', labelKey: 'leave.badgeId', sortable: true, filterable: true, width: 100,
      render: (row) => (
        <Typography sx={{ fontSize: '0.85rem', fontWeight: 600, color: '#312e81' }}>{row.badgeId}</Typography>
      ),
    },
    {
      id: 'personnelName', labelKey: 'leave.personnelName', sortable: true, filterable: true, minWidth: 150,
    },
    {
      id: 'leaveType', labelKey: 'leave.leaveType', sortable: true, filterable: true,
      filterType: 'select',
      filterOptions: ['CASUAL_LEAVE', 'SICK_LEAVE', 'EARNED_LEAVE', 'PATERNITY_LEAVE', 'WEEKLY_OFF', 'COMMUTED_LEAVE', 'ABSENT'],
      render: (row) => (
        <Typography sx={{ fontSize: '0.82rem', color: '#6b7280' }}>{row.leaveType.replace(/_/g, ' ')}</Typography>
      ),
    },
    { id: 'startDate', labelKey: 'leave.startDate', sortable: true, width: 110 },
    { 
      id: 'endDate', labelKey: 'leave.endDate', sortable: true, width: 110,
      render: (row) => (
        <Typography sx={{ fontSize: '0.82rem', color: row.endDate ? '#374151' : '#f59e0b', fontWeight: row.endDate ? 400 : 600 }}>
          {row.endDate || t('leave.openEnded')}
        </Typography>
      ),
    },
    {
      id: 'status', labelKey: 'leave.status', sortable: true, filterable: true,
      filterType: 'select',
      filterOptions: ['PENDING', 'APPROVED', 'REJECTED', 'CANCELLED', 'COMPLETED'],
      render: (row) => (
        <StatusBadge status={mapStatusLabel(row.status)} size="small" showDot />
      ),
    },
  ];

  // Breadcrumbs and actions for PageHeader
  const breadcrumbs = [
    { label: 'Home', path: '/' },
    { label: 'Leave Requests' },
  ];

  const headerActions = [
    {
      label: t('leave.applyLeave', 'Apply Leave'),
      variant: 'primary' as const,
      icon: <AddIcon />,
      onClick: () => setDialogOpen(true),
    },
  ];

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', bgcolor: 'background.default' }}>
      {/* PageHeader replaces gradient banner */}
      <PageHeader
        title={t('leave.title', 'Leave Requests')}
        breadcrumbs={breadcrumbs}
        actions={headerActions}
      />

      {/* Main Content */}
      <Box sx={{ flex: 1, p: 3 }}>
        {error && <Alert severity="error" sx={{ mb: 2, borderRadius: 2 }} onClose={() => setError('')}>{error}</Alert>}

        {/* Calendar Section: Calendar (left) + Holidays (right) */}
        <Box sx={{ display: 'flex', gap: 0, mb: 3, bgcolor: '#fff', borderRadius: 3, border: '1px solid #f0ede6', overflow: 'hidden', flexDirection: { xs: 'column', md: 'row' } }}>
          {/* Calendar */}
          <Box sx={{ flex: '0 0 auto', width: { xs: '100%', md: 380 }, p: 2.5, borderRight: { xs: 'none', md: '1px solid #f0ede6' }, borderBottom: { xs: '1px solid #f0ede6', md: 'none' } }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <IconButton size="small" onClick={prevMonth} sx={{ color: '#6b6b80' }}><ChevronLeftIcon fontSize="small" /></IconButton>
              <Typography sx={{ fontWeight: 700, fontSize: '0.95rem', color: '#312e81' }}>{t(MONTH_KEYS[calMonth], MONTHS[calMonth])} {calYear}</Typography>
              <IconButton size="small" onClick={nextMonth} sx={{ color: '#6b6b80' }}><ChevronRightIcon fontSize="small" /></IconButton>
            </Box>
            {/* Day headers */}
            <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', mb: 1 }}>
              {DAYS.map(d => <Typography key={d} align="center" sx={{ fontSize: '0.65rem', fontWeight: 700, color: '#c4a44a', textTransform: 'uppercase' }}>{d}</Typography>)}
            </Box>
            {/* Days grid */}
            <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: '3px' }}>
              {Array.from({ length: firstDay }).map((_, i) => <Box key={`e${i}`} sx={{ height: 38 }} />)}
              {Array.from({ length: daysInMonth }).map((_, i) => {
                const day = i + 1;
                const ds = `${calYear}-${String(calMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                const isToday = ds === fmt(today);
                const isSel = ds === selectedDate;
                const hasLeave = leaveDays.has(ds);
                const isHoliday = holidayDates.has(ds);
                return (
                  <Box key={day} onClick={() => setSelectedDate(ds)} sx={{
                    height: 38, width: 38, mx: 'auto', display: 'flex', alignItems: 'center', justifyContent: 'center',
                    borderRadius: 2, cursor: 'pointer', position: 'relative', fontSize: '0.8rem',
                    fontWeight: isToday || isSel ? 700 : 400,
                    bgcolor: isSel ? '#312e81' : isToday ? '#f0f0ff' : isHoliday ? '#fef3c7' : 'transparent',
                    color: isSel ? '#fff' : isToday ? '#312e81' : isHoliday ? '#92400e' : '#374151',
                    transition: 'all 0.15s',
                    '&:hover': { bgcolor: isSel ? '#312e81' : '#f5f3ee', transform: 'scale(1.08)' },
                  }}>
                    {day}
                    {hasLeave && <Box sx={{ position: 'absolute', bottom: 3, left: '50%', ml: '-2px', width: 4, height: 4, borderRadius: '50%', bgcolor: isSel ? '#c4a44a' : '#ef4444' }} />}
                    {isHoliday && !hasLeave && <Box sx={{ position: 'absolute', bottom: 3, left: '50%', ml: '-2px', width: 4, height: 4, borderRadius: '50%', bgcolor: isSel ? '#c4a44a' : '#d97706' }} />}
                  </Box>
                );
              })}
            </Box>
            {/* Legend */}
            <Box sx={{ display: 'flex', gap: 2, mt: 2, pt: 1.5, borderTop: '1px solid #f5f3ee' }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}><Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: '#ef4444' }} /><Typography sx={{ fontSize: '0.65rem', color: '#6b6b80' }}>{t('leave.onLeave')}</Typography></Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}><Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: '#d97706' }} /><Typography sx={{ fontSize: '0.65rem', color: '#6b6b80' }}>{t('leave.holiday')}</Typography></Box>
            </Box>
            {/* On Leave section */}
            {leavesOnDate.length > 0 && (
              <Box sx={{ mt: 2, pt: 1.5, borderTop: '1px solid #f5f3ee' }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.8, mb: 1 }}>
                  <PeopleIcon sx={{ fontSize: 14, color: '#312e81' }} />
                  <Typography sx={{ fontSize: '0.72rem', fontWeight: 700, color: '#312e81' }}>On Leave ({leavesOnDate.length})</Typography>
                </Box>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                  {leavesOnDate.slice(0, 6).map(lr => (
                    <Chip key={lr.id} size="small" label={`${lr.badgeId}`} sx={{ height: 22, fontSize: '0.65rem', fontWeight: 600, bgcolor: '#fef3c7', color: '#92400e' }} />
                  ))}
                  {leavesOnDate.length > 6 && <Chip size="small" label={`+${leavesOnDate.length - 6}`} sx={{ height: 22, fontSize: '0.65rem', bgcolor: '#f3f4f6', color: '#6b7280' }} />}
                </Box>
              </Box>
            )}
          </Box>

          {/* Holidays Panel (right side) */}
          <Box sx={{ flex: 1, p: 2.5, display: 'flex', flexDirection: 'column' }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <CelebrationIcon sx={{ fontSize: 18, color: '#c4a44a' }} />
                <Typography sx={{ fontSize: '0.9rem', fontWeight: 700, color: '#312e81' }}>{t('leave.holidays')} — {t(MONTH_KEYS[calMonth], MONTHS[calMonth])}</Typography>
              </Box>
              {canManageHolidays && (
                <Tooltip title={t('leave.addHoliday', 'Add Holiday')} arrow>
                  <IconButton size="small" onClick={() => setHolidayDialogOpen(true)} sx={{ bgcolor: '#f0f0ff', '&:hover': { bgcolor: '#e0e0ff' } }}>
                    <AddIcon sx={{ fontSize: 16, color: '#312e81' }} />
                  </IconButton>
                </Tooltip>
              )}
            </Box>

            {holidays.length === 0 ? (
              <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', color: '#9ca3af' }}>
                <CelebrationIcon sx={{ fontSize: 32, color: '#e5e7eb', mb: 1 }} />
                <Typography sx={{ fontSize: '0.8rem' }}>{t('leave.noHolidaysThisMonth', 'No holidays this month')}</Typography>
                {canManageHolidays && <Typography sx={{ fontSize: '0.7rem', mt: 0.5 }}>{t('leave.clickToAdd', 'Click + to add one')}</Typography>}
              </Box>
            ) : (
              <Box sx={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 1 }}>
                {holidays.map(h => (
                  <Box key={h.id} sx={{ display: 'flex', alignItems: 'center', gap: 1.5, p: 1.5, borderRadius: 2, bgcolor: '#fafaf8', border: '1px solid #f5f3ee', transition: 'all 0.15s', '&:hover': { borderColor: '#f0ede6', bgcolor: '#f5f3ee' } }}>
                    <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: '#fef3c7', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      <Typography sx={{ fontSize: '0.9rem', fontWeight: 700, color: '#92400e', lineHeight: 1 }}>{new Date(h.date + 'T00:00:00').getDate()}</Typography>
                      <Typography sx={{ fontSize: '0.55rem', color: '#b45309', fontWeight: 600 }}>{DAYS[new Date(h.date + 'T00:00:00').getDay()]}</Typography>
                    </Box>
                    <Box sx={{ flex: 1, minWidth: 0 }}>
                      <Typography sx={{ fontSize: '0.78rem', fontWeight: 600, color: '#374151', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{h.name}</Typography>
                      <Typography sx={{ fontSize: '0.65rem', color: '#9ca3af' }}>{h.type}</Typography>
                    </Box>
                    {canManageHolidays && (
                      <IconButton size="small" onClick={() => handleDeleteHoliday(h.id)} sx={{ opacity: 0.5, '&:hover': { opacity: 1, color: '#dc2626' } }}>
                        <DeleteOutlineIcon sx={{ fontSize: 16 }} />
                      </IconButton>
                    )}
                  </Box>
                ))}
              </Box>
            )}
          </Box>
        </Box>

        {/* Data Table Section */}
        {loading ? (
          <Box>
            {/* Table skeleton */}
            <Skeleton variant="rectangular" width="100%" height={48} sx={{ borderRadius: 2, mb: 1 }} />
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} variant="rectangular" width="100%" height={40} sx={{ borderRadius: 1, mb: 0.5 }} />
            ))}
          </Box>
        ) : data.length === 0 ? (
          <Box sx={{
            display: 'flex', flexDirection: 'column', alignItems: 'center',
            justifyContent: 'center', py: 8, color: '#9ca3af',
          }}>
            <EventBusyIcon sx={{ fontSize: 48, mb: 2, opacity: 0.5 }} />
            <Typography sx={{ fontSize: '1rem', fontWeight: 500 }}>
              {t('leave.noLeaveRequests', 'No leave requests found')}
            </Typography>
            <Typography sx={{ fontSize: '0.85rem', mt: 0.5, color: '#b0b0b0' }}>
              {t('leave.noRecordsHint', 'Submit a leave request to get started')}
            </Typography>
          </Box>
        ) : (
          <DataTable<LeaveRequestDto>
            columns={columns}
            data={data}
            keyField="id"
            searchable
            searchPlaceholderKey="leave.searchPlaceholder"
            dense
            actions={(row) => (
              <Box sx={{ display: 'inline-flex', gap: 0.5 }}>
                {/* View button — always visible */}
                <Tooltip title={t('app.view', 'View')} arrow>
                  <IconButton
                    size="small"
                    onClick={() => { setViewRow(row); setViewDialogOpen(true); }}
                    sx={{ width: 28, height: 28, bgcolor: '#f0f0ff', '&:hover': { bgcolor: '#e0e0ff' } }}
                  >
                    <VisibilityIcon sx={{ fontSize: 14, color: '#312e81' }} />
                  </IconButton>
                </Tooltip>
                {/* Approve/Reject — only for Pending requests */}
                {canApprove && row.status === 'PENDING' && (
                  <>
                    <Tooltip title={t('leave.approve', 'Approve')} arrow>
                      <IconButton
                        size="small"
                        onClick={() => handleApprove(row.id)}
                        sx={{ width: 28, height: 28, bgcolor: '#d1fae5', '&:hover': { bgcolor: '#a7f3d0' } }}
                      >
                        <CheckIcon sx={{ fontSize: 14, color: '#065f46' }} />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title={t('leave.reject', 'Reject')} arrow>
                      <IconButton
                        size="small"
                        onClick={() => setRejectDialogId(row.id)}
                        sx={{ width: 28, height: 28, bgcolor: '#fee2e2', '&:hover': { bgcolor: '#fecaca' } }}
                      >
                        <CloseIcon sx={{ fontSize: 14, color: '#991b1b' }} />
                      </IconButton>
                    </Tooltip>
                  </>
                )}
                {/* Cancel — for Pending or Approved leaves (not already cancelled/rejected) */}
                {(row.status === 'PENDING' || row.status === 'APPROVED') && (
                  <Tooltip title={t('leave.cancel', 'Cancel')} arrow>
                    <IconButton
                      size="small"
                      onClick={() => setCancelDialogRow(row)}
                      sx={{ width: 28, height: 28, bgcolor: '#fee2e2', '&:hover': { bgcolor: '#fecaca' } }}
                    >
                      <CancelIcon sx={{ fontSize: 14, color: '#dc2626' }} />
                    </IconButton>
                  </Tooltip>
                )}
                {/* Close Leave — for Approved leaves without end date */}
                {row.status === 'APPROVED' && !row.endDate && (
                  <Tooltip title="Close Leave (Set End Date)" arrow>
                    <IconButton
                      size="small"
                      onClick={() => { setCloseLeaveRow(row); setCloseLeaveEndDate(''); setCloseLeaveComments(''); }}
                      sx={{ width: 28, height: 28, bgcolor: '#dbeafe', '&:hover': { bgcolor: '#bfdbfe' } }}
                    >
                      <EventAvailableIcon sx={{ fontSize: 14, color: '#1d4ed8' }} />
                    </IconButton>
                  </Tooltip>
                )}
              </Box>
            )}
          />
        )}
      </Box>

      {/* View Leave Request Dialog */}
      <Dialog open={viewDialogOpen} onClose={() => setViewDialogOpen(false)} maxWidth="sm" fullWidth PaperProps={{ sx: { borderRadius: 3 } }}>
        <Box sx={{ px: 3, pt: 3, pb: 1 }}>
          <Typography sx={{ fontSize: '1.1rem', fontWeight: 700, color: '#312e81' }}>
            {t('leave.viewRequest', 'Leave Request Details')}
          </Typography>
        </Box>
        <DialogContent sx={{ px: 3 }}>
          {viewRow && (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 1 }}>
              <Box sx={{ display: 'flex', gap: 2 }}>
                <Box sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: '0.72rem', color: '#9ca3af', fontWeight: 600, textTransform: 'uppercase' }}>Badge ID</Typography>
                  <Typography sx={{ fontSize: '0.9rem', fontWeight: 600, color: '#312e81' }}>{viewRow.badgeId}</Typography>
                </Box>
                <Box sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: '0.72rem', color: '#9ca3af', fontWeight: 600, textTransform: 'uppercase' }}>Personnel</Typography>
                  <Typography sx={{ fontSize: '0.9rem', color: '#374151' }}>{viewRow.personnelName}</Typography>
                </Box>
              </Box>
              <Box sx={{ display: 'flex', gap: 2 }}>
                <Box sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: '0.72rem', color: '#9ca3af', fontWeight: 600, textTransform: 'uppercase' }}>Leave Type</Typography>
                  <Typography sx={{ fontSize: '0.9rem', color: '#374151' }}>{viewRow.leaveType.replace(/_/g, ' ')}</Typography>
                </Box>
                <Box sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: '0.72rem', color: '#9ca3af', fontWeight: 600, textTransform: 'uppercase' }}>Status</Typography>
                  <StatusBadge status={mapStatusLabel(viewRow.status)} size="small" showDot />
                </Box>
              </Box>
              <Box sx={{ display: 'flex', gap: 2 }}>
                <Box sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: '0.72rem', color: '#9ca3af', fontWeight: 600, textTransform: 'uppercase' }}>Start Date</Typography>
                  <Typography sx={{ fontSize: '0.9rem', color: '#374151' }}>{viewRow.startDate}</Typography>
                </Box>
                <Box sx={{ flex: 1 }}>
                  <Typography sx={{ fontSize: '0.72rem', color: '#9ca3af', fontWeight: 600, textTransform: 'uppercase' }}>End Date</Typography>
                  <Typography sx={{ fontSize: '0.9rem', color: viewRow.endDate ? '#374151' : '#f59e0b', fontWeight: viewRow.endDate ? 400 : 600 }}>{viewRow.endDate || t('leave.openEnded')}</Typography>
                </Box>
              </Box>
              {viewRow.reason && (
                <Box>
                  <Typography sx={{ fontSize: '0.72rem', color: '#9ca3af', fontWeight: 600, textTransform: 'uppercase' }}>Reason</Typography>
                  <Typography sx={{ fontSize: '0.9rem', color: '#374151' }}>{viewRow.reason}</Typography>
                </Box>
              )}
              {viewRow.rejectionReason && (
                <Box>
                  <Typography sx={{ fontSize: '0.72rem', color: '#9ca3af', fontWeight: 600, textTransform: 'uppercase' }}>Rejection Reason</Typography>
                  <Typography sx={{ fontSize: '0.9rem', color: '#dc2626' }}>{viewRow.rejectionReason}</Typography>
                </Box>
              )}
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2.5 }}>
          <Button onClick={() => setViewDialogOpen(false)} sx={{ textTransform: 'none', color: '#6b6b80' }}>{t('app.close', 'Close')}</Button>
        </DialogActions>
      </Dialog>

      {/* Cancel Leave Confirmation Dialog */}
      <Dialog 
        open={cancelDialogRow !== null} 
        onClose={() => setCancelDialogRow(null)} 
        maxWidth="xs" 
        fullWidth 
        PaperProps={{ sx: { borderRadius: 3 } }}
      >
        <Box sx={{ px: 3, pt: 3, pb: 1 }}>
          <Typography sx={{ fontSize: '1.1rem', fontWeight: 700, color: '#dc2626' }}>
            {t('leave.cancelLeave', 'Cancel Leave Request')}
          </Typography>
        </Box>
        <DialogContent sx={{ px: 3 }}>
          {cancelDialogRow && (
            <Box>
              <Typography sx={{ fontSize: '0.9rem', color: '#374151', mb: 2 }}>
                Are you sure you want to cancel this leave request?
              </Typography>
              <Box sx={{ bgcolor: '#f9fafb', borderRadius: 2, p: 2, border: '1px solid #e5e7eb' }}>
                <Box sx={{ display: 'flex', gap: 2, mb: 1.5 }}>
                  <Box sx={{ flex: 1 }}>
                    <Typography sx={{ fontSize: '0.68rem', color: '#9ca3af', fontWeight: 600, textTransform: 'uppercase' }}>Personnel</Typography>
                    <Typography sx={{ fontSize: '0.85rem', fontWeight: 600, color: '#312e81' }}>{cancelDialogRow.personnelName}</Typography>
                  </Box>
                  <Box sx={{ flex: 1 }}>
                    <Typography sx={{ fontSize: '0.68rem', color: '#9ca3af', fontWeight: 600, textTransform: 'uppercase' }}>Badge ID</Typography>
                    <Typography sx={{ fontSize: '0.85rem', color: '#374151' }}>{cancelDialogRow.badgeId}</Typography>
                  </Box>
                </Box>
                <Box sx={{ display: 'flex', gap: 2, mb: 1.5 }}>
                  <Box sx={{ flex: 1 }}>
                    <Typography sx={{ fontSize: '0.68rem', color: '#9ca3af', fontWeight: 600, textTransform: 'uppercase' }}>Leave Type</Typography>
                    <Typography sx={{ fontSize: '0.85rem', color: '#374151' }}>{cancelDialogRow.leaveType.replace(/_/g, ' ')}</Typography>
                  </Box>
                  <Box sx={{ flex: 1 }}>
                    <Typography sx={{ fontSize: '0.68rem', color: '#9ca3af', fontWeight: 600, textTransform: 'uppercase' }}>Status</Typography>
                    <StatusBadge status={mapStatusLabel(cancelDialogRow.status)} size="small" showDot />
                  </Box>
                </Box>
                <Box sx={{ display: 'flex', gap: 2 }}>
                  <Box sx={{ flex: 1 }}>
                    <Typography sx={{ fontSize: '0.68rem', color: '#9ca3af', fontWeight: 600, textTransform: 'uppercase' }}>Start Date</Typography>
                    <Typography sx={{ fontSize: '0.85rem', color: '#374151' }}>{cancelDialogRow.startDate}</Typography>
                  </Box>
                  <Box sx={{ flex: 1 }}>
                    <Typography sx={{ fontSize: '0.68rem', color: '#9ca3af', fontWeight: 600, textTransform: 'uppercase' }}>End Date</Typography>
                    <Typography sx={{ fontSize: '0.85rem', color: '#374151' }}>{cancelDialogRow.endDate || t('leave.openEnded')}</Typography>
                  </Box>
                </Box>
              </Box>
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2.5, gap: 1 }}>
          <Button 
            onClick={() => setCancelDialogRow(null)} 
            sx={{ textTransform: 'none', color: '#6b6b80' }}
          >
            {t('app.back', 'Back')}
          </Button>
          <Button 
            onClick={handleCancelConfirm}
            variant="contained"
            sx={{ 
              textTransform: 'none', 
              bgcolor: '#dc2626', 
              '&:hover': { bgcolor: '#b91c1c' },
              fontWeight: 600,
            }}
          >
            {t('leave.confirmCancel', 'Yes, Cancel Leave')}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Apply Leave Dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth PaperProps={{ sx: { borderRadius: 3 } }}>
        <Box sx={{ px: 3, pt: 3, pb: 1 }}><Typography sx={{ fontSize: '1.1rem', fontWeight: 700, color: '#312e81' }}>{t('leave.applyForLeave', 'Apply for Leave')}</Typography><Typography sx={{ fontSize: '0.72rem', color: '#9ca3af' }}>{t('leave.fillDetails', 'Fill in the details below')}</Typography></Box>
        <DialogContent sx={{ px: 3 }}>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 1 }}>
            <Box>
              <Typography sx={{ fontSize: '0.75rem', fontWeight: 600, color: '#4b5563', mb: 0.5 }}>
                {t('personnel.personName')} *
              </Typography>
              <Autocomplete
                options={personnelList}
                getOptionLabel={(option) => option.personName ? `${option.personName} (${option.badgeId || ''})` : option.badgeId || ''}
                value={personnelList.find(p => p.id === form.personnelId) || null}
                onChange={(_, newValue) => setForm(p => ({ ...p, personnelId: newValue ? newValue.id : 0 }))}
                isOptionEqualToValue={(option, value) => option.id === value.id}
                filterOptions={(options, { inputValue }) => {
                  const query = inputValue.toLowerCase();
                  return options.filter(o =>
                    (o.personName || '').toLowerCase().includes(query) ||
                    (o.badgeId || '').toLowerCase().includes(query) ||
                    (o.designation || '').toLowerCase().includes(query)
                  );
                }}
                renderOption={(props, option) => (
                  <ListItem {...props} key={option.id} sx={{ py: 0.75, px: 1.5, borderBottom: '1px solid #f3f4f6' }}>
                    <ListItemText
                      primary={
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Typography sx={{ fontSize: '0.82rem', fontWeight: 500 }}>
                            {option.personName || option.badgeId}
                          </Typography>
                          {option.designation && (
                            <Chip
                              label={option.designation}
                              size="small"
                              sx={{
                                height: 18,
                                fontSize: '0.65rem',
                                fontWeight: 600,
                                bgcolor: '#ede9fe',
                                color: '#5b21b6',
                              }}
                            />
                          )}
                        </Box>
                      }
                      secondary={
                        <Typography sx={{ fontSize: '0.7rem', color: '#9ca3af' }}>
                          {option.badgeId}{option.section ? ` • Section ${option.section}` : ''}
                        </Typography>
                      }
                    />
                  </ListItem>
                )}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    placeholder="Search by name, badge ID, or designation..."
                    size="small"
                    InputProps={{
                      ...params.InputProps,
                      startAdornment: (
                        <>
                          <InputAdornment position="start">
                            <SearchIcon sx={{ fontSize: 18, color: '#9ca3af' }} />
                          </InputAdornment>
                          {params.InputProps.startAdornment}
                        </>
                      ),
                    }}
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        borderRadius: 1.5,
                        fontSize: '0.85rem',
                        '& fieldset': { borderColor: '#e5e7eb' },
                        '&:hover fieldset': { borderColor: '#0d9488' },
                        '&.Mui-focused fieldset': { borderColor: '#312e81', borderWidth: 1.5 },
                      },
                    }}
                  />
                )}
                noOptionsText="No personnel found"
                disablePortal
                slotProps={{
                  paper: {
                    sx: {
                      mt: 0.5,
                      borderRadius: 2,
                      boxShadow: '0 4px 20px rgba(0,0,0,0.12)',
                      border: '1px solid #e5e7eb',
                    },
                  },
                  listbox: {
                    sx: {
                      maxHeight: 220,
                      py: 0.5,
                    },
                  },
                }}
                fullWidth
              />
            </Box>
            <FormField labelKey="leave.leaveType" select required value={form.leaveType} onChange={e => setForm(p => ({ ...p, leaveType: e.target.value as LeaveType }))} SelectProps={{ MenuProps: { disablePortal: true, PaperProps: { sx: { maxHeight: 220, borderRadius: 2, boxShadow: '0 4px 20px rgba(0,0,0,0.12)' } } } }}>{LEAVE_TYPES.map(lt => <MenuItem key={lt.value} value={lt.value}>{t(lt.labelKey)}</MenuItem>)}</FormField>
            <Box sx={{ display: 'flex', gap: 2 }}>
              <FormField labelKey="leave.startDate" type="date" required fullWidth value={form.startDate} onChange={e => setForm(p => ({ ...p, startDate: e.target.value }))} InputLabelProps={{ shrink: true }} />
              <FormField labelKey="leave.endDate" type="date" fullWidth value={form.endDate} onChange={e => setForm(p => ({ ...p, endDate: e.target.value }))} InputLabelProps={{ shrink: true }} helperText={t('assignDuties.leavePanel.leaveBlankForOpenEnded')} />
            </Box>
            <FormField labelKey="leave.reason" multiline rows={3} value={form.reason} onChange={e => setForm(p => ({ ...p, reason: e.target.value }))} />
          </Box>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2.5 }}>
          <Button onClick={() => setDialogOpen(false)} sx={{ textTransform: 'none', color: '#6b6b80' }}>{t('app.cancel', 'Cancel')}</Button>
          <Button
            onClick={handleSubmit}
            disabled={!form.personnelId || !form.startDate || saving}
            variant="contained"
            sx={{ textTransform: 'none', borderRadius: 2 }}
          >
            {saving ? t('app.saving', 'Saving...') : t('leave.submitRequest', 'Submit Leave')}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Reject Dialog */}
      <Dialog open={rejectDialogId != null} onClose={() => setRejectDialogId(null)} maxWidth="xs" fullWidth PaperProps={{ sx: { borderRadius: 3 } }}>
        <Box sx={{ px: 3, pt: 3, pb: 1 }}><Typography sx={{ fontSize: '1rem', fontWeight: 700, color: '#dc2626' }}>{t('leave.reject', 'Reject Leave')}</Typography></Box>
        <DialogContent sx={{ px: 3 }}><TextField label={t('leave.reason', 'Reason')} fullWidth multiline rows={3} size="small" value={rejectReason} onChange={e => setRejectReason(e.target.value)} sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }} /></DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}><Button onClick={() => setRejectDialogId(null)} sx={{ textTransform: 'none', color: '#6b6b80' }}>{t('app.cancel', 'Cancel')}</Button><Button variant="contained" color="error" onClick={handleReject} sx={{ textTransform: 'none', borderRadius: 2 }}>{t('leave.reject', 'Reject')}</Button></DialogActions>
      </Dialog>

      {/* Add Holiday Dialog */}
      <Dialog open={holidayDialogOpen} onClose={() => setHolidayDialogOpen(false)} maxWidth="xs" fullWidth PaperProps={{ sx: { borderRadius: 3 } }}>
        <Box sx={{ px: 3, pt: 3, pb: 1 }}><Typography sx={{ fontSize: '1rem', fontWeight: 700, color: '#312e81' }}>{t('leave.addHoliday', 'Add Holiday')}</Typography></Box>
        <DialogContent sx={{ px: 3 }}>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 1 }}>
            <TextField size="small" label={t('leave.holidayName', 'Holiday Name')} required fullWidth value={holidayForm.name} onChange={e => setHolidayForm(p => ({ ...p, name: e.target.value }))} sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }} />
            <TextField size="small" label={t('leave.holidayDate', 'Date')} type="date" required fullWidth value={holidayForm.date} onChange={e => setHolidayForm(p => ({ ...p, date: e.target.value }))} InputLabelProps={{ shrink: true }} sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }} />
            <TextField size="small" label={t('leave.holidayType', 'Type')} select required fullWidth value={holidayForm.type} onChange={e => setHolidayForm(p => ({ ...p, type: e.target.value }))} sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }}>
              {HOLIDAY_TYPES.map(ht => <MenuItem key={ht} value={ht}>{ht}</MenuItem>)}
            </TextField>
            <TextField size="small" label={t('leave.holidayDescription', 'Description (optional)')} fullWidth multiline rows={2} value={holidayForm.description} onChange={e => setHolidayForm(p => ({ ...p, description: e.target.value }))} sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }} />
          </Box>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setHolidayDialogOpen(false)} sx={{ textTransform: 'none', color: '#6b6b80' }}>{t('app.cancel', 'Cancel')}</Button>
          <Button
            onClick={handleAddHoliday}
            disabled={!holidayForm.name || !holidayForm.date}
            variant="contained"
            sx={{ textTransform: 'none', borderRadius: 2 }}
          >
            {t('leave.addHoliday', 'Add Holiday')}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Close Leave Dialog */}
      <Dialog 
        open={closeLeaveRow !== null} 
        onClose={() => setCloseLeaveRow(null)} 
        maxWidth="xs" 
        fullWidth 
        PaperProps={{ sx: { borderRadius: 3 } }}
      >
        <Box sx={{ px: 3, pt: 3, pb: 1 }}>
          <Typography sx={{ fontSize: '1.1rem', fontWeight: 700, color: '#1d4ed8' }}>
            {t('assignDuties.closeLeaveDialog.title')}
          </Typography>
          <Typography sx={{ fontSize: '0.75rem', color: '#6b7280', mt: 0.5 }}>
            {t('leave.closeLeaveSubtitle', 'Set the end date to close this open-ended leave')}
          </Typography>
        </Box>
        <DialogContent sx={{ px: 3 }}>
          {closeLeaveRow && (
            <Box>
              <Box sx={{ bgcolor: '#f9fafb', borderRadius: 2, p: 2, border: '1px solid #e5e7eb', mb: 2 }}>
                <Box sx={{ display: 'flex', gap: 2, mb: 1.5 }}>
                  <Box sx={{ flex: 1 }}>
                    <Typography sx={{ fontSize: '0.68rem', color: '#9ca3af', fontWeight: 600, textTransform: 'uppercase' }}>{t('assignDuties.closeLeaveDialog.personnel')}</Typography>
                    <Typography sx={{ fontSize: '0.85rem', fontWeight: 600, color: '#312e81' }}>{closeLeaveRow.personnelName}</Typography>
                  </Box>
                  <Box sx={{ flex: 1 }}>
                    <Typography sx={{ fontSize: '0.68rem', color: '#9ca3af', fontWeight: 600, textTransform: 'uppercase' }}>{t('assignDuties.closeLeaveDialog.leaveType')}</Typography>
                    <Typography sx={{ fontSize: '0.85rem', color: '#374151' }}>{closeLeaveRow.leaveType.replace(/_/g, ' ')}</Typography>
                  </Box>
                </Box>
                <Box>
                  <Typography sx={{ fontSize: '0.68rem', color: '#9ca3af', fontWeight: 600, textTransform: 'uppercase' }}>{t('assignDuties.closeLeaveDialog.startDate')}</Typography>
                  <Typography sx={{ fontSize: '0.85rem', color: '#374151' }}>{closeLeaveRow.startDate}</Typography>
                </Box>
              </Box>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <TextField
                  label={t('assignDuties.closeLeaveDialog.endDate')}
                  type="date"
                  size="small"
                  required
                  fullWidth
                  value={closeLeaveEndDate}
                  onChange={e => setCloseLeaveEndDate(e.target.value)}
                  InputLabelProps={{ shrink: true }}
                  inputProps={{ min: closeLeaveRow.startDate }}
                  sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }}
                />
                <TextField
                  label={t('assignDuties.closeLeaveDialog.comments')}
                  size="small"
                  fullWidth
                  multiline
                  rows={2}
                  value={closeLeaveComments}
                  onChange={e => setCloseLeaveComments(e.target.value)}
                  placeholder={t('assignDuties.closeLeaveDialog.commentsPlaceholder')}
                  sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }}
                />
              </Box>
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2.5, gap: 1 }}>
          <Button 
            onClick={() => setCloseLeaveRow(null)} 
            sx={{ textTransform: 'none', color: '#6b6b80' }}
          >
            {t('app.cancel')}
          </Button>
          <Button 
            onClick={handleCloseLeaveConfirm}
            disabled={!closeLeaveEndDate || saving}
            variant="contained"
            sx={{ 
              textTransform: 'none', 
              bgcolor: '#1d4ed8', 
              '&:hover': { bgcolor: '#1e40af' },
              fontWeight: 600,
            }}
          >
            {saving ? t('leave.closing', 'Closing...') : t('assignDuties.closeLeaveDialog.closeLeave')}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar open={!!toast} autoHideDuration={3000} onClose={() => setToast('')} message={toast} anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }} />
    </Box>
  );
};

export default LeaveRequestsPage;

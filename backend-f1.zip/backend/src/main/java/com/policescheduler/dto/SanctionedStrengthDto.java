package com.policescheduler.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SanctionedStrengthDto {
    private Long id;
    private String designation;
    private Integer displayOrder;
    private Integer sanctionedCount;
}

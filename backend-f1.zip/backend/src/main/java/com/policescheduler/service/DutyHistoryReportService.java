package com.policescheduler.service;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.policescheduler.entity.DutyHistory;
import com.policescheduler.entity.Personnel;
import com.policescheduler.repository.DutyHistoryRepository;
import com.policescheduler.repository.PersonnelRepository;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Service for generating PDF and Excel reports for duty history.
 */
@Service
public class DutyHistoryReportService {

    private final DutyHistoryRepository dutyHistoryRepository;
    private final PersonnelRepository personnelRepository;

    private static final com.lowagie.text.Font TITLE_FONT = new com.lowagie.text.Font(
            com.lowagie.text.Font.HELVETICA, 14, com.lowagie.text.Font.BOLD);
    private static final com.lowagie.text.Font SUBTITLE_FONT = new com.lowagie.text.Font(
            com.lowagie.text.Font.HELVETICA, 10, com.lowagie.text.Font.BOLD);
    private static final com.lowagie.text.Font INFO_FONT = new com.lowagie.text.Font(
            com.lowagie.text.Font.HELVETICA, 9, com.lowagie.text.Font.NORMAL);
    private static final com.lowagie.text.Font HEADER_FONT = new com.lowagie.text.Font(
            com.lowagie.text.Font.HELVETICA, 8, com.lowagie.text.Font.BOLD, Color.BLACK);
    private static final com.lowagie.text.Font CELL_FONT = new com.lowagie.text.Font(
            com.lowagie.text.Font.HELVETICA, 7, com.lowagie.text.Font.NORMAL, Color.BLACK);
    private static final com.lowagie.text.Font FOOTER_FONT = new com.lowagie.text.Font(
            com.lowagie.text.Font.HELVETICA, 7, com.lowagie.text.Font.ITALIC, Color.GRAY);

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd-MMM-yyyy");

    public DutyHistoryReportService(DutyHistoryRepository dutyHistoryRepository,
                                     PersonnelRepository personnelRepository) {
        this.dutyHistoryRepository = dutyHistoryRepository;
        this.personnelRepository = personnelRepository;
    }

    /**
     * Generate PDF report for a person's duty history.
     * If startDate/endDate are null, returns all records.
     */
    public byte[] generatePdf(Long personId, LocalDate startDate, LocalDate endDate) {
        Personnel person = personnelRepository.findById(personId)
                .orElseThrow(() -> new IllegalArgumentException("Personnel not found: " + personId));

        List<DutyHistory> records = getRecords(personId, startDate, endDate);

        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            Document document = new Document(PageSize.A4.rotate(), 15, 15, 20, 20);
            PdfWriter.getInstance(document, baos);
            document.open();

            // Title
            Paragraph title = new Paragraph("Duty History Report", TITLE_FONT);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);
            document.add(new Paragraph("\n"));

            // Personnel Info
            Paragraph personInfo = new Paragraph();
            personInfo.setFont(SUBTITLE_FONT);
            personInfo.add(new Chunk("Name: " + person.getPersonName()));
            personInfo.add(new Chunk("    |    Badge ID: " + person.getBadgeId()));
            if (person.getDesignation() != null) {
                personInfo.add(new Chunk("    |    Designation: " + person.getDesignation()));
            }
            if (person.getSection() != null) {
                personInfo.add(new Chunk("    |    Section: " + person.getSection()));
            }
            document.add(personInfo);

            // Date Range Info
            Paragraph dateInfo = new Paragraph();
            dateInfo.setFont(INFO_FONT);
            if (startDate != null && endDate != null) {
                dateInfo.add("Period: " + startDate.format(DATE_FORMATTER) + " to " + endDate.format(DATE_FORMATTER));
            } else {
                dateInfo.add("Period: All Records");
            }
            document.add(dateInfo);
            document.add(new Paragraph("\n"));

            // Table
            PdfPTable table = new PdfPTable(9);
            table.setWidthPercentage(100);
            table.setWidths(new float[]{4, 12, 10, 14, 14, 8, 10, 14, 12});

            // Table headers
            String[] headers = {"#", "Date", "Section", "Duty Type", "Duty Location", "Shift", "Status", "Adhoc Duty", "Leave Type"};
            for (String h : headers) {
                PdfPCell cell = new PdfPCell(new Phrase(h, HEADER_FONT));
                cell.setBackgroundColor(new Color(79, 70, 229)); // Indigo
                cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                cell.setPadding(5);
                cell.setBorderWidth(0.5f);
                table.addCell(cell);
            }

            // Data rows
            int idx = 1;
            for (DutyHistory record : records) {
                Color rowBg = getRowBackgroundColor(record, idx);
                
                addCell(table, String.valueOf(idx++), rowBg);
                addCell(table, record.getRecordDate() != null ? record.getRecordDate().format(DATE_FORMATTER) : "", rowBg);
                addCell(table, record.getSection() != null ? record.getSection() : "", rowBg);
                addCell(table, record.getDutyType() != null ? record.getDutyType() : "", rowBg);
                addCell(table, record.getDutyLocation() != null ? record.getDutyLocation() : 
                        (record.getWorksAt() != null ? record.getWorksAt() : ""), rowBg);
                addCell(table, record.getShiftType() != null ? record.getShiftType() : "", rowBg);
                addCell(table, record.getStatus() != null ? record.getStatus() : "", rowBg);
                addCell(table, record.getAdhocDuty() != null ? record.getAdhocDuty() : "", rowBg);
                addCell(table, record.getLeaveType() != null ? record.getLeaveType().replace("_", " ") : "", rowBg);
            }

            document.add(table);
            document.add(new Paragraph("\n"));

            // Footer
            String generated = "Generated on " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm"));
            Paragraph footer = new Paragraph(generated + "  |  Total Records: " + records.size(), FOOTER_FONT);
            footer.setAlignment(Element.ALIGN_RIGHT);
            document.add(footer);

            document.close();
            return baos.toByteArray();
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate PDF duty history report for person " + personId, e);
        }
    }

    /**
     * Generate Excel report for a person's duty history.
     * If startDate/endDate are null, returns all records.
     */
    public byte[] generateExcel(Long personId, LocalDate startDate, LocalDate endDate) {
        Personnel person = personnelRepository.findById(personId)
                .orElseThrow(() -> new IllegalArgumentException("Personnel not found: " + personId));

        List<DutyHistory> records = getRecords(personId, startDate, endDate);

        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            String sheetName = "Duty History - " + (person.getBadgeId() != null ? 
                    person.getBadgeId().substring(0, Math.min(20, person.getBadgeId().length())) : "Report");
            Sheet sheet = workbook.createSheet(sheetName);

            // Header style
            CellStyle headerStyle = workbook.createCellStyle();
            org.apache.poi.ss.usermodel.Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerFont.setColor(IndexedColors.WHITE.getIndex());
            headerStyle.setFont(headerFont);
            headerStyle.setFillForegroundColor(IndexedColors.INDIGO.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            // Info style
            CellStyle infoStyle = workbook.createCellStyle();
            org.apache.poi.ss.usermodel.Font infoFont = workbook.createFont();
            infoFont.setBold(true);
            infoStyle.setFont(infoFont);

            // Leave row style (red background)
            CellStyle leaveStyle = workbook.createCellStyle();
            leaveStyle.setFillForegroundColor(IndexedColors.ROSE.getIndex());
            leaveStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            // Adhoc row style (green background)
            CellStyle adhocStyle = workbook.createCellStyle();
            adhocStyle.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
            adhocStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            // Row 0: Title
            org.apache.poi.ss.usermodel.Row titleRow = sheet.createRow(0);
            org.apache.poi.ss.usermodel.Cell titleCell = titleRow.createCell(0);
            titleCell.setCellValue("Duty History Report");
            titleCell.setCellStyle(infoStyle);

            // Row 1: Person info
            org.apache.poi.ss.usermodel.Row personRow = sheet.createRow(1);
            personRow.createCell(0).setCellValue("Name: " + person.getPersonName());
            personRow.createCell(2).setCellValue("Badge ID: " + person.getBadgeId());
            personRow.createCell(4).setCellValue("Designation: " + (person.getDesignation() != null ? person.getDesignation() : ""));
            personRow.createCell(6).setCellValue("Section: " + (person.getSection() != null ? person.getSection() : ""));

            // Row 2: Date range
            org.apache.poi.ss.usermodel.Row dateRow = sheet.createRow(2);
            if (startDate != null && endDate != null) {
                dateRow.createCell(0).setCellValue("Period: " + startDate.format(DATE_FORMATTER) + " to " + endDate.format(DATE_FORMATTER));
            } else {
                dateRow.createCell(0).setCellValue("Period: All Records");
            }

            // Row 4: Column headers
            org.apache.poi.ss.usermodel.Row headerRow = sheet.createRow(4);
            String[] headers = {"#", "Date", "Section", "Duty Type", "Duty Location", "Shift", "Status", "Adhoc Duty", "Leave Type"};
            for (int i = 0; i < headers.length; i++) {
                org.apache.poi.ss.usermodel.Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // Data rows
            int rowIdx = 5;
            int idx = 1;
            for (DutyHistory record : records) {
                org.apache.poi.ss.usermodel.Row row = sheet.createRow(rowIdx++);
                
                // Determine row style based on status
                CellStyle rowStyle = null;
                if (record.getLeaveType() != null && !record.getLeaveType().isBlank()) {
                    rowStyle = leaveStyle;
                } else if (record.getAdhocDuty() != null && !record.getAdhocDuty().isBlank()) {
                    rowStyle = adhocStyle;
                }

                createCell(row, 0, String.valueOf(idx++), rowStyle);
                createCell(row, 1, record.getRecordDate() != null ? record.getRecordDate().format(DATE_FORMATTER) : "", rowStyle);
                createCell(row, 2, record.getSection() != null ? record.getSection() : "", rowStyle);
                createCell(row, 3, record.getDutyType() != null ? record.getDutyType() : "", rowStyle);
                createCell(row, 4, record.getDutyLocation() != null ? record.getDutyLocation() : 
                        (record.getWorksAt() != null ? record.getWorksAt() : ""), rowStyle);
                createCell(row, 5, record.getShiftType() != null ? record.getShiftType() : "", rowStyle);
                createCell(row, 6, record.getStatus() != null ? record.getStatus() : "", rowStyle);
                createCell(row, 7, record.getAdhocDuty() != null ? record.getAdhocDuty() : "", rowStyle);
                createCell(row, 8, record.getLeaveType() != null ? record.getLeaveType().replace("_", " ") : "", rowStyle);
            }

            // Summary row
            org.apache.poi.ss.usermodel.Row summaryRow = sheet.createRow(rowIdx + 1);
            org.apache.poi.ss.usermodel.Cell summaryCell = summaryRow.createCell(0);
            summaryCell.setCellValue("Total Records: " + records.size());
            summaryCell.setCellStyle(infoStyle);

            // Generated timestamp
            org.apache.poi.ss.usermodel.Row timestampRow = sheet.createRow(rowIdx + 2);
            timestampRow.createCell(0).setCellValue("Generated on: " + 
                    LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm")));

            // Auto-size columns
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            workbook.write(baos);
            return baos.toByteArray();
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate Excel duty history report for person " + personId, e);
        }
    }

    private List<DutyHistory> getRecords(Long personId, LocalDate startDate, LocalDate endDate) {
        if (startDate != null && endDate != null) {
            return dutyHistoryRepository.findByPersonIdAndRecordDateBetweenOrderByRecordDateDesc(personId, startDate, endDate);
        } else {
            // Get all records for the person
            return dutyHistoryRepository.findByPersonIdAndRecordDateBetweenOrderByRecordDateDesc(
                    personId, LocalDate.of(2000, 1, 1), LocalDate.of(2100, 12, 31));
        }
    }

    private Color getRowBackgroundColor(DutyHistory record, int idx) {
        if (record.getLeaveType() != null && !record.getLeaveType().isBlank()) {
            return new Color(254, 226, 226); // Light red for leave
        }
        if (record.getAdhocDuty() != null && !record.getAdhocDuty().isBlank()) {
            return new Color(220, 252, 231); // Light green for adhoc
        }
        return idx % 2 == 0 ? new Color(249, 250, 251) : Color.WHITE; // Alternating rows
    }

    private void addCell(PdfPTable table, String text, Color bgColor) {
        PdfPCell cell = new PdfPCell(new Phrase(text, CELL_FONT));
        cell.setPadding(3);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setBorderWidth(0.5f);
        if (bgColor != null) {
            cell.setBackgroundColor(bgColor);
        }
        table.addCell(cell);
    }

    private void createCell(org.apache.poi.ss.usermodel.Row row, int col, String value, CellStyle style) {
        org.apache.poi.ss.usermodel.Cell cell = row.createCell(col);
        cell.setCellValue(value);
        if (style != null) {
            cell.setCellStyle(style);
        }
    }
}

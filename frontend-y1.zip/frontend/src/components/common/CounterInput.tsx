import React from 'react';
import { Box, IconButton, Typography } from '@mui/material';
import RemoveIcon from '@mui/icons-material/Remove';
import AddIcon from '@mui/icons-material/Add';

interface CounterInputProps {
  value: number;
  onChange: (value: number) => void;
  min?: number;
  max?: number;
  label?: string;
}

const CounterInput: React.FC<CounterInputProps> = ({
  value,
  onChange,
  min = 1,
  max,
  label,
}) => {
  const handleDecrement = () => {
    if (value > min) {
      onChange(value - 1);
    }
  };

  const handleIncrement = () => {
    if (max === undefined || value < max) {
      onChange(value + 1);
    }
  };

  return (
    <Box>
      {label && (
        <Typography variant="body2" color="text.secondary" sx={{ mb: 0.5 }}>
          {label}
        </Typography>
      )}
      <Box
        sx={{
          display: 'inline-flex',
          alignItems: 'center',
          border: '1px solid',
          borderColor: 'divider',
          borderRadius: 2,
          px: 1,
          py: 0.5,
          boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
        }}
      >
        <IconButton
          size="small"
          onClick={handleDecrement}
          disabled={value <= min}
          color="primary"
        >
          <RemoveIcon fontSize="small" />
        </IconButton>
        <Typography
          sx={{
            minWidth: 40,
            textAlign: 'center',
            fontWeight: 600,
            fontSize: '1rem',
            userSelect: 'none',
          }}
        >
          {value}
        </Typography>
        <IconButton
          size="small"
          onClick={handleIncrement}
          disabled={max !== undefined && value >= max}
          color="primary"
        >
          <AddIcon fontSize="small" />
        </IconButton>
      </Box>
    </Box>
  );
};

export default CounterInput;

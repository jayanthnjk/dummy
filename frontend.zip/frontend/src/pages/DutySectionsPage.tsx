import React from 'react';
import { observer } from 'mobx-react-lite';
import { Box } from '@mui/material';
import { useTranslation } from 'react-i18next';
import AddIcon from '@mui/icons-material/Add';

import { dutySectionStore } from '@/stores/dutySectionStore';
import DutyAndSectionsTab from '@/components/DutyAndSectionsTab';
import PageHeader from '@/components/common/PageHeader';
import type { ActionButtonConfig } from '@/components/common/PageHeader';

/**
 * DutySectionsPage — Enterprise-level Duty & Sections management page.
 * Uses PageHeader pattern with clean white header.
 */
const DutySectionsPage: React.FC = observer(() => {
  const { t } = useTranslation();

  const actions: ActionButtonConfig[] = [
    {
      label: t('admin.dutySections.addDutyType', 'Add Duty Type'),
      variant: 'primary',
      icon: <AddIcon />,
      onClick: () => dutySectionStore.openAddDutyTypeDialog(),
    },
  ];

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', bgcolor: 'background.default' }}>
      <PageHeader
        title={t('admin.tabs.dutySections', 'Duty & Sections')}
        breadcrumbs={[
          { label: t('nav.home', 'Home'), path: '/' },
          { label: t('admin.tabs.dutySections', 'Duty & Sections') },
        ]}
        actions={actions}
      />

      {/* Main Content Area */}
      <Box sx={{ flex: 1, px: { xs: 2, md: 3 }, py: 2 }}>
        <DutyAndSectionsTab />
      </Box>
    </Box>
  );
});

export default DutySectionsPage;

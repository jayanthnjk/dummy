import { createTheme } from '@mui/material/styles';

/*
 * KSP WorkBoard Color Palette
 * Extracted from the login screen design:
 * - Deep navy/indigo: #0b0e2a, #12153a, #1a1e4a
 * - Gold/khaki accent: #c4a44a, #b8963c, #d4b85c
 * - Warm whites: #faf8f4, #f5f2ec, #ffffff
 * - Muted text: #8888aa, #6b6b80, #9ca3af
 */

export const lightTheme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: '#1a1e4a',
      light: '#2a2e6a',
      dark: '#0b0e2a',
    },
    secondary: {
      main: '#c4a44a',
      light: '#d4b85c',
      dark: '#b8963c',
    },
    background: {
      default: '#ffffff',
      paper: '#ffffff',
    },
    text: {
      primary: '#1a1a2e',
      secondary: '#6b6b80',
    },
    divider: '#f0ede6',
    error: { main: '#dc2626' },
    warning: { main: '#e8722a' },
    success: { main: '#22c55e' },
    info: { main: '#3b82f6' },
  },
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: { backgroundColor: '#ffffff', boxShadow: 'none' },
      },
    },
    MuiDrawer: {
      styleOverrides: {
        paper: { backgroundColor: '#ffffff', borderRight: 'none' },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: { backgroundColor: '#ffffff', borderColor: '#f0ede6' },
      },
    },
    MuiTableHead: {
      styleOverrides: {
        root: { backgroundColor: '#f3f4f6' },
      },
    },
  },
});

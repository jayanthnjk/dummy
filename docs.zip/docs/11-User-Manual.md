# User Manual
## KSP WorkBoard — Police Station Management System

| Field | Details |
|-------|---------|
| **Document Title** | User Manual / User Guide |
| **Version** | 1.0.0 |
| **Audience** | All system users (General Users, Higher Officers, Admins) |
| **Date** | June 2026 |

---

## 1. Getting Started

### 1.1 Accessing the System

1. Open your web browser (Chrome, Firefox, Safari, or Edge)
2. Navigate to the application URL provided by your administrator
3. You will see the login page

### 1.2 Login

1. Enter your **username** (provided by admin)
2. Enter your **password**
3. Click **Login**
4. On successful login, you will be redirected to the Home page

**Important:** The system will automatically log you out after 15 minutes of inactivity. You will see a warning dialog before logout.

### 1.3 Changing Your Password

1. Access the change password option from your profile area
2. Enter your current password
3. Enter your new password
4. Confirm and submit

---

## 2. Navigation

### 2.1 Side Navigation Bar

The left sidebar contains all main navigation options:

| Icon | Label | Description |
|------|-------|-------------|
| 🏠 | Home | Dashboard with AI Chat interface |
| 📅 | Schedules | Current duty schedules and rotation management |
| 👥 | Personnel | Personnel records management |
| 📋 | Leave Requests | Leave application and management |
| 📄 | Reports | Download official reports (PDF/Excel) |
| ⚙️ | Admin Config | (Admin only) Duty sections configuration |

**Collapse/Expand:** Click the arrow button on the sidebar edge to collapse or expand the navigation.

**Mobile:** On mobile devices, tap the hamburger menu icon to open navigation.

---

## 3. Home Page — AI Chat Interface

### 3.1 Overview

The Home page features the AI Chat panel — your primary interface for quick operations. You can type commands in **English**, **Kannada (ಕನ್ನಡ)**, or **Hindi** and the system will understand.

### 3.2 How to Use Chat

Type natural language commands in the chat box. Examples:

**Personnel Operations:**
- "Show personnel list" / "ಸಿಬ್ಬಂದಿ ಪಟ್ಟಿ ತೋರಿಸು"
- "Details of AHC 2649"
- "Show all AHC" (lists all with AHC designation)
- "List section A personnel"
- "Show drivers" / "ಚಾಲಕರು ತೋರಿಸು"

**Leave Operations:**
- "Create sick leave for AHC 2649 on June 25 2026"
- "Show leave status" / "ರಜೆ ಸ್ಥಿತಿ ತೋರಿಸು"
- "How many on leave today?"
- "Show pending leave requests"

**Schedule Operations:**
- "Show current schedule"
- "Show platoon rotation" / "ಪ್ಲಟೂನ್ ತೋರಿಸು"
- "Create platoon cycle" (opens a form)
- "List cycles"

**Adhoc Duty:**
- "Create adhoc duty" (opens a form)
- "List adhoc duties"
- "Cancel adhoc duty 5"

**Reports:**
- "Download platoon chart"
- "Download form 168"
- "Download leave report" / "ರಜೆ ವರದಿ ಡೌನ್‌ಲೋಡ್"

**Duty Types:**
- "Show duty types"
- "Add duty type" (opens a form)

### 3.3 Chat Response Types

The chat can display different types of responses:
- **Tables** — Data displayed in sortable table format
- **Forms** — Interactive forms for creating records (fill and submit)
- **Confirmations** — Success/failure messages with details
- **Suggestions** — Clickable quick-action buttons

### 3.4 Voice Input

Click the microphone icon to record a voice message. The system will transcribe your speech and process it as a text command. Works with English, Kannada, and Hindi.

### 3.5 PDF Upload

Click the attachment icon to upload a PDF document. The system will read the document and you can ask questions about its content.

---

## 4. Personnel Management

### 4.1 Viewing Personnel List

1. Click **Personnel** in the side navigation
2. The page displays all active personnel in a table
3. Use the **search bar** to find by name, badge ID, or other fields
4. Use **filter dropdowns** for Section, Designation, Duty Type, Active Status
5. Click column headers to sort

### 4.2 Viewing Personnel Profile

1. Click on any personnel row in the list
2. The profile page shows complete details: badge ID, name, designation, section, duty, contact info, platoon assignment, vehicle details (for drivers)

### 4.3 Adding New Personnel (Admin/Higher Officer)

1. Click **Personnel** → Click **Add Person** button
2. Fill in required fields: Name, Badge ID, Section
3. Fill optional fields as needed
4. For MT section drivers: Vehicle Number, Duty Location, PDMS, and Licence Type are required
5. Click **Save**

### 4.4 Editing Personnel (Admin/Higher Officer)

1. Navigate to personnel profile
2. Click **Edit** button
3. Modify desired fields
4. Click **Save**

---

## 5. Schedule Management

### 5.1 Schedule Overview

1. Click **Schedules** in navigation
2. View current deployment across Section A (Fixed), Section B (Office), and Section C (Rotational)
3. See platoon rotation status and next rotation date

### 5.2 Cycle Management

1. Navigate to **Schedules** → **Cycles** (or use sub-navigation)
2. View existing cycles with status (Active/Completed/Deleted)
3. Click **Create Cycle** to start a new rotation

**Creating a Cycle:**
1. Start date is auto-filled with the next available date
2. Set rotation days (default: 15)
3. Review auto-generated platoon-to-section mappings
4. Adjust any platoon's section assignment if needed
5. Click **Create Cycle**
6. System auto-generates daily duty assignments for all rotational personnel

### 5.3 Cycle Activities (Audit Log)

1. Navigate to **Schedules** → **Activities**
2. View chronological log of all cycle changes: creations, updates, reassignments, deletions

### 5.4 Adhoc/Special Duties

1. Navigate to **Schedules** → **Adhoc Duties**
2. View list of adhoc duties with status
3. Click **Create** to set up a new special duty:
   - Enter duty name (e.g., "Independence Day Bandobast")
   - Set date, start time, end time
   - Set required personnel count
   - Optionally specify location and platoon preference
   - Click **Create** — system auto-assigns available personnel
4. View assigned personnel in duty details
5. Download PDF/Excel report for the duty
6. Cancel duty if no longer needed (releases personnel)

---

## 6. Leave Management

### 6.1 Viewing Leave Requests

1. Click **Leave Requests** in navigation
2. View all leave requests (filtered by your role)
3. Use filters: Status, Leave Type, Date Range

### 6.2 Submitting Leave (All Users)

1. Click **Leave Requests** → **Create** button
2. Select personnel (or use chat: "create sick leave for AHC 2649 on June 25")
3. Select leave type: Casual, Sick, Earned, Weekly Off, Compensatory Off
4. Set start and end dates
5. Optionally enter reason
6. Submit

**Note:** If your leave dates conflict with duty assignments, you'll see a warning showing which duties are affected.

### 6.3 Approving/Rejecting Leave (Admin/Higher Officer)

1. View pending leave requests
2. Click **Approve** or **Reject**
3. For rejection, provide a reason

### 6.4 Cancelling Leave

1. Find your pending/approved leave request
2. Click **Cancel**
3. Note: Cannot cancel past or already-rejected leaves

---

## 7. Reports

### 7.1 Available Reports

| Report | Description | Formats |
|--------|-------------|---------|
| Platoon Chart | Current platoon rotation and duty assignments | PDF, Excel |
| Form 168 (Daily Statement) | Daily personnel strength and deployment | PDF, Excel |
| Section A Report | Fixed/essential duties personnel | PDF, Excel |
| Section B Report | Office/support duties personnel | PDF, Excel |
| MT Section Report | Drivers with vehicle and licence details | PDF, Excel |
| Leave Statement | Leave requests summary with status | PDF, Excel |
| Personnel List | Complete personnel roster (filterable) | PDF |

### 7.2 Downloading Reports

1. Click **Reports** in navigation
2. Select the report type
3. Choose format (PDF or Excel)
4. Configure any filters (date, section, status)
5. Click **Download**
6. File downloads automatically with dated filename

---

## 8. Contact Support

1. Click **Contact Support** in navigation
2. Enter subject and description of your issue
3. Submit the ticket
4. Track ticket status on the same page
5. Admin will respond to your ticket

---

## 9. Language Settings

The system supports:
- **English** — Full interface and chat
- **Kannada (ಕನ್ನಡ)** — Full interface and chat

Your preferred language is set in your user profile. The chat automatically detects your input language and responds accordingly.

---

## 10. Tips & Shortcuts

| Tip | Description |
|-----|-------------|
| Use chat for everything | The AI chat can perform any operation faster than navigating to pages |
| Badge ID shortcuts | Type "AHC 2649" (with space) — system recognizes it as badge ID |
| Voice for quick queries | Use voice input when hands are busy |
| Click suggestions | After a greeting, click the suggested actions for quick access |
| Kannada is fully supported | "ಸಿಬ್ಬಂದಿ ಪಟ್ಟಿ" works exactly like "show personnel list" |

---

*End of Document — User Manual v1.0.0*

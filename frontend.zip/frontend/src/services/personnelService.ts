import api from './api';
import type {
  PersonnelDto,
  CreatePersonnelRequest,
  UpdatePersonnelRequest,
  PersonnelFilter,
  Page,
  DutyHistoryDto,
} from '@/types';

export const personnelService = {
  list: (filter?: PersonnelFilter, page = 0, size = 20) =>
    api.get<Page<PersonnelDto>>('/api/personnel', {
      params: { ...filter, page, size },
    }).then((r) => r.data),

  getByBadgeId: (badgeId: string) =>
    api.get<PersonnelDto>(`/api/personnel/${badgeId}`).then((r) => r.data),

  create: (data: CreatePersonnelRequest) =>
    api.post<PersonnelDto>('/api/personnel', data).then((r) => r.data),

  update: (badgeId: string, data: UpdatePersonnelRequest) =>
    api.put<PersonnelDto>(`/api/personnel/${badgeId}`, data).then((r) => r.data),

  delete: (badgeId: string) =>
    api.delete<void>(`/api/personnel/${badgeId}`),

  /**
   * Get paginated duty history for a person.
   * @param personId - The person's ID
   * @param page - Page number (0-indexed)
   * @param size - Page size
   * @param startDate - Optional start date filter (YYYY-MM-DD)
   * @param endDate - Optional end date filter (YYYY-MM-DD)
   */
  getDutyHistory: (personId: number, page = 0, size = 10, startDate?: string, endDate?: string) =>
    api.get<Page<DutyHistoryDto>>(`/api/duty-history/person/${personId}/paginated`, {
      params: { page, size, startDate, endDate },
    }).then((r) => r.data),
};

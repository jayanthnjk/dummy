import api from './api';

export interface SupportTicket {
  id: number;
  subject: string;
  message: string;
  category: string;
  priority: string;
  status: string;
  submittedBy: string;
  adminResponse: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface CreateTicketRequest {
  subject: string;
  message: string;
  category: string;
  priority: string;
}

export interface ReportParams {
  status?: string;
  priority?: string;
  from?: string;
  to?: string;
}

export const supportService = {
  submit: (data: CreateTicketRequest) =>
    api.post<SupportTicket>('/api/support/tickets', data).then((r) => r.data),

  list: () =>
    api.get<SupportTicket[]>('/api/support/tickets').then((r) => r.data),

  getAllTickets: () =>
    api.get<SupportTicket[]>('/api/support/tickets/all').then((r) => r.data),

  updateTicketStatus: (id: number, status: string) =>
    api.patch<SupportTicket>(`/api/support/tickets/${id}/status`, { status }).then((r) => r.data),

  addComment: (id: number, comment: string) =>
    api.post<SupportTicket>(`/api/support/tickets/${id}/comment`, { comment }).then((r) => r.data),

  reopenTicket: (id: number) =>
    api.patch<SupportTicket>(`/api/support/tickets/${id}/reopen`).then((r) => r.data),

  downloadTicketPdf: (id: number) =>
    api.get(`/api/support/tickets/${id}/pdf`, { responseType: 'blob' }).then((r) => r.data),

  downloadReport: (params: ReportParams) =>
    api.get('/api/support/tickets/report', { params, responseType: 'blob' }).then((r) => r.data),
};

import React, { useState, useEffect, useMemo } from 'react';
import {
  Box, Typography, TextField, Button, MenuItem, Card, CardContent,
  Chip, CircularProgress, Alert, Divider, InputAdornment, TablePagination,
} from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import SearchIcon from '@mui/icons-material/Search';
import { useTranslation } from 'react-i18next';
import { supportService, SupportTicket, CreateTicketRequest } from '@/services/supportService';
import PageHeader from '@/components/common/PageHeader';

const CATEGORIES = [
  { value: 'BUG', label: 'Bug Report' },
  { value: 'FEATURE_REQUEST', label: 'Feature Request' },
  { value: 'GENERAL', label: 'General Inquiry' },
  { value: 'ACCESS_ISSUE', label: 'Access Issue' },
];

const PRIORITIES = [
  { value: 'LOW', label: 'Low' },
  { value: 'MEDIUM', label: 'Medium' },
  { value: 'HIGH', label: 'High' },
  { value: 'CRITICAL', label: 'Critical' },
];

const STATUS_COLORS: Record<string, 'warning' | 'info' | 'success' | 'default'> = {
  OPEN: 'warning',
  IN_PROGRESS: 'info',
  RESOLVED: 'success',
  CLOSED: 'default',
};

const ContactSupportPage: React.FC = () => {
  const { t } = useTranslation();
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [category, setCategory] = useState('GENERAL');
  const [priority, setPriority] = useState('MEDIUM');
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [loading, setLoading] = useState(true);

  // Ticket filtering & pagination state
  const [ticketSearch, setTicketSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [priorityFilter, setPriorityFilter] = useState<string>('ALL');
  const [ticketPage, setTicketPage] = useState(0);
  const [ticketsPerPage, setTicketsPerPage] = useState(10);

  const loadTickets = async () => {
    try {
      const data = await supportService.list();
      setTickets(data);
    } catch {
      // Silently fail on load
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTickets();
  }, []);

  // Derived: filtered tickets based on search, status, and priority
  const filteredTickets = useMemo(() => {
    let result = tickets;
    if (ticketSearch.trim()) {
      const q = ticketSearch.toLowerCase();
      result = result.filter((t) => t.subject.toLowerCase().includes(q));
    }
    if (statusFilter !== 'ALL') {
      result = result.filter((t) => t.status === statusFilter);
    }
    if (priorityFilter !== 'ALL') {
      result = result.filter((t) => t.priority === priorityFilter);
    }
    return result;
  }, [tickets, ticketSearch, statusFilter, priorityFilter]);

  // Derived: paginated tickets
  const paginatedTickets = useMemo(() => {
    const start = ticketPage * ticketsPerPage;
    return filteredTickets.slice(start, start + ticketsPerPage);
  }, [filteredTickets, ticketPage, ticketsPerPage]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    setSuccess(false);

    try {
      const request: CreateTicketRequest = { subject, message, category, priority };
      await supportService.submit(request);
      setSuccess(true);
      setSubject('');
      setMessage('');
      setCategory('GENERAL');
      setPriority('MEDIUM');
      loadTickets();
    } catch {
      setError(t('support.ticketError', 'Failed to submit ticket. Please try again.'));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', bgcolor: 'background.default' }}>
      <PageHeader
        title={t('support.title', 'Contact Support')}
        breadcrumbs={[
          { label: t('nav.home', 'Home'), path: '/' },
          { label: t('support.title', 'Contact Support') },
        ]}
      />

      {/* Content */}
      <Box sx={{ flex: 1, px: { xs: 2, md: 4 }, py: 3, maxWidth: 900, mx: 'auto', width: '100%' }}>
        {/* Submit Ticket Form */}
        <Card sx={{ mb: 4, borderRadius: 2, border: (theme) => `1px solid ${theme.palette.divider}` }} elevation={0}>
          <CardContent sx={{ p: 3 }}>
            <Typography variant="h6" fontWeight={600} sx={{ mb: 2 }}>
              {t('support.submitNewTicket', 'Submit a New Ticket')}
            </Typography>

            {success && (
              <Alert severity="success" sx={{ mb: 2 }} onClose={() => setSuccess(false)}>
                {t('support.ticketSuccess', "Ticket submitted successfully! We'll get back to you soon.")}
              </Alert>
            )}
            {error && (
              <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>
                {error}
              </Alert>
            )}

            <Box component="form" onSubmit={handleSubmit} sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <TextField
                label={t('support.subject', 'Subject')}
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                required
                fullWidth
                size="small"
                placeholder={t('support.subject', 'Brief description of your issue')}
              />

              <Box sx={{ display: 'flex', gap: 2 }}>
                <TextField
                  label={t('support.category', 'Category')}
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  select
                  fullWidth
                  size="small"
                >
                  {CATEGORIES.map((c) => (
                    <MenuItem key={c.value} value={c.value}>{c.label}</MenuItem>
                  ))}
                </TextField>

                <TextField
                  label={t('support.priority', 'Priority')}
                  value={priority}
                  onChange={(e) => setPriority(e.target.value)}
                  select
                  fullWidth
                  size="small"
                >
                  {PRIORITIES.map((p) => (
                    <MenuItem key={p.value} value={p.value}>{p.label}</MenuItem>
                  ))}
                </TextField>
              </Box>

              <TextField
                label={t('support.message', 'Message')}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                required
                fullWidth
                multiline
                rows={4}
                size="small"
                placeholder={t('support.message', 'Describe your issue in detail...')}
              />

              <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                <Button
                  type="submit"
                  variant="contained"
                  disabled={submitting || !subject || !message}
                  startIcon={submitting ? <CircularProgress size={16} /> : <SendIcon />}
                  sx={{
                    bgcolor: 'primary.main',
                    color: '#ffffff',
                    '&:hover': { bgcolor: 'primary.dark' },
                    textTransform: 'none',
                    fontWeight: 600,
                    px: 3,
                  }}
                >
                  {submitting ? t('support.submitting', 'Submitting...') : t('support.submitTicket', 'Submit Ticket')}
                </Button>
              </Box>
            </Box>
          </CardContent>
        </Card>

        {/* Ticket History */}
        <Typography variant="h6" fontWeight={600} sx={{ mb: 2 }}>
          {t('support.yourTickets', 'Your Tickets')}
        </Typography>

        {/* Filters: search, status, priority */}
        <Box sx={{ display: 'flex', gap: 2, mb: 2, flexWrap: 'wrap', alignItems: 'center' }}>
          <TextField
            size="small"
            placeholder="Search by title..."
            value={ticketSearch}
            onChange={(e) => { setTicketSearch(e.target.value); setTicketPage(0); }}
            sx={{ minWidth: 220, flex: 1 }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ fontSize: 18, color: '#9CA3AF' }} />
                </InputAdornment>
              ),
            }}
          />
          <TextField
            select
            size="small"
            label="Status"
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value); setTicketPage(0); }}
            sx={{ minWidth: 140 }}
          >
            <MenuItem value="ALL">All Status</MenuItem>
            <MenuItem value="OPEN">Open</MenuItem>
            <MenuItem value="IN_PROGRESS">In Progress</MenuItem>
            <MenuItem value="RESOLVED">Resolved</MenuItem>
            <MenuItem value="CLOSED">Closed</MenuItem>
          </TextField>
          <TextField
            select
            size="small"
            label="Priority"
            value={priorityFilter}
            onChange={(e) => { setPriorityFilter(e.target.value); setTicketPage(0); }}
            sx={{ minWidth: 140 }}
          >
            <MenuItem value="ALL">All Priority</MenuItem>
            <MenuItem value="LOW">Low</MenuItem>
            <MenuItem value="MEDIUM">Medium</MenuItem>
            <MenuItem value="HIGH">High</MenuItem>
            <MenuItem value="CRITICAL">Critical</MenuItem>
          </TextField>
        </Box>

        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
            <CircularProgress size={32} />
          </Box>
        ) : filteredTickets.length === 0 ? (
          <Card sx={{ borderRadius: 2, border: (theme) => `1px solid ${theme.palette.divider}` }} elevation={0}>
            <CardContent sx={{ textAlign: 'center', py: 4 }}>
              <Typography color="text.secondary">
                {tickets.length === 0
                  ? t('support.noTickets', 'No tickets submitted yet. Use the form above to create one.')
                  : 'No tickets match the current filters.'}
              </Typography>
            </CardContent>
          </Card>
        ) : (
          <Box sx={{ maxHeight: 500, overflow: 'auto', border: (theme) => `1px solid ${theme.palette.divider}`, borderRadius: 2 }}>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
              {paginatedTickets.map((ticket) => (
                <Card key={ticket.id} sx={{ borderRadius: 0, borderBottom: (theme) => `1px solid ${theme.palette.divider}`, '&:last-child': { borderBottom: 'none' } }} elevation={0}>
                  <CardContent sx={{ p: 2.5 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
                      <Typography variant="subtitle1" fontWeight={600}>
                        {ticket.subject}
                      </Typography>
                      <Chip
                        label={ticket.status.replace('_', ' ')}
                        size="small"
                        color={STATUS_COLORS[ticket.status] || 'default'}
                        sx={{ fontWeight: 600, fontSize: '0.7rem' }}
                      />
                    </Box>

                    <Box sx={{ display: 'flex', gap: 1, mb: 1.5 }}>
                      <Chip label={CATEGORIES.find((c) => c.value === ticket.category)?.label || ticket.category} size="small" variant="outlined" sx={{ fontSize: '0.7rem' }} />
                      <Chip label={ticket.priority} size="small" variant="outlined" sx={{ fontSize: '0.7rem' }} />
                      <Typography variant="caption" color="text.secondary" sx={{ ml: 'auto', alignSelf: 'center' }}>
                        {new Date(ticket.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })}
                      </Typography>
                    </Box>

                    <Typography variant="body2" color="text.secondary" sx={{ mb: ticket.adminResponse ? 1.5 : 0 }}>
                      {ticket.message}
                    </Typography>

                    {ticket.adminResponse && (
                      <>
                        <Divider sx={{ my: 1.5 }} />
                        <Box sx={{ bgcolor: '#f0f9ff', borderRadius: 1, p: 1.5 }}>
                          <Typography variant="caption" fontWeight={600} color="primary" sx={{ display: 'block', mb: 0.5 }}>
                            {t('support.adminResponse', 'Admin Response')}
                          </Typography>
                          <Typography variant="body2">
                            {ticket.adminResponse}
                          </Typography>
                        </Box>
                      </>
                    )}
                  </CardContent>
                </Card>
              ))}
            </Box>
            <TablePagination
              component="div"
              count={filteredTickets.length}
              page={ticketPage}
              onPageChange={(_, newPage) => setTicketPage(newPage)}
              rowsPerPage={ticketsPerPage}
              onRowsPerPageChange={(e) => { setTicketsPerPage(parseInt(e.target.value, 10)); setTicketPage(0); }}
              rowsPerPageOptions={[5, 10, 25]}
              sx={{ borderTop: (theme) => `1px solid ${theme.palette.divider}` }}
            />
          </Box>
        )}
      </Box>
    </Box>
  );
};

export default ContactSupportPage;

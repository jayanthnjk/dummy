import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  FormHelperText,
  Alert,
  Box,
  Typography,
} from '@mui/material';
import type { ShiftCreateDialogProps, CreateShiftRequest } from '@/types/schedule';

interface FormErrors {
  shiftType?: string;
  startTime?: string;
  endTime?: string;
}

const ShiftCreateDialog: React.FC<ShiftCreateDialogProps> = ({
  open,
  onClose,
  onSubmit,
  prefilledMember,
  prefilledDate,
  shiftTypes,
}) => {
  const [shiftType, setShiftType] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [errors, setErrors] = useState<FormErrors>({});
  const [serverError, setServerError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Reset form state when dialog opens
  useEffect(() => {
    if (open) {
      setShiftType('');
      setStartTime('');
      setEndTime('');
      setErrors({});
      setServerError(null);
      setSubmitting(false);
    }
  }, [open]);

  const validate = (): boolean => {
    const newErrors: FormErrors = {};

    if (!shiftType) {
      newErrors.shiftType = 'This field is required';
    }
    if (!startTime) {
      newErrors.startTime = 'This field is required';
    }
    if (!endTime) {
      newErrors.endTime = 'This field is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) {
      return;
    }

    if (!prefilledMember || !prefilledDate) {
      return;
    }

    const request: CreateShiftRequest = {
      personnelId: prefilledMember.id,
      date: prefilledDate,
      startTime,
      endTime,
      shiftType,
    };

    setSubmitting(true);
    setServerError(null);

    try {
      await onSubmit(request);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to create shift';
      setServerError(message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleCancel = () => {
    onClose();
  };

  return (
    <Dialog open={open} onClose={handleCancel} maxWidth="sm" fullWidth>
      <DialogTitle>Create New Shift</DialogTitle>
      <DialogContent>
        {/* Server error alert */}
        {serverError && (
          <Alert severity="error" sx={{ mb: 2, mt: 1 }}>
            {serverError}
          </Alert>
        )}

        {/* Pre-filled member and date info */}
        <Box sx={{ mb: 2, mt: serverError ? 0 : 1 }}>
          {prefilledMember && (
            <Typography variant="body2" sx={{ color: '#6b7280' }}>
              Team Member: <strong>{prefilledMember.name}</strong>
            </Typography>
          )}
          {prefilledDate && (
            <Typography variant="body2" sx={{ color: '#6b7280' }}>
              Date: <strong>{prefilledDate}</strong>
            </Typography>
          )}
        </Box>

        {/* Shift Type Select */}
        <FormControl fullWidth error={!!errors.shiftType} sx={{ mb: 2 }}>
          <InputLabel id="shift-type-label">Shift Type</InputLabel>
          <Select
            labelId="shift-type-label"
            value={shiftType}
            label="Shift Type"
            onChange={(e) => {
              setShiftType(e.target.value);
              if (errors.shiftType) {
                setErrors((prev) => ({ ...prev, shiftType: undefined }));
              }
            }}
          >
            {shiftTypes.map((type) => (
              <MenuItem key={type.name} value={type.name}>
                {type.name}
              </MenuItem>
            ))}
          </Select>
          {errors.shiftType && <FormHelperText>{errors.shiftType}</FormHelperText>}
        </FormControl>

        {/* Start Time */}
        <TextField
          fullWidth
          label="Start Time"
          type="time"
          value={startTime}
          onChange={(e) => {
            setStartTime(e.target.value);
            if (errors.startTime) {
              setErrors((prev) => ({ ...prev, startTime: undefined }));
            }
          }}
          error={!!errors.startTime}
          helperText={errors.startTime}
          slotProps={{ inputLabel: { shrink: true } }}
          sx={{ mb: 2 }}
        />

        {/* End Time */}
        <TextField
          fullWidth
          label="End Time"
          type="time"
          value={endTime}
          onChange={(e) => {
            setEndTime(e.target.value);
            if (errors.endTime) {
              setErrors((prev) => ({ ...prev, endTime: undefined }));
            }
          }}
          error={!!errors.endTime}
          helperText={errors.endTime}
          slotProps={{ inputLabel: { shrink: true } }}
        />

      </DialogContent>

      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button variant="outlined" onClick={handleCancel} disabled={submitting}>
          Cancel
        </Button>
        <Button
          variant="contained"
          color="primary"
          onClick={handleSubmit}
          disabled={submitting}
        >
          Create
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ShiftCreateDialog;

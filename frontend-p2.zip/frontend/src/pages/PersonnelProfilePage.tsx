import React, { useEffect, useState } from 'react';
import {
  Box, Typography, Card, CardContent, Button,
  CircularProgress, Alert, Chip, Switch, FormControlLabel, MenuItem,
  Tab, Tabs,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import EditIcon from '@mui/icons-material/Edit';
import SaveIcon from '@mui/icons-material/Save';
import CancelIcon from '@mui/icons-material/Cancel';
import PhoneIcon from '@mui/icons-material/Phone';
import EmailIcon from '@mui/icons-material/Email';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import { useTranslation } from 'react-i18next';
import { useNavigate, useParams } from 'react-router-dom';
import FormField from '@/components/FormField';
import PageHeader from '@/components/common/PageHeader';
import { PersonAvatar } from '@/components/common/PersonAvatar';
import StatusBadge from '@/components/common/StatusBadge';
import { personnelService } from '@/services/personnelService';
import { sectionService, type SectionDto } from '@/services/sectionService';
import type { PersonnelDto, UpdatePersonnelRequest } from '@/types';

const DESIGNATIONS = ['DCP', 'ACP', 'RPI', 'RSI', 'ARSI', 'AHC', 'APC'];

const PersonnelProfilePage: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { badgeId } = useParams<{ badgeId: string }>();
  const [person, setPerson] = useState<PersonnelDto | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [sections, setSections] = useState<SectionDto[]>([]);
  const [activeTab, setActiveTab] = useState(0);
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<UpdatePersonnelRequest>({});

  useEffect(() => {
    if (!badgeId) return;
    setLoading(true);
    Promise.all([
      personnelService.getByBadgeId(badgeId),
      sectionService.list(),
    ])
      .then(([data, secs]) => { setPerson(data); setForm(data); setSections(secs); })
      .catch(() => setError('Personnel not found'))
      .finally(() => setLoading(false));
  }, [badgeId]);

  const handleSave = async () => {
    if (!badgeId) return;
    setSaving(true);
    try {
      const updated = await personnelService.update(badgeId, form);
      setPerson(updated);
      setEditing(false);
    } catch { setError(t('errors.serverError')); }
    finally { setSaving(false); }
  };

  const updateField = (field: keyof UpdatePersonnelRequest, value: string | boolean) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const handleTabChange = (_event: React.SyntheticEvent, newValue: number) => {
    setActiveTab(newValue);
  };

  if (loading) return <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}><CircularProgress /></Box>;
  if (error || !person) return (
    <Box sx={{ p: 3 }}>
      <Alert severity="error">{error || 'Not found'}</Alert>
      <Button onClick={() => navigate('/personnel')} sx={{ mt: 2 }}>Back to Personnel</Button>
    </Box>
  );

  const personName = person.personName || 'Unknown';

  return (
    <Box>
      {/* PageHeader with breadcrumbs and back action */}
      <PageHeader
        title={personName}
        breadcrumbs={[
          { label: 'Home', path: '/' },
          { label: 'Personnel', path: '/personnel' },
          { label: personName },
        ]}
        actions={[
          {
            label: 'Back',
            variant: 'ghost',
            icon: <ArrowBackIcon />,
            onClick: () => navigate('/personnel'),
          },
          ...(editing
            ? []
            : [{
                label: 'Edit',
                variant: 'secondary' as const,
                icon: <EditIcon />,
                onClick: () => setEditing(true),
              }]
          ),
        ]}
      />

      <Box sx={{ p: 3, maxWidth: 1000, mx: 'auto' }}>
        {/* Profile Hero Section */}
        <Card
          variant="outlined"
          sx={{
            borderRadius: 3,
            borderColor: 'divider',
            mb: 3,
            overflow: 'visible',
          }}
        >
          <CardContent sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', gap: 3, alignItems: 'center', flexWrap: { xs: 'wrap', sm: 'nowrap' } }}>
              {/* Large PersonAvatar */}
              <PersonAvatar
                name={personName}
                size="large"
                badgeId={person.badgeId}
                designation={person.designation}
              />

              {/* Person Info */}
              <Box sx={{ flex: 1, minWidth: 0 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 0.5, flexWrap: 'wrap' }}>
                  <Typography variant="h5" fontWeight={700} color="text.primary">
                    {personName}
                  </Typography>
                  {person.designation && (
                    <Chip
                      label={person.designation}
                      size="small"
                      sx={{
                        bgcolor: '#ede9fe',
                        color: '#6d28d9',
                        fontWeight: 600,
                        fontSize: '0.75rem',
                      }}
                    />
                  )}
                  <StatusBadge
                    status={person.isActive ? 'Active' : 'Cancelled'}
                    size="small"
                    showDot
                  />
                </Box>

                <Box sx={{ display: 'flex', gap: 3, flexWrap: 'wrap', color: 'text.secondary', mt: 1 }}>
                  <Typography variant="body2" sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    Badge: <strong>{person.badgeId}</strong>
                  </Typography>
                  {person.section && (
                    <Typography variant="body2" sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                      <LocationOnIcon sx={{ fontSize: 16 }} /> Section {person.section}
                    </Typography>
                  )}
                  {person.location && (
                    <Typography variant="body2" sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                      <LocationOnIcon sx={{ fontSize: 16 }} /> {person.location}
                    </Typography>
                  )}
                </Box>
              </Box>

              {/* Edit controls in hero when editing */}
              {editing && (
                <Box sx={{ display: 'flex', gap: 1, flexShrink: 0 }}>
                  <Button
                    startIcon={<CancelIcon sx={{ fontSize: 16 }} />}
                    onClick={() => { setEditing(false); setForm(person); }}
                    size="small"
                    sx={{ textTransform: 'none', color: 'text.secondary' }}
                  >
                    Cancel
                  </Button>
                  <Button
                    variant="contained"
                    startIcon={saving ? <CircularProgress size={14} /> : <SaveIcon sx={{ fontSize: 16 }} />}
                    onClick={handleSave}
                    disabled={saving}
                    size="small"
                    sx={{ textTransform: 'none' }}
                  >
                    Save
                  </Button>
                </Box>
              )}
            </Box>
          </CardContent>
        </Card>

        {/* Tabbed Content using MUI Tabs */}
        <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
          <Tabs
            value={activeTab}
            onChange={handleTabChange}
            aria-label="Personnel profile tabs"
          >
            <Tab label="Details" id="profile-tab-0" aria-controls="profile-tabpanel-0" />
            <Tab label="Contact" id="profile-tab-1" aria-controls="profile-tabpanel-1" />
          </Tabs>
        </Box>

        {/* Details Tab */}
        <Box
          role="tabpanel"
          hidden={activeTab !== 0}
          id="profile-tabpanel-0"
          aria-labelledby="profile-tab-0"
        >
          {activeTab === 0 && (
            <Card variant="outlined" sx={{ borderRadius: 3, borderColor: 'divider' }}>
              <CardContent sx={{ p: 3 }}>
                <Typography variant="subtitle1" fontWeight={600} color="text.primary" sx={{ mb: 3 }}>
                  Basic Information
                </Typography>
                <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr' }, gap: 2 }}>
                  {editing ? (
                    <>
                      <FormField labelKey="personnel.badgeId" value={form.badgeId || ''} onChange={e => updateField('badgeId', e.target.value)} />
                      <FormField labelKey="personnel.personName" value={form.personName || ''} onChange={e => updateField('personName', e.target.value)} />
                      <FormField labelKey="personnel.designation" select value={form.designation || ''} onChange={e => updateField('designation', e.target.value)}>
                        {DESIGNATIONS.map(d => <MenuItem key={d} value={d}>{d}</MenuItem>)}
                      </FormField>
                      <FormField labelKey="personnel.section" select value={form.section || ''} onChange={e => updateField('section', e.target.value)}>
                        {sections.map(s => <MenuItem key={s.code} value={s.code}>{s.name}</MenuItem>)}
                      </FormField>
                      <FormField labelKey="personnel.dutyType" value={form.dutyType || ''} onChange={e => updateField('dutyType', e.target.value)} />
                      <FormField labelKey="personnel.location" value={form.location || ''} onChange={e => updateField('location', e.target.value)} />
                      <FormField labelKey="personnel.dateOfJoining" type="date" value={form.dateOfJoining || ''} onChange={e => updateField('dateOfJoining', e.target.value)} InputLabelProps={{ shrink: true }} />
                    </>
                  ) : (
                    <>
                      {[
                        { label: 'Name', value: person.personName },
                        { label: 'Designation', value: person.designation },
                        { label: 'Section', value: person.section ? `Section ${person.section}` : undefined },
                        { label: 'Duty Type', value: person.dutyType },
                        { label: 'Location', value: person.location },
                        { label: 'Date of Joining', value: person.dateOfJoining },
                      ].map(item => (
                        <Box key={item.label}>
                          <Typography variant="caption" sx={{ fontWeight: 600, color: 'text.secondary', textTransform: 'uppercase', mb: 0.3, display: 'block' }}>
                            {item.label}
                          </Typography>
                          <Typography variant="body2" fontWeight={500} color="text.primary">
                            {item.value || '—'}
                          </Typography>
                        </Box>
                      ))}
                    </>
                  )}
                </Box>
                {editing && (
                  <FormControlLabel sx={{ mt: 2 }}
                    control={<Switch checked={form.isActive !== false} onChange={e => updateField('isActive', e.target.checked)} />}
                    label={<Typography variant="body2">Active</Typography>}
                  />
                )}
              </CardContent>
            </Card>
          )}
        </Box>

        {/* Contact Tab */}
        <Box
          role="tabpanel"
          hidden={activeTab !== 1}
          id="profile-tabpanel-1"
          aria-labelledby="profile-tab-1"
        >
          {activeTab === 1 && (
            <Card variant="outlined" sx={{ borderRadius: 3, borderColor: 'divider' }}>
              <CardContent sx={{ p: 3 }}>
                <Typography variant="subtitle1" fontWeight={600} color="text.primary" sx={{ mb: 3 }}>
                  Contact Information
                </Typography>
                {editing ? (
                  <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 2 }}>
                    <FormField labelKey="personnel.phoneNumber" value={form.phoneNumber || ''} onChange={e => updateField('phoneNumber', e.target.value)} />
                    <FormField labelKey="personnel.email" value={form.email || ''} onChange={e => updateField('email', e.target.value)} />
                  </Box>
                ) : (
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    {/* Phone */}
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 2, borderRadius: 2, bgcolor: 'action.hover', border: '1px solid', borderColor: 'divider' }}>
                      <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: '#dbeafe', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <PhoneIcon sx={{ fontSize: 20, color: '#1d4ed8' }} />
                      </Box>
                      <Box sx={{ flex: 1 }}>
                        <Typography variant="caption" sx={{ color: 'text.secondary', textTransform: 'uppercase', fontWeight: 600, display: 'block' }}>
                          Phone
                        </Typography>
                        <Typography variant="body2" fontWeight={500} color="text.primary">
                          {person.phoneNumber || '—'}
                        </Typography>
                      </Box>
                      {person.phoneNumber && (
                        <Button size="small" sx={{ textTransform: 'none', fontSize: '0.78rem' }}>
                          Message
                        </Button>
                      )}
                    </Box>

                    {/* Email */}
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 2, borderRadius: 2, bgcolor: 'action.hover', border: '1px solid', borderColor: 'divider' }}>
                      <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: '#fef3c7', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <EmailIcon sx={{ fontSize: 20, color: '#d97706' }} />
                      </Box>
                      <Box sx={{ flex: 1 }}>
                        <Typography variant="caption" sx={{ color: 'text.secondary', textTransform: 'uppercase', fontWeight: 600, display: 'block' }}>
                          Email
                        </Typography>
                        <Typography variant="body2" fontWeight={500} color="text.primary">
                          {person.email || '—'}
                        </Typography>
                      </Box>
                      {person.email && (
                        <Button size="small" sx={{ textTransform: 'none', fontSize: '0.78rem' }}
                          onClick={() => window.open(`mailto:${person.email}`)}>
                          Send Email
                        </Button>
                      )}
                    </Box>

                    {/* Address/Location (if available) */}
                    {person.location && (
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 2, borderRadius: 2, bgcolor: 'action.hover', border: '1px solid', borderColor: 'divider' }}>
                        <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: '#ecfdf5', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                          <LocationOnIcon sx={{ fontSize: 20, color: '#059669' }} />
                        </Box>
                        <Box sx={{ flex: 1 }}>
                          <Typography variant="caption" sx={{ color: 'text.secondary', textTransform: 'uppercase', fontWeight: 600, display: 'block' }}>
                            Location
                          </Typography>
                          <Typography variant="body2" fontWeight={500} color="text.primary">
                            {person.location}
                          </Typography>
                        </Box>
                      </Box>
                    )}
                  </Box>
                )}
              </CardContent>
            </Card>
          )}
        </Box>
      </Box>
    </Box>
  );
};

export default PersonnelProfilePage;

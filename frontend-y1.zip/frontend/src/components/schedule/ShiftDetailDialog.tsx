import React from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Box,
  Chip,
  Divider,
  Stack,
  IconButton,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import PersonIcon from '@mui/icons-material/Person';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import GroupIcon from '@mui/icons-material/Group';
import SwapHorizIcon from '@mui/icons-material/SwapHoriz';
import EditIcon from '@mui/icons-material/Edit';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import type { ShiftDetailDialogProps } from '../../types/schedule';

/**
 * Computes duration string from start/end times.
 */
function computeDuration(startTime: string, endTime: string): string {
  if (!startTime || !endTime) return '8 hours';
  const [sh, sm] = startTime.split(':').map(Number);
  const [eh, em] = endTime.split(':').map(Number);
  let diff = (eh * 60 + em) - (sh * 60 + sm);
  if (diff <= 0) diff += 24 * 60; // overnight shift
  const hours = Math.floor(diff / 60);
  const minutes = diff % 60;
  if (minutes === 0) return `${hours} hours`;
  return `${hours}h ${minutes}m`;
}

/**
 * Gets chip color based on shift type.
 */
function getShiftTypeColor(shiftType: string): 'primary' | 'success' | 'warning' | 'secondary' | 'default' {
  const normalized = shiftType.toLowerCase();
  if (normalized.includes('morning')) return 'primary';
  if (normalized.includes('afternoon')) return 'success';
  if (normalized.includes('night')) return 'warning';
  if (normalized.includes('special')) return 'secondary';
  return 'default';
}

/**
 * Formats a date string (YYYY-MM-DD) to a human-friendly format.
 */
function formatDate(dateStr: string): string {
  if (!dateStr) return '';
  const date = new Date(dateStr + 'T00:00:00');
  return date.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

/**
 * ShiftDetailDialog — Popup showing full details of a selected shift.
 * Includes duty type, time range, duration, assigned member, date, group,
 * and action buttons for changing timing, reassigning, or removing the shift.
 */
const ShiftDetailDialog: React.FC<ShiftDetailDialogProps> = ({
  open,
  onClose,
  shift,
  memberName,
  memberGroup,
}) => {
  if (!shift) return null;

  const duration = computeDuration(shift.startTime, shift.endTime);
  const chipColor = getShiftTypeColor(shift.shiftType);

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="xs"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: '14px',
          overflow: 'hidden',
        },
      }}
    >
      {/* Header */}
      <DialogTitle
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          pb: 1,
        }}
      >
        <Typography variant="h6" sx={{ fontWeight: 600, fontSize: '1.1rem' }}>
          Shift Details
        </Typography>
        <IconButton size="small" onClick={onClose} aria-label="Close">
          <CloseIcon sx={{ fontSize: 20 }} />
        </IconButton>
      </DialogTitle>

      <DialogContent sx={{ px: 3, pb: 2 }}>
        {/* Shift type chip */}
        <Box sx={{ mb: 2 }}>
          <Chip
            label={shift.shiftType}
            color={chipColor}
            size="medium"
            sx={{ fontWeight: 600, fontSize: '0.875rem' }}
          />
        </Box>

        <Divider sx={{ mb: 2 }} />

        {/* Detail rows */}
        <Stack spacing={2}>
          {/* Time */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
            <AccessTimeIcon sx={{ fontSize: 20, color: '#6B7280' }} />
            <Box>
              <Typography variant="caption" sx={{ color: '#6B7280', display: 'block' }}>
                Time Range
              </Typography>
              <Typography variant="body2" sx={{ fontWeight: 500 }}>
                {shift.startTime} - {shift.endTime} ({duration})
              </Typography>
            </Box>
          </Box>

          {/* Assigned to */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
            <PersonIcon sx={{ fontSize: 20, color: '#6B7280' }} />
            <Box>
              <Typography variant="caption" sx={{ color: '#6B7280', display: 'block' }}>
                Assigned To
              </Typography>
              <Typography variant="body2" sx={{ fontWeight: 500 }}>
                {memberName}
              </Typography>
            </Box>
          </Box>

          {/* Date */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
            <CalendarTodayIcon sx={{ fontSize: 20, color: '#6B7280' }} />
            <Box>
              <Typography variant="caption" sx={{ color: '#6B7280', display: 'block' }}>
                Date
              </Typography>
              <Typography variant="body2" sx={{ fontWeight: 500 }}>
                {formatDate(shift.date)}
              </Typography>
            </Box>
          </Box>

          {/* Section/Group */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
            <GroupIcon sx={{ fontSize: 20, color: '#6B7280' }} />
            <Box>
              <Typography variant="caption" sx={{ color: '#6B7280', display: 'block' }}>
                Section / Group
              </Typography>
              <Typography variant="body2" sx={{ fontWeight: 500 }}>
                {memberGroup}
              </Typography>
            </Box>
          </Box>
        </Stack>
      </DialogContent>

      <Divider />

      {/* Action buttons */}
      <DialogActions sx={{ px: 3, py: 2, justifyContent: 'space-between' }}>
        <Button
          size="small"
          color="error"
          startIcon={<DeleteOutlineIcon />}
          onClick={onClose}
          sx={{
            textTransform: 'none',
            fontWeight: 500,
            borderRadius: '8px',
          }}
        >
          Remove Shift
        </Button>
        <Box sx={{ display: 'flex', gap: 1 }}>
          <Button
            size="small"
            variant="outlined"
            startIcon={<SwapHorizIcon />}
            onClick={onClose}
            sx={{
              textTransform: 'none',
              fontWeight: 500,
              borderRadius: '8px',
              borderColor: '#E5E7EB',
              color: '#374151',
              '&:hover': { borderColor: '#D1D5DB', backgroundColor: '#F9FAFB' },
            }}
          >
            Reassign
          </Button>
          <Button
            size="small"
            variant="contained"
            startIcon={<EditIcon />}
            onClick={onClose}
            disableElevation
            sx={{
              textTransform: 'none',
              fontWeight: 500,
              borderRadius: '8px',
              backgroundColor: '#2563EB',
              '&:hover': { backgroundColor: '#1D4ED8' },
            }}
          >
            Change Timing
          </Button>
        </Box>
      </DialogActions>
    </Dialog>
  );
};

export default ShiftDetailDialog;

import api from './api';

export type CycleStatus = 'ACTIVE' | 'COMPLETED' | 'DELETED';

export interface PlatoonSectionMapping {
  platoonId: number;
  sectionIds: number[];
}

export interface CycleCreateRequest {
  startDate: string;
  rotationDays: number;
  platoonSections: PlatoonSectionMapping[];
}

export interface CycleResponse {
  id: number;
  startDate: string;
  endDate: string;
  rotationDays: number;
  status: CycleStatus;
  platoonSections: PlatoonSectionMapping[];
  createdAt: string;
  updatedAt: string;
}

export interface AssignmentResponse {
  id: number;
  cycleId: number;
  date: string;
  platoonId: number;
  sectionId: number;
  personId: number;
  personName: string;
  shiftType: string;
  isOverride: boolean;
  updatedAt: string;
  onLeave: boolean;
}

export interface SectionInfo {
  id: number;
  code: string;
  name: string;
  description: string | null;
  sortOrder: number;
  isActive: boolean;
  dutyTypeCount: number;
}

export interface ReassignResponse {
  id: number;
  cycleId: number;
  date: string;
  platoonId: number;
  sectionId: number;
  personId: number;
  shiftType: string;
  isOverride: boolean;
  updatedAt: string;
}

export interface CycleAuditLog {
  id: number;
  cycleId: number;
  action: string;
  description: string;
  oldValue: string | null;
  newValue: string | null;
  performedBy: number | null;
  createdAt: string;
}

export const cycleService = {
  /** Fetch all sections (for schedule display labels/colors) */
  getSections: () =>
    api.get<SectionInfo[]>('/api/sections').then((r) => r.data),

  /** Fetch all cycles, optionally filtered by status */
  getCycles: (status?: CycleStatus) =>
    api
      .get<CycleResponse[]>('/api/cycles', {
        params: status ? { status } : undefined,
      })
      .then((r) => r.data),

  /** Fetch a single cycle by ID */
  getCycleById: (id: number) =>
    api.get<CycleResponse>(`/api/cycles/${id}`).then((r) => r.data),

  /** Create a new cycle with platoon-section mappings */
  createCycle: (request: CycleCreateRequest) =>
    api.post<CycleResponse>('/api/cycles', request).then((r) => r.data),

  /** Fetch assignments for a given cycle and date, including leave conflict flags */
  getAssignments: (cycleId: number, date: string) =>
    api
      .get<AssignmentResponse[]>('/api/assignments', {
        params: { cycleId, date },
      })
      .then((r) => r.data),

  /** Fetch assignments for a date range (for week/month views) */
  getAssignmentsByRange: (cycleId: number, startDate: string, endDate: string) =>
    api
      .get<AssignmentResponse[]>('/api/assignments/range', {
        params: { cycleId, startDate, endDate },
      })
      .then((r) => r.data),

  /** Reassign a duty assignment to a different person */
  reassignDuty: (assignmentId: number, newPersonId: number) =>
    api
      .patch<ReassignResponse>('/api/assignments/reassign', {
        assignmentId,
        newPersonId,
      })
      .then((r) => r.data),

  /** Fetch all audit logs */
  getAuditLogs: () =>
    api.get<CycleAuditLog[]>('/api/cycles/audit').then((r) => r.data),

  /** Fetch audit logs for a specific cycle */
  getAuditLogsByCycle: (cycleId: number) =>
    api.get<CycleAuditLog[]>(`/api/cycles/${cycleId}/audit`).then((r) => r.data),
};

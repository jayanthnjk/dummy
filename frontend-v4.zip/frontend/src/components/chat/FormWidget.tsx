import React, { useState } from 'react';
import {
  TextField, Select, MenuItem, FormControl, InputLabel,
  Button, Typography, Box, FormHelperText, Chip,
} from '@mui/material';
import PersonAddAltIcon from '@mui/icons-material/PersonAddAlt';
import BadgeOutlinedIcon from '@mui/icons-material/BadgeOutlined';
import WorkOutlineIcon from '@mui/icons-material/WorkOutline';
import LocationOnOutlinedIcon from '@mui/icons-material/LocationOnOutlined';
import PhoneOutlinedIcon from '@mui/icons-material/PhoneOutlined';
import EmailOutlinedIcon from '@mui/icons-material/EmailOutlined';
import AccountTreeOutlinedIcon from '@mui/icons-material/AccountTreeOutlined';
import AssignmentIndOutlinedIcon from '@mui/icons-material/AssignmentIndOutlined';
import DirectionsCarIcon from '@mui/icons-material/DirectionsCar';
import type { FormResponseData } from '@/types';

interface FormWidgetProps extends FormResponseData {
  onSubmit: (formId: string, submitAction: string, fields: Record<string, string>) => Promise<boolean>;
}

const FIELD_ICONS: Record<string, React.ReactNode> = {
  personName: <PersonAddAltIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  badgeId: <BadgeOutlinedIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  designation: <AssignmentIndOutlinedIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  section: <AccountTreeOutlinedIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  dutyType: <WorkOutlineIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  location: <LocationOnOutlinedIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  phoneNumber: <PhoneOutlinedIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  email: <EmailOutlinedIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  vehicleNumber: <DirectionsCarIcon sx={{ fontSize: 17, color: '#92400e' }} />,
  dutyLocation: <LocationOnOutlinedIcon sx={{ fontSize: 17, color: '#92400e' }} />,
  pdms: <BadgeOutlinedIcon sx={{ fontSize: 17, color: '#92400e' }} />,
  licenceType: <AssignmentIndOutlinedIcon sx={{ fontSize: 17, color: '#92400e' }} />,
  deployedFrom: <LocationOnOutlinedIcon sx={{ fontSize: 17, color: '#92400e' }} />,
};

const PLACEHOLDERS: Record<string, string> = {
  personName: 'Enter full name',
  badgeId: 'e.g. DCP-01',
  location: 'e.g. Bangalore',
  phoneNumber: 'e.g. 9876543210',
  email: 'e.g. name@example.com',
  vehicleNumber: 'e.g. KA-01-AB-1234',
  dutyLocation: 'e.g. Commissioner Office',
  pdms: 'PDMS number',
  licenceType: 'e.g. LMV, HMV',
  deployedFrom: 'e.g. District Reserve',
};

const DRIVER_FIELDS = ['vehicleNumber', 'dutyLocation', 'pdms', 'licenceType', 'deployedFrom'];

const inputSx = (disabled: boolean) => ({
  '& .MuiOutlinedInput-root': {
    borderRadius: 2,
    bgcolor: disabled ? '#f8fafc' : '#fff',
    fontSize: '0.82rem',
    '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: '#6366f1' },
    '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#6366f1', borderWidth: 2 },
  },
  '& .MuiInputLabel-root': { fontSize: '0.82rem' },
});

const FormWidget: React.FC<FormWidgetProps> = ({ formId, title, fields, submitAction, submitLabel, onSubmit }) => {
  const [values, setValues] = useState<Record<string, string>>(() => {
    const init: Record<string, string> = {};
    for (const f of fields) init[f.name] = f.value ?? '';
    return init;
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const isDriver = values.dutyType?.toUpperCase() === 'DRIVER';

  const handleChange = (name: string, value: string) => {
    setValues((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors((prev) => { const n = { ...prev }; delete n[name]; return n; });
  };

  const handleSubmit = async () => {
    const newErrors: Record<string, string> = {};
    for (const f of fields) {
      if (f.required && !values[f.name]?.trim()) newErrors[f.name] = `${f.label} is required`;
    }
    if (Object.keys(newErrors).length > 0) { setErrors(newErrors); return; }
    setSubmitting(true);
    try {
      const ok = await onSubmit(formId, submitAction, values);
      if (ok) setSubmitted(true);
    } catch { /* keep editable */ } finally { setSubmitting(false); }
  };

  const basicRequired = fields.filter((f) => f.required && !DRIVER_FIELDS.includes(f.name));
  const basicOptional = fields.filter((f) => !f.required && !DRIVER_FIELDS.includes(f.name));
  const driverFields = fields.filter((f) => DRIVER_FIELDS.includes(f.name));

  const renderField = (field: typeof fields[0]) => {
    const icon = FIELD_ICONS[field.name] || null;
    const isSelect = field.type === 'select';
    const isMultiSelect = field.type === 'multi-select';
    const isDate = field.type === 'date';
    const isNumber = field.type === 'number';

    // For select fields that are part of a "group" sharing the same options
    // (e.g., platoon_*_sections), exclude options already selected by other fields in the group
    let availableOptions = field.options ?? [];
    if (isSelect && field.options && field.options.length > 0) {
      // Find sibling fields that share the exact same options
      const siblingFields = fields.filter(
        (f) => f.type === 'select' && f.name !== field.name && f.options &&
          JSON.stringify(f.options) === JSON.stringify(field.options)
      );
      if (siblingFields.length > 0) {
        // Collect values already selected by sibling fields
        const usedValues = siblingFields
          .map((f) => values[f.name])
          .filter((v) => v && v.trim() !== '');
        // Filter out used values (but keep the current field's own value)
        const currentValue = values[field.name] ?? '';
        availableOptions = field.options.filter(
          (opt) => opt === currentValue || !usedValues.includes(opt)
        );
      }
    }

    return (
      <Box key={field.name} sx={{ display: 'flex', alignItems: 'flex-start', gap: 1 }}>
        {icon && (
          <Box sx={{ mt: 1.1, flexShrink: 0, width: 24, display: 'flex', justifyContent: 'center' }}>
            {icon}
          </Box>
        )}
        {(isSelect || isMultiSelect) ? (
          <FormControl size="small" fullWidth error={!!errors[field.name]} disabled={submitted} sx={inputSx(submitted)}>
            <InputLabel>{field.label}{field.required ? ' *' : ''}</InputLabel>
            <Select
              multiple={isMultiSelect}
              value={isMultiSelect ? (values[field.name] ? values[field.name].split(',').filter(Boolean) : []) : (values[field.name] ?? '')}
              label={`${field.label}${field.required ? ' *' : ''}`}
              onChange={(e) => {
                const val = e.target.value;
                handleChange(field.name, Array.isArray(val) ? val.join(',') : val as string);
              }}
              displayEmpty
              renderValue={isMultiSelect ? (selected) => {
                const sel = selected as string[];
                return sel.length === 0 ? '' : sel.join(', ');
              } : undefined}
            >
              {availableOptions.map((opt) => (
                <MenuItem key={opt} value={opt}>{opt}</MenuItem>
              ))}
            </Select>
            {errors[field.name] && <FormHelperText>{errors[field.name]}</FormHelperText>}
          </FormControl>
        ) : (
          <TextField
            size="small" fullWidth
            type={isDate ? 'date' : isNumber ? 'number' : 'text'}
            label={`${field.label}${field.required ? ' *' : ''}`}
            placeholder={PLACEHOLDERS[field.name] || `Enter ${field.label.toLowerCase()}`}
            value={values[field.name] ?? ''}
            onChange={(e) => handleChange(field.name, e.target.value)}
            error={!!errors[field.name]} helperText={errors[field.name]}
            disabled={submitted} sx={inputSx(submitted)}
            InputLabelProps={isDate ? { shrink: true } : undefined}
          />
        )}
      </Box>
    );
  };

  return (
    <Box sx={{ width: '100%', minWidth: 480, borderRadius: 2.5, overflow: 'hidden', border: '1px solid #e5e7eb', bgcolor: '#fff' }}>
      {/* Header */}
      <Box sx={{
        px: 2.5, py: 1.5,
        background: 'linear-gradient(135deg, #1a1e4a 0%, #2d3270 100%)',
        display: 'flex', alignItems: 'center', gap: 1.5,
      }}>
        <Box sx={{
          width: 34, height: 34, borderRadius: 1.5,
          bgcolor: 'rgba(255,255,255,0.15)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <PersonAddAltIcon sx={{ fontSize: 18, color: '#c4a44a' }} />
        </Box>
        <Box>
          <Typography sx={{ fontSize: '0.88rem', fontWeight: 700, color: '#fff', lineHeight: 1.2 }}>{title}</Typography>
          <Typography sx={{ fontSize: '0.68rem', color: 'rgba(255,255,255,0.6)' }}>Fill in the details below</Typography>
        </Box>
      </Box>

      {/* Required fields */}
      <Box sx={{ px: 2.5, pt: 2, pb: 1.5 }}>
        <Chip label="Required" size="small" sx={{ height: 20, fontSize: '0.6rem', fontWeight: 700, bgcolor: '#fef2f2', color: '#dc2626', border: '1px solid #fecaca', mb: 1.5 }} />
        <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1.5 }}>
          {basicRequired.map(renderField)}
        </Box>
      </Box>

      {/* Divider */}
      <Box sx={{ px: 2.5, py: 0.5 }}><Box sx={{ borderTop: '1px dashed #e5e7eb' }} /></Box>

      {/* Optional fields */}
      {basicOptional.length > 0 && (
        <Box sx={{ px: 2.5, pt: 1, pb: 1.5 }}>
          <Chip label="Optional" size="small" sx={{ height: 20, fontSize: '0.6rem', fontWeight: 700, bgcolor: '#f0fdf4', color: '#16a34a', border: '1px solid #bbf7d0', mb: 1.5 }} />
          <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1.5 }}>
            {basicOptional.map(renderField)}
          </Box>
        </Box>
      )}

      {/* Driver fields — conditional */}
      {isDriver && driverFields.length > 0 && (
        <>
          <Box sx={{ px: 2.5, py: 0.5 }}><Box sx={{ borderTop: '1px dashed #c4a44a' }} /></Box>
          <Box sx={{ px: 2.5, pt: 1, pb: 1.5, bgcolor: '#fffbf0' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1.5 }}>
              <DirectionsCarIcon sx={{ fontSize: 16, color: '#92400e' }} />
              <Typography sx={{ fontSize: '0.78rem', fontWeight: 700, color: '#92400e' }}>Driver Details</Typography>
            </Box>
            <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1.5 }}>
              {driverFields.map(renderField)}
            </Box>
          </Box>
        </>
      )}

      {/* Footer */}
      <Box sx={{
        px: 2.5, py: 1.5, bgcolor: '#f8fafc', borderTop: '1px solid #e5e7eb',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <Typography sx={{ fontSize: '0.65rem', color: '#94a3b8' }}>
          {submitted ? '✓ Form submitted successfully' : '* indicates required fields'}
        </Typography>
        <Button
          variant="contained" size="small" onClick={handleSubmit}
          disabled={submitted || submitting}
          sx={{
            textTransform: 'none', fontSize: '0.78rem', fontWeight: 600, px: 3, borderRadius: 2,
            background: submitted ? '#94a3b8' : 'linear-gradient(135deg, #1a1e4a 0%, #2d3270 100%)',
            boxShadow: submitted ? 'none' : '0 2px 8px rgba(26,30,74,0.3)',
            '&:hover': { background: 'linear-gradient(135deg, #0b0e2a 0%, #1a1e4a 100%)', boxShadow: '0 4px 12px rgba(26,30,74,0.4)' },
            '&.Mui-disabled': { background: '#e2e8f0', color: '#94a3b8', boxShadow: 'none' },
          }}
        >
          {submitting ? 'Submitting...' : submitted ? 'Submitted ✓' : (submitLabel || title || 'Submit')}
        </Button>
      </Box>
    </Box>
  );
};

export default FormWidget;
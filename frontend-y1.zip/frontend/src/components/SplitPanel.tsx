import React from 'react';
import { Box } from '@mui/material';
import DutyTypeSidebar from './DutyTypeSidebar';
import MapComponent from './MapComponent';

interface SplitPanelProps {
  isFormOpen?: boolean;
  onMapClick?: (lat: number, lng: number) => void;
  onPinDrag?: (lat: number, lng: number) => void;
  onAddDutyType: () => void;
  onEditDutyType: (id: number) => void;
  onReassignDutyType: (id: number) => void;
}

/**
 * SplitPanel — Professional layout: [DutyTypeSidebar | Map] with matching height.
 * Map is taller (550px on desktop) for better visibility.
 */
const SplitPanel: React.FC<SplitPanelProps> = ({
  isFormOpen,
  onMapClick,
  onPinDrag,
  onAddDutyType,
  onEditDutyType,
  onReassignDutyType,
}) => {
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, width: '100%' }}>
      {/* Top section: Sidebar + Map — matching height, no gap */}
      <Box
        sx={{
          display: 'flex',
          flexDirection: { xs: 'column', md: 'row' },
          width: '100%',
          height: { xs: 'auto', md: 550 },
          borderRadius: 2,
          overflow: 'hidden',
          boxShadow: '0 1px 3px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04)',
          border: '1px solid #E2E8F0',
          backgroundColor: 'white',
        }}
      >
        {/* Left: Duty Type Sidebar */}
        <DutyTypeSidebar
          onAddDutyType={onAddDutyType}
          onEditDutyType={onEditDutyType}
          onReassignDutyType={onReassignDutyType}
        />

        {/* Right: Map Panel — fills remaining space */}
        <Box
          sx={{
            flex: 1,
            minWidth: 0,
            minHeight: { xs: 400, md: '100%' },
            height: { xs: 400, md: '100%' },
          }}
        >
          <MapComponent
            isFormOpen={isFormOpen}
            onMapClick={onMapClick}
            onPinDrag={onPinDrag}
          />
        </Box>
      </Box>
    </Box>
  );
};

export default SplitPanel;

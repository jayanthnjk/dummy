import React, { useEffect, useState, useCallback } from 'react';
import {
  Box,
  Button,
  Chip,
  CircularProgress,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import {
  cycleService,
  type AssignmentResponse,
  type CycleResponse,
} from '@/services/cycleService';

/** Predefined platoon names keyed by ID */
const PLATOON_NAMES: Record<number, string> = {
  1: 'Platoon I',
  2: 'Platoon II',
  3: 'Platoon III',
  4: 'Platoon IV',
  5: 'Platoon V',
};

/** Section names keyed by ID */
const SECTION_NAMES: Record<number, string> = {
  3: 'Section C',
  4: 'Section D',
  5: 'Section E',
  6: 'Section F',
  7: 'Section G',
};

interface CycleDetailViewProps {
  /** The ID of the cycle to display */
  cycleId: number;
  /** Callback to navigate back to the cycle list */
  onBack: () => void;
  /** Callback when a leave-conflict assignment is clicked (opens ReassignModal) */
  onReassign?: (assignment: AssignmentResponse) => void;
}

/**
 * CycleDetailView — Displays detailed information about a platoon rotation cycle.
 *
 * Shows cycle summary info, platoon-to-section mappings, and a date-based
 * assignment grid with leave conflict indicators.
 *
 * Implements Requirements 4.4, 7.1.
 */
const CycleDetailView: React.FC<CycleDetailViewProps> = ({ cycleId, onBack, onReassign }) => {
  const [cycle, setCycle] = useState<CycleResponse | null>(null);
  const [assignments, setAssignments] = useState<AssignmentResponse[]>([]);
  const [selectedDate, setSelectedDate] = useState('');
  const [loadingCycle, setLoadingCycle] = useState(true);
  const [loadingAssignments, setLoadingAssignments] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch cycle details on mount
  useEffect(() => {
    const fetchCycle = async () => {
      setLoadingCycle(true);
      setError(null);
      try {
        const data = await cycleService.getCycleById(cycleId);
        setCycle(data);
        // Default selected date to the cycle's start date
        setSelectedDate(data.startDate);
      } catch (err: unknown) {
        const message = err instanceof Error ? err.message : 'Failed to load cycle details';
        setError(message);
      } finally {
        setLoadingCycle(false);
      }
    };
    fetchCycle();
  }, [cycleId]);

  // Fetch assignments when selectedDate changes
  const fetchAssignments = useCallback(async () => {
    if (!selectedDate) return;
    setLoadingAssignments(true);
    try {
      const data = await cycleService.getAssignments(cycleId, selectedDate);
      setAssignments(data);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to load assignments';
      setError(message);
    } finally {
      setLoadingAssignments(false);
    }
  }, [cycleId, selectedDate]);

  useEffect(() => {
    if (selectedDate) {
      fetchAssignments();
    }
  }, [selectedDate, fetchAssignments]);

  const handleDateChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSelectedDate(event.target.value);
  };

  const handleLeaveClick = (assignment: AssignmentResponse) => {
    onReassign?.(assignment);
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  // Loading state
  if (loadingCycle) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
        <CircularProgress size={36} />
      </Box>
    );
  }

  // Error state
  if (error && !cycle) {
    return (
      <Box sx={{ py: 4 }}>
        <Button startIcon={<ArrowBackIcon />} onClick={onBack} sx={{ mb: 2 }}>
          Back to Cycles
        </Button>
        <Typography color="error">{error}</Typography>
      </Box>
    );
  }

  if (!cycle) return null;

  return (
    <Box sx={{ width: '100%' }}>
      {/* Back button */}
      <Button startIcon={<ArrowBackIcon />} onClick={onBack} sx={{ mb: 2 }}>
        Back to Cycles
      </Button>

      {/* Cycle summary header */}
      <Paper variant="outlined" sx={{ p: 2, mb: 3 }}>
        <Typography variant="h6" fontWeight={600} gutterBottom>
          Cycle Details
        </Typography>
        <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 2 }}>
          <Box>
            <Typography variant="caption" color="text.secondary">Start Date</Typography>
            <Typography variant="body2" fontWeight={500}>{formatDate(cycle.startDate)}</Typography>
          </Box>
          <Box>
            <Typography variant="caption" color="text.secondary">End Date</Typography>
            <Typography variant="body2" fontWeight={500}>{formatDate(cycle.endDate)}</Typography>
          </Box>
          <Box>
            <Typography variant="caption" color="text.secondary">Rotation Days</Typography>
            <Typography variant="body2" fontWeight={500}>{cycle.rotationDays}</Typography>
          </Box>
          <Box>
            <Typography variant="caption" color="text.secondary">Status</Typography>
            <Typography variant="body2" fontWeight={500}>
              <Chip
                label={cycle.status}
                size="small"
                color={cycle.status === 'ACTIVE' ? 'success' : cycle.status === 'COMPLETED' ? 'info' : 'error'}
                variant="outlined"
              />
            </Typography>
          </Box>
        </Box>
      </Paper>

      {/* Platoon-to-Section Mappings Table */}
      <Paper variant="outlined" sx={{ p: 2, mb: 3 }}>
        <Typography variant="subtitle1" fontWeight={600} gutterBottom>
          Platoon–Section Mappings
        </Typography>
        <TableContainer>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell sx={{ fontWeight: 600 }}>Platoon</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Sections</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {cycle.platoonSections.map((mapping) => (
                <TableRow key={mapping.platoonId}>
                  <TableCell>{PLATOON_NAMES[mapping.platoonId] ?? `Platoon ${mapping.platoonId}`}</TableCell>
                  <TableCell>
                    <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
                      {mapping.sectionIds.map((sectionId) => (
                        <Chip
                          key={sectionId}
                          label={SECTION_NAMES[sectionId] ?? `Section ${sectionId}`}
                          size="small"
                          variant="outlined"
                        />
                      ))}
                    </Box>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      {/* Date-based Assignment Grid */}
      <Paper variant="outlined" sx={{ p: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
          <Typography variant="subtitle1" fontWeight={600}>
            Duty Assignments
          </Typography>
          <TextField
            label="Date"
            type="date"
            value={selectedDate}
            onChange={handleDateChange}
            size="small"
            InputLabelProps={{ shrink: true }}
            inputProps={{
              min: cycle.startDate,
              max: cycle.endDate,
            }}
          />
        </Box>

        {loadingAssignments && (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
            <CircularProgress size={28} />
          </Box>
        )}

        {!loadingAssignments && assignments.length === 0 && (
          <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center', py: 4 }}>
            No assignments found for this date.
          </Typography>
        )}

        {!loadingAssignments && assignments.length > 0 && (
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 600 }}>Person ID</TableCell>
                  <TableCell sx={{ fontWeight: 600 }}>Platoon</TableCell>
                  <TableCell sx={{ fontWeight: 600 }}>Section</TableCell>
                  <TableCell sx={{ fontWeight: 600 }}>Shift Type</TableCell>
                  <TableCell sx={{ fontWeight: 600 }}>Override</TableCell>
                  <TableCell sx={{ fontWeight: 600 }}>Leave Status</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {assignments.map((assignment) => (
                  <TableRow key={assignment.id}>
                    <TableCell>{assignment.personId}</TableCell>
                    <TableCell>{PLATOON_NAMES[assignment.platoonId] ?? `Platoon ${assignment.platoonId}`}</TableCell>
                    <TableCell>{SECTION_NAMES[assignment.sectionId] ?? `Section ${assignment.sectionId}`}</TableCell>
                    <TableCell>{assignment.shiftType}</TableCell>
                    <TableCell>
                      {assignment.isOverride ? (
                        <Chip label="Override" size="small" color="warning" variant="outlined" />
                      ) : (
                        '—'
                      )}
                    </TableCell>
                    <TableCell>
                      {assignment.onLeave ? (
                        <Chip
                          label="On Leave"
                          size="small"
                          color="error"
                          onClick={() => handleLeaveClick(assignment)}
                          sx={{ cursor: 'pointer' }}
                        />
                      ) : (
                        <Chip label="Available" size="small" color="success" variant="outlined" />
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}

        {error && !loadingAssignments && (
          <Typography color="error" variant="body2" sx={{ mt: 1 }}>
            {error}
          </Typography>
        )}
      </Paper>
    </Box>
  );
};

export default CycleDetailView;

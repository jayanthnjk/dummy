import React, { useState } from 'react';
import Box from '@mui/material/Box';
import Table from '@mui/material/Table';
import TableHead from '@mui/material/TableHead';
import TableBody from '@mui/material/TableBody';
import TableRow from '@mui/material/TableRow';
import TableCell from '@mui/material/TableCell';
import TablePagination from '@mui/material/TablePagination';
import Typography from '@mui/material/Typography';
import Avatar from '@mui/material/Avatar';
import Tooltip from '@mui/material/Tooltip';
import { ScheduleGridProps } from '../../types/schedule';
import ShiftCell from './ShiftCell';
import ShiftBlock from './ShiftBlock';
import { computeTotalHours } from '../../utils/scheduleFormatting';
import { getDayColumns } from '../../utils/dateNavigation';

/** Maximum visible name length before truncation */
const MAX_NAME_LENGTH = 22;

/** Default rows per page */
const DEFAULT_ROWS_PER_PAGE = 15;

/** Available rows per page options */
const ROWS_PER_PAGE_OPTIONS = [10, 15, 25, 50];

/**
 * Extracts initials from a full name (first letter of first and last name).
 */
function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/);
  if (parts.length === 0) return '';
  if (parts.length === 1) return parts[0].charAt(0).toUpperCase();
  return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
}

/**
 * Truncates a name if it exceeds MAX_NAME_LENGTH, appending ellipsis.
 */
function truncateName(name: string): string {
  if (name.length <= MAX_NAME_LENGTH) return name;
  return name.substring(0, MAX_NAME_LENGTH) + '…';
}

/**
 * ScheduleGrid — Enterprise-grade calendar grid with:
 * - Alternating row colors (white / #F9FAFB)
 * - Subtle grid lines (#E5E7EB)
 * - Sticky left column with shadow
 * - Today column with soft blue tint
 * - Open Shifts row with cream background
 * - Pagination with rows per page selector
 */
const ScheduleGrid: React.FC<ScheduleGridProps> = ({
  viewMode,
  dateRange,
  teamMembers,
  openShifts,
  showOpenShifts,
  showTimeOff,
  onAddShift,
  onShiftClick,
  todayDate,
}) => {
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(DEFAULT_ROWS_PER_PAGE);

  const dayColumns = getDayColumns(dateRange, viewMode);

  // Pagination logic
  const totalMembers = teamMembers.length;
  const paginatedMembers = teamMembers.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );

  const handleChangePage = (_event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        flex: 1,
        overflow: 'hidden',
      }}
    >
      {/* Scrollable grid area */}
      <Box
        sx={{
          flex: 1,
          overflowX: 'auto',
          overflowY: 'auto',
        }}
      >
        <Table
          size="small"
          aria-label="Schedule grid"
          sx={{
            borderCollapse: 'separate',
            borderSpacing: 0,
            minWidth: 900,
          }}
        >
          {/* Column Headers */}
          <TableHead>
            <TableRow>
              {/* Team Member column header — sticky left */}
              <TableCell
                sx={{
                  fontWeight: 600,
                  fontSize: '0.75rem',
                  color: '#6B7280',
                  textTransform: 'uppercase',
                  letterSpacing: '0.05em',
                  minWidth: 220,
                  width: 220,
                  position: 'sticky',
                  left: 0,
                  zIndex: 4,
                  backgroundColor: '#F9FAFB',
                  borderBottom: '2px solid #E5E7EB',
                  borderRight: '1px solid #E5E7EB',
                  boxShadow: '2px 0 4px -1px rgba(0,0,0,0.06)',
                  py: 1.5,
                  px: 2,
                }}
              >
                Team Member
              </TableCell>

              {/* Day columns */}
              {dayColumns.map((col) => (
                <TableCell
                  key={col.date}
                  align="center"
                  sx={{
                    minWidth: 100,
                    backgroundColor: col.isToday ? '#EFF6FF' : '#F9FAFB',
                    borderBottom: '2px solid #E5E7EB',
                    borderRight: '1px solid #E5E7EB',
                    py: 1,
                    px: 0.5,
                  }}
                >
                  <Typography
                    variant="caption"
                    sx={{
                      fontWeight: 700,
                      fontSize: '0.75rem',
                      color: col.isToday ? '#2563EB' : '#374151',
                      display: 'block',
                      lineHeight: 1.3,
                    }}
                  >
                    {col.dayName}
                  </Typography>
                  <Typography
                    variant="caption"
                    sx={{
                      fontSize: '0.6875rem',
                      color: col.isToday ? '#3B82F6' : '#9CA3AF',
                      display: 'block',
                      lineHeight: 1.3,
                    }}
                  >
                    {col.date.split('-')[2]}
                  </Typography>
                </TableCell>
              ))}

              {/* Hours column header */}
              <TableCell
                align="right"
                sx={{
                  fontWeight: 600,
                  fontSize: '0.75rem',
                  color: '#6B7280',
                  textTransform: 'uppercase',
                  letterSpacing: '0.05em',
                  minWidth: 64,
                  backgroundColor: '#F3F4F6',
                  borderBottom: '2px solid #E5E7EB',
                  py: 1.5,
                  px: 1.5,
                }}
              >
                Hours
              </TableCell>
            </TableRow>
          </TableHead>

          <TableBody>
            {/* Open Shifts Row */}
            {showOpenShifts && (
              <TableRow>
                <TableCell
                  sx={{
                    fontWeight: 600,
                    position: 'sticky',
                    left: 0,
                    zIndex: 3,
                    backgroundColor: '#FFFBEB',
                    borderBottom: '1px solid #E5E7EB',
                    borderRight: '1px solid #E5E7EB',
                    boxShadow: '2px 0 4px -1px rgba(0,0,0,0.06)',
                    py: 1,
                    px: 2,
                  }}
                >
                  <Typography
                    variant="body2"
                    sx={{
                      fontWeight: 600,
                      fontSize: '0.8125rem',
                      color: '#92400E',
                    }}
                  >
                    Open Shifts
                  </Typography>
                </TableCell>

                {dayColumns.map((col) => {
                  const shiftsForDay = openShifts.filter(
                    (s) => s.date === col.date
                  );
                  return (
                    <TableCell
                      key={col.date}
                      sx={{
                        p: '6px 8px',
                        verticalAlign: 'middle',
                        backgroundColor: '#FFFBEB',
                        borderBottom: '1px solid #E5E7EB',
                        borderRight: '1px solid #E5E7EB',
                      }}
                    >
                      <Box sx={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                        {shiftsForDay.map((shift) => (
                          <ShiftBlock
                            key={shift.id}
                            shift={shift as any}
                            color=""
                            textColor=""
                          />
                        ))}
                      </Box>
                    </TableCell>
                  );
                })}

                {/* Empty hours cell for open shifts row */}
                <TableCell
                  align="right"
                  sx={{
                    backgroundColor: '#FFFBEB',
                    borderBottom: '1px solid #E5E7EB',
                    px: 1.5,
                    color: '#9CA3AF',
                  }}
                >
                  —
                </TableCell>
              </TableRow>
            )}

            {/* Team Member Rows — paginated */}
            {paginatedMembers.map((schedule, rowIndex) => {
              const { member, shifts, timeOffs } = schedule;
              const totalHours = computeTotalHours(shifts);
              const displayName = truncateName(member.name);
              const needsTooltip = member.name.length > MAX_NAME_LENGTH;
              const isEvenRow = rowIndex % 2 === 0;

              return (
                <TableRow
                  key={member.id}
                  sx={{
                    backgroundColor: isEvenRow ? '#FFFFFF' : '#F9FAFB',
                    '&:hover': {
                      backgroundColor: '#F0F9FF',
                    },
                  }}
                >
                  {/* Team Member info cell — sticky left */}
                  <TableCell
                    sx={{
                      position: 'sticky',
                      left: 0,
                      zIndex: 2,
                      backgroundColor: isEvenRow ? '#FFFFFF' : '#F9FAFB',
                      borderBottom: '1px solid #E5E7EB',
                      borderRight: '1px solid #E5E7EB',
                      boxShadow: '2px 0 4px -1px rgba(0,0,0,0.06)',
                      py: 1,
                      px: 2,
                      'tr:hover &': {
                        backgroundColor: '#F0F9FF',
                      },
                    }}
                  >
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                      <Avatar
                        src={member.avatar || undefined}
                        sx={{
                          width: 32,
                          height: 32,
                          fontSize: '0.75rem',
                          fontWeight: 600,
                          backgroundColor: '#E0E7FF',
                          color: '#3730A3',
                        }}
                      >
                        {!member.avatar && getInitials(member.name)}
                      </Avatar>
                      <Box sx={{ overflow: 'hidden', minWidth: 0 }}>
                        {needsTooltip ? (
                          <Tooltip title={member.name} arrow>
                            <Typography
                              variant="body2"
                              sx={{
                                fontWeight: 500,
                                fontSize: '0.8125rem',
                                color: '#111827',
                                whiteSpace: 'nowrap',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                maxWidth: 150,
                                lineHeight: 1.4,
                              }}
                            >
                              {displayName}
                            </Typography>
                          </Tooltip>
                        ) : (
                          <Typography
                            variant="body2"
                            sx={{
                              fontWeight: 500,
                              fontSize: '0.8125rem',
                              color: '#111827',
                              whiteSpace: 'nowrap',
                              lineHeight: 1.4,
                            }}
                          >
                            {displayName}
                          </Typography>
                        )}
                        <Typography
                          variant="caption"
                          sx={{
                            color: '#6B7280',
                            whiteSpace: 'nowrap',
                            fontSize: '0.6875rem',
                            lineHeight: 1.3,
                          }}
                        >
                          {member.role}
                        </Typography>
                      </Box>
                    </Box>
                  </TableCell>

                  {/* Shift cells per day */}
                  {dayColumns.map((col) => {
                    const dayShifts = shifts.filter((s) => s.date === col.date);
                    const dayTimeOffs = timeOffs.filter(
                      (t) => t.date === col.date
                    );

                    return (
                      <ShiftCell
                        key={col.date}
                        memberId={member.id}
                        date={col.date}
                        shifts={dayShifts}
                        timeOffs={dayTimeOffs}
                        showTimeOff={showTimeOff}
                        shiftTypes={[]}
                        onAddShift={onAddShift}
                        onShiftClick={
                          onShiftClick
                            ? (shift) => onShiftClick(shift, member.name, member.group)
                            : undefined
                        }
                        isToday={col.isToday}
                      />
                    );
                  })}

                  {/* Total hours cell — right-aligned with subtle background */}
                  <TableCell
                    align="right"
                    sx={{
                      backgroundColor: '#F3F4F6',
                      borderBottom: '1px solid #E5E7EB',
                      px: 1.5,
                    }}
                  >
                    <Typography
                      variant="body2"
                      sx={{
                        fontWeight: 600,
                        fontSize: '0.8125rem',
                        color: '#374151',
                      }}
                    >
                      {totalHours > 0 ? `${totalHours}h` : '—'}
                    </Typography>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Box>

      {/* Pagination footer */}
      <Box
        sx={{
          borderTop: '1px solid #E5E7EB',
          backgroundColor: '#FFFFFF',
          flexShrink: 0,
        }}
      >
        <TablePagination
          component="div"
          count={totalMembers}
          page={page}
          onPageChange={handleChangePage}
          rowsPerPage={rowsPerPage}
          onRowsPerPageChange={handleChangeRowsPerPage}
          rowsPerPageOptions={ROWS_PER_PAGE_OPTIONS}
          labelRowsPerPage="Rows per page:"
          labelDisplayedRows={({ from, to, count }) =>
            `Showing ${from}-${to} of ${count} members`
          }
          sx={{
            '& .MuiTablePagination-toolbar': {
              px: 2,
              minHeight: 48,
            },
            '& .MuiTablePagination-selectLabel, & .MuiTablePagination-displayedRows': {
              fontSize: '0.8125rem',
              color: '#6B7280',
            },
            '& .MuiTablePagination-select': {
              fontSize: '0.8125rem',
            },
          }}
        />
      </Box>
    </Box>
  );
};

export default ScheduleGrid;

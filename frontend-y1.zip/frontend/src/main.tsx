import React from 'react';
import ReactDOM from 'react-dom/client';
import '@/i18n';
import { AuthProvider } from '@/contexts/AuthContext';
import { ThemeContextProvider } from '@/contexts/ThemeContext';
import { LanguageContextProvider } from '@/contexts/LanguageContext';
import App from '@/App';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <AuthProvider>
      <ThemeContextProvider>
        <LanguageContextProvider>
          <App />
        </LanguageContextProvider>
      </ThemeContextProvider>
    </AuthProvider>
  </React.StrictMode>,
);

package com.policescheduler.controller;

import com.policescheduler.dto.DutyHistoryDto;
import com.policescheduler.entity.DutyHistory;
import com.policescheduler.repository.DutyHistoryRepository;
import com.policescheduler.service.DutyHistoryReportService;
import com.policescheduler.service.DutyHistorySchedulerService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * REST Controller for duty history operations.
 * Provides endpoints for:
 * - Querying historical duty records
 * - Generating PDF/Excel reports
 * - Manually triggering schedulers (admin operations)
 */
@RestController
@RequestMapping("/api/duty-history")
public class DutyHistoryController {

    private final DutyHistoryRepository dutyHistoryRepository;
    private final DutyHistorySchedulerService schedulerService;
    private final DutyHistoryReportService reportService;

    public DutyHistoryController(DutyHistoryRepository dutyHistoryRepository,
                                  DutyHistorySchedulerService schedulerService,
                                  DutyHistoryReportService reportService) {
        this.dutyHistoryRepository = dutyHistoryRepository;
        this.schedulerService = schedulerService;
        this.reportService = reportService;
    }

    // =========================================================================
    // QUERY ENDPOINTS
    // =========================================================================

    /**
     * Get paginated duty history for a specific person.
     * Optional date filters: startDate and endDate.
     * If no dates provided, returns all records sorted by recordDate desc.
     * 
     * Example: GET /api/duty-history/person/123/paginated?page=0&size=10
     * Example: GET /api/duty-history/person/123/paginated?page=0&size=10&startDate=2025-03-01&endDate=2025-11-30
     */
    @GetMapping("/person/{personId}/paginated")
    public ResponseEntity<Page<DutyHistoryDto>> getPersonHistoryPaginated(
            @PathVariable Long personId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {

        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "recordDate"));
        
        Page<DutyHistory> historyPage;
        
        if (startDate != null && endDate != null) {
            // Filter by date range
            historyPage = dutyHistoryRepository.findByPersonIdAndDateRange(personId, startDate, endDate, pageable);
        } else {
            // Return all records
            historyPage = dutyHistoryRepository.findByPersonIdOrderByRecordDateDesc(personId, pageable);
        }

        // Map entities to DTOs
        Page<DutyHistoryDto> dtoPage = historyPage.map(DutyHistoryDto::fromEntity);
        
        return ResponseEntity.ok(dtoPage);
    }

    // =========================================================================
    // REPORT DOWNLOAD ENDPOINTS
    // =========================================================================

    /**
     * Download PDF report of duty history for a person.
     * If startDate/endDate not provided, returns all records.
     * 
     * Example: GET /api/duty-history/person/123/report/pdf
     * Example: GET /api/duty-history/person/123/report/pdf?startDate=2025-03-01&endDate=2025-11-30
     */
    @GetMapping("/person/{personId}/report/pdf")
    public ResponseEntity<byte[]> downloadPdfReport(
            @PathVariable Long personId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {

        byte[] pdf = reportService.generatePdf(personId, startDate, endDate);
        
        String filename = "duty-history-" + personId + 
                (startDate != null && endDate != null ? "-" + startDate + "-to-" + endDate : "") + ".pdf";

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_PDF_VALUE)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                .body(pdf);
    }

    /**
     * Download Excel report of duty history for a person.
     * If startDate/endDate not provided, returns all records.
     * 
     * Example: GET /api/duty-history/person/123/report/excel
     * Example: GET /api/duty-history/person/123/report/excel?startDate=2025-03-01&endDate=2025-11-30
     */
    @GetMapping("/person/{personId}/report/excel")
    public ResponseEntity<byte[]> downloadExcelReport(
            @PathVariable Long personId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {

        byte[] excel = reportService.generateExcel(personId, startDate, endDate);
        
        String filename = "duty-history-" + personId + 
                (startDate != null && endDate != null ? "-" + startDate + "-to-" + endDate : "") + ".xlsx";

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                .body(excel);
    }

    /**
     * Get duty history for a specific person within a date range.
     * Example: GET /api/duty-history/person/123?from=2025-03-01&to=2025-11-30
     */
    @GetMapping("/person/{personId}")
    public ResponseEntity<List<DutyHistory>> getPersonHistory(
            @PathVariable Long personId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {

        List<DutyHistory> history = dutyHistoryRepository
                .findByPersonIdAndRecordDateBetweenOrderByRecordDateDesc(personId, from, to);

        return ResponseEntity.ok(history);
    }

    /**
     * Get duty history by badge ID within a date range.
     * Example: GET /api/duty-history/badge/APC-270?from=2025-03-01&to=2025-11-30
     */
    @GetMapping("/badge/{badgeId}")
    public ResponseEntity<List<DutyHistory>> getBadgeHistory(
            @PathVariable String badgeId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {

        List<DutyHistory> history = dutyHistoryRepository
                .findByBadgeIdAndRecordDateBetweenOrderByRecordDateDesc(badgeId, from, to);

        return ResponseEntity.ok(history);
    }

    /**
     * Get all duty records for a specific date.
     * Example: GET /api/duty-history/date/2025-03-15
     */
    @GetMapping("/date/{date}")
    public ResponseEntity<List<DutyHistory>> getRecordsForDate(
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {

        List<DutyHistory> records = dutyHistoryRepository.findByRecordDate(date);
        return ResponseEntity.ok(records);
    }

    /**
     * Get duty history for a section within a date range.
     * Example: GET /api/duty-history/section/C?from=2025-03-01&to=2025-11-30
     */
    @GetMapping("/section/{section}")
    public ResponseEntity<List<DutyHistory>> getSectionHistory(
            @PathVariable String section,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {

        List<DutyHistory> history = dutyHistoryRepository
                .findBySectionAndRecordDateBetweenOrderByRecordDateDesc(section, from, to);

        return ResponseEntity.ok(history);
    }

    /**
     * Get leave records within a date range.
     * Example: GET /api/duty-history/leaves?from=2025-03-01&to=2025-11-30
     */
    @GetMapping("/leaves")
    public ResponseEntity<List<DutyHistory>> getLeaveRecords(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {

        List<DutyHistory> records = dutyHistoryRepository.findLeaveRecords(from, to);
        return ResponseEntity.ok(records);
    }

    /**
     * Get adhoc duty records within a date range.
     * Example: GET /api/duty-history/adhoc?from=2025-03-01&to=2025-11-30
     */
    @GetMapping("/adhoc")
    public ResponseEntity<List<DutyHistory>> getAdhocDutyRecords(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {

        List<DutyHistory> records = dutyHistoryRepository.findAdhocDutyRecords(from, to);
        return ResponseEntity.ok(records);
    }

    /**
     * Get record count for a specific date.
     * Useful to verify if snapshot was taken.
     * Example: GET /api/duty-history/count/2025-03-15
     */
    @GetMapping("/count/{date}")
    public ResponseEntity<Map<String, Object>> getRecordCount(
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {

        long count = dutyHistoryRepository.countByRecordDate(date);
        return ResponseEntity.ok(Map.of(
                "date", date,
                "recordCount", count
        ));
    }

    // =========================================================================
    // ROSTER ENDPOINT
    // =========================================================================

    /**
     * Get duty roster data: all personnel duty history grouped by person for a date range.
     * Supports filtering by designation and unit type (CAR/MT).
     * Returns a calendar-friendly structure: list of persons each with their daily duty records.
     *
     * Example: GET /api/duty-history/roster?startDate=2026-07-16&endDate=2026-07-31
     * Example: GET /api/duty-history/roster?startDate=2026-07-16&endDate=2026-07-31&designation=APC&unit=CAR
     */
    @GetMapping("/roster")
    public ResponseEntity<List<Map<String, Object>>> getRosterData(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            @RequestParam(required = false) String designation,
            @RequestParam(required = false) String unit) {

        // Normalize empty strings to null for the query
        String desigParam = (designation != null && !designation.isBlank()) ? designation.toUpperCase().trim() : null;
        String unitParam = (unit != null && !unit.isBlank()) ? unit.toUpperCase().trim() : null;

        List<DutyHistory> records = dutyHistoryRepository.findRosterData(startDate, endDate, desigParam, unitParam);

        // Group by personId
        Map<Long, List<DutyHistory>> byPerson = new java.util.LinkedHashMap<>();
        for (DutyHistory dh : records) {
            byPerson.computeIfAbsent(dh.getPersonId(), k -> new java.util.ArrayList<>()).add(dh);
        }

        // Build response: one entry per person with their daily records
        List<Map<String, Object>> roster = new java.util.ArrayList<>();
        for (Map.Entry<Long, List<DutyHistory>> entry : byPerson.entrySet()) {
            List<DutyHistory> personRecords = entry.getValue();
            DutyHistory first = personRecords.get(0);

            Map<String, Object> personEntry = new java.util.LinkedHashMap<>();
            personEntry.put("personId", first.getPersonId());
            personEntry.put("badgeId", first.getBadgeId());
            personEntry.put("personName", first.getPersonName());
            personEntry.put("designation", first.getDesignation());

            // Map of date -> duty summary
            List<Map<String, Object>> dailyRecords = new java.util.ArrayList<>();
            for (DutyHistory dh : personRecords) {
                Map<String, Object> dayRecord = new java.util.LinkedHashMap<>();
                dayRecord.put("date", dh.getRecordDate());
                dayRecord.put("dutyType", dh.getDutyType());
                dayRecord.put("dutyLocation", dh.getDutyLocation());
                dayRecord.put("adhocDuty", dh.getAdhocDuty());
                dayRecord.put("leaveType", dh.getLeaveType());
                dayRecord.put("shiftType", dh.getShiftType());
                dayRecord.put("status", dh.getStatus());
                dailyRecords.add(dayRecord);
            }
            personEntry.put("dailyRecords", dailyRecords);
            roster.add(personEntry);
        }

        return ResponseEntity.ok(roster);
    }

    // =========================================================================
    // ADMIN ENDPOINTS (Manual Scheduler Triggers)
    // =========================================================================

    /**
     * Manually trigger the cycle completion check.
     * Marks all expired ACTIVE cycles as COMPLETED.
     */
    @PostMapping("/admin/check-expired-cycles")
    public ResponseEntity<Map<String, Object>> checkExpiredCycles() {
        int completedCount = schedulerService.manuallyCheckAndCompleteCycles();

        return ResponseEntity.ok(Map.of(
                "success", true,
                "completedCycles", completedCount,
                "message", completedCount > 0 
                        ? completedCount + " cycle(s) marked as COMPLETED"
                        : "No expired cycles found"
        ));
    }

    /**
     * Manually capture duty history snapshot for today.
     */
    @PostMapping("/admin/capture-today")
    public ResponseEntity<Map<String, Object>> captureToday() {
        LocalDate today = LocalDate.now();
        int recordCount = schedulerService.manuallyCaptureDutyHistory(today);

        return ResponseEntity.ok(Map.of(
                "success", true,
                "date", today,
                "recordsCreated", recordCount,
                "message", "Captured " + recordCount + " duty history records for " + today
        ));
    }

    /**
     * Manually capture duty history snapshot for a specific date.
     * Useful for backfilling historical data.
     * Example: POST /api/duty-history/admin/capture/2025-03-15
     */
    @PostMapping("/admin/capture/{date}")
    public ResponseEntity<Map<String, Object>> captureForDate(
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {

        int recordCount = schedulerService.manuallyCaptureDutyHistory(date);

        return ResponseEntity.ok(Map.of(
                "success", true,
                "date", date,
                "recordsCreated", recordCount,
                "message", "Captured " + recordCount + " duty history records for " + date
        ));
    }

    /**
     * Backfill duty history for a date range.
     * WARNING: This can be slow for large date ranges.
     * Example: POST /api/duty-history/admin/backfill?from=2025-01-01&to=2025-03-31
     */
    @PostMapping("/admin/backfill")
    public ResponseEntity<Map<String, Object>> backfillRange(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {

        int totalRecords = 0;
        int daysProcessed = 0;
        LocalDate current = from;

        while (!current.isAfter(to)) {
            int records = schedulerService.manuallyCaptureDutyHistory(current);
            totalRecords += records;
            daysProcessed++;
            current = current.plusDays(1);
        }

        return ResponseEntity.ok(Map.of(
                "success", true,
                "fromDate", from,
                "toDate", to,
                "daysProcessed", daysProcessed,
                "totalRecords", totalRecords,
                "message", "Backfilled " + totalRecords + " records for " + daysProcessed + " days"
        ));
    }

    // =========================================================================
    // ARCHIVE ENDPOINTS
    // =========================================================================

    /**
     * Manually archive a specific completed cycle.
     * Example: POST /api/duty-history/admin/archive-cycle/123
     */
    @PostMapping("/admin/archive-cycle/{cycleId}")
    public ResponseEntity<Map<String, Object>> archiveCycle(@PathVariable Long cycleId) {
        int archivedCount = schedulerService.manuallyArchiveCycle(cycleId);

        return ResponseEntity.ok(Map.of(
                "success", true,
                "cycleId", cycleId,
                "recordsArchived", archivedCount,
                "message", archivedCount > 0 
                        ? "Archived " + archivedCount + " records for cycle #" + cycleId
                        : "No records to archive (cycle may already be archived or has no assignments)"
        ));
    }

    /**
     * Manually archive all completed cycles.
     * Example: POST /api/duty-history/admin/archive-all-completed
     */
    @PostMapping("/admin/archive-all-completed")
    public ResponseEntity<Map<String, Object>> archiveAllCompletedCycles() {
        Map<String, Object> result = schedulerService.manuallyArchiveAllCompletedCycles();

        return ResponseEntity.ok(Map.of(
                "success", true,
                "cyclesProcessed", result.get("cyclesProcessed"),
                "totalRecordsArchived", result.get("totalRecordsArchived"),
                "message", "Archived " + result.get("totalRecordsArchived") + " records from " 
                           + result.get("cyclesProcessed") + " completed cycles"
        ));
    }
}

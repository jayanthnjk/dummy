package com.policescheduler.service;

import com.policescheduler.entity.*;
import com.policescheduler.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

/**
 * New Rotation Cycle Service — Replaces the old cycle creation logic.
 *
 * Business Rules:
 * 1. Platoons are permanent teams (never reshuffled)
 * 2. Each cycle, platoons rotate to the next section in circular order
 * 3. Only sections with include_in_rotation=true participate
 * 4. End date is calculated from start date + working days (skipping holidays)
 * 5. Duty assignment is randomized per section's duty_types and required_persons
 * 6. No person is left unassigned — overflow duties are fine (show as X/required)
 * 7. No "Leave" duty type by default — all personnel get real duties
 * 8. Single shift (GENERAL) for all personnel
 */
@Service
public class RotationCycleService {

    private static final Logger log = LoggerFactory.getLogger(RotationCycleService.class);

    private final ScheduleCycleRepository scheduleCycleRepository;
    private final CyclePlatoonSectionRepository cyclePlatoonSectionRepository;
    private final CycleDutyAssignmentRepository cycleDutyAssignmentRepository;
    private final SectionRepository sectionRepository;
    private final PlatoonRepository platoonRepository;
    private final PersonnelRepository personnelRepository;
    private final DutyTypeRepository dutyTypeRepository;
    private final HolidayRepository holidayRepository;
    private final RotationHistoryRepository rotationHistoryRepository;
    private final CycleAuditService cycleAuditService;
    private final PersonnelCycleSyncService personnelCycleSyncService;

    public RotationCycleService(ScheduleCycleRepository scheduleCycleRepository,
                                CyclePlatoonSectionRepository cyclePlatoonSectionRepository,
                                CycleDutyAssignmentRepository cycleDutyAssignmentRepository,
                                SectionRepository sectionRepository,
                                PlatoonRepository platoonRepository,
                                PersonnelRepository personnelRepository,
                                DutyTypeRepository dutyTypeRepository,
                                HolidayRepository holidayRepository,
                                RotationHistoryRepository rotationHistoryRepository,
                                CycleAuditService cycleAuditService,
                                PersonnelCycleSyncService personnelCycleSyncService) {
        this.scheduleCycleRepository = scheduleCycleRepository;
        this.cyclePlatoonSectionRepository = cyclePlatoonSectionRepository;
        this.cycleDutyAssignmentRepository = cycleDutyAssignmentRepository;
        this.sectionRepository = sectionRepository;
        this.platoonRepository = platoonRepository;
        this.personnelRepository = personnelRepository;
        this.dutyTypeRepository = dutyTypeRepository;
        this.holidayRepository = holidayRepository;
        this.rotationHistoryRepository = rotationHistoryRepository;
        this.cycleAuditService = cycleAuditService;
        this.personnelCycleSyncService = personnelCycleSyncService;
    }

    /**
     * Creates a new rotation cycle.
     * Only requires startDate and workingDays.
     * Optionally accepts platoonSectionOverrides for manual section picks.
     * Everything else (rotation, allocation) is automatic.
     */
    @Transactional
    public ScheduleCycle createRotationCycle(LocalDate startDate, int workingDays, Map<Long, Long> platoonSectionOverrides, LocalDate explicitEndDate) {
        // 1. Validate inputs
        if (startDate == null) {
            throw new IllegalArgumentException("Start date is required");
        }
        if (workingDays < 1) {
            throw new IllegalArgumentException("Working days must be at least 1");
        }

        // 2. Calculate end date
        LocalDate endDate;
        if (explicitEndDate != null) {
            // Use explicit end date (for half-month fixed periods)
            endDate = explicitEndDate;
        } else {
            // Calculate from working days (skipping holidays)
            endDate = calculateEndDate(startDate, workingDays);
        }

        // 3. Check for overlapping active cycles
        List<ScheduleCycle> overlapping = scheduleCycleRepository.findOverlappingActiveCycles(startDate, endDate);
        if (!overlapping.isEmpty()) {
            ScheduleCycle existing = overlapping.get(0);
            throw new IllegalStateException("Cycle dates overlap with existing cycle #"
                    + existing.getCycleNumber() + " (" + existing.getStartDate() + " to "
                    + existing.getEndDate() + ")");
        }

        // 4. Get rotation sections (ordered)
        List<Section> rotationSections = sectionRepository
                .findByIncludeInRotationTrueAndIsActiveTrueOrderByRotationOrder();
        if (rotationSections.isEmpty()) {
            throw new IllegalStateException("No sections configured for rotation");
        }

        // 5. Get platoons (ordered by base_offset)
        List<Platoon> platoons = platoonRepository.findAllByOrderByBaseOffsetAsc();
        if (platoons.isEmpty()) {
            throw new IllegalStateException("No platoons found");
        }

        // Validate: number of platoons must equal number of rotation sections
        if (platoons.size() != rotationSections.size()) {
            throw new IllegalStateException("Number of platoons (" + platoons.size()
                    + ") must equal number of rotation sections (" + rotationSections.size() + ")");
        }

        // 6. Determine next rotation mappings
        Map<Long, Long> platoonToSection;
        if (platoonSectionOverrides != null && !platoonSectionOverrides.isEmpty()) {
            // Use user-provided overrides
            platoonToSection = new LinkedHashMap<>(platoonSectionOverrides);
            // Validate: no duplicate sections
            Set<Long> usedSections = new HashSet<>(platoonToSection.values());
            if (usedSections.size() != platoonToSection.size()) {
                throw new IllegalArgumentException("No two platoons can have the same section");
            }
        } else {
            // Auto-calculate rotation
            platoonToSection = calculateNextRotation(platoons, rotationSections);
        }

        // 7. Validate no consecutive same-section assignment
        validateNoConsecutiveAssignment(platoonToSection);

        // 8. Create cycle entity
        int nextCycleNumber = scheduleCycleRepository.findMaxCycleNumber() + 1;
        ScheduleCycle cycle = new ScheduleCycle();
        cycle.setStartDate(startDate);
        cycle.setEndDate(endDate);
        cycle.setRotationDays((int) (endDate.toEpochDay() - startDate.toEpochDay() + 1));
        cycle.setWorkingDays(workingDays);
        cycle.setCycleNumber(nextCycleNumber);
        cycle.setStatus("ACTIVE");
        ScheduleCycle savedCycle = scheduleCycleRepository.save(cycle);

        // 9. Save platoon-section mappings
        List<CyclePlatoonSection> mappings = new ArrayList<>();
        for (Map.Entry<Long, Long> entry : platoonToSection.entrySet()) {
            CyclePlatoonSection mapping = new CyclePlatoonSection();
            mapping.setCycleId(savedCycle.getId());
            mapping.setPlatoonId(entry.getKey());
            mapping.setSectionId(entry.getValue());
            mappings.add(mapping);
        }
        cyclePlatoonSectionRepository.saveAll(mappings);

        // 10. Generate duty assignments (randomized)
        generateDutyAssignments(savedCycle, mappings);

        // 10b. Synchronize personnel records with the generated assignments
        personnelCycleSyncService.syncPersonnelForCycle(savedCycle.getId());

        // 11. Write rotation history
        writeRotationHistory(savedCycle.getId(), platoonToSection);

        // 12. Audit log
        cycleAuditService.log(savedCycle.getId(), "CYCLE_CREATED",
                "Cycle #" + nextCycleNumber + " created: " + startDate + " to " + endDate
                        + " (" + workingDays + " working days)",
                null, platoonToSection.toString());

        log.info("Created rotation cycle #{}: {} to {} ({} working days)",
                nextCycleNumber, startDate, endDate, workingDays);

        return savedCycle;
    }

    /**
     * Calculates end date by counting calendar days from start date.
     * Holidays are NOT excluded — all days count.
     */
    public LocalDate calculateEndDate(LocalDate startDate, int workingDays) {
        return startDate.plusDays(workingDays - 1);
    }

    /**
     * Calculates the next rotation for each platoon based on the previous cycle.
     * Uses circular rotation: each platoon moves forward by 1 position in the section order.
     */
    private Map<Long, Long> calculateNextRotation(List<Platoon> platoons, List<Section> rotationSections) {
        Map<Long, Long> result = new LinkedHashMap<>();
        int sectionCount = rotationSections.size();
        List<Long> sectionIds = rotationSections.stream().map(Section::getId).toList();

        // Get the most recent non-deleted cycle
        List<ScheduleCycle> previousCycles = scheduleCycleRepository
                .findByStatusNotOrderByStartDateDesc("DELETED");

        if (previousCycles.isEmpty()) {
            // First cycle ever: assign in order (Platoon 1 → Section 1, etc.)
            for (int i = 0; i < platoons.size(); i++) {
                result.put(platoons.get(i).getId(), sectionIds.get(i % sectionCount));
            }
            return result;
        }

        // Get previous cycle's platoon-section mappings
        ScheduleCycle lastCycle = previousCycles.get(0);
        List<CyclePlatoonSection> lastMappings = cyclePlatoonSectionRepository
                .findByCycleId(lastCycle.getId());

        Map<Long, Long> lastPlatoonToSection = lastMappings.stream()
                .collect(Collectors.toMap(CyclePlatoonSection::getPlatoonId, CyclePlatoonSection::getSectionId));

        // Circular rotation: shift each platoon forward by 1 position
        for (Platoon platoon : platoons) {
            Long lastSection = lastPlatoonToSection.get(platoon.getId());
            if (lastSection == null) {
                // Platoon wasn't in last cycle, assign first available
                result.put(platoon.getId(), sectionIds.get(0));
                continue;
            }

            int lastIndex = sectionIds.indexOf(lastSection);
            if (lastIndex < 0) {
                lastIndex = 0;
            }
            int nextIndex = (lastIndex + 1) % sectionCount;
            result.put(platoon.getId(), sectionIds.get(nextIndex));
        }

        return result;
    }

    /**
     * Validates that no platoon receives the same section as in the immediately previous cycle.
     */
    private void validateNoConsecutiveAssignment(Map<Long, Long> newMappings) {
        List<ScheduleCycle> previousCycles = scheduleCycleRepository
                .findByStatusNotOrderByStartDateDesc("DELETED");

        if (previousCycles.isEmpty()) return;

        ScheduleCycle lastCycle = previousCycles.get(0);
        List<CyclePlatoonSection> lastMappings = cyclePlatoonSectionRepository
                .findByCycleId(lastCycle.getId());

        Map<Long, Long> lastPlatoonToSection = lastMappings.stream()
                .collect(Collectors.toMap(CyclePlatoonSection::getPlatoonId, CyclePlatoonSection::getSectionId));

        for (Map.Entry<Long, Long> entry : newMappings.entrySet()) {
            Long platoonId = entry.getKey();
            Long newSectionId = entry.getValue();
            Long prevSectionId = lastPlatoonToSection.get(platoonId);

            if (prevSectionId != null && prevSectionId.equals(newSectionId)) {
                throw new IllegalStateException("Validation failed: Platoon " + platoonId
                        + " cannot be assigned to the same section (ID=" + newSectionId
                        + ") in two consecutive cycles");
            }
        }
    }

    /**
     * Generates duty assignments for all platoons in the cycle.
     * For each platoon's assigned section:
     * 1. Get all active personnel in that platoon
     * 2. Get PARENT duty types for that section (excluding "Leave" duties)
     * 3. For each parent, get CHILD sub-duties with required_persons
     * 4. Randomly assign personnel to sub-duties based on required_persons
     * 5. duty_type = parent name, duty_location = child (sub-duty) name
     * 6. Any remaining personnel are distributed to available sub-duties (overflow OK)
     * 7. Single shift: GENERAL
     */
    private void generateDutyAssignments(ScheduleCycle cycle, List<CyclePlatoonSection> mappings) {
        List<CycleDutyAssignment> allAssignments = new ArrayList<>();
        Random random = new Random();

        // Calculate total days in the cycle
        long totalDays = ChronoUnit.DAYS.between(cycle.getStartDate(), cycle.getEndDate()) + 1;

        for (CyclePlatoonSection mapping : mappings) {
            // Get active personnel for this platoon
            List<Personnel> personnel = personnelRepository
                    .findByPlatoonIdAndIsActiveTrue(mapping.getPlatoonId());

            if (personnel.isEmpty()) {
                log.warn("No active personnel for platoon {}", mapping.getPlatoonId());
                continue;
            }

            // Shuffle for random assignment
            List<Personnel> shuffled = new ArrayList<>(personnel);
            Collections.shuffle(shuffled, random);

            // Get section code for duty type lookup
            Section section = sectionRepository.findById(mapping.getSectionId()).orElse(null);
            if (section == null) continue;
            String sectionCode = section.getCode();

            // Get PARENT duty types for this section (level=PARENT, excluding Leave)
            List<DutyType> parentDuties = dutyTypeRepository
                    .findBySectionAndParentIsNullOrderBySortOrderAsc(sectionCode)
                    .stream()
                    .filter(d -> d.getIsActive() != null && d.getIsActive())
                    .filter(d -> !isLeaveDuty(d.getName()))
                    .collect(Collectors.toList());

            // Build assignment slots: parent -> children with required_persons
            // Each slot = (parentName, childName, requiredCount)
            List<DutyAssignmentSlot> slots = new ArrayList<>();

            for (DutyType parent : parentDuties) {
                List<DutyType> children = dutyTypeRepository.findByParentIdOrderBySortOrderAsc(parent.getId())
                        .stream()
                        .filter(c -> c.getIsActive() != null && c.getIsActive())
                        .filter(c -> !isLeaveDuty(c.getName()))
                        .collect(Collectors.toList());

                if (children.isEmpty()) {
                    // Parent has no children — use parent itself as both duty_type and duty_location
                    int required = parent.getRequiredPersons() != null ? parent.getRequiredPersons() : 0;
                    slots.add(new DutyAssignmentSlot(parent.getName(), null, Math.max(required, 1)));
                } else {
                    // Assign to children (sub-duties)
                    for (DutyType child : children) {
                        if (isLeaveDuty(child.getName())) continue;
                        int required = child.getRequiredPersons() != null ? child.getRequiredPersons() : 0;
                        if (required > 0) {
                            slots.add(new DutyAssignmentSlot(parent.getName(), child.getName(), required));
                        }
                    }
                    // If no children have required > 0, add parent with 1 slot
                    if (slots.isEmpty() || slots.stream().noneMatch(s -> s.parentDutyName.equals(parent.getName()))) {
                        slots.add(new DutyAssignmentSlot(parent.getName(), null, 1));
                    }
                }
            }

            // Assign personnel to slots
            // personId -> (parentDutyName, childDutyName)
            Map<Long, String[]> personDutyMap = new LinkedHashMap<>();
            int personnelIndex = 0;

            if (slots.isEmpty()) {
                // No duties at all — assign everyone with section name
                for (Personnel person : shuffled) {
                    personDutyMap.put(person.getId(), new String[]{section.getName(), null});
                }
            } else {
                // First pass: fill slots up to required count
                for (DutyAssignmentSlot slot : slots) {
                    for (int i = 0; i < slot.required && personnelIndex < shuffled.size(); i++) {
                        Personnel person = shuffled.get(personnelIndex++);
                        personDutyMap.put(person.getId(), new String[]{slot.parentDutyName, slot.childDutyName});
                    }
                }

                // Second pass: distribute remaining personnel round-robin (overflow OK)
                if (personnelIndex < shuffled.size()) {
                    int slotIndex = 0;
                    while (personnelIndex < shuffled.size()) {
                        DutyAssignmentSlot slot = slots.get(slotIndex % slots.size());
                        Personnel person = shuffled.get(personnelIndex++);
                        personDutyMap.put(person.getId(), new String[]{slot.parentDutyName, slot.childDutyName});
                        slotIndex++;
                    }
                }
            }

            // Generate one assignment per person per day for the entire cycle
            for (int dayIndex = 0; dayIndex < totalDays; dayIndex++) {
                LocalDate date = cycle.getStartDate().plusDays(dayIndex);
                for (Personnel person : shuffled) {
                    String[] dutyInfo = personDutyMap.getOrDefault(person.getId(), new String[]{section.getName(), null});
                    allAssignments.add(createAssignment(cycle, date, mapping, person, dutyInfo[0], dutyInfo[1]));
                }
            }
        }

        // Batch save all assignments
        if (!allAssignments.isEmpty()) {
            cycleDutyAssignmentRepository.saveAll(allAssignments);
            log.info("Generated {} duty assignments for cycle #{}", allAssignments.size(), cycle.getCycleNumber());
        }
    }

    private CycleDutyAssignment createAssignment(ScheduleCycle cycle, LocalDate date,
                                                  CyclePlatoonSection mapping,
                                                  Personnel person, String parentDutyName, String childDutyName) {
        CycleDutyAssignment assignment = new CycleDutyAssignment();
        assignment.setCycleId(cycle.getId());
        assignment.setDate(date);
        assignment.setPlatoonId(mapping.getPlatoonId());
        assignment.setSectionId(mapping.getSectionId());
        assignment.setPersonId(person.getId());
        assignment.setShiftType("GENERAL");
        assignment.setIsOverride(false);
        assignment.setGroupIndex(null);
        assignment.setStatus("ACTIVE");
        // dutyName = parent duty name (what shows in schedules page)
        assignment.setDutyName(parentDutyName);
        // dutyType = parent duty name (matches duty_types PARENT name for Form 168 grouping)
        assignment.setDutyType(parentDutyName);
        // dutyLocationField = child/sub-duty name (matches duty_types SUB name for Form 168 sub-rows)
        assignment.setDutyLocationField(childDutyName);
        assignment.setLocation(null);
        return assignment;
    }

    /**
     * Checks if a duty name represents a "Leave" type that should be excluded.
     */
    private boolean isLeaveDuty(String dutyName) {
        if (dutyName == null) return false;
        String upper = dutyName.toUpperCase().trim();
        return upper.equals("LEAVE") || upper.equals("ON LEAVE")
                || upper.startsWith("LEAVE ") || upper.contains("LEAVE TYPE");
    }

    /**
     * Writes rotation history for audit trail.
     */
    private void writeRotationHistory(Long cycleId, Map<Long, Long> platoonToSection) {
        // Get previous mappings for comparison
        List<ScheduleCycle> previousCycles = scheduleCycleRepository
                .findByStatusNotOrderByStartDateDesc("DELETED");

        Map<Long, Long> previousMapping = new LinkedHashMap<>();
        if (previousCycles.size() > 1) {
            // Skip the current cycle (index 0 is the one we just created)
            ScheduleCycle prevCycle = previousCycles.get(1);
            cyclePlatoonSectionRepository.findByCycleId(prevCycle.getId()).forEach(m ->
                    previousMapping.put(m.getPlatoonId(), m.getSectionId()));
        } else if (previousCycles.size() == 1) {
            // This is the first cycle, no previous
        }

        List<RotationHistory> histories = new ArrayList<>();
        for (Map.Entry<Long, Long> entry : platoonToSection.entrySet()) {
            Long platoonId = entry.getKey();
            Long newSectionId = entry.getValue();
            Long prevSectionId = previousMapping.get(platoonId);

            int personnelCount = personnelRepository.findByPlatoonIdAndIsActiveTrue(platoonId).size();

            RotationHistory history = new RotationHistory();
            history.setCycleId(cycleId);
            history.setPlatoonId(platoonId);
            history.setPreviousSectionId(prevSectionId);
            history.setNewSectionId(newSectionId);
            history.setPersonnelCount(personnelCount);
            histories.add(history);
        }

        rotationHistoryRepository.saveAll(histories);
    }

    /**
     * Gets information about the previous cycle for display before creating next.
     */
    public Map<String, Object> getPreviousCycleInfo() {
        List<ScheduleCycle> cycles = scheduleCycleRepository
                .findByStatusNotOrderByStartDateDesc("DELETED");

        if (cycles.isEmpty()) {
            return Map.of("hasPrevious", false);
        }

        ScheduleCycle lastCycle = cycles.get(0);
        List<CyclePlatoonSection> mappings = cyclePlatoonSectionRepository
                .findByCycleId(lastCycle.getId());

        // Build platoon details
        List<Map<String, Object>> platoonDetails = new ArrayList<>();
        for (CyclePlatoonSection mapping : mappings) {
            Map<String, Object> detail = new LinkedHashMap<>();
            Platoon platoon = platoonRepository.findById(mapping.getPlatoonId()).orElse(null);
            Section section = sectionRepository.findById(mapping.getSectionId()).orElse(null);
            int strength = personnelRepository.findByPlatoonIdAndIsActiveTrue(mapping.getPlatoonId()).size();

            detail.put("platoonId", mapping.getPlatoonId());
            detail.put("platoonName", platoon != null ? platoon.getName() : "Platoon " + mapping.getPlatoonId());
            detail.put("currentSectionId", mapping.getSectionId());
            detail.put("currentSectionName", section != null ? section.getName() : "Unknown");
            detail.put("currentSectionCode", section != null ? section.getCode() : "?");
            detail.put("personnelStrength", strength);

            platoonDetails.add(detail);
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("hasPrevious", true);
        result.put("cycleId", lastCycle.getId());
        result.put("cycleNumber", lastCycle.getCycleNumber());
        result.put("startDate", lastCycle.getStartDate().toString());
        result.put("endDate", lastCycle.getEndDate().toString());
        result.put("workingDays", lastCycle.getWorkingDays());
        result.put("platoonDetails", platoonDetails);

        return result;
    }

    /**
     * Previews what the next rotation would look like without creating it.
     */
    public Map<String, Object> previewNextRotation() {
        List<Section> rotationSections = sectionRepository
                .findByIncludeInRotationTrueAndIsActiveTrueOrderByRotationOrder();
        List<Platoon> platoons = platoonRepository.findAllByOrderByBaseOffsetAsc();

        if (rotationSections.isEmpty() || platoons.isEmpty()) {
            return Map.of("error", "No rotation sections or platoons configured");
        }

        Map<Long, Long> nextMapping = calculateNextRotation(platoons, rotationSections);

        // Get previous for comparison
        List<ScheduleCycle> previousCycles = scheduleCycleRepository
                .findByStatusNotOrderByStartDateDesc("DELETED");
        Map<Long, Long> previousMapping = new LinkedHashMap<>();
        if (!previousCycles.isEmpty()) {
            cyclePlatoonSectionRepository.findByCycleId(previousCycles.get(0).getId()).forEach(m ->
                    previousMapping.put(m.getPlatoonId(), m.getSectionId()));
        }

        List<Map<String, Object>> preview = new ArrayList<>();
        for (Platoon platoon : platoons) {
            Map<String, Object> row = new LinkedHashMap<>();
            Long nextSectionId = nextMapping.get(platoon.getId());
            Long prevSectionId = previousMapping.get(platoon.getId());

            Section nextSection = nextSectionId != null ? sectionRepository.findById(nextSectionId).orElse(null) : null;
            Section prevSection = prevSectionId != null ? sectionRepository.findById(prevSectionId).orElse(null) : null;

            row.put("platoonId", platoon.getId());
            row.put("platoonName", platoon.getName());
            row.put("previousSection", prevSection != null ? prevSection.getName() : "—");
            row.put("previousSectionCode", prevSection != null ? prevSection.getCode() : "—");
            row.put("nextSectionId", nextSectionId);
            row.put("nextSection", nextSection != null ? nextSection.getName() : "—");
            row.put("nextSectionCode", nextSection != null ? nextSection.getCode() : "—");
            row.put("personnelStrength", personnelRepository.findByPlatoonIdAndIsActiveTrue(platoon.getId()).size());

            preview.add(row);
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("preview", preview);
        result.put("rotationSections", rotationSections.stream()
                .map(s -> Map.of("id", s.getId(), "code", s.getCode(), "name", s.getName(), "order", s.getRotationOrder()))
                .toList());

        return result;
    }

    // Helper class for duty assignment slots
    private static class DutyAssignmentSlot {
        final String parentDutyName;
        final String childDutyName; // null if parent has no children
        final int required;

        DutyAssignmentSlot(String parentDutyName, String childDutyName, int required) {
            this.parentDutyName = parentDutyName;
            this.childDutyName = childDutyName;
            this.required = required;
        }
    }
}

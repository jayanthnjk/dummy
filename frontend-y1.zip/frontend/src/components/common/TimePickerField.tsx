import React, { useMemo } from 'react';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { TimePicker } from '@mui/x-date-pickers/TimePicker';
import dayjs, { Dayjs } from 'dayjs';

interface TimePickerFieldProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  minTime?: Dayjs;
  disabled?: boolean;
  selectedDate?: string; // yyyy-MM-dd format
  error?: boolean;
  helperText?: string;
}

const TimePickerField: React.FC<TimePickerFieldProps> = ({
  label,
  value,
  onChange,
  minTime: externalMinTime,
  disabled = false,
  selectedDate,
  error,
  helperText,
}) => {
  const dayjsValue = value ? dayjs(value, 'HH:mm') : null;

  // Past-time restriction: when selectedDate is today, minTime = current time
  const computedMinTime = useMemo(() => {
    if (externalMinTime) return externalMinTime;
    if (selectedDate) {
      const today = dayjs().format('YYYY-MM-DD');
      if (selectedDate === today) {
        return dayjs();
      }
    }
    return undefined;
  }, [externalMinTime, selectedDate]);

  const handleChange = (newValue: Dayjs | null) => {
    if (newValue && newValue.isValid()) {
      onChange(newValue.format('HH:mm'));
    } else {
      onChange('');
    }
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <TimePicker
        label={label}
        value={dayjsValue}
        onChange={handleChange}
        ampm={false}
        minTime={computedMinTime}
        disabled={disabled}
        slotProps={{
          textField: {
            fullWidth: true,
            size: 'medium',
            error: error,
            helperText: helperText,
          },
        }}
      />
    </LocalizationProvider>
  );
};

export default TimePickerField;

import React, { useEffect, useState } from 'react';
import { observer } from 'mobx-react-lite';
import {
  Box,
  Button,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  IconButton,
  LinearProgress,
  Skeleton,
  Stack,
  Alert,
  Snackbar,
  Typography,
} from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import PublishIcon from '@mui/icons-material/Publish';
import { useTranslation } from 'react-i18next';

import NavigationBar from '../components/schedule/NavigationBar';
import ScheduleGrid from '../components/schedule/ScheduleGrid';
import ShiftCreateDialog from '../components/schedule/ShiftCreateDialog';
import ShiftDetailDialog from '../components/schedule/ShiftDetailDialog';
import { scheduleStore } from '../stores/scheduleStore';
import type { Shift } from '../types/schedule';

/**
 * SchedulesPage — Main schedule management page with enterprise-grade layout.
 * Full-height flex column with header, toolbar, scrollable grid, and pagination.
 */
const SchedulesPage: React.FC = observer(() => {
  const { t } = useTranslation();
  const [actionError, setActionError] = useState<string | null>(null);
  const [publishDialogOpen, setPublishDialogOpen] = useState(false);
  const [publishSuccess, setPublishSuccess] = useState(false);

  // Shift detail dialog state
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [selectedShift, setSelectedShift] = useState<Shift | null>(null);
  const [selectedMemberName, setSelectedMemberName] = useState('');
  const [selectedMemberGroup, setSelectedMemberGroup] = useState('');

  // Fetch schedule data on mount
  useEffect(() => {
    scheduleStore.fetchScheduleData();
  }, []);

  // Determine loading states
  const isInitialLoad = scheduleStore.loading && scheduleStore.teamMembers.length === 0;
  const isNavigating = scheduleStore.loading && scheduleStore.teamMembers.length > 0;

  // Handle navigation direction dispatch
  const handleNavigate = (direction: 'prev' | 'next' | 'today') => {
    switch (direction) {
      case 'prev':
        scheduleStore.navigatePrev();
        break;
      case 'next':
        scheduleStore.navigateNext();
        break;
      case 'today':
        scheduleStore.navigateToday();
        break;
    }
  };

  // Handle refresh with action error capture
  const handleRefresh = async () => {
    try {
      await scheduleStore.refresh();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to refresh schedule';
      setActionError(message);
    }
  };

  // Handle export with action error capture
  const handleExport = async () => {
    try {
      await scheduleStore.exportSchedule();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to export schedule';
      setActionError(message);
    }
  };

  // Handle publish - open confirmation dialog
  const handlePublish = () => {
    setPublishDialogOpen(true);
  };

  // Handle confirmed publish after dialog confirmation
  const handleConfirmPublish = async () => {
    setPublishDialogOpen(false);
    try {
      await scheduleStore.publishSchedule();
      setPublishSuccess(true);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to publish schedule';
      setActionError(message);
    }
  };

  // Handle shift creation with action error capture
  const handleCreateShift = async (data: Parameters<typeof scheduleStore.createShift>[0]) => {
    try {
      await scheduleStore.createShift(data);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to create shift';
      setActionError(message);
      throw err;
    }
  };

  // Find the prefilled member for the create dialog
  const prefilledMember = scheduleStore.createDialogMemberId
    ? scheduleStore.teamMembers.find(
        (tm) => tm.member.id === scheduleStore.createDialogMemberId
      )?.member ?? null
    : null;

  // Close action error snackbar
  const handleCloseSnackbar = () => {
    setActionError(null);
  };

  // Handle shift click — open detail dialog
  const handleShiftClick = (shift: Shift, memberName: string, memberGroup: string) => {
    setSelectedShift(shift);
    setSelectedMemberName(memberName);
    setSelectedMemberGroup(memberGroup);
    setDetailDialogOpen(true);
  };

  const handleCloseDetailDialog = () => {
    setDetailDialogOpen(false);
    setSelectedShift(null);
  };

  // Initial load: show skeleton matching grid layout
  if (isInitialLoad) {
    return (
      <Box
        sx={{
          display: 'flex',
          flexDirection: 'column',
          height: '100%',
          flex: 1,
          backgroundColor: '#F9FAFB',
        }}
      >
        {/* Header skeleton */}
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            py: 2,
            px: 3,
            backgroundColor: '#FFFFFF',
            borderBottom: '1px solid #E5E7EB',
          }}
        >
          <Box>
            <Skeleton variant="text" width={120} height={32} />
            <Skeleton variant="text" width={220} height={18} />
          </Box>
          <Box sx={{ display: 'flex', gap: 1.5 }}>
            <Skeleton variant="rounded" width={36} height={36} sx={{ borderRadius: '8px' }} />
            <Skeleton variant="rounded" width={80} height={36} sx={{ borderRadius: '8px' }} />
            <Skeleton variant="rounded" width={140} height={36} sx={{ borderRadius: '8px' }} />
          </Box>
        </Box>

        {/* Navigation bar skeleton */}
        <Box
          sx={{
            py: 1.5,
            px: 3,
            backgroundColor: '#FFFFFF',
            borderBottom: '1px solid #E5E7EB',
          }}
        >
          <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
            <Skeleton variant="rounded" width={160} height={32} sx={{ borderRadius: '10px' }} />
            <Skeleton variant="rounded" width={260} height={32} sx={{ borderRadius: '8px' }} />
            <Box sx={{ flex: 1 }} />
            <Skeleton variant="rounded" width={140} height={32} sx={{ borderRadius: '8px' }} />
            <Skeleton variant="rounded" width={200} height={32} sx={{ borderRadius: '8px' }} />
          </Box>
        </Box>

        {/* Grid skeleton */}
        <Box sx={{ flex: 1, px: 0, py: 0, overflow: 'hidden' }}>
          {/* Header row */}
          <Box sx={{ display: 'flex', borderBottom: '2px solid #E5E7EB', backgroundColor: '#F9FAFB' }}>
            <Skeleton variant="rectangular" width={220} height={44} />
            {Array.from({ length: 7 }).map((_, i) => (
              <Skeleton key={i} variant="rectangular" height={44} sx={{ flex: 1 }} />
            ))}
            <Skeleton variant="rectangular" width={64} height={44} />
          </Box>
          {/* Data rows */}
          {Array.from({ length: 8 }).map((_, rowIdx) => (
            <Box
              key={rowIdx}
              sx={{
                display: 'flex',
                borderBottom: '1px solid #E5E7EB',
                backgroundColor: rowIdx % 2 === 0 ? '#FFFFFF' : '#F9FAFB',
              }}
            >
              <Skeleton variant="rectangular" width={220} height={52} />
              {Array.from({ length: 7 }).map((_, colIdx) => (
                <Skeleton key={colIdx} variant="rectangular" height={52} sx={{ flex: 1 }} />
              ))}
              <Skeleton variant="rectangular" width={64} height={52} />
            </Box>
          ))}
        </Box>
      </Box>
    );
  }

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        flex: 1,
        overflow: 'hidden',
        backgroundColor: '#F9FAFB',
      }}
    >
      {/* Dark Navy Page Header */}
      <Box
        sx={{
          background: 'linear-gradient(135deg, #1a1e4a 0%, #2d3561 100%)',
          color: 'white',
          px: { xs: 2, md: 4 },
          pt: 2,
          pb: 1.5,
          flexShrink: 0,
        }}
      >
        {/* Top row: Title + Actions */}
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
          <Box>
            <Typography variant="h5" fontWeight={700} sx={{ letterSpacing: '-0.02em' }}>
              {t('schedules.title', 'Schedule Management')}
            </Typography>
            <Typography variant="body2" sx={{ color: 'rgba(255,255,255,0.7)', mt: 0.5 }}>
              {t('schedules.subtitle', 'Manage team schedules and shifts')}
            </Typography>
          </Box>
          <Stack direction="row" spacing={1}>
            <IconButton
              onClick={handleRefresh}
              disabled={scheduleStore.loading}
              size="small"
              aria-label="Refresh schedule"
              sx={{
                color: 'white',
                border: '1px solid rgba(255,255,255,0.3)',
                borderRadius: '8px',
                width: 36,
                height: 36,
                '&:hover': { borderColor: 'white', backgroundColor: 'rgba(255,255,255,0.08)' },
              }}
            >
              {scheduleStore.loading ? (
                <CircularProgress size={18} sx={{ color: 'white' }} />
              ) : (
                <RefreshIcon sx={{ fontSize: 18 }} />
              )}
            </IconButton>
            <Button
              variant="contained"
              size="small"
              startIcon={<PublishIcon sx={{ fontSize: 16 }} />}
              onClick={handlePublish}
              disabled={scheduleStore.loading}
              disableElevation
              sx={{
                backgroundColor: 'rgba(255,255,255,0.08)',
                backdropFilter: 'blur(8px)',
                border: '1px solid rgba(255,255,255,0.2)',
                color: 'white',
                textTransform: 'none',
                fontWeight: 600,
                fontSize: '0.82rem',
                borderRadius: 2,
                px: 2,
                '&:hover': { 
                  backgroundColor: 'rgba(255,255,255,0.15)',
                  borderColor: 'rgba(255,255,255,0.4)',
                },
              }}
            >
              {t('schedules.publishSchedule', 'Publish Schedule')}
            </Button>
          </Stack>
        </Box>
      </Box>

      {/* Progress bar for refresh/navigation */}
      {isNavigating && (
        <LinearProgress
          sx={{
            flexShrink: 0,
            height: 2,
            backgroundColor: '#DBEAFE',
            '& .MuiLinearProgress-bar': {
              backgroundColor: '#2563EB',
            },
          }}
        />
      )}

      {/* Fetch error alert banner */}
      {scheduleStore.error && (
        <Alert
          severity="error"
          sx={{
            mx: 3,
            mt: 1,
            flexShrink: 0,
            borderRadius: '8px',
          }}
        >
          {scheduleStore.error}
        </Alert>
      )}

      {/* Navigation Bar */}
      <NavigationBar
        viewMode={scheduleStore.viewMode}
        onViewModeChange={(mode) => scheduleStore.setViewMode(mode)}
        dateRange={scheduleStore.dateRange}
        onNavigate={handleNavigate}
        groupFilter={scheduleStore.groupFilter}
        onGroupFilterChange={(group) => scheduleStore.setGroupFilter(group)}
        groups={scheduleStore.groups}
        searchQuery={scheduleStore.searchQuery}
        onSearchChange={(query) => scheduleStore.setSearchQuery(query)}
      />

      {/* Empty state */}
      {!scheduleStore.loading && scheduleStore.filteredMembers.length === 0 && (
        <Box
          sx={{
            flex: 1,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            py: 8,
          }}
        >
          <Typography variant="h6" sx={{ color: '#6B7280', mb: 1, fontWeight: 500 }}>
            No team members found
          </Typography>
          <Typography variant="body2" sx={{ color: '#9CA3AF' }}>
            Try adjusting your filters or search query.
          </Typography>
        </Box>
      )}

      {/* Schedule Grid — fills remaining space */}
      {scheduleStore.filteredMembers.length > 0 && (
        <Box sx={{ flex: 1, position: 'relative', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
          {isNavigating && (
            <Box
              sx={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                bgcolor: 'rgba(255, 255, 255, 0.7)',
                zIndex: 10,
                backdropFilter: 'blur(1px)',
              }}
            >
              <CircularProgress size={32} sx={{ color: '#2563EB' }} />
            </Box>
          )}
          <ScheduleGrid
            viewMode={scheduleStore.viewMode}
            dateRange={scheduleStore.dateRange}
            teamMembers={scheduleStore.filteredMembers}
            openShifts={scheduleStore.openShifts}
            showOpenShifts={scheduleStore.showOpenShifts}
            showTimeOff={scheduleStore.showTimeOff}
            onAddShift={(memberId, date) => scheduleStore.openCreateDialog(memberId, date)}
            onShiftClick={handleShiftClick}
            todayDate={new Date().toISOString().split('T')[0]}
          />
        </Box>
      )}

      {/* Shift Create Dialog */}
      <ShiftCreateDialog
        open={scheduleStore.createDialogOpen}
        onClose={() => scheduleStore.closeCreateDialog()}
        onSubmit={handleCreateShift}
        prefilledMember={prefilledMember}
        prefilledDate={scheduleStore.createDialogDate}
        shiftTypes={scheduleStore.shiftTypes}
      />

      {/* Shift Detail Dialog */}
      <ShiftDetailDialog
        open={detailDialogOpen}
        onClose={handleCloseDetailDialog}
        shift={selectedShift}
        memberName={selectedMemberName}
        memberGroup={selectedMemberGroup}
      />

      {/* Publish Confirmation Dialog */}
      <Dialog
        open={publishDialogOpen}
        onClose={() => setPublishDialogOpen(false)}
        aria-labelledby="publish-dialog-title"
        PaperProps={{
          sx: { borderRadius: '12px', maxWidth: 440 },
        }}
      >
        <DialogTitle id="publish-dialog-title" sx={{ fontWeight: 600 }}>
          {t('schedules.publishConfirmTitle', 'Publish Schedule')}
        </DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ color: '#374151' }}>
            {t('schedules.publishConfirmMessage', 'Are you sure you want to publish the current schedule? This will notify all team members.')}
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button
            onClick={() => setPublishDialogOpen(false)}
            variant="outlined"
            sx={{
              textTransform: 'none',
              borderRadius: '8px',
              borderColor: '#E5E7EB',
              color: '#374151',
            }}
          >
            {t('app.cancel', 'Cancel')}
          </Button>
          <Button
            onClick={handleConfirmPublish}
            variant="contained"
            disableElevation
            sx={{
              textTransform: 'none',
              borderRadius: '8px',
              backgroundColor: '#2563EB',
              '&:hover': { backgroundColor: '#1D4ED8' },
            }}
          >
            {t('schedules.publishSchedule', 'Publish')}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Publish success Snackbar */}
      <Snackbar
        open={publishSuccess}
        autoHideDuration={6000}
        onClose={() => setPublishSuccess(false)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert onClose={() => setPublishSuccess(false)} severity="success" variant="filled" sx={{ width: '100%' }}>
          {t('schedules.publishSuccess', 'Schedule published successfully!')}
        </Alert>
      </Snackbar>

      {/* Action failure Snackbar */}
      <Snackbar
        open={!!actionError}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert onClose={handleCloseSnackbar} severity="error" variant="filled" sx={{ width: '100%' }}>
          {actionError}
        </Alert>
      </Snackbar>
    </Box>
  );
});

export default SchedulesPage;

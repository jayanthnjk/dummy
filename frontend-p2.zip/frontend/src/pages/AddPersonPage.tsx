import React, { useState, useEffect } from 'react';
import {
  Box, Typography, Button, Alert, CircularProgress,
  MenuItem, Card, CardContent, Switch, FormControlLabel, IconButton,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import SaveIcon from '@mui/icons-material/Save';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import FormField from '@/components/FormField';
import { personnelService } from '@/services/personnelService';
import { sectionService, type SectionDto } from '@/services/sectionService';
import type { CreatePersonnelRequest } from '@/types';

const DESIGNATIONS = ['DCP', 'ACP', 'RPI', 'RSI', 'ARSI', 'AHC', 'APC'];
const DUTY_TYPES = ['GUARD', 'DRIVER', 'OFFICE', 'SUPPORT', 'CHECK_POST', 'PATROL', 'DOG_SQUAD', 'ASC_TEAM', 'GUNMAN', 'OOD', 'BAND', 'QRT', 'CPT'];

const emptyForm: CreatePersonnelRequest = {
  badgeId: '', personName: '', dutyType: '', location: '', phoneNumber: '',
  email: '', designation: '', section: 'A', dateOfJoining: '',
  vehicleNumber: '', dutyLocation: '', pdms: '', licenceType: '', deployedFrom: '',
  isActive: true,
};

const AddPersonPage: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [form, setForm] = useState<CreatePersonnelRequest>({ ...emptyForm });
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [sections, setSections] = useState<SectionDto[]>([]);

  useEffect(() => {
    sectionService.list().then(setSections).catch(() => {});
  }, []);

  const isDriver = form.dutyType?.toUpperCase() === 'DRIVER';

  const updateField = (field: keyof CreatePersonnelRequest, value: string | boolean | number | undefined) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = async () => {
    setError('');
    setSaving(true);
    try {
      await personnelService.create(form);
      navigate('/personnel');
    } catch (err: unknown) {
      const axiosErr = err as { response?: { status?: number } };
      if (axiosErr.response?.status === 409) {
        setError(t('personnel.duplicateBadgeId'));
      } else {
        setError(t('errors.serverError'));
      }
    } finally {
      setSaving(false);
    }
  };

  return (
    <Box sx={{ p: 3, maxWidth: 900, mx: 'auto' }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
        <IconButton onClick={() => navigate('/personnel')}
          sx={{ bgcolor: '#f5f2ec', '&:hover': { bgcolor: '#ede8dc' } }}>
          <ArrowBackIcon sx={{ fontSize: 20, color: '#312e81' }} />
        </IconButton>
        <Box sx={{ flex: 1 }}>
          <Typography sx={{ fontSize: '1.4rem', fontWeight: 700, color: '#111827' }}>
            {t('personnel.addPerson')}
          </Typography>
          <Typography sx={{ fontSize: '0.82rem', color: '#9ca3af' }}>
            Fill in the details to register new personnel
          </Typography>
        </Box>
        <Button onClick={handleSave} disabled={saving || !form.badgeId || !form.personName}
          startIcon={saving ? <CircularProgress size={16} /> : <SaveIcon sx={{ fontSize: 18 }} />}
          sx={{
            textTransform: 'none', fontWeight: 600, fontSize: '0.85rem',
            bgcolor: '#312e81', color: '#fff', borderRadius: 2, px: 3, py: 1,
            '&:hover': { bgcolor: '#1e1b4b' },
            '&.Mui-disabled': { bgcolor: '#e5e7eb', color: '#9ca3af' },
          }}>
          {t('app.save')}
        </Button>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 3, borderRadius: 2 }}>{error}</Alert>}

      {/* Basic Info Card */}
      <Card variant="outlined" sx={{ borderRadius: 3, borderColor: '#f0ede6', mb: 3 }}>
        <CardContent sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
            <PersonAddIcon sx={{ color: '#312e81', fontSize: 20 }} />
            <Typography sx={{ fontWeight: 600, fontSize: '0.95rem', color: '#111827' }}>
              Basic Information
            </Typography>
          </Box>

          <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr' }, gap: 2 }}>
            <FormField labelKey="personnel.badgeId" required value={form.badgeId}
              onChange={e => updateField('badgeId', e.target.value)} />
            <FormField labelKey="personnel.personName" required value={form.personName}
              onChange={e => updateField('personName', e.target.value)} />
            <FormField labelKey="personnel.designation" select value={form.designation}
              onChange={e => updateField('designation', e.target.value)}>
              <MenuItem value="">—</MenuItem>
              {DESIGNATIONS.map(d => <MenuItem key={d} value={d}>{d}</MenuItem>)}
            </FormField>
            <FormField labelKey="personnel.section" select required value={form.section}
              onChange={e => updateField('section', e.target.value)}>
              {sections.map(s => <MenuItem key={s.code} value={s.code}>{s.name}</MenuItem>)}
            </FormField>
            <FormField labelKey="personnel.dutyType" select value={form.dutyType}
              onChange={e => updateField('dutyType', e.target.value)}>
              <MenuItem value="">—</MenuItem>
              {DUTY_TYPES.map(d => <MenuItem key={d} value={d}>{d}</MenuItem>)}
            </FormField>
            <FormField labelKey="personnel.location" value={form.location}
              onChange={e => updateField('location', e.target.value)} />
          </Box>
        </CardContent>
      </Card>

      {/* Contact Info Card */}
      <Card variant="outlined" sx={{ borderRadius: 3, borderColor: '#f0ede6', mb: 3 }}>
        <CardContent sx={{ p: 3 }}>
          <Typography sx={{ fontWeight: 600, fontSize: '0.95rem', color: '#111827', mb: 3 }}>
            Contact & Service Details
          </Typography>
          <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr' }, gap: 2 }}>
            <FormField labelKey="personnel.phoneNumber" value={form.phoneNumber}
              onChange={e => updateField('phoneNumber', e.target.value)} />
            <FormField labelKey="personnel.email" type="email" value={form.email}
              onChange={e => updateField('email', e.target.value)} />
            <FormField labelKey="personnel.dateOfJoining" type="date" value={form.dateOfJoining}
              onChange={e => updateField('dateOfJoining', e.target.value)}
              InputLabelProps={{ shrink: true }} />
          </Box>
          <FormControlLabel
            control={<Switch checked={form.isActive !== false} onChange={e => updateField('isActive', e.target.checked)} />}
            label={<Typography sx={{ fontSize: '0.85rem' }}>{t('personnel.active')}</Typography>}
            sx={{ mt: 2 }}
          />
        </CardContent>
      </Card>

      {/* Driver Fields Card — conditional */}
      {isDriver && (
        <Card variant="outlined" sx={{ borderRadius: 3, borderColor: '#0d9488', bgcolor: '#fffbf0', mb: 3 }}>
          <CardContent sx={{ p: 3 }}>
            <Typography sx={{ fontWeight: 600, fontSize: '0.95rem', color: '#92400e', mb: 3 }}>
              {t('personnel.driverFields')}
            </Typography>
            <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 2 }}>
              <FormField labelKey="personnel.vehicleNumber" value={form.vehicleNumber}
                onChange={e => updateField('vehicleNumber', e.target.value)} />
              <FormField labelKey="personnel.dutyLocation" value={form.dutyLocation}
                onChange={e => updateField('dutyLocation', e.target.value)} />
              <FormField labelKey="personnel.pdms" value={form.pdms}
                onChange={e => updateField('pdms', e.target.value)} />
              <FormField labelKey="personnel.licenceType" value={form.licenceType}
                onChange={e => updateField('licenceType', e.target.value)} />
              <FormField labelKey="personnel.deployedFrom" value={form.deployedFrom}
                onChange={e => updateField('deployedFrom', e.target.value)} />
            </Box>
          </CardContent>
        </Card>
      )}
    </Box>
  );
};

export default AddPersonPage;

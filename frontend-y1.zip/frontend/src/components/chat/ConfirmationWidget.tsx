import React from 'react';
import { Box, Typography } from '@mui/material';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import type { ConfirmationResponseData } from '@/types';

const ConfirmationWidget: React.FC<ConfirmationResponseData> = ({ success, message, details }) => {
  return (
    <Box
      sx={{
        width: '100%',
        p: 1.5,
        borderRadius: 1,
        backgroundColor: success ? '#e8f5e9' : '#fbe9e7',
      }}
    >
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        {success ? (
          <CheckCircleOutlineIcon sx={{ color: '#2e7d32', fontSize: '1.25rem' }} />
        ) : (
          <ErrorOutlineIcon sx={{ color: '#c62828', fontSize: '1.25rem' }} />
        )}
        <Typography
          sx={{
            fontSize: '0.85rem',
            fontWeight: 600,
            color: success ? '#2e7d32' : '#c62828',
          }}
        >
          {message}
        </Typography>
      </Box>

      {details && Object.keys(details).length > 0 && (
        <Box sx={{ mt: 1, pl: 3.5 }}>
          {Object.entries(details).map(([key, value]) => (
            <Typography key={key} sx={{ fontSize: '0.75rem', color: 'text.secondary', lineHeight: 1.6 }}>
              <Box component="span" sx={{ fontWeight: 600 }}>{key}:</Box> {value}
            </Typography>
          ))}
        </Box>
      )}
    </Box>
  );
};

export default ConfirmationWidget;

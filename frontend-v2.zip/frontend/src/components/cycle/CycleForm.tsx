import React, { useState, useMemo } from 'react';
import {
  Alert,
  Box,
  Button,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  FormHelperText,
  InputLabel,
  MenuItem,
  Select,
  Stack,
  TextField,
  Typography,
  type SelectChangeEvent,
} from '@mui/material';
import { cycleService, type CycleCreateRequest, type PlatoonSectionMapping } from '@/services/cycleService';

/** Predefined platoons (I–V) mapped to their database IDs */
const PLATOONS = [
  { id: 1, name: 'Platoon I' },
  { id: 2, name: 'Platoon II' },
  { id: 3, name: 'Platoon III' },
  { id: 4, name: 'Platoon IV' },
  { id: 5, name: 'Platoon V' },
];

/** Sections C through G with their database IDs */
const SECTIONS = [
  { id: 3, name: 'Section C' },
  { id: 4, name: 'Section D' },
  { id: 5, name: 'Section E' },
  { id: 6, name: 'Section F' },
  { id: 7, name: 'Section G' },
];

interface CycleFormProps {
  /** Whether the dialog is open */
  open: boolean;
  /** Called when the dialog should close */
  onClose: () => void;
  /** Called after a successful cycle creation (e.g. to refresh the list) */
  onSuccess: () => void;
}

/**
 * Calculates end date as startDate + rotationDays - 1.
 * Exported for unit testing (Property 1: End Date Calculation).
 */
export function calculateEndDate(startDate: string, rotationDays: number): string {
  if (!startDate || rotationDays < 1) return '';
  const start = new Date(startDate + 'T00:00:00');
  if (isNaN(start.getTime())) return '';
  const end = new Date(start);
  end.setDate(end.getDate() + rotationDays - 1);
  return end.toISOString().split('T')[0];
}

/**
 * CycleForm — MUI Dialog for creating a new platoon rotation cycle.
 *
 * Each platoon gets exactly ONE section (single select).
 * Once a section is selected for one platoon, it's removed from other platoons' options.
 *
 * Implements Requirements 1.1, 1.2, 1.4.
 */
const CycleForm: React.FC<CycleFormProps> = ({ open, onClose, onSuccess }) => {
  const [startDate, setStartDate] = useState('');
  const [rotationDays, setRotationDays] = useState<number | ''>('');
  // Each platoon maps to a single section ID (or 0 for unselected)
  const [platoonSections, setPlatoonSections] = useState<Record<number, number>>(
    () => Object.fromEntries(PLATOONS.map((p) => [p.id, 0])) as Record<number, number>,
  );
  const [submitting, setSubmitting] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);

  // Auto-calculated end date
  const endDate = useMemo(() => {
    if (!startDate || !rotationDays || rotationDays < 1) return '';
    return calculateEndDate(startDate, rotationDays);
  }, [startDate, rotationDays]);

  // Get all currently selected section IDs (to exclude from other dropdowns)
  const selectedSectionIds = useMemo(() => {
    return Object.values(platoonSections).filter((id) => id > 0);
  }, [platoonSections]);

  // Validation: each platoon must have a section selected
  const allPlatoonsHaveSections = useMemo(() => {
    return PLATOONS.every((p) => platoonSections[p.id] > 0);
  }, [platoonSections]);

  // Form is valid when all fields are filled and validated
  const isFormValid = useMemo(() => {
    return (
      startDate !== '' &&
      rotationDays !== '' &&
      rotationDays >= 1 &&
      endDate !== '' &&
      allPlatoonsHaveSections
    );
  }, [startDate, rotationDays, endDate, allPlatoonsHaveSections]);

  const handleSectionChange = (platoonId: number) => (event: SelectChangeEvent<number>) => {
    const value = event.target.value as number;
    setPlatoonSections((prev) => ({ ...prev, [platoonId]: value }));
  };

  const handleReset = () => {
    setStartDate('');
    setRotationDays('');
    setPlatoonSections(
      Object.fromEntries(PLATOONS.map((p) => [p.id, 0])) as Record<number, number>,
    );
    setApiError(null);
  };

  const handleClose = () => {
    if (!submitting) {
      handleReset();
      onClose();
    }
  };

  const handleSubmit = async () => {
    if (!isFormValid) return;

    setSubmitting(true);
    setApiError(null);

    const requestBody: CycleCreateRequest = {
      startDate,
      rotationDays: rotationDays as number,
      platoonSections: PLATOONS.map<PlatoonSectionMapping>((p) => ({
        platoonId: p.id,
        sectionIds: [platoonSections[p.id]],
      })),
    };

    try {
      await cycleService.createCycle(requestBody);
      handleReset();
      onSuccess();
      onClose();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to create cycle';
      setApiError(message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      maxWidth="sm"
      fullWidth
      aria-labelledby="cycle-form-dialog-title"
    >
      <DialogTitle id="cycle-form-dialog-title">Create Rotation Cycle</DialogTitle>
      <DialogContent>
        <Stack spacing={2.5} sx={{ mt: 1 }}>
          {apiError && (
            <Alert severity="error" onClose={() => setApiError(null)}>
              {apiError}
            </Alert>
          )}

          {/* Start Date */}
          <TextField
            label="Start Date"
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            required
            fullWidth
            size="small"
            InputLabelProps={{ shrink: true }}
          />

          {/* Rotation Days */}
          <TextField
            label="Rotation Days"
            type="number"
            value={rotationDays}
            onChange={(e) => {
              const val = e.target.value;
              setRotationDays(val === '' ? '' : Math.max(1, parseInt(val, 10) || 1));
            }}
            required
            fullWidth
            size="small"
            inputProps={{ min: 1 }}
            helperText="Number of consecutive days for this rotation"
          />

          {/* End Date (read-only, auto-calculated) */}
          <TextField
            label="End Date"
            type="date"
            value={endDate}
            disabled
            fullWidth
            size="small"
            InputLabelProps={{ shrink: true }}
            helperText={endDate ? 'Start Date + Rotation Days − 1' : 'Auto-calculated once Start Date and Rotation Days are set'}
          />

          {/* Platoon-Section Assignments (Single Select with exclusion) */}
          <Box>
            <Typography variant="subtitle2" sx={{ mb: 0.5, fontWeight: 600 }}>
              Platoon Section Assignments
            </Typography>
            <Typography variant="caption" color="text.secondary" sx={{ mb: 1.5, display: 'block' }}>
              Assign one section to each platoon. Each section can only be assigned once.
            </Typography>

            <Stack spacing={1.5}>
              {PLATOONS.map((platoon) => {
                const currentValue = platoonSections[platoon.id] || 0;
                const hasError = currentValue === 0;

                // Available sections: not yet assigned to another platoon
                const availableSections = SECTIONS.filter(
                  (s) => s.id === currentValue || !selectedSectionIds.includes(s.id),
                );

                return (
                  <FormControl key={platoon.id} fullWidth size="small" error={hasError}>
                    <InputLabel id={`platoon-${platoon.id}-label`}>
                      {platoon.name}
                    </InputLabel>
                    <Select
                      labelId={`platoon-${platoon.id}-label`}
                      value={currentValue || ''}
                      onChange={handleSectionChange(platoon.id)}
                      label={platoon.name}
                    >
                      {availableSections.map((section) => (
                        <MenuItem key={section.id} value={section.id}>
                          {section.name}
                        </MenuItem>
                      ))}
                    </Select>
                    {hasError && (
                      <FormHelperText>Select a section</FormHelperText>
                    )}
                  </FormControl>
                );
              })}
            </Stack>
          </Box>
        </Stack>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={handleClose} disabled={submitting}>
          Cancel
        </Button>
        <Button
          variant="contained"
          onClick={handleSubmit}
          disabled={!isFormValid || submitting}
          startIcon={submitting ? <CircularProgress size={16} color="inherit" /> : undefined}
        >
          {submitting ? 'Creating...' : 'Create Cycle'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default CycleForm;

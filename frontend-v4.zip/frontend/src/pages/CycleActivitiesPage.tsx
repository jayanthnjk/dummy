import React, { useEffect, useState, useMemo } from 'react';
import {
  Alert,
  Box,
  Button,
  Chip,
  CircularProgress,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import { useNavigate } from 'react-router-dom';
import { cycleService, type CycleAuditLog } from '@/services/cycleService';

const RECORDS_PER_PAGE = 20;

/** Color mapping for action types */
const ACTION_COLORS: Record<string, 'success' | 'info' | 'error' | 'warning' | 'default'> = {
  CYCLE_CREATED: 'success',
  CYCLE_UPDATED: 'info',
  CYCLE_DELETED: 'error',
  DUTY_REASSIGNED: 'warning',
};

/** Format relative time */
function getRelativeTime(dateStr: string): string {
  const now = new Date();
  const date = new Date(dateStr);
  const diffMs = now.getTime() - date.getTime();
  const diffSec = Math.floor(diffMs / 1000);
  const diffMin = Math.floor(diffSec / 60);
  const diffHr = Math.floor(diffMin / 60);
  const diffDays = Math.floor(diffHr / 24);

  if (diffSec < 60) return 'Just now';
  if (diffMin < 60) return `${diffMin} minute${diffMin > 1 ? 's' : ''} ago`;
  if (diffHr < 24) return `${diffHr} hour${diffHr > 1 ? 's' : ''} ago`;
  if (diffDays < 7) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;

  return date.toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

/**
 * CycleActivitiesPage — Audit trail of all cycle changes.
 * Groups logs by cycleId with pagination (20 records per page).
 */
const CycleActivitiesPage: React.FC = () => {
  const navigate = useNavigate();
  const [logs, setLogs] = useState<CycleAuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(0);

  useEffect(() => {
    const fetchLogs = async () => {
      setLoading(true);
      setError(null);
      try {
        const data = await cycleService.getAuditLogs();
        setLogs(data);
      } catch (err: unknown) {
        const message = err instanceof Error ? err.message : 'Failed to load audit logs';
        setError(message);
      } finally {
        setLoading(false);
      }
    };
    fetchLogs();
  }, []);

  // Sort logs by most recent first
  const sortedLogs = useMemo(
    () => [...logs].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()),
    [logs],
  );

  // Group logs by cycleId
  const groupedLogs = useMemo(() => {
    const groups: Map<number, CycleAuditLog[]> = new Map();
    sortedLogs.forEach((log) => {
      if (!groups.has(log.cycleId)) {
        groups.set(log.cycleId, []);
      }
      groups.get(log.cycleId)!.push(log);
    });
    return groups;
  }, [sortedLogs]);

  // Flatten grouped logs into a display list with group headers
  const displayItems = useMemo(() => {
    const items: { type: 'header'; cycleId: number; count: number }[] | { type: 'log'; log: CycleAuditLog }[] = [];
    const flatItems: Array<{ type: 'header'; cycleId: number; count: number } | { type: 'log'; log: CycleAuditLog }> = [];

    // Sort cycle groups by most recent log timestamp
    const sortedGroups = Array.from(groupedLogs.entries()).sort((a, b) => {
      const aLatest = a[1][0]?.createdAt ?? '';
      const bLatest = b[1][0]?.createdAt ?? '';
      return new Date(bLatest).getTime() - new Date(aLatest).getTime();
    });

    sortedGroups.forEach(([cycleId, cycleLogs]) => {
      flatItems.push({ type: 'header', cycleId, count: cycleLogs.length });
      cycleLogs.forEach((log) => {
        flatItems.push({ type: 'log', log });
      });
    });

    return flatItems;
  }, [groupedLogs]);

  // Pagination on the flat sorted logs
  const totalPages = Math.max(1, Math.ceil(sortedLogs.length / RECORDS_PER_PAGE));
  const paginatedLogs = useMemo(() => {
    const start = currentPage * RECORDS_PER_PAGE;
    return sortedLogs.slice(start, start + RECORDS_PER_PAGE);
  }, [sortedLogs, currentPage]);

  // Group paginated logs by cycle for display
  const paginatedGrouped = useMemo(() => {
    const groups: Map<number, CycleAuditLog[]> = new Map();
    paginatedLogs.forEach((log) => {
      if (!groups.has(log.cycleId)) {
        groups.set(log.cycleId, []);
      }
      groups.get(log.cycleId)!.push(log);
    });
    return Array.from(groups.entries());
  }, [paginatedLogs]);

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        flex: 1,
        overflow: 'hidden',
        backgroundColor: '#F9FAFB',
      }}
    >
      {/* Dark Navy Page Header */}
      <Box
        sx={{
          background: 'linear-gradient(135deg, #1a1e4a 0%, #2d3561 100%)',
          color: 'white',
          px: { xs: 2, md: 4 },
          pt: 2,
          pb: 1.5,
          flexShrink: 0,
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Box>
            <Typography variant="h5" fontWeight={700} sx={{ letterSpacing: '-0.02em' }}>
              Cycle Activities
            </Typography>
            <Typography variant="body2" sx={{ color: 'rgba(255,255,255,0.7)', mt: 0.5 }}>
              Audit trail of all cycle changes
            </Typography>
          </Box>
          <Button
            variant="contained"
            size="small"
            startIcon={<ArrowBackIcon sx={{ fontSize: 16 }} />}
            onClick={() => navigate('/schedules')}
            disableElevation
            sx={{
              backgroundColor: 'rgba(255,255,255,0.08)',
              backdropFilter: 'blur(8px)',
              border: '1px solid rgba(255,255,255,0.2)',
              color: 'white',
              textTransform: 'none',
              fontWeight: 600,
              fontSize: '0.82rem',
              borderRadius: 2,
              px: 2,
              '&:hover': {
                backgroundColor: 'rgba(255,255,255,0.15)',
                borderColor: 'rgba(255,255,255,0.4)',
              },
            }}
          >
            Back to Schedules
          </Button>
        </Box>
      </Box>

      {/* Error banner */}
      {error && (
        <Alert
          severity="error"
          onClose={() => setError(null)}
          sx={{ mx: { xs: 2, md: 4 }, mt: 1.5, flexShrink: 0, borderRadius: '8px' }}
        >
          {error}
        </Alert>
      )}

      {/* Main Content */}
      <Box sx={{ flex: 1, overflow: 'auto', px: { xs: 2, md: 4 }, py: 2 }}>
        {loading && (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
            <CircularProgress size={36} />
          </Box>
        )}

        {!loading && sortedLogs.length === 0 && !error && (
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              py: 10,
            }}
          >
            <Typography variant="h6" sx={{ color: '#6B7280', mb: 1, fontWeight: 500 }}>
              No activity logs found
            </Typography>
            <Typography variant="body2" sx={{ color: '#9CA3AF' }}>
              Cycle activities will appear here once changes are made.
            </Typography>
          </Box>
        )}

        {!loading && sortedLogs.length > 0 && (
          <>
            {/* Pagination controls */}
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                mb: 1.5,
              }}
            >
              <Typography variant="body2" sx={{ color: '#6B7280' }}>
                {sortedLogs.length} total records
              </Typography>
              <Stack direction="row" alignItems="center" spacing={0.5}>
                <Button
                  size="small"
                  disabled={currentPage === 0}
                  onClick={() => setCurrentPage((p) => Math.max(0, p - 1))}
                  sx={{ minWidth: 32 }}
                >
                  <ChevronLeftIcon fontSize="small" />
                </Button>
                <Typography variant="caption" sx={{ color: '#374151', fontWeight: 600 }}>
                  Page {currentPage + 1} / {totalPages}
                </Typography>
                <Button
                  size="small"
                  disabled={currentPage >= totalPages - 1}
                  onClick={() => setCurrentPage((p) => Math.min(totalPages - 1, p + 1))}
                  sx={{ minWidth: 32 }}
                >
                  <ChevronRightIcon fontSize="small" />
                </Button>
              </Stack>
            </Box>

            {/* Grouped logs */}
            {paginatedGrouped.map(([cycleId, cycleLogs]) => (
              <Box key={cycleId} sx={{ mb: 3 }}>
                {/* Cycle group header */}
                <Box
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 1,
                    mb: 1,
                    px: 1,
                  }}
                >
                  <Chip
                    label={`Cycle #${cycleId}`}
                    size="small"
                    sx={{
                      fontWeight: 700,
                      backgroundColor: '#E8EAF6',
                      color: '#3F51B5',
                      border: '1px solid #C5CAE9',
                    }}
                  />
                  <Typography variant="caption" sx={{ color: '#9CA3AF' }}>
                    {cycleLogs.length} {cycleLogs.length === 1 ? 'record' : 'records'}
                  </Typography>
                </Box>

                <TableContainer
                  sx={{
                    backgroundColor: '#FFFFFF',
                    borderRadius: '8px',
                    border: '1px solid #E5E7EB',
                  }}
                >
                  <Table size="small">
                    <TableHead>
                      <TableRow sx={{ backgroundColor: '#F9FAFB' }}>
                        <TableCell sx={{ fontWeight: 600 }}>Date/Time</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>Action</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>Description</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>Details</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {cycleLogs.map((log) => (
                        <TableRow key={log.id} hover>
                          <TableCell>
                            <Typography variant="body2" fontWeight={500}>
                              {getRelativeTime(log.createdAt)}
                            </Typography>
                            <Typography variant="caption" color="text.secondary">
                              {new Date(log.createdAt).toLocaleString()}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Chip
                              label={log.action.replace(/_/g, ' ')}
                              size="small"
                              color={ACTION_COLORS[log.action] ?? 'default'}
                              sx={{ fontWeight: 600, fontSize: '0.72rem' }}
                            />
                          </TableCell>
                          <TableCell>
                            <Typography variant="body2">{log.description}</Typography>
                          </TableCell>
                          <TableCell>
                            {(log.oldValue || log.newValue) ? (
                              <Box>
                                {log.oldValue && (
                                  <Typography variant="caption" color="text.secondary" display="block">
                                    From: {log.oldValue}
                                  </Typography>
                                )}
                                {log.newValue && (
                                  <Typography variant="caption" color="text.secondary" display="block">
                                    To: {log.newValue}
                                  </Typography>
                                )}
                              </Box>
                            ) : (
                              <Typography variant="caption" color="text.disabled">
                                —
                              </Typography>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              </Box>
            ))}

            {/* Bottom pagination */}
            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
              <Stack direction="row" alignItems="center" spacing={1}>
                <Button
                  size="small"
                  variant="outlined"
                  disabled={currentPage === 0}
                  onClick={() => setCurrentPage((p) => Math.max(0, p - 1))}
                  sx={{ textTransform: 'none' }}
                >
                  Previous
                </Button>
                <Typography variant="body2" sx={{ color: '#374151', fontWeight: 600, px: 2 }}>
                  Page {currentPage + 1} of {totalPages}
                </Typography>
                <Button
                  size="small"
                  variant="outlined"
                  disabled={currentPage >= totalPages - 1}
                  onClick={() => setCurrentPage((p) => Math.min(totalPages - 1, p + 1))}
                  sx={{ textTransform: 'none' }}
                >
                  Next
                </Button>
              </Stack>
            </Box>
          </>
        )}
      </Box>
    </Box>
  );
};

export default CycleActivitiesPage;

import { makeAutoObservable, runInAction } from 'mobx';
import type { Section, DutyType, Personnel, CsvExportRow } from '@/types/dutySections';
import {
  dutySectionApiService,
  dutyTypeService,
  dutySectionPersonnelService,
} from '@/services/dutySectionService';

class DutySectionStore {
  // Observable state
  sections: Section[] = [];
  dutyTypes: DutyType[] = [];
  personnel: Personnel[] = [];
  selectedSectionCode: string | null = null;
  selectedDutyTypeId: number | null = null;
  selectedUnit: 'CAR' | 'MT' = 'CAR';
  searchQuery: string = '';
  rankFilter: string | null = null;
  locationFilter: 'all' | 'pinned' | 'unpinned' = 'all';
  loading: boolean = false;
  error: string | null = null;
  showAddDutyTypeDialog: boolean = false;

  constructor() {
    makeAutoObservable(this);
  }

  // Computed: active sections filtered by unit and sorted by sortOrder
  get activeSections(): Section[] {
    return this.sections
      .filter((s) => s.isActive)
      .filter((s) => {
        if (this.selectedUnit === 'MT') return s.code === 'MT';
        return s.code !== 'MT' && s.code !== 'PMT';
      })
      .slice()
      .sort((a, b) => a.sortOrder - b.sortOrder);
  }

  // Computed: duty types filtered by searchQuery (case-insensitive) and locationFilter
  get filteredDutyTypes(): DutyType[] {
    let result = this.dutyTypes;

    if (this.searchQuery) {
      const query = this.searchQuery.toLowerCase();
      result = result.filter((dt) => dt.name.toLowerCase().includes(query));
    }

    if (this.locationFilter === 'pinned') {
      result = result.filter((dt) => dt.latitude !== null && dt.longitude !== null);
    } else if (this.locationFilter === 'unpinned') {
      result = result.filter((dt) => dt.latitude === null || dt.longitude === null);
    }

    return result;
  }

  // Computed: personnel filtered by selectedDutyTypeId and rankFilter
  get filteredPersonnel(): Personnel[] {
    let result = this.personnel;

    if (this.selectedDutyTypeId !== null) {
      const selectedDutyType = this.dutyTypes.find((dt) => dt.id === this.selectedDutyTypeId);
      if (selectedDutyType) {
        result = result.filter((p) => p.dutyType === selectedDutyType.name);
      }
    }

    if (this.rankFilter) {
      result = result.filter((p) => p.rank === this.rankFilter);
    }

    return result;
  }

  // Computed: duty types with non-null lat/lng from filteredDutyTypes (for map pins)
  get visibleMapPins(): DutyType[] {
    return this.filteredDutyTypes.filter(
      (dt) => dt.latitude != null && dt.longitude != null
    );
  }

  // Actions
  async fetchSections(): Promise<void> {
    this.loading = true;
    this.error = null;
    try {
      const sections = await dutySectionApiService.listActive();
      runInAction(() => {
        this.sections = sections;
        this.loading = false;
      });
    } catch (err: unknown) {
      runInAction(() => {
        this.error = err instanceof Error ? err.message : 'Failed to fetch sections';
        this.loading = false;
      });
    }
  }

  async fetchDutyTypes(sectionCode: string): Promise<void> {
    this.loading = true;
    this.error = null;
    try {
      const dutyTypes = await dutyTypeService.listBySection(sectionCode);
      runInAction(() => {
        this.dutyTypes = Array.isArray(dutyTypes) ? dutyTypes : [];
        this.loading = false;
      });
    } catch (err: unknown) {
      runInAction(() => {
        this.error = err instanceof Error ? err.message : 'Failed to fetch duty types';
        this.loading = false;
      });
    }
  }

  async fetchPersonnel(sectionCode: string): Promise<void> {
    this.loading = true;
    this.error = null;
    try {
      const personnel = await dutySectionPersonnelService.listBySection(sectionCode);
      runInAction(() => {
        this.personnel = Array.isArray(personnel) ? personnel : [];
        this.loading = false;
      });
    } catch (err: unknown) {
      runInAction(() => {
        this.personnel = [];
        this.error = err instanceof Error ? err.message : 'Failed to fetch personnel';
        this.loading = false;
      });
    }
  }

  selectSection(code: string): void {
    this.selectedSectionCode = code;
    this.selectedDutyTypeId = null;
    this.fetchDutyTypes(code);
    this.fetchPersonnel(code);
  }

  selectDutyType(id: number | null): void {
    this.selectedDutyTypeId = id;
  }

  openAddDutyTypeDialog(): void {
    this.showAddDutyTypeDialog = true;
  }

  closeAddDutyTypeDialog(): void {
    this.showAddDutyTypeDialog = false;
  }

  setSearchQuery(query: string): void {
    this.searchQuery = query;
  }

  setRankFilter(rank: string | null): void {
    this.rankFilter = rank;
  }

  setLocationFilter(filter: 'all' | 'pinned' | 'unpinned'): void {
    this.locationFilter = filter;
  }

  setUnit(unit: 'CAR' | 'MT'): void {
    this.selectedUnit = unit;
    this.selectedSectionCode = null;
    this.selectedDutyTypeId = null;
    this.searchQuery = '';
    this.rankFilter = null;
    this.locationFilter = 'all';
    // Auto-select first section of the new unit
    const unitSections = this.sections
      .filter((s) => s.isActive)
      .filter((s) => {
        if (unit === 'MT') return s.code === 'MT';
        return s.code !== 'MT' && s.code !== 'PMT';
      })
      .sort((a, b) => a.sortOrder - b.sortOrder);
    if (unitSections.length > 0) {
      this.selectSection(unitSections[0].code);
    }
  }

  async refresh(): Promise<void> {
    this.searchQuery = '';
    this.rankFilter = null;
    this.locationFilter = 'all';
    this.selectedDutyTypeId = null;

    if (this.selectedSectionCode) {
      this.loading = true;
      this.error = null;
      try {
        const [sections, dutyTypes, personnel] = await Promise.all([
          dutySectionApiService.listActive(),
          dutyTypeService.listBySection(this.selectedSectionCode),
          dutySectionPersonnelService.listBySection(this.selectedSectionCode),
        ]);
        runInAction(() => {
          this.sections = sections;
          this.dutyTypes = dutyTypes;
          this.personnel = personnel;
          this.loading = false;
        });
      } catch (err: unknown) {
        runInAction(() => {
          this.error = err instanceof Error ? err.message : 'Failed to refresh data';
          this.loading = false;
        });
      }
    }
  }

  exportCsv(): void {
    const dutyTypes = this.filteredDutyTypes;
    const personnel = this.filteredPersonnel;

    if (dutyTypes.length === 0 && personnel.length === 0) {
      return;
    }

    const rows: CsvExportRow[] = [];

    for (const dt of dutyTypes) {
      const matchingPersonnel = personnel.filter((p) => p.dutyType === dt.name);
      if (matchingPersonnel.length > 0) {
        for (const p of matchingPersonnel) {
          rows.push({
            dutyTypeName: dt.name,
            sectionCode: dt.section,
            latitude: dt.latitude,
            longitude: dt.longitude,
            personnelName: p.name,
            rank: p.rank,
            assignmentStatus: p.status,
          });
        }
      } else {
        rows.push({
          dutyTypeName: dt.name,
          sectionCode: dt.section,
          latitude: dt.latitude,
          longitude: dt.longitude,
          personnelName: '',
          rank: '',
          assignmentStatus: '',
        });
      }
    }

    const headers = [
      'Duty Type Name',
      'Section Code',
      'Latitude',
      'Longitude',
      'Personnel Name',
      'Rank',
      'Assignment Status',
    ];

    const csvContent = [
      headers.join(','),
      ...rows.map((row) =>
        [
          `"${row.dutyTypeName}"`,
          `"${row.sectionCode}"`,
          row.latitude ?? '',
          row.longitude ?? '',
          `"${row.personnelName}"`,
          `"${row.rank}"`,
          `"${row.assignmentStatus}"`,
        ].join(',')
      ),
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `duty-sections-${this.selectedSectionCode || 'all'}-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  }
}

export const dutySectionStore = new DutySectionStore();

# Known Issues & Limitations
## KSP WorkBoard v1.0.0

| Field | Details |
|-------|---------|
| **Version** | 1.0.0 |
| **Date** | June 2026 |

---

## 1. Known Issues

### 1.1 Critical Issues

| # | Issue | Impact | Workaround | Status |
|---|-------|--------|------------|--------|
| KI-001 | Groq LLM occasionally returns 400 with failed_generation | Chat fails for ~5% of complex queries | System parses failed_generation for tool call; user can rephrase | Mitigated |
| KI-002 | No WebSocket — chat updates require page interaction | Users don't see real-time schedule changes from other users | Refresh page or re-query via chat | By Design |

### 1.2 Medium Issues

| # | Issue | Impact | Workaround | Status |
|---|-------|--------|------------|--------|
| KI-003 | Circuit breaker stays open for 60s on LLM failure | All chat queries fail-fast for 60 seconds after 3 consecutive LLM failures | Wait 60 seconds then retry; system auto-recovers | By Design |
| KI-004 | Cache TTL of 60s means stale data briefly visible | After a write (e.g., create leave), related reads may show old data for up to 60s | Domain-specific invalidation covers most cases; hard refresh if needed | Mitigated |
| KI-005 | Adhoc duty auto-assignment uses random selection | Fairness not guaranteed — same person may be picked multiple times across duties | Use SPECIFIC_PLATOONS to control selection pool | Known |
| KI-006 | No conversation history in LLM context | Chat cannot reference previous messages ("the person I just asked about") | Include full context in each message | By Design |
| KI-007 | Badge ID prefix assumption for bare numbers | "2649" assumes AHC prefix — incorrect for APC numbers > 100 | Always include prefix: "APC 168" | Known |

### 1.3 Low Issues

| # | Issue | Impact | Workaround | Status |
|---|-------|--------|------------|--------|
| KI-008 | Report filenames use server date not report date | Downloaded filename may show today's date even for historical report | Content inside report is correct | Cosmetic |
| KI-009 | No email/SMS notifications | Officers not notified externally of leave approvals | Check system regularly | By Design |
| KI-010 | Section strength cache not auto-updated | section_strength table may be stale after personnel changes | Manual update or ignore (not used in core logic) | Low |
| KI-011 | Translation gaps in chat responses | Some LLM-generated responses may mix English into Kannada | Rephrase in English for consistent response | Known |
| KI-012 | PDF reports English-only format | Report headers and structure are in English regardless of locale param | Content data is correct; locale affects some labels | Known |
| KI-013 | No bulk personnel import UI | Adding 200+ personnel one-by-one is slow | Use direct DB INSERT for initial data load | Known |
| KI-014 | InactivityDialog timer resets only on page interaction | Background tabs may trigger false inactivity | Click anywhere to reset timer | By Design |

---

## 2. Technical Limitations

### 2.1 Architecture Limitations

| # | Limitation | Reason | Future Fix |
|---|-----------|--------|------------|
| TL-001 | Single instance deployment | Caffeine cache is local, no shared state | Migrate to Redis for multi-instance |
| TL-002 | No API versioning | Initial release, no breaking changes yet | Add /v1/ prefix when needed |
| TL-003 | No database migration tool | DDL managed manually | Add Flyway/Liquibase |
| TL-004 | jpa.open-in-view=false | Lazy loading outside transactions throws LazyInitializationException | Use fetch joins or DTOs |
| TL-005 | No async processing | Cycle creation (3000 inserts) blocks the request thread | Add async with @Async or message queue |
| TL-006 | No pagination on audit logs | Returns all logs up to 20 limit in chat; API returns all | Add pageable parameter |

### 2.2 AI/Chat Limitations

| # | Limitation | Reason | Future Fix |
|---|-----------|--------|------------|
| AI-001 | No multi-turn context | Conversation history not passed to LLM | Add sliding window context |
| AI-002 | LLM model-dependent accuracy | Groq llama-3.3-70b has ~95% tool routing accuracy | Fine-tune or switch model |
| AI-003 | Hindi responses limited | System detects Hindi but responds in English | Add Hindi translation support |
| AI-004 | RAG limited to uploaded PDFs | No automatic knowledge base | Add document crawler |
| AI-005 | STT language limited | Whisper may struggle with heavy Kannada accent | Test with native speakers |
| AI-006 | No chat export/history view | Chat history stored but no UI to browse it | Add chat history page |

### 2.3 Business Limitations

| # | Limitation | Reason | Future Fix |
|---|-----------|--------|------------|
| BL-001 | Fixed 5 platoons, 5 sections | Hard-coded rotation algorithm | Make configurable |
| BL-002 | No leave balance tracking | System creates leaves without balance validation | Add leave quota system |
| BL-003 | No automatic cycle completion | Cycles stay ACTIVE until manually changed | Add scheduler to auto-complete |
| BL-004 | No duty swap requests | Officers can't request to swap duties with each other | Add swap request workflow |
| BL-005 | No attendance tracking | System tracks assignments but not actual attendance | Add check-in/check-out |
| BL-006 | Single station only | No multi-station or district-level aggregation | Add multi-tenant support |

---

## 3. Performance Limitations

| # | Area | Current Limit | Impact |
|---|------|---------------|--------|
| PL-001 | File upload | 10MB max | Large PDFs need splitting |
| PL-002 | Cycle creation | ~3000 inserts per cycle | Takes 2-5 seconds on t3.medium |
| PL-003 | Personnel search | Full table scan with LIKE | Slow with 500+ records without pg_trgm index |
| PL-004 | Report generation | Single-threaded | Reports > 1000 rows take 5-10 seconds |
| PL-005 | Chat rate limit | 20 LLM calls per user | Heavy users may hit limit |
| PL-006 | Database connections | Default pool size | May need tuning for 50+ concurrent users |

---

## 4. Security Limitations

| # | Limitation | Risk Level | Mitigation |
|---|-----------|-----------|------------|
| SL-001 | No token refresh mechanism | Low | 24h expiry is acceptable for police shift patterns |
| SL-002 | No IP-based rate limiting | Low | Per-user rate limiting active |
| SL-003 | No audit log for login attempts | Medium | Add login attempt logging |
| SL-004 | No password complexity rules | Medium | Enforce via admin policy |
| SL-005 | No two-factor authentication | Low | Add TOTP for admin accounts |

---

*End of Document — Known Issues & Limitations v1.0.0*

package com.policescheduler.report.generator;

import com.policescheduler.entity.Personnel;
import com.policescheduler.report.ReportGenerationException;
import com.policescheduler.repository.PersonnelRepository;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class PersonnelListExcelGenerator {

    private static final Logger log = LoggerFactory.getLogger(PersonnelListExcelGenerator.class);

    private static final String REPORT_TITLE = "CITY ARMED RESERVE MANGALURU (C.A.R COMPANY) Personnel List";
    private static final String UNIT_NAME = "CAR MANGALURU CITY";

    // Designation priority order for sorting
    private static final Map<String, Integer> DESIGNATION_PRIORITY = Map.of(
            "DCP", 1,
            "ACP", 2,
            "RPI", 3,
            "RSI", 4,
            "ARSI", 5,
            "AHC", 6,
            "APC", 7
    );

    private final PersonnelRepository personnelRepository;

    public PersonnelListExcelGenerator(PersonnelRepository personnelRepository) {
        this.personnelRepository = personnelRepository;
    }

    public byte[] generate(String section, String designation, Boolean isActive) {
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Personnel List");

            CellStyle headerStyle = createHeaderStyle(workbook);
            CellStyle dataStyle = createDataStyle(workbook);
            CellStyle titleStyle = createTitleStyle(workbook);

            // Fetch and filter CAR unit personnel only
            List<Personnel> allPersonnel = personnelRepository.findAll().stream()
                    .filter(p -> "CAR".equalsIgnoreCase(p.getUnit()))
                    .filter(p -> section == null || section.isEmpty() || section.equalsIgnoreCase(p.getSection()))
                    .filter(p -> designation == null || designation.isEmpty() || designation.equalsIgnoreCase(p.getDesignation()))
                    .filter(p -> {
                        if (isActive != null) return isActive.equals(p.getIsActive());
                        return Boolean.TRUE.equals(p.getIsActive()); // default: active only
                    })
                    .collect(Collectors.toList());

            // Sort by designation priority, then by badge_id ascending within each designation
            allPersonnel.sort(Comparator
                    .<Personnel, Integer>comparing(p ->
                            DESIGNATION_PRIORITY.getOrDefault(
                                    p.getDesignation() != null ? p.getDesignation().toUpperCase() : "", 99))
                    .thenComparing(p -> p.getBadgeId() != null ? p.getBadgeId() : ""));

            int rowIndex = 0;

            // Title row
            Row titleRow = sheet.createRow(rowIndex++);
            Cell titleCell = titleRow.createCell(0);
            titleCell.setCellValue(REPORT_TITLE);
            titleCell.setCellStyle(titleStyle);

            rowIndex++; // blank row

            // Column headers
            String[] headers = {"SL NO.", "UNIT NAME", "NAME", "DESIG", "METAL No.", "MOBILE No."};
            Row headerRow = sheet.createRow(rowIndex++);
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // Data rows
            int slNo = 1;
            for (Personnel p : allPersonnel) {
                Row row = sheet.createRow(rowIndex++);
                int col = 0;
                row.createCell(col++).setCellValue(slNo++);
                row.createCell(col++).setCellValue(UNIT_NAME);
                row.createCell(col++).setCellValue(safe(p.getPersonName()));
                row.createCell(col++).setCellValue(safe(p.getDesignation()));
                row.createCell(col++).setCellValue(extractMetalNumber(p.getBadgeId()));
                row.createCell(col++).setCellValue(safe(p.getPhoneNumber()));

                for (int i = 0; i < headers.length; i++) {
                    if (row.getCell(i) != null) {
                        row.getCell(i).setCellStyle(dataStyle);
                    }
                }
            }

            // Auto-size columns
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            workbook.write(baos);
            return baos.toByteArray();
        } catch (Exception e) {
            log.error("Failed to generate Personnel List Excel report", e);
            throw new ReportGenerationException("personnel_list_excel",
                    "Failed to generate Personnel List Excel report", e);
        }
    }

    /**
     * Extracts the metal number from a badge ID.
     * Rules:
     * - If badge_id contains "AUTO" → return "-"
     * - If badge_id doesn't contain a "-" with a number after it → return "-"
     * - Otherwise extract number after last dash (e.g., "AHC-127" → "127", "APC-2539" → "2539")
     */
    private String extractMetalNumber(String badgeId) {
        if (badgeId == null || badgeId.isBlank()) {
            return "-";
        }
        if (badgeId.toUpperCase().contains("AUTO")) {
            return "-";
        }
        int lastDash = badgeId.lastIndexOf('-');
        if (lastDash < 0 || lastDash >= badgeId.length() - 1) {
            return "-";
        }
        String afterDash = badgeId.substring(lastDash + 1);
        // Check if it's a valid number
        try {
            Integer.parseInt(afterDash);
            return afterDash;
        } catch (NumberFormatException e) {
            return "-";
        }
    }

    private String safe(String value) {
        return value != null ? value : "";
    }

    private CellStyle createTitleStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 12);
        style.setFont(font);
        return style;
    }

    private CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 9);
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    private CellStyle createDataStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 8);
        style.setFont(font);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }
}

import React from 'react';
import { observer } from 'mobx-react-lite';
import {
  TextField,
  Select,
  MenuItem,
  Button,
  InputAdornment,
  FormControl,
  Box,
  IconButton,
  Tooltip,
  type SelectChangeEvent,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import RefreshIcon from '@mui/icons-material/Refresh';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import { useTranslation } from 'react-i18next';
import { dutySectionStore } from '@/stores/dutySectionStore';

/** Common police/paramilitary ranks used in Karnataka State Police */
const RANK_OPTIONS = ['DySP', 'Inspector', 'SI', 'ASI', 'HC', 'PC', 'Driver'];

/**
 * SearchFilterBar — Compact single-row filter bar.
 * Search left (flex:1), Rank dropdown, Location dropdown, Refresh button, Export button.
 * Consistent 8px border-radius, compact height.
 */
const SearchFilterBar: React.FC = observer(() => {
  const { t } = useTranslation();

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    dutySectionStore.setSearchQuery(e.target.value);
  };

  const handleRankChange = (e: SelectChangeEvent<string>) => {
    const value = e.target.value;
    dutySectionStore.setRankFilter(value === '' ? null : value);
  };

  const handleLocationChange = (e: SelectChangeEvent<string>) => {
    dutySectionStore.setLocationFilter(e.target.value as 'all' | 'pinned' | 'unpinned');
  };

  const handleRefresh = () => {
    dutySectionStore.refresh();
  };

  const handleExport = () => {
    dutySectionStore.exportCsv();
  };

  return (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        gap: 1.5,
        px: 2,
        py: 1.25,
        backgroundColor: 'white',
        borderRadius: 2,
        border: '1px solid',
        borderColor: '#E2E8F0',
        boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
      }}
    >
      {/* Search TextField — flex:1 to fill space */}
      <TextField
        size="small"
        variant="outlined"
        placeholder={t('admin.dutySections.searchPlaceholder', 'Search locations...')}
        value={dutySectionStore.searchQuery}
        onChange={handleSearchChange}
        sx={{
          flex: 1,
          minWidth: 180,
          '& .MuiOutlinedInput-root': {
            borderRadius: 2,
            backgroundColor: '#F8FAFC',
            height: 38,
            '&:hover': { backgroundColor: '#F1F5F9' },
            '&.Mui-focused': { backgroundColor: 'white' },
          },
        }}
        slotProps={{
          input: {
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon fontSize="small" sx={{ color: '#94A3B8' }} />
              </InputAdornment>
            ),
          },
        }}
      />

      {/* Rank Select */}
      <FormControl size="small" sx={{ minWidth: 120 }}>
        <Select
          displayEmpty
          value={dutySectionStore.rankFilter ?? ''}
          onChange={handleRankChange}
          sx={{
            borderRadius: 2,
            height: 38,
            backgroundColor: '#F8FAFC',
            '& .MuiSelect-select': { py: 1 },
            '&:hover': { backgroundColor: '#F1F5F9' },
          }}
        >
          <MenuItem value="">
            {t('admin.dutySections.allRanks', 'All Ranks')}
          </MenuItem>
          {RANK_OPTIONS.map((rank) => (
            <MenuItem key={rank} value={rank}>
              {rank}
            </MenuItem>
          ))}
        </Select>
      </FormControl>

      {/* Location Select */}
      <FormControl size="small" sx={{ minWidth: 130 }}>
        <Select
          displayEmpty
          value={dutySectionStore.locationFilter}
          onChange={handleLocationChange}
          sx={{
            borderRadius: 2,
            height: 38,
            backgroundColor: '#F8FAFC',
            '& .MuiSelect-select': { py: 1 },
            '&:hover': { backgroundColor: '#F1F5F9' },
          }}
        >
          <MenuItem value="all">
            {t('admin.dutySections.allLocations', 'All Locations')}
          </MenuItem>
          <MenuItem value="pinned">{t('admin.dutySections.pinned', 'Pinned')}</MenuItem>
          <MenuItem value="unpinned">{t('admin.dutySections.unpinned', 'Unpinned')}</MenuItem>
        </Select>
      </FormControl>

      {/* Refresh Button */}
      <Tooltip title={t('admin.dutySections.refresh', 'Refresh')}>
        <IconButton
          onClick={handleRefresh}
          size="small"
          sx={{
            width: 38,
            height: 38,
            borderRadius: 2,
            backgroundColor: '#F8FAFC',
            border: '1px solid #E2E8F0',
            color: '#64748B',
            '&:hover': { backgroundColor: '#E2E8F0', color: '#1E293B' },
          }}
        >
          <RefreshIcon fontSize="small" />
        </IconButton>
      </Tooltip>

      {/* Export Button */}
      <Button
        variant="contained"
        size="small"
        startIcon={<FileDownloadIcon sx={{ fontSize: 16 }} />}
        onClick={handleExport}
        sx={{
          height: 38,
          borderRadius: 2,
          textTransform: 'none',
          fontSize: '0.8rem',
          fontWeight: 600,
          backgroundColor: '#1E293B',
          boxShadow: 'none',
          px: 2,
          '&:hover': { backgroundColor: '#334155', boxShadow: '0 2px 6px rgba(0,0,0,0.15)' },
        }}
      >
        {t('admin.dutySections.export', 'Export')}
      </Button>
    </Box>
  );
});

export default SearchFilterBar;

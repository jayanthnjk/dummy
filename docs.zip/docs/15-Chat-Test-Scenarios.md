# Chat-Based Test Scenarios (300+)
## KSP WorkBoard — AI Chat Comprehensive Testing

| Field | Details |
|-------|---------|
| **Document Title** | Chat-Based Test Commands |
| **Total Scenarios** | 310 |
| **Date** | June 2026 |
| **How to Test** | Type each command in the chat. Verify the response matches the expected result type. |

---

## Instructions

For each test case below:
1. Type the **Command** exactly as shown in the chat input
2. Verify the **Expected Response Type** matches (table/form/confirmation/suggestions/text)
3. Verify the **Expected Behavior** is correct
4. Mark Pass/Fail

---

## Category 1: Personnel Search (40 Commands)

| # | Command | Expected Response Type | Expected Behavior |
|---|---------|----------------------|-------------------|
| 1 | show personnel list | table | Shows all personnel in table |
| 2 | ಸಿಬ್ಬಂದಿ ಪಟ್ಟಿ ತೋರಿಸು | table | Personnel list in Kannada response |
| 3 | list all staff | table | All personnel |
| 4 | search jayanth | table | Shows personnel matching "jayanth" |
| 5 | find mahantesh | table | Shows matching personnel |
| 6 | details of AHC 2649 | table | Single person detail view |
| 7 | show AHC-2649 | table | Same person detail |
| 8 | info about APC 168 | table | Person with badge APC-168 |
| 9 | give details of 2649 | table | Assumes AHC prefix, shows person |
| 10 | get details of jayanth | table | Searches by name |
| 11 | show info about Mahantesh | table | Person details by name |
| 12 | list all AHC | table | All personnel with designation AHC |
| 13 | show RSI | table | All RSI-ranked personnel |
| 14 | give list of all APC currently | table | All APC designation |
| 15 | list section A personnel | table | Personnel in section A |
| 16 | show section B | table | Section B personnel |
| 17 | section MT list | table | Motor Transport section |
| 18 | who is in section C | table | Section C personnel |
| 19 | ವಿಭಾಗ A ಪಟ್ಟಿ | table | Section A list (Kannada) |
| 20 | show drivers | table | MT section drivers |
| 21 | ಚಾಲಕರು ತೋರಿಸು | table | Drivers (Kannada) |
| 22 | drivers without PDMS | table | Drivers where pdms=NOT DONE |
| 23 | LMV drivers | table | Drivers with licence_type=LMV |
| 24 | HMV licence holders | table | Drivers with HMV licence |
| 25 | show guard duty personnel | table | Personnel with duty_type=GUARD |
| 26 | who is on HOYSALA | table | HOYSALA duty personnel |
| 27 | list traffic duty | table | TRAFFIC duty personnel |
| 28 | personnel on check post | table | CHECK POST personnel |
| 29 | dog squad members | table | DOG SQUAD duty type |
| 30 | striking force personnel | table | STRIKING FORCE duty |
| 31 | AHC in Section A | table | Combined filter: designation=AHC, section=A |
| 32 | RSI on guard duty | table | Combined: designation=RSI, duty=GUARD |
| 33 | how many in section A | table/text | Strength summary for section A |
| 34 | total strength | table | Overall personnel count by designation |
| 35 | ಸಂಖ್ಯೆ ತೋರಿಸು | table | Strength summary (Kannada) |
| 36 | strength summary | table | Designation-wise count |
| 37 | how many APC | table | Count of APC designation |
| 38 | search 9876543210 | table | Search by phone number |
| 39 | find personnel by email jayanth@police | table | Email search |
| 40 | inactive personnel | table | Shows is_active=false records |

---

## Category 2: Leave Management (45 Commands)

| # | Command | Expected Response Type | Expected Behavior |
|---|---------|----------------------|-------------------|
| 41 | show leave status | table | Leave request list with details |
| 42 | ರಜೆ ಸ್ಥಿತಿ ತೋರಿಸು | table | Leave status (Kannada) |
| 43 | who is on leave | table | Currently approved leaves |
| 44 | how many on leave | text/table | Leave count by status |
| 45 | ಎಷ್ಟು ರಜೆ | text | Leave count (Kannada) |
| 46 | pending leave requests | table | Status=PENDING filter |
| 47 | approved leaves | table | Status=APPROVED filter |
| 48 | rejected leaves | table | Status=REJECTED filter |
| 49 | sick leave requests | table | leave_type=SICK_LEAVE filter |
| 50 | casual leave list | table | CASUAL_LEAVE filter |
| 51 | ಅನಾರೋಗ್ಯ ರಜೆ | table | Sick leave (Kannada) |
| 52 | ಸಾಮಾನ್ಯ ರಜೆ | table | Casual leave (Kannada) |
| 53 | create sick leave for AHC 2649 on june 25 2026 | confirmation | Creates leave request |
| 54 | casual leave for APC 168 tomorrow | confirmation | Creates with tomorrow's date |
| 55 | create sick leave for jayanth on 21 06 2026 | form/confirmation | Creates or shows form if ambiguous |
| 56 | apply leave for AHC 2649 | suggestions | Asks which leave type |
| 57 | create earned leave for RSI 01 from june 25 to june 30 | confirmation | Multi-day leave |
| 58 | weekly off for APC 200 today | confirmation | Creates WEEKLY_OFF |
| 59 | compensatory off for AHC 100 on june 28 | confirmation | Creates COMPENSATORY_OFF |
| 60 | ರಜೆ ಅರ್ಜಿ AHC 2649 | form | Leave form (Kannada) |
| 61 | leave for today for badge APC-035 | suggestions | Asks leave type |
| 62 | create leave | form | Shows leave creation form |
| 63 | apply sick leave for Mahantesh on 22 06 2026 | confirmation | Creates by name |
| 64 | show leaves this month | table | Date-filtered leaves |
| 65 | leaves in june 2026 | table | Month filter |
| 66 | who is on leave today | table | Today's approved leaves |
| 67 | leave count | text | Summary counts |
| 68 | ರಜೆ ವರದಿ ಡೌನ್‌ಲೋಡ್ | confirmation | Downloads leave PDF |
| 69 | download leave report | confirmation | PDF download trigger |
| 70 | show leave details for AHC 2649 | table | Person-specific leaves |
| 71 | cancel leave 42 | confirmation | Cancels leave ID 42 |
| 72 | approve leave 43 | confirmation | Approves leave (if admin) |
| 73 | reject leave 44 with reason staffing | confirmation | Rejects with reason |
| 74 | create leave for section A personnel | form | Shows form |
| 75 | bulk leave for tomorrow | form | Shows form |
| 76 | how many sick leaves pending | text | Count |
| 77 | earned leave balance | text/suggestions | Not supported message |
| 78 | leave history for APC 168 | table | Person's leave history |
| 79 | show all approved sick leaves | table | Combined filter |
| 80 | pending casual leaves | table | Combined filter |
| 81 | create sick leave for 5 people | form | Shows form |
| 82 | leave report for june | table | Month filter |
| 83 | ದಿನಾಂಕ 25 ಜೂನ್ ರಜೆ | form | Date-specific (Kannada) |
| 84 | weekly off schedule | table | WEEKLY_OFF leaves |
| 85 | compensatory off requests | table | COMPENSATORY_OFF filter |

---

## Category 3: Schedule & Duty (35 Commands)

| # | Command | Expected Response Type | Expected Behavior |
|---|---------|----------------------|-------------------|
| 86 | show current schedule | table | Schedule overview |
| 87 | today's assignment | table | Today's duty assignments |
| 88 | who's working today | table | Current deployment |
| 89 | ವೇಳಾಪಟ್ಟಿ ತೋರಿಸು | table | Schedule (Kannada) |
| 90 | show schedule overview | table | Section-wise overview |
| 91 | platoon rotation | table | Current platoon-section mapping |
| 92 | ಪ್ಲಟೂನ್ ತೋರಿಸು | table | Platoon rotation (Kannada) |
| 93 | which platoon is on guard | table | Platoon assigned to guard |
| 94 | today's guard duty | table | Guard duty personnel today |
| 95 | who is on check post today | table | Check post assignments |
| 96 | today's striking force | table | Striking force duty |
| 97 | ಗಾರ್ಡ್ ಕರ್ತವ್ಯ | table | Guard duty (Kannada) |
| 98 | show duty types | table | All duty types list |
| 99 | ಕರ್ತವ್ಯ ಪ್ರಕಾರಗಳು | table | Duty types (Kannada) |
| 100 | duty types in section A | table | Section-filtered duty types |
| 101 | posts in section B | table | Section B duties |
| 102 | show all posts | table | All duty types |
| 103 | ಹುದ್ದೆಗಳು ತೋರಿಸು | table | Posts (Kannada) |
| 104 | add duty type | form | Shows duty type creation form |
| 105 | create duty type PATROL in section C | confirmation | Creates duty type |
| 106 | new post | form | Duty type creation form |
| 107 | add duty | form | Duty type form |
| 108 | update duty type GUARD to MAIN GUARD | confirmation | Renames |
| 109 | delete duty type OBSOLETE | confirmation | Deletes |
| 110 | section A duties | table | Section A duty types |
| 111 | what duties are there | table | All duty types |
| 112 | show sections | table | Section list |
| 113 | how many duty types | text | Count |
| 114 | today's deployment | table | Full deployment view |
| 115 | current schedule for section A | table | Section A current |
| 116 | night duty personnel | table | Night shift |
| 117 | afternoon shift today | table | Afternoon duty |
| 118 | day shift personnel | table | Day shift |
| 119 | duty types with location | table | Geo-located duties |
| 120 | guard posts list | table | Guard-related duty types |

---

## Category 4: Cycle Management (40 Commands)

| # | Command | Expected Response Type | Expected Behavior |
|---|---------|----------------------|-------------------|
| 121 | create platoon | form | Cycle creation form with auto-mappings |
| 122 | create platoon cycle | form | Same as above |
| 123 | create cycle | form | Cycle form |
| 124 | new cycle | form | Cycle form |
| 125 | setup rotation | form | Cycle form |
| 126 | create shift cycle | form | Cycle form |
| 127 | create schedule | form | Cycle form |
| 128 | publish cycle | form | Cycle form |
| 129 | list cycles | table | All non-deleted cycles |
| 130 | show cycles | table | Cycle list |
| 131 | view cycles | table | Cycle list |
| 132 | cycle history | table | All cycles including completed |
| 133 | active cycles | table | Status=ACTIVE filter |
| 134 | completed cycles | table | Status=COMPLETED filter |
| 135 | show cycle 5 | table | Details of cycle ID 5 |
| 136 | cycle details for 3 | table | Cycle ID 3 details |
| 137 | update cycle 5 | confirmation | Update cycle |
| 138 | modify cycle 5 rotation to 20 days | confirmation | Update rotation_days |
| 139 | delete cycle 5 | confirmation | Soft-delete |
| 140 | remove cycle 3 | confirmation | Soft-delete |
| 141 | reassign duty assignment 1500 to person 45 | confirmation | Manual reassignment |
| 142 | reassign assignment 1500 | form | Shows available personnel |
| 143 | manually reassign duty 1500 to 67 | confirmation | Reassignment |
| 144 | auto reassign assignment 1500 | confirmation | Auto-picks replacement |
| 145 | auto assign duty 1500 | confirmation | Auto-reassignment |
| 146 | find replacement for 1500 | confirmation | Auto-reassign |
| 147 | auto swap duty 1500 | confirmation | Auto-reassign |
| 148 | automatically reassign 1500 | confirmation | Auto-reassign |
| 149 | show activities | table | Cycle audit log |
| 150 | cycle history log | table | Audit entries |
| 151 | what changed in cycles | table | Recent audit |
| 152 | audit log | table | All activities |
| 153 | show activities for cycle 5 | table | Cycle-specific audit |
| 154 | create 15 day cycle starting july 1 | form/confirmation | Pre-filled form |
| 155 | next available date for cycle | text | Returns date |
| 156 | when does current cycle end | table | Current cycle end date |
| 157 | how many days left in current cycle | text | Calculation |
| 158 | platoon 1 current duty | table | What section P1 is on |
| 159 | which section is platoon 3 | table | P3 mapping |
| 160 | rotation schedule | table | Full rotation view |

---

## Category 5: Adhoc Duties (30 Commands)

| # | Command | Expected Response Type | Expected Behavior |
|---|---------|----------------------|-------------------|
| 161 | create adhoc duty | form | Adhoc duty form |
| 162 | bandobast duty | form | Same (adhoc form) |
| 163 | special duty | form | Adhoc form |
| 164 | create special assignment | form | Adhoc form |
| 165 | create adhoc duty Independence Day on aug 15 with 20 people | form/confirmation | Pre-filled or created |
| 166 | bandobast for tomorrow 10 people | form | Pre-filled form |
| 167 | list adhoc duties | table | All adhoc duties |
| 168 | show special duties | table | Adhoc list |
| 169 | bandobast list | table | Same |
| 170 | adhoc duties today | table | Date-filtered |
| 171 | active adhoc duties | table | Status=ACTIVE |
| 172 | adhoc duty details 8 | table | Specific duty details |
| 173 | show adhoc duty 5 | table | Details with assignees |
| 174 | cancel adhoc duty 8 | confirmation | Cancels duty |
| 175 | cancel special duty 5 | confirmation | Cancels |
| 176 | how many adhoc duties | text | Count |
| 177 | upcoming special duties | table | Future dated |
| 178 | past adhoc duties | table | Completed ones |
| 179 | cancelled adhoc duties | table | Status=CANCELLED |
| 180 | create VIP escort duty for june 30 | form | Pre-filled |
| 181 | bandobast 15 people from platoon 1 and 2 | form | SPECIFIC_PLATOONS |
| 182 | special duty at city center | form | Location pre-filled |
| 183 | adhoc duty from 6am to 6pm | form | Time pre-filled |
| 184 | create night patrol duty | form | Adhoc form |
| 185 | show personnel for adhoc duty 8 | table | Assignees list |
| 186 | download adhoc duty 8 report | confirmation | PDF download |
| 187 | adhoc duty excel 8 | confirmation | Excel download |
| 188 | how many people assigned to adhoc 8 | text | actual_count |
| 189 | available personnel for july 1 | table | Preview |
| 190 | who is free on june 30 afternoon | table | Available personnel |

---

## Category 6: Reports & Downloads (30 Commands)

| # | Command | Expected Response Type | Expected Behavior |
|---|---------|----------------------|-------------------|
| 191 | download drivers | confirmation | MT Section PDF |
| 192 | ಚಾಲಕರ ವರದಿ ಡೌನ್‌ಲೋಡ್ | confirmation | MT Section PDF (Kannada) |
| 193 | download section a | confirmation | Section A PDF |
| 194 | ವಿಭಾಗ A ವರದಿ | confirmation | Section A (Kannada) |
| 195 | download leave report | confirmation | Leave Statement PDF |
| 196 | ರಜೆ ವರದಿ ಡೌನ್‌ಲೋಡ್ | confirmation | Leave PDF (Kannada) |
| 197 | download form 168 | confirmation | Daily Statement PDF |
| 198 | ದೈನಿಕ ಹೇಳಿಕೆ | confirmation | Form 168 (Kannada) |
| 199 | download platoon chart | confirmation | Platoon Chart PDF |
| 200 | daily statement download | confirmation | Form 168 |
| 201 | download section b report | confirmation | Section B PDF |
| 202 | MT section report | confirmation | Drivers PDF |
| 203 | personnel report download | confirmation | Personnel List PDF |
| 204 | section a and b combined | confirmation | Section AB PDF |
| 205 | schedule report | confirmation | Schedule PDF |
| 206 | download all reports | suggestions | Not supported, shows options |
| 207 | excel report for drivers | confirmation | MT Excel |
| 208 | platoon chart excel | confirmation | Platoon Excel |
| 209 | leave statement excel | confirmation | Leave Excel |
| 210 | form 168 for june 20 | confirmation | Specific date report |
| 211 | yesterday's daily statement | confirmation | Previous day report |
| 212 | ವರದಿ ಡೌನ್‌ಲೋಡ್ | suggestions | Shows report options |
| 213 | download report | suggestions | Shows available reports |
| 214 | generate pdf | suggestions | Shows report options |
| 215 | section C report | confirmation | Platoon chart section C |
| 216 | section D report | confirmation | Section D platoon chart |
| 217 | all section reports | suggestions | Shows options |
| 218 | approved leave report | confirmation | Filtered leave PDF |
| 219 | AHC personnel report | confirmation | Filtered personnel PDF |
| 220 | active personnel report | confirmation | isActive=true filter |

---

## Category 7: Personnel Updates (30 Commands)

| # | Command | Expected Response Type | Expected Behavior |
|---|---------|----------------------|-------------------|
| 221 | change name of AHC 2649 to Jayanth Kumar S | confirmation | Updates person_name |
| 222 | rename APC 168 to Suresh Rao K | confirmation | Updates name |
| 223 | update name of RSI 01 to Prakash M | confirmation | Updates name |
| 224 | change designation of APC 168 to AHC | confirmation | Updates designation |
| 225 | update rank of AHC 100 to RSI | confirmation | Updates designation |
| 226 | move AHC 2649 to section B | confirmation | Updates section |
| 227 | change section of APC 168 to MT | confirmation | Updates section |
| 228 | update phone of AHC 2649 to 9999888877 | confirmation | Updates phone |
| 229 | change email of APC 168 | confirmation | Updates email |
| 230 | set AHC 2649 inactive | confirmation | is_active=false |
| 231 | deactivate APC 100 | confirmation | is_active=false |
| 232 | activate APC 100 | confirmation | is_active=true |
| 233 | change duty type of AHC 2649 to HOYSALA | confirmation | Updates duty |
| 234 | update vehicle of APC 168 to KA19P1234 | confirmation | Updates vehicle |
| 235 | change location of AHC 2649 to Main Gate | confirmation | Updates location |
| 236 | add person Ramesh badge APC-301 section C | confirmation | Creates new person |
| 237 | add new staff member | form | Personnel creation form |
| 238 | create personnel | form | Personnel form |
| 239 | register new officer | form | Personnel form |
| 240 | add driver | form | Personnel form (MT focus) |
| 241 | add person to platoon 3 | form | Pre-filled platoon |
| 242 | transfer AHC 2649 to section D platoon 4 | confirmation | Updates section+platoon |
| 243 | update pdms of APC 168 to DONE | confirmation | PDMS status |
| 244 | change licence type to HMV for APC 200 | confirmation | Licence update |
| 245 | update deployed from for AHC 100 | confirmation | Updates deployedFrom |
| 246 | show AHC 2649 current section | table | Person details |
| 247 | what is APC 168 duty type | table | Person details |
| 248 | is AHC 2649 active | table | Person details |
| 249 | personnel details badge APC-035 | table | Full details |
| 250 | update date of joining for AHC 2649 | confirmation | Updates DOJ |

---

## Category 8: Greetings & General (30 Commands)

| # | Command | Expected Response Type | Expected Behavior |
|---|---------|----------------------|-------------------|
| 251 | hi | suggestions | Greeting + suggestions |
| 252 | hello | suggestions | Greeting |
| 253 | ನಮಸ್ಕಾರ | suggestions | Kannada greeting |
| 254 | good morning | suggestions | Greeting |
| 255 | namaskara | suggestions | Greeting |
| 256 | help | suggestions | Shows available options |
| 257 | what can you do | suggestions | Shows capabilities |
| 258 | features | suggestions | Shows feature list |
| 259 | ನೀವು ಏನು ಮಾಡಬಹುದು | suggestions | Capabilities (Kannada) |
| 260 | thank you | suggestions | Acknowledgment |
| 261 | ధన్యవಾద | suggestions | Thanks (Kannada/Telugu) |
| 262 | ok | suggestions | Acknowledgment |
| 263 | bye | suggestions | Farewell |
| 264 | show options | suggestions | Available actions |
| 265 | menu | suggestions | Options |
| 266 | what is this system | text | System description |
| 267 | who made this | text | System info |
| 268 | system status | text | Health info |
| 269 | is AI working | text | AI health check |
| 270 | current date | text | Today's date |
| 271 | what day is today | text | Day of week |
| 272 | gibberish text asdfjkl | suggestions | Fallback suggestions |
| 273 | empty message | suggestions | Fallback |
| 274 | 12345 | table | Tries badge search |
| 275 | random sentence with no meaning | suggestions | Fallback |
| 276 | zzzzz | suggestions | Fallback |
| 277 | show everything | suggestions | Too broad, shows options |
| 278 | do something | suggestions | Shows options |
| 279 | I need help | suggestions | Shows assistance options |
| 280 | ಸಹಾಯ | suggestions | Help (Kannada) |

---

## Category 9: Mixed Language & Edge Cases (30 Commands)

| # | Command | Expected Response Type | Expected Behavior |
|---|---------|----------------------|-------------------|
| 281 | show ಸಿಬ್ಬಂದಿ list | table | Mixed EN+KN: personnel list |
| 282 | AHC 2649 ವಿವರ | table | Mixed: badge + Kannada "details" |
| 283 | ರಜೆ create for APC 168 | form | Mixed: Kannada "leave" + English |
| 284 | section A ಪಟ್ಟಿ | table | Mixed: section A list |
| 285 | platoon ತೋರಿಸು | table | Mixed: show platoon |
| 286 | guard duty ಇವತ್ತು | table | Mixed: guard today |
| 287 | AHC2649 | table | No space in badge — should normalize |
| 288 | ahc 2649 | table | Lowercase prefix — should normalize |
| 289 | AHC  2649 | table | Extra spaces — should handle |
| 290 | details AHC-2649 | table | With hyphen |
| 291 | DETAILS OF AHC 2649 | table | All caps |
| 292 | personnel | table | Single word query |
| 293 | leave | table | Single word — leave details |
| 294 | schedule | table | Single word — schedule |
| 295 | duty | table | Duty types or today duties |
| 296 | report | suggestions | Report options |
| 297 | create | suggestions | Create what? |
| 298 | delete | suggestions | Delete what? |
| 299 | update | suggestions | Update what? |
| 300 | show | suggestions | Show what? |
| 301 | list | suggestions | List what? |
| 302 | download | suggestions | Download options |
| 303 | create sick leave for jayanth kumar on 25/06/2026 | confirmation | Date format handling |
| 304 | casual leave 3 days from june 25 | form | Multi-day with inference |
| 305 | add APC-500 Ramesh section A designation APC | confirmation | Full inline creation |
| 306 | search by phone 9876 | table | Partial phone search |
| 307 | who joined after 2020 | table | Date-based search |
| 308 | platoon 1 members | table | Platoon filter |
| 309 | section C platoon 2 personnel | table | Combined filter |
| 310 | show cycle 999 | text/error | Non-existent cycle |

---

## Execution Summary Template

| Category | Total | Passed | Failed | Notes |
|----------|-------|--------|--------|-------|
| Personnel Search | 40 | ☐ | ☐ | |
| Leave Management | 45 | ☐ | ☐ | |
| Schedule & Duty | 35 | ☐ | ☐ | |
| Cycle Management | 40 | ☐ | ☐ | |
| Adhoc Duties | 30 | ☐ | ☐ | |
| Reports & Downloads | 30 | ☐ | ☐ | |
| Personnel Updates | 30 | ☐ | ☐ | |
| Greetings & General | 30 | ☐ | ☐ | |
| Mixed Language & Edge | 30 | ☐ | ☐ | |
| **Total** | **310** | | | |

---

*End of Document — Chat Test Scenarios v1.0.0*

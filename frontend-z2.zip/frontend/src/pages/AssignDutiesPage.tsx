import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import {
  Box,
  Card,
  CardActionArea,
  Typography,
  Stack,
  Chip,
  IconButton,
  TextField,
  Autocomplete,
  Collapse,
  Button,
  CircularProgress,
  Snackbar,
  Alert,
  InputAdornment,
  Tooltip,
  Paper,
  List,
  ListItemButton,
  ListItemText,
  Divider,
  Badge,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Tab,
  Tabs,
} from '@mui/material';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import BadgeIcon from '@mui/icons-material/Badge';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { useTranslation } from 'react-i18next';
import PageHeader from '@/components/common/PageHeader';
import Carousel from '@/components/common/Carousel';
import {
  sectionChartService,
  type SectionChartData,
  type DutyCard,
  type SubDutyGroup,
  type ChartPersonnel,
  type PersonnelSearchResult,
} from '@/services/sectionChartService';

// ===== Section Definitions =====
const SECTIONS = [
  { id: 'A', name: 'Section A', description: 'Fixed / Essential Duties', color: '#312e81', bgColor: '#eef2ff' },
  { id: 'B', name: 'Section B', description: 'Office / Support Duties', color: '#0d9488', bgColor: '#f0fdfa' },
  { id: 'C', name: 'Section C', description: 'Guard-I (Rotation)', color: '#7c3aed', bgColor: '#f5f3ff' },
  { id: 'D', name: 'Section D', description: 'Guard-II (Rotation)', color: '#dc2626', bgColor: '#fef2f2' },
  { id: 'E', name: 'Section E', description: 'Check Post Duty', color: '#d97706', bgColor: '#fffbeb' },
  { id: 'F', name: 'Section F', description: 'VIP Escorts / Prisoner Escort', color: '#2563eb', bgColor: '#eff6ff' },
  { id: 'G', name: 'Section G', description: 'Striking Force / Follow Up', color: '#059669', bgColor: '#ecfdf5' },
  { id: 'O', name: 'Section O', description: "Officer's Duty", color: '#be185d', bgColor: '#fdf2f8' },
  { id: 'MT', name: 'MT Section', description: 'Motor Transport / Drivers', color: '#ea580c', bgColor: '#fff7ed' },
];

// ===== Leave Categories (from Form 168) =====
const LEAVE_CATEGORIES = [
  { name: 'LEAVE (CL,CML,PL,EL)', description: 'Casual / Medical / Privilege / Earned Leave' },
  { name: 'ABSENT', description: 'Absent without leave' },
  { name: 'SUSPENSION', description: 'Under suspension' },
  { name: 'PERMISSION / RH TO RPI, RSI AND', description: 'Permission / Restricted Holiday' },
  { name: 'SICK', description: 'Sick leave' },
  { name: 'WEEKLY OFF', description: 'Weekly off duty' },
];

// ===== Main Page Component =====
const AssignDutiesPage: React.FC = () => {
  const { t } = useTranslation();
  const [selectedSection, setSelectedSection] = useState<string | null>('A');
  const [chartData, setChartData] = useState<SectionChartData | null>(null);
  const [selectedDutyTypeId, setSelectedDutyTypeId] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [snackbar, setSnackbar] = useState<{ open: boolean; message: string; severity: 'success' | 'error' }>({
    open: false, message: '', severity: 'success',
  });
  const [sidebarFilter, setSidebarFilter] = useState('');
  const [showAddDutyType, setShowAddDutyType] = useState(false);
  const [newDutyTypeName, setNewDutyTypeName] = useState('');
  const [activeTab, setActiveTab] = useState(0); // 0 = Duty Management, 1 = Leave Management
  const [selectedLeaveCategory, setSelectedLeaveCategory] = useState<string>(LEAVE_CATEGORIES[0].name);
  const [deleteDialog, setDeleteDialog] = useState<{
    open: boolean;
    type: 'dutyType' | 'subDuty';
    name: string;
    dutyTypeId?: number;
    subDutyName?: string;
  }>({ open: false, type: 'dutyType', name: '' });

  // Load chart data when section changes
  useEffect(() => {
    if (selectedSection) {
      loadChartData(selectedSection);
    } else {
      setChartData(null);
      setSelectedDutyTypeId(null);
    }
  }, [selectedSection]);

  const loadChartData = async (sectionCode: string, showSpinner = true) => {
    if (showSpinner) setLoading(true);
    try {
      const data = await sectionChartService.getChart(sectionCode);
      setChartData(data);
      // Auto-select first duty type if none selected
      if (data.dutyCards.length > 0 && !selectedDutyTypeId) {
        setSelectedDutyTypeId(data.dutyCards[0].dutyTypeId);
      }
    } catch (err) {
      setSnackbar({ open: true, message: 'Failed to load section data', severity: 'error' });
    } finally {
      setLoading(false);
    }
  };

  const handleSectionClick = (sectionId: string) => {
    setSelectedSection(sectionId);
    setSelectedDutyTypeId(null);
    setSidebarFilter('');
    setShowAddDutyType(false);
  };

  const handleAssignPerson = async (personnelId: number, dutyTypeId: number, subDuty?: string | null) => {
    if (!selectedSection) return;
    setSaving(true);
    try {
      await sectionChartService.assign({
        personnelId,
        dutyTypeId,
        sectionCode: selectedSection,
        subDuty: subDuty || null,
      });
      setSnackbar({ open: true, message: '✓ Person assigned successfully', severity: 'success' });
      await loadChartData(selectedSection, false);
    } catch (err) {
      setSnackbar({ open: true, message: 'Failed to assign person', severity: 'error' });
    } finally {
      setSaving(false);
    }
  };

  const handleUnassignPerson = async (personnelId: number) => {
    if (!selectedSection) return;
    setSaving(true);
    try {
      await sectionChartService.unassign({ personnelId });
      setSnackbar({ open: true, message: '✓ Person removed from duty', severity: 'success' });
      await loadChartData(selectedSection, false);
    } catch (err) {
      setSnackbar({ open: true, message: 'Failed to remove person', severity: 'error' });
    } finally {
      setSaving(false);
    }
  };

  const handleAddDutyType = async () => {
    if (!selectedSection || !newDutyTypeName.trim()) return;
    setSaving(true);
    try {
      const maxSort = chartData?.dutyCards.length ?? 0;
      await sectionChartService.createDutyType({
        name: newDutyTypeName.trim().toUpperCase(),
        section: selectedSection,
        sortOrder: maxSort + 1,
        level: 'PARENT',
      });
      setSnackbar({ open: true, message: '✓ Duty type created', severity: 'success' });
      setNewDutyTypeName('');
      setShowAddDutyType(false);
      await loadChartData(selectedSection, false);
    } catch (err) {
      setSnackbar({ open: true, message: 'Failed to create duty type', severity: 'error' });
    } finally {
      setSaving(false);
    }
  };

  const handleAddSubDuty = async (parentDutyTypeId: number, subDutyName: string) => {
    if (!selectedSection || !subDutyName.trim()) return;
    setSaving(true);
    try {
      // Sub-duty is just a duty_location value. 
      // We validate it via the backend, then it becomes available when assigning personnel.
      await sectionChartService.addSubDuty({
        subDutyName: subDutyName.trim().toUpperCase(),
        parentDutyTypeId,
      });
      setSnackbar({ open: true, message: '✓ Sub duty added. Assign personnel to persist.', severity: 'success' });
      // Reload to refresh (won't show empty sub-duty until someone is assigned)
      await loadChartData(selectedSection, false);
    } catch (err) {
      setSnackbar({ open: true, message: 'Failed to add sub duty', severity: 'error' });
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteDutyType = (dutyTypeId: number, name: string) => {
    setDeleteDialog({ open: true, type: 'dutyType', name, dutyTypeId });
  };

  const handleDeleteSubDuty = (dutyTypeId: number, subDutyName: string) => {
    setDeleteDialog({ open: true, type: 'subDuty', name: subDutyName, dutyTypeId, subDutyName });
  };

  const confirmDelete = async () => {
    if (!selectedSection) return;
    setSaving(true);
    setDeleteDialog((d) => ({ ...d, open: false }));
    try {
      if (deleteDialog.type === 'dutyType' && deleteDialog.dutyTypeId) {
        await sectionChartService.deleteDutyType(deleteDialog.dutyTypeId);
        setSnackbar({ open: true, message: `✓ "${deleteDialog.name}" deleted`, severity: 'success' });
        // If deleted the currently selected, clear selection
        if (selectedDutyTypeId === deleteDialog.dutyTypeId) {
          setSelectedDutyTypeId(null);
        }
      } else if (deleteDialog.type === 'subDuty' && deleteDialog.dutyTypeId && deleteDialog.subDutyName) {
        await sectionChartService.deleteSubDuty(deleteDialog.dutyTypeId, deleteDialog.subDutyName);
        setSnackbar({ open: true, message: `✓ Sub duty "${deleteDialog.name}" deleted`, severity: 'success' });
      }
      await loadChartData(selectedSection, false);
    } catch (err) {
      setSnackbar({ open: true, message: 'Failed to delete', severity: 'error' });
    } finally {
      setSaving(false);
    }
  };

  // Get the selected duty card
  const selectedCard = chartData?.dutyCards.find((c) => c.dutyTypeId === selectedDutyTypeId);
  const selectedData = SECTIONS.find((s) => s.id === selectedSection);

  // Filter sidebar duty types
  const filteredDutyCards = chartData?.dutyCards.filter((card) => {
    if (!sidebarFilter) return true;
    return card.dutyTypeName.toLowerCase().includes(sidebarFilter.toLowerCase());
  }) ?? [];

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', bgcolor: 'background.default' }}>
      <PageHeader
        title={t('nav.assignDuties', 'Assign Duties')}
        breadcrumbs={[
          { label: t('nav.home', 'Home'), path: '/' },
          { label: t('nav.groups.operations', 'Operations') },
          { label: t('nav.assignDuties', 'Assign Duties') },
        ]}
      />

      {/* Section Carousel */}
      <Box sx={{ px: { xs: 2, md: 3 }, pt: 3, pb: 1 }}>
        <Typography variant="subtitle1" sx={{ mb: 1.5, color: 'text.secondary', fontWeight: 600 }}>
          Select Section
        </Typography>
        <Carousel ariaLabel="Duty sections carousel">
          {SECTIONS.map((section) => {
            const isSelected = selectedSection === section.id;
            return (
              <Card
                key={section.id}
                elevation={isSelected ? 6 : 0}
                sx={{
                  flex: '0 0 auto',
                  width: { xs: '140px', sm: '150px', md: '160px' },
                  borderRadius: '12px',
                  border: 'none',
                  background: isSelected
                    ? `linear-gradient(135deg, ${section.color} 0%, ${section.color}cc 100%)`
                    : `linear-gradient(135deg, ${section.bgColor} 0%, ${section.color}12 100%)`,
                  transition: 'all 300ms cubic-bezier(0.4, 0, 0.2, 1)',
                  position: 'relative',
                  overflow: 'visible',
                  '&:hover': {
                    transform: 'translateY(-4px) scale(1.02)',
                    boxShadow: `0 12px 32px ${section.color}30`,
                  },
                }}
              >
                {isSelected && (
                  <Chip
                    label="✓ Active"
                    size="small"
                    sx={{
                      position: 'absolute', top: -10, right: 12,
                      bgcolor: '#ffffff', color: section.color,
                      fontSize: '0.6rem', height: 20, fontWeight: 700,
                      boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
                    }}
                  />
                )}
                <CardActionArea onClick={() => handleSectionClick(section.id)} sx={{ px: 1.5, py: 1.5 }}>
                  <Stack spacing={0.5} alignItems="center">
                    <Box
                      sx={{
                        width: 28, height: 28, borderRadius: '8px',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        bgcolor: isSelected ? 'rgba(255,255,255,0.25)' : `${section.color}18`,
                      }}
                    >
                      <Typography sx={{ fontWeight: 800, fontSize: '0.75rem', color: isSelected ? '#ffffff' : section.color }}>
                        {section.id}
                      </Typography>
                    </Box>
                    <Typography sx={{ fontWeight: 700, fontSize: '0.72rem', color: isSelected ? '#ffffff' : 'text.primary', textAlign: 'center', lineHeight: 1.2 }}>
                      {section.name}
                    </Typography>
                    <Typography sx={{ fontSize: '0.6rem', color: isSelected ? 'rgba(255,255,255,0.85)' : 'text.secondary', textAlign: 'center', lineHeight: 1.2 }}>
                      {section.description}
                    </Typography>
                  </Stack>
                </CardActionArea>
              </Card>
            );
          })}
        </Carousel>
      </Box>

      {/* Main Content: Tabs + Content */}
      <Box sx={{ flex: 1, px: { xs: 1, md: 3 }, py: 2 }}>
        {/* Tab Navigation */}
        {selectedData && chartData && (
          <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 2 }}>
            <Tabs
              value={activeTab}
              onChange={(_, v) => setActiveTab(v)}
              sx={{
                '& .MuiTab-root': { textTransform: 'none', fontWeight: 600, fontSize: '0.85rem' },
                '& .Mui-selected': { color: selectedData.color },
                '& .MuiTabs-indicator': { backgroundColor: selectedData.color },
              }}
            >
              <Tab label="Duty Management" />
              <Tab label="Leave Management" />
            </Tabs>
          </Box>
        )}

        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
            <CircularProgress />
          </Box>
        ) : selectedData && chartData ? (
          <>
            {/* TAB 0: Duty Management (existing view) */}
            {activeTab === 0 && (
          <Box sx={{ display: 'flex', gap: 2, alignItems: 'flex-start' }}>
            {/* LEFT SIDEBAR: Parent Duty Types List - shows full list, no scroll */}
            <Paper
              elevation={0}
              sx={{
                width: { xs: 200, sm: 240, md: 280 },
                flexShrink: 0,
                border: '1px solid',
                borderColor: 'divider',
                borderRadius: '12px',
                display: 'flex',
                flexDirection: 'column',
                position: 'sticky',
                top: 16,
              }}
            >
              {/* Sidebar Header */}
              <Box sx={{ px: 2, py: 1.5, bgcolor: selectedData.bgColor, borderBottom: '1px solid', borderColor: 'divider' }}>
                <Typography variant="subtitle2" sx={{ fontWeight: 700, color: selectedData.color }}>
                  {selectedData.name} Duties
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {chartData.dutyCards.length} duties • {chartData.totalPersonnel} personnel
                </Typography>
              </Box>

              {/* Search Filter */}
              <Box sx={{ px: 1.5, py: 1 }}>
                <TextField
                  size="small"
                  fullWidth
                  placeholder="Filter duties..."
                  value={sidebarFilter}
                  onChange={(e) => setSidebarFilter(e.target.value)}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <SearchIcon fontSize="small" color="action" />
                      </InputAdornment>
                    ),
                    sx: { fontSize: '0.8rem' },
                  }}
                />
              </Box>

              {/* Duty Types List - full height, no scroll */}
              <Box>
                <List dense disablePadding>
                  {filteredDutyCards.map((card) => (
                    <ListItemButton
                      key={card.dutyTypeId}
                      selected={selectedDutyTypeId === card.dutyTypeId}
                      onClick={() => setSelectedDutyTypeId(card.dutyTypeId)}
                      sx={{
                        px: 2, py: 1,
                        borderLeft: selectedDutyTypeId === card.dutyTypeId ? `3px solid ${selectedData.color}` : '3px solid transparent',
                        '&.Mui-selected': {
                          bgcolor: `${selectedData.color}08`,
                        },
                        '&.Mui-selected:hover': {
                          bgcolor: `${selectedData.color}12`,
                        },
                      }}
                    >
                      <ListItemText
                        primary={
                          <Stack direction="row" spacing={0.5} alignItems="center">
                            <Typography
                              variant="caption"
                              sx={{
                                fontWeight: selectedDutyTypeId === card.dutyTypeId ? 700 : 500,
                                fontSize: '0.72rem',
                                textTransform: 'uppercase',
                                letterSpacing: '0.3px',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                whiteSpace: 'nowrap',
                                flex: 1,
                              }}
                            >
                              {card.dutyTypeName}
                            </Typography>
                            <Chip
                              label={card.personnelCount}
                              size="small"
                              sx={{
                                height: 18, fontSize: '0.6rem', fontWeight: 700,
                                bgcolor: card.personnelCount > 0 ? `${selectedData.color}15` : 'grey.100',
                                color: card.personnelCount > 0 ? selectedData.color : 'text.disabled',
                              }}
                            />
                          </Stack>
                        }
                      />
                    </ListItemButton>
                  ))}
                </List>
              </Box>

              {/* Add Duty Type */}
              <Box sx={{ borderTop: '1px solid', borderColor: 'divider', p: 1.5 }}>
                {showAddDutyType ? (
                  <Stack spacing={1}>
                    <TextField
                      size="small"
                      fullWidth
                      placeholder="New duty type name..."
                      value={newDutyTypeName}
                      onChange={(e) => setNewDutyTypeName(e.target.value)}
                      onKeyDown={(e) => { if (e.key === 'Enter') handleAddDutyType(); }}
                      autoFocus
                      InputProps={{ sx: { fontSize: '0.8rem' } }}
                    />
                    <Stack direction="row" spacing={0.5}>
                      <Button size="small" variant="contained" onClick={handleAddDutyType} disabled={!newDutyTypeName.trim()} sx={{ fontSize: '0.7rem' }}>
                        Create
                      </Button>
                      <Button size="small" onClick={() => { setShowAddDutyType(false); setNewDutyTypeName(''); }} sx={{ fontSize: '0.7rem' }}>
                        Cancel
                      </Button>
                    </Stack>
                  </Stack>
                ) : (
                  <Button
                    fullWidth
                    size="small"
                    startIcon={<AddCircleOutlineIcon />}
                    onClick={() => setShowAddDutyType(true)}
                    sx={{ textTransform: 'none', fontSize: '0.75rem' }}
                  >
                    Add Duty Type
                  </Button>
                )}
              </Box>
            </Paper>

            {/* RIGHT: Main Content - matches left sidebar height, scrolls if content overflows */}
            <Box sx={{ flex: 1, minWidth: 0, alignSelf: 'stretch' }}>
              {selectedCard ? (
                <DutyDetailPanel
                  card={selectedCard}
                  sectionCode={selectedSection ?? ''}
                  sectionColor={selectedData.color}
                  sectionBgColor={selectedData.bgColor}
                  onAssign={handleAssignPerson}
                  onUnassign={handleUnassignPerson}
                  onAddSubDuty={handleAddSubDuty}
                  onDeleteDutyType={handleDeleteDutyType}
                  onDeleteSubDuty={handleDeleteSubDuty}
                />
              ) : (
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', opacity: 0.5 }}>
                  <Stack alignItems="center" spacing={1}>
                    <ArrowBackIcon sx={{ fontSize: 40, color: 'text.disabled' }} />
                    <Typography variant="body2" color="text.secondary">
                      Select a duty type from the left panel
                    </Typography>
                  </Stack>
                </Box>
              )}
            </Box>
          </Box>
            )}

            {/* TAB 1: Leave Management */}
            {activeTab === 1 && (
              <LeaveManagementPanel
                sectionCode={selectedSection ?? ''}
                sectionColor={selectedData.color}
                sectionBgColor={selectedData.bgColor}
                onAssign={handleAssignPerson}
                onUnassign={handleUnassignPerson}
                chartData={chartData}
                onRefresh={() => selectedSection && loadChartData(selectedSection, false)}
                selectedCategory={selectedLeaveCategory}
                onCategoryChange={setSelectedLeaveCategory}
              />
            )}
          </>
        ) : (
          <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', py: 8, gap: 2 }}>
            <BadgeIcon sx={{ fontSize: 56, color: 'text.disabled' }} />
            <Typography variant="h6" color="text.secondary" fontWeight={600}>
              Select a section to view duty chart
            </Typography>
            <Typography variant="body2" color="text.disabled">
              Choose a section from the carousel above to view and edit duty assignments
            </Typography>
          </Box>
        )}
      </Box>

      {/* Saving overlay */}
      {saving && (
        <Box sx={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, bgcolor: 'rgba(0,0,0,0.08)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <CircularProgress />
        </Box>
      )}

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialog.open} onClose={() => setDeleteDialog((d) => ({ ...d, open: false }))}>
        <DialogTitle>Confirm Delete</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to delete &quot;{deleteDialog.name}&quot;?
            {deleteDialog.type === 'dutyType' && ' All personnel assignments under this duty will be cleared.'}
            {deleteDialog.type === 'subDuty' && ' Personnel under this sub-duty will have their location cleared.'}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialog((d) => ({ ...d, open: false }))}>Cancel</Button>
          <Button onClick={confirmDelete} color="error" variant="contained">Delete</Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={3000}
        onClose={() => setSnackbar((s) => ({ ...s, open: false }))}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert severity={snackbar.severity} variant="filled" sx={{ width: '100%' }}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

// ===== Duty Detail Panel (Right Side) =====
interface DutyDetailPanelProps {
  card: DutyCard;
  sectionCode: string;
  sectionColor: string;
  sectionBgColor: string;
  onAssign: (personnelId: number, dutyTypeId: number, subDuty?: string | null) => void;
  onUnassign: (personnelId: number) => void;
  onAddSubDuty: (parentDutyTypeId: number, subDutyName: string) => void;
  onDeleteDutyType: (dutyTypeId: number, name: string) => void;
  onDeleteSubDuty: (dutyTypeId: number, subDutyName: string) => void;
}

const DutyDetailPanel: React.FC<DutyDetailPanelProps> = ({
  card, sectionCode, sectionColor, sectionBgColor, onAssign, onUnassign, onAddSubDuty, onDeleteDutyType, onDeleteSubDuty,
}) => {
  const [showAddSubDuty, setShowAddSubDuty] = useState(false);
  const [newSubDutyName, setNewSubDutyName] = useState('');

  const handleAddSubDutySubmit = () => {
    if (newSubDutyName.trim()) {
      onAddSubDuty(card.dutyTypeId, newSubDutyName);
      setNewSubDutyName('');
      setShowAddSubDuty(false);
    }
  };

  return (
    <Paper
      elevation={0}
      sx={{
        border: '1px solid',
        borderColor: 'divider',
        borderRadius: '12px',
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      {/* Header */}
      <Box sx={{ px: 3, py: 2, bgcolor: sectionBgColor, borderBottom: '1px solid', borderColor: 'divider' }}>
        <Stack direction="row" spacing={1.5} alignItems="center" justifyContent="space-between">
          <Stack direction="row" spacing={1.5} alignItems="center">
            <Typography variant="h6" sx={{ fontWeight: 700, color: sectionColor, textTransform: 'uppercase', letterSpacing: '0.5px' }}>
              {card.dutyTypeName}
            </Typography>
            <Chip
              label={`${card.personnelCount} personnel`}
              size="small"
              sx={{ fontWeight: 600, bgcolor: `${sectionColor}15`, color: sectionColor }}
            />
          </Stack>
          <Tooltip title="Delete this duty type">
            <Button size="small" color="error" startIcon={<DeleteOutlineIcon fontSize="small" />} onClick={() => onDeleteDutyType(card.dutyTypeId, card.dutyTypeName)}>
              Delete
            </Button>
          </Tooltip>
        </Stack>
      </Box>

      {/* Content - Scrollable */}
      <Box sx={{ flex: 1, overflowY: 'auto', p: 3 }}>
        {/* Sub Duties */}
        {card.subDuties.length > 0 && (
          <Stack spacing={2.5}>
            {card.subDuties.map((subDuty) => (
              <SubDutySection
                key={subDuty.subDutyName}
                subDuty={subDuty}
                dutyTypeId={card.dutyTypeId}
                sectionColor={sectionColor}
                onAssign={(personnelId) => onAssign(personnelId, card.dutyTypeId, subDuty.subDutyName)}
                onUnassign={onUnassign}
                onDeleteSubDuty={() => onDeleteSubDuty(card.dutyTypeId, subDuty.subDutyName)}
              />
            ))}
          </Stack>
        )}

        {/* Personnel without sub-duty (direct assignment to parent) */}
        {card.personnel.length > 0 && (
          <Box sx={{ mt: card.subDuties.length > 0 ? 3 : 0 }}>
            {card.subDuties.length > 0 && (
              <Typography variant="caption" sx={{ fontWeight: 600, color: 'text.secondary', mb: 1, display: 'block', textTransform: 'uppercase' }}>
                Direct Assignment (No Sub Duty)
              </Typography>
            )}
            <PersonnelList
              personnel={card.personnel}
              dutyTypeId={card.dutyTypeId}
              subDuty={null}
              onAssign={(personnelId) => onAssign(personnelId, card.dutyTypeId, null)}
              onUnassign={onUnassign}
            />
          </Box>
        )}

        {/* If no sub-duties and no personnel, show the add person area */}
        {card.subDuties.length === 0 && card.personnel.length === 0 && (
          <Box sx={{ py: 2 }}>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
              No personnel assigned to this duty yet.
            </Typography>
            <PersonnelList
              personnel={[]}
              dutyTypeId={card.dutyTypeId}
              subDuty={null}
              onAssign={(personnelId) => onAssign(personnelId, card.dutyTypeId, null)}
              onUnassign={onUnassign}
            />
          </Box>
        )}

        {/* Add Sub Duty */}
        <Box sx={{ mt: 3, pt: 2, borderTop: '1px dashed', borderColor: 'divider' }}>
          {showAddSubDuty ? (
            <Stack direction="row" spacing={1} alignItems="center">
              <TextField
                size="small"
                placeholder="Sub duty name (e.g. COMMISSIONER OFFICE)..."
                value={newSubDutyName}
                onChange={(e) => setNewSubDutyName(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') handleAddSubDutySubmit(); }}
                sx={{ flex: 1, maxWidth: 400 }}
                autoFocus
              />
              <Button size="small" variant="contained" onClick={handleAddSubDutySubmit} disabled={!newSubDutyName.trim()}>
                Add
              </Button>
              <Button size="small" onClick={() => { setShowAddSubDuty(false); setNewSubDutyName(''); }}>
                Cancel
              </Button>
            </Stack>
          ) : (
            <Button
              size="small"
              startIcon={<AddCircleOutlineIcon />}
              onClick={() => setShowAddSubDuty(true)}
              sx={{ textTransform: 'none' }}
            >
              Add Sub Duty (Location)
            </Button>
          )}
        </Box>
      </Box>
    </Paper>
  );
};

// ===== Sub Duty Section =====
interface SubDutySectionProps {
  subDuty: SubDutyGroup;
  dutyTypeId: number;
  sectionColor: string;
  onAssign: (personnelId: number) => void;
  onUnassign: (personnelId: number) => void;
  onDeleteSubDuty: () => void;
}

const SubDutySection: React.FC<SubDutySectionProps> = ({ subDuty, dutyTypeId, sectionColor, onAssign, onUnassign, onDeleteSubDuty }) => {
  return (
    <Box
      sx={{
        pl: 2,
        borderLeft: `3px solid ${sectionColor}40`,
        borderRadius: '0 8px 8px 0',
      }}
    >
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1 }}>
        <Typography variant="body2" sx={{ fontWeight: 700, color: 'text.primary', textTransform: 'uppercase', flex: 1 }}>
          {subDuty.subDutyName}
        </Typography>
        <Chip
          label={subDuty.personnelCount}
          size="small"
          sx={{ height: 18, fontSize: '0.65rem', fontWeight: 600 }}
        />
        <Tooltip title="Delete this sub duty">
          <Button size="small" color="error" startIcon={<DeleteOutlineIcon sx={{ fontSize: 14 }} />} onClick={onDeleteSubDuty} sx={{ fontSize: '0.65rem', minWidth: 'auto', px: 0.5, py: 0 }}>
            Delete
          </Button>
        </Tooltip>
      </Stack>
      <PersonnelList
        personnel={subDuty.personnel}
        dutyTypeId={dutyTypeId}
        subDuty={subDuty.subDutyName}
        onAssign={onAssign}
        onUnassign={onUnassign}
      />
    </Box>
  );
};

// ===== Personnel List with Add Person =====
interface PersonnelListProps {
  personnel: ChartPersonnel[];
  dutyTypeId: number;
  subDuty: string | null;
  onAssign: (personnelId: number) => void;
  onUnassign: (personnelId: number) => void;
}

const PersonnelList: React.FC<PersonnelListProps> = ({ personnel, dutyTypeId, subDuty, onAssign, onUnassign }) => {
  const [showSearch, setShowSearch] = useState(false);

  return (
    <Box>
      {/* Personnel Rows */}
      <Stack spacing={0.5}>
        {personnel.map((person) => (
          <PersonnelRow key={person.id} person={person} onRemove={() => onUnassign(person.id)} />
        ))}
      </Stack>

      {/* Add Person */}
      {showSearch ? (
        <Box sx={{ mt: 1 }}>
          <PersonnelAutocomplete
            onSelect={(personnelId) => {
              onAssign(personnelId);
              setShowSearch(false);
            }}
            onCancel={() => setShowSearch(false)}
          />
        </Box>
      ) : (
        <Button
          size="small"
          startIcon={<PersonAddIcon />}
          onClick={() => setShowSearch(true)}
          sx={{ mt: 0.75, textTransform: 'none', fontSize: '0.75rem' }}
        >
          Add Person
        </Button>
      )}
    </Box>
  );
};

// ===== Personnel Row =====
interface PersonnelRowProps {
  person: ChartPersonnel;
  onRemove: () => void;
}

const PersonnelRow: React.FC<PersonnelRowProps> = ({ person, onRemove }) => {
  return (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        px: 1.5,
        py: 0.6,
        borderRadius: '8px',
        bgcolor: 'grey.50',
        border: '1px solid',
        borderColor: 'grey.200',
        transition: 'all 0.15s',
        '&:hover': { bgcolor: 'grey.100', borderColor: 'grey.300', '& .remove-btn': { opacity: 1 } },
      }}
    >
      <Stack direction="row" spacing={1} alignItems="center" sx={{ minWidth: 0, flex: 1 }}>
        <Typography
          variant="body2"
          sx={{ fontWeight: 700, color: 'primary.main', whiteSpace: 'nowrap', fontSize: '0.78rem', minWidth: 70 }}
        >
          {person.badgeId || '—'}
        </Typography>
        <Typography
          variant="body2"
          sx={{ color: 'text.primary', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: '0.78rem' }}
        >
          {person.personName}
        </Typography>
        {person.designation && (
          <Chip
            label={person.designation}
            size="small"
            sx={{ height: 18, fontSize: '0.6rem', fontWeight: 600, bgcolor: 'grey.200' }}
          />
        )}
      </Stack>
      <Tooltip title="Remove from this duty">
        <IconButton
          size="small"
          className="remove-btn"
          onClick={(e) => { e.stopPropagation(); onRemove(); }}
          sx={{ opacity: 0.3, transition: 'opacity 0.2s', p: 0.3 }}
        >
          <DeleteOutlineIcon sx={{ fontSize: 16, color: 'error.main' }} />
        </IconButton>
      </Tooltip>
    </Box>
  );
};

// ===== Personnel Autocomplete =====
interface PersonnelAutocompleteProps {
  onSelect: (personnelId: number) => void;
  onCancel: () => void;
}

const PersonnelAutocomplete: React.FC<PersonnelAutocompleteProps> = ({ onSelect, onCancel }) => {
  const [options, setOptions] = useState<PersonnelSearchResult[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [loading, setLoading] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const searchPersonnel = useCallback(async (query: string) => {
    if (query.length < 2) {
      setOptions([]);
      return;
    }
    setLoading(true);
    try {
      const results = await sectionChartService.searchPersonnel(query, 10);
      setOptions(results);
    } catch {
      setOptions([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const handleInputChange = (_event: React.SyntheticEvent, value: string) => {
    setInputValue(value);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => searchPersonnel(value), 250);
  };

  return (
    <Stack direction="row" spacing={0.5} alignItems="flex-start">
      <Autocomplete
        size="small"
        fullWidth
        disablePortal={false}
        options={options}
        loading={loading}
        inputValue={inputValue}
        onInputChange={handleInputChange}
        getOptionLabel={(option) => `${option.badgeId || ''} ${option.personName}`}
        isOptionEqualToValue={(option, value) => option.id === value.id}
        onChange={(_e, value) => {
          if (value) onSelect(value.id);
        }}
        renderOption={(props, option) => (
          <li {...props} key={option.id}>
            <Stack direction="row" spacing={1} alignItems="center" sx={{ width: '100%' }}>
              <Typography variant="caption" sx={{ fontWeight: 700, color: 'primary.main', minWidth: 75 }}>
                {option.badgeId || '—'}
              </Typography>
              <Typography variant="body2" sx={{ flex: 1 }}>
                {option.personName}
              </Typography>
              {option.designation && (
                <Chip label={option.designation} size="small" sx={{ height: 18, fontSize: '0.6rem' }} />
              )}
            </Stack>
          </li>
        )}
        renderInput={(params) => (
          <TextField
            {...params}
            placeholder="Search by badge ID or name..."
            autoFocus
            InputProps={{
              ...params.InputProps,
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon fontSize="small" color="action" />
                </InputAdornment>
              ),
            }}
          />
        )}
        noOptionsText={inputValue.length < 2 ? 'Type at least 2 characters...' : 'No personnel found'}
        sx={{ flex: 1 }}
        slotProps={{
          popper: {
            sx: { zIndex: 1500 },
            placement: 'bottom-start' as const,
          },
        }}
      />
      <Button size="small" onClick={onCancel} sx={{ minWidth: 'auto', px: 1, mt: 0.5 }}>
        ✕
      </Button>
    </Stack>
  );
};

// ===== Leave Management Panel (Two-card layout matching Duty Management) =====
interface LeaveManagementPanelProps {
  sectionCode: string;
  sectionColor: string;
  sectionBgColor: string;
  onAssign: (personnelId: number, dutyTypeId: number, subDuty?: string | null) => void;
  onUnassign: (personnelId: number) => void;
  chartData: SectionChartData;
  onRefresh: () => void;
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
}

const LeaveManagementPanel: React.FC<LeaveManagementPanelProps> = ({
  sectionCode, sectionColor, sectionBgColor, onAssign, onUnassign, chartData, onRefresh,
  selectedCategory, onCategoryChange,
}) => {
  const [showAddCategory, setShowAddCategory] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [customCategories, setCustomCategories] = useState<{ name: string; description: string }[]>([]);

  // Find the "LEAVE" duty card from chart data (if it exists)
  const leaveCard = chartData.dutyCards.find(
    (c) => c.dutyTypeName.toUpperCase() === 'LEAVE'
  );

  // Build all categories (default + custom from sub-duties in chart data)
  const allCategories = useMemo(() => {
    const cats = [...LEAVE_CATEGORIES, ...customCategories];
    // Also add any sub-duty names from the LEAVE card that aren't in the defaults
    if (leaveCard) {
      leaveCard.subDuties.forEach((sd) => {
        const exists = cats.find((c) => c.name.toUpperCase() === sd.subDutyName.toUpperCase());
        if (!exists) {
          cats.push({ name: sd.subDutyName, description: 'Custom leave type' });
        }
      });
    }
    return cats;
  }, [leaveCard, customCategories]);

  // Group personnel by leave category
  const leaveGroups: Record<string, ChartPersonnel[]> = {};
  allCategories.forEach((cat) => { leaveGroups[cat.name] = []; });

  if (leaveCard) {
    // Personnel directly on the LEAVE card (no sub-duty)
    leaveCard.personnel.forEach((p) => {
      leaveGroups[LEAVE_CATEGORIES[0].name]?.push(p);
    });
    // Personnel in sub-duties
    leaveCard.subDuties.forEach((sd) => {
      const matchedCat = allCategories.find(
        (cat) => cat.name.toUpperCase() === sd.subDutyName.toUpperCase().trim()
      );
      if (matchedCat) {
        sd.personnel.forEach((p) => {
          if (!leaveGroups[matchedCat.name]) leaveGroups[matchedCat.name] = [];
          leaveGroups[matchedCat.name].push(p);
        });
      } else {
        sd.personnel.forEach((p) => leaveGroups[LEAVE_CATEGORIES[0].name]?.push(p));
      }
    });
  }

  const totalLeavePersonnel = Object.values(leaveGroups).reduce((sum, arr) => sum + arr.length, 0);
  const selectedCategoryData = allCategories.find((c) => c.name === selectedCategory);
  const selectedPersonnel = leaveGroups[selectedCategory] || [];

  const handleAddCategory = () => {
    if (newCategoryName.trim()) {
      setCustomCategories((prev) => [...prev, { name: newCategoryName.trim().toUpperCase(), description: 'Custom leave type' }]);
      onCategoryChange(newCategoryName.trim().toUpperCase());
      setNewCategoryName('');
      setShowAddCategory(false);
    }
  };

  return (
    <Box sx={{ display: 'flex', gap: 2, alignItems: 'flex-start' }}>
      {/* LEFT SIDEBAR: Leave Categories */}
      <Paper
        elevation={0}
        sx={{
          width: { xs: 200, sm: 240, md: 280 },
          flexShrink: 0,
          border: '1px solid',
          borderColor: 'divider',
          borderRadius: '12px',
          display: 'flex',
          flexDirection: 'column',
          position: 'sticky',
          top: 16,
        }}
      >
        {/* Sidebar Header */}
        <Box sx={{ px: 2, py: 1.5, bgcolor: sectionBgColor, borderBottom: '1px solid', borderColor: 'divider' }}>
          <Typography variant="subtitle2" sx={{ fontWeight: 700, color: sectionColor }}>
            Leave Types
          </Typography>
          <Typography variant="caption" color="text.secondary">
            {allCategories.length} types • {totalLeavePersonnel} personnel
          </Typography>
        </Box>

        {/* Leave Category List */}
        <Box>
          <List dense disablePadding>
            {allCategories.map((cat) => {
              const count = leaveGroups[cat.name]?.length || 0;
              return (
                <ListItemButton
                  key={cat.name}
                  selected={selectedCategory === cat.name}
                  onClick={() => onCategoryChange(cat.name)}
                  sx={{
                    px: 2, py: 1,
                    borderLeft: selectedCategory === cat.name ? `3px solid ${sectionColor}` : '3px solid transparent',
                    '&.Mui-selected': { bgcolor: `${sectionColor}08` },
                    '&.Mui-selected:hover': { bgcolor: `${sectionColor}12` },
                  }}
                >
                  <ListItemText
                    primary={
                      <Stack direction="row" spacing={0.5} alignItems="center">
                        <Typography
                          variant="caption"
                          sx={{
                            fontWeight: selectedCategory === cat.name ? 700 : 500,
                            fontSize: '0.7rem',
                            textTransform: 'uppercase',
                            letterSpacing: '0.3px',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap',
                            flex: 1,
                          }}
                        >
                          {cat.name}
                        </Typography>
                        <Chip
                          label={count}
                          size="small"
                          sx={{
                            height: 18, fontSize: '0.6rem', fontWeight: 700,
                            bgcolor: count > 0 ? `${sectionColor}15` : 'grey.100',
                            color: count > 0 ? sectionColor : 'text.disabled',
                          }}
                        />
                      </Stack>
                    }
                  />
                </ListItemButton>
              );
            })}
          </List>
        </Box>

        {/* Add Custom Leave Type */}
        <Box sx={{ borderTop: '1px solid', borderColor: 'divider', p: 1.5 }}>
          {showAddCategory ? (
            <Stack spacing={1}>
              <TextField
                size="small"
                fullWidth
                placeholder="New leave type..."
                value={newCategoryName}
                onChange={(e) => setNewCategoryName(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') handleAddCategory(); }}
                autoFocus
                InputProps={{ sx: { fontSize: '0.8rem' } }}
              />
              <Stack direction="row" spacing={0.5}>
                <Button size="small" variant="contained" onClick={handleAddCategory} disabled={!newCategoryName.trim()} sx={{ fontSize: '0.7rem' }}>
                  Create
                </Button>
                <Button size="small" onClick={() => { setShowAddCategory(false); setNewCategoryName(''); }} sx={{ fontSize: '0.7rem' }}>
                  Cancel
                </Button>
              </Stack>
            </Stack>
          ) : (
            <Button
              fullWidth
              size="small"
              startIcon={<AddCircleOutlineIcon />}
              onClick={() => setShowAddCategory(true)}
              sx={{ textTransform: 'none', fontSize: '0.75rem' }}
            >
              Add Leave Type
            </Button>
          )}
        </Box>
      </Paper>

      {/* RIGHT: Detail Panel for selected leave category */}
      <Box sx={{ flex: 1, minWidth: 0, alignSelf: 'stretch' }}>
        {selectedCategoryData ? (
          <LeaveDetailPanel
            category={selectedCategoryData}
            personnel={selectedPersonnel}
            sectionCode={sectionCode}
            sectionColor={sectionColor}
            sectionBgColor={sectionBgColor}
            leaveCard={leaveCard}
            onRefresh={onRefresh}
          />
        ) : (
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', opacity: 0.5 }}>
            <Typography variant="body2" color="text.secondary">
              Select a leave type from the left panel
            </Typography>
          </Box>
        )}
      </Box>
    </Box>
  );
};

// ===== Leave Detail Panel (Right Side) =====
interface LeaveDetailPanelProps {
  category: { name: string; description: string };
  personnel: ChartPersonnel[];
  sectionCode: string;
  sectionColor: string;
  sectionBgColor: string;
  leaveCard?: DutyCard;
  onRefresh: () => void;
}

const LeaveDetailPanel: React.FC<LeaveDetailPanelProps> = ({
  category, personnel, sectionCode, sectionColor, sectionBgColor, leaveCard, onRefresh,
}) => {
  const [showSearch, setShowSearch] = useState(false);
  const [saving, setSaving] = useState(false);

  const handleAddPerson = async (personnelId: number) => {
    setSaving(true);
    try {
      let dutyTypeId = leaveCard?.dutyTypeId;

      // If there's no LEAVE duty type for this section, create it first
      if (!dutyTypeId) {
        const created = await sectionChartService.createDutyType({
          name: 'LEAVE',
          section: sectionCode,
          sortOrder: 99,
          level: 'PARENT',
        });
        dutyTypeId = created?.id;
        if (!dutyTypeId) {
          onRefresh();
          setShowSearch(false);
          setSaving(false);
          return;
        }
      }

      await sectionChartService.assign({
        personnelId,
        dutyTypeId,
        sectionCode,
        subDuty: category.name,
      });
      onRefresh();
      setShowSearch(false);
    } catch {
      // Error
    } finally {
      setSaving(false);
    }
  };

  const handleRemovePerson = async (personnelId: number) => {
    setSaving(true);
    try {
      await sectionChartService.unassign({ personnelId });
      onRefresh();
    } catch {
      // Error
    } finally {
      setSaving(false);
    }
  };

  return (
    <Paper
      elevation={0}
      sx={{ border: '1px solid', borderColor: 'divider', borderRadius: '12px', height: '100%', display: 'flex', flexDirection: 'column' }}
    >
      {/* Header */}
      <Box sx={{ px: 3, py: 2, bgcolor: sectionBgColor, borderBottom: '1px solid', borderColor: 'divider' }}>
        <Stack direction="row" spacing={1.5} alignItems="center">
          <Typography variant="h6" sx={{ fontWeight: 700, color: sectionColor, textTransform: 'uppercase', letterSpacing: '0.5px' }}>
            {category.name}
          </Typography>
          <Chip
            label={`${personnel.length} personnel`}
            size="small"
            sx={{ fontWeight: 600, bgcolor: `${sectionColor}15`, color: sectionColor }}
          />
        </Stack>
        <Typography variant="caption" color="text.secondary">
          {category.description}
        </Typography>
      </Box>

      {/* Personnel List */}
      <Box sx={{ flex: 1, overflowY: 'auto', p: 3 }}>
        {personnel.length > 0 ? (
          <Stack spacing={0.5}>
            {personnel.map((person) => (
              <Stack
                key={person.id}
                direction="row"
                alignItems="center"
                spacing={1.5}
                sx={{
                  py: 1, px: 1.5,
                  borderRadius: '8px',
                  border: '1px solid',
                  borderColor: 'divider',
                  '&:hover': { bgcolor: 'grey.50', borderColor: sectionColor },
                }}
              >
                <Typography
                  variant="body2"
                  sx={{ fontWeight: 700, color: 'primary.main', whiteSpace: 'nowrap', fontSize: '0.78rem', minWidth: 80 }}
                >
                  {person.badgeId || '—'}
                </Typography>
                <Typography variant="body2" sx={{ flex: 1, fontSize: '0.82rem' }}>
                  {person.personName}
                </Typography>
                {person.designation && (
                  <Chip label={person.designation} size="small" sx={{ height: 20, fontSize: '0.6rem' }} />
                )}
                <Tooltip title="Remove from leave">
                  <IconButton
                    size="small"
                    onClick={() => handleRemovePerson(person.id)}
                    disabled={saving}
                    sx={{ opacity: 0.4, '&:hover': { opacity: 1 } }}
                  >
                    <DeleteOutlineIcon sx={{ fontSize: 16, color: 'error.main' }} />
                  </IconButton>
                </Tooltip>
              </Stack>
            ))}
          </Stack>
        ) : (
          <Typography variant="body2" color="text.secondary" sx={{ py: 2 }}>
            No personnel assigned to this leave type.
          </Typography>
        )}

        {/* Add Person */}
        <Box sx={{ mt: 2, pt: 2, borderTop: '1px dashed', borderColor: 'divider' }}>
          {showSearch ? (
            <PersonnelAutocomplete
              onSelect={(personnelId) => handleAddPerson(personnelId)}
              onCancel={() => setShowSearch(false)}
            />
          ) : (
            <Button
              size="small"
              startIcon={<PersonAddIcon sx={{ fontSize: 16 }} />}
              onClick={() => setShowSearch(true)}
              sx={{ textTransform: 'none', color: sectionColor }}
            >
              Add Person
            </Button>
          )}
        </Box>
      </Box>
    </Paper>
  );
};

export default AssignDutiesPage;

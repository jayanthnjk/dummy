package com.policescheduler.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Entity representing a daily duty history snapshot for a personnel.
 * This table stores the duty status of each person at the end of each day,
 * enabling historical queries like "where did person X work from March to November?"
 */
@Entity
@Table(name = "duty_history")
public class DutyHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "person_id", nullable = false)
    private Long personId;

    @Column(name = "badge_id", length = 50)
    private String badgeId;

    @Column(name = "person_name", nullable = false, length = 200)
    private String personName;

    @Column(length = 100)
    private String designation;

    @Column(name = "record_date", nullable = false)
    private LocalDate recordDate;

    @Column(length = 100)
    private String section;

    @Column(name = "duty_type", length = 200)
    private String dutyType;

    @Column(name = "duty_location", length = 200)
    private String dutyLocation;

    @Column(name = "works_at", length = 200)
    private String worksAt;  // location column value

    @Column(name = "adhoc_duty", length = 300)
    private String adhocDuty;  // adhoc duty name if any

    @Column(name = "leave_type", length = 50)
    private String leaveType;  // leave type if on leave

    @Column(name = "shift_type", length = 20)
    private String shiftType;  // DAY/NIGHT

    @Column(length = 50)
    private String status;  // ACTIVE, ON_LEAVE, ADHOC, etc.

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    // Getters and Setters

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getPersonId() { return personId; }
    public void setPersonId(Long personId) { this.personId = personId; }

    public String getBadgeId() { return badgeId; }
    public void setBadgeId(String badgeId) { this.badgeId = badgeId; }

    public String getPersonName() { return personName; }
    public void setPersonName(String personName) { this.personName = personName; }

    public String getDesignation() { return designation; }
    public void setDesignation(String designation) { this.designation = designation; }

    public LocalDate getRecordDate() { return recordDate; }
    public void setRecordDate(LocalDate recordDate) { this.recordDate = recordDate; }

    public String getSection() { return section; }
    public void setSection(String section) { this.section = section; }

    public String getDutyType() { return dutyType; }
    public void setDutyType(String dutyType) { this.dutyType = dutyType; }

    public String getDutyLocation() { return dutyLocation; }
    public void setDutyLocation(String dutyLocation) { this.dutyLocation = dutyLocation; }

    public String getWorksAt() { return worksAt; }
    public void setWorksAt(String worksAt) { this.worksAt = worksAt; }

    public String getAdhocDuty() { return adhocDuty; }
    public void setAdhocDuty(String adhocDuty) { this.adhocDuty = adhocDuty; }

    public String getLeaveType() { return leaveType; }
    public void setLeaveType(String leaveType) { this.leaveType = leaveType; }

    public String getShiftType() { return shiftType; }
    public void setShiftType(String shiftType) { this.shiftType = shiftType; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}

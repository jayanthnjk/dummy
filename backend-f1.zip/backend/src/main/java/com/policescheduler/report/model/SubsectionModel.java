package com.policescheduler.report.model;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class SubsectionModel {
    private String name; // "CAR HQ", "CHAMBER SENTRY/ CP ESTATE", etc.
    private List<DutyRowModel> rows;
    private int[] total; // ACP, RPI, RSI, ARSI, AHC, APC, SWP, TOTAL (8 elements)
}

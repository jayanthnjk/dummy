import React, { useEffect, useState, useCallback, useMemo } from 'react';
import {
  Box, Typography, Alert, CircularProgress, Button, Chip, Stack,
  Dialog, DialogTitle, DialogContent, DialogActions, MenuItem, TextField,
  IconButton, Tooltip, Select, FormControl, InputLabel, Snackbar,
} from '@mui/material';
import CheckIcon from '@mui/icons-material/Check';
import CloseIcon from '@mui/icons-material/Close';
import CancelIcon from '@mui/icons-material/Cancel';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import EventBusyIcon from '@mui/icons-material/EventBusy';
import AddIcon from '@mui/icons-material/Add';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import CelebrationIcon from '@mui/icons-material/Celebration';
import PeopleIcon from '@mui/icons-material/People';

import { useTranslation } from 'react-i18next';
import { useAuth } from '@/contexts/AuthContext';
import { leaveService } from '@/services/leaveService';
import { personnelService } from '@/services/personnelService';
import { reportService } from '@/services/reportService';
import DownloadButton from '@/components/DownloadButton';
import FormField from '@/components/FormField';
import api from '@/services/api';
import type { LeaveRequestDto, CreateLeaveRequest, LeaveType, PersonnelDto } from '@/types';

interface Holiday { id: number; name: string; date: string; type: string; description?: string; }

const LEAVE_TYPES: { value: LeaveType; label: string }[] = [
  { value: 'CASUAL_LEAVE', label: 'Casual Leave' },
  { value: 'SICK_LEAVE', label: 'Sick Leave' },
  { value: 'EARNED_LEAVE', label: 'Earned Leave' },
  { value: 'WEEKLY_OFF', label: 'Weekly Off' },
  { value: 'COMPENSATORY_OFF', label: 'Compensatory Off' },
];
const HOLIDAY_TYPES = ['NATIONAL', 'STATE', 'RESTRICTED', 'CUSTOM'];
const DAYS = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

function getDaysInMonth(y: number, m: number) { return new Date(y, m + 1, 0).getDate(); }
function getFirstDay(y: number, m: number) { return new Date(y, m, 1).getDay(); }
function fmt(d: Date) { return d.toISOString().split('T')[0]; }
function isFutureOrToday(s: string) { return s >= fmt(new Date()); }

const LeaveRequestsPage: React.FC = () => {
  const { t } = useTranslation();
  const { role } = useAuth();
  const [data, setData] = useState<LeaveRequestDto[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [toast, setToast] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [holidayDialogOpen, setHolidayDialogOpen] = useState(false);
  const [rejectDialogId, setRejectDialogId] = useState<number | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [saving, setSaving] = useState(false);
  const [personnelList, setPersonnelList] = useState<PersonnelDto[]>([]);
  const [holidays, setHolidays] = useState<Holiday[]>([]);
  const [holidayForm, setHolidayForm] = useState({ name: '', date: '', type: 'NATIONAL', description: '' });
  const [form, setForm] = useState<CreateLeaveRequest>({ personnelId: 0, leaveType: 'CASUAL_LEAVE', startDate: '', endDate: '', reason: '' });

  const today = new Date();
  const [calMonth, setCalMonth] = useState(today.getMonth());
  const [calYear, setCalYear] = useState(today.getFullYear());
  const [selectedDate, setSelectedDate] = useState<string>(fmt(today));
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [filterFrom, setFilterFrom] = useState('');
  const [filterTo, setFilterTo] = useState('');

  const canApprove = role === 'ADMIN' || role === 'HIGHER_OFFICER';
  const canManageHolidays = role === 'ADMIN' || role === 'HIGHER_OFFICER';

  const fetchData = useCallback(async () => {
    setLoading(true);
    try { const r = await leaveService.list(undefined, 0, 500); setData(r.content); } catch { setError('Failed to load'); } finally { setLoading(false); }
  }, []);

  const fetchHolidays = useCallback(async () => {
    try { const r = await api.get<Holiday[]>('/api/holidays', { params: { year: calYear, month: calMonth + 1 } }); setHolidays(r.data); } catch { /* ignore */ }
  }, [calYear, calMonth]);

  useEffect(() => { fetchData(); }, [fetchData]);
  useEffect(() => { fetchHolidays(); }, [fetchHolidays]);
  useEffect(() => { if (dialogOpen && personnelList.length === 0) personnelService.list(undefined, 0, 1000).then(r => setPersonnelList(r.content)).catch(() => {}); }, [dialogOpen, personnelList.length]);

  const handleSubmit = async () => {
    setSaving(true); setError('');
    try { await leaveService.submit(form); setDialogOpen(false); setForm({ personnelId: 0, leaveType: 'CASUAL_LEAVE', startDate: '', endDate: '', reason: '' }); setToast('Leave request submitted'); fetchData(); }
    catch (err: unknown) { const e = err as { response?: { status?: number } }; setError(e.response?.status === 409 ? 'Overlapping leave exists' : 'Failed to submit'); }
    finally { setSaving(false); }
  };
  const handleApprove = async (id: number) => { try { await leaveService.approve(id); setToast('Approved'); fetchData(); } catch { setError('Failed'); } };
  const handleReject = async () => { if (!rejectDialogId) return; try { await leaveService.reject(rejectDialogId, rejectReason); setRejectDialogId(null); setRejectReason(''); setToast('Rejected'); fetchData(); } catch { setError('Failed'); } };
  const handleCancel = async (id: number) => { try { await leaveService.cancel(id); setToast('Cancelled'); fetchData(); } catch { setError('Cannot cancel'); } };

  const handleAddHoliday = async () => {
    try { await api.post('/api/holidays', holidayForm); setHolidayDialogOpen(false); setHolidayForm({ name: '', date: '', type: 'NATIONAL', description: '' }); setToast(t('leave.holidayAdded', 'Holiday added')); fetchHolidays(); }
    catch { setError(t('leave.failedAddHoliday', 'Failed to add holiday')); }
  };
  const handleDeleteHoliday = async (id: number) => {
    try { await api.delete(`/api/holidays/${id}`); setToast('Holiday removed'); fetchHolidays(); } catch { setError('Failed'); }
  };

  // Filtered data
  const filteredData = useMemo(() => {
    let r = [...data];
    if (filterStatus !== 'ALL') r = r.filter(x => x.status === filterStatus);
    if (filterFrom) r = r.filter(x => x.endDate >= filterFrom);
    if (filterTo) r = r.filter(x => x.startDate <= filterTo);
    return r;
  }, [data, filterStatus, filterFrom, filterTo]);

  // Calendar helpers
  const leaveDays = useMemo(() => {
    const s = new Set<string>();
    data.forEach(r => { if (r.status === 'APPROVED' || r.status === 'PENDING') { const st = new Date(r.startDate + 'T00:00:00'); const en = new Date(r.endDate + 'T00:00:00'); for (let d = new Date(st); d <= en; d.setDate(d.getDate() + 1)) s.add(fmt(d)); } });
    return s;
  }, [data]);
  const holidayDates = useMemo(() => new Set(holidays.map(h => h.date)), [holidays]);
  const leavesOnDate = useMemo(() => data.filter(r => (r.status === 'APPROVED' || r.status === 'PENDING') && r.startDate <= selectedDate && r.endDate >= selectedDate), [data, selectedDate]);

  const daysInMonth = getDaysInMonth(calYear, calMonth);
  const firstDay = getFirstDay(calYear, calMonth);
  const prevMonth = () => { if (calMonth === 0) { setCalMonth(11); setCalYear(y => y - 1); } else setCalMonth(m => m - 1); };
  const nextMonth = () => { if (calMonth === 11) { setCalMonth(0); setCalYear(y => y + 1); } else setCalMonth(m => m + 1); };

  const statusChip = (status: string) => {
    const map: Record<string, { bg: string; color: string }> = { PENDING: { bg: '#fef3c7', color: '#92400e' }, APPROVED: { bg: '#d1fae5', color: '#065f46' }, REJECTED: { bg: '#fee2e2', color: '#991b1b' }, CANCELLED: { bg: '#f3f4f6', color: '#4b5563' } };
    const s = map[status] || { bg: '#f3f4f6', color: '#4b5563' };
    return <Box sx={{ display: 'inline-block', px: 1.2, py: 0.3, borderRadius: 1, fontSize: '0.68rem', fontWeight: 600, bgcolor: s.bg, color: s.color }}>{status}</Box>;
  };

  // Metrics based on filtered data
  const metrics = [
    { label: 'Total', count: filteredData.length, color: '#1a1e4a' },
    { label: 'Pending', count: filteredData.filter(r => r.status === 'PENDING').length, color: '#d97706' },
    { label: 'Approved', count: filteredData.filter(r => r.status === 'APPROVED').length, color: '#059669' },
    { label: 'Rejected', count: filteredData.filter(r => r.status === 'REJECTED').length, color: '#dc2626' },
    { label: 'Cancelled', count: filteredData.filter(r => r.status === 'CANCELLED').length, color: '#6b7280' },
  ];

  if (loading) return <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '60vh' }}><CircularProgress sx={{ color: '#1a1e4a' }} /></Box>;

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: 'calc(100vh - 52px)', bgcolor: '#fafaf8' }}>
      {/* Dark Navy Page Header */}
      <Box
        sx={{
          background: 'linear-gradient(135deg, #1a1e4a 0%, #2d3561 100%)',
          color: 'white',
          px: { xs: 2, md: 4 },
          pt: 2,
          pb: 1.5,
        }}
      >
        {/* Top row: Title + Actions */}
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
          <Box>
            <Typography variant="h5" fontWeight={700} sx={{ letterSpacing: '-0.02em' }}>
              {t('leave.title', 'Leave Management')}
            </Typography>
            <Typography variant="body2" sx={{ color: 'rgba(255,255,255,0.7)', mt: 0.5 }}>
              {t('leave.subtitle', 'Track leaves, holidays & attendance')}
            </Typography>
          </Box>
          <Stack direction="row" spacing={1}>
            <Button
              onClick={() => setDialogOpen(true)}
              sx={{
                backgroundColor: 'rgba(255,255,255,0.08)',
                backdropFilter: 'blur(8px)',
                border: '1px solid rgba(255,255,255,0.2)',
                color: 'white',
                textTransform: 'none',
                fontWeight: 600,
                fontSize: '0.82rem',
                borderRadius: 2,
                px: 2,
                '&:hover': { 
                  backgroundColor: 'rgba(255,255,255,0.15)',
                  borderColor: 'rgba(255,255,255,0.4)',
                },
              }}
            >
              {t('leave.applyLeave', 'Apply Leave')}
            </Button>
          </Stack>
        </Box>
      </Box>

      {/* Main Content */}
      <Box sx={{ flex: 1, p: { xs: 2, md: 3 } }}>

      {error && <Alert severity="error" sx={{ mb: 2, borderRadius: 2 }} onClose={() => setError('')}>{error}</Alert>}

      {/* Full-width Calendar Section: Calendar (left) + Holidays (right) */}
      <Box sx={{ display: 'flex', gap: 0, mb: 3, bgcolor: '#fff', borderRadius: 3, border: '1px solid #f0ede6', overflow: 'hidden', flexDirection: { xs: 'column', md: 'row' } }}>
        {/* Calendar */}
        <Box sx={{ flex: '0 0 auto', width: { xs: '100%', md: 380 }, p: 2.5, borderRight: { xs: 'none', md: '1px solid #f0ede6' }, borderBottom: { xs: '1px solid #f0ede6', md: 'none' } }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <IconButton size="small" onClick={prevMonth} sx={{ color: '#6b6b80' }}><ChevronLeftIcon fontSize="small" /></IconButton>
            <Typography sx={{ fontWeight: 700, fontSize: '0.95rem', color: '#1a1e4a' }}>{MONTHS[calMonth]} {calYear}</Typography>
            <IconButton size="small" onClick={nextMonth} sx={{ color: '#6b6b80' }}><ChevronRightIcon fontSize="small" /></IconButton>
          </Box>
          {/* Day headers */}
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', mb: 1 }}>
            {DAYS.map(d => <Typography key={d} align="center" sx={{ fontSize: '0.65rem', fontWeight: 700, color: '#c4a44a', textTransform: 'uppercase' }}>{d}</Typography>)}
          </Box>
          {/* Days grid */}
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: '3px' }}>
            {Array.from({ length: firstDay }).map((_, i) => <Box key={`e${i}`} sx={{ height: 38 }} />)}
            {Array.from({ length: daysInMonth }).map((_, i) => {
              const day = i + 1;
              const ds = `${calYear}-${String(calMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
              const isToday = ds === fmt(today);
              const isSel = ds === selectedDate;
              const hasLeave = leaveDays.has(ds);
              const isHoliday = holidayDates.has(ds);
              return (
                <Box key={day} onClick={() => setSelectedDate(ds)} sx={{
                  height: 38, width: 38, mx: 'auto', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  borderRadius: 2, cursor: 'pointer', position: 'relative', fontSize: '0.8rem',
                  fontWeight: isToday || isSel ? 700 : 400,
                  bgcolor: isSel ? '#1a1e4a' : isToday ? '#f0f0ff' : isHoliday ? '#fef3c7' : 'transparent',
                  color: isSel ? '#fff' : isToday ? '#1a1e4a' : isHoliday ? '#92400e' : '#374151',
                  transition: 'all 0.15s',
                  '&:hover': { bgcolor: isSel ? '#1a1e4a' : '#f5f3ee', transform: 'scale(1.08)' },
                }}>
                  {day}
                  {hasLeave && <Box sx={{ position: 'absolute', bottom: 3, left: '50%', ml: '-2px', width: 4, height: 4, borderRadius: '50%', bgcolor: isSel ? '#c4a44a' : '#ef4444' }} />}
                  {isHoliday && !hasLeave && <Box sx={{ position: 'absolute', bottom: 3, left: '50%', ml: '-2px', width: 4, height: 4, borderRadius: '50%', bgcolor: isSel ? '#c4a44a' : '#d97706' }} />}
                </Box>
              );
            })}
          </Box>
          {/* Legend */}
          <Box sx={{ display: 'flex', gap: 2, mt: 2, pt: 1.5, borderTop: '1px solid #f5f3ee' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}><Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: '#ef4444' }} /><Typography sx={{ fontSize: '0.65rem', color: '#6b6b80' }}>On Leave</Typography></Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}><Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: '#d97706' }} /><Typography sx={{ fontSize: '0.65rem', color: '#6b6b80' }}>Holiday</Typography></Box>
          </Box>
          {/* On Leave section */}
          {leavesOnDate.length > 0 && (
            <Box sx={{ mt: 2, pt: 1.5, borderTop: '1px solid #f5f3ee' }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.8, mb: 1 }}>
                <PeopleIcon sx={{ fontSize: 14, color: '#1a1e4a' }} />
                <Typography sx={{ fontSize: '0.72rem', fontWeight: 700, color: '#1a1e4a' }}>On Leave ({leavesOnDate.length})</Typography>
              </Box>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                {leavesOnDate.slice(0, 6).map(lr => (
                  <Chip key={lr.id} size="small" label={`${lr.badgeId}`} sx={{ height: 22, fontSize: '0.65rem', fontWeight: 600, bgcolor: '#fef3c7', color: '#92400e' }} />
                ))}
                {leavesOnDate.length > 6 && <Chip size="small" label={`+${leavesOnDate.length - 6}`} sx={{ height: 22, fontSize: '0.65rem', bgcolor: '#f3f4f6', color: '#6b7280' }} />}
              </Box>
            </Box>
          )}
        </Box>

        {/* Holidays Panel (right side) */}
        <Box sx={{ flex: 1, p: 2.5, display: 'flex', flexDirection: 'column' }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <CelebrationIcon sx={{ fontSize: 18, color: '#c4a44a' }} />
              <Typography sx={{ fontSize: '0.9rem', fontWeight: 700, color: '#1a1e4a' }}>{t('leave.holidays', 'Holidays')} — {MONTHS[calMonth]}</Typography>
            </Box>
            {canManageHolidays && (
              <Tooltip title={t('leave.addHoliday', 'Add Holiday')} arrow>
                <IconButton size="small" onClick={() => setHolidayDialogOpen(true)} sx={{ bgcolor: '#f0f0ff', '&:hover': { bgcolor: '#e0e0ff' } }}>
                  <AddIcon sx={{ fontSize: 16, color: '#1a1e4a' }} />
                </IconButton>
              </Tooltip>
            )}
          </Box>

          {holidays.length === 0 ? (
            <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', color: '#9ca3af' }}>
              <CelebrationIcon sx={{ fontSize: 32, color: '#e5e7eb', mb: 1 }} />
              <Typography sx={{ fontSize: '0.8rem' }}>{t('leave.noHolidaysThisMonth', 'No holidays this month')}</Typography>
              {canManageHolidays && <Typography sx={{ fontSize: '0.7rem', mt: 0.5 }}>{t('leave.clickToAdd', 'Click + to add one')}</Typography>}
            </Box>
          ) : (
            <Box sx={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 1 }}>
              {holidays.map(h => (
                <Box key={h.id} sx={{ display: 'flex', alignItems: 'center', gap: 1.5, p: 1.5, borderRadius: 2, bgcolor: '#fafaf8', border: '1px solid #f5f3ee', transition: 'all 0.15s', '&:hover': { borderColor: '#f0ede6', bgcolor: '#f5f3ee' } }}>
                  <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: '#fef3c7', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <Typography sx={{ fontSize: '0.9rem', fontWeight: 700, color: '#92400e', lineHeight: 1 }}>{new Date(h.date + 'T00:00:00').getDate()}</Typography>
                    <Typography sx={{ fontSize: '0.55rem', color: '#b45309', fontWeight: 600 }}>{DAYS[new Date(h.date + 'T00:00:00').getDay()]}</Typography>
                  </Box>
                  <Box sx={{ flex: 1, minWidth: 0 }}>
                    <Typography sx={{ fontSize: '0.78rem', fontWeight: 600, color: '#374151', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{h.name}</Typography>
                    <Typography sx={{ fontSize: '0.65rem', color: '#9ca3af' }}>{h.type}</Typography>
                  </Box>
                  {canManageHolidays && (
                    <IconButton size="small" onClick={() => handleDeleteHoliday(h.id)} sx={{ opacity: 0.5, '&:hover': { opacity: 1, color: '#dc2626' } }}>
                      <DeleteOutlineIcon sx={{ fontSize: 16 }} />
                    </IconButton>
                  )}
                </Box>
              ))}
            </Box>
          )}
        </Box>
      </Box>

      {/* Filters */}
      <Box sx={{ display: 'flex', gap: 1.5, mb: 2, flexWrap: 'wrap', alignItems: 'center' }}>
        <FormControl size="small" sx={{ minWidth: 120 }}>
          <InputLabel sx={{ fontSize: '0.78rem' }}>Status</InputLabel>
          <Select value={filterStatus} label="Status" onChange={e => setFilterStatus(e.target.value)} sx={{ fontSize: '0.78rem', borderRadius: 2, bgcolor: '#fff', '& fieldset': { borderColor: '#f0ede6' } }}>
            <MenuItem value="ALL">All</MenuItem>
            <MenuItem value="PENDING">Pending</MenuItem>
            <MenuItem value="APPROVED">Approved</MenuItem>
            <MenuItem value="REJECTED">Rejected</MenuItem>
            <MenuItem value="CANCELLED">Cancelled</MenuItem>
          </Select>
        </FormControl>
        <TextField size="small" type="date" label="From" value={filterFrom} onChange={e => setFilterFrom(e.target.value)} InputLabelProps={{ shrink: true }} sx={{ width: 150, '& .MuiOutlinedInput-root': { fontSize: '0.78rem', borderRadius: 2, bgcolor: '#fff', '& fieldset': { borderColor: '#f0ede6' } } }} />
        <TextField size="small" type="date" label="To" value={filterTo} onChange={e => setFilterTo(e.target.value)} InputLabelProps={{ shrink: true }} sx={{ width: 150, '& .MuiOutlinedInput-root': { fontSize: '0.78rem', borderRadius: 2, bgcolor: '#fff', '& fieldset': { borderColor: '#f0ede6' } } }} />
        {(filterStatus !== 'ALL' || filterFrom || filterTo) && (
          <Box onClick={() => { setFilterStatus('ALL'); setFilterFrom(''); setFilterTo(''); }} sx={{ px: 1.5, py: 0.6, cursor: 'pointer', borderRadius: 1.5, fontSize: '0.72rem', fontWeight: 500, color: '#dc2626', bgcolor: '#fef2f2', border: '1px solid #fecaca', '&:hover': { bgcolor: '#fee2e2' } }}>Clear</Box>
        )}
      </Box>

      {/* Metrics (synced with filtered data) */}
      <Box sx={{ display: 'flex', gap: 1.5, mb: 2, flexWrap: 'wrap' }}>
        {metrics.map(m => (
          <Box key={m.label} sx={{ display: 'flex', alignItems: 'center', gap: 1, px: 2, py: 1, bgcolor: '#fff', borderRadius: 2, border: '1px solid #f0ede6' }}>
            <Box sx={{ width: 3, height: 24, borderRadius: 1, bgcolor: m.color }} />
            <Typography sx={{ fontSize: '1.1rem', fontWeight: 700, color: m.color, lineHeight: 1 }}>{m.count}</Typography>
            <Typography sx={{ fontSize: '0.68rem', color: '#9ca3af', fontWeight: 500 }}>{m.label}</Typography>
          </Box>
        ))}
        <Typography sx={{ ml: 'auto', fontSize: '0.72rem', color: '#9ca3af', alignSelf: 'center' }}>{filteredData.length} requests</Typography>
      </Box>

      {/* Table */}
      <Box sx={{ bgcolor: '#fff', borderRadius: 3, border: '1px solid #f0ede6', overflow: 'hidden' }}>
        <Box sx={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                {['Badge ID', 'Person Name', 'Leave Type', 'Start', 'End', 'Reason', 'Status', 'Actions'].map((h, i) => (
                  <th key={h} style={{ padding: '14px 16px', textAlign: i >= 3 && i <= 4 ? 'center' : i >= 6 ? 'center' : 'left', fontWeight: 600, fontSize: '0.68rem', color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '0.05em', borderBottom: '1px solid #f0ede6', whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filteredData.length === 0 ? (
                <tr><td colSpan={8} style={{ padding: '48px 16px', textAlign: 'center', color: '#9ca3af', fontSize: '0.85rem' }}>
                  <EventBusyIcon sx={{ fontSize: 32, color: '#e5e7eb', mb: 1, display: 'block', mx: 'auto' }} />{t('leave.noLeaveRequests', 'No leave requests found')}
                </td></tr>
              ) : filteredData.map(row => (
                <tr key={row.id} style={{ borderBottom: '1px solid #f8f6f2', transition: 'background 0.15s' }}
                  onMouseEnter={e => (e.currentTarget.style.background = '#fafaf8')} onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                  <td style={{ padding: '12px 16px', fontSize: '0.8rem', fontWeight: 600, color: '#1a1e4a' }}>{row.badgeId}</td>
                  <td style={{ padding: '12px 16px', fontSize: '0.8rem', color: '#374151' }}>{row.personnelName}</td>
                  <td style={{ padding: '12px 16px', fontSize: '0.78rem', color: '#6b7280' }}>{row.leaveType.replace(/_/g, ' ')}</td>
                  <td style={{ padding: '12px 16px', fontSize: '0.78rem', color: '#374151', textAlign: 'center' }}>{row.startDate}</td>
                  <td style={{ padding: '12px 16px', fontSize: '0.78rem', color: '#374151', textAlign: 'center' }}>{row.endDate}</td>
                  <td style={{ padding: '12px 16px', fontSize: '0.75rem', color: '#9ca3af', maxWidth: 140, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{row.reason || '—'}</td>
                  <td style={{ padding: '12px 16px', textAlign: 'center' }}>{statusChip(row.status)}</td>
                  <td style={{ padding: '12px 16px', textAlign: 'center' }}>
                    <Box sx={{ display: 'inline-flex', gap: 0.3 }}>
                      {canApprove && row.status === 'PENDING' && (<>
                        <Tooltip title="Approve" arrow><IconButton size="small" onClick={() => handleApprove(row.id)} sx={{ width: 28, height: 28, bgcolor: '#d1fae5', '&:hover': { bgcolor: '#a7f3d0' } }}><CheckIcon sx={{ fontSize: 14, color: '#065f46' }} /></IconButton></Tooltip>
                        <Tooltip title="Reject" arrow><IconButton size="small" onClick={() => setRejectDialogId(row.id)} sx={{ width: 28, height: 28, bgcolor: '#fee2e2', '&:hover': { bgcolor: '#fecaca' } }}><CloseIcon sx={{ fontSize: 14, color: '#991b1b' }} /></IconButton></Tooltip>
                      </>)}
                      {(row.status === 'PENDING' || row.status === 'APPROVED') && isFutureOrToday(row.endDate) && (
                        <Tooltip title="Cancel" arrow><IconButton size="small" onClick={() => handleCancel(row.id)} sx={{ width: 28, height: 28, bgcolor: '#f3f4f6', '&:hover': { bgcolor: '#e5e7eb' } }}><CancelIcon sx={{ fontSize: 14, color: '#6b7280' }} /></IconButton></Tooltip>
                      )}
                    </Box>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Box>
      </Box>

      </Box>{/* End Main Content */}

      {/* Apply Leave Dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth PaperProps={{ sx: { borderRadius: 3 } }}>
        <Box sx={{ px: 3, pt: 3, pb: 1 }}><Typography sx={{ fontSize: '1.1rem', fontWeight: 700, color: '#1a1e4a' }}>{t('leave.applyForLeave', 'Apply for Leave')}</Typography><Typography sx={{ fontSize: '0.72rem', color: '#9ca3af' }}>{t('leave.fillDetails', 'Fill in the details below')}</Typography></Box>
        <DialogContent sx={{ px: 3 }}>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 1 }}>
            <FormField labelKey="personnel.personName" select required value={form.personnelId || ''} onChange={e => setForm(p => ({ ...p, personnelId: Number(e.target.value) }))}><MenuItem value="" disabled>Select Personnel</MenuItem>{personnelList.map(p => <MenuItem key={p.id} value={p.id}>{p.personName} ({p.badgeId})</MenuItem>)}</FormField>
            <FormField labelKey="leave.leaveType" select required value={form.leaveType} onChange={e => setForm(p => ({ ...p, leaveType: e.target.value as LeaveType }))}>{LEAVE_TYPES.map(lt => <MenuItem key={lt.value} value={lt.value}>{lt.label}</MenuItem>)}</FormField>
            <Box sx={{ display: 'flex', gap: 2 }}>
              <FormField labelKey="leave.startDate" type="date" required fullWidth value={form.startDate} onChange={e => setForm(p => ({ ...p, startDate: e.target.value }))} InputLabelProps={{ shrink: true }} />
              <FormField labelKey="leave.endDate" type="date" required fullWidth value={form.endDate} onChange={e => setForm(p => ({ ...p, endDate: e.target.value }))} InputLabelProps={{ shrink: true }} />
            </Box>
            <FormField labelKey="leave.reason" multiline rows={3} value={form.reason} onChange={e => setForm(p => ({ ...p, reason: e.target.value }))} />
          </Box>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2.5 }}>
          <Button onClick={() => setDialogOpen(false)} sx={{ textTransform: 'none', color: '#6b6b80' }}>{t('app.cancel', 'Cancel')}</Button>
          <Box onClick={!saving && form.personnelId && form.startDate && form.endDate ? handleSubmit : undefined} sx={{ px: 2.5, py: 0.9, borderRadius: 2, fontSize: '0.82rem', fontWeight: 600, bgcolor: !form.personnelId || !form.startDate || !form.endDate || saving ? '#e5e7eb' : '#1a1e4a', color: !form.personnelId || !form.startDate || !form.endDate || saving ? '#9ca3af' : '#fff', cursor: !form.personnelId || !form.startDate || !form.endDate || saving ? 'not-allowed' : 'pointer', transition: 'all 0.2s', '&:hover': { bgcolor: form.personnelId && form.startDate && form.endDate && !saving ? '#0b0e2a' : undefined } }}>
            {saving ? <CircularProgress size={16} sx={{ color: '#9ca3af' }} /> : t('leave.submitRequest', 'Submit Leave')}
          </Box>
        </DialogActions>
      </Dialog>

      {/* Reject Dialog */}
      <Dialog open={rejectDialogId != null} onClose={() => setRejectDialogId(null)} maxWidth="xs" fullWidth PaperProps={{ sx: { borderRadius: 3 } }}>
        <Box sx={{ px: 3, pt: 3, pb: 1 }}><Typography sx={{ fontSize: '1rem', fontWeight: 700, color: '#dc2626' }}>{t('leave.reject', 'Reject Leave')}</Typography></Box>
        <DialogContent sx={{ px: 3 }}><TextField label={t('leave.reason', 'Reason')} fullWidth multiline rows={3} size="small" value={rejectReason} onChange={e => setRejectReason(e.target.value)} sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }} /></DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}><Button onClick={() => setRejectDialogId(null)} sx={{ textTransform: 'none', color: '#6b6b80' }}>{t('app.cancel', 'Cancel')}</Button><Button variant="contained" color="error" onClick={handleReject} sx={{ textTransform: 'none', borderRadius: 2 }}>{t('leave.reject', 'Reject')}</Button></DialogActions>
      </Dialog>

      {/* Add Holiday Dialog */}
      <Dialog open={holidayDialogOpen} onClose={() => setHolidayDialogOpen(false)} maxWidth="xs" fullWidth PaperProps={{ sx: { borderRadius: 3 } }}>
        <Box sx={{ px: 3, pt: 3, pb: 1 }}><Typography sx={{ fontSize: '1rem', fontWeight: 700, color: '#1a1e4a' }}>{t('leave.addHoliday', 'Add Holiday')}</Typography></Box>
        <DialogContent sx={{ px: 3 }}>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 1 }}>
            <TextField size="small" label={t('leave.holidayName', 'Holiday Name')} required fullWidth value={holidayForm.name} onChange={e => setHolidayForm(p => ({ ...p, name: e.target.value }))} sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }} />
            <TextField size="small" label={t('leave.holidayDate', 'Date')} type="date" required fullWidth value={holidayForm.date} onChange={e => setHolidayForm(p => ({ ...p, date: e.target.value }))} InputLabelProps={{ shrink: true }} sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }} />
            <TextField size="small" label={t('leave.holidayType', 'Type')} select required fullWidth value={holidayForm.type} onChange={e => setHolidayForm(p => ({ ...p, type: e.target.value }))} sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }}>
              {HOLIDAY_TYPES.map(ht => <MenuItem key={ht} value={ht}>{ht}</MenuItem>)}
            </TextField>
            <TextField size="small" label={t('leave.holidayDescription', 'Description (optional)')} fullWidth multiline rows={2} value={holidayForm.description} onChange={e => setHolidayForm(p => ({ ...p, description: e.target.value }))} sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }} />
          </Box>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setHolidayDialogOpen(false)} sx={{ textTransform: 'none', color: '#6b6b80' }}>{t('app.cancel', 'Cancel')}</Button>
          <Box onClick={holidayForm.name && holidayForm.date ? handleAddHoliday : undefined} sx={{ px: 2.5, py: 0.9, borderRadius: 2, fontSize: '0.82rem', fontWeight: 600, bgcolor: holidayForm.name && holidayForm.date ? '#1a1e4a' : '#e5e7eb', color: holidayForm.name && holidayForm.date ? '#fff' : '#9ca3af', cursor: holidayForm.name && holidayForm.date ? 'pointer' : 'not-allowed', transition: 'all 0.2s', '&:hover': { bgcolor: holidayForm.name && holidayForm.date ? '#0b0e2a' : undefined } }}>
            {t('leave.addHoliday', 'Add Holiday')}
          </Box>
        </DialogActions>
      </Dialog>

      <Snackbar open={!!toast} autoHideDuration={3000} onClose={() => setToast('')} message={toast} anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }} />
    </Box>
  );
};

export default LeaveRequestsPage;

import React, { useEffect, useRef, useState } from 'react';
import { observer } from 'mobx-react-lite';
import { Box, Typography } from '@mui/material';
import {
  MapContainer,
  TileLayer,
  Marker,
  Circle,
  Popup,
  useMap,
  useMapEvents,
} from 'react-leaflet';
import type { DutyType } from '@/types/dutySections';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { useTranslation } from 'react-i18next';
import { dutySectionStore } from '@/stores/dutySectionStore';

// Fix Leaflet default marker icon path issue in bundled environments
import markerIcon2x from 'leaflet/dist/images/marker-icon-2x.png';
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';

delete (L.Icon.Default.prototype as unknown as Record<string, unknown>)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
});

// Karnataka center coordinates and default zoom
const KARNATAKA_CENTER: L.LatLngTuple = [15.3173, 75.7139];
const DEFAULT_ZOOM = 8;

/** Section color palette */
const SECTION_COLORS: Record<string, string> = {
  A: '#3B82F6',
  B: '#10B981',
  C: '#8B5CF6',
  D: '#F97316',
  E: '#06B6D4',
  F: '#EC4899',
  G: '#EF4444',
};

function getSectionColor(sectionCode: string): string {
  const key = sectionCode.charAt(0).toUpperCase();
  return SECTION_COLORS[key] || '#6B7280';
}

/** Section icon map — Unicode icons per section type */
const SECTION_ICONS: Record<string, string> = {
  A: '🏛️',
  B: '🏢',
  C: '⚡',
  D: '🚔',
  E: '🏥',
  F: '🎯',
  G: '🔒',
};

function getSectionIcon(sectionCode: string): string {
  const key = sectionCode.charAt(0).toUpperCase();
  return SECTION_ICONS[key] || sectionCode.charAt(0).toUpperCase();
}

/**
 * Creates a custom colored circle DivIcon for a duty type marker.
 */
function createCustomIcon(sectionCode: string, isSelected: boolean): L.DivIcon {
  const color = getSectionColor(sectionCode);
  const icon = getSectionIcon(sectionCode);
  const size = isSelected ? 44 : 36;
  const anchor = size / 2;
  const shadowStyle = isSelected
    ? `box-shadow: 0 0 0 4px ${color}40, 0 4px 12px rgba(0,0,0,0.4);`
    : 'box-shadow: 0 2px 8px rgba(0,0,0,0.3);';
  const transform = isSelected ? 'transform: scale(1.1);' : '';

  return L.divIcon({
    className: 'custom-duty-marker',
    html: `<div style="
      width: ${size}px;
      height: ${size}px;
      border-radius: 50%;
      background: ${color};
      border: 3px solid white;
      ${shadowStyle}
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-weight: bold;
      font-size: ${isSelected ? '16px' : '14px'};
      ${transform}
      transition: all 0.2s ease;
      cursor: pointer;
    ">${icon}</div>`,
    iconSize: [size, size],
    iconAnchor: [anchor, anchor],
    popupAnchor: [0, -anchor],
  });
}

interface MapComponentProps {
  isFormOpen?: boolean;
  onMapClick?: (lat: number, lng: number) => void;
  onPinDrag?: (lat: number, lng: number) => void;
}

/**
 * Helper to round a number to 6 decimal places.
 */
function roundTo6dp(value: number): number {
  return Math.round(value * 1_000_000) / 1_000_000;
}

/**
 * Sub-component that fits map bounds to visible markers and
 * handles centering on selected duty type.
 */
const MapBoundsController: React.FC = observer(() => {
  const map = useMap();
  const { visibleMapPins, selectedDutyTypeId } = dutySectionStore;
  const prevPinsRef = useRef<string>('');

  // Fit bounds when visibleMapPins changes
  useEffect(() => {
    const pinsKey = visibleMapPins.map((p) => `${p.id}`).join(',');
    if (pinsKey === prevPinsRef.current) return;
    prevPinsRef.current = pinsKey;

    if (visibleMapPins.length > 0) {
      const validPins = visibleMapPins.filter((pin) => pin.latitude != null && pin.longitude != null);
      if (validPins.length > 0) {
        const bounds = L.latLngBounds(
          validPins.map((pin) => [pin.latitude as number, pin.longitude as number] as L.LatLngTuple)
        );
        map.fitBounds(bounds, { padding: [40, 40], maxZoom: 14 });
      } else {
        map.setView(KARNATAKA_CENTER, DEFAULT_ZOOM);
      }
    } else {
      map.setView(KARNATAKA_CENTER, DEFAULT_ZOOM);
    }
  }, [visibleMapPins, map]);

  // Center/zoom on selected duty type
  useEffect(() => {
    if (selectedDutyTypeId !== null) {
      const selected = visibleMapPins.find((dt) => dt.id === selectedDutyTypeId);
      if (selected && selected.latitude !== null && selected.longitude !== null) {
        map.setView([selected.latitude, selected.longitude], 14, { animate: true });
      }
    }
  }, [selectedDutyTypeId, visibleMapPins, map]);

  return null;
});

/**
 * Sub-component that handles map click events when form is open.
 */
const MapClickHandler: React.FC<{
  isFormOpen?: boolean;
  onMapClick?: (lat: number, lng: number) => void;
}> = ({ isFormOpen, onMapClick }) => {
  useMapEvents({
    click(e) {
      if (isFormOpen && onMapClick) {
        onMapClick(roundTo6dp(e.latlng.lat), roundTo6dp(e.latlng.lng));
      }
    },
  });
  return null;
};

/**
 * Draggable pin shown when form is open.
 */
const DraggableFormPin: React.FC<{
  position: L.LatLngTuple | null;
  onPinDrag?: (lat: number, lng: number) => void;
}> = ({ position, onPinDrag }) => {
  if (!position) return null;

  return (
    <Marker
      position={position}
      draggable
      eventHandlers={{
        dragend: (e) => {
          const marker = e.target as L.Marker;
          const latlng = marker.getLatLng();
          if (onPinDrag) {
            onPinDrag(roundTo6dp(latlng.lat), roundTo6dp(latlng.lng));
          }
        },
      }}
    />
  );
};

/**
 * Individual marker for a duty type pin with custom colored circle icon.
 * Auto-opens popup when selected.
 */
const DutyTypeMarker: React.FC<{ pin: DutyType }> = observer(({ pin }) => {
  const { t } = useTranslation();
  const { selectedDutyTypeId, personnel } = dutySectionStore;
  const markerRef = useRef<L.Marker | null>(null);

  const isSelected = selectedDutyTypeId === pin.id;
  const personnelCount = personnel.filter((p) => p.dutyType === pin.name).length;
  const sectionColor = getSectionColor(pin.section);
  const icon = createCustomIcon(pin.section, isSelected);

  // Auto-open popup when this pin is selected
  useEffect(() => {
    if (isSelected && markerRef.current) {
      markerRef.current.openPopup();
    }
  }, [isSelected]);

  return (
    <Marker
      ref={markerRef}
      position={[pin.latitude as number, pin.longitude as number]}
      icon={icon}
      eventHandlers={{
        click: () => {
          dutySectionStore.selectDutyType(pin.id);
        },
      }}
    >
      <Popup>
        <Box sx={{ minWidth: 180 }}>
          {/* Popup header with section color */}
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              gap: 1,
              mb: 0.75,
              pb: 0.75,
              borderBottom: `2px solid ${sectionColor}`,
            }}
          >
            <Box
              sx={{
                width: 24,
                height: 24,
                borderRadius: '50%',
                backgroundColor: sectionColor,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '12px',
              }}
            >
              {getSectionIcon(pin.section)}
            </Box>
            <Typography variant="body2" fontWeight={700} sx={{ fontSize: '0.85rem' }}>
              {pin.name}
            </Typography>
          </Box>

          {/* Details */}
          <Typography variant="caption" display="block" sx={{ color: '#64748B', mb: 0.25 }}>
            {t('admin.dutySections.section', 'Section')}: <strong>{pin.section}</strong>
          </Typography>
          <Typography variant="caption" display="block" sx={{ color: '#64748B', mb: 0.25 }}>
            📍 {(pin.latitude as number).toFixed(6)}, {(pin.longitude as number).toFixed(6)}
          </Typography>
          {personnelCount > 0 && (
            <Typography variant="caption" display="block" sx={{ color: '#64748B', mb: 0.75 }}>
              👥 {personnelCount} {t('admin.dutySections.totalPersonnel', 'personnel')}
            </Typography>
          )}

          {/* Action links */}
          <Box sx={{ display: 'flex', gap: 1.5, pt: 0.5 }}>
            <Typography
              variant="caption"
              sx={{
                color: '#3B82F6',
                cursor: 'pointer',
                fontWeight: 600,
                '&:hover': { textDecoration: 'underline' },
              }}
            >
              ✏️ Edit
            </Typography>
            <Typography
              variant="caption"
              sx={{
                color: '#EF4444',
                cursor: 'pointer',
                fontWeight: 600,
                '&:hover': { textDecoration: 'underline' },
              }}
            >
              🗑️ Delete
            </Typography>
          </Box>
        </Box>
      </Popup>
    </Marker>
  );
});

/**
 * MapComponent — Professional map with custom colored circle markers + dashed radius circles.
 * Each marker shows a section-colored circle with an icon inside.
 * Radius circles use dashed stroke with low-opacity fill.
 */
const MapComponent: React.FC<MapComponentProps> = observer(
  ({ isFormOpen, onMapClick, onPinDrag }) => {
    const { t } = useTranslation();
    const { visibleMapPins } = dutySectionStore;
    const [draggablePosition, setDraggablePosition] = useState<L.LatLngTuple | null>(null);

    // When map is clicked with form open, update draggable pin position
    const handleMapClick = (lat: number, lng: number) => {
      setDraggablePosition([lat, lng]);
      if (onMapClick) {
        onMapClick(lat, lng);
      }
    };

    const handlePinDrag = (lat: number, lng: number) => {
      setDraggablePosition([lat, lng]);
      if (onPinDrag) {
        onPinDrag(lat, lng);
      }
    };

    // Clear draggable pin when form closes
    useEffect(() => {
      if (!isFormOpen) {
        setDraggablePosition(null);
      }
    }, [isFormOpen]);

    return (
      <Box
        sx={{
          position: 'relative',
          height: '100%',
          minHeight: 400,
          borderRadius: 2,
          overflow: 'hidden',
          border: '1px solid #E2E8F0',
          // Hide default leaflet marker class styles
          '& .custom-duty-marker': {
            background: 'none !important',
            border: 'none !important',
          },
        }}
      >
        <MapContainer
          center={KARNATAKA_CENTER}
          zoom={DEFAULT_ZOOM}
          style={{ height: '100%', width: '100%', minHeight: 400 }}
          scrollWheelZoom
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />

          <MapBoundsController />
          <MapClickHandler isFormOpen={isFormOpen} onMapClick={handleMapClick} />

          {/* Render dashed radius circles FIRST (behind markers) */}
          {visibleMapPins
            .filter((pin) => pin.latitude != null && pin.longitude != null)
            .map((pin) => {
              const sectionColor = getSectionColor(pin.section);
              const radiusMeters = pin.radiusMeters || 500; // Default 500m radius for visual

              return (
                <Circle
                  key={`circle-${pin.id}`}
                  center={[pin.latitude as number, pin.longitude as number]}
                  radius={radiusMeters}
                  pathOptions={{
                    color: sectionColor,
                    fillColor: sectionColor,
                    fillOpacity: 0.08,
                    weight: 2,
                    dashArray: '8, 6',
                  }}
                />
              );
            })}

          {/* Render custom colored markers */}
          {visibleMapPins
            .filter((pin) => pin.latitude != null && pin.longitude != null)
            .map((pin) => (
              <DutyTypeMarker key={pin.id} pin={pin} />
            ))}

          {/* Draggable pin when form is open */}
          {isFormOpen && (
            <DraggableFormPin position={draggablePosition} onPinDrag={handlePinDrag} />
          )}
        </MapContainer>

        {/* No locations overlay message */}
        {visibleMapPins.length === 0 && (
          <Box
            sx={{
              position: 'absolute',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              zIndex: 1000,
              backgroundColor: 'rgba(255, 255, 255, 0.95)',
              px: 4,
              py: 3,
              borderRadius: 3,
              textAlign: 'center',
              pointerEvents: 'none',
              boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
              border: '1px solid #E2E8F0',
            }}
          >
            <Typography variant="body1" color="text.secondary" fontWeight={500}>
              📍 {t('admin.dutySections.noLocations', 'No locations to display')}
            </Typography>
            <Typography variant="caption" color="text.secondary" sx={{ mt: 0.5 }}>
              Select a section to view duty posts on the map
            </Typography>
          </Box>
        )}
      </Box>
    );
  }
);

export default MapComponent;

import React, { useState, useRef } from 'react';
import { Box, TextField, IconButton, Tooltip } from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import MicIcon from '@mui/icons-material/Mic';
import MicOffIcon from '@mui/icons-material/MicOff';
import AttachFileIcon from '@mui/icons-material/AttachFile';
import { useTranslation } from 'react-i18next';

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  onUploadPdf: (file: File) => void;
  disabled?: boolean;
}

const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage, onUploadPdf, disabled }) => {
  const { t } = useTranslation();
  const [text, setText] = useState('');
  const [listening, setListening] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  const handleSend = () => {
    const trimmed = text.trim();
    if (!trimmed) return;
    onSendMessage(trimmed);
    setText('');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const toggleVoice = () => {
    const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognitionAPI) return;

    if (listening && recognitionRef.current) {
      recognitionRef.current.stop();
      setListening(false);
      return;
    }

    const recognition = new SpeechRecognitionAPI();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';
    recognition.onresult = (event: SpeechRecognitionEvent) => {
      const transcript = event.results[0]?.[0]?.transcript ?? '';
      if (transcript) {
        onSendMessage(transcript);
      }
    };
    recognition.onend = () => setListening(false);
    recognition.onerror = () => setListening(false);
    recognitionRef.current = recognition;
    recognition.start();
    setListening(true);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type === 'application/pdf') {
      onUploadPdf(file);
    }
    if (fileRef.current) fileRef.current.value = '';
  };

  return (
    <Box sx={{ display: 'flex', gap: 0.5, alignItems: 'center', p: 1 }}>
      <input ref={fileRef} type="file" accept=".pdf" hidden onChange={handleFileChange} />
      <Tooltip title={t('home.attachPdf')}>
        <IconButton size="small" onClick={() => fileRef.current?.click()} disabled={disabled}>
          <AttachFileIcon fontSize="small" />
        </IconButton>
      </Tooltip>
      <TextField
        size="small"
        fullWidth
        placeholder={t('home.chatPlaceholder')}
        value={text}
        onChange={(e) => setText(e.target.value)}
        onKeyDown={handleKeyDown}
        disabled={disabled}
      />
      <Tooltip title={t('home.voiceCommand')}>
        <IconButton size="small" onClick={toggleVoice} disabled={disabled} color={listening ? 'error' : 'default'}>
          {listening ? <MicOffIcon fontSize="small" /> : <MicIcon fontSize="small" />}
        </IconButton>
      </Tooltip>
      <Tooltip title={t('home.sendMessage')}>
        <IconButton size="small" onClick={handleSend} disabled={disabled || !text.trim()} color="primary">
          <SendIcon fontSize="small" />
        </IconButton>
      </Tooltip>
    </Box>
  );
};

export default ChatInput;

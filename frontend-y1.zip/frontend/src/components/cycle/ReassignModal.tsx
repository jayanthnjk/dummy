import React, { useState, useCallback, useEffect, useRef } from 'react';
import {
  Alert,
  Box,
  Button,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  Stack,
  TextField,
  Typography,
} from '@mui/material';
import AutoFixHighIcon from '@mui/icons-material/AutoFixHigh';
import PersonSearchIcon from '@mui/icons-material/PersonSearch';
import { cycleService, type AvailablePersonnel } from '@/services/cycleService';
import { isAxiosError } from 'axios';

export interface ReassignModalProps {
  /** Whether the dialog is visible */
  open: boolean;
  /** Close handler */
  onClose: () => void;
  /** Called after successful reassignment (to refresh the parent grid) */
  onSuccess: () => void;
  /** The assignment to reassign */
  assignmentId: number | null;
  /** The date of the assignment (for display) */
  assignmentDate: string;
  /** Name of current assignee (for display) */
  currentPersonName: string;
  /** Whether to show the auto-reassign option */
  showAutoOption?: boolean;
}

/**
 * ReassignModal — MUI Dialog with searchable personnel dropdown and auto-reassign.
 * Shows available personnel who can take over a duty assignment.
 */
const ReassignModal: React.FC<ReassignModalProps> = ({
  open,
  onClose,
  onSuccess,
  assignmentId,
  assignmentDate,
  currentPersonName,
  showAutoOption = false,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [results, setResults] = useState<AvailablePersonnel[]>([]);
  const [searching, setSearching] = useState(false);
  const [selectedPerson, setSelectedPerson] = useState<AvailablePersonnel | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [autoReassigning, setAutoReassigning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmMode, setConfirmMode] = useState(false);
  const [autoResult, setAutoResult] = useState<string | null>(null);
  const searchTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Search for available personnel when query changes
  useEffect(() => {
    if (!open || !assignmentId) return;

    if (searchTimeout.current) {
      clearTimeout(searchTimeout.current);
    }

    searchTimeout.current = setTimeout(async () => {
      setSearching(true);
      try {
        const data = await cycleService.getAvailablePersonnel(assignmentId, searchQuery || undefined);
        setResults(data.content);
      } catch (err) {
        console.warn('Failed to fetch available personnel:', err);
        setResults([]);
      } finally {
        setSearching(false);
      }
    }, 300);

    return () => {
      if (searchTimeout.current) clearTimeout(searchTimeout.current);
    };
  }, [searchQuery, open, assignmentId]);

  const handleClose = useCallback(() => {
    if (submitting || autoReassigning) return;
    setSearchQuery('');
    setResults([]);
    setSelectedPerson(null);
    setError(null);
    setConfirmMode(false);
    setAutoResult(null);
    onClose();
  }, [submitting, autoReassigning, onClose]);

  const handleSelectPerson = (person: AvailablePersonnel) => {
    setSelectedPerson(person);
    setConfirmMode(true);
  };

  const handleConfirmReassign = useCallback(async () => {
    if (!assignmentId || !selectedPerson) return;

    setSubmitting(true);
    setError(null);

    try {
      await cycleService.reassignDuty(assignmentId, selectedPerson.id);
      setSearchQuery('');
      setResults([]);
      setSelectedPerson(null);
      setConfirmMode(false);
      setError(null);
      onSuccess();
      onClose();
    } catch (err: unknown) {
      if (isAxiosError(err) && err.response) {
        const data = err.response.data as { error?: string; message?: string };
        setError(data?.error || data?.message || 'Failed to reassign duty.');
      } else {
        setError(err instanceof Error ? err.message : 'Failed to reassign duty.');
      }
    } finally {
      setSubmitting(false);
    }
  }, [assignmentId, selectedPerson, onSuccess, onClose]);

  const handleAutoReassign = useCallback(async () => {
    if (!assignmentId) return;

    setAutoReassigning(true);
    setError(null);

    try {
      const result = await cycleService.autoReassign(assignmentId);
      setAutoResult(
        `Duty reassigned to ${result.newPersonName} (${result.newPersonBadgeId}) from Platoon ${result.newPersonPlatoonId}`,
      );
      // Delay success callback to let user see the result
      setTimeout(() => {
        onSuccess();
        onClose();
        setAutoResult(null);
      }, 2500);
    } catch (err: unknown) {
      if (isAxiosError(err) && err.response) {
        const data = err.response.data as { error?: string; message?: string };
        setError(data?.error || data?.message || 'Auto-reassign failed.');
      } else {
        setError(err instanceof Error ? err.message : 'Auto-reassign failed.');
      }
    } finally {
      setAutoReassigning(false);
    }
  }, [assignmentId, onSuccess, onClose]);

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '';
    return new Date(dateStr + 'T00:00:00').toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      maxWidth="sm"
      fullWidth
      aria-labelledby="reassign-modal-title"
    >
      <DialogTitle id="reassign-modal-title">Reassign Duty</DialogTitle>
      <DialogContent>
        <Stack spacing={2} sx={{ mt: 1 }}>
          {/* Leave conflict message */}
          <Alert severity="warning" icon={false}>
            <Typography variant="body2" fontWeight={500}>
              This person is on leave. Please reassign.
            </Typography>
          </Alert>

          {/* Current assignment info */}
          <Box sx={{ pl: 1 }}>
            <Typography variant="body2" color="text.secondary">
              <strong>Current assignee:</strong> {currentPersonName}
            </Typography>
            {assignmentDate && (
              <Typography variant="body2" color="text.secondary">
                <strong>Date:</strong> {formatDate(assignmentDate)}
              </Typography>
            )}
          </Box>

          {/* Auto-reassign result */}
          {autoResult && (
            <Alert severity="success">
              {autoResult}
            </Alert>
          )}

          {/* Error display */}
          {error && (
            <Alert severity="error" onClose={() => setError(null)}>
              {error}
            </Alert>
          )}

          {/* Confirmation mode */}
          {confirmMode && selectedPerson && (
            <Alert severity="info" sx={{ borderRadius: '8px' }}>
              <Typography variant="body2" fontWeight={500}>
                Reassigning duty from <strong>{currentPersonName}</strong> to{' '}
                <strong>{selectedPerson.personName} ({selectedPerson.badgeId})</strong> for{' '}
                <strong>{formatDate(assignmentDate)}</strong> only.
              </Typography>
            </Alert>
          )}

          {/* Search input (hidden in confirm mode) */}
          {!confirmMode && !autoResult && (
            <>
              <TextField
                label="Search Personnel"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                fullWidth
                size="small"
                placeholder="Search by name or badge ID..."
                disabled={submitting || autoReassigning}
                InputProps={{
                  startAdornment: (
                    <PersonSearchIcon sx={{ mr: 1, color: '#9CA3AF', fontSize: 20 }} />
                  ),
                  endAdornment: searching ? <CircularProgress size={16} /> : undefined,
                }}
              />

              {/* Results dropdown */}
              {results.length > 0 && (
                <Box
                  sx={{
                    maxHeight: 200,
                    overflowY: 'auto',
                    border: '1px solid #E5E7EB',
                    borderRadius: '8px',
                    backgroundColor: '#FAFBFC',
                  }}
                >
                  {results.map((person) => (
                    <Box
                      key={person.id}
                      onClick={() => handleSelectPerson(person)}
                      sx={{
                        px: 2,
                        py: 1.2,
                        cursor: 'pointer',
                        borderBottom: '1px solid #F3F4F6',
                        '&:hover': { backgroundColor: '#EEF2FF' },
                        '&:last-child': { borderBottom: 'none' },
                      }}
                    >
                      <Typography variant="body2" fontWeight={600} sx={{ color: '#1F2937' }}>
                        {person.personName} ({person.badgeId})
                      </Typography>
                      <Typography variant="caption" sx={{ color: '#6B7280' }}>
                        {person.section} — {person.currentDutyType || 'No duty type'}
                      </Typography>
                    </Box>
                  ))}
                </Box>
              )}

              {!searching && searchQuery && results.length === 0 && (
                <Typography variant="body2" color="text.secondary" sx={{ pl: 1 }}>
                  No available personnel found.
                </Typography>
              )}
            </>
          )}

          {/* Auto-Reassign button */}
          {showAutoOption && !confirmMode && !autoResult && (
            <>
              <Divider sx={{ my: 1 }}>
                <Typography variant="caption" color="text.secondary">
                  OR
                </Typography>
              </Divider>
              <Button
                variant="outlined"
                color="secondary"
                onClick={handleAutoReassign}
                disabled={autoReassigning || submitting}
                startIcon={
                  autoReassigning ? (
                    <CircularProgress size={16} color="inherit" />
                  ) : (
                    <AutoFixHighIcon />
                  )
                }
                sx={{ textTransform: 'none', fontWeight: 600 }}
              >
                {autoReassigning ? 'Auto Reassigning...' : 'Auto Reassign (From Other Platoon)'}
              </Button>
            </>
          )}
        </Stack>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={handleClose} disabled={submitting || autoReassigning}>
          Cancel
        </Button>
        {confirmMode && (
          <Button
            variant="contained"
            onClick={handleConfirmReassign}
            disabled={submitting}
            startIcon={submitting ? <CircularProgress size={16} color="inherit" /> : undefined}
          >
            {submitting ? 'Reassigning...' : 'Confirm Reassign'}
          </Button>
        )}
        {confirmMode && (
          <Button
            onClick={() => {
              setConfirmMode(false);
              setSelectedPerson(null);
            }}
            disabled={submitting}
          >
            Back
          </Button>
        )}
      </DialogActions>
    </Dialog>
  );
};

export default ReassignModal;

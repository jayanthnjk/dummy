import { keyframes } from '@mui/material/styles';

/**
 * Animation keyframes for the KSP WorkBoard UX redesign.
 * All animations should be used with `prefers-reduced-motion` checks
 * to provide instant state changes when motion is disabled.
 */

/** Fade in: opacity 0 → 1 */
export const fadeIn = keyframes`
  from { opacity: 0; }
  to { opacity: 1; }
`;

/** Slide up: opacity 0 → 1 + translateY(20px → 0) */
export const slideUp = keyframes`
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
`;

/** Scale in: opacity 0 → 1 + scale(0.95 → 1) */
export const scaleIn = keyframes`
  from { opacity: 0; transform: scale(0.95); }
  to { opacity: 1; transform: scale(1); }
`;

/** Pulse: scale 1 → 1.05 → 1 */
export const pulse = keyframes`
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.05); }
`;

/** Scale out: opacity 1 → 0 + scale(1 → 0.95) — used for dialog close */
export const scaleOut = keyframes`
  from { opacity: 1; transform: scale(1); }
  to { opacity: 0; transform: scale(0.95); }
`;

/** Slide in from bottom: translateY(100% → 0) + opacity 0 → 1 — used for snackbar */
export const slideInFromBottom = keyframes`
  from { opacity: 0; transform: translateY(100%); }
  to { opacity: 1; transform: translateY(0); }
`;

/** Slide out to bottom: translateY(0 → 100%) + opacity 1 → 0 — used for snackbar dismiss */
export const slideOutToBottom = keyframes`
  from { opacity: 1; transform: translateY(0); }
  to { opacity: 0; transform: translateY(100%); }
`;

# Release Notes
## KSP WorkBoard — Version 1.0.0

| Field | Details |
|-------|---------|
| **Release Version** | 1.0.0 |
| **Release Date** | June 2026 |
| **Release Type** | Initial Production Release |
| **Application** | KSP WorkBoard |

---

## 1. Release Summary

This is the initial production release of KSP WorkBoard — a comprehensive AI-powered police station management system built for the City Armed Reserve (CAR) Police Station, Mangalore. This release delivers the complete core functionality including personnel management, platoon rotation scheduling, leave management, adhoc duty operations, AI chat interface, and report generation.

---

## 2. What's Included

### 2.1 Core Modules

| Module | Status | Description |
|--------|--------|-------------|
| Authentication & Authorization | ✅ Complete | JWT login, 3 roles, password change, inactivity auto-logout |
| Personnel Management | ✅ Complete | Full CRUD, search, filter, 200+ personnel records |
| Platoon Cycle Management | ✅ Complete | Create/update/delete cycles, auto-generate mappings, 3-shift rotation |
| Duty Assignment Engine | ✅ Complete | Auto-generation, manual reassignment, auto-reassignment |
| Leave Management | ✅ Complete | Submit/approve/reject/cancel, conflict detection, 5 leave types |
| Adhoc Duty Management | ✅ Complete | Create special duties, auto-assign personnel, preview available |
| AI Chat Interface | ✅ Complete | 37 tools, multilingual (EN/KN/HI), voice input, PDF upload |
| Report Generation | ✅ Complete | 6 report types × PDF + Excel formats |
| Schedule Visualization | ✅ Complete | Section overview, platoon rotation view |
| Admin Configuration | ✅ Complete | Duty types with geolocation, section management |
| Internationalization | ✅ Complete | English + Kannada (ಕನ್ನಡ) |
| Support Tickets | ✅ Complete | Submit, respond, status tracking |

### 2.2 Technical Features

| Feature | Implementation |
|---------|---------------|
| AI Provider Abstraction | Groq (dev) + AWS Bedrock (prod) via unified LlmClient interface |
| MCP Architecture | 5 MCP servers with 37 registered tools |
| Circuit Breakers | Resilience4j for STT and LLM calls |
| Response Caching | Caffeine with domain-specific invalidation |
| Prompt Injection Protection | InputSanitizerService active on all chat inputs |
| PII Filter | Logging filter for sensitive data access |
| Audit Trail | Immutable cycle_audit_log for all duty changes |
| Voice Input | Groq Whisper STT integration |
| Document RAG | PDF upload, chunking, pgvector embeddings |

### 2.3 Deployment Infrastructure

| Component | Specification |
|-----------|--------------|
| Backend | Spring Boot 3.4.4, Java 17, EC2 t3.medium |
| Frontend | React 19, Vite 6, S3 + CloudFront |
| Database | PostgreSQL 15+ with pgvector |
| AI | AWS Bedrock (Amazon Nova Lite v1) |
| Process Manager | systemd |

---

## 3. System Requirements

### 3.1 Server Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| CPU | 2 vCPU | 4 vCPU |
| RAM | 4 GB | 8 GB |
| Storage | 20 GB | 50 GB |
| Java | 17 | 17 (LTS) |
| PostgreSQL | 15 | 16 |
| OS | Amazon Linux 2 | Amazon Linux 2023 |

### 3.2 Client Requirements

| Component | Minimum |
|-----------|---------|
| Browser | Chrome 90+, Firefox 90+, Safari 15+, Edge 90+ |
| Screen | 1024×768 (responsive design supports mobile) |
| Network | Stable internet connection |

---

## 4. Known Limitations

| # | Limitation | Impact | Workaround |
|---|-----------|--------|------------|
| 1 | Single-station deployment only | Cannot manage multiple police stations | Separate deployment per station |
| 2 | No real-time notifications | Users must refresh to see new changes | Use chat to query latest state |
| 3 | No mobile native app | Mobile users use responsive web | Works on mobile browsers |
| 4 | LLM occasionally misroutes tools | ~5% of complex Kannada queries may need rephrasing | Rephrase in English or simpler Kannada |
| 5 | Voice input requires internet | STT service is cloud-based | Type message as fallback |
| 6 | No offline mode | System requires active internet | — |
| 7 | PDF reports are English-only format | Report headers/structure in English | Locale parameter partial support |
| 8 | Max 10MB file upload | Large PDFs need splitting | Split PDF before upload |
| 9 | No bulk personnel import | Must add personnel one by one via UI/chat | Use direct DB insert for initial load |
| 10 | No email/SMS notifications | Leave approvals not notified externally | Check system regularly |

---

## 5. API Endpoints Count

| Category | Endpoints |
|----------|-----------|
| Authentication | 3 |
| Personnel | 5 |
| Leave Requests | 5 |
| Cycles | 10 |
| Adhoc Duties | 7 |
| Chat | 4 |
| Schedules | 7 |
| Assignments | 5 |
| Reports | 17 |
| Duty Types | 4 |
| Sections | 5 |
| Holidays | 3 |
| i18n | 3 |
| Admin Config | 2 |
| Support | 4 |
| Health | 2 |
| **Total** | **86** |

---

## 6. Database Tables

Total: 22 tables supporting authentication, personnel, scheduling, leave, adhoc duties, chat history, document embeddings, configuration, and audit logging.

---

## 7. Upgrade Instructions

This is the initial release. No upgrade path needed. For fresh deployment, follow the Deployment Guide (Document #8).

---

## 8. Breaking Changes

Not applicable — initial release.

---

## 9. Security Notes

- All passwords stored with BCrypt hashing
- JWT tokens expire after 24 hours
- Prompt injection protection active on all chat inputs
- PII filter logs access to sensitive data
- CORS configured to allow only the frontend domain
- Rate limiting: 30 general + 20 LLM requests per user

---

*End of Document — Release Notes v1.0.0*

import React, { useEffect, useState, useCallback } from 'react';
import { observer } from 'mobx-react-lite';
import { Box, CircularProgress, Alert, Typography } from '@mui/material';
import { useTranslation } from 'react-i18next';
import { dutySectionStore } from '@/stores/dutySectionStore';
import SectionTabsBar from './SectionTabsBar';
import SearchFilterBar from './SearchFilterBar';
import SplitPanel from './SplitPanel';
import DutyTypeFormDialog from './DutyTypeFormDialog';
import SectionManagementDialog from './SectionManagementDialog';
import ReassignDialog from './ReassignDialog';

/**
 * DutyAndSectionsTab — Main container component for the unified "Duty & Sections" view.
 * Composes SectionTabsBar (chip filters), SearchFilterBar, and SplitPanel (Sidebar + Map + Personnel Table).
 * Manages dialog open/close state and wires map interactions to the form dialog.
 */
const DutyAndSectionsTab: React.FC = observer(() => {
  const { t } = useTranslation();

  // Dialog open/close state
  const [sectionManagementOpen, setSectionManagementOpen] = useState(false);
  const [dutyTypeFormOpen, setDutyTypeFormOpen] = useState(false);
  const [editDutyTypeId, setEditDutyTypeId] = useState<number | null>(null);
  const [reassignOpen, setReassignOpen] = useState(false);
  const [preSelectedReassignIds, setPreSelectedReassignIds] = useState<number[]>([]);

  // Map click-to-place / pin drag coordinates (passed to DutyTypeFormDialog)
  const [mapClickCoords, setMapClickCoords] = useState<{ lat: number; lng: number } | null>(null);

  // Fetch sections on mount
  useEffect(() => {
    dutySectionStore.fetchSections();
  }, []);

  // Watch store for header "Add Duty Type" button trigger
  useEffect(() => {
    if (dutySectionStore.showAddDutyTypeDialog) {
      setEditDutyTypeId(null);
      setMapClickCoords(null);
      setDutyTypeFormOpen(true);
      dutySectionStore.closeAddDutyTypeDialog();
    }
  }, [dutySectionStore.showAddDutyTypeDialog]);

  // --- Section Management Dialog handlers ---
  const handleSettingsClick = useCallback(() => {
    setSectionManagementOpen(true);
  }, []);

  const handleSectionManagementClose = useCallback(() => {
    setSectionManagementOpen(false);
  }, []);

  // --- Duty Type Form Dialog handlers ---
  const handleAddDutyType = useCallback(() => {
    setEditDutyTypeId(null);
    setMapClickCoords(null);
    setDutyTypeFormOpen(true);
  }, []);

  const handleEditDutyType = useCallback((id: number) => {
    setEditDutyTypeId(id);
    setMapClickCoords(null);
    setDutyTypeFormOpen(true);
  }, []);

  const handleDutyTypeFormClose = useCallback(() => {
    setDutyTypeFormOpen(false);
    setEditDutyTypeId(null);
    setMapClickCoords(null);
  }, []);

  // --- Reassign Dialog handlers ---
  const handleReassignDutyType = useCallback((id: number) => {
    setPreSelectedReassignIds([id]);
    setReassignOpen(true);
  }, []);

  const handleReassignClose = useCallback(() => {
    setReassignOpen(false);
    setPreSelectedReassignIds([]);
  }, []);

  // --- Map interactions (click-to-place / pin drag) ---
  const handleMapClick = useCallback(
    (lat: number, lng: number) => {
      if (dutyTypeFormOpen) {
        setMapClickCoords({ lat, lng });
      }
    },
    [dutyTypeFormOpen]
  );

  const handlePinDrag = useCallback(
    (lat: number, lng: number) => {
      if (dutyTypeFormOpen) {
        setMapClickCoords({ lat, lng });
      }
    },
    [dutyTypeFormOpen]
  );

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      {/* Loading indicator */}
      {dutySectionStore.loading && (
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            py: 2,
            backgroundColor: 'white',
            borderRadius: 2,
            border: '1px solid #E2E8F0',
          }}
        >
          <CircularProgress size={24} sx={{ color: '#3B82F6' }} />
          <Typography variant="body2" color="text.secondary" sx={{ ml: 1.5 }}>
            {t('admin.dutySections.loading', 'Loading...')}
          </Typography>
        </Box>
      )}

      {/* Error alert */}
      {dutySectionStore.error && (
        <Alert
          severity="error"
          sx={{
            borderRadius: 2,
            border: '1px solid #FEE2E2',
            '& .MuiAlert-icon': { color: '#EF4444' },
          }}
        >
          {dutySectionStore.error}
        </Alert>
      )}

      {/* 1. Section Filter Chips Bar */}
      <SectionTabsBar onSettingsClick={handleSettingsClick} />

      {/* 2. Search / Filter Bar */}
      <SearchFilterBar />

      {/* 3. Split Panel (Sidebar + Map + Personnel Table) */}
      <SplitPanel
        isFormOpen={dutyTypeFormOpen}
        onMapClick={handleMapClick}
        onPinDrag={handlePinDrag}
        onAddDutyType={handleAddDutyType}
        onEditDutyType={handleEditDutyType}
        onReassignDutyType={handleReassignDutyType}
      />

      {/* Dialogs */}
      <DutyTypeFormDialog
        open={dutyTypeFormOpen}
        onClose={handleDutyTypeFormClose}
        editDutyTypeId={editDutyTypeId}
        onMapClick={mapClickCoords}
      />

      <SectionManagementDialog
        open={sectionManagementOpen}
        onClose={handleSectionManagementClose}
      />

      <ReassignDialog
        open={reassignOpen}
        onClose={handleReassignClose}
        preSelectedDutyTypeIds={preSelectedReassignIds}
      />
    </Box>
  );
});

export default DutyAndSectionsTab;

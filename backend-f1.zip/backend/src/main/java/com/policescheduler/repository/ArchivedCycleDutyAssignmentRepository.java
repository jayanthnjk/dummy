package com.policescheduler.repository;

import com.policescheduler.entity.ArchivedCycleDutyAssignment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

/**
 * Repository for archived cycle duty assignments.
 * Used for querying historical cycle data.
 */
@Repository
public interface ArchivedCycleDutyAssignmentRepository extends JpaRepository<ArchivedCycleDutyAssignment, Long> {

    /**
     * Find all archived assignments for a specific cycle.
     */
    List<ArchivedCycleDutyAssignment> findByCycleId(Long cycleId);

    /**
     * Find archived assignments for a cycle on a specific date.
     */
    List<ArchivedCycleDutyAssignment> findByCycleIdAndDate(Long cycleId, LocalDate date);

    /**
     * Find archived assignments for a person within a date range.
     */
    List<ArchivedCycleDutyAssignment> findByPersonIdAndDateBetweenOrderByDateDesc(
            Long personId, LocalDate startDate, LocalDate endDate);

    /**
     * Find archived assignments for a specific date.
     */
    List<ArchivedCycleDutyAssignment> findByDate(LocalDate date);

    /**
     * Count archived records for a cycle (to verify archival).
     */
    long countByCycleId(Long cycleId);

    /**
     * Check if cycle has already been archived.
     */
    @Query("SELECT COUNT(a) > 0 FROM ArchivedCycleDutyAssignment a WHERE a.cycleId = :cycleId")
    boolean existsByCycleId(@Param("cycleId") Long cycleId);
}

import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import {
  Box, Typography, TextField, Button, MenuItem, Card, CardContent,
  Chip, CircularProgress, Alert, Divider, InputAdornment, TablePagination,
} from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import SearchIcon from '@mui/icons-material/Search';
import ReplayIcon from '@mui/icons-material/Replay';
import AttachFileIcon from '@mui/icons-material/AttachFile';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import CloseIcon from '@mui/icons-material/Close';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import { useTranslation } from 'react-i18next';
import { supportService, SupportTicket, CreateTicketRequest } from '@/services/supportService';
import PageHeader from '@/components/common/PageHeader';

const CATEGORIES = [
  { value: 'BUG', label: 'Bug Report' },
  { value: 'FEATURE_REQUEST', label: 'Feature Request' },
  { value: 'GENERAL', label: 'General Inquiry' },
  { value: 'ACCESS_ISSUE', label: 'Access Issue' },
];

const PRIORITIES = [
  { value: 'LOW', label: 'Low' },
  { value: 'MEDIUM', label: 'Medium' },
  { value: 'HIGH', label: 'High' },
  { value: 'CRITICAL', label: 'Critical' },
];

const ALLOWED_FILE_TYPES = [
  'image/png', 'image/jpeg', 'image/jpg', 'image/gif', 'image/webp',
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
];
const ALLOWED_EXTENSIONS = '.png, .jpg, .jpeg, .gif, .webp, .pdf, .doc, .docx';
const MAX_FILE_SIZE = 50 * 1024; // 50KB

const STATUS_COLORS: Record<string, 'warning' | 'info' | 'success' | 'default'> = {
  OPEN: 'warning',
  IN_PROGRESS: 'info',
  RESOLVED: 'success',
  CLOSED: 'default',
};

const ContactSupportPage: React.FC = () => {
  const { t } = useTranslation();
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [category, setCategory] = useState('GENERAL');
  const [priority, setPriority] = useState('MEDIUM');
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [loading, setLoading] = useState(true);
  const [attachment, setAttachment] = useState<File | null>(null);
  const [attachmentError, setAttachmentError] = useState('');
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Ticket filtering & pagination state
  const [ticketSearch, setTicketSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [priorityFilter, setPriorityFilter] = useState<string>('ALL');
  const [ticketPage, setTicketPage] = useState(0);
  const [ticketsPerPage, setTicketsPerPage] = useState(10);
  const [reopening, setReopening] = useState<number | null>(null);

  const loadTickets = async () => {
    try {
      const data = await supportService.list();
      setTickets(data);
    } catch {
      // Silently fail on load
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTickets();
  }, []);

  // Derived: filtered tickets based on search, status, and priority
  const filteredTickets = useMemo(() => {
    let result = tickets;
    if (ticketSearch.trim()) {
      const q = ticketSearch.toLowerCase();
      result = result.filter((t) => t.subject.toLowerCase().includes(q));
    }
    if (statusFilter !== 'ALL') {
      result = result.filter((t) => t.status === statusFilter);
    }
    if (priorityFilter !== 'ALL') {
      result = result.filter((t) => t.priority === priorityFilter);
    }
    return result;
  }, [tickets, ticketSearch, statusFilter, priorityFilter]);

  // Derived: paginated tickets
  const paginatedTickets = useMemo(() => {
    const start = ticketPage * ticketsPerPage;
    return filteredTickets.slice(start, start + ticketsPerPage);
  }, [filteredTickets, ticketPage, ticketsPerPage]);

  const validateFile = useCallback((file: File): string | null => {
    if (file.size > MAX_FILE_SIZE) {
      return `File size (${(file.size / 1024).toFixed(1)}KB) exceeds maximum 50KB limit`;
    }
    if (!ALLOWED_FILE_TYPES.includes(file.type)) {
      return `File type not allowed. Accepted: ${ALLOWED_EXTENSIONS}`;
    }
    return null;
  }, []);

  const handleFileSelect = useCallback((file: File) => {
    setAttachmentError('');
    const validationError = validateFile(file);
    if (validationError) {
      setAttachmentError(validationError);
      return;
    }

    // Check for password-protected PDF (basic client-side check)
    if (file.type === 'application/pdf') {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        if (content && content.includes('/Encrypt')) {
          setAttachmentError('Password-protected files are not accepted. Please remove the password and try again.');
          setAttachment(null);
          return;
        }
        setAttachment(file);
      };
      reader.readAsText(file.slice(0, 1024));
    } else {
      setAttachment(file);
    }
  }, [validateFile]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFileSelect(file);
  }, [handleFileSelect]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    setSuccess(false);

    try {
      const request: CreateTicketRequest = { subject, message, category, priority };
      await supportService.submit(request, attachment);
      setSuccess(true);
      setSubject('');
      setMessage('');
      setCategory('GENERAL');
      setPriority('MEDIUM');
      setAttachment(null);
      setAttachmentError('');
      loadTickets();
    } catch (err: any) {
      const msg = err?.response?.data?.error || t('support.ticketError', 'Failed to submit ticket. Please try again.');
      setError(msg);
    } finally {
      setSubmitting(false);
    }
  };

  const handleReopenTicket = async (ticketId: number) => {
    setReopening(ticketId);
    try {
      await supportService.reopenTicket(ticketId);
      loadTickets();
    } catch {
      setError(t('support.reopenError', 'Failed to reopen ticket. Please try again.'));
    } finally {
      setReopening(null);
    }
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', bgcolor: 'background.default' }}>
      <PageHeader
        title={t('support.title', 'Contact Support')}
        breadcrumbs={[
          { label: t('nav.home', 'Home'), path: '/' },
          { label: t('support.title', 'Contact Support') },
        ]}
      />

      {/* Content */}
      <Box sx={{ flex: 1, px: { xs: 2, md: 4 }, py: 3, maxWidth: 900, mx: 'auto', width: '100%' }}>
        {/* Submit Ticket Form */}
        <Card sx={{ mb: 4, borderRadius: 2, border: (theme) => `1px solid ${theme.palette.divider}` }} elevation={0}>
          <CardContent sx={{ p: 3 }}>
            <Typography variant="h6" fontWeight={600} sx={{ mb: 2 }}>
              {t('support.submitNewTicket', 'Submit a New Ticket')}
            </Typography>

            {success && (
              <Alert severity="success" sx={{ mb: 2 }} onClose={() => setSuccess(false)}>
                {t('support.ticketSuccess', "Ticket submitted successfully! We'll get back to you soon.")}
              </Alert>
            )}
            {error && (
              <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>
                {error}
              </Alert>
            )}

            <Box component="form" onSubmit={handleSubmit} sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <TextField
                label={t('support.subject', 'Subject')}
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                required
                fullWidth
                size="small"
                placeholder={t('support.subject', 'Brief description of your issue')}
              />

              <Box sx={{ display: 'flex', gap: 2 }}>
                <TextField
                  label={t('support.category', 'Category')}
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  select
                  fullWidth
                  size="small"
                >
                  {CATEGORIES.map((c) => (
                    <MenuItem key={c.value} value={c.value}>{c.label}</MenuItem>
                  ))}
                </TextField>

                <TextField
                  label={t('support.priority', 'Priority')}
                  value={priority}
                  onChange={(e) => setPriority(e.target.value)}
                  select
                  fullWidth
                  size="small"
                >
                  {PRIORITIES.map((p) => (
                    <MenuItem key={p.value} value={p.value}>{p.label}</MenuItem>
                  ))}
                </TextField>
              </Box>

              <TextField
                label={t('support.message', 'Message')}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                required
                fullWidth
                multiline
                rows={4}
                size="small"
                placeholder={t('support.message', 'Describe your issue in detail...')}
              />

              {/* File Attachment - Drag & Drop */}
              <Box>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept={ALLOWED_EXTENSIONS}
                  style={{ display: 'none' }}
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleFileSelect(file);
                    e.target.value = '';
                  }}
                />
                {!attachment ? (
                  <Box
                    onDrop={handleDrop}
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onClick={() => fileInputRef.current?.click()}
                    sx={{
                      border: '2px dashed',
                      borderColor: dragOver ? 'primary.main' : attachmentError ? 'error.main' : '#d1d5db',
                      borderRadius: 2,
                      p: 2.5,
                      textAlign: 'center',
                      cursor: 'pointer',
                      bgcolor: dragOver ? 'action.hover' : 'transparent',
                      transition: 'all 0.2s ease',
                      '&:hover': { borderColor: 'primary.main', bgcolor: 'action.hover' },
                    }}
                  >
                    <CloudUploadIcon sx={{ fontSize: 32, color: dragOver ? 'primary.main' : '#9ca3af', mb: 0.5 }} />
                    <Typography variant="body2" sx={{ color: 'text.secondary', fontWeight: 500 }}>
                      Drag & drop a file here or click to browse
                    </Typography>
                    <Typography variant="caption" sx={{ color: '#9ca3af', display: 'block', mt: 0.5 }}>
                      Max 50KB | Formats: PNG, JPG, GIF, WEBP, PDF, DOC, DOCX
                    </Typography>
                    <Typography variant="caption" sx={{ color: '#9ca3af', display: 'block' }}>
                      Password-protected files are not accepted
                    </Typography>
                  </Box>
                ) : (
                  <Box sx={{
                    display: 'flex', alignItems: 'center', gap: 1.5,
                    p: 1.5, border: '1px solid', borderColor: 'success.main',
                    borderRadius: 2, bgcolor: '#f0fdf4',
                  }}>
                    <InsertDriveFileIcon sx={{ color: 'success.main', fontSize: 28 }} />
                    <Box sx={{ flex: 1, minWidth: 0 }}>
                      <Typography variant="body2" sx={{ fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {attachment.name}
                      </Typography>
                      <Typography variant="caption" sx={{ color: 'text.secondary' }}>
                        {(attachment.size / 1024).toFixed(1)} KB
                      </Typography>
                    </Box>
                    <Button
                      size="small"
                      color="error"
                      onClick={(e) => { e.stopPropagation(); setAttachment(null); setAttachmentError(''); }}
                      sx={{ minWidth: 'auto', p: 0.5 }}
                    >
                      <CloseIcon sx={{ fontSize: 18 }} />
                    </Button>
                  </Box>
                )}
                {attachmentError && (
                  <Typography variant="caption" color="error" sx={{ mt: 0.5, display: 'block' }}>
                    {attachmentError}
                  </Typography>
                )}
              </Box>

              <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                <Button
                  type="submit"
                  variant="contained"
                  disabled={submitting || !subject || !message}
                  startIcon={submitting ? <CircularProgress size={16} /> : <SendIcon />}
                  sx={{
                    bgcolor: 'primary.main',
                    color: '#ffffff',
                    '&:hover': { bgcolor: 'primary.dark' },
                    textTransform: 'none',
                    fontWeight: 600,
                    px: 3,
                  }}
                >
                  {submitting ? t('support.submitting', 'Submitting...') : t('support.submitTicket', 'Submit Ticket')}
                </Button>
              </Box>
            </Box>
          </CardContent>
        </Card>

        {/* Ticket History */}
        <Typography variant="h6" fontWeight={600} sx={{ mb: 2 }}>
          {t('support.yourTickets', 'Your Tickets')}
        </Typography>

        {/* Filters: search, status, priority */}
        <Box sx={{ display: 'flex', gap: 2, mb: 2, flexWrap: 'wrap', alignItems: 'center' }}>
          <TextField
            size="small"
            placeholder="Search by title..."
            value={ticketSearch}
            onChange={(e) => { setTicketSearch(e.target.value); setTicketPage(0); }}
            sx={{ minWidth: 220, flex: 1 }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ fontSize: 18, color: '#9CA3AF' }} />
                </InputAdornment>
              ),
            }}
          />
          <TextField
            select
            size="small"
            label="Status"
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value); setTicketPage(0); }}
            sx={{ minWidth: 140 }}
          >
            <MenuItem value="ALL">All Status</MenuItem>
            <MenuItem value="OPEN">Open</MenuItem>
            <MenuItem value="IN_PROGRESS">In Progress</MenuItem>
            <MenuItem value="RESOLVED">Resolved</MenuItem>
            <MenuItem value="CLOSED">Closed</MenuItem>
          </TextField>
          <TextField
            select
            size="small"
            label="Priority"
            value={priorityFilter}
            onChange={(e) => { setPriorityFilter(e.target.value); setTicketPage(0); }}
            sx={{ minWidth: 140 }}
          >
            <MenuItem value="ALL">All Priority</MenuItem>
            <MenuItem value="LOW">Low</MenuItem>
            <MenuItem value="MEDIUM">Medium</MenuItem>
            <MenuItem value="HIGH">High</MenuItem>
            <MenuItem value="CRITICAL">Critical</MenuItem>
          </TextField>
        </Box>

        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
            <CircularProgress size={32} />
          </Box>
        ) : filteredTickets.length === 0 ? (
          <Card sx={{ borderRadius: 2, border: (theme) => `1px solid ${theme.palette.divider}` }} elevation={0}>
            <CardContent sx={{ textAlign: 'center', py: 4 }}>
              <Typography color="text.secondary">
                {tickets.length === 0
                  ? t('support.noTickets', 'No tickets submitted yet. Use the form above to create one.')
                  : 'No tickets match the current filters.'}
              </Typography>
            </CardContent>
          </Card>
        ) : (
          <Box sx={{ maxHeight: 500, overflow: 'auto', border: (theme) => `1px solid ${theme.palette.divider}`, borderRadius: 2 }}>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
              {paginatedTickets.map((ticket) => (
                <Card key={ticket.id} sx={{ borderRadius: 0, borderBottom: (theme) => `1px solid ${theme.palette.divider}`, '&:last-child': { borderBottom: 'none' } }} elevation={0}>
                  <CardContent sx={{ p: 2.5 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
                      <Typography variant="subtitle1" fontWeight={600}>
                        {ticket.subject}
                      </Typography>
                      <Chip
                        label={ticket.status.replace('_', ' ')}
                        size="small"
                        color={STATUS_COLORS[ticket.status] || 'default'}
                        sx={{ fontWeight: 600, fontSize: '0.7rem' }}
                      />
                    </Box>

                    <Box sx={{ display: 'flex', gap: 1, mb: 1.5 }}>
                      <Chip label={CATEGORIES.find((c) => c.value === ticket.category)?.label || ticket.category} size="small" variant="outlined" sx={{ fontSize: '0.7rem' }} />
                      <Chip label={ticket.priority} size="small" variant="outlined" sx={{ fontSize: '0.7rem' }} />
                      <Typography variant="caption" color="text.secondary" sx={{ ml: 'auto', alignSelf: 'center' }}>
                        {new Date(ticket.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })}
                      </Typography>
                    </Box>

                    <Typography variant="body2" color="text.secondary" sx={{ mb: ticket.adminResponse || ticket.attachmentFilename ? 1.5 : 0 }}>
                      {ticket.message}
                    </Typography>

                    {/* Attachment display */}
                    {ticket.attachmentFilename && (
                      <Box sx={{
                        display: 'flex', alignItems: 'center', gap: 1, mt: 1, mb: ticket.adminResponse ? 1.5 : 0,
                        p: 1, border: '1px solid', borderColor: 'divider', borderRadius: 1.5, bgcolor: '#f8fafc',
                      }}>
                        <InsertDriveFileIcon sx={{ color: '#6366f1', fontSize: 20 }} />
                        <Box sx={{ flex: 1, minWidth: 0 }}>
                          <Typography variant="body2" sx={{ fontWeight: 600, fontSize: '0.78rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            {ticket.attachmentFilename}
                          </Typography>
                          <Typography variant="caption" sx={{ color: 'text.secondary' }}>
                            {ticket.attachmentSize ? `${(ticket.attachmentSize / 1024).toFixed(1)} KB` : ''}
                          </Typography>
                        </Box>
                        <Button
                          size="small"
                          variant="outlined"
                          onClick={async () => {
                            try {
                              const blob = await supportService.downloadAttachment(ticket.id);
                              const url = window.URL.createObjectURL(new Blob([blob], {
                                type: ticket.attachmentContentType || 'application/octet-stream'
                              }));
                              const link = document.createElement('a');
                              link.href = url;
                              link.download = ticket.attachmentFilename || 'attachment';
                              link.click();
                              window.URL.revokeObjectURL(url);
                            } catch {
                              setError('Failed to download attachment');
                            }
                          }}
                          sx={{ textTransform: 'none', fontSize: '0.7rem', fontWeight: 600, minWidth: 'auto', px: 1.5 }}
                        >
                          Download
                        </Button>
                      </Box>
                    )}

                    {ticket.adminResponse && (
                      <>
                        <Divider sx={{ my: 1.5 }} />
                        <Box sx={{ bgcolor: '#f0f9ff', borderRadius: 1, p: 1.5 }}>
                          <Typography variant="caption" fontWeight={600} color="primary" sx={{ display: 'block', mb: 0.5 }}>
                            {t('support.adminResponse', 'Admin Response')}
                          </Typography>
                          <Typography variant="body2">
                            {ticket.adminResponse}
                          </Typography>
                        </Box>
                      </>
                    )}

                    {/* Reopen button for closed/resolved tickets */}
                    {(ticket.status === 'CLOSED' || ticket.status === 'RESOLVED') && (
                      <Box sx={{ mt: 1.5, display: 'flex', justifyContent: 'flex-end' }}>
                        <Button
                          variant="outlined"
                          size="small"
                          startIcon={reopening === ticket.id ? <CircularProgress size={14} /> : <ReplayIcon />}
                          onClick={() => handleReopenTicket(ticket.id)}
                          disabled={reopening === ticket.id}
                          sx={{
                            textTransform: 'none',
                            fontWeight: 600,
                            fontSize: '0.75rem',
                            borderColor: '#f59e0b',
                            color: '#d97706',
                            '&:hover': { borderColor: '#d97706', bgcolor: '#fffbeb' },
                          }}
                        >
                          {reopening === ticket.id ? 'Reopening...' : 'Reopen Ticket'}
                        </Button>
                      </Box>
                    )}
                  </CardContent>
                </Card>
              ))}
            </Box>
            <TablePagination
              component="div"
              count={filteredTickets.length}
              page={ticketPage}
              onPageChange={(_, newPage) => setTicketPage(newPage)}
              rowsPerPage={ticketsPerPage}
              onRowsPerPageChange={(e) => { setTicketsPerPage(parseInt(e.target.value, 10)); setTicketPage(0); }}
              rowsPerPageOptions={[5, 10, 25]}
              sx={{ borderTop: (theme) => `1px solid ${theme.palette.divider}` }}
            />
          </Box>
        )}
      </Box>
    </Box>
  );
};

export default ContactSupportPage;

import React, { useEffect, useState, useCallback, useRef } from 'react';
import {
  Alert,
  Box,
  Button,
  Chip,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  IconButton,
  InputLabel,
  MenuItem,
  Paper,
  Select,
  Snackbar,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import AddIcon from '@mui/icons-material/Add';
import CancelIcon from '@mui/icons-material/Cancel';
import VisibilityIcon from '@mui/icons-material/Visibility';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import TableChartIcon from '@mui/icons-material/TableChart';
import PreviewIcon from '@mui/icons-material/Preview';
import RemoveCircleOutlineIcon from '@mui/icons-material/RemoveCircleOutline';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import { useNavigate } from 'react-router-dom';
import {
  cycleService,
  type AdhocDutyResponse,
  type AdhocAssigneeInfo,
  type CreateAdhocDutyRequest,
} from '@/services/cycleService';

const PLATOON_NAMES: Record<number, string> = {
  1: 'Platoon I',
  2: 'Platoon II',
  3: 'Platoon III',
  4: 'Platoon IV',
  5: 'Platoon V',
};

const STATUS_COLORS: Record<string, 'success' | 'warning' | 'error' | 'default'> = {
  ACTIVE: 'success',
  COMPLETED: 'default',
  CANCELLED: 'error',
};

type SelectedPerson = AdhocAssigneeInfo & { manuallyAdded?: boolean };

const AdhocDutyPage: React.FC = () => {
  const navigate = useNavigate();
  const [duties, setDuties] = useState<AdhocDutyResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterDate, setFilterDate] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [page, setPage] = useState(0);
  const [rowsPerPage] = useState(20);
  const [snackbar, setSnackbar] = useState<{ open: boolean; message: string; severity: 'success' | 'error' }>({
    open: false, message: '', severity: 'success'
  });

  // Create dialog state
  const [createOpen, setCreateOpen] = useState(false);
  const [createForm, setCreateForm] = useState<CreateAdhocDutyRequest>({
    dutyName: '', date: '', startTime: '', endTime: '', requiredCount: 1
  });
  const [previewPersonnel, setPreviewPersonnel] = useState<AdhocAssigneeInfo[]>([]);
  const [selectedPersonnel, setSelectedPersonnel] = useState<SelectedPerson[]>([]);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewTriggered, setPreviewTriggered] = useState(false);
  const [creating, setCreating] = useState(false);
  const [pickFrom, setPickFrom] = useState('ALL_PLATOONS');
  const [selectedPlatoons, setSelectedPlatoons] = useState<number[]>([]);

  // Search dialog state
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<AdhocAssigneeInfo[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const searchDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Detail dialog
  const [detailOpen, setDetailOpen] = useState(false);
  const [detailDuty, setDetailDuty] = useState<AdhocDutyResponse | null>(null);

  // Cancel confirmation
  const [cancelId, setCancelId] = useState<number | null>(null);

  const fetchDuties = useCallback(async () => {
    setLoading(true);
    try {
      const data = await cycleService.getAdhocDuties(
        filterDate || undefined,
        filterStatus || undefined
      );
      setDuties(data);
    } catch (err) {
      setSnackbar({ open: true, message: 'Failed to fetch adhoc duties', severity: 'error' });
    } finally {
      setLoading(false);
    }
  }, [filterDate, filterStatus]);

  useEffect(() => { fetchDuties(); }, [fetchDuties]);

  const handlePreview = async () => {
    if (!createForm.date || !createForm.startTime || !createForm.endTime || !createForm.requiredCount) return;
    setPreviewLoading(true);
    setPreviewTriggered(true);
    try {
      const data = await cycleService.previewAdhocPersonnel(
        createForm.date, createForm.startTime, createForm.endTime,
        createForm.requiredCount, pickFrom,
        pickFrom === 'SPECIFIC_PLATOONS' ? selectedPlatoons : undefined
      );
      setPreviewPersonnel(data);
      setSelectedPersonnel(data.map(p => ({ ...p, manuallyAdded: false })));
    } catch (err) {
      setSnackbar({ open: true, message: 'Failed to preview personnel', severity: 'error' });
    } finally {
      setPreviewLoading(false);
    }
  };

  const handleRemovePersonnel = (personId: number) => {
    setSelectedPersonnel(prev => prev.filter(p => p.personId !== personId));
  };

  const handleAddPersonnel = (person: AdhocAssigneeInfo) => {
    if (selectedPersonnel.some(p => p.personId === person.personId)) return;
    setSelectedPersonnel(prev => [...prev, { ...person, manuallyAdded: true }]);
  };

  // Search with debounce
  const handleSearchQueryChange = (value: string) => {
    setSearchQuery(value);
    if (searchDebounceRef.current) {
      clearTimeout(searchDebounceRef.current);
    }
    if (value.length >= 2) {
      searchDebounceRef.current = setTimeout(() => {
        performSearch(value);
      }, 300);
    } else {
      setSearchResults([]);
    }
  };

  const performSearch = async (query: string) => {
    if (!createForm.date || !createForm.startTime || !createForm.endTime) return;
    setSearchLoading(true);
    try {
      const results = await cycleService.searchAdhocPersonnel(
        query, createForm.date, createForm.startTime, createForm.endTime
      );
      setSearchResults(results);
    } catch (err) {
      setSnackbar({ open: true, message: 'Search failed', severity: 'error' });
    } finally {
      setSearchLoading(false);
    }
  };

  const handleCreate = async () => {
    setCreating(true);
    try {
      const request: CreateAdhocDutyRequest = {
        ...createForm,
        pickFrom,
        platoonIds: pickFrom === 'SPECIFIC_PLATOONS' ? selectedPlatoons : undefined,
        personnelIds: selectedPersonnel.map(p => p.personId),
      };
      await cycleService.createAdhocDuty(request);
      setSnackbar({ open: true, message: 'Adhoc duty created successfully', severity: 'success' });
      setCreateOpen(false);
      resetCreateForm();
      fetchDuties();
    } catch (err: any) {
      setSnackbar({ open: true, message: err.response?.data?.message || 'Failed to create', severity: 'error' });
    } finally {
      setCreating(false);
    }
  };

  const handleCancel = async () => {
    if (!cancelId) return;
    try {
      await cycleService.cancelAdhocDuty(cancelId);
      setSnackbar({ open: true, message: 'Adhoc duty cancelled', severity: 'success' });
      setCancelId(null);
      fetchDuties();
    } catch (err) {
      setSnackbar({ open: true, message: 'Failed to cancel', severity: 'error' });
    }
  };

  const handleViewDetail = async (id: number) => {
    try {
      const detail = await cycleService.getAdhocDutyById(id);
      setDetailDuty(detail);
      setDetailOpen(true);
    } catch (err) {
      setSnackbar({ open: true, message: 'Failed to fetch details', severity: 'error' });
    }
  };

  const handleDownload = async (id: number, format: 'pdf' | 'excel') => {
    try {
      const blob = format === 'pdf'
        ? await cycleService.downloadAdhocPdf(id)
        : await cycleService.downloadAdhocExcel(id);
      const url = URL.createObjectURL(new Blob([blob]));
      const link = document.createElement('a');
      link.href = url;
      link.download = `adhoc-duty-${id}.${format === 'pdf' ? 'pdf' : 'xlsx'}`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      setSnackbar({ open: true, message: 'Download failed', severity: 'error' });
    }
  };

  const resetCreateForm = () => {
    setCreateForm({ dutyName: '', date: '', startTime: '', endTime: '', requiredCount: 1 });
    setPreviewPersonnel([]);
    setSelectedPersonnel([]);
    setPreviewTriggered(false);
    setPickFrom('ALL_PLATOONS');
    setSelectedPlatoons([]);
    setSearchQuery('');
    setSearchResults([]);
  };

  const selectedCount = selectedPersonnel.length;
  const requiredCount = createForm.requiredCount;
  const countMatches = selectedCount === requiredCount;

  const paginatedDuties = duties.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box sx={{ background: 'linear-gradient(135deg, #1a1e4a 0%, #2d3561 100%)', color: 'white', p: 2, borderRadius: 1, mb: 3, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Stack direction="row" alignItems="center" spacing={2}>
          <Button startIcon={<ArrowBackIcon />} onClick={() => navigate('/schedules')} sx={{ color: 'white' }}>
            Back to Schedules
          </Button>
          <Typography variant="h5" fontWeight="bold">Adhoc Duties</Typography>
        </Stack>
        <Button variant="contained" startIcon={<AddIcon />} onClick={() => setCreateOpen(true)}
          sx={{ bgcolor: 'white', color: '#1a1e4a', '&:hover': { bgcolor: '#e8eaf6' } }}>
          Create Adhoc Duty
        </Button>
      </Box>

      {/* Filters */}
      <Stack direction="row" spacing={2} sx={{ mb: 2 }}>
        <TextField type="date" label="Date" value={filterDate} onChange={(e) => setFilterDate(e.target.value)}
          InputLabelProps={{ shrink: true }} size="small" sx={{ width: 200 }} />
        <FormControl size="small" sx={{ width: 180 }}>
          <InputLabel>Status</InputLabel>
          <Select value={filterStatus} label="Status" onChange={(e) => setFilterStatus(e.target.value)}>
            <MenuItem value="">All</MenuItem>
            <MenuItem value="ACTIVE">Active</MenuItem>
            <MenuItem value="COMPLETED">Completed</MenuItem>
            <MenuItem value="CANCELLED">Cancelled</MenuItem>
          </Select>
        </FormControl>
        <Typography variant="body2" sx={{ alignSelf: 'center', color: 'text.secondary' }}>
          Total: {duties.length} records
        </Typography>
      </Stack>

      {/* Table */}
      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}><CircularProgress /></Box>
      ) : (
        <TableContainer component={Paper}>
          <Table size="small">
            <TableHead>
              <TableRow sx={{ bgcolor: '#f5f5f5' }}>
                <TableCell>ID</TableCell>
                <TableCell>Duty Name</TableCell>
                <TableCell>Date</TableCell>
                <TableCell>Time</TableCell>
                <TableCell>Location</TableCell>
                <TableCell align="center">Required</TableCell>
                <TableCell align="center">Actual</TableCell>
                <TableCell>Status</TableCell>
                <TableCell align="center">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {paginatedDuties.map((duty) => (
                <TableRow key={duty.id} hover>
                  <TableCell>{duty.id}</TableCell>
                  <TableCell>{duty.dutyName}</TableCell>
                  <TableCell>{duty.date}</TableCell>
                  <TableCell>{duty.startTime} - {duty.endTime}</TableCell>
                  <TableCell>{duty.location || '-'}</TableCell>
                  <TableCell align="center">{duty.requiredCount}</TableCell>
                  <TableCell align="center">{duty.actualCount}</TableCell>
                  <TableCell>
                    <Chip label={duty.status} size="small" color={STATUS_COLORS[duty.status] || 'default'} />
                  </TableCell>
                  <TableCell align="center">
                    <Stack direction="row" spacing={0.5} justifyContent="center">
                      <Tooltip title="View Details">
                        <IconButton size="small" onClick={() => handleViewDetail(duty.id)}><VisibilityIcon fontSize="small" /></IconButton>
                      </Tooltip>
                      {duty.status === 'ACTIVE' && (
                        <Tooltip title="Cancel">
                          <IconButton size="small" color="error" onClick={() => setCancelId(duty.id)}><CancelIcon fontSize="small" /></IconButton>
                        </Tooltip>
                      )}
                      <Tooltip title="Download PDF">
                        <IconButton size="small" onClick={() => handleDownload(duty.id, 'pdf')}><PictureAsPdfIcon fontSize="small" /></IconButton>
                      </Tooltip>
                      <Tooltip title="Download Excel">
                        <IconButton size="small" onClick={() => handleDownload(duty.id, 'excel')}><TableChartIcon fontSize="small" /></IconButton>
                      </Tooltip>
                    </Stack>
                  </TableCell>
                </TableRow>
              ))}
              {paginatedDuties.length === 0 && (
                <TableRow><TableCell colSpan={9} align="center">No adhoc duties found</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
          <TablePagination rowsPerPageOptions={[20]} component="div" count={duties.length}
            rowsPerPage={rowsPerPage} page={page} onPageChange={(_, p) => setPage(p)} />
        </TableContainer>
      )}

      {/* Create Dialog */}
      <Dialog open={createOpen} onClose={() => { setCreateOpen(false); resetCreateForm(); }} maxWidth="md" fullWidth>
        <DialogTitle>Create Adhoc Duty</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField label="Duty Name" value={createForm.dutyName} required
              onChange={(e) => setCreateForm({ ...createForm, dutyName: e.target.value })} />
            <Stack direction="row" spacing={2}>
              <TextField type="date" label="Date" value={createForm.date} required fullWidth
                InputLabelProps={{ shrink: true }}
                inputProps={{ min: new Date().toISOString().split('T')[0] }}
                onChange={(e) => setCreateForm({ ...createForm, date: e.target.value })} />
              <TextField type="time" label="Start Time" value={createForm.startTime} required fullWidth
                InputLabelProps={{ shrink: true }}
                onChange={(e) => setCreateForm({ ...createForm, startTime: e.target.value })} />
              <TextField type="time" label="End Time" value={createForm.endTime} required fullWidth
                InputLabelProps={{ shrink: true }}
                onChange={(e) => setCreateForm({ ...createForm, endTime: e.target.value })} />
            </Stack>
            <Stack direction="row" spacing={2}>
              <TextField label="Location" value={createForm.location || ''} fullWidth
                onChange={(e) => setCreateForm({ ...createForm, location: e.target.value })} />
              <TextField type="number" label="Required Count" value={createForm.requiredCount} required
                inputProps={{ min: 1 }} sx={{ width: 180 }}
                onChange={(e) => setCreateForm({ ...createForm, requiredCount: parseInt(e.target.value) || 1 })} />
            </Stack>
            <Stack direction="row" spacing={2} alignItems="center">
              <FormControl sx={{ width: 200 }}>
                <InputLabel>Pick From</InputLabel>
                <Select value={pickFrom} label="Pick From" onChange={(e) => setPickFrom(e.target.value)}>
                  <MenuItem value="ALL_PLATOONS">All Platoons</MenuItem>
                  <MenuItem value="SPECIFIC_PLATOONS">Specific Platoons</MenuItem>
                </Select>
              </FormControl>
              {pickFrom === 'SPECIFIC_PLATOONS' && (
                <Stack direction="row" spacing={1}>
                  {[1,2,3,4,5].map(id => (
                    <Chip key={id} label={PLATOON_NAMES[id]}
                      color={selectedPlatoons.includes(id) ? 'primary' : 'default'}
                      onClick={() => setSelectedPlatoons(prev =>
                        prev.includes(id) ? prev.filter(p => p !== id) : [...prev, id]
                      )} />
                  ))}
                </Stack>
              )}
              <Button variant="outlined" startIcon={<PreviewIcon />} onClick={handlePreview}
                disabled={!createForm.date || !createForm.startTime || !createForm.endTime || !createForm.requiredCount}>
                Preview Personnel
              </Button>
            </Stack>

            {previewLoading && <CircularProgress size={24} />}

            {/* Selected Personnel Table */}
            {previewTriggered && selectedPersonnel.length > 0 && (
              <Box>
                {selectedPersonnel.length < createForm.requiredCount && (
                  <Alert severity="warning" sx={{ mb: 1 }}>
                    Only {selectedPersonnel.length} of {createForm.requiredCount} personnel selected
                  </Alert>
                )}
                <TableContainer component={Paper} variant="outlined" sx={{ maxHeight: 300 }}>
                  <Table size="small" stickyHeader>
                    <TableHead>
                      <TableRow>
                        <TableCell>Name</TableCell>
                        <TableCell>Badge ID</TableCell>
                        <TableCell>Section</TableCell>
                        <TableCell>Current Shift</TableCell>
                        <TableCell>Current Duty</TableCell>
                        <TableCell align="center">Disruption (min)</TableCell>
                        <TableCell>Source</TableCell>
                        <TableCell align="center">Actions</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {selectedPersonnel.map((p) => (
                        <TableRow key={p.personId}>
                          <TableCell>{p.personName}</TableCell>
                          <TableCell>{p.badgeId}</TableCell>
                          <TableCell>{p.section}</TableCell>
                          <TableCell><Chip size="small" label={p.originalShift}
                            sx={{ bgcolor: p.originalShift === 'DAY' ? '#E8F5E9' : p.originalShift === 'AFTERNOON' ? '#F3E5F5' : '#E3F2FD' }} /></TableCell>
                          <TableCell>{p.originalDutyName}</TableCell>
                          <TableCell align="center">{p.disruptionScore}</TableCell>
                          <TableCell>
                            <Chip size="small" label={p.manuallyAdded ? 'Manual' : 'Auto'}
                              color={p.manuallyAdded ? 'secondary' : 'default'} variant="outlined" />
                          </TableCell>
                          <TableCell align="center">
                            <Tooltip title="Remove">
                              <IconButton size="small" color="error" onClick={() => handleRemovePersonnel(p.personId)}>
                                <RemoveCircleOutlineIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
                <Button variant="outlined" startIcon={<PersonAddIcon />} onClick={() => setSearchOpen(true)} sx={{ mt: 1 }}>
                  Add Manually
                </Button>
              </Box>
            )}

            {/* Empty state after preview triggered */}
            {previewTriggered && !previewLoading && selectedPersonnel.length === 0 && (
              <Box>
                <Alert severity="info">
                  No personnel selected. Use &apos;Preview Personnel&apos; to auto-pick or &apos;Add Manually&apos; to search.
                </Alert>
                <Button variant="outlined" startIcon={<PersonAddIcon />} onClick={() => setSearchOpen(true)} sx={{ mt: 1 }}>
                  Add Manually
                </Button>
              </Box>
            )}
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => { setCreateOpen(false); resetCreateForm(); }}>Cancel</Button>
          {previewTriggered && (
            <Typography variant="body2" sx={{
              mr: 1,
              color: countMatches ? 'success.main' : 'warning.main',
              fontWeight: 'bold'
            }}>
              {selectedCount}/{requiredCount} selected
            </Typography>
          )}
          <Button variant="contained" onClick={handleCreate}
            disabled={creating || selectedPersonnel.length !== createForm.requiredCount || selectedPersonnel.length === 0}>
            {creating ? <CircularProgress size={20} /> : 'Confirm & Create'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Search Personnel Dialog */}
      <Dialog open={searchOpen} onClose={() => { setSearchOpen(false); setSearchQuery(''); setSearchResults([]); }} maxWidth="sm" fullWidth>
        <DialogTitle>Search Personnel</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField
              label="Search by name or badge ID"
              value={searchQuery}
              onChange={(e) => handleSearchQueryChange(e.target.value)}
              placeholder="Type at least 2 characters..."
              autoFocus
            />
            {searchLoading && <CircularProgress size={24} sx={{ alignSelf: 'center' }} />}
            {searchResults.length > 0 && (
              <TableContainer component={Paper} variant="outlined" sx={{ maxHeight: 300 }}>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      <TableCell>Name</TableCell>
                      <TableCell>Badge ID</TableCell>
                      <TableCell>Section</TableCell>
                      <TableCell>Shift</TableCell>
                      <TableCell align="center">Action</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {searchResults.map((person) => {
                      const alreadySelected = selectedPersonnel.some(p => p.personId === person.personId);
                      return (
                        <TableRow key={person.personId}>
                          <TableCell>{person.personName}</TableCell>
                          <TableCell>{person.badgeId}</TableCell>
                          <TableCell>{person.section}</TableCell>
                          <TableCell>{person.originalShift}</TableCell>
                          <TableCell align="center">
                            {alreadySelected ? (
                              <Chip size="small" label="Already selected" color="default" />
                            ) : (
                              <Button size="small" variant="outlined" onClick={() => handleAddPersonnel(person)}>
                                Add
                              </Button>
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
            {!searchLoading && searchQuery.length >= 2 && searchResults.length === 0 && (
              <Typography variant="body2" color="text.secondary" align="center">
                No results found
              </Typography>
            )}
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => { setSearchOpen(false); setSearchQuery(''); setSearchResults([]); }}>Close</Button>
        </DialogActions>
      </Dialog>

      {/* Detail Dialog */}
      <Dialog open={detailOpen} onClose={() => setDetailOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>Adhoc Duty Details</DialogTitle>
        <DialogContent>
          {detailDuty && (
            <Stack spacing={2} sx={{ mt: 1 }}>
              <Stack direction="row" spacing={4}>
                <Typography><strong>Name:</strong> {detailDuty.dutyName}</Typography>
                <Typography><strong>Date:</strong> {detailDuty.date}</Typography>
                <Typography><strong>Time:</strong> {detailDuty.startTime} - {detailDuty.endTime}</Typography>
              </Stack>
              <Stack direction="row" spacing={4}>
                <Typography><strong>Location:</strong> {detailDuty.location || '-'}</Typography>
                <Typography><strong>Status:</strong> <Chip size="small" label={detailDuty.status} color={STATUS_COLORS[detailDuty.status] || 'default'} /></Typography>
                <Typography><strong>Personnel:</strong> {detailDuty.actualCount}/{detailDuty.requiredCount}</Typography>
              </Stack>
              {detailDuty.assignees && detailDuty.assignees.length > 0 && (
                <TableContainer component={Paper} variant="outlined">
                  <Table size="small">
                    <TableHead>
                      <TableRow sx={{ bgcolor: '#f5f5f5' }}>
                        <TableCell>#</TableCell>
                        <TableCell>Name</TableCell>
                        <TableCell>Badge ID</TableCell>
                        <TableCell>Designation</TableCell>
                        <TableCell>Section</TableCell>
                        <TableCell>Original Duty</TableCell>
                        <TableCell>Original Shift</TableCell>
                        <TableCell>Status</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {detailDuty.assignees.map((a, idx) => (
                        <TableRow key={a.personId}>
                          <TableCell>{idx + 1}</TableCell>
                          <TableCell>{a.personName}</TableCell>
                          <TableCell>{a.badgeId}</TableCell>
                          <TableCell>{a.designation}</TableCell>
                          <TableCell>{a.section}</TableCell>
                          <TableCell>{a.originalDutyName}</TableCell>
                          <TableCell>{a.originalShift}</TableCell>
                          <TableCell><Chip size="small" label={a.status} /></TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}
              <Stack direction="row" spacing={1}>
                <Button startIcon={<PictureAsPdfIcon />} onClick={() => handleDownload(detailDuty.id, 'pdf')}>
                  Download PDF
                </Button>
                <Button startIcon={<TableChartIcon />} onClick={() => handleDownload(detailDuty.id, 'excel')}>
                  Download Excel
                </Button>
              </Stack>
            </Stack>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDetailOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>

      {/* Cancel Confirmation */}
      <Dialog open={cancelId !== null} onClose={() => setCancelId(null)}>
        <DialogTitle>Cancel Adhoc Duty</DialogTitle>
        <DialogContent>
          <Typography>Are you sure you want to cancel this adhoc duty? All assigned personnel will be released back to their regular duties.</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setCancelId(null)}>No, Keep It</Button>
          <Button variant="contained" color="error" onClick={handleCancel}>Yes, Cancel</Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar */}
      <Snackbar open={snackbar.open} autoHideDuration={4000} onClose={() => setSnackbar(s => ({ ...s, open: false }))}>
        <Alert severity={snackbar.severity}>{snackbar.message}</Alert>
      </Snackbar>
    </Box>
  );
};

export default AdhocDutyPage;

import React from 'react';
import {
  Box,
  IconButton,
  Typography,
  Button,
  Select,
  MenuItem,
  TextField,
  InputAdornment,
  FormControl,
  Stack,
  useMediaQuery,
  useTheme,
  type SelectChangeEvent,
} from '@mui/material';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import SearchIcon from '@mui/icons-material/Search';
import { useTranslation } from 'react-i18next';
import type { NavigationBarProps, ViewMode } from '../../types/schedule';

/**
 * NavigationBar — Two-row enterprise toolbar.
 * Row 1: Date navigation + Today | View mode segmented control | spacer | Group filter
 * Row 2: Full-width search bar
 */
const NavigationBar: React.FC<NavigationBarProps> = ({
  viewMode,
  onViewModeChange,
  dateRange,
  onNavigate,
  groupFilter,
  onGroupFilterChange,
  groups,
  searchQuery,
  onSearchChange,
}) => {
  const { t } = useTranslation();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));

  const handleGroupChange = (event: SelectChangeEvent<string>) => {
    onGroupFilterChange(event.target.value);
  };

  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onSearchChange(event.target.value);
  };

  const viewModes: ViewMode[] = ['day', 'week', 'month'];

  return (
    <Box
      sx={{
        px: 3,
        py: 1.5,
        backgroundColor: '#FFFFFF',
        borderBottom: '1px solid #E5E7EB',
        flexShrink: 0,
      }}
    >
      {/* Row 1: Navigation controls */}
      <Stack
        direction={isMobile ? 'column' : 'row'}
        spacing={2}
        alignItems={isMobile ? 'stretch' : 'center'}
      >
        {/* Date Navigation */}
        <Stack direction="row" spacing={0.5} alignItems="center">
          <IconButton
            size="small"
            onClick={() => onNavigate('prev')}
            aria-label="Previous period"
            sx={{
              color: '#374151',
              border: '1px solid #E5E7EB',
              borderRadius: '8px',
              width: 32,
              height: 32,
              '&:hover': { backgroundColor: '#F9FAFB' },
            }}
          >
            <ChevronLeftIcon sx={{ fontSize: 18 }} />
          </IconButton>

          <Typography
            variant="body2"
            sx={{
              fontWeight: 600,
              fontSize: '0.875rem',
              color: '#111827',
              minWidth: 180,
              textAlign: 'center',
              px: 1,
            }}
          >
            {dateRange.label}
          </Typography>

          <IconButton
            size="small"
            onClick={() => onNavigate('next')}
            aria-label="Next period"
            sx={{
              color: '#374151',
              border: '1px solid #E5E7EB',
              borderRadius: '8px',
              width: 32,
              height: 32,
              '&:hover': { backgroundColor: '#F9FAFB' },
            }}
          >
            <ChevronRightIcon sx={{ fontSize: 18 }} />
          </IconButton>

          <Button
            variant="outlined"
            size="small"
            onClick={() => onNavigate('today')}
            sx={{
              textTransform: 'none',
              fontWeight: 500,
              fontSize: '0.8125rem',
              borderColor: '#E5E7EB',
              color: '#374151',
              borderRadius: '8px',
              ml: 1,
              px: 1.5,
              py: 0.5,
              '&:hover': {
                backgroundColor: '#F9FAFB',
                borderColor: '#D1D5DB',
              },
            }}
          >
            {t('schedules.today', 'Today')}
          </Button>
        </Stack>

        {/* Segmented View Mode Control */}
        <Box
          sx={{
            display: 'inline-flex',
            backgroundColor: '#F3F4F6',
            borderRadius: '10px',
            padding: '3px',
            gap: '2px',
          }}
        >
          {viewModes.map((mode) => (
            <Button
              key={mode}
              size="small"
              onClick={() => onViewModeChange(mode)}
              aria-label={`${mode} view`}
              sx={{
                textTransform: 'capitalize',
                fontWeight: viewMode === mode ? 600 : 400,
                fontSize: '0.8125rem',
                px: 2,
                py: 0.5,
                minWidth: 56,
                borderRadius: '8px',
                color: viewMode === mode ? '#FFFFFF' : '#6B7280',
                backgroundColor: viewMode === mode ? '#2563EB' : 'transparent',
                boxShadow: viewMode === mode ? '0 1px 3px rgba(37, 99, 235, 0.3)' : 'none',
                '&:hover': {
                  backgroundColor: viewMode === mode ? '#1D4ED8' : '#E5E7EB',
                },
              }}
            >
              {mode}
            </Button>
          ))}
        </Box>

        {/* Spacer for pushing right elements */}
        <Box sx={{ flex: 1 }} />

        {/* Group Filter */}
        <FormControl size="small" variant="outlined" sx={{ minWidth: 160 }}>
          <Select
            value={groupFilter}
            onChange={handleGroupChange}
            displayEmpty
            sx={{
              fontSize: '0.8125rem',
              borderRadius: '8px',
              color: '#374151',
              '& .MuiOutlinedInput-notchedOutline': {
                borderColor: '#E5E7EB',
              },
              '&:hover .MuiOutlinedInput-notchedOutline': {
                borderColor: '#D1D5DB',
              },
              '& .MuiSelect-select': {
                py: 0.75,
                px: 1.5,
              },
            }}
          >
            <MenuItem value="all">All Groups</MenuItem>
            {groups.map((group) => (
              <MenuItem key={group} value={group}>
                {group}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </Stack>

      {/* Row 2: Search bar + inline color legend */}
      <Stack direction="row" spacing={2} alignItems="center" sx={{ mt: 1.5 }}>
        <TextField
          size="small"
          variant="outlined"
          placeholder={t('app.search', 'Search employees by name, ID, or email...')}
          value={searchQuery}
          onChange={handleSearchChange}
          sx={{
            flex: 1,
            '& .MuiOutlinedInput-root': {
              borderRadius: '10px',
              fontSize: '0.875rem',
              backgroundColor: '#F9FAFB',
              '& fieldset': {
                borderColor: '#E5E7EB',
              },
              '&:hover fieldset': {
                borderColor: '#D1D5DB',
              },
              '&.Mui-focused fieldset': {
                borderColor: '#2563EB',
                borderWidth: '1.5px',
              },
              '& input': {
                py: 1,
                px: 1,
              },
            },
          }}
          slotProps={{
            input: {
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ fontSize: 20, color: '#9CA3AF' }} />
                </InputAdornment>
              ),
            },
          }}
        />

        {/* Inline Color Legend */}
        <Stack direction="row" spacing={1.5} alignItems="center" sx={{ flexShrink: 0 }}>
          {[
            { label: 'Morning', bg: '#DBEAFE', border: '#1E40AF', text: '#1E40AF' },
            { label: 'Afternoon', bg: '#D1FAE5', border: '#065F46', text: '#065F46' },
            { label: 'Night', bg: '#FEF3C7', border: '#92400E', text: '#92400E' },
            { label: 'Special', bg: '#EDE9FE', border: '#5B21B6', text: '#5B21B6' },
          ].map((item) => (
            <Box key={item.label} sx={{ display: 'inline-flex', alignItems: 'center', gap: 0.5 }}>
              <Box
                sx={{
                  width: 10,
                  height: 10,
                  borderRadius: '3px',
                  backgroundColor: item.bg,
                  borderLeft: `2.5px solid ${item.border}`,
                }}
              />
              <Typography variant="caption" sx={{ fontSize: '0.7rem', color: item.text, fontWeight: 500, whiteSpace: 'nowrap' }}>
                {item.label}
              </Typography>
            </Box>
          ))}
        </Stack>
      </Stack>
    </Box>
  );
};

export default NavigationBar;

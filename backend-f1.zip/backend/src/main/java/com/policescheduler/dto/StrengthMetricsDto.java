package com.policescheduler.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StrengthMetricsDto {
    private List<String> designations;
    private Map<String, Integer> sanctionedStrength;
    private Map<String, Integer> presentStrength;
    private Map<String, Integer> vacancy;
    private Integer totalSanctioned;
    private Integer totalPresent;
    private Integer totalVacancy;
}

import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import {
  Box,
  Card,
  CardActionArea,
  Typography,
  Stack,
  Chip,
  IconButton,
  TextField,
  Autocomplete,
  Collapse,
  Button,
  CircularProgress,
  Snackbar,
  Alert,
  InputAdornment,
  Tooltip,
  Paper,
  List,
  ListItemButton,
  ListItemText,
  Divider,
  Badge,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Tab,
  Tabs,
} from '@mui/material';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import BadgeIcon from '@mui/icons-material/Badge';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { useTranslation } from 'react-i18next';
import PageHeader from '@/components/common/PageHeader';
import Carousel from '@/components/common/Carousel';
import Form168TableView from '@/components/Form168TableView';
import {
  sectionChartService,
  type SectionChartData,
  type DutyCard,
  type SubDutyGroup,
  type ChartPersonnel,
  type PersonnelSearchResult,
} from '@/services/sectionChartService';
import { leaveService } from '@/services/leaveService';
import api from '@/services/api';
import type { LeaveRequestDto, CreateLeaveRequest } from '@/types';

// ===== Section Definitions =====
const SECTIONS = [
  { id: 'A', name: 'Section A', description: 'Fixed / Essential Duties', color: '#312e81', bgColor: '#eef2ff' },
  { id: 'B', name: 'Section B', description: 'Office / Support Duties', color: '#0d9488', bgColor: '#f0fdfa' },
  { id: 'C', name: 'Section C', description: 'Guard-I (Rotation)', color: '#7c3aed', bgColor: '#f5f3ff' },
  { id: 'D', name: 'Section D', description: 'Guard-II (Rotation)', color: '#dc2626', bgColor: '#fef2f2' },
  { id: 'E', name: 'Section E', description: 'Check Post Duty', color: '#d97706', bgColor: '#fffbeb' },
  { id: 'F', name: 'Section F', description: 'VIP Escorts / Prisoner Escort', color: '#2563eb', bgColor: '#eff6ff' },
  { id: 'G', name: 'Section G', description: 'Striking Force / Follow Up', color: '#059669', bgColor: '#ecfdf5' },
  { id: 'O', name: 'Section O', description: "Officer's Duty", color: '#be185d', bgColor: '#fdf2f8' },
  { id: 'MT', name: 'MT Section', description: 'Motor Transport / Drivers', color: '#ea580c', bgColor: '#fff7ed' },
];

// ===== Leave Categories (from Form 168) =====
const LEAVE_CATEGORIES = [
  { name: 'LEAVE (CL,CML,PL,EL)', description: 'Casual / Medical / Privilege / Earned Leave' },
  { name: 'ABSENT', description: 'Absent without leave' },
  { name: 'SUSPENSION', description: 'Under suspension' },
  { name: 'PERMISSION / RH TO RPI, RSI AND', description: 'Permission / Restricted Holiday' },
  { name: 'SICK', description: 'Sick leave' },
  { name: 'WEEKLY OFF', description: 'Weekly off duty' },
];

// ===== Main Page Component =====
const AssignDutiesPage: React.FC = () => {
  const { t } = useTranslation();
  const [selectedSection, setSelectedSection] = useState<string | null>('A');
  const [chartData, setChartData] = useState<SectionChartData | null>(null);
  const [selectedDutyTypeId, setSelectedDutyTypeId] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [snackbar, setSnackbar] = useState<{ open: boolean; message: string; severity: 'success' | 'error' }>({
    open: false, message: '', severity: 'success',
  });
  const [sidebarFilter, setSidebarFilter] = useState('');
  const [showAddDutyType, setShowAddDutyType] = useState(false);
  const [newDutyTypeName, setNewDutyTypeName] = useState('');
  const [activeTab, setActiveTab] = useState(0); // 0 = Duty Management, 1 = Leave Management
  const [selectedLeaveCategory, setSelectedLeaveCategory] = useState<string>(LEAVE_CATEGORIES[0].name);
  const [deleteDialog, setDeleteDialog] = useState<{
    open: boolean;
    type: 'dutyType' | 'subDuty';
    name: string;
    dutyTypeId?: number;
    subDutyName?: string;
  }>({ open: false, type: 'dutyType', name: '' });

  // Reassignment state
  const [reassignDialog, setReassignDialog] = useState<{
    open: boolean;
    person: ChartPersonnel | null;
  }>({ open: false, person: null });
  const [reassignForm, setReassignForm] = useState({ replacementId: 0, startDate: '', endDate: '' });
  const [reassignSaving, setReassignSaving] = useState(false);
  const [activeReassignments, setActiveReassignments] = useState<Array<{
    id: number; leavePersonId: number; replacementPersonId: number;
    leavePersonName: string; leavePersonBadgeId: string;
    replacementPersonName: string; replacementPersonBadgeId: string;
    dutyType: string; dutyLocation: string;
    startDate: string; endDate: string; days: number; status: string;
  }>>([]);

  // Load chart data when section changes
  useEffect(() => {
    if (selectedSection) {
      loadChartData(selectedSection);
    } else {
      setChartData(null);
      setSelectedDutyTypeId(null);
    }
  }, [selectedSection]);

  const loadChartData = async (sectionCode: string, showSpinner = true) => {
    if (showSpinner) setLoading(true);
    try {
      const data = await sectionChartService.getChart(sectionCode);
      setChartData(data);
      // Auto-select first duty type if none selected
      if (data.dutyCards.length > 0 && !selectedDutyTypeId) {
        setSelectedDutyTypeId(data.dutyCards[0].dutyTypeId);
      }
      // Load active reassignments for this section
      try {
        const reassignRes = await api.get<typeof activeReassignments>(`/api/duty-reassignments`, { params: { sectionCode } });
        setActiveReassignments(reassignRes.data);
      } catch { setActiveReassignments([]); }
    } catch (err) {
      setSnackbar({ open: true, message: 'Failed to load section data', severity: 'error' });
    } finally {
      setLoading(false);
    }
  };

  const handleSectionClick = (sectionId: string) => {
    setSelectedSection(sectionId);
    setSelectedDutyTypeId(null);
    setSidebarFilter('');
    setShowAddDutyType(false);
  };

  const handleAssignPerson = async (personnelId: number, dutyTypeId: number, subDuty?: string | null) => {
    if (!selectedSection) return;
    setSaving(true);
    try {
      await sectionChartService.assign({
        personnelId,
        dutyTypeId,
        sectionCode: selectedSection,
        subDuty: subDuty || null,
      });
      setSnackbar({ open: true, message: '✓ Person assigned successfully', severity: 'success' });
      await loadChartData(selectedSection, false);
    } catch (err) {
      setSnackbar({ open: true, message: 'Failed to assign person', severity: 'error' });
    } finally {
      setSaving(false);
    }
  };

  const handleUnassignPerson = async (personnelId: number) => {
    if (!selectedSection) return;
    setSaving(true);
    try {
      await sectionChartService.unassign({ personnelId });
      setSnackbar({ open: true, message: '✓ Person removed from duty', severity: 'success' });
      await loadChartData(selectedSection, false);
    } catch (err) {
      setSnackbar({ open: true, message: 'Failed to remove person', severity: 'error' });
    } finally {
      setSaving(false);
    }
  };

  const handleAddDutyType = async () => {
    if (!selectedSection || !newDutyTypeName.trim()) return;
    setSaving(true);
    try {
      const maxSort = chartData?.dutyCards.length ?? 0;
      await sectionChartService.createDutyType({
        name: newDutyTypeName.trim().toUpperCase(),
        section: selectedSection,
        sortOrder: maxSort + 1,
        level: 'PARENT',
      });
      setSnackbar({ open: true, message: '✓ Duty type created', severity: 'success' });
      setNewDutyTypeName('');
      setShowAddDutyType(false);
      await loadChartData(selectedSection, false);
    } catch (err) {
      setSnackbar({ open: true, message: 'Failed to create duty type', severity: 'error' });
    } finally {
      setSaving(false);
    }
  };

  const handleAddSubDuty = async (parentDutyTypeId: number, subDutyName: string) => {
    if (!selectedSection || !subDutyName.trim()) return;
    setSaving(true);
    try {
      // Sub-duty is just a duty_location value. 
      // We validate it via the backend, then it becomes available when assigning personnel.
      await sectionChartService.addSubDuty({
        subDutyName: subDutyName.trim().toUpperCase(),
        parentDutyTypeId,
      });
      setSnackbar({ open: true, message: '✓ Sub duty added. Assign personnel to persist.', severity: 'success' });
      // Reload to refresh (won't show empty sub-duty until someone is assigned)
      await loadChartData(selectedSection, false);
    } catch (err) {
      setSnackbar({ open: true, message: 'Failed to add sub duty', severity: 'error' });
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteDutyType = (dutyTypeId: number, name: string) => {
    setDeleteDialog({ open: true, type: 'dutyType', name, dutyTypeId });
  };

  const handleDeleteSubDuty = (dutyTypeId: number, subDutyName: string) => {
    setDeleteDialog({ open: true, type: 'subDuty', name: subDutyName, dutyTypeId, subDutyName });
  };

  const confirmDelete = async () => {
    if (!selectedSection) return;
    setSaving(true);
    setDeleteDialog((d) => ({ ...d, open: false }));
    try {
      if (deleteDialog.type === 'dutyType' && deleteDialog.dutyTypeId) {
        await sectionChartService.deleteDutyType(deleteDialog.dutyTypeId);
        setSnackbar({ open: true, message: `✓ "${deleteDialog.name}" deleted`, severity: 'success' });
        // If deleted the currently selected, clear selection
        if (selectedDutyTypeId === deleteDialog.dutyTypeId) {
          setSelectedDutyTypeId(null);
        }
      } else if (deleteDialog.type === 'subDuty' && deleteDialog.dutyTypeId && deleteDialog.subDutyName) {
        await sectionChartService.deleteSubDuty(deleteDialog.dutyTypeId, deleteDialog.subDutyName);
        setSnackbar({ open: true, message: `✓ Sub duty "${deleteDialog.name}" deleted`, severity: 'success' });
      }
      await loadChartData(selectedSection, false);
    } catch (err) {
      setSnackbar({ open: true, message: 'Failed to delete', severity: 'error' });
    } finally {
      setSaving(false);
    }
  };

  // Get the selected duty card
  const selectedCard = chartData?.dutyCards.find((c) => c.dutyTypeId === selectedDutyTypeId);
  const selectedData = SECTIONS.find((s) => s.id === selectedSection);

  // Reassignment handler
  const handleOpenReassign = (person: ChartPersonnel) => {
    setReassignDialog({ open: true, person });
    setReassignForm({
      replacementId: 0,
      startDate: person.leaveStartDate || '',
      endDate: person.leaveEndDate || '',
    });
  };

  const handleSubmitReassign = async () => {
    if (!reassignDialog.person || !reassignForm.replacementId || !reassignForm.startDate || !reassignForm.endDate || !selectedSection) return;
    setReassignSaving(true);
    try {
      const person = reassignDialog.person;
      await api.post('/api/duty-reassignments', {
        leavePersonId: person.id,
        replacementPersonId: reassignForm.replacementId,
        leaveRequestId: person.leaveRequestId || null,
        sectionCode: selectedSection,
        dutyType: selectedCard?.dutyTypeName || null,
        dutyLocation: person.dutyLocation || null,
        startDate: reassignForm.startDate,
        endDate: reassignForm.endDate,
      });
      setSnackbar({ open: true, message: '✓ Duty reassigned successfully', severity: 'success' });
      setReassignDialog({ open: false, person: null });
      await loadChartData(selectedSection, false);
      fetchReassignments(selectedSection);
    } catch {
      setSnackbar({ open: true, message: 'Failed to reassign duty', severity: 'error' });
    } finally {
      setReassignSaving(false);
    }
  };

  // Reassignment data for current section
  interface ReassignmentRecord {
    id: number;
    leavePersonId: number;
    replacementPersonId: number;
    leavePersonName: string;
    leavePersonBadgeId: string;
    replacementPersonName: string;
    replacementPersonBadgeId: string;
    dutyType: string;
    dutyLocation: string;
    startDate: string;
    endDate: string;
    days: number;
    status: string;
  }
  const [reassignments, setReassignments] = useState<ReassignmentRecord[]>([]);

  const fetchReassignments = useCallback(async (sectionCode: string) => {
    try {
      const res = await api.get<ReassignmentRecord[]>('/api/duty-reassignments', {
        params: { sectionCode },
      });
      setReassignments(res.data);
    } catch {
      setReassignments([]);
    }
  }, []);

  // Fetch reassignments when section changes
  useEffect(() => {
    if (selectedSection) {
      fetchReassignments(selectedSection);
    } else {
      setReassignments([]);
    }
  }, [selectedSection, fetchReassignments]);

  // Build a map: leavePersonId → replacementPersonBadgeId (for showing chip on leave personnel)
  const reassignmentMap = useMemo(() => {
    const map: Record<number, string> = {};
    reassignments.forEach((r) => {
      if (r.status === 'ACTIVE') {
        map[r.leavePersonId] = r.replacementPersonBadgeId || `ID:${r.replacementPersonId}`;
      }
    });
    return map;
  }, [reassignments]);

  // Filter sidebar duty types
  const filteredDutyCards = chartData?.dutyCards.filter((card) => {
    if (!sidebarFilter) return true;
    return card.dutyTypeName.toLowerCase().includes(sidebarFilter.toLowerCase());
  }) ?? [];

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', bgcolor: 'background.default' }}>
      <PageHeader
        title={t('nav.assignDuties', 'Assign Duties')}
        breadcrumbs={[
          { label: t('nav.home', 'Home'), path: '/' },
          { label: t('nav.groups.operations', 'Operations') },
          { label: t('nav.assignDuties', 'Assign Duties') },
        ]}
      />

      {/* Section Carousel */}
      <Box sx={{ px: { xs: 2, md: 3 }, pt: 3, pb: 1 }}>
        <Typography variant="subtitle1" sx={{ mb: 1.5, color: 'text.secondary', fontWeight: 600 }}>
          Select Section
        </Typography>
        <Carousel ariaLabel="Duty sections carousel">
          {SECTIONS.map((section) => {
            const isSelected = selectedSection === section.id;
            return (
              <Card
                key={section.id}
                elevation={isSelected ? 6 : 0}
                sx={{
                  flex: '0 0 auto',
                  width: { xs: '140px', sm: '150px', md: '160px' },
                  borderRadius: '12px',
                  border: 'none',
                  background: isSelected
                    ? `linear-gradient(135deg, ${section.color} 0%, ${section.color}cc 100%)`
                    : `linear-gradient(135deg, ${section.bgColor} 0%, ${section.color}12 100%)`,
                  transition: 'all 300ms cubic-bezier(0.4, 0, 0.2, 1)',
                  position: 'relative',
                  overflow: 'visible',
                  '&:hover': {
                    transform: 'translateY(-4px) scale(1.02)',
                    boxShadow: `0 12px 32px ${section.color}30`,
                  },
                }}
              >
                {isSelected && (
                  <Chip
                    label="✓ Active"
                    size="small"
                    sx={{
                      position: 'absolute', top: -10, right: 12,
                      bgcolor: '#ffffff', color: section.color,
                      fontSize: '0.6rem', height: 20, fontWeight: 700,
                      boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
                    }}
                  />
                )}
                <CardActionArea onClick={() => handleSectionClick(section.id)} sx={{ px: 1.5, py: 1.5 }}>
                  <Stack spacing={0.5} alignItems="center">
                    <Box
                      sx={{
                        width: 28, height: 28, borderRadius: '8px',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        bgcolor: isSelected ? 'rgba(255,255,255,0.25)' : `${section.color}18`,
                      }}
                    >
                      <Typography sx={{ fontWeight: 800, fontSize: '0.75rem', color: isSelected ? '#ffffff' : section.color }}>
                        {section.id}
                      </Typography>
                    </Box>
                    <Typography sx={{ fontWeight: 700, fontSize: '0.72rem', color: isSelected ? '#ffffff' : 'text.primary', textAlign: 'center', lineHeight: 1.2 }}>
                      {section.name}
                    </Typography>
                    <Typography sx={{ fontSize: '0.6rem', color: isSelected ? 'rgba(255,255,255,0.85)' : 'text.secondary', textAlign: 'center', lineHeight: 1.2 }}>
                      {section.description}
                    </Typography>
                  </Stack>
                </CardActionArea>
              </Card>
            );
          })}
        </Carousel>
      </Box>

      {/* Main Content: Tabs + Content */}
      <Box sx={{ flex: 1, px: { xs: 1, md: 3 }, py: 2 }}>
        {/* Tab Navigation */}
        {selectedData && chartData && (
          <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 2 }}>
            <Tabs
              value={activeTab}
              onChange={(_, v) => setActiveTab(v)}
              sx={{
                '& .MuiTab-root': { textTransform: 'none', fontWeight: 600, fontSize: '0.85rem', minWidth: 'auto', px: 2 },
                '& .Mui-selected': { color: selectedData.color },
                '& .MuiTabs-indicator': { backgroundColor: selectedData.color },
              }}
            >
              <Tab label="Duty Management" />
              <Tab label="Leave Management" />
              <Tab label="Form 168 View" />
            </Tabs>
          </Box>
        )}

        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
            <CircularProgress />
          </Box>
        ) : selectedData && chartData ? (
          <>
            {/* TAB 0: Duty Management (existing view) */}
            {activeTab === 0 && (
          <Box sx={{ display: 'flex', gap: 2, alignItems: 'flex-start' }}>
            {/* LEFT SIDEBAR: Parent Duty Types List - shows full list, no scroll */}
            <Paper
              elevation={0}
              sx={{
                width: { xs: 200, sm: 240, md: 280 },
                flexShrink: 0,
                border: '1px solid',
                borderColor: 'divider',
                borderRadius: '12px',
                display: 'flex',
                flexDirection: 'column',
                position: 'sticky',
                top: 16,
              }}
            >
              {/* Sidebar Header */}
              <Box sx={{ px: 2, py: 1.5, bgcolor: selectedData.bgColor, borderBottom: '1px solid', borderColor: 'divider' }}>
                <Typography variant="subtitle2" sx={{ fontWeight: 700, color: selectedData.color }}>
                  {selectedData.name} Duties
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {chartData.dutyCards.length} duties • {chartData.totalPersonnel} personnel
                </Typography>
              </Box>

              {/* Search Filter */}
              <Box sx={{ px: 1.5, py: 1 }}>
                <TextField
                  size="small"
                  fullWidth
                  placeholder="Filter duties..."
                  value={sidebarFilter}
                  onChange={(e) => setSidebarFilter(e.target.value)}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <SearchIcon fontSize="small" color="action" />
                      </InputAdornment>
                    ),
                    sx: { fontSize: '0.8rem' },
                  }}
                />
              </Box>

              {/* Duty Types List - full height, no scroll */}
              <Box>
                <List dense disablePadding>
                  {filteredDutyCards.map((card) => (
                    <ListItemButton
                      key={card.dutyTypeId}
                      selected={selectedDutyTypeId === card.dutyTypeId}
                      onClick={() => setSelectedDutyTypeId(card.dutyTypeId)}
                      sx={{
                        px: 2, py: 1,
                        borderLeft: selectedDutyTypeId === card.dutyTypeId ? `3px solid ${selectedData.color}` : '3px solid transparent',
                        '&.Mui-selected': {
                          bgcolor: `${selectedData.color}08`,
                        },
                        '&.Mui-selected:hover': {
                          bgcolor: `${selectedData.color}12`,
                        },
                      }}
                    >
                      <ListItemText
                        primary={
                          <Stack direction="row" spacing={0.5} alignItems="center">
                            <Typography
                              variant="caption"
                              sx={{
                                fontWeight: selectedDutyTypeId === card.dutyTypeId ? 700 : 500,
                                fontSize: '0.72rem',
                                textTransform: 'uppercase',
                                letterSpacing: '0.3px',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                whiteSpace: 'nowrap',
                                flex: 1,
                              }}
                            >
                              {card.dutyTypeName}
                            </Typography>
                            <Chip
                              label={card.personnelCount}
                              size="small"
                              sx={{
                                height: 18, fontSize: '0.6rem', fontWeight: 700,
                                bgcolor: card.personnelCount > 0 ? `${selectedData.color}15` : 'grey.100',
                                color: card.personnelCount > 0 ? selectedData.color : 'text.disabled',
                              }}
                            />
                          </Stack>
                        }
                      />
                    </ListItemButton>
                  ))}
                </List>
              </Box>

              {/* Reassigned Duties Entry */}
              {activeReassignments.length > 0 && (
                <Box sx={{ borderTop: '1px solid', borderColor: 'divider' }}>
                  <ListItemButton
                    selected={selectedDutyTypeId === -999}
                    onClick={() => setSelectedDutyTypeId(-999)}
                    sx={{
                      px: 2, py: 1,
                      borderLeft: selectedDutyTypeId === -999 ? '3px solid #2563eb' : '3px solid transparent',
                      bgcolor: selectedDutyTypeId === -999 ? '#eff6ff' : 'transparent',
                      '&.Mui-selected': { bgcolor: '#eff6ff' },
                      '&.Mui-selected:hover': { bgcolor: '#dbeafe' },
                    }}
                  >
                    <ListItemText
                      primary={
                        <Stack direction="row" spacing={0.5} alignItems="center">
                          <Typography
                            variant="caption"
                            sx={{ fontWeight: 700, fontSize: '0.72rem', textTransform: 'uppercase', letterSpacing: '0.3px', flex: 1, color: '#2563eb' }}
                          >
                            Reassigned Duties
                          </Typography>
                          <Chip
                            label={activeReassignments.length}
                            size="small"
                            sx={{ height: 18, fontSize: '0.6rem', fontWeight: 700, bgcolor: '#dbeafe', color: '#1d4ed8' }}
                          />
                        </Stack>
                      }
                    />
                  </ListItemButton>
                </Box>
              )}

              {/* Add Duty Type */}
              <Box sx={{ borderTop: '1px solid', borderColor: 'divider', p: 1.5 }}>
                {showAddDutyType ? (
                  <Stack spacing={1}>
                    <TextField
                      size="small"
                      fullWidth
                      placeholder="New duty type name..."
                      value={newDutyTypeName}
                      onChange={(e) => setNewDutyTypeName(e.target.value)}
                      onKeyDown={(e) => { if (e.key === 'Enter') handleAddDutyType(); }}
                      autoFocus
                      InputProps={{ sx: { fontSize: '0.8rem' } }}
                    />
                    <Stack direction="row" spacing={0.5}>
                      <Button size="small" variant="contained" onClick={handleAddDutyType} disabled={!newDutyTypeName.trim()} sx={{ fontSize: '0.7rem' }}>
                        Create
                      </Button>
                      <Button size="small" onClick={() => { setShowAddDutyType(false); setNewDutyTypeName(''); }} sx={{ fontSize: '0.7rem' }}>
                        Cancel
                      </Button>
                    </Stack>
                  </Stack>
                ) : (
                  <Button
                    fullWidth
                    size="small"
                    startIcon={<AddCircleOutlineIcon />}
                    onClick={() => setShowAddDutyType(true)}
                    sx={{ textTransform: 'none', fontSize: '0.75rem' }}
                  >
                    Add Duty Type
                  </Button>
                )}
              </Box>
            </Paper>

            {/* RIGHT: Main Content - matches left sidebar height, scrolls if content overflows */}
            <Box sx={{ flex: 1, minWidth: 0, alignSelf: 'stretch' }}>
              {selectedDutyTypeId === -999 ? (
                /* Reassigned Duties Panel */
                <Paper elevation={0} sx={{ border: '1px solid', borderColor: 'divider', borderRadius: '12px', height: '100%', display: 'flex', flexDirection: 'column' }}>
                  <Box sx={{ px: 3, py: 2, bgcolor: '#eff6ff', borderBottom: '1px solid', borderColor: 'divider' }}>
                    <Stack direction="row" spacing={1.5} alignItems="center">
                      <Typography variant="h6" sx={{ fontWeight: 700, color: '#1d4ed8', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                        Reassigned Duties
                      </Typography>
                      <Chip label={`${activeReassignments.length} active`} size="small" sx={{ fontWeight: 600, bgcolor: '#dbeafe', color: '#1d4ed8' }} />
                    </Stack>
                    <Typography variant="caption" color="text.secondary">Personnel covering for those on leave</Typography>
                  </Box>
                  <Box sx={{ flex: 1, overflowY: 'auto', p: 3 }}>
                    {activeReassignments.length === 0 ? (
                      <Typography variant="body2" color="text.secondary">No active reassignments.</Typography>
                    ) : (
                      <Stack spacing={1}>
                        {activeReassignments.map((r) => (
                          <Box key={r.id} sx={{ p: 1.5, borderRadius: '8px', border: '1px solid #dbeafe', bgcolor: '#f8faff' }}>
                            <Stack direction="row" justifyContent="space-between" alignItems="flex-start">
                              <Box>
                                <Typography variant="body2" fontWeight={700} color="#1d4ed8">
                                  {r.replacementPersonBadgeId} — {r.replacementPersonName}
                                </Typography>
                                <Typography variant="caption" color="text.secondary">
                                  Covering for: {r.leavePersonBadgeId} ({r.leavePersonName})
                                </Typography>
                                <Stack direction="row" spacing={1} sx={{ mt: 0.5 }}>
                                  {r.dutyType && <Chip label={r.dutyType} size="small" sx={{ height: 18, fontSize: '0.58rem' }} />}
                                  {r.dutyLocation && <Chip label={r.dutyLocation} size="small" variant="outlined" sx={{ height: 18, fontSize: '0.58rem' }} />}
                                </Stack>
                                <Typography variant="caption" color="text.secondary" sx={{ mt: 0.5, display: 'block' }}>
                                  {r.startDate} → {r.endDate} ({r.days}d)
                                </Typography>
                              </Box>
                              <Tooltip title="Cancel reassignment">
                                <IconButton
                                  size="small"
                                  onClick={async () => {
                                    try {
                                      await api.delete(`/api/duty-reassignments/${r.id}`);
                                      setSnackbar({ open: true, message: '✓ Reassignment cancelled', severity: 'success' });
                                      if (selectedSection) fetchReassignments(selectedSection);
                                    } catch {
                                      setSnackbar({ open: true, message: 'Failed to cancel', severity: 'error' });
                                    }
                                  }}
                                  sx={{ color: 'error.main' }}
                                >
                                  <DeleteOutlineIcon sx={{ fontSize: 16 }} />
                                </IconButton>
                              </Tooltip>
                            </Stack>
                          </Box>
                        ))}
                      </Stack>
                    )}
                  </Box>
                </Paper>
              ) : selectedCard ? (
                <DutyDetailPanel
                  card={selectedCard}
                  sectionCode={selectedSection ?? ''}
                  sectionColor={selectedData.color}
                  sectionBgColor={selectedData.bgColor}
                  onAssign={handleAssignPerson}
                  onUnassign={handleUnassignPerson}
                  onAddSubDuty={handleAddSubDuty}
                  onDeleteDutyType={handleDeleteDutyType}
                  onDeleteSubDuty={handleDeleteSubDuty}
                  onReassign={handleOpenReassign}
                  reassignments={activeReassignments}
                />
              ) : (
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', opacity: 0.5 }}>
                  <Stack alignItems="center" spacing={1}>
                    <ArrowBackIcon sx={{ fontSize: 40, color: 'text.disabled' }} />
                    <Typography variant="body2" color="text.secondary">
                      Select a duty type from the left panel
                    </Typography>
                  </Stack>
                </Box>
              )}
            </Box>
          </Box>
            )}

            {/* TAB 1: Leave Management */}
            {activeTab === 1 && (
              <LeaveManagementPanel
                sectionCode={selectedSection ?? ''}
                sectionColor={selectedData.color}
                sectionBgColor={selectedData.bgColor}
                onAssign={handleAssignPerson}
                onUnassign={handleUnassignPerson}
                chartData={chartData}
                onRefresh={() => selectedSection && loadChartData(selectedSection, false)}
                selectedCategory={selectedLeaveCategory}
                onCategoryChange={setSelectedLeaveCategory}
              />
            )}

            {/* TAB 2: Form 168 View */}
            {activeTab === 2 && selectedSection && (
              <Form168TableView
                sectionCode={selectedSection}
                sectionColor={selectedData.color}
              />
            )}
          </>
        ) : (
          <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', py: 8, gap: 2 }}>
            <BadgeIcon sx={{ fontSize: 56, color: 'text.disabled' }} />
            <Typography variant="h6" color="text.secondary" fontWeight={600}>
              Select a section to view duty chart
            </Typography>
            <Typography variant="body2" color="text.disabled">
              Choose a section from the carousel above to view and edit duty assignments
            </Typography>
          </Box>
        )}
      </Box>

      {/* Saving overlay */}
      {saving && (
        <Box sx={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, bgcolor: 'rgba(0,0,0,0.08)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <CircularProgress />
        </Box>
      )}

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialog.open} onClose={() => setDeleteDialog((d) => ({ ...d, open: false }))}>
        <DialogTitle>Confirm Delete</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to delete &quot;{deleteDialog.name}&quot;?
            {deleteDialog.type === 'dutyType' && ' All personnel assignments under this duty will be cleared.'}
            {deleteDialog.type === 'subDuty' && ' Personnel under this sub-duty will have their location cleared.'}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialog((d) => ({ ...d, open: false }))}>Cancel</Button>
          <Button onClick={confirmDelete} color="error" variant="contained">Delete</Button>
        </DialogActions>
      </Dialog>

      {/* Reassignment Dialog */}
      <Dialog
        open={reassignDialog.open}
        onClose={() => setReassignDialog({ open: false, person: null })}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle sx={{ fontWeight: 700 }}>Reassign Duty</DialogTitle>
        <DialogContent>
          {reassignDialog.person && (
            <Stack spacing={2.5} sx={{ mt: 1 }}>
              {/* Leave Person Info */}
              <Box sx={{ p: 1.5, borderRadius: '8px', bgcolor: '#fee2e2', border: '1px solid #fca5a5' }}>
                <Typography variant="caption" color="text.secondary" fontWeight={600}>Person on Leave</Typography>
                <Typography variant="body2" fontWeight={700}>
                  {reassignDialog.person.badgeId} — {reassignDialog.person.personName}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  Leave: {reassignDialog.person.leaveStartDate} to {reassignDialog.person.leaveEndDate} ({reassignDialog.person.leaveDays} days)
                </Typography>
              </Box>

              {/* Replacement Person */}
              <Box>
                <Typography variant="caption" fontWeight={600} sx={{ mb: 0.5, display: 'block' }}>
                  Select Replacement Person *
                </Typography>
                <PersonnelAutocomplete
                  onSelect={(id) => setReassignForm((f) => ({ ...f, replacementId: id }))}
                  onCancel={() => setReassignForm((f) => ({ ...f, replacementId: 0 }))}
                />
              </Box>

              {/* Date Range */}
              <Stack direction="row" spacing={2}>
                <TextField
                  label="Start Date"
                  type="date"
                  size="small"
                  fullWidth
                  value={reassignForm.startDate}
                  onChange={(e) => setReassignForm((f) => ({ ...f, startDate: e.target.value }))}
                  InputLabelProps={{ shrink: true }}
                  inputProps={{
                    min: reassignDialog.person.leaveStartDate,
                    max: reassignDialog.person.leaveEndDate,
                  }}
                  helperText="Cannot exceed leave dates"
                />
                <TextField
                  label="End Date"
                  type="date"
                  size="small"
                  fullWidth
                  value={reassignForm.endDate}
                  onChange={(e) => setReassignForm((f) => ({ ...f, endDate: e.target.value }))}
                  InputLabelProps={{ shrink: true }}
                  inputProps={{
                    min: reassignForm.startDate || reassignDialog.person.leaveStartDate,
                    max: reassignDialog.person.leaveEndDate,
                  }}
                  helperText="Cannot exceed leave dates"
                />
              </Stack>

              {/* Validation message */}
              {reassignForm.startDate && reassignForm.endDate && reassignDialog.person.leaveEndDate && (
                reassignForm.endDate > reassignDialog.person.leaveEndDate || reassignForm.startDate < (reassignDialog.person.leaveStartDate || '')
              ) && (
                <Alert severity="error" sx={{ fontSize: '0.75rem' }}>
                  Reassignment dates must be within the leave period ({reassignDialog.person.leaveStartDate} to {reassignDialog.person.leaveEndDate})
                </Alert>
              )}
            </Stack>
          )}
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setReassignDialog({ open: false, person: null })}>Cancel</Button>
          <Button
            variant="contained"
            onClick={handleSubmitReassign}
            disabled={
              reassignSaving || !reassignForm.replacementId || !reassignForm.startDate || !reassignForm.endDate
            }
            sx={{ textTransform: 'none' }}
          >
            {reassignSaving ? 'Saving...' : 'Reassign'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={3000}
        onClose={() => setSnackbar((s) => ({ ...s, open: false }))}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert severity={snackbar.severity} variant="filled" sx={{ width: '100%' }}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

// ===== Duty Detail Panel (Right Side) =====
interface DutyDetailPanelProps {
  card: DutyCard;
  sectionCode: string;
  sectionColor: string;
  sectionBgColor: string;
  onAssign: (personnelId: number, dutyTypeId: number, subDuty?: string | null) => void;
  onUnassign: (personnelId: number) => void;
  onAddSubDuty: (parentDutyTypeId: number, subDutyName: string) => void;
  onDeleteDutyType: (dutyTypeId: number, name: string) => void;
  onDeleteSubDuty: (dutyTypeId: number, subDutyName: string) => void;
  onReassign?: (person: ChartPersonnel) => void;
  reassignments?: Array<{ leavePersonId: number; replacementPersonBadgeId: string }>;
}

const DutyDetailPanel: React.FC<DutyDetailPanelProps> = ({
  card, sectionCode, sectionColor, sectionBgColor, onAssign, onUnassign, onAddSubDuty, onDeleteDutyType, onDeleteSubDuty, onReassign, reassignments,
}) => {
  const [showAddSubDuty, setShowAddSubDuty] = useState(false);
  const [newSubDutyName, setNewSubDutyName] = useState('');

  const handleAddSubDutySubmit = () => {
    if (newSubDutyName.trim()) {
      onAddSubDuty(card.dutyTypeId, newSubDutyName);
      setNewSubDutyName('');
      setShowAddSubDuty(false);
    }
  };

  return (
    <Paper
      elevation={0}
      sx={{
        border: '1px solid',
        borderColor: 'divider',
        borderRadius: '12px',
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      {/* Header */}
      <Box sx={{ px: 3, py: 2, bgcolor: sectionBgColor, borderBottom: '1px solid', borderColor: 'divider' }}>
        <Stack direction="row" spacing={1.5} alignItems="center" justifyContent="space-between">
          <Stack direction="row" spacing={1.5} alignItems="center">
            <Typography variant="h6" sx={{ fontWeight: 700, color: sectionColor, textTransform: 'uppercase', letterSpacing: '0.5px' }}>
              {card.dutyTypeName}
            </Typography>
            <Chip
              label={`${card.personnelCount} personnel`}
              size="small"
              sx={{ fontWeight: 600, bgcolor: `${sectionColor}15`, color: sectionColor }}
            />
          </Stack>
          <Tooltip title="Delete this duty type">
            <Button size="small" color="error" startIcon={<DeleteOutlineIcon fontSize="small" />} onClick={() => onDeleteDutyType(card.dutyTypeId, card.dutyTypeName)}>
              Delete
            </Button>
          </Tooltip>
        </Stack>
      </Box>

      {/* Content - Scrollable */}
      <Box sx={{ flex: 1, overflowY: 'auto', p: 3 }}>
        {/* Sub Duties */}
        {card.subDuties.length > 0 && (
          <Stack spacing={2.5}>
            {card.subDuties.map((subDuty) => (
              <SubDutySection
                key={subDuty.subDutyName}
                subDuty={subDuty}
                dutyTypeId={card.dutyTypeId}
                sectionColor={sectionColor}
                onAssign={(personnelId) => onAssign(personnelId, card.dutyTypeId, subDuty.subDutyName)}
                onUnassign={onUnassign}
                onDeleteSubDuty={() => onDeleteSubDuty(card.dutyTypeId, subDuty.subDutyName)}
                onReassign={onReassign}
                reassignments={reassignments}
              />
            ))}
          </Stack>
        )}

        {/* Personnel without sub-duty (direct assignment to parent) */}
        {card.personnel.length > 0 && (
          <Box sx={{ mt: card.subDuties.length > 0 ? 3 : 0 }}>
            {card.subDuties.length > 0 && (
              <Typography variant="caption" sx={{ fontWeight: 600, color: 'text.secondary', mb: 1, display: 'block', textTransform: 'uppercase' }}>
                Direct Assignment (No Sub Duty)
              </Typography>
            )}
            <PersonnelList
              personnel={card.personnel}
              dutyTypeId={card.dutyTypeId}
              subDuty={null}
              onAssign={(personnelId) => onAssign(personnelId, card.dutyTypeId, null)}
              onUnassign={onUnassign}
              onReassign={onReassign}
              reassignments={reassignments}
            />
          </Box>
        )}

        {/* If no sub-duties and no personnel, show the add person area */}
        {card.subDuties.length === 0 && card.personnel.length === 0 && (
          <Box sx={{ py: 2 }}>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
              No personnel assigned to this duty yet.
            </Typography>
            <PersonnelList
              personnel={[]}
              dutyTypeId={card.dutyTypeId}
              subDuty={null}
              onAssign={(personnelId) => onAssign(personnelId, card.dutyTypeId, null)}
              onUnassign={onUnassign}
            />
          </Box>
        )}

        {/* Add Sub Duty */}
        <Box sx={{ mt: 3, pt: 2, borderTop: '1px dashed', borderColor: 'divider' }}>
          {showAddSubDuty ? (
            <Stack direction="row" spacing={1} alignItems="center">
              <TextField
                size="small"
                placeholder="Sub duty name (e.g. COMMISSIONER OFFICE)..."
                value={newSubDutyName}
                onChange={(e) => setNewSubDutyName(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') handleAddSubDutySubmit(); }}
                sx={{ flex: 1, maxWidth: 400 }}
                autoFocus
              />
              <Button size="small" variant="contained" onClick={handleAddSubDutySubmit} disabled={!newSubDutyName.trim()}>
                Add
              </Button>
              <Button size="small" onClick={() => { setShowAddSubDuty(false); setNewSubDutyName(''); }}>
                Cancel
              </Button>
            </Stack>
          ) : (
            <Button
              size="small"
              startIcon={<AddCircleOutlineIcon />}
              onClick={() => setShowAddSubDuty(true)}
              sx={{ textTransform: 'none' }}
            >
              Add Sub Duty (Location)
            </Button>
          )}
        </Box>
      </Box>
    </Paper>
  );
};

// ===== Sub Duty Section =====
interface SubDutySectionProps {
  subDuty: SubDutyGroup;
  dutyTypeId: number;
  sectionColor: string;
  onAssign: (personnelId: number) => void;
  onUnassign: (personnelId: number) => void;
  onDeleteSubDuty: () => void;
  onReassign?: (person: ChartPersonnel) => void;
  reassignments?: Array<{ leavePersonId: number; replacementPersonBadgeId: string }>;
}

const SubDutySection: React.FC<SubDutySectionProps> = ({ subDuty, dutyTypeId, sectionColor, onAssign, onUnassign, onDeleteSubDuty, onReassign, reassignments }) => {
  return (
    <Box
      sx={{
        pl: 2,
        borderLeft: `3px solid ${sectionColor}40`,
        borderRadius: '0 8px 8px 0',
      }}
    >
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1 }}>
        <Typography variant="body2" sx={{ fontWeight: 700, color: 'text.primary', textTransform: 'uppercase', flex: 1 }}>
          {subDuty.subDutyName}
        </Typography>
        <Chip
          label={subDuty.personnelCount}
          size="small"
          sx={{ height: 18, fontSize: '0.65rem', fontWeight: 600 }}
        />
        <Tooltip title="Delete this sub duty">
          <Button size="small" color="error" startIcon={<DeleteOutlineIcon sx={{ fontSize: 14 }} />} onClick={onDeleteSubDuty} sx={{ fontSize: '0.65rem', minWidth: 'auto', px: 0.5, py: 0 }}>
            Delete
          </Button>
        </Tooltip>
      </Stack>
      <PersonnelList
        personnel={subDuty.personnel}
        dutyTypeId={dutyTypeId}
        subDuty={subDuty.subDutyName}
        onAssign={onAssign}
        onUnassign={onUnassign}
        onReassign={onReassign}
        reassignments={reassignments}
      />
    </Box>
  );
};

// ===== Personnel List with Add Person =====
interface PersonnelListProps {
  personnel: ChartPersonnel[];
  dutyTypeId: number;
  subDuty: string | null;
  onAssign: (personnelId: number) => void;
  onUnassign: (personnelId: number) => void;
  onReassign?: (person: ChartPersonnel) => void;
  reassignments?: Array<{ leavePersonId: number; replacementPersonBadgeId: string }>;
}

const PersonnelList: React.FC<PersonnelListProps> = ({ personnel, dutyTypeId, subDuty, onAssign, onUnassign, onReassign, reassignments }) => {
  const [showSearch, setShowSearch] = useState(false);

  return (
    <Box>
      {/* Personnel Rows */}
      <Stack spacing={0.5}>
        {personnel.map((person) => {
          const reassignment = reassignments?.find((r) => r.leavePersonId === person.id);
          return (
            <PersonnelRow
              key={person.id}
              person={person}
              onRemove={() => onUnassign(person.id)}
              onReassign={onReassign}
              reassignedTo={reassignment?.replacementPersonBadgeId}
            />
          );
        })}
      </Stack>

      {/* Add Person */}
      {showSearch ? (
        <Box sx={{ mt: 1 }}>
          <PersonnelAutocomplete
            onSelect={(personnelId) => {
              onAssign(personnelId);
              setShowSearch(false);
            }}
            onCancel={() => setShowSearch(false)}
          />
        </Box>
      ) : (
        <Button
          size="small"
          startIcon={<PersonAddIcon />}
          onClick={() => setShowSearch(true)}
          sx={{ mt: 0.75, textTransform: 'none', fontSize: '0.75rem' }}
        >
          Add Person
        </Button>
      )}
    </Box>
  );
};

// ===== Personnel Row =====
interface PersonnelRowProps {
  person: ChartPersonnel;
  onRemove: () => void;
  onReassign?: (person: ChartPersonnel) => void;
  reassignedTo?: string; // badge ID of replacement person
}

const PersonnelRow: React.FC<PersonnelRowProps> = ({ person, onRemove, onReassign, reassignedTo }) => {
  return (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        px: 1.5,
        py: 0.6,
        borderRadius: '8px',
        bgcolor: person.onLeave ? '#fff5f5' : 'grey.50',
        border: '1px solid',
        borderColor: person.onLeave ? '#fca5a5' : 'grey.200',
        transition: 'all 0.15s',
        '&:hover': { bgcolor: person.onLeave ? '#fee2e2' : 'grey.100', borderColor: person.onLeave ? '#f87171' : 'grey.300', '& .remove-btn': { opacity: 1 } },
      }}
    >
      <Stack direction="row" spacing={1} alignItems="center" sx={{ minWidth: 0, flex: 1 }}>
        <Typography
          variant="body2"
          sx={{ fontWeight: 700, color: 'primary.main', whiteSpace: 'nowrap', fontSize: '0.78rem', minWidth: 70 }}
        >
          {person.badgeId || '—'}
        </Typography>
        <Typography
          variant="body2"
          sx={{ color: 'text.primary', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: '0.78rem' }}
        >
          {person.personName}
        </Typography>
        {person.onLeave && (
          <Chip
            label={`On Leave · ${person.leaveType?.replace(/_/g, ' ')} (${person.leaveDays}d)`}
            size="small"
            sx={{ height: 18, fontSize: '0.55rem', fontWeight: 700, bgcolor: '#fee2e2', color: '#dc2626', border: '1px solid #fca5a5' }}
          />
        )}
        {person.onLeave && reassignedTo && (
          <Chip
            label={`Reassigned to: ${reassignedTo}`}
            size="small"
            sx={{ height: 18, fontSize: '0.55rem', fontWeight: 700, bgcolor: '#dbeafe', color: '#1d4ed8', border: '1px solid #93c5fd' }}
          />
        )}
        {person.designation && (
          <Chip
            label={person.designation}
            size="small"
            sx={{ height: 18, fontSize: '0.6rem', fontWeight: 600, bgcolor: 'grey.200' }}
          />
        )}
      </Stack>
      <Stack direction="row" spacing={0.5} alignItems="center">
        {person.onLeave && onReassign && !reassignedTo && (
          <Button
            size="small"
            variant="outlined"
            onClick={(e) => { e.stopPropagation(); onReassign(person); }}
            sx={{
              fontSize: '0.6rem', fontWeight: 700, py: 0.2, px: 0.8,
              textTransform: 'none', borderColor: '#2563eb', color: '#2563eb',
              minWidth: 'auto', height: 22,
              '&:hover': { bgcolor: '#eff6ff', borderColor: '#1d4ed8' },
            }}
          >
            Reassign
          </Button>
        )}
        <Tooltip title="Remove from this duty">
          <IconButton
            size="small"
            className="remove-btn"
            onClick={(e) => { e.stopPropagation(); onRemove(); }}
            sx={{ opacity: 0.3, transition: 'opacity 0.2s', p: 0.3 }}
          >
            <DeleteOutlineIcon sx={{ fontSize: 16, color: 'error.main' }} />
          </IconButton>
        </Tooltip>
      </Stack>
    </Box>
  );
};

// ===== Personnel Autocomplete =====
interface PersonnelAutocompleteProps {
  onSelect: (personnelId: number) => void;
  onCancel: () => void;
}

const PersonnelAutocomplete: React.FC<PersonnelAutocompleteProps> = ({ onSelect, onCancel }) => {
  const [options, setOptions] = useState<PersonnelSearchResult[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [loading, setLoading] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const searchPersonnel = useCallback(async (query: string) => {
    if (query.length < 2) {
      setOptions([]);
      return;
    }
    setLoading(true);
    try {
      const results = await sectionChartService.searchPersonnel(query, 10);
      setOptions(results);
    } catch {
      setOptions([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const handleInputChange = (_event: React.SyntheticEvent, value: string) => {
    setInputValue(value);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => searchPersonnel(value), 250);
  };

  return (
    <Stack direction="row" spacing={0.5} alignItems="flex-start">
      <Autocomplete
        size="small"
        fullWidth
        disablePortal={false}
        options={options}
        loading={loading}
        inputValue={inputValue}
        onInputChange={handleInputChange}
        getOptionLabel={(option) => `${option.badgeId || ''} ${option.personName}`}
        isOptionEqualToValue={(option, value) => option.id === value.id}
        onChange={(_e, value) => {
          if (value) onSelect(value.id);
        }}
        renderOption={(props, option) => (
          <li {...props} key={option.id}>
            <Stack direction="row" spacing={1} alignItems="center" sx={{ width: '100%' }}>
              <Typography variant="caption" sx={{ fontWeight: 700, color: 'primary.main', minWidth: 75 }}>
                {option.badgeId || '—'}
              </Typography>
              <Typography variant="body2" sx={{ flex: 1 }}>
                {option.personName}
              </Typography>
              {option.designation && (
                <Chip label={option.designation} size="small" sx={{ height: 18, fontSize: '0.6rem' }} />
              )}
            </Stack>
          </li>
        )}
        renderInput={(params) => (
          <TextField
            {...params}
            placeholder="Search by badge ID or name..."
            autoFocus
            InputProps={{
              ...params.InputProps,
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon fontSize="small" color="action" />
                </InputAdornment>
              ),
            }}
          />
        )}
        noOptionsText={inputValue.length < 2 ? 'Type at least 2 characters...' : 'No personnel found'}
        sx={{ flex: 1 }}
        slotProps={{
          popper: {
            sx: { zIndex: 1500 },
            placement: 'bottom-start' as const,
          },
        }}
      />
      <Button size="small" onClick={onCancel} sx={{ minWidth: 'auto', px: 1, mt: 0.5 }}>
        ✕
      </Button>
    </Stack>
  );
};

// ===== Leave Type Mapping =====
const LEAVE_TYPE_MAP: Record<string, string> = {
  'LEAVE (CL,CML,PL,EL)': 'CASUAL_LEAVE',
  'ABSENT': 'ABSENT',
  'SUSPENSION': 'SUSPENSION',
  'PERMISSION / RH TO RPI, RSI AND': 'PERMISSION',
  'SICK': 'SICK_LEAVE',
  'WEEKLY OFF': 'WEEKLY_OFF',
};

const BACKEND_TO_DISPLAY: Record<string, string> = {
  'CASUAL_LEAVE': 'LEAVE (CL,CML,PL,EL)',
  'ABSENT': 'ABSENT',
  'SUSPENSION': 'SUSPENSION',
  'PERMISSION': 'PERMISSION / RH TO RPI, RSI AND',
  'SICK_LEAVE': 'SICK',
  'WEEKLY_OFF': 'WEEKLY OFF',
};

// ===== Leave Management Panel (Two-card layout matching Duty Management) =====
interface LeaveManagementPanelProps {
  sectionCode: string;
  sectionColor: string;
  sectionBgColor: string;
  chartData: SectionChartData;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  onAssign?: any;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  onUnassign?: any;
  onRefresh?: () => void;
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
}

const LeaveManagementPanel: React.FC<LeaveManagementPanelProps> = ({
  sectionCode, sectionColor, sectionBgColor,
  selectedCategory, onCategoryChange,
}) => {
  const [leaveRecords, setLeaveRecords] = useState<LeaveRequestDto[]>([]);
  const [loading, setLoading] = useState(false);
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState<{
    personnelId: number | null;
    startDate: string;
    endDate: string;
    reason: string;
  }>({ personnelId: null, startDate: '', endDate: '', reason: '' });

  // Fetch active leave records on mount
  const fetchLeaveRecords = useCallback(async () => {
    setLoading(true);
    try {
      const result = await leaveService.list(undefined, 0, 500);
      const today = new Date().toISOString().split('T')[0];
      // Filter for APPROVED leaves where today is between startDate and endDate
      const activeLeaves = result.content.filter((lr) => {
        return lr.status === 'APPROVED' && lr.startDate <= today && lr.endDate >= today;
      });
      setLeaveRecords(activeLeaves);
    } catch {
      // Error fetching leave records
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchLeaveRecords();
  }, [fetchLeaveRecords]);

  // Group leave records by display category
  const leaveGroups: Record<string, LeaveRequestDto[]> = {};
  LEAVE_CATEGORIES.forEach((cat) => { leaveGroups[cat.name] = []; });

  leaveRecords.forEach((lr) => {
    const displayName = BACKEND_TO_DISPLAY[lr.leaveType] || lr.leaveType;
    if (leaveGroups[displayName]) {
      leaveGroups[displayName].push(lr);
    } else {
      // Fallback: put in first category
      leaveGroups[LEAVE_CATEGORIES[0].name]?.push(lr);
    }
  });

  const totalLeavePersonnel = leaveRecords.length;
  const selectedCategoryData = LEAVE_CATEGORIES.find((c) => c.name === selectedCategory);
  const selectedRecords = leaveGroups[selectedCategory] || [];

  // Handle adding a leave record
  const handleSubmitLeave = async () => {
    if (!formData.personnelId || !formData.startDate || !formData.endDate) return;
    setSaving(true);
    try {
      const backendLeaveType = LEAVE_TYPE_MAP[selectedCategory] || 'CASUAL_LEAVE';
      await leaveService.submit({
        personnelId: formData.personnelId,
        leaveType: backendLeaveType,
        startDate: formData.startDate,
        endDate: formData.endDate,
        reason: formData.reason || undefined,
      });
      setAddDialogOpen(false);
      setFormData({ personnelId: null, startDate: '', endDate: '', reason: '' });
      fetchLeaveRecords();
    } catch {
      // Error submitting leave
    } finally {
      setSaving(false);
    }
  };

  // Handle canceling a leave
  const handleCancelLeave = async (id: number) => {
    setSaving(true);
    try {
      await leaveService.cancel(id);
      fetchLeaveRecords();
    } catch {
      // Error canceling leave
    } finally {
      setSaving(false);
    }
  };

  // Calculate days between two dates
  const calculateDays = (start: string, end: string): number => {
    const startMs = new Date(start).getTime();
    const endMs = new Date(end).getTime();
    return Math.floor((endMs - startMs) / (1000 * 60 * 60 * 24)) + 1;
  };

  return (
    <Box sx={{ display: 'flex', gap: 2, alignItems: 'flex-start' }}>
      {/* LEFT SIDEBAR: Leave Categories */}
      <Paper
        elevation={0}
        sx={{
          width: { xs: 200, sm: 240, md: 280 },
          flexShrink: 0,
          border: '1px solid',
          borderColor: 'divider',
          borderRadius: '12px',
          display: 'flex',
          flexDirection: 'column',
          position: 'sticky',
          top: 16,
        }}
      >
        {/* Sidebar Header */}
        <Box sx={{ px: 2, py: 1.5, bgcolor: sectionBgColor, borderBottom: '1px solid', borderColor: 'divider' }}>
          <Typography variant="subtitle2" sx={{ fontWeight: 700, color: sectionColor }}>
            Leave Types
          </Typography>
          <Typography variant="caption" color="text.secondary">
            {LEAVE_CATEGORIES.length} types • {totalLeavePersonnel} personnel
          </Typography>
        </Box>

        {/* Leave Category List */}
        <Box>
          <List dense disablePadding>
            {LEAVE_CATEGORIES.map((cat) => {
              const count = leaveGroups[cat.name]?.length || 0;
              return (
                <ListItemButton
                  key={cat.name}
                  selected={selectedCategory === cat.name}
                  onClick={() => onCategoryChange(cat.name)}
                  sx={{
                    px: 2, py: 1,
                    borderLeft: selectedCategory === cat.name ? `3px solid ${sectionColor}` : '3px solid transparent',
                    '&.Mui-selected': { bgcolor: `${sectionColor}08` },
                    '&.Mui-selected:hover': { bgcolor: `${sectionColor}12` },
                  }}
                >
                  <ListItemText
                    primary={
                      <Stack direction="row" spacing={0.5} alignItems="center">
                        <Typography
                          variant="caption"
                          sx={{
                            fontWeight: selectedCategory === cat.name ? 700 : 500,
                            fontSize: '0.7rem',
                            textTransform: 'uppercase',
                            letterSpacing: '0.3px',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap',
                            flex: 1,
                          }}
                        >
                          {cat.name}
                        </Typography>
                        <Chip
                          label={count}
                          size="small"
                          sx={{
                            height: 18, fontSize: '0.6rem', fontWeight: 700,
                            bgcolor: count > 0 ? `${sectionColor}15` : 'grey.100',
                            color: count > 0 ? sectionColor : 'text.disabled',
                          }}
                        />
                      </Stack>
                    }
                  />
                </ListItemButton>
              );
            })}
          </List>
        </Box>
      </Paper>

      {/* RIGHT: Detail Panel for selected leave category */}
      <Box sx={{ flex: 1, minWidth: 0, alignSelf: 'stretch' }}>
        {selectedCategoryData ? (
          <Paper
            elevation={0}
            sx={{ border: '1px solid', borderColor: 'divider', borderRadius: '12px', height: '100%', display: 'flex', flexDirection: 'column' }}
          >
            {/* Header */}
            <Box sx={{ px: 3, py: 2, bgcolor: sectionBgColor, borderBottom: '1px solid', borderColor: 'divider' }}>
              <Stack direction="row" spacing={1.5} alignItems="center" justifyContent="space-between">
                <Stack direction="row" spacing={1.5} alignItems="center">
                  <Typography variant="h6" sx={{ fontWeight: 700, color: sectionColor, textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                    {selectedCategoryData.name}
                  </Typography>
                  <Chip
                    label={`${selectedRecords.length} personnel`}
                    size="small"
                    sx={{ fontWeight: 600, bgcolor: `${sectionColor}15`, color: sectionColor }}
                  />
                </Stack>
                <Button
                  size="small"
                  variant="contained"
                  startIcon={<PersonAddIcon sx={{ fontSize: 16 }} />}
                  onClick={() => setAddDialogOpen(true)}
                  sx={{ textTransform: 'none' }}
                >
                  Add Person on Leave
                </Button>
              </Stack>
              <Typography variant="caption" color="text.secondary">
                {selectedCategoryData.description}
              </Typography>
            </Box>

            {/* Leave Records Table */}
            <Box sx={{ flex: 1, overflowY: 'auto', p: 2 }}>
              {loading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
                  <CircularProgress size={24} />
                </Box>
              ) : selectedRecords.length > 0 ? (
                <Box sx={{ overflowX: 'auto' }}>
                  <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.82rem' }}>
                    <thead>
                      <tr style={{ borderBottom: '2px solid #e0e0e0' }}>
                        <th style={{ textAlign: 'left', padding: '8px 12px', fontWeight: 700, fontSize: '0.75rem', textTransform: 'uppercase', color: '#666' }}>Badge ID</th>
                        <th style={{ textAlign: 'left', padding: '8px 12px', fontWeight: 700, fontSize: '0.75rem', textTransform: 'uppercase', color: '#666' }}>Name</th>
                        <th style={{ textAlign: 'left', padding: '8px 12px', fontWeight: 700, fontSize: '0.75rem', textTransform: 'uppercase', color: '#666' }}>Start Date</th>
                        <th style={{ textAlign: 'left', padding: '8px 12px', fontWeight: 700, fontSize: '0.75rem', textTransform: 'uppercase', color: '#666' }}>End Date</th>
                        <th style={{ textAlign: 'center', padding: '8px 12px', fontWeight: 700, fontSize: '0.75rem', textTransform: 'uppercase', color: '#666' }}>Days</th>
                        <th style={{ textAlign: 'left', padding: '8px 12px', fontWeight: 700, fontSize: '0.75rem', textTransform: 'uppercase', color: '#666' }}>Reason</th>
                        <th style={{ textAlign: 'center', padding: '8px 12px', fontWeight: 700, fontSize: '0.75rem', textTransform: 'uppercase', color: '#666' }}>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedRecords.map((record) => (
                        <tr key={record.id} style={{ borderBottom: '1px solid #f0f0f0' }}>
                          <td style={{ padding: '8px 12px', fontWeight: 600, color: '#1976d2' }}>{record.badgeId || '—'}</td>
                          <td style={{ padding: '8px 12px' }}>{record.personnelName}</td>
                          <td style={{ padding: '8px 12px' }}>{record.startDate}</td>
                          <td style={{ padding: '8px 12px' }}>{record.endDate}</td>
                          <td style={{ padding: '8px 12px', textAlign: 'center', fontWeight: 600 }}>{calculateDays(record.startDate, record.endDate)}</td>
                          <td style={{ padding: '8px 12px', maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{record.reason || '—'}</td>
                          <td style={{ padding: '8px 12px', textAlign: 'center' }}>
                            <Tooltip title="Cancel Leave">
                              <IconButton
                                size="small"
                                onClick={() => handleCancelLeave(record.id)}
                                disabled={saving}
                                sx={{ color: 'error.main' }}
                              >
                                <DeleteOutlineIcon sx={{ fontSize: 16 }} />
                              </IconButton>
                            </Tooltip>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </Box>
              ) : (
                <Typography variant="body2" color="text.secondary" sx={{ py: 2 }}>
                  No active leave records for this category.
                </Typography>
              )}
            </Box>
          </Paper>
        ) : (
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', opacity: 0.5 }}>
            <Typography variant="body2" color="text.secondary">
              Select a leave type from the left panel
            </Typography>
          </Box>
        )}
      </Box>

      {/* Add Leave Dialog */}
      <Dialog open={addDialogOpen} onClose={() => setAddDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Add Person on Leave — {selectedCategory}</DialogTitle>
        <DialogContent>
          <Stack spacing={2.5} sx={{ mt: 1 }}>
            <Box>
              <Typography variant="caption" color="text.secondary" sx={{ mb: 0.5, display: 'block' }}>
                Person
              </Typography>
              <PersonnelAutocomplete
                onSelect={(personnelId) => setFormData((prev) => ({ ...prev, personnelId }))}
                onCancel={() => setFormData((prev) => ({ ...prev, personnelId: null }))}
              />
            </Box>
            <TextField
              label="Start Date"
              type="date"
              size="small"
              fullWidth
              InputLabelProps={{ shrink: true }}
              value={formData.startDate}
              onChange={(e) => setFormData((prev) => ({ ...prev, startDate: e.target.value }))}
            />
            <TextField
              label="End Date"
              type="date"
              size="small"
              fullWidth
              InputLabelProps={{ shrink: true }}
              value={formData.endDate}
              onChange={(e) => setFormData((prev) => ({ ...prev, endDate: e.target.value }))}
            />
            <TextField
              label="Reason"
              size="small"
              fullWidth
              multiline
              rows={2}
              value={formData.reason}
              onChange={(e) => setFormData((prev) => ({ ...prev, reason: e.target.value }))}
            />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => { setAddDialogOpen(false); setFormData({ personnelId: null, startDate: '', endDate: '', reason: '' }); }}>
            Cancel
          </Button>
          <Button
            variant="contained"
            onClick={handleSubmitLeave}
            disabled={saving || !formData.personnelId || !formData.startDate || !formData.endDate}
          >
            {saving ? <CircularProgress size={18} /> : 'Submit'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default AssignDutiesPage;

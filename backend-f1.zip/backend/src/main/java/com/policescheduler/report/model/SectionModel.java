package com.policescheduler.report.model;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class SectionModel {
    private String sectionName; // "SECTION A", "SECTION B", etc.
    private List<SubsectionModel> subsections;
    private int[] grandTotal; // ACP, RPI, RSI, ARSI, AHC, APC, SWP, TOTAL (8 elements)
}

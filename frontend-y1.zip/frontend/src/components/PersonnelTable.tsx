import React, { useState } from 'react';
import { observer } from 'mobx-react-lite';
import {
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  Typography,
  Paper,
  Chip,
  CircularProgress,
} from '@mui/material';
import { useTranslation } from 'react-i18next';
import { dutySectionStore } from '@/stores/dutySectionStore';

/**
 * Format date range for display.
 */
function formatDateRange(start: string, end: string | null): string {
  const startDate = new Date(start).toLocaleDateString();
  if (!end) return `${startDate} – Present`;
  const endDate = new Date(end).toLocaleDateString();
  return `${startDate} – ${endDate}`;
}

const PersonnelTable: React.FC = observer(() => {
  const { t } = useTranslation();

  // Safety: ensure filteredPersonnel is always an array
  const data = Array.isArray(dutySectionStore.filteredPersonnel)
    ? dutySectionStore.filteredPersonnel
    : [];

  // Pagination state
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  const handleChangePage = (_event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // Compute visible rows for current page
  const paginatedData = data.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Header with count */}
      <Box sx={{ px: 2, py: 1, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Typography variant="subtitle2" fontWeight="bold">
          {t('admin.dutySections.personnelTitle', 'Personnel')}
        </Typography>
        <Typography variant="caption" color="text.secondary">
          {t('admin.dutySections.personnelCount', '{{count}} people', {
            count: data.length,
          })}
        </Typography>
      </Box>

      {/* Loading state */}
      {dutySectionStore.loading && (
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', py: 4 }}>
          <CircularProgress size={28} />
          <Typography variant="body2" color="text.secondary" sx={{ ml: 1 }}>
            {t('admin.dutySections.loading', 'Loading...')}
          </Typography>
        </Box>
      )}

      {/* Empty state */}
      {!dutySectionStore.loading && data.length === 0 ? (
        <Box sx={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', p: 3 }}>
          <Typography variant="body2" color="text.secondary">
            {t('admin.dutySections.noPersonnel', 'No personnel data')}
          </Typography>
        </Box>
      ) : !dutySectionStore.loading && data.length > 0 ? (
        <>
          <TableContainer component={Paper} variant="outlined" sx={{ flex: 1, overflow: 'auto' }}>
            <Table size="small" stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 'bold' }}>
                    {t('admin.dutySections.personnelName', 'Name')}
                  </TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>
                    {t('admin.dutySections.personnelRank', 'Rank')}
                  </TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>
                    {t('admin.dutySections.personnelDutyType', 'Duty Type')}
                  </TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>
                    {t('admin.dutySections.personnelDateRange', 'Date Range')}
                  </TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>
                    {t('admin.dutySections.personnelStatus', 'Status')}
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {paginatedData.map((person, index) => (
                  <TableRow
                    key={person.id}
                    sx={{
                      backgroundColor: index % 2 === 0 ? 'background.paper' : 'action.hover',
                    }}
                  >
                    <TableCell>{person.name}</TableCell>
                    <TableCell>{person.rank}</TableCell>
                    <TableCell>{person.dutyType}</TableCell>
                    <TableCell>
                      {formatDateRange(person.assignmentStart, person.assignmentEnd)}
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={person.status}
                        size="small"
                        color={person.status === 'Active' ? 'success' : 'default'}
                        variant="outlined"
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          {/* Pagination */}
          <TablePagination
            component="div"
            count={data.length}
            page={page}
            onPageChange={handleChangePage}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={handleChangeRowsPerPage}
            rowsPerPageOptions={[5, 10, 25, 50]}
            sx={{ borderTop: '1px solid', borderColor: 'divider' }}
          />
        </>
      ) : null}
    </Box>
  );
});

export default PersonnelTable;

package com.policescheduler.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Entity for storing Report Specific Email Configuration.
 * Allows administrators to configure email content separately for each report.
 * One configuration record per report.
 */
@Entity
@Table(name = "report_specific_email_config", 
       uniqueConstraints = @UniqueConstraint(columnNames = "report_type"))
public class ReportSpecificEmailConfig {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "report_type", nullable = false, unique = true, length = 100)
    private String reportType;  // e.g., "platoon_chart", "form_168", "section_ab"

    @Column(name = "report_name", nullable = false, length = 255)
    private String reportName;  // Human-readable name: "Platoon Chart C"

    @Column(name = "email_subject", nullable = false, length = 500)
    private String emailSubject;

    @Column(name = "email_body", nullable = false, columnDefinition = "TEXT")
    private String emailBody;

    @Column(name = "schedule_days", length = 50)
    private String scheduleDays;  // Comma-separated days: SUN,MON,TUE,WED,THU,FRI,SAT

    @Column(name = "schedule_time", length = 10)
    private String scheduleTime;  // Time in HH:mm format (24-hour), e.g., "06:00"

    @Column(name = "is_schedule_enabled", nullable = false)
    private Boolean isScheduleEnabled = false;  // Whether scheduling is enabled for this report

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    @Column(name = "created_by", length = 100)
    private String createdBy;

    @Column(name = "updated_by", length = 100)
    private String updatedBy;

    @PrePersist
    protected void onCreate() {
        LocalDateTime now = LocalDateTime.now();
        if (createdAt == null) {
            createdAt = now;
        }
        updatedAt = now;
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getReportType() {
        return reportType;
    }

    public void setReportType(String reportType) {
        this.reportType = reportType;
    }

    public String getReportName() {
        return reportName;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }

    public String getEmailSubject() {
        return emailSubject;
    }

    public void setEmailSubject(String emailSubject) {
        this.emailSubject = emailSubject;
    }

    public String getEmailBody() {
        return emailBody;
    }

    public void setEmailBody(String emailBody) {
        this.emailBody = emailBody;
    }

    public String getScheduleDays() {
        return scheduleDays;
    }

    public void setScheduleDays(String scheduleDays) {
        this.scheduleDays = scheduleDays;
    }

    public String getScheduleTime() {
        return scheduleTime;
    }

    public void setScheduleTime(String scheduleTime) {
        this.scheduleTime = scheduleTime;
    }

    public Boolean getIsScheduleEnabled() {
        return isScheduleEnabled;
    }

    public void setIsScheduleEnabled(Boolean isScheduleEnabled) {
        this.isScheduleEnabled = isScheduleEnabled;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }
}

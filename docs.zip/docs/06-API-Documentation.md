# API Documentation
## KSP WorkBoard — Police Station Management System

| Field | Details |
|-------|---------|
| **Document Title** | REST API Documentation |
| **Base URL** | `http://localhost:8080` (dev) / `https://api.{domain}` (prod) |
| **Version** | 1.0.0 |
| **Date** | June 2026 |
| **Auth** | JWT Bearer Token (all except public endpoints) |
| **Content-Type** | application/json (default) |
| **Status** | Final |

---

## 1. Authentication

### 1.1 Global Headers

All authenticated requests must include:
```
Authorization: Bearer {jwt_token}
Content-Type: application/json
```

### 1.2 Error Response Format (Global)

All errors follow this structure:
```json
{
  "error": {
    "code": "ERROR_CODE",
    "message": "Human-readable description",
    "timestamp": "2026-06-21T10:00:00Z"
  }
}
```

### 1.3 Pagination Format (Global)

All paginated endpoints return Spring Page format:
```json
{
  "content": [...],
  "totalElements": 215,
  "totalPages": 11,
  "size": 20,
  "number": 0,
  "first": true,
  "last": false
}
```

**Pagination Parameters:** `?page=0&size=20&sort=personName,asc`

---

## 2. Auth Endpoints (`/api/auth`)

### POST /api/auth/login
**Access:** Public | **Purpose:** Authenticate user and receive JWT token

**Request:**
```json
{
  "username": "admin",
  "password": "password123",
  "loginType": "standard"
}
```

**Response 200:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGUiOiJBRE1JTiIsImlhdCI6MTcxOTAwMDAwMCwiZXhwIjoxNzE5MDg2NDAwfQ.signature",
  "role": "ADMIN",
  "displayName": "Station Admin",
  "locale": "en"
}
```

| Error | Status | Message |
|-------|--------|---------|
| Invalid credentials | 401 | "Invalid credentials" |
| Blank username | 400 | Validation error |

---

### POST /api/auth/logout
**Access:** Authenticated

**Headers:** `Authorization: Bearer {token}`

**Response 200:**
```json
{ "message": "Logged out successfully" }
```

---

### POST /api/auth/change-password
**Access:** Authenticated

**Request:**
```json
{
  "oldPassword": "currentPass123",
  "newPassword": "newPass456"
}
```

**Response 200:**
```json
{ "message": "Password changed successfully" }
```

---

## 3. Personnel Endpoints (`/api/personnel`)

### GET /api/personnel
**Access:** Authenticated | **Paginated:** Yes (default size=20)

**Query Parameters:**
| Param | Type | Example | Description |
|-------|------|---------|-------------|
| search | String | "jayanth" | Searches across name, badge, phone, email, duty, designation, section |
| section | String | "A" | Exact match on section |
| dutyType | String | "GUARD" | Case-insensitive match |
| designation | String | "AHC" | Exact match on rank |
| isActive | Boolean | true | Filter active/inactive |
| page | Integer | 0 | Page number (0-indexed) |
| size | Integer | 20 | Items per page |
| sort | String | "personName,asc" | Sort field and direction |

**Response 200:**
```json
{
  "content": [
    {
      "id": 1,
      "badgeId": "AHC-2649",
      "personName": "Jayanth Kumar",
      "dutyType": "GUARD",
      "location": "Main Gate",
      "phoneNumber": "9876543210",
      "email": "jayanth@police.gov.in",
      "designation": "AHC",
      "section": "A",
      "dateOfJoining": "2015-06-15",
      "vehicleNumber": null,
      "dutyLocation": null,
      "pdms": null,
      "licenceType": null,
      "deployedFrom": null,
      "platoonId": null,
      "isActive": true,
      "createdAt": "2024-01-15T10:30:00",
      "updatedAt": "2024-06-10T14:20:00"
    }
  ],
  "totalElements": 215,
  "totalPages": 11,
  "size": 20,
  "number": 0
}
```

---

### GET /api/personnel/{badgeId}
**Access:** Authenticated

**Example:** `GET /api/personnel/AHC-2649`

**Response 200:** Single PersonnelDto object (same fields as list item)

**Response 404:** Personnel record not found for badge ID: AHC-2649

---

### POST /api/personnel
**Access:** ADMIN or HIGHER_OFFICER

**Request:**
```json
{
  "badgeId": "APC-300",
  "personName": "Mahantesh Patil",
  "designation": "APC",
  "section": "C",
  "dutyType": "GUARD",
  "location": "City Center",
  "phoneNumber": "9988776655",
  "email": "mahantesh@police.gov.in",
  "platoonId": 2,
  "isActive": true
}
```

**Response 201:** Created PersonnelDto

**Errors:**
| Condition | Status | Message |
|-----------|--------|---------|
| Duplicate badge ID | 400 | "Badge ID already exists: APC-300" |
| Duty type DRIVER without driver fields | 400 | "Driver fields required when duty type is DRIVER: vehicleNumber, dutyLocation, pdms, licenceType" |
| Unauthorized | 403 | Access denied |

---

### PUT /api/personnel/{badgeId}
**Access:** ADMIN or HIGHER_OFFICER

**Request (partial update — only include fields to change):**
```json
{
  "phoneNumber": "9999888877",
  "section": "D",
  "platoonId": 3
}
```

**Response 200:** Updated PersonnelDto

---

### DELETE /api/personnel/{badgeId}
**Access:** ADMIN only

**Response 204:** No Content (successful deletion)

---

## 4. Leave Request Endpoints (`/api/leave-requests`)

### GET /api/leave-requests
**Access:** Authenticated (role-scoped) | **Paginated:** Yes

**Role-based visibility:**
- GENERAL_USER → sees only their own leave requests
- HIGHER_OFFICER/ADMIN → sees all leave requests

**Query Parameters:**
| Param | Type | Example |
|-------|------|---------|
| status | String | "PENDING" |
| leaveType | String | "SICK_LEAVE" |
| personnelId | Long | 5 |
| startDate | LocalDate | "2026-06-01" |
| endDate | LocalDate | "2026-06-30" |

**Response 200:** Page<LeaveRequestDto>
```json
{
  "content": [
    {
      "id": 42,
      "personnelId": 5,
      "personnelName": "Jayanth Kumar",
      "badgeId": "AHC-2649",
      "leaveType": "SICK_LEAVE",
      "startDate": "2026-06-22",
      "endDate": "2026-06-23",
      "status": "PENDING",
      "reason": "Fever and cold",
      "approvedBy": null,
      "rejectionReason": null,
      "createdAt": "2026-06-21T08:00:00",
      "updatedAt": "2026-06-21T08:00:00"
    }
  ],
  "totalElements": 35,
  "totalPages": 2,
  "size": 20,
  "number": 0
}
```

---

### POST /api/leave-requests
**Access:** Authenticated

**Request:**
```json
{
  "personnelId": 5,
  "leaveType": "SICK_LEAVE",
  "startDate": "2026-06-25",
  "endDate": "2026-06-26",
  "reason": "Medical appointment"
}
```

**Valid leaveType values:** `CASUAL_LEAVE`, `SICK_LEAVE`, `EARNED_LEAVE`, `WEEKLY_OFF`, `COMPENSATORY_OFF`

**Response 201 (no conflicts):** LeaveRequestDto

**Response 201 (with duty conflicts):**
```json
{
  "leave": {
    "id": 43,
    "personnelId": 5,
    "personnelName": "Jayanth Kumar",
    "leaveType": "SICK_LEAVE",
    "startDate": "2026-06-25",
    "endDate": "2026-06-26",
    "status": "PENDING"
  },
  "dutyConflicts": [
    {
      "assignmentId": 500,
      "date": "2026-06-25",
      "dutyName": "DAY",
      "platoonId": 2
    },
    {
      "assignmentId": 501,
      "date": "2026-06-26",
      "dutyName": "NIGHT",
      "platoonId": 2
    }
  ]
}
```

**Errors:**
| Condition | Status | Message |
|-----------|--------|---------|
| Personnel not found | 404 | "Personnel not found: {id}" |
| Overlapping leave | 400 | "Overlapping leave request exists" |

---

### PUT /api/leave-requests/{id}/approve
**Access:** ADMIN or HIGHER_OFFICER

**Response 200:** Updated LeaveRequestDto (status=APPROVED)

**Error:** "Leave request already processed" (if not PENDING)

---

### PUT /api/leave-requests/{id}/reject
**Access:** ADMIN or HIGHER_OFFICER

**Request:**
```json
{ "reason": "Staffing constraints during festival season" }
```

**Response 200:** Updated LeaveRequestDto (status=REJECTED, rejectionReason set)

---

### PUT /api/leave-requests/{id}/cancel
**Access:** Authenticated

**Response 200:** Updated LeaveRequestDto (status=CANCELLED)

**Errors:**
- "Leave request cannot be cancelled" (already REJECTED/CANCELLED)
- "Cannot cancel past leave requests" (endDate before today)

---

## 5. Cycle Endpoints (`/api/cycles`)

### POST /api/cycles
**Access:** Authenticated

**Request:**
```json
{
  "startDate": "2026-07-01",
  "rotationDays": 15,
  "platoonSections": [
    { "platoonId": 1, "sectionIds": [3] },
    { "platoonId": 2, "sectionIds": [4] },
    { "platoonId": 3, "sectionIds": [5] },
    { "platoonId": 4, "sectionIds": [6] },
    { "platoonId": 5, "sectionIds": [7] }
  ]
}
```

**Response 201:**
```json
{
  "id": 5,
  "startDate": "2026-07-01",
  "endDate": "2026-07-15",
  "rotationDays": 15,
  "status": "ACTIVE",
  "platoonSections": [
    { "platoonId": 1, "sectionIds": [3] },
    { "platoonId": 2, "sectionIds": [4] },
    { "platoonId": 3, "sectionIds": [5] },
    { "platoonId": 4, "sectionIds": [6] },
    { "platoonId": 5, "sectionIds": [7] }
  ],
  "createdAt": "2026-06-21T12:00:00",
  "updatedAt": "2026-06-21T12:00:00"
}
```

**Error 400:** "Cycle dates overlap with existing cycle #4 (2026-06-16 to 2026-06-30). Please choose dates after 2026-06-30."

---

### GET /api/cycles
**Access:** Authenticated

**Query:** `?status=ACTIVE` (optional, defaults to all non-DELETED)

**Response 200:** Array of CycleResponse objects, ordered by start_date DESC

---

### GET /api/cycles/{id}
**Access:** Authenticated | **Response:** Single CycleResponse | **Error 404:** "Cycle not found"

---

### PATCH /api/cycles/{id}
**Access:** Authenticated | **Partial update**

**Request (only non-null fields applied):**
```json
{
  "rotationDays": 20,
  "status": "COMPLETED"
}
```

---

### PUT /api/cycles/{id}
**Access:** Authenticated | **Full replacement** — same payload as POST

---

### DELETE /api/cycles/{id}
**Access:** Authenticated | **Response:** 204 No Content (soft-delete: status=DELETED)

---

### GET /api/cycles/next-available-date
**Response 200:**
```json
{ "nextAvailableDate": "2026-07-16" }
```

---

### GET /api/cycles/auto-generate
**Response 200:**
```json
{
  "mappings": [
    { "platoonId": 1, "sectionIds": [4] },
    { "platoonId": 2, "sectionIds": [5] },
    { "platoonId": 3, "sectionIds": [6] },
    { "platoonId": 4, "sectionIds": [7] },
    { "platoonId": 5, "sectionIds": [3] }
  ],
  "previousCycle": {
    "id": 4,
    "mappings": [
      { "platoonId": 1, "sectionIds": [3] },
      { "platoonId": 2, "sectionIds": [4] },
      { "platoonId": 3, "sectionIds": [5] },
      { "platoonId": 4, "sectionIds": [6] },
      { "platoonId": 5, "sectionIds": [7] }
    ]
  },
  "previousPlatoonSections": { "1": 3, "2": 4, "3": 5, "4": 6, "5": 7 },
  "rotationIndex": 0
}
```

---

### GET /api/cycles/audit
**Response 200:** Array of CycleAuditLogResponse

### GET /api/cycles/{id}/audit
**Response 200:** Audit logs for specific cycle

```json
[
  {
    "id": 1,
    "cycleId": 5,
    "action": "CYCLE_CREATED",
    "description": "Cycle created from 2026-07-01 to 2026-07-15 (15 days)",
    "oldValue": null,
    "newValue": null,
    "performedBy": null,
    "createdAt": "2026-06-21T12:00:00"
  }
]
```

---

## 6. Adhoc Duty Endpoints (`/api/adhoc-duties`)

### POST /api/adhoc-duties
**Access:** Authenticated

**Request:**
```json
{
  "dutyName": "Independence Day Bandobast",
  "date": "2026-08-15",
  "startTime": "06:00",
  "endTime": "18:00",
  "requiredCount": 20,
  "location": "City Center Main Road",
  "pickFrom": "ALL_PLATOONS",
  "platoonIds": null
}
```

**Response 201:**
```json
{
  "id": 8,
  "dutyName": "Independence Day Bandobast",
  "date": "2026-08-15",
  "startTime": "06:00",
  "endTime": "18:00",
  "requiredCount": 20,
  "actualCount": 18,
  "pickFrom": "ALL_PLATOONS",
  "platoonIds": null,
  "location": "City Center Main Road",
  "status": "ACTIVE",
  "createdAt": "2026-06-21T10:00:00",
  "assignees": [
    { "personId": 15, "personName": "Ram Kumar", "badgeId": "APC-101", "platoonId": 2 },
    { "personId": 22, "personName": "Suresh Rao", "badgeId": "APC-115", "platoonId": 3 }
  ]
}
```

---

### GET /api/adhoc-duties
**Query:** `?date=2026-08-15&status=ACTIVE`

**Response 200:** Array of AdhocDutyResponse

---

### GET /api/adhoc-duties/{id}
**Response 200:** Single AdhocDutyResponse with assignees list

---

### DELETE /api/adhoc-duties/{id}
**Response 200:** Cancelled AdhocDutyResponse (status=CANCELLED)

---

### GET /api/adhoc-duties/preview
**Query:** `?date=2026-08-15&startTime=06:00&endTime=18:00&count=20&pickFrom=ALL_PLATOONS`

**Response 200:**
```json
[
  { "personId": 15, "personName": "Ram Kumar", "badgeId": "APC-101", "platoonId": 2, "section": "C" }
]
```

---

### GET /api/adhoc-duties/{id}/report/pdf
**Response:** Binary PDF file download

### GET /api/adhoc-duties/{id}/report/excel
**Response:** Binary Excel file download

---

## 7. Chat Endpoints (`/api/chat`)

### POST /api/chat/message
**Access:** Authenticated

**Request:**
```json
{ "message": "show personnel list" }
```

**Response 200 (table type):**
```json
{
  "response": "Here are the personnel records:",
  "commandType": "SEARCH_PERSONNEL",
  "responseType": "table",
  "data": {
    "columns": [
      { "key": "badgeId", "label": "Badge ID" },
      { "key": "personName", "label": "Name" },
      { "key": "designation", "label": "Rank" },
      { "key": "section", "label": "Section" }
    ],
    "rows": [
      { "badgeId": "AHC-2649", "personName": "Jayanth Kumar", "designation": "AHC", "section": "A" }
    ],
    "totalCount": 215
  }
}
```

**Response 200 (form type):**
```json
{
  "response": "Fill in the details to create a new cycle:",
  "responseType": "form",
  "data": {
    "formId": "create-cycle-1719000000",
    "title": "Create Platoon Rotation Cycle",
    "submitAction": "create_cycle",
    "submitLabel": "Create Cycle",
    "fields": [
      { "name": "startDate", "label": "Start Date", "type": "date", "required": true, "value": "2026-07-16" },
      { "name": "rotationDays", "label": "Rotation Days", "type": "number", "required": true, "value": "15" },
      { "name": "platoon_1_sections", "label": "Platoon 1", "type": "select", "required": true, "value": "Section D", "options": ["Section C","Section D","Section E","Section F","Section G"] }
    ]
  }
}
```

**Response 200 (confirmation type):**
```json
{
  "response": "Personnel record created successfully for Mahantesh.",
  "responseType": "confirmation",
  "data": {
    "success": true,
    "message": "Personnel record created successfully for Mahantesh.",
    "details": { "Name": "Mahantesh", "Badge ID": "APC-300", "Section": "C" }
  }
}
```

**Response 200 (suggestions type):**
```json
{
  "response": "ನಮಸ್ಕಾರ! ನಾನು ನಿಮಗೆ ಹೇಗೆ ಸಹಾಯ ಮಾಡಬಹುದು?",
  "responseType": "suggestions",
  "data": {
    "message": "ನಮಸ್ಕಾರ! ನಾನು ನಿಮಗೆ ಹೇಗೆ ಸಹಾಯ ಮಾಡಬಹುದು?",
    "suggestions": ["Show personnel list", "Show duty types", "Show leave status", "Show schedule", "Show drivers"]
  }
}
```

---

### POST /api/chat/voice
**Access:** Authenticated | **Content-Type:** multipart/form-data

**Form Data:** `file` — audio file (WAV, MP3, etc.)

**Response 200:** Same ChatResponse format as /message (audio is transcribed first)

**Fallback:** "Voice transcription is temporarily unavailable. Please type your message instead."

---

### POST /api/chat/upload-pdf
**Access:** Authenticated | **Content-Type:** multipart/form-data | **Max Size:** 10MB

**Form Data:** `file` — PDF document

**Response 200:** ChatResponse confirming upload and showing extracted summary

---

### POST /api/chat/form-submit
**Access:** Authenticated

**Request:**
```json
{
  "formId": "create-cycle-1719000000",
  "submitAction": "create_cycle",
  "fields": {
    "startDate": "2026-07-16",
    "rotationDays": "15",
    "platoon_1_sections": "Section D",
    "platoon_2_sections": "Section E",
    "platoon_3_sections": "Section F",
    "platoon_4_sections": "Section G",
    "platoon_5_sections": "Section C"
  }
}
```

**Valid submitAction values:** `create_person`, `create_leave`, `create_cycle`, `create_adhoc_duty`

**Response 200:** ChatResponse with confirmation type

---

## 8. Schedule Endpoints (`/api/schedules`)

### GET /api/schedules/sections
**Response 200:** SectionOverview
```json
{
  "sectionA": [ { "id": 1, "personnelName": "Guard 1", "dutyTypeName": "GUARD", "section": "A", "isCurrent": true } ],
  "sectionB": [ ... ],
  "sectionC": {
    "rotation": {
      "currentCycleIndex": 2,
      "lastRotationDate": "2026-06-01",
      "nextRotationDate": "2026-06-16",
      "platoonMappings": [
        { "platoonId": 1, "platoonName": "Platoon 1", "baseOffset": 0, "currentDutyType": "Guard I" }
      ]
    },
    "assignments": [ ... ]
  }
}
```

---

### GET /api/schedules/section-a
**Response:** Array of DutyAssignmentDto

### GET /api/schedules/section-b
**Response:** Array of DutyAssignmentDto

### GET /api/schedules/section-c
**Response:** SectionCData (rotation + assignments)

### GET /api/schedules/platoons
**Response:** PlatoonRotationDto

### POST /api/schedules/platoons/rotate
**Access:** ADMIN only | **Response:** Updated PlatoonRotationDto

### PUT /api/schedules/assignments/{id}
**Access:** ADMIN or HIGHER_OFFICER

---

## 9. Assignment Endpoints (`/api/assignments`)

### GET /api/assignments
**Query:** `?cycleId=5&date=2026-07-05`

**Response 200:**
```json
[
  {
    "id": 1500,
    "cycleId": 5,
    "date": "2026-07-05",
    "platoonId": 1,
    "sectionId": 3,
    "personId": 15,
    "personName": "Ram Kumar",
    "shiftType": "DAY",
    "dutyName": "Section C",
    "groupIndex": "A",
    "status": "ACTIVE",
    "adhocDutyName": null,
    "adhocDutyTime": null,
    "isOverride": false,
    "onLeave": false,
    "updatedAt": "2026-07-01T00:00:00"
  }
]
```

---

### GET /api/assignments/range
**Query:** `?cycleId=5&startDate=2026-07-01&endDate=2026-07-07`

**Response 200:** Array (same schema as above) for the date range

---

### PATCH /api/assignments/reassign
**Request:**
```json
{
  "assignmentId": 1500,
  "newPersonId": 45
}
```

**Response 200:**
```json
{
  "id": 1500,
  "cycleId": 5,
  "date": "2026-07-05",
  "platoonId": 1,
  "sectionId": 3,
  "personId": 45,
  "shiftType": "DAY",
  "isOverride": true,
  "updatedAt": "2026-06-21T14:00:00"
}
```

**Errors:**
- 404: Assignment or person not found
- 400: "Replacement person is on approved leave for this date"
- 400: "Replacement person already has assignment for this cycle/date/section"

---

### POST /api/assignments/{assignmentId}/auto-reassign
**Response 200:**
```json
{
  "assignmentId": 1500,
  "cycleId": 5,
  "date": "2026-07-05",
  "platoonId": 1,
  "sectionId": 3,
  "newPersonId": 67,
  "newPersonName": "Suresh Rao",
  "newPersonBadgeId": "APC-115",
  "newPersonPlatoonId": 3,
  "isOverride": true,
  "reason": "auto-assigned due to leave"
}
```

**Error 400:** "No available personnel from other platoons for auto-reassignment"

---

### GET /api/assignments/{assignmentId}/available-personnel
**Query:** `?search=ram` (optional name/badge search)

**Response 200:**
```json
[
  { "id": 67, "personName": "Ram Kumar", "badgeId": "APC-115", "section": "D", "currentDutyType": "GUARD" }
]
```
(Limited to 10 results)

---

## 10. Report Endpoints (`/api/reports`)

All report endpoints return binary file downloads.

| Endpoint | Format | Filename Pattern | Parameters |
|----------|--------|-----------------|------------|
| GET /api/reports/platoon-chart | PDF | Section_C_{dd-MM-yyyy}.pdf | date?, section?(C/D/E/F/G), locale? |
| GET /api/reports/platoon-chart/excel | XLSX | Section_C_{dd-MM-yyyy}.xlsx | — |
| GET /api/reports/form-168 | PDF | STATEMENT {dd-MM-yyyy}.pdf | date?, locale? |
| GET /api/reports/form-168/excel | XLSX | STATEMENT {dd-MM-yyyy}.xlsx | date? |
| GET /api/reports/section-a | PDF | Section_A_{dd-MM-yyyy}.pdf | locale? |
| GET /api/reports/section-a/excel | XLSX | Section_A_{dd-MM-yyyy}.xlsx | — |
| GET /api/reports/section-b | PDF | Section_B_{dd-MM-yyyy}.pdf | locale? |
| GET /api/reports/section-b/excel | XLSX | Section_B_{dd-MM-yyyy}.xlsx | — |
| GET /api/reports/section-ab | PDF | section-ab.pdf | locale? |
| GET /api/reports/mt-section | PDF | MT_Section_{dd-MM-yyyy}.pdf | locale? |
| GET /api/reports/mt-section/excel | XLSX | MT_Section_{dd-MM-yyyy}.xlsx | — |
| GET /api/reports/personnel | PDF | personnel-list.pdf | section?, designation?, dutyType?, isActive?, locale? |
| GET /api/reports/leave-statement | PDF | Leave_Statement_{dd-MM-yyyy}.pdf | status?, leaveType?, locale? |
| GET /api/reports/leave-statement/excel | XLSX | Leave_Statement_{dd-MM-yyyy}.xlsx | status?, leaveType? |
| GET /api/reports/leave-requests | PDF | (alias for leave-statement) | status?, leaveType?, locale? |
| GET /api/reports/schedules | PDF | schedule-report.pdf | locale? |
| GET /api/reports/download/{fileId} | PDF | {fileId}.pdf | — |

**Response Headers:**
```
Content-Type: application/pdf (or application/vnd.openxmlformats-officedocument.spreadsheetml.sheet)
Content-Disposition: attachment; filename="Section_C_21-06-2026.pdf"
```

---

## 11. Duty Type Endpoints (`/api/duty-types`)

### GET /api/duty-types
**Query:** `?section=A` (optional)

**Response 200:**
```json
[
  { "id": 1, "name": "GUARD", "section": "A", "sortOrder": 1, "latitude": 12.8714, "longitude": 74.8428, "radiusMeters": 500 },
  { "id": 2, "name": "CHAMBER SENTRY", "section": "A", "sortOrder": 2, "latitude": null, "longitude": null, "radiusMeters": 500 }
]
```

### POST /api/duty-types
**Response:** 201 + DutyTypeDto

### PUT /api/duty-types/{id}
**Response:** 200 + DutyTypeDto

### DELETE /api/duty-types/{id}
**Response:** 204 | **Error 409:** Active assignments exist

---

## 12. Section Endpoints (`/api/sections`)

### GET /api/sections
**Response 200:**
```json
[
  { "id": 1, "code": "A", "name": "Section A", "description": "Fixed/Essential duties", "sortOrder": 1, "isActive": true, "dutyTypeCount": 8 }
]
```

### GET /api/sections/active
**Response:** Only sections where isActive=true

### POST /api/sections
**Response:** 201 | **Error 409:** Duplicate code

### PUT /api/sections/{id}
**Response:** 200

### POST /api/sections/reassign
**Purpose:** Bulk move duty types between sections

---

## 13. Holiday Endpoints (`/api/holidays`)

### GET /api/holidays
**Query:** `?year=2026&month=8` (optional filters)

**Response 200:**
```json
[
  { "id": 1, "date": "2026-08-15", "name": "Independence Day", "type": "NATIONAL" }
]
```

### POST /api/holidays
**Access:** ADMIN or HIGHER_OFFICER | **Response:** 201

### DELETE /api/holidays/{id}
**Access:** ADMIN or HIGHER_OFFICER | **Response:** 204

---

## 14. i18n Endpoints (`/api/i18n`)

### GET /api/i18n/translations/{locale}
**Example:** `GET /api/i18n/translations/kn`

**Response 200:**
```json
{
  "nav.home": "ಮುಖಪುಟ",
  "nav.personnel": "ಸಿಬ್ಬಂದಿ",
  "nav.schedules": "ವೇಳಾಪಟ್ಟಿ",
  "nav.leaveRequests": "ರಜೆ ವಿನಂತಿಗಳು",
  "nav.reports": "ವರದಿಗಳು"
}
```

### POST /api/i18n/translations
**Access:** ADMIN only

**Request:**
```json
{
  "translationKey": "nav.home",
  "locale": "kn",
  "translationValue": "ಮುಖಪುಟ",
  "category": "nav"
}
```

### GET /api/i18n/missing?locale=kn
**Access:** ADMIN | **Response:** Array of translation keys without Kannada translation

---

## 15. Admin Config Endpoints (`/api/admin/config`)

### GET /api/admin/config
**Access:** ADMIN only

**Response 200:**
```json
[
  { "id": 1, "configKey": "min_section_strength", "configValue": "5" },
  { "id": 2, "configKey": "rotation_cycle_default_days", "configValue": "15" }
]
```

### PUT /api/admin/config
**Access:** ADMIN only

**Request:**
```json
{
  "min_section_strength": "6",
  "rotation_cycle_default_days": "20"
}
```

---

## 16. Support Ticket Endpoints (`/api/support/tickets`)

### POST /api/support/tickets
**Access:** Authenticated

**Request:**
```json
{
  "subject": "Unable to download report",
  "description": "When I click download platoon chart, nothing happens."
}
```

**Response 201:** SupportTicketDto

---

### GET /api/support/tickets
**Access:** ADMIN sees all, GENERAL_USER sees own tickets only

---

### PUT /api/support/tickets/{id}/respond
**Access:** ADMIN only

**Request:**
```json
{ "response": "This has been fixed. Please try again." }
```

---

### PUT /api/support/tickets/{id}/status
**Access:** ADMIN only

**Request:**
```json
{ "status": "RESOLVED" }
```

---

## 17. Health Endpoints (`/api/health`)

### GET /api/health
**Access:** Public

**Response 200:**
```json
{ "status": "UP", "aiProvider": "groq" }
```

---

### GET /api/health/ai
**Access:** Public

**Response 200 (connected):**
```json
{ "connected": true, "provider": "groq" }
```

**Response 200 (disconnected):**
```json
{ "connected": false, "reason": "Connection refused", "provider": "groq" }
```

---

## 18. API Summary Table

| # | Method | Endpoint | Auth | Role | Description |
|---|--------|----------|------|------|-------------|
| 1 | POST | /api/auth/login | Public | — | Login |
| 2 | POST | /api/auth/logout | Auth | Any | Logout |
| 3 | POST | /api/auth/change-password | Auth | Any | Change password |
| 4 | GET | /api/personnel | Auth | Any | List personnel |
| 5 | GET | /api/personnel/{badgeId} | Auth | Any | Get by badge |
| 6 | POST | /api/personnel | Auth | Admin/HO | Create |
| 7 | PUT | /api/personnel/{badgeId} | Auth | Admin/HO | Update |
| 8 | DELETE | /api/personnel/{badgeId} | Auth | Admin | Delete |
| 9 | GET | /api/leave-requests | Auth | Scoped | List leave |
| 10 | POST | /api/leave-requests | Auth | Any | Submit |
| 11 | PUT | /api/leave-requests/{id}/approve | Auth | Admin/HO | Approve |
| 12 | PUT | /api/leave-requests/{id}/reject | Auth | Admin/HO | Reject |
| 13 | PUT | /api/leave-requests/{id}/cancel | Auth | Any | Cancel |
| 14 | POST | /api/cycles | Auth | Any | Create cycle |
| 15 | GET | /api/cycles | Auth | Any | List cycles |
| 16 | GET | /api/cycles/{id} | Auth | Any | Get cycle |
| 17 | PATCH | /api/cycles/{id} | Auth | Any | Partial update |
| 18 | PUT | /api/cycles/{id} | Auth | Any | Full update |
| 19 | DELETE | /api/cycles/{id} | Auth | Any | Soft-delete |
| 20 | GET | /api/cycles/next-available-date | Auth | Any | Next date |
| 21 | GET | /api/cycles/auto-generate | Auth | Any | Auto mappings |
| 22 | GET | /api/cycles/audit | Auth | Any | All audit logs |
| 23 | GET | /api/cycles/{id}/audit | Auth | Any | Cycle audit |
| 24 | POST | /api/adhoc-duties | Auth | Any | Create adhoc |
| 25 | GET | /api/adhoc-duties | Auth | Any | List adhoc |
| 26 | GET | /api/adhoc-duties/{id} | Auth | Any | Get details |
| 27 | DELETE | /api/adhoc-duties/{id} | Auth | Any | Cancel |
| 28 | GET | /api/adhoc-duties/preview | Auth | Any | Preview |
| 29 | GET | /api/adhoc-duties/{id}/report/pdf | Auth | Any | PDF report |
| 30 | GET | /api/adhoc-duties/{id}/report/excel | Auth | Any | Excel report |
| 31 | POST | /api/chat/message | Auth | Any | Send message |
| 32 | POST | /api/chat/voice | Auth | Any | Voice input |
| 33 | POST | /api/chat/upload-pdf | Auth | Any | Upload PDF |
| 34 | POST | /api/chat/form-submit | Auth | Any | Submit form |
| 35 | GET | /api/schedules/sections | Auth | Any | Overview |
| 36 | GET | /api/schedules/section-a | Auth | Any | Section A |
| 37 | GET | /api/schedules/section-b | Auth | Any | Section B |
| 38 | GET | /api/schedules/section-c | Auth | Any | Section C |
| 39 | GET | /api/schedules/platoons | Auth | Any | Rotation |
| 40 | POST | /api/schedules/platoons/rotate | Auth | Admin | Rotate |
| 41 | PUT | /api/schedules/assignments/{id} | Auth | Admin/HO | Update |
| 42 | GET | /api/assignments | Auth | Any | Get by cycle+date |
| 43 | GET | /api/assignments/range | Auth | Any | Date range |
| 44 | PATCH | /api/assignments/reassign | Auth | Any | Reassign |
| 45 | POST | /api/assignments/{id}/auto-reassign | Auth | Any | Auto-reassign |
| 46 | GET | /api/assignments/{id}/available-personnel | Auth | Any | Available |
| 47-63 | GET | /api/reports/* | Auth | Any | Reports (17 endpoints) |
| 64 | GET | /api/duty-types | Auth | Any | List |
| 65 | POST | /api/duty-types | Auth | Any | Create |
| 66 | PUT | /api/duty-types/{id} | Auth | Any | Update |
| 67 | DELETE | /api/duty-types/{id} | Auth | Any | Delete |
| 68 | GET | /api/sections | Auth | Any | All sections |
| 69 | GET | /api/sections/active | Auth | Any | Active only |
| 70 | POST | /api/sections | Auth | Any | Create |
| 71 | PUT | /api/sections/{id} | Auth | Any | Update |
| 72 | POST | /api/sections/reassign | Auth | Any | Bulk reassign |
| 73 | GET | /api/holidays | Auth | Any | List |
| 74 | POST | /api/holidays | Auth | Admin/HO | Create |
| 75 | DELETE | /api/holidays/{id} | Auth | Admin/HO | Delete |
| 76 | GET | /api/i18n/translations/{locale} | Auth | Any | Get translations |
| 77 | POST | /api/i18n/translations | Auth | Admin | Upsert |
| 78 | GET | /api/i18n/missing | Auth | Admin | Missing keys |
| 79 | GET | /api/admin/config | Auth | Admin | Get config |
| 80 | PUT | /api/admin/config | Auth | Admin | Update config |
| 81 | POST | /api/support/tickets | Auth | Any | Submit ticket |
| 82 | GET | /api/support/tickets | Auth | Scoped | List tickets |
| 83 | PUT | /api/support/tickets/{id}/respond | Auth | Admin | Respond |
| 84 | PUT | /api/support/tickets/{id}/status | Auth | Admin | Update status |
| 85 | GET | /api/health | Public | — | Health check |
| 86 | GET | /api/health/ai | Public | — | AI status |

**Total: 86 endpoints**

---

## 19. Document Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0.0 | June 2026 | Generated from Codebase | Initial complete API docs |

---

*End of Document — API Documentation v1.0.0*

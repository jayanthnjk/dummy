import api from './api';

export interface SectionDto {
  id: number;
  code: string;
  name: string;
  description?: string;
  sortOrder: number;
  isActive: boolean;
}

export const sectionService = {
  list: () => api.get<SectionDto[]>('/api/sections').then((r) => r.data),
  listWithDutyTypes: () => api.get('/api/sections/with-duty-types').then((r) => r.data),
  create: (section: Partial<SectionDto>) => api.post<SectionDto>('/api/sections', section).then((r) => r.data),
  update: (id: number, section: Partial<SectionDto>) => api.put<SectionDto>(`/api/sections/${id}`, section).then((r) => r.data),
  remove: (id: number) => api.delete(`/api/sections/${id}`),
};

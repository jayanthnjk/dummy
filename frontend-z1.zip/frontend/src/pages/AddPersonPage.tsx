import React, { useState, useEffect, useMemo } from 'react';
import {
  Box, Typography, Button, Alert, CircularProgress,
  MenuItem, Card, CardContent, Switch, FormControlLabel, IconButton,
  TextField, Select, Dialog, DialogTitle, DialogContent, DialogActions,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import SaveIcon from '@mui/icons-material/Save';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import FormField from '@/components/FormField';
import { personnelService } from '@/services/personnelService';
import { sectionService, type SectionDto } from '@/services/sectionService';
import { dutyTypeService } from '@/services/dutySectionService';
import type { DutyType } from '@/types/dutySections';
import type { CreatePersonnelRequest } from '@/types';

const DESIGNATIONS = ['DCP', 'ACP', 'RPI', 'RSI', 'ARSI', 'AHC', 'APC'];
const UNITS = ['CAR', 'MT'];
const ADD_NEW_VALUE = '__ADD_NEW__';

const emptyForm: CreatePersonnelRequest = {
  badgeId: '', personName: '', dutyType: '', location: '', phoneNumber: '',
  email: '', designation: '', section: '', dateOfJoining: '',
  vehicleNumber: '', dutyLocation: '', pdms: '', licenceType: '', deployedFrom: '',
  isActive: true, unit: 'CAR',
};

const AddPersonPage: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [form, setForm] = useState<CreatePersonnelRequest>({ ...emptyForm });
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const [sections, setSections] = useState<SectionDto[]>([]);
  const [allDutyTypes, setAllDutyTypes] = useState<DutyType[]>([]);
  const [loadingDutyTypes, setLoadingDutyTypes] = useState(false);

  // Selected IDs
  const [selectedParentId, setSelectedParentId] = useState<number | ''>('');
  const [selectedSubId, setSelectedSubId] = useState<number | ''>('');

  // Add new dialog state
  const [addDialog, setAddDialog] = useState<{ open: boolean; type: 'parent' | 'sub'; name: string }>({
    open: false, type: 'parent', name: '',
  });
  const [creatingDuty, setCreatingDuty] = useState(false);

  useEffect(() => {
    sectionService.list().then(setSections).catch(() => {});
  }, []);

  // Fetch duty types when section changes
  useEffect(() => {
    if (form.section) {
      setLoadingDutyTypes(true);
      setSelectedParentId('');
      setSelectedSubId('');
      setAllDutyTypes([]);
      dutyTypeService.listBySection(form.section)
        .then((data) => { setAllDutyTypes(data); setLoadingDutyTypes(false); })
        .catch(() => setLoadingDutyTypes(false));
    } else {
      setAllDutyTypes([]);
      setSelectedParentId('');
      setSelectedSubId('');
    }
  }, [form.section]);

  // Parent duty types
  const parentDutyTypes = useMemo(() => {
    return allDutyTypes
      .filter((dt) => dt.level === 'PARENT' || (!dt.parentId && !dt.level))
      .sort((a, b) => a.sortOrder - b.sortOrder);
  }, [allDutyTypes]);

  // Sub duty types for selected parent
  const subDutyTypes = useMemo(() => {
    if (!selectedParentId) return [];
    return allDutyTypes
      .filter((dt) => dt.parentId === selectedParentId)
      .sort((a, b) => a.sortOrder - b.sortOrder);
  }, [allDutyTypes, selectedParentId]);

  // Update form.dutyType based on selection
  useEffect(() => {
    if (selectedSubId) {
      const sub = allDutyTypes.find(dt => dt.id === selectedSubId);
      updateField('dutyType', sub?.name || '');
    } else if (selectedParentId && subDutyTypes.length === 0) {
      const parent = parentDutyTypes.find(dt => dt.id === selectedParentId);
      updateField('dutyType', parent?.name || '');
    } else {
      updateField('dutyType', '');
    }
  }, [selectedParentId, selectedSubId, subDutyTypes.length]);

  const isDriver = form.unit?.toUpperCase() === 'MT';

  const updateField = (field: keyof CreatePersonnelRequest, value: string | boolean | number | undefined) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const handleParentChange = (value: string) => {
    if (value === ADD_NEW_VALUE) {
      setAddDialog({ open: true, type: 'parent', name: '' });
      return;
    }
    setSelectedParentId(value ? Number(value) : '');
    setSelectedSubId('');
  };

  const handleSubChange = (value: string) => {
    if (value === ADD_NEW_VALUE) {
      setAddDialog({ open: true, type: 'sub', name: '' });
      return;
    }
    setSelectedSubId(value ? Number(value) : '');
  };

  const handleAddDialogSave = async () => {
    if (!addDialog.name.trim()) return;
    setCreatingDuty(true);
    try {
      if (addDialog.type === 'parent') {
        const created = await dutyTypeService.create({
          name: addDialog.name.trim(), section: form.section,
          sortOrder: parentDutyTypes.length + 1, level: 'PARENT',
        });
        setAllDutyTypes(prev => [...prev, created]);
        setSelectedParentId(created.id);
        setSelectedSubId('');
      } else {
        const created = await dutyTypeService.create({
          name: addDialog.name.trim(), section: form.section,
          sortOrder: subDutyTypes.length + 1, parentId: selectedParentId as number, level: 'SUB',
        });
        setAllDutyTypes(prev => [...prev, created]);
        setSelectedSubId(created.id);
      }
      setAddDialog({ open: false, type: 'parent', name: '' });
    } catch {
      setError('Failed to create duty type');
    } finally {
      setCreatingDuty(false);
    }
  };

  const handleSave = async () => {
    setError('');
    setSaving(true);
    try {
      await personnelService.create(form);
      navigate('/personnel');
    } catch (err: unknown) {
      const axiosErr = err as { response?: { status?: number } };
      if (axiosErr.response?.status === 409) setError(t('personnel.duplicateBadgeId'));
      else setError(t('errors.serverError'));
    } finally { setSaving(false); }
  };

  const labelSx = { fontSize: '0.75rem', fontWeight: 600, color: '#4b5563', mb: 0.5 };
  const selectSx = {
    borderRadius: 1.5, fontSize: '0.85rem',
    '& fieldset': { borderColor: '#e5e7eb' },
    '&:hover fieldset': { borderColor: '#0d9488' },
    '&.Mui-focused fieldset': { borderColor: '#312e81', borderWidth: 1.5 },
  };

  return (
    <Box sx={{ p: 3, maxWidth: 960, mx: 'auto' }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
        <IconButton onClick={() => navigate('/personnel')}
          sx={{ bgcolor: '#f5f2ec', '&:hover': { bgcolor: '#ede8dc' } }}>
          <ArrowBackIcon sx={{ fontSize: 20, color: '#312e81' }} />
        </IconButton>
        <Box sx={{ flex: 1 }}>
          <Typography sx={{ fontSize: '1.4rem', fontWeight: 700, color: '#111827' }}>
            {t('personnel.addPerson')}
          </Typography>
          <Typography sx={{ fontSize: '0.82rem', color: '#9ca3af' }}>
            Fill in the details to register new personnel
          </Typography>
        </Box>
        <Button onClick={handleSave} disabled={saving || !form.badgeId || !form.personName}
          startIcon={saving ? <CircularProgress size={16} /> : <SaveIcon sx={{ fontSize: 18 }} />}
          sx={{
            textTransform: 'none', fontWeight: 600, fontSize: '0.85rem',
            bgcolor: '#312e81', color: '#fff', borderRadius: 2, px: 3, py: 1,
            '&:hover': { bgcolor: '#1e1b4b' },
            '&.Mui-disabled': { bgcolor: '#e5e7eb', color: '#9ca3af' },
          }}>
          {t('app.save')}
        </Button>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 3, borderRadius: 2 }}>{error}</Alert>}

      {/* Basic Info Card */}
      <Card variant="outlined" sx={{ borderRadius: 3, borderColor: '#f0ede6', mb: 3 }}>
        <CardContent sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
            <PersonAddIcon sx={{ color: '#312e81', fontSize: 20 }} />
            <Typography sx={{ fontWeight: 600, fontSize: '0.95rem', color: '#111827' }}>
              Basic Information
            </Typography>
          </Box>

          {/* Row 1: Unit, Badge ID, Person Name, Designation */}
          <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr 1fr' }, gap: 2, mb: 3 }}>
            <Box>
              <Typography sx={labelSx}>Unit *</Typography>
              <Select displayEmpty size="small" fullWidth
                value={form.unit || 'CAR'}
                onChange={(e) => {
                  updateField('unit', e.target.value);
                  updateField('section', '');
                  setSelectedParentId('');
                  setSelectedSubId('');
                  setAllDutyTypes([]);
                }}
                sx={selectSx}
              >
                {UNITS.map(u => <MenuItem key={u} value={u}>{u}</MenuItem>)}
              </Select>
            </Box>
            <FormField labelKey="personnel.badgeId" required value={form.badgeId}
              onChange={e => updateField('badgeId', e.target.value)} />
            <FormField labelKey="personnel.personName" required value={form.personName}
              onChange={e => updateField('personName', e.target.value)} />
            <FormField labelKey="personnel.designation" select value={form.designation}
              onChange={e => updateField('designation', e.target.value)}>
              <MenuItem value="">—</MenuItem>
              {DESIGNATIONS.map(d => <MenuItem key={d} value={d}>{d}</MenuItem>)}
            </FormField>
          </Box>

          {/* Row 2: Section & Duty Details */}
          <Typography sx={{ fontWeight: 600, fontSize: '0.88rem', color: '#374151', mb: 1.5 }}>
            Section & Duty Details
          </Typography>
          <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr 1fr' }, gap: 2 }}>
            {/* Section */}
            <Box>
              <Typography sx={labelSx}>Section *</Typography>
              <Select displayEmpty size="small" fullWidth
                value={form.section}
                onChange={(e) => updateField('section', e.target.value)}
                sx={selectSx}
              >
                <MenuItem value="">— Select Section —</MenuItem>
                {sections.map(s => <MenuItem key={s.code} value={s.code}>{s.name}</MenuItem>)}
              </Select>
            </Box>

            {/* Duty Type - regular Select */}
            <Box>
              <Typography sx={labelSx}>Duty Type</Typography>
              <Select displayEmpty size="small" fullWidth
                value={selectedParentId === '' ? '' : String(selectedParentId)}
                onChange={(e) => handleParentChange(e.target.value)}
                disabled={!form.section || loadingDutyTypes}
                sx={selectSx}
                MenuProps={{
                  disablePortal: false,
                  anchorOrigin: { vertical: 'bottom', horizontal: 'left' },
                  transformOrigin: { vertical: 'top', horizontal: 'left' },
                  slotProps: { paper: { sx: { maxHeight: 300, mt: 0.5 } } },
                  marginThreshold: 0,
                }}
              >
                <MenuItem value="">— Select Duty Type —</MenuItem>
                {parentDutyTypes.map(dt => (
                  <MenuItem key={dt.id} value={String(dt.id)}>{dt.name}</MenuItem>
                ))}
                <MenuItem value={ADD_NEW_VALUE} sx={{ color: '#312e81', fontWeight: 600, borderTop: '1px solid #e5e7eb', mt: 0.5 }}>
                  <AddCircleOutlineIcon sx={{ fontSize: 16, mr: 0.5 }} />
                  + Add New Duty Type
                </MenuItem>
              </Select>
            </Box>

            {/* Sub Duty Type - regular Select */}
            <Box>
              <Typography sx={labelSx}>Sub Duty Type</Typography>
              <Select displayEmpty size="small" fullWidth
                value={selectedSubId === '' ? '' : String(selectedSubId)}
                onChange={(e) => handleSubChange(e.target.value)}
                disabled={subDutyTypes.length === 0}
                sx={selectSx}
                MenuProps={{
                  disablePortal: false,
                  anchorOrigin: { vertical: 'bottom', horizontal: 'left' },
                  transformOrigin: { vertical: 'top', horizontal: 'left' },
                  slotProps: { paper: { sx: { maxHeight: 300, mt: 0.5 } } },
                  marginThreshold: 0,
                }}
              >
                <MenuItem value="">— {subDutyTypes.length > 0 ? 'Select Sub Duty' : 'No sub duties'} —</MenuItem>
                {subDutyTypes.map(dt => (
                  <MenuItem key={dt.id} value={String(dt.id)}>{dt.name}</MenuItem>
                ))}
                {selectedParentId && (
                  <MenuItem value={ADD_NEW_VALUE} sx={{ color: '#312e81', fontWeight: 600, borderTop: '1px solid #e5e7eb', mt: 0.5 }}>
                    <AddCircleOutlineIcon sx={{ fontSize: 16, mr: 0.5 }} />
                    + Add New Sub Duty
                  </MenuItem>
                )}
              </Select>
            </Box>

            {/* Location */}
            <FormField labelKey="personnel.location" value={form.location}
              onChange={e => updateField('location', e.target.value)} />
          </Box>
        </CardContent>
      </Card>

      {/* Contact Info Card */}
      <Card variant="outlined" sx={{ borderRadius: 3, borderColor: '#f0ede6', mb: 3 }}>
        <CardContent sx={{ p: 3 }}>
          <Typography sx={{ fontWeight: 600, fontSize: '0.95rem', color: '#111827', mb: 3 }}>
            Contact & Service Details
          </Typography>
          <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr' }, gap: 2 }}>
            <FormField labelKey="personnel.phoneNumber" value={form.phoneNumber}
              onChange={e => updateField('phoneNumber', e.target.value)} />
            <FormField labelKey="personnel.email" type="email" value={form.email}
              onChange={e => updateField('email', e.target.value)} />
            <FormField labelKey="personnel.dateOfJoining" type="date" value={form.dateOfJoining}
              onChange={e => updateField('dateOfJoining', e.target.value)}
              InputLabelProps={{ shrink: true }} />
          </Box>
          <FormControlLabel
            control={<Switch checked={form.isActive !== false} onChange={e => updateField('isActive', e.target.checked)} />}
            label={<Typography sx={{ fontSize: '0.85rem' }}>{t('personnel.active')}</Typography>}
            sx={{ mt: 2 }}
          />
        </CardContent>
      </Card>

      {/* Driver Fields Card */}
      {isDriver && (
        <Card variant="outlined" sx={{ borderRadius: 3, borderColor: '#0d9488', bgcolor: '#fffbf0', mb: 3 }}>
          <CardContent sx={{ p: 3 }}>
            <Typography sx={{ fontWeight: 600, fontSize: '0.95rem', color: '#92400e', mb: 3 }}>
              {t('personnel.driverFields')}
            </Typography>
            <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 2 }}>
              <FormField labelKey="personnel.vehicleNumber" value={form.vehicleNumber}
                onChange={e => updateField('vehicleNumber', e.target.value)} />
              <FormField labelKey="personnel.dutyLocation" value={form.dutyLocation}
                onChange={e => updateField('dutyLocation', e.target.value)} />
              <FormField labelKey="personnel.pdms" value={form.pdms}
                onChange={e => updateField('pdms', e.target.value)} />
              <FormField labelKey="personnel.licenceType" value={form.licenceType}
                onChange={e => updateField('licenceType', e.target.value)} />
              <FormField labelKey="personnel.deployedFrom" value={form.deployedFrom}
                onChange={e => updateField('deployedFrom', e.target.value)} />
            </Box>
          </CardContent>
        </Card>
      )}

      {/* Add New Duty Type Dialog */}
      <Dialog open={addDialog.open} onClose={() => setAddDialog({ ...addDialog, open: false })}
        maxWidth="xs" fullWidth>
        <DialogTitle sx={{ fontWeight: 600, fontSize: '1rem' }}>
          {addDialog.type === 'parent' ? 'Add New Duty Type' : 'Add New Sub Duty Type'}
        </DialogTitle>
        <DialogContent>
          <TextField
            autoFocus fullWidth size="small" sx={{ mt: 1 }}
            label={addDialog.type === 'parent' ? 'Duty Type Name' : 'Sub Duty Type Name'}
            value={addDialog.name}
            onChange={(e) => setAddDialog({ ...addDialog, name: e.target.value })}
            onKeyDown={(e) => { if (e.key === 'Enter') handleAddDialogSave(); }}
          />
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setAddDialog({ ...addDialog, open: false })} disabled={creatingDuty}>
            Cancel
          </Button>
          <Button onClick={handleAddDialogSave} variant="contained" disabled={creatingDuty || !addDialog.name.trim()}
            sx={{ bgcolor: '#312e81', '&:hover': { bgcolor: '#1e1b4b' } }}>
            {creatingDuty ? <CircularProgress size={16} /> : 'Add'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default AddPersonPage;

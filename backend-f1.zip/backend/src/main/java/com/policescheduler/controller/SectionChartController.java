package com.policescheduler.controller;

import com.policescheduler.entity.DutyType;
import com.policescheduler.entity.LeaveRequest;
import com.policescheduler.entity.Personnel;
import com.policescheduler.repository.DutyTypeRepository;
import com.policescheduler.repository.LeaveRequestRepository;
import com.policescheduler.repository.PersonnelRepository;
import com.policescheduler.report.generator.MtSectionReportGenerator;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

/**
 * REST controller for the Section Chart view (Assign Duties page).
 * 
 * Data model:
 * - Parent Duty = duty_type field on Personnel (also matches DutyType entity name)
 * - Sub Duty = duty_location field on Personnel (text field, NOT a child DutyType entity)
 * 
 * Hierarchy: Section -> Parent Duty (duty_type) -> Sub Duty (duty_location) -> Personnel
 */
@RestController
@RequestMapping("/api/section-chart")
public class SectionChartController {

    private final DutyTypeRepository dutyTypeRepository;
    private final PersonnelRepository personnelRepository;
    private final MtSectionReportGenerator mtSectionReportGenerator;
    private final LeaveRequestRepository leaveRequestRepository;
    private final com.policescheduler.repository.AdhocDutyRepository adhocDutyRepository;
    private final com.policescheduler.repository.AdhocDutyAssignmentRepository adhocDutyAssignmentRepository;
    private final com.policescheduler.service.ReassignmentResolverService reassignmentResolverService;

    public SectionChartController(DutyTypeRepository dutyTypeRepository,
                                  PersonnelRepository personnelRepository,
                                  MtSectionReportGenerator mtSectionReportGenerator,
                                  LeaveRequestRepository leaveRequestRepository,
                                  com.policescheduler.repository.AdhocDutyRepository adhocDutyRepository,
                                  com.policescheduler.repository.AdhocDutyAssignmentRepository adhocDutyAssignmentRepository,
                                  com.policescheduler.service.ReassignmentResolverService reassignmentResolverService) {
        this.dutyTypeRepository = dutyTypeRepository;
        this.personnelRepository = personnelRepository;
        this.mtSectionReportGenerator = mtSectionReportGenerator;
        this.leaveRequestRepository = leaveRequestRepository;
        this.adhocDutyRepository = adhocDutyRepository;
        this.adhocDutyAssignmentRepository = adhocDutyAssignmentRepository;
        this.reassignmentResolverService = reassignmentResolverService;
    }

    /**
     * GET /api/section-chart/{sectionCode}
     * Returns chart data for a section.
     * 
     * Structure:
     * - dutyCards: list of parent duty types for this section
     *   - each card has subDuties derived from distinct duty_location values of personnel
     *   - each subDuty has its personnel list
     *   - personnel with null duty_location go directly under the parent duty card
     */
    @GetMapping("/{sectionCode}")
    public ResponseEntity<Map<String, Object>> getSectionChart(@PathVariable String sectionCode) {
        String section = sectionCode.toUpperCase().trim();

        // Get parent-level duty types for this section (from duty_types table)
        List<DutyType> parentDutyTypes = dutyTypeRepository.findBySectionAndParentIsNullOrderBySortOrderAsc(section);

        // Get personnel based on section type:
        // - MT section: filter by unit='MT', group by categorizePersonnel() + FK match, sub-group by duty_location
        // - All other sections: filter by section code
        if ("MT".equals(section)) {
            // Get all MT unit personnel
            List<Personnel> mtPersonnel = personnelRepository.findByUnitAndIsActiveTrue("MT");

            // Use categorizePersonnel() to group into categories matching duty_types table names
            // Also use FK matching for personnel assigned via the UI
            Map<String, List<Personnel>> categorized = new LinkedHashMap<>();
            for (Personnel p : mtPersonnel) {
                String category = mtSectionReportGenerator.categorizePersonnel(p);
                categorized.computeIfAbsent(category, k -> new ArrayList<>()).add(p);
            }

            Set<Long> assignedIds = new HashSet<>();
            List<Map<String, Object>> dutyCards = new ArrayList<>();

            for (DutyType parent : parentDutyTypes) {
                String parentName = parent.getName().toUpperCase().trim();

                // Get personnel from categorization
                List<Personnel> dutyPersonnel = new ArrayList<>(categorized.getOrDefault(parentName, List.of()));
                Set<Long> existingIds = dutyPersonnel.stream().map(Personnel::getId).collect(Collectors.toSet());

                // Also match by duty_type_id FK pointing to this parent (for personnel assigned via UI)
                for (Personnel p : mtPersonnel) {
                    if (existingIds.contains(p.getId())) continue;
                    if (p.getDutyTypeEntity() != null && p.getDutyTypeEntity().getId().equals(parent.getId())) {
                        dutyPersonnel.add(p);
                        existingIds.add(p.getId());
                    }
                }

                // Also match personnel whose duty_type_id points to a child of this parent
                List<DutyType> childDutyTypes = dutyTypeRepository.findByParentIdOrderBySortOrderAsc(parent.getId());
                Set<Long> childIds = childDutyTypes.stream().map(DutyType::getId).collect(Collectors.toSet());
                if (!childIds.isEmpty()) {
                    for (Personnel p : mtPersonnel) {
                        if (existingIds.contains(p.getId())) continue;
                        if (p.getDutyTypeEntity() != null && childIds.contains(p.getDutyTypeEntity().getId())) {
                            dutyPersonnel.add(p);
                            existingIds.add(p.getId());
                        }
                    }
                }

                // Remove already assigned to a previous card
                dutyPersonnel = dutyPersonnel.stream()
                        .filter(p -> !assignedIds.contains(p.getId()))
                        .collect(Collectors.toList());
                for (Personnel p : dutyPersonnel) {
                    assignedIds.add(p.getId());
                }

                // Group by duty_location (sub-duty)
                Map<String, List<Personnel>> byLocation = new LinkedHashMap<>();
                List<Personnel> noLocationPersonnel = new ArrayList<>();

                for (Personnel p : dutyPersonnel) {
                    String loc = p.getDutyLocation();
                    if (loc != null && !loc.isBlank()) {
                        byLocation.computeIfAbsent(loc.trim(), k -> new ArrayList<>()).add(p);
                    } else {
                        noLocationPersonnel.add(p);
                    }
                }

                // Build sub-duties: include child DutyType entries from DB + duty_location groups
                List<Map<String, Object>> subDuties = new ArrayList<>();
                Set<String> addedSubDutyNames = new HashSet<>();

                // First, add sub-duties from the duty_types table (children of this parent)
                for (DutyType child : childDutyTypes) {
                    String childName = child.getName();
                    String childNameUpper = childName.toUpperCase().trim();
                    List<Personnel> childPersonnel = byLocation.getOrDefault(childName,
                            byLocation.getOrDefault(childNameUpper, List.of()));
                    if (childPersonnel.isEmpty()) {
                        for (Map.Entry<String, List<Personnel>> entry : byLocation.entrySet()) {
                            if (entry.getKey().toUpperCase().trim().equals(childNameUpper)) {
                                childPersonnel = entry.getValue();
                                break;
                            }
                        }
                    }
                    Map<String, Object> subDuty = new LinkedHashMap<>();
                    subDuty.put("subDutyName", childName);
                    subDuty.put("personnel", toPersonnelDtoList(childPersonnel));
                    subDuty.put("personnelCount", childPersonnel.size());
                    subDuties.add(subDuty);
                    addedSubDutyNames.add(childNameUpper);
                }

                // Then add any additional duty_location groups not already covered
                for (Map.Entry<String, List<Personnel>> entry : byLocation.entrySet()) {
                    if (!addedSubDutyNames.contains(entry.getKey().toUpperCase().trim())) {
                        Map<String, Object> subDuty = new LinkedHashMap<>();
                        subDuty.put("subDutyName", entry.getKey());
                        subDuty.put("personnel", toPersonnelDtoList(entry.getValue()));
                        subDuty.put("personnelCount", entry.getValue().size());
                        subDuties.add(subDuty);
                    }
                }

                Map<String, Object> card = new LinkedHashMap<>();
                card.put("dutyTypeId", parent.getId());
                card.put("dutyTypeName", parent.getName());
                card.put("sortOrder", parent.getSortOrder());
                card.put("subDuties", subDuties);
                card.put("personnel", toPersonnelDtoList(noLocationPersonnel));
                card.put("personnelCount", dutyPersonnel.size());
                dutyCards.add(card);
            }

            Map<String, Object> response = new LinkedHashMap<>();
            response.put("sectionCode", section);
            response.put("dutyCards", dutyCards);
            response.put("totalPersonnel", assignedIds.size());
            return ResponseEntity.ok(response);
        }

        // Non-MT sections: standard flow
        List<Personnel> sectionPersonnel = new ArrayList<>(personnelRepository.findBySectionAndIsActiveTrue(section));
        // Also try "SECTION X" format for legacy data
        if (section.length() <= 2) {
            List<Personnel> altPersonnel = personnelRepository.findBySectionAndIsActiveTrue("SECTION " + section);
            Set<Long> existingPersonnelIds = sectionPersonnel.stream().map(Personnel::getId).collect(Collectors.toSet());
            for (Personnel p : altPersonnel) {
                if (!existingPersonnelIds.contains(p.getId())) {
                    sectionPersonnel.add(p);
                }
            }
        }

        // Apply reassignment resolution: hide personnel sent away, add incoming replacements
        sectionPersonnel = reassignmentResolverService.resolveForSection(sectionPersonnel, section, java.time.LocalDate.now());

        // Group personnel by duty_type text (upper-cased for case-insensitive matching)
        Map<String, List<Personnel>> personnelByDutyType = sectionPersonnel.stream()
                .filter(p -> p.getDutyType() != null && !p.getDutyType().isBlank())
                .collect(Collectors.groupingBy(p -> p.getDutyType().toUpperCase().trim()));

        // Track which personnel have been assigned to a card
        Set<Long> assignedIds = new HashSet<>();

        List<Map<String, Object>> dutyCards = new ArrayList<>();

        for (DutyType parent : parentDutyTypes) {
            String parentName = parent.getName().toUpperCase().trim();

            // Find personnel matching this duty type by text (case-insensitive)
            List<Personnel> dutyPersonnel = new ArrayList<>(personnelByDutyType.getOrDefault(parentName, List.of()));

            // Collect IDs already in the list for dedup checks
            Set<Long> existingIds = dutyPersonnel.stream().map(Personnel::getId).collect(Collectors.toSet());

            // Also match by duty_type_id FK (for records that have the FK set)
            sectionPersonnel.stream()
                    .filter(p -> p.getDutyTypeEntity() != null && p.getDutyTypeEntity().getId().equals(parent.getId()))
                    .filter(p -> !existingIds.contains(p.getId()))
                    .forEach(p -> { dutyPersonnel.add(p); existingIds.add(p.getId()); });

            // Also match personnel whose duty_type_id points to a CHILD of this parent
            // (some personnel may be linked to child DutyType entities)
            List<DutyType> childDutyTypes = dutyTypeRepository.findByParentIdOrderBySortOrderAsc(parent.getId());
            Set<Long> childIds = childDutyTypes.stream().map(DutyType::getId).collect(Collectors.toSet());
            if (!childIds.isEmpty()) {
                sectionPersonnel.stream()
                        .filter(p -> p.getDutyTypeEntity() != null && childIds.contains(p.getDutyTypeEntity().getId()))
                        .filter(p -> !existingIds.contains(p.getId()))
                        .forEach(p -> { dutyPersonnel.add(p); existingIds.add(p.getId()); });
            }

            // Remove already assigned to a previous card
            List<Personnel> finalPersonnel = dutyPersonnel.stream()
                    .filter(p -> !assignedIds.contains(p.getId()))
                    .collect(Collectors.toList());

            // Group by duty_location (sub-duty)
            Map<String, List<Personnel>> byLocation = new LinkedHashMap<>();
            List<Personnel> noLocationPersonnel = new ArrayList<>();

            for (Personnel p : finalPersonnel) {
                assignedIds.add(p.getId());
                String loc = p.getDutyLocation();
                if (loc != null && !loc.isBlank()) {
                    byLocation.computeIfAbsent(loc.trim(), k -> new ArrayList<>()).add(p);
                } else {
                    noLocationPersonnel.add(p);
                }
            }

            // Build sub-duties: include child DutyType entries from DB + duty_location groups
            List<Map<String, Object>> subDuties = new ArrayList<>();

            // First, add sub-duties from the duty_types table (children of this parent)
            Set<String> addedSubDutyNames = new HashSet<>();
            for (DutyType child : childDutyTypes) {
                String childName = child.getName();
                String childNameUpper = childName.toUpperCase().trim();
                List<Personnel> childPersonnel = byLocation.getOrDefault(childName, 
                        byLocation.getOrDefault(childNameUpper, List.of()));
                // Also check case-insensitive
                if (childPersonnel.isEmpty()) {
                    for (Map.Entry<String, List<Personnel>> entry : byLocation.entrySet()) {
                        if (entry.getKey().toUpperCase().trim().equals(childNameUpper)) {
                            childPersonnel = entry.getValue();
                            break;
                        }
                    }
                }
                Map<String, Object> subDuty = new LinkedHashMap<>();
                subDuty.put("subDutyName", childName);
                subDuty.put("personnel", toPersonnelDtoList(childPersonnel));
                subDuty.put("personnelCount", childPersonnel.size());
                subDuties.add(subDuty);
                addedSubDutyNames.add(childNameUpper);
            }

            // Then add any additional duty_location groups not already covered by child DutyTypes
            for (Map.Entry<String, List<Personnel>> entry : byLocation.entrySet()) {
                if (!addedSubDutyNames.contains(entry.getKey().toUpperCase().trim())) {
                    Map<String, Object> subDuty = new LinkedHashMap<>();
                    subDuty.put("subDutyName", entry.getKey());
                    subDuty.put("personnel", toPersonnelDtoList(entry.getValue()));
                    subDuty.put("personnelCount", entry.getValue().size());
                    subDuties.add(subDuty);
                }
            }

            int totalCount = finalPersonnel.size();

            Map<String, Object> card = new LinkedHashMap<>();
            card.put("dutyTypeId", parent.getId());
            card.put("dutyTypeName", parent.getName());
            card.put("sortOrder", parent.getSortOrder());
            card.put("subDuties", subDuties);
            card.put("personnel", toPersonnelDtoList(noLocationPersonnel)); // personnel without sub-duty
            card.put("personnelCount", totalCount);

            dutyCards.add(card);
        }

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("sectionCode", section);
        response.put("dutyCards", dutyCards);
        response.put("totalPersonnel", assignedIds.size());

        return ResponseEntity.ok(response);
    }

    /**
     * GET /api/section-chart/{sectionCode}/form168-view
     * Returns data structured exactly like the Form 168 document.
     * 
     * Key differences from the regular chart endpoint:
     * 1. Personnel on leave are EXCLUDED from duty cards (shown only in LEAVE subsection)
     * 2. Personnel display uses badge ID if available, else "DESIGNATION SRI NAME"
     * 3. Counts per designation column (ACP, RPI, RSI, ARSI, AHC, APC, SWP, TOTAL)
     * 4. Personnel grouped by designation within each sub-duty
     * 5. No duplicates across duties
     */
    @GetMapping("/{sectionCode}/form168-view")
    public ResponseEntity<Map<String, Object>> getForm168View(@PathVariable String sectionCode) {
        String section = sectionCode.toUpperCase().trim();
        LocalDate today = LocalDate.now();

        // Get parent-level duty types for this section
        List<DutyType> parentDutyTypes = dutyTypeRepository.findBySectionAndParentIsNullOrderBySortOrderAsc(section);

        // Get all section personnel
        // MT section: fetch by unit='MT' (same as Duty Management tab)
        List<Personnel> sectionPersonnel;
        if ("MT".equals(section)) {
            sectionPersonnel = new ArrayList<>(personnelRepository.findByUnitAndIsActiveTrue("MT"));
        } else {
            sectionPersonnel = new ArrayList<>(personnelRepository.findBySectionAndIsActiveTrue(section));
            if (section.length() <= 2) {
                List<Personnel> altPersonnel = personnelRepository.findBySectionAndIsActiveTrue("SECTION " + section);
                Set<Long> existingIds = sectionPersonnel.stream().map(Personnel::getId).collect(Collectors.toSet());
                for (Personnel p : altPersonnel) {
                    if (!existingIds.contains(p.getId())) {
                        sectionPersonnel.add(p);
                    }
                }
            }
            // Apply reassignment resolution for Form 168 view
            sectionPersonnel = reassignmentResolverService.resolveForSection(sectionPersonnel, section, today);
        }

        // Identify personnel on leave (approved leaves covering today)
        Set<Long> onLeaveIds = new HashSet<>();
        Map<Long, LeaveRequest> leaveByPersonnelId = new HashMap<>();
        for (Personnel p : sectionPersonnel) {
            List<LeaveRequest> activeLeaves = leaveRequestRepository.findApprovedOverlapping(p.getId(), today, today);
            if (!activeLeaves.isEmpty()) {
                onLeaveIds.add(p.getId());
                leaveByPersonnelId.put(p.getId(), activeLeaves.get(0));
            }
        }

        // Also identify personnel with leave-like duty_type values (ABSENT, SUSPENSION, SICK, WEEKLY OFF, PERMISSION)
        Set<Long> dutyBasedLeaveIds = new HashSet<>();
        for (Personnel p : sectionPersonnel) {
            if (onLeaveIds.contains(p.getId())) continue;
            String dt = p.getDutyType() != null ? p.getDutyType().toUpperCase().trim() : "";
            String dl = p.getDutyLocation() != null ? p.getDutyLocation().toUpperCase().trim() : "";
            if (dt.contains("ABSENT") || dt.contains("SUSPENSION") || dt.contains("SICK")
                || dt.contains("WEEKLY OFF") || dt.contains("W/OFF") || dt.contains("PERMISSION")
                || dl.contains("ABSENT") || dl.contains("SUSPENSION") || dl.contains("SICK")
                || dl.contains("WEEKLY OFF") || dl.contains("W/OFF") || dl.contains("PERMISSION")) {
                dutyBasedLeaveIds.add(p.getId());
            }
        }

        // All leave personnel IDs (either from leave_requests or duty-based)
        Set<Long> allLeaveIds = new HashSet<>(onLeaveIds);
        allLeaveIds.addAll(dutyBasedLeaveIds);

        // Exclude personnel assigned to active adhoc duties today
        Set<Long> adhocAssignedIds = new HashSet<>();
        List<com.policescheduler.entity.AdhocDuty> todayAdhocDuties = adhocDutyRepository.findByDateAndStatusNot(today, "CANCELLED");
        for (com.policescheduler.entity.AdhocDuty adhocDuty : todayAdhocDuties) {
            List<com.policescheduler.entity.AdhocDutyAssignment> assignments = adhocDutyAssignmentRepository
                .findByAdhocDutyIdAndStatus(adhocDuty.getId(), "ASSIGNED");
            for (com.policescheduler.entity.AdhocDutyAssignment a : assignments) {
                adhocAssignedIds.add(a.getPersonId());
            }
        }

        // Separate personnel: on-duty vs on-leave (excluding adhoc-assigned from on-duty)
        List<Personnel> onDutyPersonnel = sectionPersonnel.stream()
                .filter(p -> !allLeaveIds.contains(p.getId()))
                .filter(p -> !adhocAssignedIds.contains(p.getId()))
                .collect(Collectors.toList());

        List<Personnel> leavePersonnel = sectionPersonnel.stream()
                .filter(p -> allLeaveIds.contains(p.getId()))
                .collect(Collectors.toList());

        // Group on-duty personnel by duty_type text OR by MT categorization
        Map<String, List<Personnel>> personnelByDutyType;
        if ("MT".equals(section)) {
            // MT section: use categorizePersonnel() to group, same as Duty Management tab
            personnelByDutyType = new LinkedHashMap<>();
            for (Personnel p : onDutyPersonnel) {
                String category = mtSectionReportGenerator.categorizePersonnel(p);
                personnelByDutyType.computeIfAbsent(category, k -> new ArrayList<>()).add(p);
            }
        } else {
            personnelByDutyType = onDutyPersonnel.stream()
                    .filter(p -> p.getDutyType() != null && !p.getDutyType().isBlank())
                    .collect(Collectors.groupingBy(p -> p.getDutyType().toUpperCase().trim()));
        }

        // Track assigned to prevent duplicates
        Set<Long> assignedIds = new HashSet<>();
        int serialNumber = 1;

        List<Map<String, Object>> dutyCards = new ArrayList<>();

        for (DutyType parent : parentDutyTypes) {
            String parentName = parent.getName().toUpperCase().trim();

            // Find personnel matching this duty type
            List<Personnel> dutyPersonnel;
            if ("MT".equals(section)) {
                // MT: get from categorized groups
                dutyPersonnel = new ArrayList<>(personnelByDutyType.getOrDefault(parentName, List.of()));
            } else {
                dutyPersonnel = new ArrayList<>(personnelByDutyType.getOrDefault(parentName, List.of()));
                Set<Long> existingIds = dutyPersonnel.stream().map(Personnel::getId).collect(Collectors.toSet());

                // Also match by duty_type_id FK
                for (Personnel p : onDutyPersonnel) {
                    if (existingIds.contains(p.getId())) continue;
                    if (p.getDutyTypeEntity() != null && p.getDutyTypeEntity().getId().equals(parent.getId())) {
                        dutyPersonnel.add(p);
                        existingIds.add(p.getId());
                    }
                }

                // Match children FK
                List<DutyType> childDutyTypes = dutyTypeRepository.findByParentIdOrderBySortOrderAsc(parent.getId());
                Set<Long> childIds = childDutyTypes.stream().map(DutyType::getId).collect(Collectors.toSet());
                if (!childIds.isEmpty()) {
                    for (Personnel p : onDutyPersonnel) {
                        if (existingIds.contains(p.getId())) continue;
                        if (p.getDutyTypeEntity() != null && childIds.contains(p.getDutyTypeEntity().getId())) {
                            dutyPersonnel.add(p);
                            existingIds.add(p.getId());
                        }
                    }
                }
            }

            // Remove already assigned
            dutyPersonnel = dutyPersonnel.stream()
                    .filter(p -> !assignedIds.contains(p.getId()))
                    .collect(Collectors.toList());
            for (Personnel p : dutyPersonnel) {
                assignedIds.add(p.getId());
            }

            // Group by duty_location (sub-duty)
            Map<String, List<Personnel>> byLocation = new LinkedHashMap<>();
            List<Personnel> noLocationPersonnel = new ArrayList<>();
            for (Personnel p : dutyPersonnel) {
                String loc = p.getDutyLocation();
                if (loc != null && !loc.isBlank()) {
                    byLocation.computeIfAbsent(loc.trim(), k -> new ArrayList<>()).add(p);
                } else {
                    noLocationPersonnel.add(p);
                }
            }

            // Build sub-duty rows
            List<Map<String, Object>> subDutyRows = new ArrayList<>();

            // From child DutyType entries (skip for MT since categorization handles grouping)
            Set<String> addedSubDutyNames = new HashSet<>();
            if (!"MT".equals(section)) {
                List<DutyType> childDutyTypesForRows = dutyTypeRepository.findByParentIdOrderBySortOrderAsc(parent.getId());
                for (DutyType child : childDutyTypesForRows) {
                    String childName = child.getName();
                    String childNameUpper = childName.toUpperCase().trim();
                    List<Personnel> childPersonnel = byLocation.getOrDefault(childName,
                            byLocation.getOrDefault(childNameUpper, List.of()));
                    if (childPersonnel.isEmpty()) {
                        for (Map.Entry<String, List<Personnel>> entry : byLocation.entrySet()) {
                            if (entry.getKey().toUpperCase().trim().equals(childNameUpper)) {
                                childPersonnel = entry.getValue();
                                break;
                            }
                        }
                    }
                    if (!childPersonnel.isEmpty()) {
                        serialNumber = addForm168RowsWithLocationGrouping(subDutyRows, serialNumber, childName, childPersonnel);
                    }
                    addedSubDutyNames.add(childNameUpper);
                }
            }

            // Additional duty_location groups not covered by child DutyTypes
            for (Map.Entry<String, List<Personnel>> entry : byLocation.entrySet()) {
                if (!addedSubDutyNames.contains(entry.getKey().toUpperCase().trim())) {
                    serialNumber = addForm168RowsWithLocationGrouping(subDutyRows, serialNumber, entry.getKey(), entry.getValue());
                }
            }

            // If no sub-duties but has personnel without location, show as single row
            if (subDutyRows.isEmpty() && !noLocationPersonnel.isEmpty()) {
                serialNumber = addForm168RowsWithLocationGrouping(subDutyRows, serialNumber, null, noLocationPersonnel);
            } else if (!noLocationPersonnel.isEmpty()) {
                // Add as direct-assignment row
                serialNumber = addForm168RowsWithLocationGrouping(subDutyRows, serialNumber, null, noLocationPersonnel);
            }

            // Calculate parent duty totals
            int[] parentCounts = new int[8]; // ACP, RPI, RSI, ARSI, AHC, APC, SWP, TOTAL
            for (Personnel p : dutyPersonnel) {
                incrementCount(parentCounts, p.getDesignation());
            }
            parentCounts[7] = parentCounts[0] + parentCounts[1] + parentCounts[2] + parentCounts[3] + parentCounts[4] + parentCounts[5];

            Map<String, Object> card = new LinkedHashMap<>();
            card.put("dutyTypeId", parent.getId());
            card.put("dutyTypeName", parent.getName());
            card.put("sortOrder", parent.getSortOrder());
            card.put("subDutyRows", subDutyRows);
            card.put("counts", parentCounts);
            card.put("personnelCount", dutyPersonnel.size());
            dutyCards.add(card);
        }

        // Build LEAVE section
        Map<String, Object> leaveSection = buildForm168LeaveSection(leavePersonnel, onLeaveIds, dutyBasedLeaveIds, leaveByPersonnelId);

        // Build grand total across all duty cards
        int[] grandTotal = new int[8];
        for (Map<String, Object> card : dutyCards) {
            int[] counts = (int[]) card.get("counts");
            for (int i = 0; i < 8; i++) {
                grandTotal[i] += counts[i];
            }
        }
        // Add leave totals to grand total
        int[] leaveTotalCounts = (int[]) leaveSection.get("counts");
        int[] sectionGrandTotal = new int[8];
        for (int i = 0; i < 8; i++) {
            sectionGrandTotal[i] = grandTotal[i] + leaveTotalCounts[i];
        }

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("sectionCode", section);
        response.put("dutyCards", dutyCards);
        response.put("leaveSection", leaveSection);
        response.put("dutySubTotal", grandTotal);
        response.put("grandTotal", sectionGrandTotal);
        response.put("totalOnDuty", assignedIds.size());
        response.put("totalOnLeave", allLeaveIds.size());
        response.put("totalPersonnel", sectionPersonnel.size());
        return ResponseEntity.ok(response);
    }

    /**
     * Adds Form 168 rows with location sub-rows inside the HEADS cell.
     * Each sub-duty row shows the sub-duty name in one part and location rows with personnel in nested rows.
     * Returns the updated serial number.
     */
    private int addForm168RowsWithLocationGrouping(List<Map<String, Object>> subDutyRows, int serialNumber,
                                                     String subDutyName, List<Personnel> personnel) {
        // Group personnel by location
        Map<String, List<Personnel>> byLocationField = new LinkedHashMap<>();
        List<Personnel> noLocation = new ArrayList<>();
        for (Personnel p : personnel) {
            String loc = p.getLocation();
            if (loc != null && !loc.isBlank()) {
                byLocationField.computeIfAbsent(loc.trim(), k -> new ArrayList<>()).add(p);
            } else {
                noLocation.add(p);
            }
        }

        // Build the row with location sub-rows
        Map<String, Object> row = buildForm168DutyRow(serialNumber++, subDutyName, personnel);

        // Add location breakdown data
        if (!byLocationField.isEmpty()) {
            List<Map<String, Object>> locationRows = new ArrayList<>();
            for (Map.Entry<String, List<Personnel>> locEntry : byLocationField.entrySet()) {
                Map<String, Object> locRow = new LinkedHashMap<>();
                locRow.put("locationName", locEntry.getKey());
                locRow.put("personnelCount", locEntry.getValue().size());
                locRow.put("personnelDetails", formatPersonnelDetailsString(locEntry.getValue()));
                // counts per designation
                int[] locCounts = new int[8];
                for (Personnel p : locEntry.getValue()) {
                    incrementCount(locCounts, p.getDesignation());
                }
                locCounts[7] = locCounts[0] + locCounts[1] + locCounts[2] + locCounts[3] + locCounts[4] + locCounts[5];
                locRow.put("counts", locCounts);
                locRow.put("total", locCounts[7]);
                locationRows.add(locRow);
            }
            if (!noLocation.isEmpty()) {
                Map<String, Object> locRow = new LinkedHashMap<>();
                locRow.put("locationName", "—");
                locRow.put("personnelCount", noLocation.size());
                locRow.put("personnelDetails", formatPersonnelDetailsString(noLocation));
                int[] locCounts = new int[8];
                for (Personnel p : noLocation) {
                    incrementCount(locCounts, p.getDesignation());
                }
                locCounts[7] = locCounts[0] + locCounts[1] + locCounts[2] + locCounts[3] + locCounts[4] + locCounts[5];
                locRow.put("counts", locCounts);
                locRow.put("total", locCounts[7]);
                locationRows.add(locRow);
            }
            row.put("locationRows", locationRows);
        }

        subDutyRows.add(row);
        return serialNumber;
    }

    /**
     * Builds a single duty row in Form 168 format with designation counts and personnel details.
     */
    private Map<String, Object> buildForm168DutyRow(int serialNumber, String subDutyName, List<Personnel> personnel) {
        int[] counts = new int[8]; // ACP, RPI, RSI, ARSI, AHC, APC, SWP, TOTAL
        for (Personnel p : personnel) {
            incrementCount(counts, p.getDesignation());
        }
        counts[7] = counts[0] + counts[1] + counts[2] + counts[3] + counts[4] + counts[5];

        // Group personnel by designation for display (exclude DCP as there is no DCP column)
        Map<String, List<Map<String, Object>>> personnelByDesignation = new LinkedHashMap<>();
        List<String> desigOrder = List.of("ACP", "RPI", "RSI", "ARSI", "AHC", "APC");
        for (String desig : desigOrder) {
            personnelByDesignation.put(desig, new ArrayList<>());
        }

        for (Personnel p : personnel) {
            String desig = normalizeDesig(p.getDesignation());
            // Skip DCP personnel as there is no DCP column in Section Form 168 view
            if ("DCP".equals(desig)) {
                continue;
            }
            Map<String, Object> pDto = new LinkedHashMap<>();
            pDto.put("id", p.getId());
            pDto.put("badgeId", p.getBadgeId());
            pDto.put("personName", p.getPersonName());
            pDto.put("designation", p.getDesignation());
            pDto.put("displayText", formatPersonnelDisplay(p));
            personnelByDesignation.computeIfAbsent(desig, k -> new ArrayList<>()).add(pDto);
        }
        // Remove empty designation groups
        personnelByDesignation.entrySet().removeIf(e -> e.getValue().isEmpty());

        // Build combined personnel details string (like in the document)
        String personnelDetailsText = formatPersonnelDetailsString(personnel);

        Map<String, Object> row = new LinkedHashMap<>();
        row.put("serialNumber", serialNumber);
        row.put("subDutyName", subDutyName);
        row.put("counts", counts);
        row.put("total", counts[7]);
        row.put("personnelByDesignation", personnelByDesignation);
        row.put("personnelDetails", personnelDetailsText);
        return row;
    }

    /**
     * Builds the LEAVE section in Form 168 format.
     * Groups leave personnel into individual categories: CL, CML, PL, EL, ABSENT, SUSPENSION, PERMISSION, SICK, WEEKLY OFF
     */
    private Map<String, Object> buildForm168LeaveSection(
            List<Personnel> leavePersonnel,
            Set<Long> onLeaveIds,
            Set<Long> dutyBasedLeaveIds,
            Map<Long, LeaveRequest> leaveByPersonnelId) {

        // Categorize leave personnel into individual types
        List<Personnel> clLeave = new ArrayList<>();
        List<Personnel> cmlLeave = new ArrayList<>();
        List<Personnel> plLeave = new ArrayList<>();
        List<Personnel> elLeave = new ArrayList<>();
        List<Personnel> absent = new ArrayList<>();
        List<Personnel> suspension = new ArrayList<>();
        List<Personnel> permission = new ArrayList<>();
        List<Personnel> sick = new ArrayList<>();
        List<Personnel> weeklyOff = new ArrayList<>();

        for (Personnel p : leavePersonnel) {
            if (onLeaveIds.contains(p.getId())) {
                // Has an approved leave record — categorize by leave type
                LeaveRequest lr = leaveByPersonnelId.get(p.getId());
                String leaveType = lr != null ? lr.getLeaveType().toUpperCase() : "";
                switch (leaveType) {
                    case "ABSENT": absent.add(p); break;
                    case "SUSPENSION": suspension.add(p); break;
                    case "PERMISSION": permission.add(p); break;
                    case "SICK":
                    case "SICK_LEAVE": sick.add(p); break;
                    case "W/OFF":
                    case "WEEKLY OFF":
                    case "WEEKLY_OFF": weeklyOff.add(p); break;
                    case "COMMUTED_LEAVE":
                    case "COMPENSATORY_OFF":
                    case "CML":
                    case "COMP_OFF": cmlLeave.add(p); break;
                    case "PATERNITY_LEAVE":
                    case "PRIVILEGE_LEAVE":
                    case "PL": plLeave.add(p); break;
                    case "EARNED_LEAVE":
                    case "EL": elLeave.add(p); break;
                    case "CASUAL_LEAVE":
                    case "CL":
                    default: clLeave.add(p); break;
                }
            } else if (dutyBasedLeaveIds.contains(p.getId())) {
                // Duty-based leave indicator
                String dt = p.getDutyType() != null ? p.getDutyType().toUpperCase() : "";
                String dl = p.getDutyLocation() != null ? p.getDutyLocation().toUpperCase() : "";
                if (dt.contains("ABSENT") || dl.contains("ABSENT")) {
                    absent.add(p);
                } else if (dt.contains("SUSPENSION") || dl.contains("SUSPENSION")) {
                    suspension.add(p);
                } else if (dt.contains("PERMISSION") || dl.contains("PERMISSION")) {
                    permission.add(p);
                } else if (dt.contains("SICK") || dl.contains("SICK")) {
                    sick.add(p);
                } else if (dt.contains("WEEKLY OFF") || dt.contains("W/OFF") || dl.contains("WEEKLY OFF") || dl.contains("W/OFF")) {
                    weeklyOff.add(p);
                } else {
                    clLeave.add(p);
                }
            }
        }

        // Build rows for each leave category (always show all even if empty)
        List<Map<String, Object>> leaveRows = new ArrayList<>();
        int serialNumber = 1;
        leaveRows.add(buildForm168LeaveRow(serialNumber++, "CL (CASUAL LEAVE)", clLeave, leaveByPersonnelId));
        leaveRows.add(buildForm168LeaveRow(serialNumber++, "CML (COMMUTED LEAVE)", cmlLeave, leaveByPersonnelId));
        leaveRows.add(buildForm168LeaveRow(serialNumber++, "PL (PATERNITY LEAVE)", plLeave, leaveByPersonnelId));
        leaveRows.add(buildForm168LeaveRow(serialNumber++, "EL (EARNED LEAVE)", elLeave, leaveByPersonnelId));
        leaveRows.add(buildForm168LeaveRow(serialNumber++, "ABSENT", absent, leaveByPersonnelId));
        leaveRows.add(buildForm168LeaveRow(serialNumber++, "SUSPENSION", suspension, leaveByPersonnelId));
        leaveRows.add(buildForm168LeaveRow(serialNumber++, "PERMISSION / RH TO RPI, RSI AND ARSI'S", permission, leaveByPersonnelId));
        leaveRows.add(buildForm168LeaveRow(serialNumber++, "SICK", sick, leaveByPersonnelId));
        leaveRows.add(buildForm168LeaveRow(serialNumber++, "WEEKLY OFF TO AHC APC", weeklyOff, leaveByPersonnelId));

        // Total counts
        int[] totalCounts = new int[8];
        for (Personnel p : leavePersonnel) {
            incrementCount(totalCounts, p.getDesignation());
        }
        totalCounts[7] = totalCounts[0] + totalCounts[1] + totalCounts[2] + totalCounts[3] + totalCounts[4] + totalCounts[5];

        Map<String, Object> leaveSection = new LinkedHashMap<>();
        leaveSection.put("name", "LEAVE");
        leaveSection.put("rows", leaveRows);
        leaveSection.put("counts", totalCounts);
        leaveSection.put("totalPersonnel", leavePersonnel.size());
        return leaveSection;
    }

    /**
     * Builds a single leave row with personnel grouped by designation.
     */
    private Map<String, Object> buildForm168LeaveRow(int serialNumber, String categoryName,
                                                      List<Personnel> personnel,
                                                      Map<Long, LeaveRequest> leaveByPersonnelId) {
        int[] counts = new int[8];
        for (Personnel p : personnel) {
            incrementCount(counts, p.getDesignation());
        }
        counts[7] = counts[0] + counts[1] + counts[2] + counts[3] + counts[4] + counts[5];

        // Group by designation with leave details (exclude DCP as there is no DCP column)
        Map<String, List<Map<String, Object>>> personnelByDesignation = new LinkedHashMap<>();
        for (Personnel p : personnel) {
            String desig = normalizeDesig(p.getDesignation());
            // Skip DCP personnel as there is no DCP column in Section Form 168 view
            if ("DCP".equals(desig)) {
                continue;
            }
            Map<String, Object> pDto = new LinkedHashMap<>();
            pDto.put("id", p.getId());
            pDto.put("badgeId", p.getBadgeId());
            pDto.put("personName", p.getPersonName());
            pDto.put("designation", p.getDesignation());
            pDto.put("displayText", formatPersonnelDisplay(p));

            // Add leave details if available
            LeaveRequest lr = leaveByPersonnelId.get(p.getId());
            if (lr != null) {
                pDto.put("leaveType", lr.getLeaveType());
                pDto.put("leaveStartDate", lr.getStartDate() != null ? lr.getStartDate().toString() : null);
                
                // Handle open-ended leaves (endDate can be null)
                if (lr.getEndDate() != null) {
                    long days = ChronoUnit.DAYS.between(lr.getStartDate(), lr.getEndDate()) + 1;
                    pDto.put("leaveEndDate", lr.getEndDate().toString());
                    pDto.put("leaveDays", days);
                } else {
                    // Open-ended leave - no end date specified
                    pDto.put("leaveEndDate", null);
                    pDto.put("leaveDays", "Open");
                }
            }
            personnelByDesignation.computeIfAbsent(desig, k -> new ArrayList<>()).add(pDto);
        }

        String personnelDetailsText = formatPersonnelDetailsString(personnel);

        Map<String, Object> row = new LinkedHashMap<>();
        row.put("serialNumber", serialNumber);
        row.put("categoryName", categoryName);
        row.put("counts", counts);
        row.put("total", counts[7]);
        row.put("personnelByDesignation", personnelByDesignation);
        row.put("personnelDetails", personnelDetailsText);
        return row;
    }

    /**
     * Format personnel display text:
     * - If badge ID exists and is not blank/auto-generated: show badge ID (e.g., "AHC-2653")
     * - If no badge ID: show "DESIGNATION SRI NAME" (e.g., "ARSI SRI SUDHEERKUMAR")
     */
    private String formatPersonnelDisplay(Personnel p) {
        String badgeId = p.getBadgeId() != null ? p.getBadgeId().trim() : "";
        String name = p.getPersonName() != null ? p.getPersonName().trim() : "";
        String desig = p.getDesignation() != null ? p.getDesignation().toUpperCase().trim() : "";

        if (!badgeId.isEmpty() && !badgeId.contains("AUTO") && !"-".equals(badgeId)) {
            return badgeId;
        } else if (!name.isEmpty()) {
            String displayName = name.toUpperCase().startsWith("SRI ") ? name.substring(4) : name;
            return desig + " SRI " + displayName;
        }
        return "";
    }

    /**
     * Format combined personnel details string matching Form 168 style.
     * e.g., "RSI SRI VISHWANATH RAI M, AHC-2653, 180, APC-0285 DIGVIJAYA K"
     * 
     * NOTE: Excludes DCP personnel since there is no DCP column in Section A-G Form 168 view.
     * DCP personnel are only shown in the strength table at the top, not in section duty rows.
     */
    private String formatPersonnelDetailsString(List<Personnel> personnel) {
        if (personnel == null || personnel.isEmpty()) return "";
        List<String> parts = new ArrayList<>();
        for (Personnel p : personnel) {
            // Skip DCP personnel as there is no DCP column in Section Form 168 view
            String desig = p.getDesignation() != null ? p.getDesignation().toUpperCase().trim() : "";
            if (desig.contains("DCP")) {
                continue;
            }
            String displayText = formatPersonnelDisplay(p);
            if (!displayText.isEmpty()) {
                parts.add(displayText);
            }
        }
        return String.join(", ", parts);
    }

    /**
     * Increment designation count in the counts array.
     * Index: 0=ACP, 1=RPI, 2=RSI, 3=ARSI, 4=AHC, 5=APC, 6=SWP
     */
    private void incrementCount(int[] counts, String designation) {
        if (designation == null) return;
        String d = designation.toUpperCase().trim();
        // Check ARSI before RSI (contains check order matters)
        if (d.contains("DCP")) { /* DCP not in this array for section view, but skip */ }
        else if (d.contains("ACP")) counts[0]++;
        else if (d.contains("RPI")) counts[1]++;
        else if (d.contains("ARSI")) counts[3]++;
        else if (d.contains("RSI")) counts[2]++;
        else if (d.contains("AHC")) counts[4]++;
        else if (d.contains("APC")) counts[5]++;
    }

    /**
     * Normalize designation string to a standard form.
     */
    private String normalizeDesig(String designation) {
        if (designation == null) return "OTHER";
        String d = designation.toUpperCase().trim();
        if (d.contains("DCP")) return "DCP";
        if (d.contains("ACP")) return "ACP";
        if (d.contains("RPI")) return "RPI";
        if (d.contains("ARSI")) return "ARSI";
        if (d.contains("RSI")) return "RSI";
        if (d.contains("AHC")) return "AHC";
        if (d.contains("APC")) return "APC";
        return "OTHER";
    }

    /**
     * PUT /api/section-chart/assign
     * Assigns a person to a duty type + optional sub-duty (duty_location).
     * 
     * Request body:
     * - personnelId (required): ID of the person
     * - dutyTypeId (required): ID of the DutyType (can be parent or sub)
     * - sectionCode (required): section code
     * - subDuty (optional): the duty_location value (sub-duty name)
     * 
     * When assigning to a sub-duty:
     * - duty_type = parent duty type name
     * - duty_location = sub-duty name
     * - duty_type_id FK = parent duty type ID
     */
    @PutMapping("/assign")
    public ResponseEntity<?> assignPersonnel(@RequestBody Map<String, Object> request) {
        Long personnelId = ((Number) request.get("personnelId")).longValue();
        Long dutyTypeId = ((Number) request.get("dutyTypeId")).longValue();
        String sectionCode = (String) request.get("sectionCode");
        String subDuty = (String) request.get("subDuty"); // duty_location

        Personnel person = personnelRepository.findById(personnelId).orElse(null);
        if (person == null) {
            return ResponseEntity.notFound().build();
        }

        DutyType dutyType = dutyTypeRepository.findById(dutyTypeId).orElse(null);
        if (dutyType == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Duty type not found"));
        }

        // Determine the parent duty type (for setting duty_type field)
        DutyType parentDutyType;
        if (dutyType.getParent() != null) {
            // dutyTypeId points to a SUB duty type — use its parent
            parentDutyType = dutyType.getParent();
        } else {
            parentDutyType = dutyType;
        }

        // Update personnel record
        person.setDutyTypeEntity(parentDutyType);
        person.setDutyType(parentDutyType.getName());
        String effectiveSection = sectionCode != null ? sectionCode : parentDutyType.getSection();
        person.setSection(effectiveSection);

        // Set unit based on section: MT section uses unit='MT', all others use 'CAR'
        if ("MT".equalsIgnoreCase(effectiveSection)) {
            person.setUnit("MT");
        } else if ("MT".equalsIgnoreCase(person.getUnit())) {
            // Moving out of MT section back to CAR
            person.setUnit("CAR");
        }

        // duty_location = sub_duty name
        if (subDuty != null && !subDuty.isBlank()) {
            person.setDutyLocation(subDuty.trim());
        } else if (dutyType.getParent() != null) {
            // If assigning directly to a SUB duty type, use its name as duty_location
            person.setDutyLocation(dutyType.getName());
        } else {
            person.setDutyLocation(null);
        }

        personnelRepository.save(person);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("personnelId", person.getId());
        result.put("badgeId", person.getBadgeId());
        result.put("personName", person.getPersonName());
        result.put("designation", person.getDesignation());
        result.put("dutyTypeId", parentDutyType.getId());
        result.put("dutyTypeName", parentDutyType.getName());
        result.put("dutyLocation", person.getDutyLocation());
        result.put("section", person.getSection());

        return ResponseEntity.ok(result);
    }

    /**
     * PUT /api/section-chart/unassign
     * Removes a person from their current duty assignment.
     * Clears duty_type, duty_type_id, and duty_location.
     */
    @PutMapping("/unassign")
    public ResponseEntity<?> unassignPersonnel(@RequestBody Map<String, Object> request) {
        Long personnelId = ((Number) request.get("personnelId")).longValue();

        Personnel person = personnelRepository.findById(personnelId).orElse(null);
        if (person == null) {
            return ResponseEntity.notFound().build();
        }

        // Clear duty assignment fields
        person.setDutyTypeEntity(null);
        person.setDutyType(null);
        person.setDutyLocation(null);

        personnelRepository.save(person);

        return ResponseEntity.ok(Map.of("success", true, "personnelId", personnelId));
    }

    /**
     * POST /api/section-chart/add-leave-type
     * Adds a new leave type as a child of the LEAVE parent duty type across ALL sections.
     * Body: { "name": "NEW LEAVE TYPE NAME" }
     */
    @PostMapping("/add-leave-type")
    public ResponseEntity<?> addLeaveType(@RequestBody Map<String, Object> request) {
        String name = (String) request.get("name");
        if (name == null || name.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Leave type name is required"));
        }
        String normalizedName = name.trim().toUpperCase();

        // Find all LEAVE parent duty types across all sections
        List<DutyType> leaveParents = dutyTypeRepository.findAll().stream()
                .filter(dt -> dt.getParent() == null)
                .filter(dt -> "LEAVE".equalsIgnoreCase(dt.getName().trim()))
                .filter(dt -> dt.getIsActive() == null || dt.getIsActive())
                .collect(Collectors.toList());

        if (leaveParents.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "No LEAVE parent duty type found in any section"));
        }

        int addedCount = 0;
        for (DutyType leaveParent : leaveParents) {
            // Check if this leave type already exists under this parent
            List<DutyType> existingChildren = dutyTypeRepository.findByParentIdOrderBySortOrderAsc(leaveParent.getId());
            boolean alreadyExists = existingChildren.stream()
                    .anyMatch(c -> normalizedName.equals(c.getName().toUpperCase().trim()));
            if (alreadyExists) {
                continue;
            }

            // Create child
            int nextSort = existingChildren.isEmpty() ? 1 : existingChildren.get(existingChildren.size() - 1).getSortOrder() + 1;
            DutyType newLeaveType = new DutyType();
            newLeaveType.setName(normalizedName);
            newLeaveType.setSection(leaveParent.getSection());
            newLeaveType.setParent(leaveParent);
            newLeaveType.setLevel("SUB");
            newLeaveType.setIsActive(true);
            newLeaveType.setSortOrder(nextSort);
            newLeaveType.setRequiredPersons(0);
            dutyTypeRepository.save(newLeaveType);
            addedCount++;
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("success", true);
        result.put("name", normalizedName);
        result.put("sectionsUpdated", addedCount);
        result.put("message", "Leave type '" + normalizedName + "' added to " + addedCount + " section(s)");
        return ResponseEntity.ok(result);
    }

    /**
     * POST /api/section-chart/add-sub-duty
     * Creates a sub-duty type in the duty_types table (child of parent with level=SUB).
     * When personnel are assigned to this sub-duty, their duty_location gets set to this name.
     * Accepts optional sortOrder — if provided at an existing position, shifts subsequent items up.
     */
    @PostMapping("/add-sub-duty")
    public ResponseEntity<?> addSubDuty(@RequestBody Map<String, Object> request) {
        String subDutyName = (String) request.get("subDutyName");
        Long parentDutyTypeId = ((Number) request.get("parentDutyTypeId")).longValue();
        Integer requestedSortOrder = request.get("sortOrder") != null ? ((Number) request.get("sortOrder")).intValue() : null;

        if (subDutyName == null || subDutyName.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Sub duty name is required"));
        }

        // Verify parent exists
        DutyType parent = dutyTypeRepository.findById(parentDutyTypeId).orElse(null);
        if (parent == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Parent duty type not found"));
        }

        // Get existing children sorted by sort_order
        List<DutyType> existingChildren = dutyTypeRepository.findByParentIdOrderBySortOrderAsc(parentDutyTypeId);
        int maxSort = existingChildren.isEmpty() ? 0 : existingChildren.get(existingChildren.size() - 1).getSortOrder();
        int nextSort = maxSort + 1;

        // Determine final sort order
        int finalSortOrder;
        if (requestedSortOrder != null) {
            // Validate: must be >= 1 and <= nextSort
            if (requestedSortOrder < 1) {
                return ResponseEntity.badRequest().body(Map.of("error", "Sort order must be at least 1"));
            }
            if (requestedSortOrder > nextSort) {
                return ResponseEntity.badRequest().body(Map.of("error", "Sort order cannot exceed " + nextSort));
            }
            finalSortOrder = requestedSortOrder;

            // Shift existing items at or after this position up by 1
            for (DutyType child : existingChildren) {
                if (child.getSortOrder() >= finalSortOrder) {
                    child.setSortOrder(child.getSortOrder() + 1);
                    dutyTypeRepository.save(child);
                }
            }
        } else {
            finalSortOrder = nextSort;
        }

        // Create child DutyType record
        DutyType subDutyType = new DutyType();
        subDutyType.setName(subDutyName.trim().toUpperCase());
        subDutyType.setSection(parent.getSection());
        subDutyType.setParent(parent);
        subDutyType.setLevel("SUB");
        subDutyType.setIsActive(true);
        subDutyType.setSortOrder(finalSortOrder);

        DutyType saved = dutyTypeRepository.save(subDutyType);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("success", true);
        result.put("subDutyId", saved.getId());
        result.put("subDutyName", saved.getName());
        result.put("sortOrder", saved.getSortOrder());
        result.put("parentDutyTypeId", parentDutyTypeId);
        result.put("parentDutyTypeName", parent.getName());

        return ResponseEntity.ok(result);
    }

    /**
     * GET /api/section-chart/search-personnel?query=...
     * Autocomplete search for personnel by badge ID or name.
     * Returns only active personnel.
     */
    @GetMapping("/search-personnel")
    public ResponseEntity<List<Map<String, Object>>> searchPersonnel(
            @RequestParam String query,
            @RequestParam(defaultValue = "10") int limit) {

        if (query == null || query.trim().length() < 2) {
            return ResponseEntity.ok(List.of());
        }

        List<Personnel> results = personnelRepository.searchByNameOrBadgeId(
                query.trim(), org.springframework.data.domain.PageRequest.of(0, limit));

        List<Map<String, Object>> dtos = results.stream().map(p -> {
            Map<String, Object> dto = new LinkedHashMap<>();
            dto.put("id", p.getId());
            dto.put("badgeId", p.getBadgeId());
            dto.put("personName", p.getPersonName());
            dto.put("designation", p.getDesignation());
            dto.put("currentSection", p.getSection());
            dto.put("currentDutyType", p.getDutyType());
            dto.put("currentDutyLocation", p.getDutyLocation());
            return dto;
        }).collect(Collectors.toList());

        return ResponseEntity.ok(dtos);
    }

    /**
     * Converts a list of Personnel entities to DTO maps for JSON response.
     */
    private List<Map<String, Object>> toPersonnelDtoList(List<Personnel> personnel) {
        LocalDate today = LocalDate.now();
        return personnel.stream().map(p -> {
            Map<String, Object> dto = new LinkedHashMap<>();
            dto.put("id", p.getId());
            dto.put("badgeId", p.getBadgeId());
            dto.put("personName", p.getPersonName());
            dto.put("designation", p.getDesignation());
            dto.put("dutyLocation", p.getDutyLocation());
            dto.put("location", p.getLocation());
            // Check if person has an active approved leave today
            List<LeaveRequest> activeLeaves = leaveRequestRepository.findApprovedOverlapping(
                    p.getId(), today, today);
            if (!activeLeaves.isEmpty()) {
                LeaveRequest leave = activeLeaves.get(0);
                dto.put("onLeave", true);
                dto.put("leaveType", leave.getLeaveType());
                dto.put("leaveStartDate", leave.getStartDate().toString());
                dto.put("leaveEndDate", leave.getEndDate() != null ? leave.getEndDate().toString() : null);
                long days = leave.getEndDate() != null
                        ? java.time.temporal.ChronoUnit.DAYS.between(leave.getStartDate(), leave.getEndDate()) + 1
                        : java.time.temporal.ChronoUnit.DAYS.between(leave.getStartDate(), today) + 1;
                dto.put("leaveDays", days);
                dto.put("leaveOpenEnded", leave.getEndDate() == null);
                dto.put("leaveRequestId", leave.getId());
            } else {
                dto.put("onLeave", false);
            }
            // Check if person is assigned to an active adhoc duty today
            List<com.policescheduler.entity.AdhocDutyAssignment> adhocAssignments = adhocDutyAssignmentRepository
                .findByPersonIdAndStatus(p.getId(), "ASSIGNED");
            for (com.policescheduler.entity.AdhocDutyAssignment a : adhocAssignments) {
                com.policescheduler.entity.AdhocDuty adhocDuty = adhocDutyRepository.findById(a.getAdhocDutyId()).orElse(null);
                if (adhocDuty != null && adhocDuty.getDate().equals(today) && !"CANCELLED".equals(adhocDuty.getStatus())) {
                    dto.put("onAdhocDuty", true);
                    dto.put("adhocDutyName", adhocDuty.getDutyName());
                    dto.put("adhocDutyStartTime", adhocDuty.getStartTime().toString());
                    dto.put("adhocDutyEndTime", adhocDuty.getEndTime().toString());
                    dto.put("adhocDutyId", adhocDuty.getId());
                    break;
                }
            }
            if (!dto.containsKey("onAdhocDuty")) {
                dto.put("onAdhocDuty", false);
            }
            return dto;
        }).collect(Collectors.toList());
    }

    /**
     * PATCH /api/section-chart/duty-type/{dutyTypeId}/rename
     * Renames a duty type (parent or sub). Also updates all personnel records that reference the old name.
     * - Parent duty: updates duty_types.name + personnel.duty_type for all matching personnel
     * - Sub duty: updates duty_types.name + personnel.duty_location for all matching personnel
     * Body: { "name": "NEW NAME" }
     */
    @PatchMapping("/duty-type/{dutyTypeId}/rename")
    public ResponseEntity<?> renameDutyType(@PathVariable Long dutyTypeId, @RequestBody Map<String, Object> request) {
        String newName = (String) request.get("name");
        if (newName == null || newName.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Name is required"));
        }
        newName = newName.trim().toUpperCase();

        DutyType dutyType = dutyTypeRepository.findById(dutyTypeId).orElse(null);
        if (dutyType == null) {
            return ResponseEntity.notFound().build();
        }

        String oldName = dutyType.getName();
        boolean isParent = dutyType.getParent() == null;

        // Update the duty type name
        dutyType.setName(newName);
        dutyTypeRepository.save(dutyType);

        // Update personnel records
        List<Personnel> allActive = personnelRepository.findByIsActiveTrue();
        int updatedCount = 0;

        if (isParent) {
            // Parent duty: update personnel.duty_type where it matches the old name
            for (Personnel p : allActive) {
                boolean match = false;
                if (p.getDutyTypeEntity() != null && p.getDutyTypeEntity().getId().equals(dutyTypeId)) {
                    match = true;
                } else if (p.getDutyType() != null && p.getDutyType().toUpperCase().trim().equals(oldName.toUpperCase().trim())) {
                    match = true;
                }
                if (match) {
                    p.setDutyType(newName);
                    personnelRepository.save(p);
                    updatedCount++;
                }
            }
        } else {
            // Sub duty: update personnel.duty_location where it matches the old name
            // Only update personnel under the same parent duty type
            DutyType parentDuty = dutyType.getParent();
            String parentName = parentDuty != null ? parentDuty.getName().toUpperCase().trim() : "";
            for (Personnel p : allActive) {
                boolean underParent = false;
                if (p.getDutyTypeEntity() != null && parentDuty != null && p.getDutyTypeEntity().getId().equals(parentDuty.getId())) {
                    underParent = true;
                } else if (p.getDutyType() != null && p.getDutyType().toUpperCase().trim().equals(parentName)) {
                    underParent = true;
                }
                if (underParent && p.getDutyLocation() != null && p.getDutyLocation().toUpperCase().trim().equals(oldName.toUpperCase().trim())) {
                    p.setDutyLocation(newName);
                    personnelRepository.save(p);
                    updatedCount++;
                }
            }
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("success", true);
        result.put("dutyTypeId", dutyTypeId);
        result.put("oldName", oldName);
        result.put("newName", newName);
        result.put("personnelUpdated", updatedCount);
        return ResponseEntity.ok(result);
    }

    /**
     * PATCH /api/section-chart/sub-duty/rename
     * Renames a sub-duty by parent ID + old name. Updates duty_types.name + personnel.duty_location.
     * Body: { "parentDutyTypeId": 123, "oldName": "OLD NAME", "newName": "NEW NAME" }
     */
    @PatchMapping("/sub-duty/rename")
    public ResponseEntity<?> renameSubDuty(@RequestBody Map<String, Object> request) {
        Long parentDutyTypeId = request.get("parentDutyTypeId") != null ? ((Number) request.get("parentDutyTypeId")).longValue() : null;
        String oldName = (String) request.get("oldName");
        String newName = (String) request.get("newName");

        if (parentDutyTypeId == null || oldName == null || oldName.isBlank() || newName == null || newName.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "parentDutyTypeId, oldName, and newName are required"));
        }
        newName = newName.trim().toUpperCase();
        String oldNameUpper = oldName.trim().toUpperCase();

        DutyType parent = dutyTypeRepository.findById(parentDutyTypeId).orElse(null);
        if (parent == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Parent duty type not found"));
        }

        // Find the child duty type by name under this parent
        List<DutyType> children = dutyTypeRepository.findByParentIdOrderBySortOrderAsc(parentDutyTypeId);
        DutyType childDutyType = null;
        for (DutyType child : children) {
            if (child.getName().toUpperCase().trim().equals(oldNameUpper)) {
                childDutyType = child;
                break;
            }
        }

        // Update duty_types record if found
        if (childDutyType != null) {
            childDutyType.setName(newName);
            dutyTypeRepository.save(childDutyType);
        }

        // Update all personnel whose duty_location matches the old name under this parent
        String parentName = parent.getName().toUpperCase().trim();
        List<Personnel> allActive = personnelRepository.findByIsActiveTrue();
        int updatedCount = 0;
        for (Personnel p : allActive) {
            boolean underParent = false;
            if (p.getDutyTypeEntity() != null && p.getDutyTypeEntity().getId().equals(parentDutyTypeId)) {
                underParent = true;
            } else if (p.getDutyType() != null && p.getDutyType().toUpperCase().trim().equals(parentName)) {
                underParent = true;
            }
            if (underParent && p.getDutyLocation() != null && p.getDutyLocation().toUpperCase().trim().equals(oldNameUpper)) {
                p.setDutyLocation(newName);
                personnelRepository.save(p);
                updatedCount++;
            }
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("success", true);
        result.put("oldName", oldName);
        result.put("newName", newName);
        result.put("personnelUpdated", updatedCount);
        return ResponseEntity.ok(result);
    }

    /**
     * DELETE /api/section-chart/duty-type/{dutyTypeId}
     * Deletes a parent duty type. Unassigns all personnel under it first.
     */
    @DeleteMapping("/duty-type/{dutyTypeId}")
    public ResponseEntity<?> deleteDutyType(@PathVariable Long dutyTypeId) {
        DutyType dutyType = dutyTypeRepository.findById(dutyTypeId).orElse(null);
        if (dutyType == null) {
            return ResponseEntity.notFound().build();
        }

        // Unassign all personnel linked to this duty type (by FK or text match)
        List<Personnel> allActive = personnelRepository.findByIsActiveTrue();
        String dutyName = dutyType.getName().toUpperCase().trim();

        for (Personnel p : allActive) {
            boolean match = false;
            if (p.getDutyTypeEntity() != null && p.getDutyTypeEntity().getId().equals(dutyTypeId)) {
                match = true;
            } else if (p.getDutyType() != null && p.getDutyType().toUpperCase().trim().equals(dutyName)) {
                match = true;
            }
            if (match) {
                p.setDutyTypeEntity(null);
                p.setDutyType(null);
                p.setDutyLocation(null);
                personnelRepository.save(p);
            }
        }

        // Delete child duty types first
        List<DutyType> children = dutyTypeRepository.findByParentIdOrderBySortOrderAsc(dutyTypeId);
        for (DutyType child : children) {
            dutyTypeRepository.delete(child);
        }

        // Delete the parent duty type
        dutyTypeRepository.delete(dutyType);

        // Re-sequence remaining siblings (close the gap)
        String section = dutyType.getSection();
        List<DutyType> remainingSiblings = dutyTypeRepository.findBySectionAndParentIsNullOrderBySortOrderAsc(section);
        int seq = 1;
        for (DutyType sibling : remainingSiblings) {
            if (sibling.getSortOrder() != seq) {
                sibling.setSortOrder(seq);
                dutyTypeRepository.save(sibling);
            }
            seq++;
        }

        return ResponseEntity.ok(Map.of("success", true, "deleted", dutyType.getName()));
    }

    /**
     * DELETE /api/section-chart/sub-duty
     * Deletes a sub-duty (duty_location). Clears duty_location for all personnel with that value
     * under the specified parent duty type.
     */
    @DeleteMapping("/sub-duty")
    public ResponseEntity<?> deleteSubDuty(
            @RequestParam Long parentDutyTypeId,
            @RequestParam String subDutyName) {

        if (subDutyName == null || subDutyName.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Sub duty name is required"));
        }

        DutyType parent = dutyTypeRepository.findById(parentDutyTypeId).orElse(null);
        if (parent == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Parent duty type not found"));
        }

        // Find all personnel with this duty_location under the parent duty type
        String parentName = parent.getName().toUpperCase().trim();
        String subName = subDutyName.trim();
        List<Personnel> allActive = personnelRepository.findByIsActiveTrue();
        int cleared = 0;

        for (Personnel p : allActive) {
            boolean isUnderParent = false;
            if (p.getDutyTypeEntity() != null && p.getDutyTypeEntity().getId().equals(parentDutyTypeId)) {
                isUnderParent = true;
            } else if (p.getDutyType() != null && p.getDutyType().toUpperCase().trim().equals(parentName)) {
                isUnderParent = true;
            }

            if (isUnderParent && p.getDutyLocation() != null && p.getDutyLocation().trim().equalsIgnoreCase(subName)) {
                p.setDutyLocation(null);
                personnelRepository.save(p);
                cleared++;
            }
        }

        // Also delete the DutyType child record if it exists
        List<DutyType> children = dutyTypeRepository.findByParentIdOrderBySortOrderAsc(parentDutyTypeId);
        for (DutyType child : children) {
            if (child.getName().trim().equalsIgnoreCase(subName)) {
                dutyTypeRepository.delete(child);
                break;
            }
        }

        // Re-sequence remaining children (close the gap)
        List<DutyType> remainingChildren = dutyTypeRepository.findByParentIdOrderBySortOrderAsc(parentDutyTypeId);
        int seq = 1;
        for (DutyType child : remainingChildren) {
            if (child.getSortOrder() != seq) {
                child.setSortOrder(seq);
                dutyTypeRepository.save(child);
            }
            seq++;
        }

        return ResponseEntity.ok(Map.of(
                "success", true,
                "subDutyName", subName,
                "personnelCleared", cleared
        ));
    }
}

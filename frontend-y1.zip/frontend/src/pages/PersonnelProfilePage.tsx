import React, { useEffect, useState, useMemo } from 'react';
import {
  Box, Typography, Card, CardContent, Button,
  CircularProgress, Alert, Chip, Switch, FormControlLabel, MenuItem,
  Tab, Tabs, Select, Dialog, DialogTitle, DialogContent, DialogActions, TextField,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import EditIcon from '@mui/icons-material/Edit';
import SaveIcon from '@mui/icons-material/Save';
import CancelIcon from '@mui/icons-material/Cancel';
import DeleteIcon from '@mui/icons-material/Delete';
import PhoneIcon from '@mui/icons-material/Phone';
import EmailIcon from '@mui/icons-material/Email';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import { useTranslation } from 'react-i18next';
import { useNavigate, useParams } from 'react-router-dom';
import FormField from '@/components/FormField';
import PageHeader from '@/components/common/PageHeader';
import { PersonAvatar } from '@/components/common/PersonAvatar';
import StatusBadge from '@/components/common/StatusBadge';
import { personnelService } from '@/services/personnelService';
import { sectionService, type SectionDto } from '@/services/sectionService';
import { dutyTypeService } from '@/services/dutySectionService';
import type { DutyType } from '@/types/dutySections';
import type { PersonnelDto, UpdatePersonnelRequest } from '@/types';

const DESIGNATIONS = ['DCP', 'ACP', 'RPI', 'RSI', 'ARSI', 'AHC', 'APC'];
const UNITS = ['CAR', 'MT'];
const ADD_NEW_VALUE = '__ADD_NEW__';

const PersonnelProfilePage: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { badgeId } = useParams<{ badgeId: string }>();
  const [person, setPerson] = useState<PersonnelDto | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [sections, setSections] = useState<SectionDto[]>([]);
  const [activeTab, setActiveTab] = useState(0);
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<UpdatePersonnelRequest>({});

  // Duty type state
  const [allDutyTypes, setAllDutyTypes] = useState<DutyType[]>([]);
  const [loadingDutyTypes, setLoadingDutyTypes] = useState(false);
  const [selectedParentId, setSelectedParentId] = useState<number | ''>('');
  const [selectedSubId, setSelectedSubId] = useState<number | ''>('');

  // Add new duty type dialog
  const [addDialog, setAddDialog] = useState<{ open: boolean; type: 'parent' | 'sub'; name: string }>({
    open: false, type: 'parent', name: '',
  });
  const [creatingDuty, setCreatingDuty] = useState(false);

  // Delete state
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [deleteCode, setDeleteCode] = useState('');
  const [deleteInput, setDeleteInput] = useState('');

  const generateDeleteCode = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = '';
    for (let i = 0; i < 6; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  };

  useEffect(() => {
    if (!badgeId) return;
    setLoading(true);
    Promise.all([
      personnelService.getByBadgeId(badgeId),
      sectionService.list(),
    ])
      .then(([data, secs]) => { setPerson(data); setForm(data); setSections(secs); })
      .catch(() => setError('Personnel not found'))
      .finally(() => setLoading(false));
  }, [badgeId]);

  // Fetch duty types when section changes during editing
  useEffect(() => {
    if (form.section && editing) {
      setLoadingDutyTypes(true);
      dutyTypeService.listBySection(form.section)
        .then((data) => {
          setAllDutyTypes(data);
          // Try to match existing dutyType to set parent/sub selections
          if (form.dutyType) {
            const matchSub = data.find(dt => dt.name === form.dutyType && dt.parentId);
            if (matchSub) {
              setSelectedSubId(matchSub.id);
              setSelectedParentId(matchSub.parentId!);
            } else {
              const matchParent = data.find(dt => dt.name === form.dutyType && !dt.parentId);
              if (matchParent) {
                setSelectedParentId(matchParent.id);
                setSelectedSubId('');
              }
            }
          }
          setLoadingDutyTypes(false);
        })
        .catch(() => setLoadingDutyTypes(false));
    }
  }, [form.section, editing]);

  // Parent duty types
  const parentDutyTypes = useMemo(() => {
    return allDutyTypes
      .filter((dt) => dt.level === 'PARENT' || (!dt.parentId && !dt.level))
      .sort((a, b) => a.sortOrder - b.sortOrder);
  }, [allDutyTypes]);

  // Sub duty types for selected parent
  const subDutyTypes = useMemo(() => {
    if (!selectedParentId) return [];
    return allDutyTypes
      .filter((dt) => dt.parentId === selectedParentId)
      .sort((a, b) => a.sortOrder - b.sortOrder);
  }, [allDutyTypes, selectedParentId]);

  const isDriver = form.unit?.toUpperCase() === 'MT';

  // Update form.dutyType based on selection
  useEffect(() => {
    if (!editing) return;
    if (isDriver) {
      // MT unit: duty_type = parent name, duty_location = sub-duty name
      if (selectedParentId) {
        const parent = parentDutyTypes.find(dt => dt.id === selectedParentId);
        if (parent) updateField('dutyType', parent.name);
      }
      if (selectedSubId) {
        const sub = allDutyTypes.find(dt => dt.id === selectedSubId);
        if (sub) updateField('dutyLocation', sub.name);
      } else {
        updateField('dutyLocation', '');
      }
    } else {
      // CAR unit: duty_type = sub-duty name (or parent if no sub)
      if (selectedSubId) {
        const sub = allDutyTypes.find(dt => dt.id === selectedSubId);
        if (sub) updateField('dutyType', sub.name);
      } else if (selectedParentId && subDutyTypes.length === 0) {
        const parent = parentDutyTypes.find(dt => dt.id === selectedParentId);
        if (parent) updateField('dutyType', parent.name);
      }
    }
  }, [selectedParentId, selectedSubId, subDutyTypes.length, editing, isDriver]);

  const handleSave = async () => {
    if (!badgeId) return;
    setSaving(true);
    try {
      const updated = await personnelService.update(badgeId, form);
      setPerson(updated);
      setEditing(false);
    } catch { setError(t('errors.serverError')); }
    finally { setSaving(false); }
  };

  const handleDelete = async () => {
    if (!badgeId) return;
    setDeleting(true);
    try {
      await personnelService.delete(badgeId);
      navigate('/personnel');
    } catch { setError('Failed to delete personnel record'); }
    finally { setDeleting(false); setDeleteDialogOpen(false); }
  };

  const updateField = (field: keyof UpdatePersonnelRequest, value: string | boolean) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const handleTabChange = (_event: React.SyntheticEvent, newValue: number) => {
    setActiveTab(newValue);
  };

  const handleParentChange = (value: string) => {
    if (value === ADD_NEW_VALUE) {
      setAddDialog({ open: true, type: 'parent', name: '' });
      return;
    }
    setSelectedParentId(value ? Number(value) : '');
    setSelectedSubId('');
  };

  const handleSubChange = (value: string) => {
    if (value === ADD_NEW_VALUE) {
      setAddDialog({ open: true, type: 'sub', name: '' });
      return;
    }
    setSelectedSubId(value ? Number(value) : '');
  };

  const handleAddDialogSave = async () => {
    if (!addDialog.name.trim()) return;
    setCreatingDuty(true);
    try {
      if (addDialog.type === 'parent') {
        const created = await dutyTypeService.create({
          name: addDialog.name.trim(), section: form.section!,
          sortOrder: parentDutyTypes.length + 1, level: 'PARENT',
        });
        setAllDutyTypes(prev => [...prev, created]);
        setSelectedParentId(created.id);
        setSelectedSubId('');
      } else {
        const created = await dutyTypeService.create({
          name: addDialog.name.trim(), section: form.section!,
          sortOrder: subDutyTypes.length + 1, parentId: selectedParentId as number, level: 'SUB',
        });
        setAllDutyTypes(prev => [...prev, created]);
        setSelectedSubId(created.id);
      }
      setAddDialog({ open: false, type: 'parent', name: '' });
    } catch {
      setError('Failed to create duty type');
    } finally {
      setCreatingDuty(false);
    }
  };

  const labelSx = { fontSize: '0.75rem', fontWeight: 600, color: '#4b5563', mb: 0.5 };
  const selectSx = {
    borderRadius: 1.5, fontSize: '0.85rem',
    '& fieldset': { borderColor: '#e5e7eb' },
    '&:hover fieldset': { borderColor: '#0d9488' },
    '&.Mui-focused fieldset': { borderColor: '#312e81', borderWidth: 1.5 },
  };

  if (loading) return <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}><CircularProgress /></Box>;
  if (error || !person) return (
    <Box sx={{ p: 3 }}>
      <Alert severity="error">{error || 'Not found'}</Alert>
      <Button onClick={() => navigate('/personnel')} sx={{ mt: 2 }}>Back to Personnel</Button>
    </Box>
  );

  const personName = person.personName || 'Unknown';

  return (
    <Box>
      {/* PageHeader with breadcrumbs and back action */}
      <PageHeader
        title={personName}
        breadcrumbs={[
          { label: 'Home', path: '/' },
          { label: 'Personnel', path: '/personnel' },
          { label: personName },
        ]}
        actions={[
          {
            label: 'Back',
            variant: 'ghost',
            icon: <ArrowBackIcon />,
            onClick: () => navigate('/personnel'),
          },
          ...(editing
            ? []
            : [
                {
                  label: 'Delete',
                  variant: 'destructive' as const,
                  icon: <DeleteIcon />,
                  onClick: () => {
                    setDeleteCode(generateDeleteCode());
                    setDeleteInput('');
                    setDeleteDialogOpen(true);
                  },
                },
                {
                  label: 'Edit',
                  variant: 'secondary' as const,
                  icon: <EditIcon />,
                  onClick: () => setEditing(true),
                },
              ]
          ),
        ]}
      />

      <Box sx={{ p: 3, maxWidth: 1000, mx: 'auto' }}>
        {/* Profile Hero Section */}
        <Card
          variant="outlined"
          sx={{
            borderRadius: 3,
            borderColor: 'divider',
            mb: 3,
            overflow: 'visible',
          }}
        >
          <CardContent sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', gap: 3, alignItems: 'center', flexWrap: { xs: 'wrap', sm: 'nowrap' } }}>
              <PersonAvatar
                name={personName}
                size="large"
                badgeId={person.badgeId}
                designation={person.designation}
              />

              <Box sx={{ flex: 1, minWidth: 0 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 0.5, flexWrap: 'wrap' }}>
                  <Typography variant="h5" fontWeight={700} color="text.primary">
                    {personName}
                  </Typography>
                  {person.designation && (
                    <Chip
                      label={person.designation}
                      size="small"
                      sx={{ bgcolor: '#ede9fe', color: '#6d28d9', fontWeight: 600, fontSize: '0.75rem' }}
                    />
                  )}
                  <StatusBadge
                    status={person.isActive ? 'Active' : 'Cancelled'}
                    size="small"
                    showDot
                  />
                </Box>

                <Box sx={{ display: 'flex', gap: 3, flexWrap: 'wrap', color: 'text.secondary', mt: 1 }}>
                  <Typography variant="body2" sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    Badge: <strong>{person.badgeId}</strong>
                  </Typography>
                  {person.unit && (
                    <Typography variant="body2" sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                      Unit: <strong>{person.unit}</strong>
                    </Typography>
                  )}
                  {person.section && (
                    <Typography variant="body2" sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                      <LocationOnIcon sx={{ fontSize: 16 }} /> Section {person.section}
                    </Typography>
                  )}
                </Box>
              </Box>

              {editing && (
                <Box sx={{ display: 'flex', gap: 1, flexShrink: 0 }}>
                  <Button
                    startIcon={<CancelIcon sx={{ fontSize: 16 }} />}
                    onClick={() => { setEditing(false); setForm(person); setSelectedParentId(''); setSelectedSubId(''); }}
                    size="small"
                    sx={{ textTransform: 'none', color: 'text.secondary' }}
                  >
                    Cancel
                  </Button>
                  <Button
                    variant="contained"
                    startIcon={saving ? <CircularProgress size={14} /> : <SaveIcon sx={{ fontSize: 16 }} />}
                    onClick={handleSave}
                    disabled={saving}
                    size="small"
                    sx={{ textTransform: 'none' }}
                  >
                    Save
                  </Button>
                </Box>
              )}
            </Box>
          </CardContent>
        </Card>

        {/* Tabbed Content */}
        <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
          <Tabs value={activeTab} onChange={handleTabChange} aria-label="Personnel profile tabs">
            <Tab label="Details" id="profile-tab-0" aria-controls="profile-tabpanel-0" />
            <Tab label="Contact" id="profile-tab-1" aria-controls="profile-tabpanel-1" />
          </Tabs>
        </Box>

        {/* Details Tab */}
        <Box role="tabpanel" hidden={activeTab !== 0} id="profile-tabpanel-0" aria-labelledby="profile-tab-0">
          {activeTab === 0 && (
            <>
              <Card variant="outlined" sx={{ borderRadius: 3, borderColor: 'divider', mb: 3 }}>
                <CardContent sx={{ p: 3 }}>
                  <Typography variant="subtitle1" fontWeight={600} color="text.primary" sx={{ mb: 3 }}>
                    Basic Information
                  </Typography>
                  {editing ? (
                    <>
                      {/* Row 1: Unit, Badge ID, Person Name, Designation */}
                      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr 1fr' }, gap: 2, mb: 3 }}>
                        <Box>
                          <Typography sx={labelSx}>Unit</Typography>
                          <Select displayEmpty size="small" fullWidth
                            value={form.unit || 'CAR'}
                            onChange={(e) => {
                              updateField('unit', e.target.value);
                              updateField('section', '');
                              setSelectedParentId('');
                              setSelectedSubId('');
                              setAllDutyTypes([]);
                            }}
                            sx={selectSx}
                          >
                            {UNITS.map(u => <MenuItem key={u} value={u}>{u}</MenuItem>)}
                          </Select>
                        </Box>
                        <FormField labelKey="personnel.badgeId" value={form.badgeId || ''} onChange={e => updateField('badgeId', e.target.value)} />
                        <FormField labelKey="personnel.personName" value={form.personName || ''} onChange={e => updateField('personName', e.target.value)} />
                        <FormField labelKey="personnel.designation" select value={form.designation || ''} onChange={e => updateField('designation', e.target.value)}>
                          <MenuItem value="">—</MenuItem>
                          {DESIGNATIONS.map(d => <MenuItem key={d} value={d}>{d}</MenuItem>)}
                        </FormField>
                      </Box>

                      {/* Row 2: Section & Duty Details */}
                      <Typography sx={{ fontWeight: 600, fontSize: '0.88rem', color: '#374151', mb: 1.5 }}>
                        Section & Duty Details
                      </Typography>
                      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr 1fr' }, gap: 2, mb: 2 }}>
                        {/* Section */}
                        <Box>
                          <Typography sx={labelSx}>Section</Typography>
                          <Select displayEmpty size="small" fullWidth
                            value={form.section || ''}
                            onChange={(e) => {
                              updateField('section', e.target.value);
                              setSelectedParentId('');
                              setSelectedSubId('');
                              setAllDutyTypes([]);
                            }}
                            sx={selectSx}
                          >
                            <MenuItem value="">— Select Section —</MenuItem>
                            {sections.map(s => <MenuItem key={s.code} value={s.code}>{s.name}</MenuItem>)}
                          </Select>
                        </Box>

                        {/* Duty Type */}
                        <Box>
                          <Typography sx={labelSx}>Duty Type</Typography>
                          <Select displayEmpty size="small" fullWidth
                            value={selectedParentId === '' ? '' : String(selectedParentId)}
                            onChange={(e) => handleParentChange(e.target.value)}
                            disabled={!form.section || loadingDutyTypes}
                            sx={selectSx}
                            MenuProps={{
                              disablePortal: false,
                              anchorOrigin: { vertical: 'bottom', horizontal: 'left' },
                              transformOrigin: { vertical: 'top', horizontal: 'left' },
                              slotProps: { paper: { sx: { maxHeight: 300, mt: 0.5 } } },
                              marginThreshold: 0,
                            }}
                          >
                            <MenuItem value="">— Select Duty Type —</MenuItem>
                            {parentDutyTypes.map(dt => (
                              <MenuItem key={dt.id} value={String(dt.id)}>{dt.name}</MenuItem>
                            ))}
                            <MenuItem value={ADD_NEW_VALUE} sx={{ color: '#312e81', fontWeight: 600, borderTop: '1px solid #e5e7eb', mt: 0.5 }}>
                              <AddCircleOutlineIcon sx={{ fontSize: 16, mr: 0.5 }} />
                              + Add New Duty Type
                            </MenuItem>
                          </Select>
                        </Box>

                        {/* Sub Duty Type */}
                        <Box>
                          <Typography sx={labelSx}>Sub Duty Type</Typography>
                          <Select displayEmpty size="small" fullWidth
                            value={selectedSubId === '' ? '' : String(selectedSubId)}
                            onChange={(e) => handleSubChange(e.target.value)}
                            disabled={subDutyTypes.length === 0}
                            sx={selectSx}
                            MenuProps={{
                              disablePortal: false,
                              anchorOrigin: { vertical: 'bottom', horizontal: 'left' },
                              transformOrigin: { vertical: 'top', horizontal: 'left' },
                              slotProps: { paper: { sx: { maxHeight: 300, mt: 0.5 } } },
                              marginThreshold: 0,
                            }}
                          >
                            <MenuItem value="">— {subDutyTypes.length > 0 ? 'Select Sub Duty' : 'No sub duties'} —</MenuItem>
                            {subDutyTypes.map(dt => (
                              <MenuItem key={dt.id} value={String(dt.id)}>{dt.name}</MenuItem>
                            ))}
                            {selectedParentId && (
                              <MenuItem value={ADD_NEW_VALUE} sx={{ color: '#312e81', fontWeight: 600, borderTop: '1px solid #e5e7eb', mt: 0.5 }}>
                                <AddCircleOutlineIcon sx={{ fontSize: 16, mr: 0.5 }} />
                                + Add New Sub Duty
                              </MenuItem>
                            )}
                          </Select>
                        </Box>

                        {/* Location */}
                        <FormField labelKey="personnel.location" value={form.location || ''} onChange={e => updateField('location', e.target.value)} />
                      </Box>

                      {/* Date of Joining & Active */}
                      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr 1fr' }, gap: 2 }}>
                        <FormField labelKey="personnel.dateOfJoining" type="date" value={form.dateOfJoining || ''} onChange={e => updateField('dateOfJoining', e.target.value)} InputLabelProps={{ shrink: true }} />
                      </Box>
                      <FormControlLabel sx={{ mt: 2 }}
                        control={<Switch checked={form.isActive !== false} onChange={e => updateField('isActive', e.target.checked)} />}
                        label={<Typography variant="body2">Active</Typography>}
                      />
                    </>
                  ) : (
                    <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr' }, gap: 2 }}>
                      {[
                        { label: 'Unit', value: person.unit },
                        { label: 'Badge ID', value: person.badgeId },
                        { label: 'Name', value: person.personName },
                        { label: 'Designation', value: person.designation },
                        { label: 'Section', value: person.section ? `Section ${person.section}` : undefined },
                        { label: 'Duty Type', value: person.dutyType },
                        { label: 'Location', value: person.location },
                        { label: 'Date of Joining', value: person.dateOfJoining },
                        { label: 'Status', value: person.isActive ? 'Active' : 'Inactive' },
                      ].map(item => (
                        <Box key={item.label}>
                          <Typography variant="caption" sx={{ fontWeight: 600, color: 'text.secondary', textTransform: 'uppercase', mb: 0.3, display: 'block' }}>
                            {item.label}
                          </Typography>
                          <Typography variant="body2" fontWeight={500} color="text.primary">
                            {item.value || '—'}
                          </Typography>
                        </Box>
                      ))}
                    </Box>
                  )}
                </CardContent>
              </Card>

              {/* Driver Details Card - shown when unit is MT */}
              {(isDriver || person.unit?.toUpperCase() === 'MT') && (
                <Card variant="outlined" sx={{ borderRadius: 3, borderColor: '#0d9488', bgcolor: '#fffbf0', mb: 3 }}>
                  <CardContent sx={{ p: 3 }}>
                    <Typography sx={{ fontWeight: 600, fontSize: '0.95rem', color: '#92400e', mb: 3 }}>
                      {t('personnel.driverFields')}
                    </Typography>
                    {editing ? (
                      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 2 }}>
                        <FormField labelKey="personnel.vehicleNumber" value={form.vehicleNumber || ''} onChange={e => updateField('vehicleNumber', e.target.value)} />
                        <FormField labelKey="personnel.pdms" value={form.pdms || ''} onChange={e => updateField('pdms', e.target.value)} />
                        <FormField labelKey="personnel.licenceType" value={form.licenceType || ''} onChange={e => updateField('licenceType', e.target.value)} />
                        <FormField labelKey="personnel.deployedFrom" value={form.deployedFrom || ''} onChange={e => updateField('deployedFrom', e.target.value)} />
                      </Box>
                    ) : (
                      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 2 }}>
                        {[
                          { label: 'Vehicle Number', value: person.vehicleNumber },
                          { label: 'PDMS', value: person.pdms },
                          { label: 'Type of Licence', value: person.licenceType },
                          { label: 'Deployed From', value: person.deployedFrom },
                        ].map(item => (
                          <Box key={item.label}>
                            <Typography variant="caption" sx={{ fontWeight: 600, color: 'text.secondary', textTransform: 'uppercase', mb: 0.3, display: 'block' }}>
                              {item.label}
                            </Typography>
                            <Typography variant="body2" fontWeight={500} color="text.primary">
                              {item.value || '—'}
                            </Typography>
                          </Box>
                        ))}
                      </Box>
                    )}
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </Box>

        {/* Contact Tab */}
        <Box role="tabpanel" hidden={activeTab !== 1} id="profile-tabpanel-1" aria-labelledby="profile-tab-1">
          {activeTab === 1 && (
            <Card variant="outlined" sx={{ borderRadius: 3, borderColor: 'divider' }}>
              <CardContent sx={{ p: 3 }}>
                <Typography variant="subtitle1" fontWeight={600} color="text.primary" sx={{ mb: 3 }}>
                  Contact Information
                </Typography>
                {editing ? (
                  <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 2 }}>
                    <FormField labelKey="personnel.phoneNumber" value={form.phoneNumber || ''} onChange={e => updateField('phoneNumber', e.target.value)} />
                    <FormField labelKey="personnel.email" value={form.email || ''} onChange={e => updateField('email', e.target.value)} />
                  </Box>
                ) : (
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    {/* Phone */}
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 2, borderRadius: 2, bgcolor: 'action.hover', border: '1px solid', borderColor: 'divider' }}>
                      <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: '#dbeafe', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <PhoneIcon sx={{ fontSize: 20, color: '#1d4ed8' }} />
                      </Box>
                      <Box sx={{ flex: 1 }}>
                        <Typography variant="caption" sx={{ color: 'text.secondary', textTransform: 'uppercase', fontWeight: 600, display: 'block' }}>
                          Phone
                        </Typography>
                        <Typography variant="body2" fontWeight={500} color="text.primary">
                          {person.phoneNumber || '—'}
                        </Typography>
                      </Box>
                      {person.phoneNumber && (
                        <Button size="small" sx={{ textTransform: 'none', fontSize: '0.78rem' }}>
                          Message
                        </Button>
                      )}
                    </Box>

                    {/* Email */}
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 2, borderRadius: 2, bgcolor: 'action.hover', border: '1px solid', borderColor: 'divider' }}>
                      <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: '#fef3c7', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <EmailIcon sx={{ fontSize: 20, color: '#d97706' }} />
                      </Box>
                      <Box sx={{ flex: 1 }}>
                        <Typography variant="caption" sx={{ color: 'text.secondary', textTransform: 'uppercase', fontWeight: 600, display: 'block' }}>
                          Email
                        </Typography>
                        <Typography variant="body2" fontWeight={500} color="text.primary">
                          {person.email || '—'}
                        </Typography>
                      </Box>
                      {person.email && (
                        <Button size="small" sx={{ textTransform: 'none', fontSize: '0.78rem' }}
                          onClick={() => window.open(`mailto:${person.email}`)}>
                          Send Email
                        </Button>
                      )}
                    </Box>

                    {/* Location */}
                    {person.location && (
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 2, borderRadius: 2, bgcolor: 'action.hover', border: '1px solid', borderColor: 'divider' }}>
                        <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: '#ecfdf5', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                          <LocationOnIcon sx={{ fontSize: 20, color: '#059669' }} />
                        </Box>
                        <Box sx={{ flex: 1 }}>
                          <Typography variant="caption" sx={{ color: 'text.secondary', textTransform: 'uppercase', fontWeight: 600, display: 'block' }}>
                            Location
                          </Typography>
                          <Typography variant="body2" fontWeight={500} color="text.primary">
                            {person.location}
                          </Typography>
                        </Box>
                      </Box>
                    )}
                  </Box>
                )}
              </CardContent>
            </Card>
          )}
        </Box>
      </Box>

      {/* Add New Duty Type Dialog */}
      <Dialog open={addDialog.open} onClose={() => setAddDialog({ ...addDialog, open: false })} maxWidth="xs" fullWidth>
        <DialogTitle sx={{ fontWeight: 600, fontSize: '1rem' }}>
          {addDialog.type === 'parent' ? 'Add New Duty Type' : 'Add New Sub Duty Type'}
        </DialogTitle>
        <DialogContent>
          <TextField
            autoFocus fullWidth size="small" sx={{ mt: 1 }}
            label={addDialog.type === 'parent' ? 'Duty Type Name' : 'Sub Duty Type Name'}
            value={addDialog.name}
            onChange={(e) => setAddDialog({ ...addDialog, name: e.target.value })}
            onKeyDown={(e) => { if (e.key === 'Enter') handleAddDialogSave(); }}
          />
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setAddDialog({ ...addDialog, open: false })} disabled={creatingDuty}>
            Cancel
          </Button>
          <Button onClick={handleAddDialogSave} variant="contained" disabled={creatingDuty || !addDialog.name.trim()}
            sx={{ bgcolor: '#312e81', '&:hover': { bgcolor: '#1e1b4b' } }}>
            {creatingDuty ? <CircularProgress size={16} /> : 'Add'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onClose={() => setDeleteDialogOpen(false)} maxWidth="xs" fullWidth>
        <DialogTitle sx={{ fontWeight: 600, fontSize: '1rem', color: '#dc2626' }}>
          Delete Personnel Record
        </DialogTitle>
        <DialogContent>
          <Typography sx={{ fontSize: '0.9rem', color: '#374151', mb: 2 }}>
            Are you sure you want to permanently delete <strong>{person?.personName}</strong> ({person?.badgeId})?
            This action cannot be undone.
          </Typography>
          <Typography sx={{ fontSize: '0.85rem', color: '#6b7280', mb: 1 }}>
            To confirm, type the code below:
          </Typography>
          <Box sx={{
            display: 'inline-block', px: 2, py: 1, mb: 2,
            bgcolor: '#fef2f2', border: '1px dashed #dc2626', borderRadius: 1,
            fontFamily: 'monospace', fontSize: '1.2rem', fontWeight: 700,
            letterSpacing: '0.2em', color: '#dc2626', userSelect: 'all',
          }}>
            {deleteCode}
          </Box>
          <TextField
            fullWidth size="small"
            placeholder="Enter the code above"
            value={deleteInput}
            onChange={(e) => setDeleteInput(e.target.value.toUpperCase())}
            inputProps={{ maxLength: 6, style: { fontFamily: 'monospace', letterSpacing: '0.15em', fontSize: '1rem' } }}
            sx={{ mt: 1 }}
          />
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setDeleteDialogOpen(false)} disabled={deleting}>
            Cancel
          </Button>
          <Button onClick={handleDelete} variant="contained"
            disabled={deleting || deleteInput !== deleteCode}
            sx={{
              bgcolor: deleteInput === deleteCode ? '#dc2626' : '#e5e7eb',
              color: deleteInput === deleteCode ? '#ffffff' : '#9ca3af',
              '&:hover': { bgcolor: deleteInput === deleteCode ? '#b91c1c' : '#e5e7eb' },
              '&.Mui-disabled': { bgcolor: '#e5e7eb', color: '#9ca3af' },
            }}>
            {deleting ? <CircularProgress size={16} /> : 'Delete'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default PersonnelProfilePage;

package com.policescheduler.report.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LeaveEntry {
    private int serialNumber;
    private String badgeOrName;
    private String type;
    private String details; // dates, duration
}

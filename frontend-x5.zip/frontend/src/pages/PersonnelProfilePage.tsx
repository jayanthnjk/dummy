import React, { useEffect, useState, useMemo, useCallback } from 'react';
import {
  Box, Typography, Card, CardContent, Button,
  CircularProgress, Alert, Chip, Switch, FormControlLabel, MenuItem,
  Select, Dialog, DialogTitle, DialogContent, DialogActions, TextField,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper,
  TablePagination, IconButton, Tooltip,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import EditIcon from '@mui/icons-material/Edit';
import SaveIcon from '@mui/icons-material/Save';
import CancelIcon from '@mui/icons-material/Cancel';
import DeleteIcon from '@mui/icons-material/Delete';
import PhoneIcon from '@mui/icons-material/Phone';
import EmailIcon from '@mui/icons-material/Email';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import HistoryIcon from '@mui/icons-material/History';
import FilterListIcon from '@mui/icons-material/FilterList';
import ClearIcon from '@mui/icons-material/Clear';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import TableChartIcon from '@mui/icons-material/TableChart';
import { useTranslation } from 'react-i18next';
import { useNavigate, useParams } from 'react-router-dom';
import FormField from '@/components/FormField';
import PageHeader from '@/components/common/PageHeader';
import { PersonAvatar } from '@/components/common/PersonAvatar';
import StatusBadge from '@/components/common/StatusBadge';
import { personnelService } from '@/services/personnelService';
import { sectionService, type SectionDto } from '@/services/sectionService';
import { dutyTypeService } from '@/services/dutySectionService';
import api from '@/services/api';
import type { DutyType } from '@/types/dutySections';
import type { PersonnelDto, UpdatePersonnelRequest, DutyHistoryDto, Page } from '@/types';

const DESIGNATIONS = ['DCP', 'ACP', 'RPI', 'RSI', 'ARSI', 'AHC', 'APC'];
const UNITS = ['CAR', 'MT'];
const ADD_NEW_VALUE = '__ADD_NEW__';
const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

const PersonnelProfilePage: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { badgeId } = useParams<{ badgeId: string }>();
  const [person, setPerson] = useState<PersonnelDto | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [sections, setSections] = useState<SectionDto[]>([]);
  const [activeTab, setActiveTab] = useState(0);
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<UpdatePersonnelRequest>({});

  // Duty type state
  const [allDutyTypes, setAllDutyTypes] = useState<DutyType[]>([]);
  const [loadingDutyTypes, setLoadingDutyTypes] = useState(false);
  const [selectedParentId, setSelectedParentId] = useState<number | ''>('');
  const [selectedSubId, setSelectedSubId] = useState<number | ''>('');

  // Add new duty type dialog
  const [addDialog, setAddDialog] = useState<{ open: boolean; type: 'parent' | 'sub'; name: string }>({
    open: false, type: 'parent', name: '',
  });
  const [creatingDuty, setCreatingDuty] = useState(false);

  // Delete state
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [deleteCode, setDeleteCode] = useState('');
  const [deleteInput, setDeleteInput] = useState('');

  // Duty History state
  const [dutyHistory, setDutyHistory] = useState<Page<DutyHistoryDto> | null>(null);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [historyPage, setHistoryPage] = useState(0);
  const [historyRowsPerPage, setHistoryRowsPerPage] = useState(10);
  const [historyStartDate, setHistoryStartDate] = useState('');
  const [historyEndDate, setHistoryEndDate] = useState('');
  const [historyFiltersApplied, setHistoryFiltersApplied] = useState(false);
  const [downloading, setDownloading] = useState<'pdf' | 'excel' | null>(null);

  const generateDeleteCode = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = '';
    for (let i = 0; i < 6; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  };

  // Fetch duty history
  const fetchDutyHistory = useCallback(async () => {
    if (!person?.id) return;
    setHistoryLoading(true);
    try {
      const data = await personnelService.getDutyHistory(
        person.id,
        historyPage,
        historyRowsPerPage,
        historyFiltersApplied && historyStartDate ? historyStartDate : undefined,
        historyFiltersApplied && historyEndDate ? historyEndDate : undefined
      );
      setDutyHistory(data);
    } catch {
      // Silent error - empty state will be shown
      setDutyHistory(null);
    } finally {
      setHistoryLoading(false);
    }
  }, [person?.id, historyPage, historyRowsPerPage, historyStartDate, historyEndDate, historyFiltersApplied]);

  // Download duty history report (PDF or Excel)
  const handleDownloadReport = useCallback(async (format: 'pdf' | 'excel') => {
    if (!person?.id) return;
    setDownloading(format);
    try {
      // Build URL with date filters if applied
      let url = `/api/duty-history/person/${person.id}/report/${format}`;
      const params = new URLSearchParams();
      if (historyFiltersApplied && historyStartDate) {
        params.append('startDate', historyStartDate);
      }
      if (historyFiltersApplied && historyEndDate) {
        params.append('endDate', historyEndDate);
      }
      if (params.toString()) {
        url += `?${params.toString()}`;
      }

      const response = await api.get(url, { responseType: 'blob' });
      
      // Create download link
      const blob = new Blob([response.data], { 
        type: format === 'pdf' ? 'application/pdf' : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      });
      const downloadUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      
      // Generate filename
      const dateRange = historyFiltersApplied && historyStartDate && historyEndDate 
        ? `-${historyStartDate}-to-${historyEndDate}` 
        : '';
      link.download = `duty-history-${person.badgeId}${dateRange}.${format === 'pdf' ? 'pdf' : 'xlsx'}`;
      
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(downloadUrl);
    } catch {
      // Silent error - user can try again
    } finally {
      setDownloading(null);
    }
  }, [person?.id, person?.badgeId, historyFiltersApplied, historyStartDate, historyEndDate]);

  // Fetch duty history when tab changes to history tab or pagination changes
  useEffect(() => {
    if (activeTab === 2 && person?.id) {
      fetchDutyHistory();
    }
  }, [activeTab, fetchDutyHistory, person?.id]);

  useEffect(() => {
    if (!badgeId) return;
    setLoading(true);
    Promise.all([
      personnelService.getByBadgeId(badgeId),
      sectionService.list(),
    ])
      .then(([data, secs]) => { setPerson(data); setForm(data); setSections(secs); })
      .catch(() => setError('Personnel not found'))
      .finally(() => setLoading(false));
  }, [badgeId]);

  // Fetch duty types when section changes during editing
  useEffect(() => {
    if (form.section && editing) {
      setLoadingDutyTypes(true);
      dutyTypeService.listBySection(form.section)
        .then((data) => {
          setAllDutyTypes(data);
          // Try to match existing dutyType to set parent/sub selections
          if (form.dutyType) {
            const matchSub = data.find(dt => dt.name === form.dutyType && dt.parentId);
            if (matchSub) {
              setSelectedSubId(matchSub.id);
              setSelectedParentId(matchSub.parentId!);
            } else {
              const matchParent = data.find(dt => dt.name === form.dutyType && !dt.parentId);
              if (matchParent) {
                setSelectedParentId(matchParent.id);
                setSelectedSubId('');
              }
            }
          }
          setLoadingDutyTypes(false);
        })
        .catch(() => setLoadingDutyTypes(false));
    }
  }, [form.section, editing]);

  // Parent duty types
  const parentDutyTypes = useMemo(() => {
    return allDutyTypes
      .filter((dt) => dt.level === 'PARENT' || (!dt.parentId && !dt.level))
      .sort((a, b) => a.sortOrder - b.sortOrder);
  }, [allDutyTypes]);

  // Sub duty types for selected parent
  const subDutyTypes = useMemo(() => {
    if (!selectedParentId) return [];
    return allDutyTypes
      .filter((dt) => dt.parentId === selectedParentId)
      .sort((a, b) => a.sortOrder - b.sortOrder);
  }, [allDutyTypes, selectedParentId]);

  const isDriver = form.unit?.toUpperCase() === 'MT';

  // Update form.dutyType based on selection
  useEffect(() => {
    if (!editing) return;
    if (isDriver) {
      // MT unit: duty_type = parent name, duty_location = sub-duty name
      if (selectedParentId) {
        const parent = parentDutyTypes.find(dt => dt.id === selectedParentId);
        if (parent) updateField('dutyType', parent.name);
      }
      if (selectedSubId) {
        const sub = allDutyTypes.find(dt => dt.id === selectedSubId);
        if (sub) updateField('dutyLocation', sub.name);
      } else {
        updateField('dutyLocation', '');
      }
    } else {
      // CAR unit: duty_type = sub-duty name (or parent if no sub)
      if (selectedSubId) {
        const sub = allDutyTypes.find(dt => dt.id === selectedSubId);
        if (sub) updateField('dutyType', sub.name);
      } else if (selectedParentId && subDutyTypes.length === 0) {
        const parent = parentDutyTypes.find(dt => dt.id === selectedParentId);
        if (parent) updateField('dutyType', parent.name);
      }
    }
  }, [selectedParentId, selectedSubId, subDutyTypes.length, editing, isDriver]);

  const handleSave = async () => {
    if (!badgeId) return;
    setSaving(true);
    try {
      const updated = await personnelService.update(badgeId, form);
      setPerson(updated);
      setEditing(false);
    } catch { setError(t('errors.serverError')); }
    finally { setSaving(false); }
  };

  const handleDelete = async () => {
    if (!badgeId) return;
    setDeleting(true);
    try {
      await personnelService.delete(badgeId);
      navigate('/personnel');
    } catch { setError('Failed to delete personnel record'); }
    finally { setDeleting(false); setDeleteDialogOpen(false); }
  };

  const updateField = (field: keyof UpdatePersonnelRequest, value: string | boolean) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const handleParentChange = (value: string) => {
    if (value === ADD_NEW_VALUE) {
      setAddDialog({ open: true, type: 'parent', name: '' });
      return;
    }
    setSelectedParentId(value ? Number(value) : '');
    setSelectedSubId('');
  };

  const handleSubChange = (value: string) => {
    if (value === ADD_NEW_VALUE) {
      setAddDialog({ open: true, type: 'sub', name: '' });
      return;
    }
    setSelectedSubId(value ? Number(value) : '');
  };

  const handleAddDialogSave = async () => {
    if (!addDialog.name.trim()) return;
    setCreatingDuty(true);
    try {
      if (addDialog.type === 'parent') {
        const created = await dutyTypeService.create({
          name: addDialog.name.trim(), section: form.section!,
          sortOrder: parentDutyTypes.length + 1, level: 'PARENT',
        });
        setAllDutyTypes(prev => [...prev, created]);
        setSelectedParentId(created.id);
        setSelectedSubId('');
      } else {
        const created = await dutyTypeService.create({
          name: addDialog.name.trim(), section: form.section!,
          sortOrder: subDutyTypes.length + 1, parentId: selectedParentId as number, level: 'SUB',
        });
        setAllDutyTypes(prev => [...prev, created]);
        setSelectedSubId(created.id);
      }
      setAddDialog({ open: false, type: 'parent', name: '' });
    } catch {
      setError('Failed to create duty type');
    } finally {
      setCreatingDuty(false);
    }
  };

  const labelSx = { fontSize: '0.75rem', fontWeight: 600, color: '#4b5563', mb: 0.5 };
  const selectSx = {
    borderRadius: 1.5, fontSize: '0.85rem',
    '& fieldset': { borderColor: '#e5e7eb' },
    '&:hover fieldset': { borderColor: '#0d9488' },
    '&.Mui-focused fieldset': { borderColor: '#312e81', borderWidth: 1.5 },
  };

  if (loading) return <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}><CircularProgress /></Box>;
  if (error || !person) return (
    <Box sx={{ p: 3 }}>
      <Alert severity="error">{error || 'Not found'}</Alert>
      <Button onClick={() => navigate('/personnel')} sx={{ mt: 2 }}>Back to Personnel</Button>
    </Box>
  );

  const personName = person.personName || 'Unknown';

  return (
    <Box>
      {/* PageHeader with breadcrumbs and back action */}
      <PageHeader
        title={personName}
        breadcrumbs={[
          { label: 'Home', path: '/' },
          { label: 'Personnel', path: '/personnel' },
          { label: personName },
        ]}
        actions={[
          {
            label: 'Back',
            variant: 'ghost',
            icon: <ArrowBackIcon />,
            onClick: () => navigate('/personnel'),
          },
          ...(editing
            ? []
            : [
                {
                  label: 'Edit',
                  variant: 'secondary' as const,
                  icon: <EditIcon />,
                  onClick: () => setEditing(true),
                },
                {
                  label: 'Delete',
                  variant: 'destructive' as const,
                  icon: <DeleteIcon />,
                  onClick: () => {
                    setDeleteCode(generateDeleteCode());
                    setDeleteInput('');
                    setDeleteDialogOpen(true);
                  },
                },
              ]
          ),
        ]}
      />

      <Box sx={{ p: 3, maxWidth: 1000, mx: 'auto' }}>
        {/* Profile Hero Section */}
        <Card
          variant="outlined"
          sx={{
            borderRadius: 3,
            borderColor: 'divider',
            mb: 3,
            overflow: 'visible',
          }}
        >
          <CardContent sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', gap: 3, alignItems: 'center', flexWrap: { xs: 'wrap', sm: 'nowrap' } }}>
              <PersonAvatar
                name={personName}
                size="large"
                badgeId={person.badgeId}
                designation={person.designation}
              />

              <Box sx={{ flex: 1, minWidth: 0 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 0.5, flexWrap: 'wrap' }}>
                  <Typography variant="h5" fontWeight={700} color="text.primary">
                    {personName}
                  </Typography>
                  {person.designation && (
                    <Chip
                      label={person.designation}
                      size="small"
                      sx={{ bgcolor: '#ede9fe', color: '#6d28d9', fontWeight: 600, fontSize: '0.75rem' }}
                    />
                  )}
                  <StatusBadge
                    status={person.isActive ? 'Active' : 'Cancelled'}
                    size="small"
                    showDot
                  />
                </Box>

                <Box sx={{ display: 'flex', gap: 3, flexWrap: 'wrap', color: 'text.secondary', mt: 1 }}>
                  <Typography variant="body2" sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    Badge: <strong>{person.badgeId}</strong>
                  </Typography>
                  {person.unit && (
                    <Typography variant="body2" sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                      Unit: <strong>{person.unit}</strong>
                    </Typography>
                  )}
                  {person.section && (
                    <Typography variant="body2" sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                      <LocationOnIcon sx={{ fontSize: 16 }} /> Section {person.section}
                    </Typography>
                  )}
                </Box>
              </Box>

              {editing && (
                <Box sx={{ display: 'flex', gap: 1, flexShrink: 0 }}>
                  <Button
                    startIcon={<CancelIcon sx={{ fontSize: 16 }} />}
                    onClick={() => { setEditing(false); setForm(person); setSelectedParentId(''); setSelectedSubId(''); }}
                    size="small"
                    sx={{ textTransform: 'none', color: 'text.secondary' }}
                  >
                    Cancel
                  </Button>
                  <Button
                    variant="contained"
                    startIcon={saving ? <CircularProgress size={14} /> : <SaveIcon sx={{ fontSize: 16 }} />}
                    onClick={handleSave}
                    disabled={saving}
                    size="small"
                    sx={{ textTransform: 'none' }}
                  >
                    Save
                  </Button>
                </Box>
              )}
            </Box>
          </CardContent>
        </Card>

        {/* Toggle Switch Tabs */}
        <Box sx={{ mb: 3, display: 'inline-flex', bgcolor: '#f1f5f9', borderRadius: '10px', p: '4px', gap: '4px' }}>
          {[
            { label: 'Details', icon: null },
            { label: 'Contact', icon: null },
            { label: 'Duty History', icon: <HistoryIcon sx={{ fontSize: 16, mr: 0.5 }} /> },
          ].map((tab, idx) => (
            <Box
              key={tab.label}
              onClick={() => setActiveTab(idx)}
              role="tab"
              id={`profile-tab-${idx}`}
              aria-controls={`profile-tabpanel-${idx}`}
              aria-selected={activeTab === idx}
              tabIndex={0}
              onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') setActiveTab(idx); }}
              sx={{
                px: 2.5,
                py: 1,
                borderRadius: '8px',
                cursor: 'pointer',
                fontWeight: 600,
                fontSize: '0.82rem',
                transition: 'all 0.2s ease',
                userSelect: 'none',
                display: 'flex',
                alignItems: 'center',
                ...(activeTab === idx
                  ? { bgcolor: '#fff', color: '#312e81', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }
                  : { bgcolor: 'transparent', color: '#64748b', '&:hover': { color: '#312e81' } }
                ),
              }}
            >
              {tab.icon}
              {tab.label}
            </Box>
          ))}
        </Box>

        {/* Details Tab */}
        <Box role="tabpanel" hidden={activeTab !== 0} id="profile-tabpanel-0" aria-labelledby="profile-tab-0">
          {activeTab === 0 && (
            <>
              <Card variant="outlined" sx={{ borderRadius: 3, borderColor: 'divider', mb: 3 }}>
                <CardContent sx={{ p: 3 }}>
                  <Typography variant="subtitle1" fontWeight={600} color="text.primary" sx={{ mb: 3 }}>
                    Basic Information
                  </Typography>
                  {editing ? (
                    <>
                      {/* Row 1: Unit, Badge ID, Person Name, Designation */}
                      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr 1fr' }, gap: 2, mb: 3 }}>
                        <Box>
                          <Typography sx={labelSx}>Unit</Typography>
                          <Select displayEmpty size="small" fullWidth
                            value={form.unit || 'CAR'}
                            onChange={(e) => {
                              updateField('unit', e.target.value);
                              updateField('section', '');
                              setSelectedParentId('');
                              setSelectedSubId('');
                              setAllDutyTypes([]);
                            }}
                            sx={selectSx}
                          >
                            {UNITS.map(u => <MenuItem key={u} value={u}>{u}</MenuItem>)}
                          </Select>
                        </Box>
                        <FormField labelKey="personnel.badgeId" value={form.badgeId || ''} onChange={e => updateField('badgeId', e.target.value)} />
                        <FormField labelKey="personnel.personName" value={form.personName || ''} onChange={e => updateField('personName', e.target.value)} />
                        <FormField labelKey="personnel.designation" select value={form.designation || ''} onChange={e => updateField('designation', e.target.value)}>
                          <MenuItem value="">—</MenuItem>
                          {DESIGNATIONS.map(d => <MenuItem key={d} value={d}>{d}</MenuItem>)}
                        </FormField>
                      </Box>

                      {/* Row 2: Section & Duty Details */}
                      <Typography sx={{ fontWeight: 600, fontSize: '0.88rem', color: '#374151', mb: 1.5 }}>
                        Section & Duty Details
                      </Typography>
                      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr 1fr' }, gap: 2, mb: 2 }}>
                        {/* Section */}
                        <Box>
                          <Typography sx={labelSx}>Section</Typography>
                          <Select displayEmpty size="small" fullWidth
                            value={form.section || ''}
                            onChange={(e) => {
                              updateField('section', e.target.value);
                              setSelectedParentId('');
                              setSelectedSubId('');
                              setAllDutyTypes([]);
                            }}
                            sx={selectSx}
                          >
                            <MenuItem value="">— Select Section —</MenuItem>
                            {sections.map(s => <MenuItem key={s.code} value={s.code}>{s.name}</MenuItem>)}
                          </Select>
                        </Box>

                        {/* Duty Type */}
                        <Box>
                          <Typography sx={labelSx}>Duty Type</Typography>
                          <Select displayEmpty size="small" fullWidth
                            value={selectedParentId === '' ? '' : String(selectedParentId)}
                            onChange={(e) => handleParentChange(e.target.value)}
                            disabled={!form.section || loadingDutyTypes}
                            sx={selectSx}
                            MenuProps={{
                              disablePortal: false,
                              anchorOrigin: { vertical: 'bottom', horizontal: 'left' },
                              transformOrigin: { vertical: 'top', horizontal: 'left' },
                              slotProps: { paper: { sx: { maxHeight: 300, mt: 0.5 } } },
                              marginThreshold: 0,
                            }}
                          >
                            <MenuItem value="">— Select Duty Type —</MenuItem>
                            {parentDutyTypes.map(dt => (
                              <MenuItem key={dt.id} value={String(dt.id)}>{dt.name}</MenuItem>
                            ))}
                            <MenuItem value={ADD_NEW_VALUE} sx={{ color: '#312e81', fontWeight: 600, borderTop: '1px solid #e5e7eb', mt: 0.5 }}>
                              <AddCircleOutlineIcon sx={{ fontSize: 16, mr: 0.5 }} />
                              + Add New Duty Type
                            </MenuItem>
                          </Select>
                        </Box>

                        {/* Sub Duty Type */}
                        <Box>
                          <Typography sx={labelSx}>Sub Duty Type</Typography>
                          <Select displayEmpty size="small" fullWidth
                            value={selectedSubId === '' ? '' : String(selectedSubId)}
                            onChange={(e) => handleSubChange(e.target.value)}
                            disabled={subDutyTypes.length === 0}
                            sx={selectSx}
                            MenuProps={{
                              disablePortal: false,
                              anchorOrigin: { vertical: 'bottom', horizontal: 'left' },
                              transformOrigin: { vertical: 'top', horizontal: 'left' },
                              slotProps: { paper: { sx: { maxHeight: 300, mt: 0.5 } } },
                              marginThreshold: 0,
                            }}
                          >
                            <MenuItem value="">— {subDutyTypes.length > 0 ? 'Select Sub Duty' : 'No sub duties'} —</MenuItem>
                            {subDutyTypes.map(dt => (
                              <MenuItem key={dt.id} value={String(dt.id)}>{dt.name}</MenuItem>
                            ))}
                            {selectedParentId && (
                              <MenuItem value={ADD_NEW_VALUE} sx={{ color: '#312e81', fontWeight: 600, borderTop: '1px solid #e5e7eb', mt: 0.5 }}>
                                <AddCircleOutlineIcon sx={{ fontSize: 16, mr: 0.5 }} />
                                + Add New Sub Duty
                              </MenuItem>
                            )}
                          </Select>
                        </Box>

                        {/* Location */}
                        <FormField labelKey="personnel.location" value={form.location || ''} onChange={e => updateField('location', e.target.value)} />
                      </Box>

                      {/* Date of Joining & Active */}
                      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr 1fr' }, gap: 2 }}>
                        <FormField labelKey="personnel.dateOfJoining" type="date" value={form.dateOfJoining || ''} onChange={e => updateField('dateOfJoining', e.target.value)} InputLabelProps={{ shrink: true }} />
                      </Box>
                      <FormControlLabel sx={{ mt: 2 }}
                        control={<Switch checked={form.isActive !== false} onChange={e => updateField('isActive', e.target.checked)} />}
                        label={<Typography variant="body2">Active</Typography>}
                      />
                    </>
                  ) : (
                    <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr' }, gap: 2 }}>
                      {[
                        { label: 'Unit', value: person.unit },
                        { label: 'Badge ID', value: person.badgeId },
                        { label: 'Name', value: person.personName },
                        { label: 'Designation', value: person.designation },
                        { label: 'Section', value: person.section ? `Section ${person.section}` : undefined },
                        { label: 'Duty Type', value: person.dutyType },
                        { label: 'Location', value: person.location },
                        { label: 'Date of Joining', value: person.dateOfJoining },
                        { label: 'Status', value: person.isActive ? 'Active' : 'Inactive' },
                      ].map(item => (
                        <Box key={item.label}>
                          <Typography variant="caption" sx={{ fontWeight: 600, color: 'text.secondary', textTransform: 'uppercase', mb: 0.3, display: 'block' }}>
                            {item.label}
                          </Typography>
                          <Typography variant="body2" fontWeight={500} color="text.primary">
                            {item.value || '—'}
                          </Typography>
                        </Box>
                      ))}
                    </Box>
                  )}
                </CardContent>
              </Card>

              {/* Personal Details Card */}
              <Card variant="outlined" sx={{ borderRadius: 3, borderColor: 'divider', mb: 3 }}>
                <CardContent sx={{ p: 3 }}>
                  <Typography variant="subtitle1" fontWeight={600} color="text.primary" sx={{ mb: 3 }}>
                    Personal Details
                  </Typography>
                  {editing ? (
                    <>
                      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr' }, gap: 2, mb: 2 }}>
                        <FormField labelKey="personnel.dateOfBirth" type="date" value={form.dateOfBirth || ''} onChange={e => updateField('dateOfBirth', e.target.value)} InputLabelProps={{ shrink: true }} />
                        <Box>
                          <Typography sx={labelSx}>Blood Group</Typography>
                          <Select displayEmpty size="small" fullWidth
                            value={form.bloodGroup || ''}
                            onChange={(e) => updateField('bloodGroup', e.target.value)}
                            sx={selectSx}
                          >
                            <MenuItem value="">— Select Blood Group —</MenuItem>
                            {BLOOD_GROUPS.map(bg => <MenuItem key={bg} value={bg}>{bg}</MenuItem>)}
                          </Select>
                        </Box>
                        <FormField labelKey="personnel.qualification" value={form.qualification || ''} onChange={e => updateField('qualification', e.target.value)} />
                      </Box>
                      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 2, mb: 2 }}>
                        <Box>
                          <Typography sx={labelSx}>Permanent Address</Typography>
                          <TextField
                            fullWidth size="small" multiline rows={2}
                            value={form.permanentAddress || ''}
                            onChange={e => updateField('permanentAddress', e.target.value)}
                            placeholder="Enter permanent address"
                            sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1.5, fontSize: '0.85rem' } }}
                          />
                        </Box>
                        <Box>
                          <Typography sx={labelSx}>Present Address</Typography>
                          <TextField
                            fullWidth size="small" multiline rows={2}
                            value={form.presentAddress || ''}
                            onChange={e => updateField('presentAddress', e.target.value)}
                            placeholder="Enter present address"
                            sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1.5, fontSize: '0.85rem' } }}
                          />
                        </Box>
                      </Box>
                      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 2 }}>
                        <FormField labelKey="personnel.nativePoliceStation" value={form.nativePoliceStation || ''} onChange={e => updateField('nativePoliceStation', e.target.value)} />
                      </Box>
                    </>
                  ) : (
                    <>
                      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr' }, gap: 2, mb: 2 }}>
                        {[
                          { label: 'Date of Birth', value: person.dateOfBirth },
                          { label: 'Blood Group', value: person.bloodGroup },
                          { label: 'Qualification', value: person.qualification },
                        ].map(item => (
                          <Box key={item.label}>
                            <Typography variant="caption" sx={{ fontWeight: 600, color: 'text.secondary', textTransform: 'uppercase', mb: 0.3, display: 'block' }}>
                              {item.label}
                            </Typography>
                            <Typography variant="body2" fontWeight={500} color="text.primary">
                              {item.value || '—'}
                            </Typography>
                          </Box>
                        ))}
                      </Box>
                      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 2, mb: 2 }}>
                        <Box>
                          <Typography variant="caption" sx={{ fontWeight: 600, color: 'text.secondary', textTransform: 'uppercase', mb: 0.3, display: 'block' }}>
                            Permanent Address
                          </Typography>
                          <Typography variant="body2" fontWeight={500} color="text.primary" sx={{ whiteSpace: 'pre-wrap' }}>
                            {person.permanentAddress || '—'}
                          </Typography>
                        </Box>
                        <Box>
                          <Typography variant="caption" sx={{ fontWeight: 600, color: 'text.secondary', textTransform: 'uppercase', mb: 0.3, display: 'block' }}>
                            Present Address
                          </Typography>
                          <Typography variant="body2" fontWeight={500} color="text.primary" sx={{ whiteSpace: 'pre-wrap' }}>
                            {person.presentAddress || '—'}
                          </Typography>
                        </Box>
                      </Box>
                      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 2 }}>
                        <Box>
                          <Typography variant="caption" sx={{ fontWeight: 600, color: 'text.secondary', textTransform: 'uppercase', mb: 0.3, display: 'block' }}>
                            Native Police Station
                          </Typography>
                          <Typography variant="body2" fontWeight={500} color="text.primary">
                            {person.nativePoliceStation || '—'}
                          </Typography>
                        </Box>
                      </Box>
                    </>
                  )}
                </CardContent>
              </Card>

              {/* Driver Details Card - shown when unit is MT */}
              {(isDriver || person.unit?.toUpperCase() === 'MT') && (
                <Card variant="outlined" sx={{ borderRadius: 3, borderColor: '#0d9488', bgcolor: '#fffbf0', mb: 3 }}>
                  <CardContent sx={{ p: 3 }}>
                    <Typography sx={{ fontWeight: 600, fontSize: '0.95rem', color: '#92400e', mb: 3 }}>
                      {t('personnel.driverFields')}
                    </Typography>
                    {editing ? (
                      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 2 }}>
                        <FormField labelKey="personnel.vehicleNumber" value={form.vehicleNumber || ''} onChange={e => updateField('vehicleNumber', e.target.value)} />
                        <FormField labelKey="personnel.pdms" value={form.pdms || ''} onChange={e => updateField('pdms', e.target.value)} />
                        <FormField labelKey="personnel.licenceType" value={form.licenceType || ''} onChange={e => updateField('licenceType', e.target.value)} />
                        <FormField labelKey="personnel.deployedFrom" value={form.deployedFrom || ''} onChange={e => updateField('deployedFrom', e.target.value)} />
                      </Box>
                    ) : (
                      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 2 }}>
                        {[
                          { label: 'Vehicle Number', value: person.vehicleNumber },
                          { label: 'PDMS', value: person.pdms },
                          { label: 'Type of Licence', value: person.licenceType },
                          { label: 'Deployed From', value: person.deployedFrom },
                        ].map(item => (
                          <Box key={item.label}>
                            <Typography variant="caption" sx={{ fontWeight: 600, color: 'text.secondary', textTransform: 'uppercase', mb: 0.3, display: 'block' }}>
                              {item.label}
                            </Typography>
                            <Typography variant="body2" fontWeight={500} color="text.primary">
                              {item.value || '—'}
                            </Typography>
                          </Box>
                        ))}
                      </Box>
                    )}
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </Box>

        {/* Contact Tab */}
        <Box role="tabpanel" hidden={activeTab !== 1} id="profile-tabpanel-1" aria-labelledby="profile-tab-1">
          {activeTab === 1 && (
            <Card variant="outlined" sx={{ borderRadius: 3, borderColor: 'divider' }}>
              <CardContent sx={{ p: 3 }}>
                <Typography variant="subtitle1" fontWeight={600} color="text.primary" sx={{ mb: 3 }}>
                  Contact Information
                </Typography>
                {editing ? (
                  <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 2 }}>
                    <FormField labelKey="personnel.phoneNumber" value={form.phoneNumber || ''} onChange={e => updateField('phoneNumber', e.target.value)} />
                    <FormField labelKey="personnel.email" value={form.email || ''} onChange={e => updateField('email', e.target.value)} />
                  </Box>
                ) : (
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    {/* Phone */}
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 2, borderRadius: 2, bgcolor: 'action.hover', border: '1px solid', borderColor: 'divider' }}>
                      <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: '#dbeafe', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <PhoneIcon sx={{ fontSize: 20, color: '#1d4ed8' }} />
                      </Box>
                      <Box sx={{ flex: 1 }}>
                        <Typography variant="caption" sx={{ color: 'text.secondary', textTransform: 'uppercase', fontWeight: 600, display: 'block' }}>
                          Phone
                        </Typography>
                        <Typography variant="body2" fontWeight={500} color="text.primary">
                          {person.phoneNumber || '—'}
                        </Typography>
                      </Box>
                      {person.phoneNumber && (
                        <Button size="small" sx={{ textTransform: 'none', fontSize: '0.78rem' }}>
                          Message
                        </Button>
                      )}
                    </Box>

                    {/* Email */}
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 2, borderRadius: 2, bgcolor: 'action.hover', border: '1px solid', borderColor: 'divider' }}>
                      <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: '#fef3c7', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <EmailIcon sx={{ fontSize: 20, color: '#d97706' }} />
                      </Box>
                      <Box sx={{ flex: 1 }}>
                        <Typography variant="caption" sx={{ color: 'text.secondary', textTransform: 'uppercase', fontWeight: 600, display: 'block' }}>
                          Email
                        </Typography>
                        <Typography variant="body2" fontWeight={500} color="text.primary">
                          {person.email || '—'}
                        </Typography>
                      </Box>
                      {person.email && (
                        <Button size="small" sx={{ textTransform: 'none', fontSize: '0.78rem' }}
                          onClick={() => window.open(`mailto:${person.email}`)}>
                          Send Email
                        </Button>
                      )}
                    </Box>

                    {/* Location */}
                    {person.location && (
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 2, borderRadius: 2, bgcolor: 'action.hover', border: '1px solid', borderColor: 'divider' }}>
                        <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: '#ecfdf5', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                          <LocationOnIcon sx={{ fontSize: 20, color: '#059669' }} />
                        </Box>
                        <Box sx={{ flex: 1 }}>
                          <Typography variant="caption" sx={{ color: 'text.secondary', textTransform: 'uppercase', fontWeight: 600, display: 'block' }}>
                            Location
                          </Typography>
                          <Typography variant="body2" fontWeight={500} color="text.primary">
                            {person.location}
                          </Typography>
                        </Box>
                      </Box>
                    )}
                  </Box>
                )}
              </CardContent>
            </Card>
          )}
        </Box>

        {/* Duty History Tab */}
        <Box role="tabpanel" hidden={activeTab !== 2} id="profile-tabpanel-2" aria-labelledby="profile-tab-2">
          {activeTab === 2 && (
            <Card variant="outlined" sx={{ borderRadius: 3, borderColor: 'divider' }}>
              <CardContent sx={{ p: 3 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3, flexWrap: 'wrap', gap: 2 }}>
                  <Typography variant="subtitle1" fontWeight={600} color="text.primary" sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <HistoryIcon sx={{ fontSize: 20, color: '#6366f1' }} />
                    Duty History
                  </Typography>

                  {/* Date Filters */}
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, flexWrap: 'wrap' }}>
                    <TextField
                      type="date"
                      size="small"
                      label="Start Date"
                      value={historyStartDate}
                      onChange={(e) => setHistoryStartDate(e.target.value)}
                      InputLabelProps={{ shrink: true }}
                      sx={{ 
                        width: 150,
                        '& .MuiOutlinedInput-root': { borderRadius: 1.5, fontSize: '0.85rem' }
                      }}
                    />
                    <TextField
                      type="date"
                      size="small"
                      label="End Date"
                      value={historyEndDate}
                      onChange={(e) => setHistoryEndDate(e.target.value)}
                      InputLabelProps={{ shrink: true }}
                      sx={{ 
                        width: 150,
                        '& .MuiOutlinedInput-root': { borderRadius: 1.5, fontSize: '0.85rem' }
                      }}
                    />
                    <Tooltip title="Apply Filters">
                      <IconButton
                        size="small"
                        onClick={() => {
                          setHistoryFiltersApplied(true);
                          setHistoryPage(0);
                        }}
                        disabled={!historyStartDate && !historyEndDate}
                        sx={{
                          bgcolor: '#312e81',
                          color: '#fff',
                          '&:hover': { bgcolor: '#1e1b4b' },
                          '&.Mui-disabled': { bgcolor: '#e5e7eb', color: '#9ca3af' },
                        }}
                      >
                        <FilterListIcon sx={{ fontSize: 18 }} />
                      </IconButton>
                    </Tooltip>
                    {historyFiltersApplied && (
                      <Tooltip title="Clear Filters">
                        <IconButton
                          size="small"
                          onClick={() => {
                            setHistoryStartDate('');
                            setHistoryEndDate('');
                            setHistoryFiltersApplied(false);
                            setHistoryPage(0);
                          }}
                          sx={{
                            bgcolor: '#fee2e2',
                            color: '#dc2626',
                            '&:hover': { bgcolor: '#fecaca' },
                          }}
                        >
                          <ClearIcon sx={{ fontSize: 18 }} />
                        </IconButton>
                      </Tooltip>
                    )}

                    {/* Download Buttons */}
                    <Box sx={{ borderLeft: '1px solid #e5e7eb', pl: 1.5, ml: 0.5, display: 'flex', gap: 0.5 }}>
                      <Tooltip title={historyFiltersApplied ? `Download PDF (${historyStartDate} to ${historyEndDate})` : 'Download PDF (All Records)'}>
                        <IconButton
                          size="small"
                          onClick={() => handleDownloadReport('pdf')}
                          disabled={downloading !== null}
                          sx={{
                            bgcolor: '#dc2626',
                            color: '#fff',
                            '&:hover': { bgcolor: '#b91c1c' },
                            '&.Mui-disabled': { bgcolor: '#e5e7eb', color: '#9ca3af' },
                          }}
                        >
                          {downloading === 'pdf' ? <CircularProgress size={16} sx={{ color: '#fff' }} /> : <PictureAsPdfIcon sx={{ fontSize: 18 }} />}
                        </IconButton>
                      </Tooltip>
                      <Tooltip title={historyFiltersApplied ? `Download Excel (${historyStartDate} to ${historyEndDate})` : 'Download Excel (All Records)'}>
                        <IconButton
                          size="small"
                          onClick={() => handleDownloadReport('excel')}
                          disabled={downloading !== null}
                          sx={{
                            bgcolor: '#16a34a',
                            color: '#fff',
                            '&:hover': { bgcolor: '#15803d' },
                            '&.Mui-disabled': { bgcolor: '#e5e7eb', color: '#9ca3af' },
                          }}
                        >
                          {downloading === 'excel' ? <CircularProgress size={16} sx={{ color: '#fff' }} /> : <TableChartIcon sx={{ fontSize: 18 }} />}
                        </IconButton>
                      </Tooltip>
                    </Box>
                  </Box>
                </Box>

                {historyLoading ? (
                  <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
                    <CircularProgress size={32} />
                  </Box>
                ) : dutyHistory && dutyHistory.content.length > 0 ? (
                  <>
                    <TableContainer component={Paper} variant="outlined" sx={{ borderRadius: 2, mb: 2 }}>
                      <Table size="small">
                        <TableHead>
                          <TableRow sx={{ bgcolor: '#f8fafc' }}>
                            <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem', color: '#475569', py: 1.5 }}>Date</TableCell>
                            <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem', color: '#475569', py: 1.5 }}>Section</TableCell>
                            <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem', color: '#475569', py: 1.5 }}>Duty Type</TableCell>
                            <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem', color: '#475569', py: 1.5 }}>Duty Location</TableCell>
                            <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem', color: '#475569', py: 1.5 }}>Shift</TableCell>
                            <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem', color: '#475569', py: 1.5 }}>Status</TableCell>
                            <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem', color: '#475569', py: 1.5 }}>Adhoc Duty</TableCell>
                            <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem', color: '#475569', py: 1.5 }}>Leave</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {dutyHistory.content.map((record) => (
                            <TableRow 
                              key={record.id} 
                              hover
                              sx={{ 
                                '&:last-child td': { border: 0 },
                                bgcolor: record.leaveType ? '#fef2f2' : record.adhocDuty ? '#f0fdf4' : 'inherit',
                              }}
                            >
                              <TableCell sx={{ fontSize: '0.82rem', fontWeight: 500, py: 1.2 }}>
                                {new Date(record.recordDate).toLocaleDateString('en-IN', { 
                                  day: '2-digit', 
                                  month: 'short', 
                                  year: 'numeric' 
                                })}
                              </TableCell>
                              <TableCell sx={{ fontSize: '0.82rem', py: 1.2 }}>
                                {record.section ? (
                                  <Chip 
                                    label={`Section ${record.section}`} 
                                    size="small" 
                                    sx={{ 
                                      bgcolor: '#ede9fe', 
                                      color: '#6d28d9', 
                                      fontWeight: 600, 
                                      fontSize: '0.7rem',
                                      height: 22,
                                    }} 
                                  />
                                ) : '—'}
                              </TableCell>
                              <TableCell sx={{ fontSize: '0.82rem', py: 1.2 }}>{record.dutyType || '—'}</TableCell>
                              <TableCell sx={{ fontSize: '0.82rem', py: 1.2 }}>{record.dutyLocation || record.worksAt || '—'}</TableCell>
                              <TableCell sx={{ fontSize: '0.82rem', py: 1.2 }}>
                                {record.shiftType ? (
                                  <Chip 
                                    label={record.shiftType} 
                                    size="small" 
                                    sx={{ 
                                      bgcolor: record.shiftType === 'DAY' ? '#fef3c7' : '#dbeafe',
                                      color: record.shiftType === 'DAY' ? '#92400e' : '#1e40af',
                                      fontWeight: 600, 
                                      fontSize: '0.7rem',
                                      height: 22,
                                    }} 
                                  />
                                ) : '—'}
                              </TableCell>
                              <TableCell sx={{ fontSize: '0.82rem', py: 1.2 }}>
                                {record.status ? (
                                  <Chip 
                                    label={record.status} 
                                    size="small" 
                                    sx={{ 
                                      bgcolor: 
                                        record.status === 'ACTIVE' ? '#dcfce7' : 
                                        record.status === 'ON_LEAVE' ? '#fee2e2' :
                                        record.status === 'ADHOC' ? '#d1fae5' : '#f3f4f6',
                                      color: 
                                        record.status === 'ACTIVE' ? '#166534' : 
                                        record.status === 'ON_LEAVE' ? '#dc2626' :
                                        record.status === 'ADHOC' ? '#059669' : '#374151',
                                      fontWeight: 600, 
                                      fontSize: '0.7rem',
                                      height: 22,
                                    }} 
                                  />
                                ) : '—'}
                              </TableCell>
                              <TableCell sx={{ fontSize: '0.82rem', py: 1.2, color: record.adhocDuty ? '#059669' : 'inherit' }}>
                                {record.adhocDuty || '—'}
                              </TableCell>
                              <TableCell sx={{ fontSize: '0.82rem', py: 1.2, color: record.leaveType ? '#dc2626' : 'inherit' }}>
                                {record.leaveType ? (
                                  <Chip 
                                    label={record.leaveType.replace(/_/g, ' ')} 
                                    size="small" 
                                    sx={{ 
                                      bgcolor: '#fee2e2', 
                                      color: '#dc2626', 
                                      fontWeight: 600, 
                                      fontSize: '0.7rem',
                                      height: 22,
                                    }} 
                                  />
                                ) : '—'}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </TableContainer>

                    {/* Pagination */}
                    <TablePagination
                      component="div"
                      count={dutyHistory.totalElements}
                      page={historyPage}
                      onPageChange={(_, newPage) => setHistoryPage(newPage)}
                      rowsPerPage={historyRowsPerPage}
                      onRowsPerPageChange={(e) => {
                        setHistoryRowsPerPage(parseInt(e.target.value, 10));
                        setHistoryPage(0);
                      }}
                      rowsPerPageOptions={[5, 10, 25, 50]}
                      sx={{
                        '.MuiTablePagination-selectLabel, .MuiTablePagination-displayedRows': {
                          fontSize: '0.8rem',
                        },
                        '.MuiTablePagination-select': {
                          fontSize: '0.8rem',
                        },
                      }}
                    />
                  </>
                ) : (
                  <Box sx={{ 
                    textAlign: 'center', 
                    py: 6, 
                    color: 'text.secondary',
                    bgcolor: '#f9fafb',
                    borderRadius: 2,
                    border: '1px dashed #e5e7eb',
                  }}>
                    <HistoryIcon sx={{ fontSize: 48, color: '#d1d5db', mb: 1 }} />
                    <Typography variant="body2" sx={{ fontWeight: 500 }}>
                      No duty history records found
                    </Typography>
                    <Typography variant="caption" sx={{ color: '#9ca3af' }}>
                      {historyFiltersApplied 
                        ? 'Try adjusting the date filters'
                        : 'Duty history will appear here once records are captured'}
                    </Typography>
                  </Box>
                )}
              </CardContent>
            </Card>
          )}
        </Box>
      </Box>

      {/* Add New Duty Type Dialog */}
      <Dialog open={addDialog.open} onClose={() => setAddDialog({ ...addDialog, open: false })} maxWidth="xs" fullWidth>
        <DialogTitle sx={{ fontWeight: 600, fontSize: '1rem' }}>
          {addDialog.type === 'parent' ? 'Add New Duty Type' : 'Add New Sub Duty Type'}
        </DialogTitle>
        <DialogContent>
          <TextField
            autoFocus fullWidth size="small" sx={{ mt: 1 }}
            label={addDialog.type === 'parent' ? 'Duty Type Name' : 'Sub Duty Type Name'}
            value={addDialog.name}
            onChange={(e) => setAddDialog({ ...addDialog, name: e.target.value })}
            onKeyDown={(e) => { if (e.key === 'Enter') handleAddDialogSave(); }}
          />
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setAddDialog({ ...addDialog, open: false })} disabled={creatingDuty}>
            Cancel
          </Button>
          <Button onClick={handleAddDialogSave} variant="contained" disabled={creatingDuty || !addDialog.name.trim()}
            sx={{ bgcolor: '#312e81', '&:hover': { bgcolor: '#1e1b4b' } }}>
            {creatingDuty ? <CircularProgress size={16} /> : 'Add'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onClose={() => setDeleteDialogOpen(false)} maxWidth="xs" fullWidth>
        <DialogTitle sx={{ fontWeight: 600, fontSize: '1rem', color: '#dc2626' }}>
          Delete Personnel Record
        </DialogTitle>
        <DialogContent>
          <Typography sx={{ fontSize: '0.9rem', color: '#374151', mb: 2 }}>
            Are you sure you want to permanently delete <strong>{person?.personName}</strong> ({person?.badgeId})?
            This action cannot be undone.
          </Typography>
          <Typography sx={{ fontSize: '0.85rem', color: '#6b7280', mb: 1 }}>
            To confirm, type the code below:
          </Typography>
          <Box sx={{
            display: 'inline-block', px: 2, py: 1, mb: 2,
            bgcolor: '#fef2f2', border: '1px dashed #dc2626', borderRadius: 1,
            fontFamily: 'monospace', fontSize: '1.2rem', fontWeight: 700,
            letterSpacing: '0.2em', color: '#dc2626', userSelect: 'all',
          }}>
            {deleteCode}
          </Box>
          <TextField
            fullWidth size="small"
            placeholder="Enter the code above"
            value={deleteInput}
            onChange={(e) => setDeleteInput(e.target.value.toUpperCase())}
            inputProps={{ maxLength: 6, style: { fontFamily: 'monospace', letterSpacing: '0.15em', fontSize: '1rem' } }}
            sx={{ mt: 1 }}
          />
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setDeleteDialogOpen(false)} disabled={deleting}>
            Cancel
          </Button>
          <Button onClick={handleDelete} variant="contained"
            disabled={deleting || deleteInput !== deleteCode}
            sx={{
              bgcolor: deleteInput === deleteCode ? '#dc2626' : '#e5e7eb',
              color: deleteInput === deleteCode ? '#ffffff' : '#9ca3af',
              '&:hover': { bgcolor: deleteInput === deleteCode ? '#b91c1c' : '#e5e7eb' },
              '&.Mui-disabled': { bgcolor: '#e5e7eb', color: '#9ca3af' },
            }}>
            {deleting ? <CircularProgress size={16} /> : 'Delete'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default PersonnelProfilePage;

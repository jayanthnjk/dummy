import React, { useState, useCallback } from 'react';
import { Box, Button, Stack, Typography } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';

import CycleListView from '@/components/cycle/CycleListView';
import CycleDetailView from '@/components/cycle/CycleDetailView';
import CycleForm from '@/components/cycle/CycleForm';
import ReassignModal from '@/components/cycle/ReassignModal';
import type { AssignmentResponse } from '@/services/cycleService';

type ViewState = 'list' | 'detail';

/**
 * CycleManagementPage — Full page for managing platoon rotation cycles.
 *
 * State machine:
 *  - 'list': shows CycleListView + "Create Cycle" button
 *  - 'detail': shows CycleDetailView with back navigation
 *
 * Integrates CycleForm (dialog) for creation and ReassignModal for leave-conflict reassignment.
 *
 * Implements Requirements 4.3, 4.4.
 */
const CycleManagementPage: React.FC = () => {
  // View state machine
  const [view, setView] = useState<ViewState>('list');
  const [selectedCycleId, setSelectedCycleId] = useState<number | null>(null);

  // CycleForm dialog state
  const [cycleFormOpen, setCycleFormOpen] = useState(false);

  // ReassignModal state
  const [reassignOpen, setReassignOpen] = useState(false);
  const [reassignAssignment, setReassignAssignment] = useState<AssignmentResponse | null>(null);

  // Key to force CycleListView remount (refresh) after creation
  const [listKey, setListKey] = useState(0);
  // Key to force CycleDetailView remount (refresh) after reassignment
  const [detailKey, setDetailKey] = useState(0);

  // Navigate to cycle detail
  const handleCycleSelect = useCallback((cycleId: number) => {
    setSelectedCycleId(cycleId);
    setView('detail');
  }, []);

  // Navigate back to list
  const handleBack = useCallback(() => {
    setView('list');
    setSelectedCycleId(null);
  }, []);

  // Open CycleForm
  const handleOpenCycleForm = useCallback(() => {
    setCycleFormOpen(true);
  }, []);

  // On successful cycle creation, close form and refresh list
  const handleCycleCreated = useCallback(() => {
    setCycleFormOpen(false);
    setListKey((prev) => prev + 1);
  }, []);

  // Open ReassignModal when CycleDetailView emits onReassign
  const handleReassign = useCallback((assignment: AssignmentResponse) => {
    setReassignAssignment(assignment);
    setReassignOpen(true);
  }, []);

  // On successful reassignment, close modal and refresh detail view
  const handleReassignSuccess = useCallback(() => {
    setReassignOpen(false);
    setReassignAssignment(null);
    setDetailKey((prev) => prev + 1);
  }, []);

  const handleReassignClose = useCallback(() => {
    setReassignOpen(false);
    setReassignAssignment(null);
  }, []);

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        flex: 1,
        overflow: 'hidden',
        backgroundColor: '#F9FAFB',
      }}
    >
      {/* Dark Navy Page Header */}
      <Box
        sx={{
          background: 'linear-gradient(135deg, #1a1e4a 0%, #2d3561 100%)',
          color: 'white',
          px: { xs: 2, md: 4 },
          pt: 2,
          pb: 1.5,
          flexShrink: 0,
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
          <Box>
            <Typography variant="h5" fontWeight={700} sx={{ letterSpacing: '-0.02em' }}>
              Platoon Cycle Management
            </Typography>
            <Typography variant="body2" sx={{ color: 'rgba(255,255,255,0.7)', mt: 0.5 }}>
              Create and manage platoon rotation cycles
            </Typography>
          </Box>
          {view === 'list' && (
            <Stack direction="row" spacing={1}>
              <Button
                variant="contained"
                size="small"
                startIcon={<AddIcon sx={{ fontSize: 16 }} />}
                onClick={handleOpenCycleForm}
                disableElevation
                sx={{
                  backgroundColor: 'rgba(255,255,255,0.08)',
                  backdropFilter: 'blur(8px)',
                  border: '1px solid rgba(255,255,255,0.2)',
                  color: 'white',
                  textTransform: 'none',
                  fontWeight: 600,
                  fontSize: '0.82rem',
                  borderRadius: 2,
                  px: 2,
                  '&:hover': {
                    backgroundColor: 'rgba(255,255,255,0.15)',
                    borderColor: 'rgba(255,255,255,0.4)',
                  },
                }}
              >
                Create Cycle
              </Button>
            </Stack>
          )}
        </Box>
      </Box>

      {/* Page Content */}
      <Box sx={{ flex: 1, overflow: 'auto', p: { xs: 2, md: 3 } }}>
        {view === 'list' && (
          <CycleListView key={listKey} onCycleSelect={handleCycleSelect} />
        )}

        {view === 'detail' && selectedCycleId !== null && (
          <CycleDetailView
            key={detailKey}
            cycleId={selectedCycleId}
            onBack={handleBack}
            onReassign={handleReassign}
          />
        )}
      </Box>

      {/* CycleForm Dialog */}
      <CycleForm
        open={cycleFormOpen}
        onClose={() => setCycleFormOpen(false)}
        onSuccess={handleCycleCreated}
      />

      {/* ReassignModal */}
      <ReassignModal
        open={reassignOpen}
        onClose={handleReassignClose}
        onSuccess={handleReassignSuccess}
        assignmentId={reassignAssignment?.id ?? null}
        assignmentDate={reassignAssignment?.date ?? ''}
        currentPersonName={
          reassignAssignment ? `Person ${reassignAssignment.personId}` : ''
        }
      />
    </Box>
  );
};

export default CycleManagementPage;

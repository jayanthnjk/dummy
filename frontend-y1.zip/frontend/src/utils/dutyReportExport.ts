import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import type { DutyType } from '@/types/dutySections';

interface SectionInfo {
  code: string;
  name: string;
}

interface ParentGroup {
  name: string;
  children: string[];
}

/**
 * Builds hierarchical data grouped by section -> parent -> sub duties
 */
function buildHierarchicalData(
  dutyTypes: DutyType[],
  sections: SectionInfo[]
): { sectionCode: string; sectionName: string; parents: ParentGroup[] }[] {
  const result: { sectionCode: string; sectionName: string; parents: ParentGroup[] }[] = [];

  const bySection: Record<string, DutyType[]> = {};
  for (const dt of dutyTypes) {
    if (!bySection[dt.section]) bySection[dt.section] = [];
    bySection[dt.section].push(dt);
  }

  for (const section of sections) {
    const sectionDuties = bySection[section.code];
    if (!sectionDuties || sectionDuties.length === 0) continue;

    const parents = sectionDuties
      .filter((dt) => dt.level === 'PARENT' || (!dt.parentId && !dt.level))
      .sort((a, b) => a.sortOrder - b.sortOrder);

    const parentData: ParentGroup[] = [];
    for (const parent of parents) {
      const children = sectionDuties
        .filter((dt) => dt.parentId === parent.id)
        .sort((a, b) => a.sortOrder - b.sortOrder)
        .map((dt) => dt.name);
      parentData.push({ name: parent.name, children });
    }

    result.push({ sectionCode: section.code, sectionName: section.name, parents: parentData });
  }

  return result;
}

/**
 * Export duty types as PDF — clean, simple tabular format matching the source document style.
 * Columns: Sl.No | Parent Duty Type | Sub Duty Type
 */
export function exportDutyTypesPdf(
  dutyTypes: DutyType[],
  sections: SectionInfo[],
  selectedSectionCode?: string | null
): void {
  const doc = new jsPDF('p', 'mm', 'a4');
  const pageWidth = doc.internal.pageSize.getWidth();
  const today = new Date().toLocaleDateString('en-IN', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });

  const filteredSections = selectedSectionCode
    ? sections.filter((s) => s.code === selectedSectionCode)
    : sections;

  const hierarchicalData = buildHierarchicalData(dutyTypes, filteredSections);

  let currentY = 15;

  // Title - centered, bold
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(0, 0, 0);
  doc.text('DUTY TYPES LIST', pageWidth / 2, currentY, { align: 'center' });
  currentY += 7;

  // Date
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(80, 80, 80);
  doc.text(`Date: ${today}`, 14, currentY);
  currentY += 8;

  for (const sectionData of hierarchicalData) {
    // Section header - centered, bold, with background
    doc.setFillColor(50, 50, 50);
    doc.rect(14, currentY - 4, pageWidth - 28, 7, 'F');
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(255, 255, 255);
    doc.text(`SECTION ${sectionData.sectionCode}`, pageWidth / 2, currentY, { align: 'center' });
    currentY += 6;

    // Build table rows
    const tableBody: (string | { content: string; rowSpan?: number; styles?: object })[][] = [];
    let slNo = 1;

    for (const parent of sectionData.parents) {
      if (parent.children.length === 0) {
        // Parent with no children — spans both sub-duty columns
        tableBody.push([
          String(slNo),
          { content: parent.name, styles: { fontStyle: 'bold' } },
          '',
        ]);
      } else {
        // Parent with children: first row shows parent + first child
        tableBody.push([
          { content: String(slNo), rowSpan: parent.children.length },
          { content: parent.name, rowSpan: parent.children.length, styles: { fontStyle: 'bold' } },
          parent.children[0],
        ]);
        // Subsequent children rows
        for (let i = 1; i < parent.children.length; i++) {
          tableBody.push([parent.children[i]]);
        }
      }
      slNo++;
    }

    autoTable(doc, {
      startY: currentY,
      head: [['Sl.No', 'Duty Type', 'Sub Duty Type']],
      body: tableBody as any,
      theme: 'grid',
      styles: {
        font: 'helvetica',
        fontSize: 8,
        cellPadding: 2,
        lineColor: [0, 0, 0],
        lineWidth: 0.2,
        textColor: [0, 0, 0],
        valign: 'middle',
      },
      headStyles: {
        fillColor: [240, 240, 240],
        textColor: [0, 0, 0],
        fontStyle: 'bold',
        fontSize: 8,
        halign: 'center',
      },
      columnStyles: {
        0: { cellWidth: 12, halign: 'center' },
        1: { cellWidth: 55 },
        2: { cellWidth: pageWidth - 28 - 12 - 55 },
      },
      margin: { left: 14, right: 14 },
    });

    currentY = (doc as any).lastAutoTable.finalY + 5;

    // Total row
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(0, 0, 0);
    doc.text(`TOTAL= ${sectionData.parents.length} Duty Types`, pageWidth - 14, currentY, { align: 'right' });
    currentY += 10;

    // New page if needed
    if (currentY > doc.internal.pageSize.getHeight() - 30) {
      doc.addPage();
      currentY = 15;
    }
  }

  const fileName = selectedSectionCode
    ? `Duty-Types-Section-${selectedSectionCode}-${today.replace(/\//g, '-')}.pdf`
    : `Duty-Types-All-Sections-${today.replace(/\//g, '-')}.pdf`;

  doc.save(fileName);
}

/**
 * Export duty types as Excel — clean tabular format.
 * Columns: Sl.No | Duty Type | Sub Duty Type
 */
export function exportDutyTypesExcel(
  dutyTypes: DutyType[],
  sections: SectionInfo[],
  selectedSectionCode?: string | null
): void {
  const today = new Date().toLocaleDateString('en-IN', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });

  const filteredSections = selectedSectionCode
    ? sections.filter((s) => s.code === selectedSectionCode)
    : sections;

  const hierarchicalData = buildHierarchicalData(dutyTypes, filteredSections);

  const wb = XLSX.utils.book_new();

  // Build sheet data
  const wsData: (string | number | null)[][] = [];
  wsData.push(['DUTY TYPES LIST']);
  wsData.push([`Date: ${today}`]);
  wsData.push([]);

  for (const sectionData of hierarchicalData) {
    // Section header row
    wsData.push([`SECTION ${sectionData.sectionCode}`]);
    wsData.push(['Sl.No', 'Duty Type', 'Sub Duty Type']);

    let slNo = 1;
    for (const parent of sectionData.parents) {
      if (parent.children.length === 0) {
        wsData.push([slNo, parent.name, '']);
      } else {
        // First child with parent
        wsData.push([slNo, parent.name, parent.children[0]]);
        // Remaining children
        for (let i = 1; i < parent.children.length; i++) {
          wsData.push(['', '', parent.children[i]]);
        }
      }
      slNo++;
    }

    wsData.push([null, null, null, `TOTAL= ${sectionData.parents.length} Duty Types`]);
    wsData.push([]); // gap
  }

  const ws = XLSX.utils.aoa_to_sheet(wsData);

  // Column widths
  ws['!cols'] = [
    { wch: 6 },   // Sl.No
    { wch: 35 },  // Duty Type
    { wch: 55 },  // Sub Duty Type
    { wch: 20 },  // Total
  ];

  XLSX.utils.book_append_sheet(wb, ws, 'Duty Types');

  const fileName = selectedSectionCode
    ? `Duty-Types-Section-${selectedSectionCode}-${today.replace(/\//g, '-')}.xlsx`
    : `Duty-Types-All-Sections-${today.replace(/\//g, '-')}.xlsx`;

  const wbOut = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([wbOut], { type: 'application/octet-stream' });
  saveAs(blob, fileName);
}

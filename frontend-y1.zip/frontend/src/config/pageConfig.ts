import type { BreadcrumbItem } from '../components/common/PageHeader';

/**
 * Centralized page configuration defining title, i18n key, and breadcrumb path
 * for each application page. Used by PageHeader for consistent navigation display.
 *
 * NOTE: Pages currently pass these props inline. This config exists for centralization
 * and future reference — pages can migrate to config-driven headers over time.
 */
export interface PageConfig {
  /** Display title for the page header */
  title: string;
  /** i18n translation key for the page title */
  titleKey: string;
  /** Breadcrumb path items (last item has no path = current page) */
  breadcrumbs: BreadcrumbItem[];
}

const HOME_BREADCRUMB: BreadcrumbItem = { label: 'Home', path: '/' };

export const homePageConfig: PageConfig = {
  title: 'AI Assistant',
  titleKey: 'home.title',
  breadcrumbs: [{ label: 'Home' }],
};

export const personnelPageConfig: PageConfig = {
  title: 'Personnel',
  titleKey: 'personnel.title',
  breadcrumbs: [HOME_BREADCRUMB, { label: 'Personnel' }],
};

export const schedulesPageConfig: PageConfig = {
  title: 'Schedules',
  titleKey: 'schedules.title',
  breadcrumbs: [HOME_BREADCRUMB, { label: 'Schedules' }],
};

export const adhocDutyPageConfig: PageConfig = {
  title: 'Adhoc Duties',
  titleKey: 'pages.adhocDuty.title',
  breadcrumbs: [HOME_BREADCRUMB, { label: 'Adhoc Duties' }],
};

export const leaveRequestsPageConfig: PageConfig = {
  title: 'Leave Requests',
  titleKey: 'leave.title',
  breadcrumbs: [HOME_BREADCRUMB, { label: 'Leave Requests' }],
};

export const reportsPageConfig: PageConfig = {
  title: 'Reports',
  titleKey: 'reports.title',
  breadcrumbs: [HOME_BREADCRUMB, { label: 'Reports' }],
};

export const settingsPageConfig: PageConfig = {
  title: 'Settings',
  titleKey: 'settings.title',
  breadcrumbs: [HOME_BREADCRUMB, { label: 'Settings' }],
};

/**
 * All page configs keyed by route identifier for lookup convenience.
 */
export const pageConfigs: Record<string, PageConfig> = {
  home: homePageConfig,
  personnel: personnelPageConfig,
  schedules: schedulesPageConfig,
  adhocDuties: adhocDutyPageConfig,
  leaveRequests: leaveRequestsPageConfig,
  reports: reportsPageConfig,
  settings: settingsPageConfig,
};

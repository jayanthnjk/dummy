import HomeIcon from '@mui/icons-material/Home';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import PeopleIcon from '@mui/icons-material/People';
import EventBusyIcon from '@mui/icons-material/EventBusy';
import AssignmentLateIcon from '@mui/icons-material/AssignmentLate';
import DescriptionIcon from '@mui/icons-material/Description';
import AssignmentIcon from '@mui/icons-material/Assignment';
import SupportAgentIcon from '@mui/icons-material/SupportAgent';
import LockResetIcon from '@mui/icons-material/LockReset';
import type { SvgIconComponent } from '@mui/icons-material';

export interface NavItem {
  id: string;
  labelKey: string;
  path: string;
  icon: SvgIconComponent;
  adminOnly?: boolean;
}

export interface NavGroup {
  id: string;
  label: string;
  labelKey: string;
  items: NavItem[];
}

export const navigationGroups: NavGroup[] = [
  {
    id: 'main',
    label: 'Main',
    labelKey: 'nav.groups.main',
    items: [
      { id: 'home', labelKey: 'nav.home', path: '/', icon: HomeIcon },
      { id: 'schedules', labelKey: 'nav.schedules', path: '/schedules', icon: CalendarMonthIcon },
      { id: 'personnel', labelKey: 'nav.personnel', path: '/personnel', icon: PeopleIcon },
    ],
  },
  {
    id: 'operations',
    label: 'Operations',
    labelKey: 'nav.groups.operations',
    items: [
      { id: 'leave', labelKey: 'nav.leaveRequests', path: '/leave-requests', icon: EventBusyIcon },
      { id: 'adhoc', labelKey: 'nav.adhocDuties', path: '/schedules/adhoc', icon: AssignmentLateIcon },
      { id: 'reports', labelKey: 'nav.reports', path: '/reports', icon: DescriptionIcon },
    ],
  },
  {
    id: 'administration',
    label: 'Administration',
    labelKey: 'nav.groups.administration',
    items: [
      { id: 'dutySections', labelKey: 'nav.dutySections', path: '/admin/duty-sections', icon: AssignmentIcon, adminOnly: true },
      { id: 'contactSupport', labelKey: 'nav.contactSupport', path: '/contact-support', icon: SupportAgentIcon },
      { id: 'changePassword', labelKey: 'nav.changePassword', path: '/change-password', icon: LockResetIcon },
    ],
  },
];

/**
 * Filters navigation groups to only include items visible to the given user role.
 * Items with `adminOnly: true` are only visible to users with "ADMIN" or "HIGHER_OFFICER" roles.
 * Non-admin items are always visible regardless of role.
 */
export function getVisibleNavItems(groups: NavGroup[], userRole: string): NavGroup[] {
  const isPrivileged = userRole === 'ADMIN' || userRole === 'HIGHER_OFFICER';

  return groups
    .map((group) => ({
      ...group,
      items: group.items.filter((item) => !item.adminOnly || isPrivileged),
    }))
    .filter((group) => group.items.length > 0);
}

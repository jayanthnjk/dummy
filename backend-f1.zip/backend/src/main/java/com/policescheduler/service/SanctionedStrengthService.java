package com.policescheduler.service;

import com.policescheduler.dto.SanctionedStrengthDto;
import com.policescheduler.dto.StrengthMetricsDto;
import com.policescheduler.dto.UpdateSanctionedStrengthRequest;
import com.policescheduler.entity.SanctionedStrength;
import com.policescheduler.exception.ResourceNotFoundException;
import com.policescheduler.repository.PersonnelRepository;
import com.policescheduler.repository.SanctionedStrengthRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class SanctionedStrengthService {

    private final SanctionedStrengthRepository sanctionedStrengthRepository;
    private final PersonnelRepository personnelRepository;

    public SanctionedStrengthService(SanctionedStrengthRepository sanctionedStrengthRepository,
                                     PersonnelRepository personnelRepository) {
        this.sanctionedStrengthRepository = sanctionedStrengthRepository;
        this.personnelRepository = personnelRepository;
    }

    public List<SanctionedStrengthDto> getAllSanctionedStrength() {
        return sanctionedStrengthRepository.findAllByOrderByDisplayOrderAsc()
                .stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    public SanctionedStrengthDto getByDesignation(String designation) {
        return sanctionedStrengthRepository.findByDesignation(designation)
                .map(this::toDto)
                .orElseThrow(() -> new ResourceNotFoundException("Sanctioned strength not found for designation: " + designation));
    }

    @Transactional
    public SanctionedStrengthDto updateSanctionedStrength(UpdateSanctionedStrengthRequest request) {
        SanctionedStrength entity = sanctionedStrengthRepository.findByDesignation(request.getDesignation())
                .orElseGet(() -> {
                    // Create new entry if it doesn't exist
                    SanctionedStrength newEntity = new SanctionedStrength();
                    newEntity.setDesignation(request.getDesignation());
                    // Set display order based on existing entries
                    int maxOrder = sanctionedStrengthRepository.findAllByOrderByDisplayOrderAsc()
                            .stream()
                            .mapToInt(SanctionedStrength::getDisplayOrder)
                            .max()
                            .orElse(0);
                    newEntity.setDisplayOrder(maxOrder + 1);
                    return newEntity;
                });
        
        entity.setSanctionedCount(request.getSanctionedCount());
        return toDto(sanctionedStrengthRepository.save(entity));
    }

    @Transactional
    public List<SanctionedStrengthDto> bulkUpdateSanctionedStrength(List<UpdateSanctionedStrengthRequest> requests) {
        List<SanctionedStrengthDto> results = new ArrayList<>();
        for (UpdateSanctionedStrengthRequest request : requests) {
            results.add(updateSanctionedStrength(request));
        }
        return results;
    }

    public StrengthMetricsDto getStrengthMetrics() {
        // Get all sanctioned strength entries ordered by display order
        List<SanctionedStrength> sanctionedList = sanctionedStrengthRepository.findAllByOrderByDisplayOrderAsc();
        
        // Get present count grouped by designation (combining CAR and MT units)
        Map<String, Long> presentCountMap = personnelRepository.findByIsActiveTrue()
                .stream()
                .filter(p -> p.getDesignation() != null && !p.getDesignation().isEmpty())
                .collect(Collectors.groupingBy(
                        p -> p.getDesignation().toUpperCase(),
                        Collectors.counting()
                ));

        // Build the metrics
        List<String> designations = new ArrayList<>();
        Map<String, Integer> sanctionedStrength = new LinkedHashMap<>();
        Map<String, Integer> presentStrength = new LinkedHashMap<>();
        Map<String, Integer> vacancy = new LinkedHashMap<>();

        int totalSanctioned = 0;
        int totalPresent = 0;

        for (SanctionedStrength ss : sanctionedList) {
            String designation = ss.getDesignation();
            designations.add(designation);
            
            int sanctioned = ss.getSanctionedCount();
            int present = presentCountMap.getOrDefault(designation.toUpperCase(), 0L).intValue();
            int vac = sanctioned - present;

            sanctionedStrength.put(designation, sanctioned);
            presentStrength.put(designation, present);
            vacancy.put(designation, vac);

            totalSanctioned += sanctioned;
            totalPresent += present;
        }

        return StrengthMetricsDto.builder()
                .designations(designations)
                .sanctionedStrength(sanctionedStrength)
                .presentStrength(presentStrength)
                .vacancy(vacancy)
                .totalSanctioned(totalSanctioned)
                .totalPresent(totalPresent)
                .totalVacancy(totalSanctioned - totalPresent)
                .build();
    }

    private SanctionedStrengthDto toDto(SanctionedStrength entity) {
        return SanctionedStrengthDto.builder()
                .id(entity.getId())
                .designation(entity.getDesignation())
                .displayOrder(entity.getDisplayOrder())
                .sanctionedCount(entity.getSanctionedCount())
                .build();
    }
}

import React from 'react';
import { Box, Typography, Chip } from '@mui/material';
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import type { SuggestionsResponseData } from '@/types';

interface SuggestionsWidgetProps extends SuggestionsResponseData {
  onSuggestionClick: (suggestion: string) => void;
}

const SuggestionsWidget: React.FC<SuggestionsWidgetProps> = ({ message, suggestions, onSuggestionClick }) => {
  return (
    <Box sx={{
      width: '100%', borderRadius: 2.5, overflow: 'hidden',
      border: '1px solid #e5e7eb', bgcolor: '#fff',
    }}>
      {/* Header */}
      <Box sx={{
        px: 2, py: 1.5, bgcolor: '#fefce8',
        borderBottom: '1px solid #fde68a',
        display: 'flex', alignItems: 'center', gap: 1.5,
      }}>
        <Box sx={{
          width: 30, height: 30, borderRadius: 1.5,
          bgcolor: '#fef3c7',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <HelpOutlineIcon sx={{ fontSize: 16, color: '#d97706' }} />
        </Box>
        <Typography sx={{ fontSize: '0.82rem', color: '#92400e', lineHeight: 1.4 }}>
          {message}
        </Typography>
      </Box>

      {/* Suggestions */}
      <Box sx={{ px: 2, py: 1.5 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mb: 1.5 }}>
          <AutoAwesomeIcon sx={{ fontSize: 14, color: '#6366f1' }} />
          <Typography sx={{ fontSize: '0.7rem', fontWeight: 600, color: '#6366f1', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            You can try these
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
          {suggestions.map((s, i) => (
            <Chip
              key={i}
              label={s}
              onClick={() => onSuggestionClick(s)}
              sx={{
                fontSize: '0.78rem',
                fontWeight: 500,
                height: 34,
                borderRadius: 2,
                bgcolor: '#f8fafc',
                border: '1px solid #e2e8f0',
                color: '#334155',
                cursor: 'pointer',
                transition: 'all 0.2s',
                '&:hover': {
                  bgcolor: '#eef2ff',
                  borderColor: '#6366f1',
                  color: '#4338ca',
                  transform: 'translateY(-1px)',
                  boxShadow: '0 2px 8px rgba(99,102,241,0.15)',
                },
              }}
            />
          ))}
        </Box>
      </Box>
    </Box>
  );
};

export default SuggestionsWidget;

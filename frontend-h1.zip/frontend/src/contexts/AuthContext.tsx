import React, { createContext, useContext } from 'react';
import { observer } from 'mobx-react-lite';
import { authStore } from '@/stores/authStore';
import type { UserRole, AuthResponse } from '@/types';

interface AuthContextValue {
  token: string | null;
  role: UserRole | null;
  displayName: string | null;
  units: string | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  hasCAR: boolean;
  hasMT: boolean;
  isCAROnly: boolean;
  isMTOnly: boolean;
  login: (authResponse: AuthResponse) => void;
  logout: () => void;
  showInactivityDialog: boolean;
  inactivityCountdown: number;
  staySignedIn: () => void;
}

const AuthContext = createContext<AuthContextValue>(null!);

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = observer(({ children }) => {
  const value: AuthContextValue = {
    token: authStore.token,
    role: authStore.role,
    displayName: authStore.displayName,
    units: authStore.units,
    isAuthenticated: authStore.isAuthenticated,
    isAdmin: authStore.isAdmin,
    hasCAR: authStore.hasCAR,
    hasMT: authStore.hasMT,
    isCAROnly: authStore.isCAROnly,
    isMTOnly: authStore.isMTOnly,
    login: (auth) => authStore.login(auth),
    logout: () => authStore.logout(),
    showInactivityDialog: authStore.showInactivityDialog,
    inactivityCountdown: authStore.inactivityCountdown,
    staySignedIn: () => authStore.staySignedIn(),
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
});

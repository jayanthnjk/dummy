package com.policescheduler.dto;

/**
 * DTO for listing available reports in the system.
 * Used for populating report selection dropdowns.
 */
public class AvailableReportDTO {

    private String reportType;  // e.g., "platoon_chart", "form_168"
    private String reportName;  // Human-readable: "Platoon Chart C - Rotational Duties"
    private String description;

    public AvailableReportDTO() {
    }

    public AvailableReportDTO(String reportType, String reportName, String description) {
        this.reportType = reportType;
        this.reportName = reportName;
        this.description = description;
    }

    // Getters and Setters

    public String getReportType() {
        return reportType;
    }

    public void setReportType(String reportType) {
        this.reportType = reportType;
    }

    public String getReportName() {
        return reportName;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}

import api from './api';
import type { TranslationEntry } from '@/types';

export const i18nService = {
  getTranslations: (locale: string) =>
    api.get<Record<string, string>>(`/api/i18n/translations/${locale}`).then((r) => r.data),

  upsertTranslation: (entry: TranslationEntry) =>
    api.post<void>('/api/i18n/translations', entry),

  getMissingTranslations: () =>
    api.get<string[]>('/api/i18n/missing').then((r) => r.data),
};

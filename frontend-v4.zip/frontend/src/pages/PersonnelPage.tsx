import React, { useEffect, useState } from 'react';
import {
  Box, Typography, Button, Alert, CircularProgress, Stack,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';

import { useTranslation } from 'react-i18next';
import DataTable, { type Column } from '@/components/DataTable';
import DownloadButton from '@/components/DownloadButton';
import { personnelService } from '@/services/personnelService';
import { sectionService } from '@/services/sectionService';
import { reportService } from '@/services/reportService';
import type { PersonnelDto } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

const PersonnelPage: React.FC = () => {
  const { t } = useTranslation();
  const { role } = useAuth();
  const navigate = useNavigate();
  const [data, setData] = useState<PersonnelDto[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [sectionCodes, setSectionCodes] = useState<string[]>([]);

  const canEdit = role === 'ADMIN' || role === 'HIGHER_OFFICER';

  const fetchData = async () => {
    setLoading(true);
    try {
      const [result, sections] = await Promise.all([
        personnelService.list(undefined, 0, 500),
        sectionService.list(),
      ]);
      setData(result.content);
      setSectionCodes(sections.map(s => s.code));
    } catch {
      setError(t('app.error'));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const columns: Column<PersonnelDto>[] = [
    { id: 'badgeId', labelKey: 'personnel.badgeId', filterable: true, width: 100 },
    {
      id: 'personName', labelKey: 'personnel.personName', filterable: true, minWidth: 180,
      render: (row) => (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.2 }}>
          <Box sx={{
            width: 32, height: 32, borderRadius: '50%', bgcolor: '#f0f0ff', flexShrink: 0,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: '0.72rem', fontWeight: 600, color: '#1a1e4a',
          }}>
            {row.personName?.charAt(0)?.toUpperCase() || '?'}
          </Box>
          <Box>
            <Typography sx={{ fontSize: '0.85rem', fontWeight: 500, color: '#111827', lineHeight: 1.2 }}>{row.personName}</Typography>
            {row.email && <Typography sx={{ fontSize: '0.72rem', color: '#9ca3af' }}>{row.email}</Typography>}
          </Box>
        </Box>
      ),
    },
    {
      id: 'designation', labelKey: 'personnel.designation', filterable: true,
      filterType: 'select', filterOptions: ['DCP', 'ACP', 'RPI', 'RSI', 'ARSI', 'AHC', 'APC'],
      render: (row) => row.designation ? (
        <Box sx={{
          display: 'inline-block', px: 1.2, py: 0.3, borderRadius: 1,
          bgcolor: row.designation === 'DCP' || row.designation === 'ACP' ? '#ede9fe' :
                   row.designation === 'RSI' || row.designation === 'RPI' ? '#dbeafe' : '#f0fdf4',
          color: row.designation === 'DCP' || row.designation === 'ACP' ? '#6d28d9' :
                 row.designation === 'RSI' || row.designation === 'RPI' ? '#1d4ed8' : '#166534',
          fontSize: '0.75rem', fontWeight: 600,
        }}>
          {row.designation}
        </Box>
      ) : null,
    },
    { id: 'dutyType', labelKey: 'personnel.dutyType', filterable: true },
    {
      id: 'section', labelKey: 'personnel.section', filterable: true,
      filterType: 'select', filterOptions: sectionCodes,
    },
    { id: 'location', labelKey: 'personnel.location' },
    {
      id: 'isActive', labelKey: 'personnel.active',
      render: (row) => (
        <Box sx={{
          display: 'inline-block', px: 1.2, py: 0.3, borderRadius: 1,
          bgcolor: row.isActive ? '#f0fdf4' : '#fef2f2',
          color: row.isActive ? '#166534' : '#dc2626',
          fontSize: '0.75rem', fontWeight: 600,
        }}>
          {row.isActive ? 'Active' : 'Inactive'}
        </Box>
      ),
    },
  ];

  const activeCount = data.filter(p => p.isActive).length;
  const sectionCount = sectionCodes.length;

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', backgroundColor: '#F8FAFC' }}>
      {/* Dark Navy Page Header */}
      <Box
        sx={{
          background: 'linear-gradient(135deg, #1a1e4a 0%, #2d3561 100%)',
          color: 'white',
          px: { xs: 2, md: 4 },
          pt: 2,
          pb: 1.5,
        }}
      >
        {/* Top row: Title + Actions */}
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
          <Box>
            <Typography variant="h5" fontWeight={700} sx={{ letterSpacing: '-0.02em' }}>
              {t('personnel.title')}
            </Typography>
            <Typography variant="body2" sx={{ color: 'rgba(255,255,255,0.7)', mt: 0.5 }}>
              {t('personnel.subtitle', 'Manage personnel records and assignments')}
            </Typography>
          </Box>
          <Stack direction="row" spacing={1}>
            {canEdit && (
              <Button
                startIcon={<AddIcon />}
                onClick={() => navigate('/personnel/add')}
                sx={{
                  backgroundColor: 'rgba(255,255,255,0.08)',
                  backdropFilter: 'blur(8px)',
                  border: '1px solid rgba(255,255,255,0.2)',
                  color: 'white',
                  textTransform: 'none',
                  fontWeight: 600,
                  fontSize: '0.82rem',
                  borderRadius: 2,
                  px: 2,
                  '&:hover': { 
                    backgroundColor: 'rgba(255,255,255,0.15)',
                    borderColor: 'rgba(255,255,255,0.4)',
                  },
                }}
              >
                {t('personnel.addPerson')}
              </Button>
            )}
          </Stack>
        </Box>
      </Box>

      {/* Main Content */}
      <Box sx={{ flex: 1, p: 3 }}>
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}><CircularProgress /></Box>
        ) : (
          <DataTable<PersonnelDto>
            columns={columns}
            data={data}
            keyField="id"
            searchable
            searchPlaceholderKey="personnel.searchPlaceholder"
            dense
            actions={(row) => (
              <Button size="small" onClick={() => navigate(`/personnel/${row.badgeId}`)}
                sx={{
                  textTransform: 'none', fontSize: '0.78rem', fontWeight: 500,
                  color: '#1a1e4a', '&:hover': { bgcolor: '#f0f0ff' },
                }}>
                View
              </Button>
            )}
          />
        )}
      </Box>
    </Box>
  );
};

export default PersonnelPage;

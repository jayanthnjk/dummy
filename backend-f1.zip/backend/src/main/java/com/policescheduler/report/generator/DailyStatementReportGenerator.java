package com.policescheduler.report.generator;

import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.PageSize;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.policescheduler.report.Form168LayoutEngine;
import com.policescheduler.report.Form168StyleHelper;
import com.policescheduler.report.PdfReportGenerator;
import com.policescheduler.report.ReportGenerationException;
import com.policescheduler.report.ReportRequest;
import com.policescheduler.report.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

@Service
public class DailyStatementReportGenerator implements PdfReportGenerator {

    private static final Logger log = LoggerFactory.getLogger(DailyStatementReportGenerator.class);
    private static final DateTimeFormatter DISPLAY_DATE_FORMAT = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private static final List<String> STRENGTH_DESIGNATION_COLS = List.of("DCP", "ACP", "RPI", "RSI", "ARSI", "AHC", "APC");
    private static final float[] SECTION_TABLE_WIDTHS = {28, 5, 5, 5, 5, 7, 7, 5, 7, 26};
    private static final float[] LEAVE_TABLE_WIDTHS = {5, 20, 15, 60};

    private static final String[] STRENGTH_ROW_LABELS = {
            "C.A.R SANCTIONED STRENGTH",
            "PRESENT STRENGTH TOTAL",
            "ACTUAL VACANCY",
            "PRESENT STRENGTH PMT",
            "PRESENT STRENGTH COMPANY",
            "RECRUIT APC'S"
    };

    private static final String[] SECTION_COLUMN_HEADERS = {
            "HEADS", "ACP", "RPI", "RSI", "ARSI", "AHC", "APC", "SWP", "TOTAL", "PERSONNEL DETAILS"
    };

    private final Form168StyleHelper styleHelper;
    private final Form168LayoutEngine layoutEngine;

    public DailyStatementReportGenerator(Form168StyleHelper styleHelper,
                                          Form168LayoutEngine layoutEngine) {
        this.styleHelper = styleHelper;
        this.layoutEngine = layoutEngine;
    }

    @Override
    public String getReportType() {
        return "form_168";
    }

    @Override
    public byte[] generate(ReportRequest request) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            Document document = new Document(
                    PageSize.A4,
                    Form168StyleHelper.MARGIN_LEFT,
                    Form168StyleHelper.MARGIN_RIGHT,
                    Form168StyleHelper.MARGIN_TOP,
                    Form168StyleHelper.MARGIN_BOTTOM
            );
            PdfWriter.getInstance(document, baos);
            document.open();

            LocalDate reportDate = request.getDate() != null ? request.getDate() : LocalDate.now();

            // Build the report model via layout engine
            Form168ReportModel model = layoutEngine.buildReportModel(reportDate);

            // Render all sections in order
            renderFormHeader(document, reportDate);
            renderStrengthTable(document, model.getStrengthTable());
            renderSectionColumnHeaders(document);
            renderAllSections(document, model.getSections());
            renderOfficerDutySection(document, model.getOfficerDuty());
            renderLeaveStatementSection(document, model.getLeaveStatement());

            document.close();
            return baos.toByteArray();
        } catch (ReportGenerationException e) {
            throw e;
        } catch (Exception e) {
            log.error("Failed to generate Form 168 daily statement report", e);
            throw new ReportGenerationException("form_168", "Failed to generate daily statement report", e);
        }
    }

    // ======================== FORM HEADER ========================

    private void renderFormHeader(Document document, LocalDate reportDate) throws Exception {
        PdfPTable headerTable = new PdfPTable(3);
        headerTable.setWidthPercentage(100);
        headerTable.setWidths(new float[]{33, 34, 33});

        PdfPCell formCell = new PdfPCell(new Phrase("FORM NO:168", styleHelper.getTitleFont()));
        formCell.setBorder(Rectangle.NO_BORDER);
        formCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        headerTable.addCell(formCell);

        PdfPCell middleCell = new PdfPCell(new Phrase(""));
        middleCell.setBorder(Rectangle.NO_BORDER);
        headerTable.addCell(middleCell);

        PdfPCell dateCell = new PdfPCell(new Phrase("DATE :" + reportDate.format(DISPLAY_DATE_FORMAT), styleHelper.getHeaderFont()));
        dateCell.setBorder(Rectangle.NO_BORDER);
        dateCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        headerTable.addCell(dateCell);

        document.add(headerTable);
    }

    // ======================== STRENGTH TABLE ========================

    private void renderStrengthTable(Document document, StrengthTableModel strengthTable) throws Exception {
        // 11 columns: # | HEADS | DCP | ACP | RPI | RSI | ARSI | AHC | APC | SUBTOTAL | GRAND TOTAL
        PdfPTable table = new PdfPTable(11);
        table.setWidthPercentage(100);
        table.setWidths(new float[]{3, 22, 6, 6, 6, 6, 7, 7, 8, 9, 9});
        table.setSpacingBefore(4f);

        // Header row — for rows 1-4 the last 2 cols merge into "TOTAL"
        table.addCell(styleHelper.createHeaderCell(""));
        table.addCell(styleHelper.createHeaderCell("HEADS"));
        for (String col : STRENGTH_DESIGNATION_COLS) {
            table.addCell(styleHelper.createVerticalHeaderCell(col));
        }
        // TOTAL header spans 2 columns
        PdfPCell totalHeader = new PdfPCell(new Phrase("TOTAL", styleHelper.getHeaderFont()));
        totalHeader.setColspan(2);
        totalHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
        totalHeader.setVerticalAlignment(Element.ALIGN_MIDDLE);
        totalHeader.setBackgroundColor(Form168StyleHelper.TABLE_HEADER_BG);
        totalHeader.setPadding(4);
        totalHeader.setBorderWidth(0.5f);
        table.addCell(totalHeader);

        // Data rows
        Map<String, Integer>[] rowData = getStrengthRowData(strengthTable);

        // Rows 1-4: total spans 2 columns (merged)
        for (int i = 0; i < 4; i++) {
            table.addCell(styleHelper.createDataCell(String.valueOf(i + 1), Element.ALIGN_CENTER));
            boolean isBold = (i == 2); // ACTUAL VACANCY
            if (isBold) {
                table.addCell(styleHelper.createTotalCell(STRENGTH_ROW_LABELS[i], Element.ALIGN_LEFT));
            } else {
                table.addCell(styleHelper.createDataCell(STRENGTH_ROW_LABELS[i], Element.ALIGN_LEFT));
            }
            int rowTotal = 0;
            for (String col : STRENGTH_DESIGNATION_COLS) {
                int val = rowData[i].getOrDefault(col, 0);
                // For ACTUAL VACANCY row (i == 2), only count positive values for total
                if (i == 2) {
                    rowTotal += (val > 0 ? val : 0);
                } else {
                    rowTotal += val;
                }
                if (isBold) {
                    table.addCell(styleHelper.createTotalCell(String.valueOf(val), Element.ALIGN_CENTER));
                } else {
                    table.addCell(styleHelper.createDataCell(String.valueOf(val), Element.ALIGN_CENTER));
                }
            }
            // Total spans 2 columns
            PdfPCell totalCell = new PdfPCell(new Phrase(String.valueOf(rowTotal),
                    isBold ? styleHelper.getSectionHeaderFont() : styleHelper.getDataFont()));
            totalCell.setColspan(2);
            totalCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            totalCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            totalCell.setPadding(3);
            totalCell.setBorderWidth(0.5f);
            table.addCell(totalCell);
        }

        // Row 5 (PRESENT STRENGTH COMPANY): subtotal in col 9, grand total rowspan in col 10
        int row5Total = 0;
        table.addCell(styleHelper.createDataCell("5", Element.ALIGN_CENTER));
        table.addCell(styleHelper.createDataCell(STRENGTH_ROW_LABELS[4], Element.ALIGN_LEFT));
        for (String col : STRENGTH_DESIGNATION_COLS) {
            int val = rowData[4].getOrDefault(col, 0);
            row5Total += val;
            table.addCell(styleHelper.createDataCell(String.valueOf(val), Element.ALIGN_CENTER));
        }
        table.addCell(styleHelper.createTotalCell(String.valueOf(row5Total), Element.ALIGN_CENTER));

        // Grand total (row 5 + row 6) spans 2 rows
        int row6Total = 0;
        for (String col : STRENGTH_DESIGNATION_COLS) {
            row6Total += rowData[5].getOrDefault(col, 0);
        }
        int grandTotal = row5Total + row6Total;
        PdfPCell grandTotalCell = new PdfPCell(new Phrase(
                String.valueOf(grandTotal), styleHelper.getSectionHeaderFont()));
        grandTotalCell.setRowspan(2);
        grandTotalCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        grandTotalCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        grandTotalCell.setPadding(3);
        grandTotalCell.setBorderWidth(0.5f);
        table.addCell(grandTotalCell);

        // Row 6 (RECRUIT APC'S)
        table.addCell(styleHelper.createDataCell("6", Element.ALIGN_CENTER));
        table.addCell(styleHelper.createDataCell(STRENGTH_ROW_LABELS[5], Element.ALIGN_LEFT));
        for (String col : STRENGTH_DESIGNATION_COLS) {
            int val = rowData[5].getOrDefault(col, 0);
            table.addCell(styleHelper.createDataCell(String.valueOf(val), Element.ALIGN_CENTER));
        }
        table.addCell(styleHelper.createTotalCell(String.valueOf(row6Total), Element.ALIGN_CENTER));
        // Grand total cell already spans from row 5

        document.add(table);
    }

    @SuppressWarnings("unchecked")
    private Map<String, Integer>[] getStrengthRowData(StrengthTableModel st) {
        return new Map[]{
                st.getSanctionedStrength(),
                st.getPresentStrengthTotal(),
                st.getActualVacancy(),
                st.getPresentStrengthPmt(),
                st.getPresentStrengthCompany(),
                st.getRecruitApcs()
        };
    }

    // ======================== SECTION COLUMN HEADERS ========================

    private void renderSectionColumnHeaders(Document document) throws Exception {
        PdfPTable table = new PdfPTable(10);
        table.setWidthPercentage(100);
        table.setWidths(SECTION_TABLE_WIDTHS);
        table.setSpacingBefore(4f);

        // HEADS is horizontal, designation columns (ACP-TOTAL) are VERTICAL (rotated 90°)
        table.addCell(styleHelper.createHeaderCell("HEADS"));
        for (int i = 1; i < SECTION_COLUMN_HEADERS.length; i++) {
            String header = SECTION_COLUMN_HEADERS[i];
            // PERSONNEL DETAILS stays horizontal since it's wide; others rotate
            if ("PERSONNEL DETAILS".equals(header)) {
                table.addCell(styleHelper.createHeaderCell(header));
            } else {
                table.addCell(styleHelper.createVerticalHeaderCell(header));
            }
        }

        document.add(table);
    }

    // ======================== SECTIONS A-G ========================

    private void renderAllSections(Document document, List<SectionModel> sections) throws Exception {
        for (SectionModel section : sections) {
            renderSection(document, section);
        }
    }

    private void renderSection(Document document, SectionModel section) throws Exception {
        PdfPTable table = new PdfPTable(10);
        table.setWidthPercentage(100);
        table.setWidths(SECTION_TABLE_WIDTHS);

        // Section header row
        table.addCell(styleHelper.createSectionHeaderCell(section.getSectionName(), 10));

        // Subsections
        for (SubsectionModel subsection : section.getSubsections()) {
            renderSubsection(table, subsection);
        }

        // Section grand total row
        renderTotalRow(table, "GRAND TOTAL", section.getGrandTotal());

        document.add(table);
    }

    private void renderSubsection(PdfPTable table, SubsectionModel subsection) {
        // Subsection header
        table.addCell(styleHelper.createSubsectionHeaderCell(subsection.getName(), 10));

        // Data rows
        for (DutyRowModel row : subsection.getRows()) {
            renderDutyRow(table, row);
        }

        // Subsection total row
        if (subsection.getTotal() != null) {
            renderTotalRow(table, "TOTAL", subsection.getTotal());
        }
    }

    private void renderDutyRow(PdfPTable table, DutyRowModel row) {
        // HEADS column: serial number prepended to description
        String headsText = row.getSerialNumber() + "  " + row.getDutyDescription();
        table.addCell(styleHelper.createDataCell(headsText, Element.ALIGN_LEFT));

        // Count columns: ACP, RPI, RSI, ARSI, AHC, APC, SWP (7 elements)
        int[] counts = row.getCounts();
        for (int i = 0; i < 7; i++) {
            String val = counts != null && i < counts.length ? String.valueOf(counts[i]) : "0";
            table.addCell(styleHelper.createDataCell(val, Element.ALIGN_CENTER));
        }

        // TOTAL column
        table.addCell(styleHelper.createDataCell(String.valueOf(row.getTotal()), Element.ALIGN_CENTER));

        // PERSONNEL DETAILS column (uses smaller font)
        String details = row.getPersonnelDetails() != null ? row.getPersonnelDetails() : "";
        PdfPCell detailsCell = new PdfPCell(new Phrase(details, styleHelper.getPersonnelDetailsFont()));
        detailsCell.setBorderWidth(Form168StyleHelper.BORDER_WIDTH);
        detailsCell.setBorderColor(Form168StyleHelper.BORDER_COLOR);
        detailsCell.setPadding(2f);
        detailsCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        detailsCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table.addCell(detailsCell);
    }

    private void renderTotalRow(PdfPTable table, String label, int[] totals) {
        // HEADS column with label — center aligned
        table.addCell(styleHelper.createTotalCell(label, Element.ALIGN_CENTER));

        // Count columns: ACP(0), RPI(1), RSI(2), ARSI(3), AHC(4), APC(5), SWP(6)
        for (int i = 0; i < 7; i++) {
            String val = totals != null && i < totals.length ? String.valueOf(totals[i]) : "0";
            table.addCell(styleHelper.createTotalCell(val, Element.ALIGN_CENTER));
        }

        // TOTAL column (index 7)
        String totalVal = totals != null && totals.length > 7 ? String.valueOf(totals[7]) : "0";
        table.addCell(styleHelper.createTotalCell(totalVal, Element.ALIGN_CENTER));

        // Empty personnel details column
        table.addCell(styleHelper.createTotalCell("", Element.ALIGN_LEFT));
    }

    // ======================== OFFICER'S DUTY SECTION ========================

    private void renderOfficerDutySection(Document document, OfficerDutyModel officerDuty) throws Exception {
        if (officerDuty == null) return;

        // === Part 1: Officer's Duty in SAME 10-column format as Sections A-G ===
        PdfPTable dutyTable = new PdfPTable(10);
        dutyTable.setWidthPercentage(100);
        dutyTable.setWidths(SECTION_TABLE_WIDTHS);
        dutyTable.setSpacingBefore(4f);

        // Section header "OFFICER'S DUTY" (olive/green, taller)
        dutyTable.addCell(styleHelper.createSectionHeaderCell("OFFICER'S DUTY", 10));

        // Render subsections: VIP ESCORTS/PILOT, OTHER DUTY'S, LEAVE
        if (officerDuty.getSubsections() != null) {
            for (SubsectionModel subsection : officerDuty.getSubsections()) {
                renderSubsection(dutyTable, subsection);
            }
        }

        // SUB TOTAL row
        renderTotalRow(dutyTable, "SUB TOTAL", officerDuty.getSubTotal());

        // GRAND TOTAL (COMPANY) row
        renderTotalRow(dutyTable, "GRAND TOTAL (COMPANY)", officerDuty.getGrandTotalCompany());

        document.add(dutyTable);

        // === "UNDER TRAINING/WITHOUT TRAINING" section ===
        PdfPTable trainingTable = new PdfPTable(10);
        trainingTable.setWidthPercentage(100);
        trainingTable.setWidths(SECTION_TABLE_WIDTHS);

        // Section header (olive/green, taller)
        trainingTable.addCell(styleHelper.createSectionHeaderCell("UNDER TRAINING/WITHOUT TRAINING", 10));

        // Under training subsections (BASIC TRAINING PTS DHARWAD, RECRUIT APC'S)
        if (officerDuty.getUnderTrainingSubsections() != null) {
            for (SubsectionModel subsection : officerDuty.getUnderTrainingSubsections()) {
                renderSubsection(trainingTable, subsection);
            }
        }

        // TOTAL row for under training
        renderTotalRow(trainingTable, "TOTAL", officerDuty.getUnderTrainingTotal());

        // Under training LEAVE subsection
        if (officerDuty.getUnderTrainingLeave() != null) {
            renderSubsection(trainingTable, officerDuty.getUnderTrainingLeave());
        }

        // P.M.T row
        renderTotalRow(trainingTable, "P.M.T", officerDuty.getPmtLine());

        // Final GRAND TOTAL row
        renderTotalRow(trainingTable, "GRAND TOTAL", officerDuty.getGrandTotal());

        document.add(trainingTable);

        // === Part 2: Separate 4-column S.NO | NAME | DESIGNATION | DUTY table ===
        PdfPTable nameTable = new PdfPTable(4);
        nameTable.setWidthPercentage(100);
        nameTable.setWidths(new float[]{8, 27, 18, 47});
        nameTable.setSpacingBefore(4f);

        // Section header
        nameTable.addCell(styleHelper.createSectionHeaderCell("OFFICER'S DUTY", 4));

        // Column headers
        nameTable.addCell(styleHelper.createHeaderCell("S.NO"));
        nameTable.addCell(styleHelper.createHeaderCell("NAME"));
        nameTable.addCell(styleHelper.createHeaderCell("DESIGNATION"));
        nameTable.addCell(styleHelper.createHeaderCell("DUTY"));

        // Officer rows
        if (officerDuty.getOfficers() != null) {
            int serialNumber = 1;
            for (OfficerRow officer : officerDuty.getOfficers()) {
                nameTable.addCell(styleHelper.createDataCell(
                        String.valueOf(serialNumber++), Element.ALIGN_CENTER));
                nameTable.addCell(styleHelper.createDataCell(
                        officer.getName() != null ? officer.getName() : "", Element.ALIGN_LEFT));
                nameTable.addCell(styleHelper.createDataCell(
                        officer.getDesignation() != null ? officer.getDesignation() : "", Element.ALIGN_CENTER));
                nameTable.addCell(styleHelper.createDataCell(
                        officer.getDuty() != null ? officer.getDuty() : "", Element.ALIGN_LEFT));
            }
        }

        document.add(nameTable);
    }

    // ======================== LEAVE STATEMENT SECTION ========================

    private void renderLeaveStatementSection(Document document, LeaveStatementModel leaveStatement) throws Exception {
        if (leaveStatement == null || leaveStatement.getGroups() == null) return;

        PdfPTable table = new PdfPTable(4);
        table.setWidthPercentage(100);
        table.setWidths(LEAVE_TABLE_WIDTHS);
        table.setSpacingBefore(4f);

        // Section header
        table.addCell(styleHelper.createSectionHeaderCell("LEAVE STATEMENT", 4));

        // Column headers
        table.addCell(styleHelper.createHeaderCell("SL"));
        table.addCell(styleHelper.createHeaderCell("BADGE/NAME"));
        table.addCell(styleHelper.createHeaderCell("TYPE"));
        table.addCell(styleHelper.createHeaderCell("DETAILS"));

        // Leave groups
        for (LeaveGroup group : leaveStatement.getGroups()) {
            // Type header row
            table.addCell(styleHelper.createSubsectionHeaderCell(group.getType(), 4));

            // Entries
            if (group.getEntries() != null) {
                for (LeaveEntry entry : group.getEntries()) {
                    table.addCell(styleHelper.createDataCell(
                            String.valueOf(entry.getSerialNumber()), Element.ALIGN_CENTER));
                    table.addCell(styleHelper.createDataCell(
                            entry.getBadgeOrName() != null ? entry.getBadgeOrName() : "", Element.ALIGN_LEFT));
                    table.addCell(styleHelper.createDataCell(
                            entry.getType() != null ? entry.getType() : "", Element.ALIGN_CENTER));
                    table.addCell(styleHelper.createDataCell(
                            entry.getDetails() != null ? entry.getDetails() : "", Element.ALIGN_LEFT));
                }
            }
        }

        document.add(table);
    }
}

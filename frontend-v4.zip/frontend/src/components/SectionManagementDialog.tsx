import React, { useEffect, useState, useCallback } from 'react';
import { observer } from 'mobx-react-lite';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  IconButton,
  Switch,
  FormControlLabel,
  Alert,
  Stack,
  Typography,
  Box,
  CircularProgress,
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import AddIcon from '@mui/icons-material/Add';
import { useTranslation } from 'react-i18next';
import { dutySectionApiService } from '@/services/dutySectionService';
import { dutySectionStore } from '@/stores/dutySectionStore';
import type { Section, SectionCreateRequest, SectionUpdateRequest } from '@/types/dutySections';

interface SectionManagementDialogProps {
  open: boolean;
  onClose: () => void;
}

interface SectionFormValues {
  code: string;
  name: string;
  description: string;
  sortOrder: string;
  isActive: boolean;
}

interface SectionFormErrors {
  code?: string;
  name?: string;
  description?: string;
  sortOrder?: string;
}

const emptySectionForm: SectionFormValues = {
  code: '',
  name: '',
  description: '',
  sortOrder: '0',
  isActive: true,
};

/**
 * Sorts sections by sort_order ASC, then code alphabetically ASC as tiebreaker.
 */
function sortSections(sections: Section[]): Section[] {
  return [...sections].sort((a, b) => {
    if (a.sortOrder !== b.sortOrder) return a.sortOrder - b.sortOrder;
    return a.code.localeCompare(b.code);
  });
}

const SectionManagementDialog: React.FC<SectionManagementDialogProps> = observer(
  ({ open, onClose }) => {
    const { t } = useTranslation();

    const [sections, setSections] = useState<Section[]>([]);
    const [loading, setLoading] = useState(false);
    const [loadError, setLoadError] = useState<string | null>(null);

    // Form state
    const [showForm, setShowForm] = useState(false);
    const [editingSection, setEditingSection] = useState<Section | null>(null);
    const [formValues, setFormValues] = useState<SectionFormValues>(emptySectionForm);
    const [formErrors, setFormErrors] = useState<SectionFormErrors>({});
    const [apiError, setApiError] = useState<string | null>(null);
    const [submitting, setSubmitting] = useState(false);

    // Deactivation confirmation state
    const [deactivateConfirm, setDeactivateConfirm] = useState<Section | null>(null);

    const fetchSections = useCallback(async () => {
      setLoading(true);
      setLoadError(null);
      try {
        const data = await dutySectionApiService.list();
        setSections(sortSections(data));
      } catch (err: unknown) {
        const message =
          err instanceof Error
            ? err.message
            : t('admin.dutySections.sectionManagement.errors.loadFailed', 'Failed to load sections');
        setLoadError(message);
      } finally {
        setLoading(false);
      }
    }, [t]);

    useEffect(() => {
      if (open) {
        fetchSections();
        resetForm();
      }
    }, [open, fetchSections]);

    const resetForm = () => {
      setShowForm(false);
      setEditingSection(null);
      setFormValues(emptySectionForm);
      setFormErrors({});
      setApiError(null);
    };

    const handleAddClick = () => {
      setEditingSection(null);
      setFormValues(emptySectionForm);
      setFormErrors({});
      setApiError(null);
      setShowForm(true);
    };

    const handleEditClick = (section: Section) => {
      setEditingSection(section);
      setFormValues({
        code: section.code,
        name: section.name,
        description: section.description || '',
        sortOrder: String(section.sortOrder),
        isActive: section.isActive,
      });
      setFormErrors({});
      setApiError(null);
      setShowForm(true);
    };

    const handleFormChange =
      (field: keyof SectionFormValues) =>
      (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setFormValues((prev) => ({ ...prev, [field]: e.target.value }));
        setFormErrors((prev) => ({ ...prev, [field]: undefined }));
      };

    const handleIsActiveToggle = (e: React.ChangeEvent<HTMLInputElement>) => {
      const newValue = e.target.checked;

      // If toggling to false and we're editing a section that might have personnel
      if (!newValue && editingSection && editingSection.isActive) {
        setDeactivateConfirm(editingSection);
        return;
      }

      setFormValues((prev) => ({ ...prev, isActive: newValue }));
    };

    const confirmDeactivation = () => {
      setFormValues((prev) => ({ ...prev, isActive: false }));
      setDeactivateConfirm(null);
    };

    const cancelDeactivation = () => {
      setDeactivateConfirm(null);
    };

    const validate = (): boolean => {
      const newErrors: SectionFormErrors = {};

      // Code: required, max 5, uppercase alphabetic only (only validate for new sections)
      if (!editingSection) {
        if (!formValues.code.trim()) {
          newErrors.code = t(
            'admin.dutySections.sectionManagement.errors.codeRequired',
            'Code is required'
          );
        } else if (formValues.code.trim().length > 5) {
          newErrors.code = t(
            'admin.dutySections.sectionManagement.errors.codeMaxLength',
            'Code must be 5 characters or less'
          );
        } else if (!/^[A-Z]+$/.test(formValues.code.trim())) {
          newErrors.code = t(
            'admin.dutySections.sectionManagement.errors.codeFormat',
            'Code must be uppercase alphabetic only'
          );
        }
      }

      // Name: required, max 100
      if (!formValues.name.trim()) {
        newErrors.name = t(
          'admin.dutySections.sectionManagement.errors.nameRequired',
          'Name is required'
        );
      } else if (formValues.name.trim().length > 100) {
        newErrors.name = t(
          'admin.dutySections.sectionManagement.errors.nameMaxLength',
          'Name must be 100 characters or less'
        );
      }

      // Description: optional, max 500
      if (formValues.description.length > 500) {
        newErrors.description = t(
          'admin.dutySections.sectionManagement.errors.descriptionMaxLength',
          'Description must be 500 characters or less'
        );
      }

      // Sort Order: required, 0-999
      const sortOrderNum = Number(formValues.sortOrder);
      if (formValues.sortOrder.trim() === '' || isNaN(sortOrderNum)) {
        newErrors.sortOrder = t(
          'admin.dutySections.sectionManagement.errors.sortOrderRequired',
          'Sort order is required'
        );
      } else if (sortOrderNum < 0 || sortOrderNum > 999 || !Number.isInteger(sortOrderNum)) {
        newErrors.sortOrder = t(
          'admin.dutySections.sectionManagement.errors.sortOrderRange',
          'Sort order must be between 0 and 999'
        );
      }

      setFormErrors(newErrors);
      return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async () => {
      if (!validate()) return;

      setSubmitting(true);
      setApiError(null);

      try {
        if (editingSection) {
          const request: SectionUpdateRequest = {
            name: formValues.name.trim(),
            description: formValues.description.trim() || null,
            sortOrder: Number(formValues.sortOrder),
            isActive: formValues.isActive,
          };
          await dutySectionApiService.update(editingSection.id, request);
        } else {
          const request: SectionCreateRequest = {
            code: formValues.code.trim(),
            name: formValues.name.trim(),
            description: formValues.description.trim() || null,
            sortOrder: Number(formValues.sortOrder),
            isActive: formValues.isActive,
          };
          await dutySectionApiService.create(request);
        }

        // Refresh sections in dialog
        await fetchSections();
        // Update the store tabs
        await dutySectionStore.fetchSections();
        resetForm();
      } catch (err: unknown) {
        if (isAxiosError(err) && err.response?.status === 409) {
          setApiError(
            t(
              'admin.dutySections.sectionManagement.errors.duplicateCode',
              'A section with this code already exists'
            )
          );
        } else {
          const message =
            err instanceof Error
              ? err.message
              : t(
                  'admin.dutySections.sectionManagement.errors.submitFailed',
                  'Failed to save section'
                );
          setApiError(message);
        }
      } finally {
        setSubmitting(false);
      }
    };

    const handleCancelForm = () => {
      resetForm();
    };

    const isEditMode = editingSection !== null;

    return (
      <>
        <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
          <DialogTitle>
            {t('admin.dutySections.sectionManagement.title', 'Section Management')}
          </DialogTitle>
          <DialogContent dividers>
            {/* Load Error State */}
            {loadError && (
              <Alert
                severity="error"
                action={
                  <Button color="inherit" size="small" onClick={fetchSections}>
                    {t('admin.dutySections.sectionManagement.retry', 'Retry')}
                  </Button>
                }
                sx={{ mb: 2 }}
              >
                {loadError}
              </Alert>
            )}

            {/* Loading State */}
            {loading && (
              <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
                <CircularProgress />
              </Box>
            )}

            {/* Sections Table */}
            {!loading && !loadError && (
              <>
                <Table size="small" aria-label={t('admin.dutySections.sectionManagement.tableLabel', 'Sections table')}>
                  <TableHead>
                    <TableRow>
                      <TableCell>{t('admin.dutySections.sectionManagement.columns.code', 'Code')}</TableCell>
                      <TableCell>{t('admin.dutySections.sectionManagement.columns.name', 'Name')}</TableCell>
                      <TableCell>{t('admin.dutySections.sectionManagement.columns.description', 'Description')}</TableCell>
                      <TableCell align="center">{t('admin.dutySections.sectionManagement.columns.sortOrder', 'Sort Order')}</TableCell>
                      <TableCell align="center">{t('admin.dutySections.sectionManagement.columns.dutyTypeCount', 'Duty Types')}</TableCell>
                      <TableCell align="center">{t('admin.dutySections.sectionManagement.columns.active', 'Active')}</TableCell>
                      <TableCell align="center">{t('admin.dutySections.sectionManagement.columns.actions', 'Actions')}</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {sections.map((section) => (
                      <TableRow
                        key={section.id}
                        sx={{
                          opacity: section.isActive ? 1 : 0.5,
                          fontStyle: section.isActive ? 'normal' : 'italic',
                          '& td': {
                            fontStyle: section.isActive ? 'normal' : 'italic',
                          },
                        }}
                      >
                        <TableCell>{section.code}</TableCell>
                        <TableCell>{section.name}</TableCell>
                        <TableCell>
                          <Typography variant="body2" noWrap sx={{ maxWidth: 200 }}>
                            {section.description || '—'}
                          </Typography>
                        </TableCell>
                        <TableCell align="center">{section.sortOrder}</TableCell>
                        <TableCell align="center">{section.dutyTypeCount ?? 0}</TableCell>
                        <TableCell align="center">
                          <Typography
                            variant="body2"
                            color={section.isActive ? 'success.main' : 'text.disabled'}
                          >
                            {section.isActive
                              ? t('admin.dutySections.sectionManagement.activeYes', 'Yes')
                              : t('admin.dutySections.sectionManagement.activeNo', 'No')}
                          </Typography>
                        </TableCell>
                        <TableCell align="center">
                          <IconButton
                            size="small"
                            onClick={() => handleEditClick(section)}
                            aria-label={t('admin.dutySections.sectionManagement.editSection', 'Edit section')}
                          >
                            <EditIcon fontSize="small" />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    ))}
                    {sections.length === 0 && !loading && (
                      <TableRow>
                        <TableCell colSpan={7} align="center">
                          <Typography variant="body2" color="text.secondary" sx={{ py: 2 }}>
                            {t('admin.dutySections.sectionManagement.noSections', 'No sections found')}
                          </Typography>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>

                {/* Add Section Button */}
                {!showForm && (
                  <Box sx={{ mt: 2 }}>
                    <Button
                      startIcon={<AddIcon />}
                      variant="outlined"
                      size="small"
                      onClick={handleAddClick}
                    >
                      {t('admin.dutySections.sectionManagement.addSection', 'Add Section')}
                    </Button>
                  </Box>
                )}

                {/* Inline Form for Add/Edit */}
                {showForm && (
                  <Box sx={{ mt: 2, p: 2, border: 1, borderColor: 'divider', borderRadius: 1 }}>
                    <Typography variant="subtitle2" gutterBottom>
                      {isEditMode
                        ? t('admin.dutySections.sectionManagement.editTitle', 'Edit Section')
                        : t('admin.dutySections.sectionManagement.addTitle', 'Add New Section')}
                    </Typography>

                    {apiError && (
                      <Alert severity="error" onClose={() => setApiError(null)} sx={{ mb: 2 }}>
                        {apiError}
                      </Alert>
                    )}

                    <Stack spacing={2}>
                      {/* Code */}
                      <TextField
                        label={t('admin.dutySections.sectionManagement.form.code', 'Code')}
                        value={formValues.code}
                        onChange={handleFormChange('code')}
                        required
                        disabled={isEditMode}
                        error={!!formErrors.code}
                        helperText={
                          formErrors.code ||
                          t(
                            'admin.dutySections.sectionManagement.form.codeHint',
                            'Max 5 chars, uppercase letters only'
                          )
                        }
                        fullWidth
                        size="small"
                        inputProps={{ maxLength: 5, style: { textTransform: 'uppercase' } }}
                      />

                      {/* Name */}
                      <TextField
                        label={t('admin.dutySections.sectionManagement.form.name', 'Name')}
                        value={formValues.name}
                        onChange={handleFormChange('name')}
                        required
                        error={!!formErrors.name}
                        helperText={formErrors.name}
                        fullWidth
                        size="small"
                        inputProps={{ maxLength: 100 }}
                      />

                      {/* Description */}
                      <TextField
                        label={t('admin.dutySections.sectionManagement.form.description', 'Description')}
                        value={formValues.description}
                        onChange={handleFormChange('description')}
                        error={!!formErrors.description}
                        helperText={formErrors.description}
                        fullWidth
                        size="small"
                        multiline
                        minRows={2}
                        inputProps={{ maxLength: 500 }}
                      />

                      {/* Sort Order */}
                      <TextField
                        label={t('admin.dutySections.sectionManagement.form.sortOrder', 'Sort Order')}
                        value={formValues.sortOrder}
                        onChange={handleFormChange('sortOrder')}
                        required
                        error={!!formErrors.sortOrder}
                        helperText={
                          formErrors.sortOrder ||
                          t('admin.dutySections.sectionManagement.form.sortOrderHint', '0 to 999')
                        }
                        fullWidth
                        size="small"
                        type="number"
                        inputProps={{ min: 0, max: 999 }}
                      />

                      {/* Is Active Toggle */}
                      <FormControlLabel
                        control={
                          <Switch
                            checked={formValues.isActive}
                            onChange={handleIsActiveToggle}
                          />
                        }
                        label={t('admin.dutySections.sectionManagement.form.isActive', 'Active')}
                      />

                      {/* Form Actions */}
                      <Stack direction="row" spacing={1} justifyContent="flex-end">
                        <Button onClick={handleCancelForm} disabled={submitting} size="small">
                          {t('admin.dutySections.sectionManagement.form.cancel', 'Cancel')}
                        </Button>
                        <Button
                          variant="contained"
                          onClick={handleSubmit}
                          disabled={submitting}
                          size="small"
                        >
                          {submitting
                            ? t('admin.dutySections.sectionManagement.form.saving', 'Saving...')
                            : isEditMode
                              ? t('admin.dutySections.sectionManagement.form.update', 'Update')
                              : t('admin.dutySections.sectionManagement.form.create', 'Create')}
                        </Button>
                      </Stack>
                    </Stack>
                  </Box>
                )}
              </>
            )}
          </DialogContent>
          <DialogActions sx={{ px: 3, pb: 2 }}>
            <Button onClick={onClose}>
              {t('admin.dutySections.sectionManagement.close', 'Close')}
            </Button>
          </DialogActions>
        </Dialog>

        {/* Deactivation Confirmation Dialog */}
        <Dialog
          open={deactivateConfirm !== null}
          onClose={cancelDeactivation}
          maxWidth="xs"
          fullWidth
        >
          <DialogTitle>
            {t('admin.dutySections.sectionManagement.deactivateConfirm.title', 'Confirm Deactivation')}
          </DialogTitle>
          <DialogContent>
            <Typography>
              {t(
                'admin.dutySections.sectionManagement.deactivateConfirm.message',
                'Deactivating this section may affect personnel and duty assignments associated with it. Are you sure you want to proceed?'
              )}
            </Typography>
          </DialogContent>
          <DialogActions>
            <Button onClick={cancelDeactivation}>
              {t('admin.dutySections.sectionManagement.deactivateConfirm.cancel', 'Cancel')}
            </Button>
            <Button variant="contained" color="warning" onClick={confirmDeactivation}>
              {t('admin.dutySections.sectionManagement.deactivateConfirm.confirm', 'Deactivate')}
            </Button>
          </DialogActions>
        </Dialog>
      </>
    );
  }
);

/**
 * Type guard for Axios errors with response data.
 */
function isAxiosError(
  err: unknown
): err is { response?: { status: number; data?: { error?: string } } } {
  return typeof err === 'object' && err !== null && 'response' in err;
}

export default SectionManagementDialog;

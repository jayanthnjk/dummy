package com.policescheduler.service;

import com.policescheduler.entity.ReportEmailConfig;
import com.policescheduler.entity.ReportHistory;
import com.policescheduler.entity.ReportSpecificEmailConfig;
import com.policescheduler.report.PdfReportGenerator;
import com.policescheduler.report.ReportRequest;
import com.policescheduler.report.S3ReportStorageService;
import com.policescheduler.repository.ReportEmailConfigRepository;
import com.policescheduler.repository.ReportHistoryRepository;
import com.policescheduler.repository.ReportSpecificEmailConfigRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Service responsible for scheduled report generation and email delivery.
 * 
 * This service:
 * 1. Runs every 5 minutes to check for scheduled reports
 * 2. Queries the database for reports that are due based on schedule_days and schedule_time
 * 3. Generates the PDF report using existing report generators
 * 4. Stores the report in S3 under dailyReports/{reportFolder}/{date}/
 * 5. Sends email with PDF attachment to all configured recipients
 * 
 * All configuration is pulled from the database:
 * - report_specific_email_config: Contains schedule (days, time) and email content
 * - report_email_config: Contains recipient email addresses for each report type
 */
@Service
public class ScheduledReportService {

    private static final Logger log = LoggerFactory.getLogger(ScheduledReportService.class);
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm");
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    private final ReportSpecificEmailConfigRepository reportSpecificEmailConfigRepository;
    private final ReportEmailConfigRepository reportEmailConfigRepository;
    private final ReportHistoryRepository reportHistoryRepository;
    private final Map<String, PdfReportGenerator> generatorsByType;
    private final S3ReportStorageService s3ReportStorageService;
    private final EmailNotificationService emailNotificationService;

    // Mapping of Java DayOfWeek to our schedule day codes
    private static final Map<DayOfWeek, String> DAY_OF_WEEK_MAP = Map.of(
            DayOfWeek.SUNDAY, "SUN",
            DayOfWeek.MONDAY, "MON",
            DayOfWeek.TUESDAY, "TUE",
            DayOfWeek.WEDNESDAY, "WED",
            DayOfWeek.THURSDAY, "THU",
            DayOfWeek.FRIDAY, "FRI",
            DayOfWeek.SATURDAY, "SAT"
    );

    public ScheduledReportService(
            ReportSpecificEmailConfigRepository reportSpecificEmailConfigRepository,
            ReportEmailConfigRepository reportEmailConfigRepository,
            ReportHistoryRepository reportHistoryRepository,
            List<PdfReportGenerator> generators,
            S3ReportStorageService s3ReportStorageService,
            EmailNotificationService emailNotificationService) {
        this.reportSpecificEmailConfigRepository = reportSpecificEmailConfigRepository;
        this.reportEmailConfigRepository = reportEmailConfigRepository;
        this.reportHistoryRepository = reportHistoryRepository;
        this.s3ReportStorageService = s3ReportStorageService;
        this.emailNotificationService = emailNotificationService;

        // Build map of report generators by type
        this.generatorsByType = new HashMap<>();
        for (PdfReportGenerator generator : generators) {
            this.generatorsByType.put(generator.getReportType(), generator);
        }
        log.info("ScheduledReportService initialized with {} report generators", generatorsByType.size());
    }

    /**
     * Scheduled task that runs every 5 minutes to check for and process scheduled reports.
     * 
     * Cron: "0 *​/5 * * * ?" means:
     * - 0 seconds
     * - Every 5 minutes (0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55)
     * - Every hour
     * - Every day
     */
    @Scheduled(cron = "0 */5 * * * ?")
    public void checkAndProcessScheduledReports() {
        LocalTime now = LocalTime.now();
        LocalDate today = LocalDate.now();
        
        // Round down to nearest 5-minute interval for matching
        int minute = (now.getMinute() / 5) * 5;
        String currentTime = String.format("%02d:%02d", now.getHour(), minute);
        String currentDay = DAY_OF_WEEK_MAP.get(today.getDayOfWeek());

        log.debug("Checking for scheduled reports at {} on {}", currentTime, currentDay);

        // Find all reports that are scheduled for this time and day
        List<ReportSpecificEmailConfig> dueReports = reportSpecificEmailConfigRepository
                .findScheduledReportsDue(currentTime, currentDay);

        if (dueReports.isEmpty()) {
            log.debug("No scheduled reports due at {} on {}", currentTime, currentDay);
            return;
        }

        log.info("Found {} scheduled reports due at {} on {}", dueReports.size(), currentTime, currentDay);

        for (ReportSpecificEmailConfig config : dueReports) {
            try {
                processScheduledReport(config, today);
            } catch (Exception e) {
                log.error("Failed to process scheduled report for {}: {}", config.getReportType(), e.getMessage(), e);
            }
        }
    }

    /**
     * Process a single scheduled report:
     * 1. Generate PDF
     * 2. Store in S3
     * 3. Find recipients
     * 4. Send email with attachment
     */
    private void processScheduledReport(ReportSpecificEmailConfig config, LocalDate reportDate) {
        String reportType = config.getReportType();
        log.info("Processing scheduled report: {} ({})", config.getReportName(), reportType);

        // Step 1: Generate PDF report
        byte[] pdfData = generateReport(reportType, reportDate);
        if (pdfData == null || pdfData.length == 0) {
            log.error("Failed to generate PDF for report type: {}", reportType);
            return;
        }

        // Step 2: Build filename
        String filename = buildFilename(reportType, config.getReportName(), reportDate);

        // Step 3: Store in S3
        String s3Key = null;
        try {
            s3Key = s3ReportStorageService.uploadScheduledReport(reportType, filename, pdfData, "application/pdf");
            log.info("Stored scheduled report in S3: {}", s3Key);

            // Save to report history
            saveReportHistory(filename, reportType, s3Key, pdfData.length);
        } catch (Exception e) {
            log.error("Failed to store report in S3: {}", e.getMessage());
            // Continue to send email even if S3 storage fails
        }

        // Step 4: Find all recipients for this report type
        List<String> recipients = findRecipientsForReportType(reportType);
        if (recipients.isEmpty()) {
            log.warn("No recipients configured for report type: {}. Skipping email.", reportType);
            return;
        }

        // Step 5: Send email with attachment
        String emailSubject = config.getEmailSubject();
        String emailBody = config.getEmailBody();

        // Replace date placeholders in body if present
        String dateStr = reportDate.format(DATE_FMT);
        emailBody = emailBody.replace("{date}", dateStr)
                           .replace("{DATE}", dateStr);

        boolean emailSent = emailNotificationService.sendScheduledReportEmail(
                recipients, emailSubject, emailBody, pdfData, filename);

        if (emailSent) {
            log.info("Successfully sent scheduled report {} to {} recipients", 
                    config.getReportName(), recipients.size());
        } else {
            log.error("Failed to send scheduled report email for {}", config.getReportName());
        }
    }

    /**
     * Generate PDF report using the appropriate generator.
     */
    private byte[] generateReport(String reportType, LocalDate reportDate) {
        PdfReportGenerator generator = generatorsByType.get(reportType);
        if (generator == null) {
            log.error("No PDF generator found for report type: {}", reportType);
            return null;
        }

        try {
            ReportRequest.ReportRequestBuilder requestBuilder = ReportRequest.builder()
                    .reportType(reportType)
                    .date(reportDate)
                    .locale("en");

            // Handle special cases for different report types
            switch (reportType) {
                case "section_ab":
                    requestBuilder.combined(true);
                    break;
                case "platoon_chart":
                    // No special handling needed
                    break;
                case "form_168":
                    // Date is already set
                    break;
                case "mt_section":
                case "personnel_list":
                case "leave_statement":
                    // No special handling needed
                    break;
                default:
                    log.warn("Unknown report type: {}, using default settings", reportType);
            }

            ReportRequest request = requestBuilder.build();
            return generator.generate(request);
        } catch (Exception e) {
            log.error("Error generating report {}: {}", reportType, e.getMessage(), e);
            return null;
        }
    }

    /**
     * Build filename for the scheduled report.
     * Format varies by report type but follows pattern: ReportName_dd-MM-yyyy.pdf
     */
    private String buildFilename(String reportType, String reportName, LocalDate reportDate) {
        String dateStr = reportDate.format(DATE_FMT);
        String safeName = reportName.replaceAll("[^a-zA-Z0-9\\s]", "").replaceAll("\\s+", "_");
        
        return switch (reportType) {
            case "form_168" -> "Statement_Form168_" + dateStr + ".pdf";
            case "platoon_chart" -> "PlatoonChartC_" + dateStr + ".pdf";
            case "section_ab" -> "PlatoonChartAB_" + dateStr + ".pdf";
            case "mt_section" -> "MT_Section_" + dateStr + ".pdf";
            case "leave_statement" -> "Leave_Statement_" + dateStr + ".pdf";
            case "personnel_list" -> "Personnel_List_" + dateStr + ".pdf";
            default -> safeName + "_" + dateStr + ".pdf";
        };
    }

    /**
     * Find all email recipients for a specific report type.
     * Queries report_email_config table for active configs that include this report type.
     */
    private List<String> findRecipientsForReportType(String reportType) {
        List<ReportEmailConfig> configs = reportEmailConfigRepository.findActiveConfigsWithReportType(reportType);
        
        Set<String> uniqueRecipients = new HashSet<>();
        for (ReportEmailConfig config : configs) {
            if (config.getEmailIds() != null && !config.getEmailIds().trim().isEmpty()) {
                String[] emails = config.getEmailIds().split(",");
                for (String email : emails) {
                    String trimmed = email.trim();
                    if (!trimmed.isEmpty()) {
                        uniqueRecipients.add(trimmed);
                    }
                }
            }
        }

        return new ArrayList<>(uniqueRecipients);
    }

    /**
     * Save report generation to history.
     */
    private void saveReportHistory(String filename, String reportType, String s3Key, int fileSize) {
        try {
            ReportHistory history = new ReportHistory();
            history.setReportName(filename);
            history.setReportType(reportType);
            history.setS3Key(s3Key);
            history.setFileSize((long) fileSize);
            history.setContentType("application/pdf");
            reportHistoryRepository.save(history);
        } catch (Exception e) {
            log.warn("Failed to save report history: {}", e.getMessage());
        }
    }

    /**
     * Manual trigger for testing - can be called via API endpoint.
     * Processes all scheduled reports regardless of schedule.
     */
    public void triggerAllScheduledReports() {
        log.info("Manual trigger: Processing all enabled scheduled reports");
        List<ReportSpecificEmailConfig> enabledReports = reportSpecificEmailConfigRepository.findByIsScheduleEnabledTrue();
        
        LocalDate today = LocalDate.now();
        for (ReportSpecificEmailConfig config : enabledReports) {
            try {
                processScheduledReport(config, today);
            } catch (Exception e) {
                log.error("Failed to process report {}: {}", config.getReportType(), e.getMessage());
            }
        }
    }

    /**
     * Trigger a specific report by type - for manual testing.
     */
    public void triggerReportByType(String reportType) {
        log.info("Manual trigger: Processing report type {}", reportType);
        reportSpecificEmailConfigRepository.findByReportType(reportType)
                .ifPresent(config -> processScheduledReport(config, LocalDate.now()));
    }
}

import { TeamMemberSchedule } from '../types/schedule';

/**
 * Filters team members by group.
 * Returns the full list when group is "all", otherwise returns only
 * members whose group field matches the selected group (case-sensitive).
 */
export function filterByGroup(
  members: TeamMemberSchedule[],
  group: string
): TeamMemberSchedule[] {
  if (group === 'all') {
    return members;
  }
  return members.filter((entry) => entry.member.group === group);
}

/**
 * Filters team members by a search query.
 * Returns the full list when query is empty. Otherwise filters to only
 * members where at least one of name, badgeId, or email contains the
 * query as a case-insensitive substring.
 */
export function filterBySearch(
  members: TeamMemberSchedule[],
  query: string
): TeamMemberSchedule[] {
  if (query === '') {
    return members;
  }
  const lowerQuery = query.toLowerCase();
  return members.filter((entry) => {
    const { name, badgeId, email } = entry.member;
    return (
      name.toLowerCase().includes(lowerQuery) ||
      badgeId.toLowerCase().includes(lowerQuery) ||
      email.toLowerCase().includes(lowerQuery)
    );
  });
}

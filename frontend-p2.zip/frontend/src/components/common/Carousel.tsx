import React, { useRef, useState, useEffect, useCallback } from 'react';
import { Box, IconButton, useMediaQuery } from '@mui/material';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';

/**
 * Props for the Carousel component
 */
export interface CarouselProps {
  /** Content items to display inside the carousel */
  children: React.ReactNode;
  /** Accessible label for the carousel region */
  ariaLabel: string;
}

/**
 * Pure function to determine arrow disabled states based on scroll position.
 *
 * @param scrollLeft - Current scroll position from the left
 * @param scrollWidth - Total scrollable width of the content
 * @param clientWidth - Visible width of the container
 * @returns Object with leftDisabled and rightDisabled booleans
 *
 * Validates: Requirements 6.3, 6.4
 */
export function getArrowStates(
  scrollLeft: number,
  scrollWidth: number,
  clientWidth: number
): { leftDisabled: boolean; rightDisabled: boolean } {
  return {
    leftDisabled: scrollLeft <= 0,
    rightDisabled: scrollLeft >= scrollWidth - clientWidth,
  };
}

/**
 * Carousel — A horizontally scrollable container with arrow navigation.
 *
 * Features:
 * - Horizontal scroll with left/right arrow buttons at vertical center
 * - Smooth-scroll one card width on click (300ms ease-out)
 * - Disable arrows at scroll boundaries (0.4 opacity)
 * - Gradient fade overlays (24px) on edges with overflow
 * - Hide arrows if fewer than 2 items
 * - Touch swipe below 768px (arrows hidden)
 * - Keyboard left/right arrow support when container focused
 * - Responsive card count: 3 (>1200px), 2 (900-1200px), 1 (<900px)
 * - Debounce rapid clicks (100ms threshold)
 * - role="region" with aria-label prop
 * - Arrow buttons with aria-label="Previous items" / "Next items"
 *
 * Validates: Requirements 6.1–6.5, 6.6, 6.8, 6.9, 12.5, 13.5
 */
const Carousel: React.FC<CarouselProps> = ({ children, ariaLabel }) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const lastScrollTimeRef = useRef<number>(0);
  const [arrowStates, setArrowStates] = useState({
    leftDisabled: true,
    rightDisabled: false,
  });
  const [hasOverflowLeft, setHasOverflowLeft] = useState(false);
  const [hasOverflowRight, setHasOverflowRight] = useState(false);

  // Responsive: hide arrows below 768px (touch swipe mode)
  const isMobile = useMediaQuery('(max-width:767px)');

  // Count the number of children
  const childCount = React.Children.count(children);
  const showControls = childCount >= 2 && !isMobile;

  /**
   * Update arrow states and overflow indicators based on current scroll position.
   */
  const updateScrollState = useCallback(() => {
    const container = scrollContainerRef.current;
    if (!container) return;

    const { scrollLeft, scrollWidth, clientWidth } = container;
    const states = getArrowStates(scrollLeft, scrollWidth, clientWidth);

    setArrowStates(states);
    setHasOverflowLeft(scrollLeft > 0);
    setHasOverflowRight(scrollLeft < scrollWidth - clientWidth);
  }, []);

  useEffect(() => {
    const container = scrollContainerRef.current;
    if (!container) return;

    // Initial state check
    updateScrollState();

    container.addEventListener('scroll', updateScrollState);

    // Also update on resize to handle dynamic content changes
    const resizeObserver = new ResizeObserver(() => {
      updateScrollState();
    });
    resizeObserver.observe(container);

    return () => {
      container.removeEventListener('scroll', updateScrollState);
      resizeObserver.disconnect();
    };
  }, [updateScrollState, childCount]);

  /**
   * Scroll by one card width in the specified direction.
   * Uses the first child's offsetWidth as the card width reference.
   * Debounces rapid clicks with a 100ms threshold.
   */
  const handleScroll = useCallback((direction: 'left' | 'right') => {
    const now = Date.now();
    if (now - lastScrollTimeRef.current < 100) return; // Debounce rapid clicks
    lastScrollTimeRef.current = now;

    const container = scrollContainerRef.current;
    if (!container) return;

    // Use first child's width as reference for scroll amount
    const firstChild = container.firstElementChild as HTMLElement | null;
    const scrollAmount = firstChild ? firstChild.offsetWidth : 300;

    container.scrollBy({
      left: direction === 'left' ? -scrollAmount : scrollAmount,
      behavior: 'smooth',
    });
  }, []);

  /**
   * Keyboard navigation handler: scroll left/right on ArrowLeft/ArrowRight key press.
   * Validates: Requirement 6.9
   */
  const handleKeyDown = useCallback((event: React.KeyboardEvent<HTMLDivElement>) => {
    if (event.key === 'ArrowLeft') {
      event.preventDefault();
      handleScroll('left');
    } else if (event.key === 'ArrowRight') {
      event.preventDefault();
      handleScroll('right');
    }
  }, [handleScroll]);

  return (
    <Box
      role="region"
      aria-label={ariaLabel}
      sx={{ position: 'relative' }}
    >
      {/* Scroll container with keyboard navigation support */}
      <Box
        ref={scrollContainerRef}
        tabIndex={0}
        onKeyDown={handleKeyDown}
        sx={{
          display: 'flex',
          overflowX: 'auto',
          scrollBehavior: 'smooth',
          gap: 2,
          py: 1,
          px: showControls ? 1 : 0,
          /* Hide scrollbar across browsers */
          scrollbarWidth: 'none',
          '&::-webkit-scrollbar': {
            display: 'none',
          },
          /* Smooth scroll timing */
          scrollSnapType: 'x proximity',
          /* Focus outline for keyboard navigation */
          '&:focus': {
            outline: '2px solid',
            outlineColor: 'primary.main',
            outlineOffset: '2px',
            borderRadius: 1,
          },
          '&:focus:not(:focus-visible)': {
            outline: 'none',
          },
          /*
           * Responsive card count guidance:
           * Children should use flex: '0 0 auto' and set their width responsively.
           * Recommended child widths:
           *   - >1200px: ~calc((100% - 32px) / 3) for 3 visible cards
           *   - 900-1200px: ~calc((100% - 16px) / 2) for 2 visible cards
           *   - <900px: 100% for 1 visible card
           * The carousel container ensures children don't shrink with the flex display.
           */
        }}
      >
        {children}
      </Box>

      {/* Left gradient fade overlay */}
      {showControls && hasOverflowLeft && (
        <Box
          aria-hidden="true"
          sx={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '24px',
            height: '100%',
            background: 'linear-gradient(to right, white, transparent)',
            pointerEvents: 'none',
            zIndex: 1,
          }}
        />
      )}

      {/* Right gradient fade overlay */}
      {showControls && hasOverflowRight && (
        <Box
          aria-hidden="true"
          sx={{
            position: 'absolute',
            top: 0,
            right: 0,
            width: '24px',
            height: '100%',
            background: 'linear-gradient(to left, white, transparent)',
            pointerEvents: 'none',
            zIndex: 1,
          }}
        />
      )}

      {/* Left arrow button — hidden on mobile (<768px) */}
      {showControls && (
        <IconButton
          aria-label="Previous items"
          disabled={arrowStates.leftDisabled}
          onClick={() => handleScroll('left')}
          sx={{
            position: 'absolute',
            left: -20,
            top: '50%',
            transform: 'translateY(-50%)',
            zIndex: 2,
            bgcolor: 'background.paper',
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
            opacity: arrowStates.leftDisabled ? 0.4 : 1,
            transition: 'opacity 300ms ease-out',
            '&:hover': {
              bgcolor: 'background.paper',
            },
            '&.Mui-disabled': {
              opacity: 0.4,
            },
          }}
        >
          <ChevronLeftIcon />
        </IconButton>
      )}

      {/* Right arrow button — hidden on mobile (<768px) */}
      {showControls && (
        <IconButton
          aria-label="Next items"
          disabled={arrowStates.rightDisabled}
          onClick={() => handleScroll('right')}
          sx={{
            position: 'absolute',
            right: -20,
            top: '50%',
            transform: 'translateY(-50%)',
            zIndex: 2,
            bgcolor: 'background.paper',
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
            opacity: arrowStates.rightDisabled ? 0.4 : 1,
            transition: 'opacity 300ms ease-out',
            '&:hover': {
              bgcolor: 'background.paper',
            },
            '&.Mui-disabled': {
              opacity: 0.4,
            },
          }}
        >
          <ChevronRightIcon />
        </IconButton>
      )}
    </Box>
  );
};

export default Carousel;

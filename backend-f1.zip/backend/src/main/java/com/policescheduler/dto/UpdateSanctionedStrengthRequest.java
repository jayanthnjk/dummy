package com.policescheduler.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateSanctionedStrengthRequest {
    @NotBlank(message = "Designation is required")
    private String designation;
    
    @NotNull(message = "Sanctioned count is required")
    @Min(value = 0, message = "Sanctioned count must be non-negative")
    private Integer sanctionedCount;
}

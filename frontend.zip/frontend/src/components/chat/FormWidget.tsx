import React, { useState, useMemo } from 'react';
import {
  TextField, Select, MenuItem, FormControl, InputLabel,
  Button, Typography, Box, FormHelperText, Chip, Switch, FormControlLabel,
  Stack, Table, TableHead, TableBody, TableRow, TableCell, TableContainer, Paper,
} from '@mui/material';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { TimePicker } from '@mui/x-date-pickers/TimePicker';
import dayjs from 'dayjs';
import PersonAddAltIcon from '@mui/icons-material/PersonAddAlt';
import BadgeOutlinedIcon from '@mui/icons-material/BadgeOutlined';
import WorkOutlineIcon from '@mui/icons-material/WorkOutline';
import LocationOnOutlinedIcon from '@mui/icons-material/LocationOnOutlined';
import PhoneOutlinedIcon from '@mui/icons-material/PhoneOutlined';
import EmailOutlinedIcon from '@mui/icons-material/EmailOutlined';
import AccountTreeOutlinedIcon from '@mui/icons-material/AccountTreeOutlined';
import AssignmentIndOutlinedIcon from '@mui/icons-material/AssignmentIndOutlined';
import DirectionsCarIcon from '@mui/icons-material/DirectionsCar';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import CakeIcon from '@mui/icons-material/Cake';
import BloodtypeIcon from '@mui/icons-material/Bloodtype';
import SchoolIcon from '@mui/icons-material/School';
import HomeIcon from '@mui/icons-material/Home';
import LocalPoliceIcon from '@mui/icons-material/LocalPolice';
import EventIcon from '@mui/icons-material/Event';
import BusinessIcon from '@mui/icons-material/Business';
import type { FormResponseData } from '@/types';

interface FormWidgetProps extends FormResponseData {
  onSubmit: (formId: string, submitAction: string, fields: Record<string, string>) => Promise<boolean>;
}

const FIELD_ICONS: Record<string, React.ReactNode> = {
  personName: <PersonAddAltIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  badgeId: <BadgeOutlinedIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  designation: <AssignmentIndOutlinedIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  section: <AccountTreeOutlinedIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  dutyType: <WorkOutlineIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  location: <LocationOnOutlinedIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  phoneNumber: <PhoneOutlinedIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  email: <EmailOutlinedIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  vehicleNumber: <DirectionsCarIcon sx={{ fontSize: 17, color: '#92400e' }} />,
  pdms: <BadgeOutlinedIcon sx={{ fontSize: 17, color: '#92400e' }} />,
  licenceType: <AssignmentIndOutlinedIcon sx={{ fontSize: 17, color: '#92400e' }} />,
  deployedFrom: <LocationOnOutlinedIcon sx={{ fontSize: 17, color: '#92400e' }} />,
  // Time fields
  start_time: <AccessTimeIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  end_time: <AccessTimeIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  // Date fields
  date: <CalendarTodayIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  dateOfBirth: <CakeIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  dateOfJoining: <EventIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  // Personal details
  bloodGroup: <BloodtypeIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  qualification: <SchoolIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  permanentAddress: <HomeIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  presentAddress: <HomeIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  nativePoliceStation: <LocalPoliceIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
  unit: <BusinessIcon sx={{ fontSize: 17, color: '#6366f1' }} />,
};

const PLACEHOLDERS: Record<string, string> = {
  personName: 'Enter full name',
  badgeId: 'e.g. DCP-01',
  location: 'e.g. Bangalore',
  phoneNumber: 'e.g. 9876543210',
  email: 'e.g. name@example.com',
  vehicleNumber: 'e.g. KA-01-AB-1234',
  pdms: 'PDMS number',
  licenceType: 'e.g. LMV, HMV',
  deployedFrom: 'e.g. District Reserve',
  qualification: 'e.g. B.Com, Graduate',
  permanentAddress: 'Enter permanent address',
  presentAddress: 'Enter present address',
  nativePoliceStation: 'e.g. Koramangala PS',
  duty_name: 'e.g. VIP Security, Stadium Duty',
};

const DRIVER_FIELDS = ['vehicleNumber', 'pdms', 'licenceType', 'deployedFrom'];
const PERSONAL_FIELDS = ['dateOfBirth', 'bloodGroup', 'qualification', 'permanentAddress', 'presentAddress', 'nativePoliceStation'];
const CONTACT_FIELDS = ['phoneNumber', 'email', 'dateOfJoining'];

// Designation list for designation-counts field type
const DESIGNATIONS_LIST = ['RPI', 'RSI', 'ARSI', 'AHC', 'APC'];

const inputSx = (disabled: boolean) => ({
  '& .MuiOutlinedInput-root': {
    borderRadius: 2,
    bgcolor: disabled ? '#f8fafc' : '#fff',
    fontSize: '0.82rem',
    '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: '#6366f1' },
    '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#6366f1', borderWidth: 2 },
  },
  '& .MuiInputLabel-root': { fontSize: '0.82rem' },
});

const FormWidget: React.FC<FormWidgetProps> = ({ formId, title, fields, submitAction, submitLabel, onSubmit }) => {
  const [values, setValues] = useState<Record<string, string>>(() => {
    const init: Record<string, string> = {};
    for (const f of fields) init[f.name] = f.value ?? '';
    return init;
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // For chip-select field types, track selected items
  const [chipSelections, setChipSelections] = useState<Record<string, string[]>>(() => {
    const init: Record<string, string[]> = {};
    for (const f of fields) {
      if (f.type === 'chip-select') {
        init[f.name] = f.value ? f.value.split(',').filter(Boolean) : [];
      }
    }
    return init;
  });

  // For designation-counts field type
  const [designationCounts, setDesignationCounts] = useState<Record<string, number>>({});

  const isDriver = values.dutyType?.toUpperCase() === 'DRIVER' || values.unit?.toUpperCase() === 'MT';

  const handleChange = (name: string, value: string) => {
    setValues((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors((prev) => { const n = { ...prev }; delete n[name]; return n; });
  };

  const handleChipToggle = (fieldName: string, option: string) => {
    setChipSelections(prev => {
      const current = prev[fieldName] || [];
      const newSelection = current.includes(option)
        ? current.filter(s => s !== option)
        : [...current, option];
      // Also update values for form submission
      setValues(v => ({ ...v, [fieldName]: newSelection.join(',') }));
      return { ...prev, [fieldName]: newSelection };
    });
  };

  const handleDesignationCountChange = (desig: string, count: number) => {
    setDesignationCounts(prev => {
      const updated = { ...prev, [desig]: count };
      // Update the field value as JSON string
      setValues(v => ({ ...v, designation_counts: JSON.stringify(updated) }));
      return updated;
    });
  };

  const totalDesignationCount = useMemo(() => {
    return Object.values(designationCounts).reduce((sum, v) => sum + (v || 0), 0);
  }, [designationCounts]);

  const handleSubmit = async () => {
    const newErrors: Record<string, string> = {};
    for (const f of fields) {
      if (f.required && !values[f.name]?.trim()) newErrors[f.name] = `${f.label} is required`;
    }
    if (Object.keys(newErrors).length > 0) { setErrors(newErrors); return; }
    setSubmitting(true);
    try {
      const ok = await onSubmit(formId, submitAction, values);
      if (ok) setSubmitted(true);
    } catch { /* keep editable */ } finally { setSubmitting(false); }
  };

  // Group fields by their group property or by default categorization
  const groupedFields = useMemo(() => {
    const basicRequired: typeof fields = [];
    const basicOptional: typeof fields = [];
    const personalFields: typeof fields = [];
    const contactFields: typeof fields = [];
    const driverFieldsList: typeof fields = [];
    const personnelFields: typeof fields = [];

    for (const f of fields) {
      // Hidden fields are not rendered, skip them
      if (f.type === 'hidden') continue;
      
      // Personnel-list fields get their own section
      if (f.type === 'personnel-list') {
        personnelFields.push(f);
        continue;
      }
      
      const group = (f as { group?: string }).group;
      if (group === 'personal' || PERSONAL_FIELDS.includes(f.name)) {
        personalFields.push(f);
      } else if (group === 'contact' || CONTACT_FIELDS.includes(f.name)) {
        contactFields.push(f);
      } else if (group === 'driver' || DRIVER_FIELDS.includes(f.name)) {
        driverFieldsList.push(f);
      } else if (f.required) {
        basicRequired.push(f);
      } else {
        basicOptional.push(f);
      }
    }

    return { basicRequired, basicOptional, personalFields, contactFields, driverFields: driverFieldsList, personnelFields };
  }, [fields]);

  const renderField = (field: typeof fields[0]) => {
    const icon = FIELD_ICONS[field.name] || null;
    const isSelect = field.type === 'select';
    const isMultiSelect = field.type === 'multi-select';
    const isDate = field.type === 'date';
    const isNumber = field.type === 'number';
    const isTime = field.type === 'time';
    const isTextarea = field.type === 'textarea';
    const isSwitch = field.type === 'switch';
    const isChipSelect = field.type === 'chip-select';
    const isDesignationCounts = field.type === 'designation-counts';

    // For select fields that are part of a "group" sharing the same options
    // (e.g., platoon_*_sections), exclude options already selected by other fields in the group
    let availableOptions = field.options ?? [];
    if (isSelect && field.options && field.options.length > 0) {
      // Find sibling fields that share the exact same options
      const siblingFields = fields.filter(
        (f) => f.type === 'select' && f.name !== field.name && f.options &&
          JSON.stringify(f.options) === JSON.stringify(field.options)
      );
      if (siblingFields.length > 0) {
        // Collect values already selected by sibling fields
        const usedValues = siblingFields
          .map((f) => values[f.name])
          .filter((v) => v && v.trim() !== '');
        // Filter out used values (but keep the current field's own value)
        const currentValue = values[field.name] ?? '';
        availableOptions = field.options.filter(
          (opt) => opt === currentValue || !usedValues.includes(opt)
        );
      }
    }

    // Time picker widget
    if (isTime) {
      const dayjsValue = values[field.name] ? dayjs(values[field.name], 'HH:mm') : null;
      return (
        <Box key={field.name} sx={{ display: 'flex', alignItems: 'flex-start', gap: 1 }}>
          {icon && (
            <Box sx={{ mt: 1.1, flexShrink: 0, width: 24, display: 'flex', justifyContent: 'center' }}>
              {icon}
            </Box>
          )}
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <TimePicker
              label={`${field.label}${field.required ? ' *' : ''}`}
              value={dayjsValue}
              onChange={(newValue) => {
                if (newValue && newValue.isValid()) {
                  handleChange(field.name, newValue.format('HH:mm'));
                } else {
                  handleChange(field.name, '');
                }
              }}
              ampm={false}
              disabled={submitted}
              slotProps={{
                textField: {
                  size: 'small',
                  fullWidth: true,
                  error: !!errors[field.name],
                  helperText: errors[field.name],
                  sx: inputSx(submitted),
                },
              }}
            />
          </LocalizationProvider>
        </Box>
      );
    }

    // Chip-select for section selection (like adhoc duty page)
    if (isChipSelect) {
      const selected = chipSelections[field.name] || [];
      // Map section codes to display names
      const sectionLabels: Record<string, string> = {
        'B': 'Section B',
        'D': 'Section D',
        'E': 'Section E',
        'F': 'Section F',
        'G': 'Section G',
      };
      return (
        <Box key={field.name} sx={{ gridColumn: '1 / -1' }}>
          <Typography sx={{ fontSize: '0.75rem', fontWeight: 600, color: '#4b5563', mb: 0.5 }}>
            {field.label}{field.required ? ' *' : ''}
          </Typography>
          {field.helperText && (
            <Typography sx={{ fontSize: '0.68rem', color: '#9ca3af', mb: 1 }}>
              {field.helperText}
            </Typography>
          )}
          <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
            {(field.options ?? []).map((option) => {
              const isSelected = selected.includes(option);
              const displayLabel = sectionLabels[option] || option;
              return (
                <Chip
                  key={option}
                  label={displayLabel}
                  color={isSelected ? 'primary' : 'default'}
                  variant={isSelected ? 'filled' : 'outlined'}
                  onClick={() => !submitted && handleChipToggle(field.name, option)}
                  disabled={submitted}
                  sx={{ cursor: submitted ? 'default' : 'pointer', fontSize: '0.75rem' }}
                />
              );
            })}
          </Stack>
          {errors[field.name] && (
            <FormHelperText error>{errors[field.name]}</FormHelperText>
          )}
        </Box>
      );
    }

    // Designation counts table (like adhoc duty page)
    if (isDesignationCounts) {
      return (
        <Box key={field.name} sx={{ gridColumn: '1 / -1' }}>
          <Typography sx={{ fontSize: '0.75rem', fontWeight: 600, color: '#4b5563', mb: 0.5 }}>
            {field.label}{field.required ? ' *' : ''}
          </Typography>
          {field.helperText && (
            <Typography sx={{ fontSize: '0.68rem', color: '#9ca3af', mb: 1 }}>
              {field.helperText}
            </Typography>
          )}
          <TableContainer component={Paper} variant="outlined" sx={{ mb: 1 }}>
            <Table size="small">
              <TableHead>
                <TableRow>
                  {DESIGNATIONS_LIST.map((desig) => (
                    <TableCell key={desig} align="center" sx={{ fontWeight: 700, minWidth: 60, fontSize: '0.72rem', py: 0.5 }}>
                      {desig}
                    </TableCell>
                  ))}
                  <TableCell align="center" sx={{ fontWeight: 700, minWidth: 70, bgcolor: '#f5f5f5', fontSize: '0.72rem', py: 0.5 }}>
                    TOTAL
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                <TableRow>
                  {DESIGNATIONS_LIST.map((desig) => (
                    <TableCell key={desig} align="center" sx={{ p: 0.5 }}>
                      <TextField
                        type="number"
                        size="small"
                        value={designationCounts[desig] || ''}
                        onChange={(e) => handleDesignationCountChange(desig, parseInt(e.target.value) || 0)}
                        disabled={submitted}
                        inputProps={{ min: 0, max: 99, style: { textAlign: 'center', fontSize: '0.8rem' } }}
                        sx={{ width: 50 }}
                      />
                    </TableCell>
                  ))}
                  <TableCell align="center" sx={{ fontWeight: 700, fontSize: '0.9rem', bgcolor: '#f5f5f5' }}>
                    {totalDesignationCount}
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      );
    }

    // Hidden field - store value but don't render
    if (field.type === 'hidden') {
      return null;
    }

    // Personnel list with add/remove capability
    if (field.type === 'personnel-list') {
      // Parse personnel options: id|name|badge|designation|section
      const personnelOptions = (field.options ?? []).map(opt => {
        const parts = opt.split('|');
        return {
          id: parts[0] || '',
          name: parts[1] || '',
          badge: parts[2] || '',
          designation: parts[3] || '-',
          section: parts[4] || '-',
        };
      });
      
      // Current selected IDs from values
      const selectedIds = (values[field.name] || '').split(',').filter(Boolean);
      const selectedPersonnel = personnelOptions.filter(p => selectedIds.includes(p.id));
      
      const handleRemovePerson = (personId: string) => {
        const newIds = selectedIds.filter(id => id !== personId);
        handleChange(field.name, newIds.join(','));
      };

      return (
        <Box key={field.name} sx={{ gridColumn: '1 / -1' }}>
          <Typography sx={{ fontSize: '0.75rem', fontWeight: 600, color: '#4b5563', mb: 0.5 }}>
            {field.label}{field.required ? ' *' : ''}
          </Typography>
          {field.helperText && (
            <Typography sx={{ fontSize: '0.68rem', color: '#9ca3af', mb: 1 }}>
              {field.helperText}
            </Typography>
          )}
          {selectedPersonnel.length > 0 ? (
            <TableContainer component={Paper} variant="outlined" sx={{ maxHeight: 250, overflow: 'auto' }}>
              <Table size="small" stickyHeader>
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5 }}>Name</TableCell>
                    <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5 }}>Badge</TableCell>
                    <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5 }}>Designation</TableCell>
                    <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5 }}>Section</TableCell>
                    <TableCell align="center" sx={{ fontWeight: 700, fontSize: '0.72rem', py: 0.5 }}>Action</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {selectedPersonnel.map((person) => (
                    <TableRow key={person.id}>
                      <TableCell sx={{ fontSize: '0.75rem', py: 0.5 }}>{person.name}</TableCell>
                      <TableCell sx={{ fontSize: '0.75rem', py: 0.5 }}>{person.badge}</TableCell>
                      <TableCell sx={{ fontSize: '0.75rem', py: 0.5 }}>{person.designation}</TableCell>
                      <TableCell sx={{ fontSize: '0.75rem', py: 0.5 }}>{person.section}</TableCell>
                      <TableCell align="center" sx={{ py: 0.5 }}>
                        {!submitted && (
                          <Button
                            size="small"
                            color="error"
                            onClick={() => handleRemovePerson(person.id)}
                            sx={{ minWidth: 'auto', p: 0.5, fontSize: '0.65rem' }}
                          >
                            Remove
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          ) : (
            <Typography sx={{ fontSize: '0.75rem', color: '#9ca3af', fontStyle: 'italic' }}>
              No personnel selected
            </Typography>
          )}
          {errors[field.name] && (
            <FormHelperText error>{errors[field.name]}</FormHelperText>
          )}
        </Box>
      );
    }

    // Textarea for multi-line text
    if (isTextarea) {
      return (
        <Box key={field.name} sx={{ display: 'flex', alignItems: 'flex-start', gap: 1 }}>
          {icon && (
            <Box sx={{ mt: 1.1, flexShrink: 0, width: 24, display: 'flex', justifyContent: 'center' }}>
              {icon}
            </Box>
          )}
          <TextField
            size="small" fullWidth multiline rows={2}
            label={`${field.label}${field.required ? ' *' : ''}`}
            placeholder={PLACEHOLDERS[field.name] || `Enter ${field.label.toLowerCase()}`}
            value={values[field.name] ?? ''}
            onChange={(e) => handleChange(field.name, e.target.value)}
            error={!!errors[field.name]} helperText={errors[field.name]}
            disabled={submitted} sx={inputSx(submitted)}
          />
        </Box>
      );
    }

    // Switch for boolean fields
    if (isSwitch) {
      return (
        <Box key={field.name} sx={{ display: 'flex', alignItems: 'center', gap: 1, gridColumn: '1 / -1' }}>
          <FormControlLabel
            control={
              <Switch
                checked={values[field.name] === 'true'}
                onChange={(e) => handleChange(field.name, e.target.checked ? 'true' : 'false')}
                disabled={submitted}
              />
            }
            label={<Typography sx={{ fontSize: '0.82rem' }}>{field.label}</Typography>}
          />
        </Box>
      );
    }

    return (
      <Box key={field.name} sx={{ display: 'flex', alignItems: 'flex-start', gap: 1 }}>
        {icon && (
          <Box sx={{ mt: 1.1, flexShrink: 0, width: 24, display: 'flex', justifyContent: 'center' }}>
            {icon}
          </Box>
        )}
        {(isSelect || isMultiSelect) ? (
          <FormControl size="small" fullWidth error={!!errors[field.name]} disabled={submitted} sx={inputSx(submitted)}>
            <InputLabel>{field.label}{field.required ? ' *' : ''}</InputLabel>
            <Select
              multiple={isMultiSelect}
              value={isMultiSelect ? (values[field.name] ? values[field.name].split(',').filter(Boolean) : []) : (values[field.name] ?? '')}
              label={`${field.label}${field.required ? ' *' : ''}`}
              onChange={(e) => {
                const val = e.target.value;
                handleChange(field.name, Array.isArray(val) ? val.join(',') : val as string);
              }}
              displayEmpty
              renderValue={isMultiSelect ? (selected) => {
                const sel = selected as string[];
                return sel.length === 0 ? '' : sel.join(', ');
              } : undefined}
            >
              {availableOptions.map((opt) => (
                <MenuItem key={opt} value={opt}>{opt}</MenuItem>
              ))}
            </Select>
            {errors[field.name] && <FormHelperText>{errors[field.name]}</FormHelperText>}
          </FormControl>
        ) : (
          <TextField
            size="small" fullWidth
            type={isDate ? 'date' : isNumber ? 'number' : 'text'}
            label={`${field.label}${field.required ? ' *' : ''}`}
            placeholder={PLACEHOLDERS[field.name] || (field as { placeholder?: string }).placeholder || `Enter ${field.label.toLowerCase()}`}
            value={values[field.name] ?? ''}
            onChange={(e) => handleChange(field.name, e.target.value)}
            error={!!errors[field.name]} helperText={errors[field.name]}
            disabled={submitted} sx={inputSx(submitted)}
            InputLabelProps={isDate ? { shrink: true } : undefined}
          />
        )}
      </Box>
    );
  };

  return (
    <Box sx={{ width: '100%', minWidth: 480, borderRadius: 2.5, overflow: 'hidden', border: '1px solid #e5e7eb', bgcolor: '#fff' }}>
      {/* Header */}
      <Box sx={{
        px: 2.5, py: 1.5,
        background: 'linear-gradient(135deg, #312e81 0%, #4338ca 100%)',
        display: 'flex', alignItems: 'center', gap: 1.5,
      }}>
        <Box sx={{
          width: 34, height: 34, borderRadius: 1.5,
          bgcolor: 'rgba(255,255,255,0.15)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <PersonAddAltIcon sx={{ fontSize: 18, color: '#0d9488' }} />
        </Box>
        <Box>
          <Typography sx={{ fontSize: '0.88rem', fontWeight: 700, color: '#fff', lineHeight: 1.2 }}>{title}</Typography>
          <Typography sx={{ fontSize: '0.68rem', color: 'rgba(255,255,255,0.6)' }}>Fill in the details below</Typography>
        </Box>
      </Box>

      {/* Required fields */}
      <Box sx={{ px: 2.5, pt: 2, pb: 1.5 }}>
        <Chip label="Required" size="small" sx={{ height: 20, fontSize: '0.6rem', fontWeight: 700, bgcolor: '#fef2f2', color: '#dc2626', border: '1px solid #fecaca', mb: 1.5 }} />
        <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1.5 }}>
          {groupedFields.basicRequired.map(renderField)}
        </Box>
      </Box>

      {/* Divider */}
      <Box sx={{ px: 2.5, py: 0.5 }}><Box sx={{ borderTop: '1px dashed #e5e7eb' }} /></Box>

      {/* Optional fields */}
      {groupedFields.basicOptional.length > 0 && (
        <Box sx={{ px: 2.5, pt: 1, pb: 1.5 }}>
          <Chip label="Optional" size="small" sx={{ height: 20, fontSize: '0.6rem', fontWeight: 700, bgcolor: '#f0fdf4', color: '#16a34a', border: '1px solid #bbf7d0', mb: 1.5 }} />
          <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1.5 }}>
            {groupedFields.basicOptional.map(renderField)}
          </Box>
        </Box>
      )}

      {/* Personal Details section */}
      {groupedFields.personalFields.length > 0 && (
        <>
          <Box sx={{ px: 2.5, py: 0.5 }}><Box sx={{ borderTop: '1px dashed #6366f1' }} /></Box>
          <Box sx={{ px: 2.5, pt: 1, pb: 1.5, bgcolor: '#faf5ff' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1.5 }}>
              <CakeIcon sx={{ fontSize: 16, color: '#7c3aed' }} />
              <Typography sx={{ fontSize: '0.78rem', fontWeight: 700, color: '#7c3aed' }}>Personal Details</Typography>
            </Box>
            <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1.5 }}>
              {groupedFields.personalFields.map(renderField)}
            </Box>
          </Box>
        </>
      )}

      {/* Contact & Service Details section */}
      {groupedFields.contactFields.length > 0 && (
        <>
          <Box sx={{ px: 2.5, py: 0.5 }}><Box sx={{ borderTop: '1px dashed #0891b2' }} /></Box>
          <Box sx={{ px: 2.5, pt: 1, pb: 1.5, bgcolor: '#f0fdfa' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1.5 }}>
              <PhoneOutlinedIcon sx={{ fontSize: 16, color: '#0891b2' }} />
              <Typography sx={{ fontSize: '0.78rem', fontWeight: 700, color: '#0891b2' }}>Contact & Service Details</Typography>
            </Box>
            <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1.5 }}>
              {groupedFields.contactFields.map(renderField)}
            </Box>
          </Box>
        </>
      )}

      {/* Driver fields — conditional */}
      {isDriver && groupedFields.driverFields.length > 0 && (
        <>
          <Box sx={{ px: 2.5, py: 0.5 }}><Box sx={{ borderTop: '1px dashed #0d9488' }} /></Box>
          <Box sx={{ px: 2.5, pt: 1, pb: 1.5, bgcolor: '#fffbf0' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1.5 }}>
              <DirectionsCarIcon sx={{ fontSize: 16, color: '#92400e' }} />
              <Typography sx={{ fontSize: '0.78rem', fontWeight: 700, color: '#92400e' }}>Driver Details</Typography>
            </Box>
            <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1.5 }}>
              {groupedFields.driverFields.map(renderField)}
            </Box>
          </Box>
        </>
      )}

      {/* Personnel List section (for adhoc duty confirmation) */}
      {groupedFields.personnelFields.length > 0 && (
        <>
          <Box sx={{ px: 2.5, py: 0.5 }}><Box sx={{ borderTop: '1px dashed #059669' }} /></Box>
          <Box sx={{ px: 2.5, pt: 1, pb: 1.5, bgcolor: '#ecfdf5' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1.5 }}>
              <PersonAddAltIcon sx={{ fontSize: 16, color: '#059669' }} />
              <Typography sx={{ fontSize: '0.78rem', fontWeight: 700, color: '#059669' }}>Selected Personnel</Typography>
            </Box>
            <Box sx={{ display: 'grid', gridTemplateColumns: '1fr', gap: 1.5 }}>
              {groupedFields.personnelFields.map(renderField)}
            </Box>
          </Box>
        </>
      )}

      {/* Footer */}
      <Box sx={{
        px: 2.5, py: 1.5, bgcolor: '#f8fafc', borderTop: '1px solid #e5e7eb',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <Typography sx={{ fontSize: '0.65rem', color: '#94a3b8' }}>
          {submitted ? '✓ Form submitted successfully' : '* indicates required fields'}
        </Typography>
        <Button
          variant="contained" size="small" onClick={handleSubmit}
          disabled={submitted || submitting}
          sx={{
            textTransform: 'none', fontSize: '0.78rem', fontWeight: 600, px: 3, borderRadius: 2,
            background: submitted ? '#94a3b8' : 'linear-gradient(135deg, #312e81 0%, #4338ca 100%)',
            boxShadow: submitted ? 'none' : '0 2px 8px rgba(49,46,129,0.3)',
            '&:hover': { background: 'linear-gradient(135deg, #1e1b4b 0%, #312e81 100%)', boxShadow: '0 4px 12px rgba(49,46,129,0.4)' },
            '&.Mui-disabled': { background: '#e2e8f0', color: '#94a3b8', boxShadow: 'none' },
          }}
        >
          {submitting ? 'Submitting...' : submitted ? 'Submitted ✓' : (submitLabel || title || 'Submit')}
        </Button>
      </Box>
    </Box>
  );
};

export default FormWidget;
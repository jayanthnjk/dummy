package com.policescheduler.service;

import com.policescheduler.entity.DutyReassignment;
import com.policescheduler.entity.Personnel;
import com.policescheduler.repository.DutyReassignmentRepository;
import com.policescheduler.repository.PersonnelRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Centralized service for resolving effective duty personnel based on active reassignments.
 *
 * DISPLAY-ONLY layer. Does NOT modify the personnel table or duty_assignment records.
 * 
 * Logic:
 * - If an ACTIVE reassignment exists and current date is within startDate–endDate:
 *   1. REMOVE replacement person from their source section
 *   2. ADD replacement person to the target section under the leave person's duty/sub-duty
 *   3. The leave person still shows in the leave section (not removed from personnel list)
 * - After endDate passes: status moves to INACTIVE (triggered on page load)
 */
@Service
public class ReassignmentResolverService {

    private static final Logger log = LoggerFactory.getLogger(ReassignmentResolverService.class);

    private final DutyReassignmentRepository reassignmentRepository;
    private final PersonnelRepository personnelRepository;

    public ReassignmentResolverService(DutyReassignmentRepository reassignmentRepository,
                                        PersonnelRepository personnelRepository) {
        this.reassignmentRepository = reassignmentRepository;
        this.personnelRepository = personnelRepository;
    }

    // =========================================================================
    // EXPIRY: Mark expired reassignments as INACTIVE
    // =========================================================================

    /**
     * Expires all ACTIVE reassignments whose endDate is before the given date.
     * Called when user lands on any main page (Assign Duties, Schedules, Reports, Leave).
     *
     * @return number of records expired
     */
    @Transactional
    public int expireOverdueReassignments() {
        LocalDate today = LocalDate.now();
        List<DutyReassignment> expired = reassignmentRepository.findActiveExpiredBefore(today);
        if (expired.isEmpty()) {
            return 0;
        }
        for (DutyReassignment r : expired) {
            r.setStatus("INACTIVE");
        }
        reassignmentRepository.saveAll(expired);
        log.info("Expired {} overdue reassignment(s)", expired.size());
        return expired.size();
    }

    // =========================================================================
    // RESOLUTION: Determine effective personnel for a section
    // =========================================================================

    /**
     * Resolves the effective personnel list for a section on a given date.
     *
     * 1. REMOVES replacement personnel who belong to this section but are covering
     *    duty in another section (sent away).
     * 2. ADDS replacement personnel coming INTO this section from other sections,
     *    with the leave person's duty_type and duty_location set on a virtual copy.
     *
     * The leave person (who is on leave) stays in the list — the existing leave
     * detection logic will handle showing them in the LEAVE section.
     *
     * @param originalPersonnel the raw personnel list from the DB for a section
     * @param sectionCode       the section code being displayed
     * @param date              the date to resolve for (typically today)
     * @return resolved personnel list
     */
    public List<Personnel> resolveForSection(List<Personnel> originalPersonnel, String sectionCode, LocalDate date) {
        List<DutyReassignment> activeReassignments = reassignmentRepository.findAllActiveOnDate(date);
        if (activeReassignments.isEmpty()) {
            return originalPersonnel;
        }

        // Build lookup maps
        Map<Long, DutyReassignment> byReplacementPerson = activeReassignments.stream()
                .collect(Collectors.toMap(DutyReassignment::getReplacementPersonId, r -> r, (a, b) -> a));

        // Step 1: Filter out replacement personnel who are sent away from this section
        List<Personnel> resolved = new ArrayList<>();
        for (Personnel person : originalPersonnel) {
            DutyReassignment r = byReplacementPerson.get(person.getId());
            if (r != null) {
                // This person is a replacement somewhere
                String targetSection = r.getSectionCode();
                if (targetSection != null && !targetSection.equalsIgnoreCase(sectionCode)) {
                    // Sent to a different section — remove from here
                    continue;
                }
            }
            resolved.add(person);
        }

        // Step 2: Add incoming replacements (people from other sections covering duty here)
        List<DutyReassignment> incomingToThisSection = activeReassignments.stream()
                .filter(r -> sectionCode.equalsIgnoreCase(r.getSectionCode()))
                .collect(Collectors.toList());

        for (DutyReassignment r : incomingToThisSection) {
            Long replacementId = r.getReplacementPersonId();
            // Only add if not already present (they might already be in this section)
            boolean alreadyPresent = resolved.stream().anyMatch(p -> p.getId().equals(replacementId));
            if (!alreadyPresent) {
                Personnel replacementPerson = personnelRepository.findById(replacementId).orElse(null);
                if (replacementPerson != null) {
                    // Create a virtual copy with the reassignment's duty info
                    // so they appear under the correct duty card in this section
                    Personnel virtual = new Personnel();
                    virtual.setId(replacementPerson.getId());
                    virtual.setBadgeId(replacementPerson.getBadgeId());
                    virtual.setPersonName(replacementPerson.getPersonName());
                    virtual.setDesignation(replacementPerson.getDesignation());
                    virtual.setUnit(replacementPerson.getUnit());
                    virtual.setPlatoonId(replacementPerson.getPlatoonId());
                    virtual.setIsActive(replacementPerson.getIsActive());
                    // Use the reassignment's duty info (leave person's duty)
                    virtual.setSection(sectionCode);
                    virtual.setDutyType(r.getDutyType());
                    virtual.setDutyLocation(r.getDutyLocation());
                    virtual.setLocation(null);
                    virtual.setCurrentCycleId(replacementPerson.getCurrentCycleId());
                    resolved.add(virtual);
                }
            }
        }

        return resolved;
    }

    /**
     * Returns the set of personnel IDs that should be HIDDEN from a given section
     * because they are currently reassigned to cover duty in another section.
     */
    public Set<Long> getPersonnelSentAwayFromSection(String sectionCode, LocalDate date) {
        List<DutyReassignment> activeReassignments = reassignmentRepository.findAllActiveOnDate(date);
        if (activeReassignments.isEmpty()) return Collections.emptySet();

        Set<Long> result = new HashSet<>();
        for (DutyReassignment r : activeReassignments) {
            String targetSection = r.getSectionCode();
            if (targetSection != null && !targetSection.equalsIgnoreCase(sectionCode)) {
                result.add(r.getReplacementPersonId());
            }
        }
        return result;
    }
}

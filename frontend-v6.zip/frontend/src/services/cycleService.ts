import api from './api';

export type CycleStatus = 'ACTIVE' | 'COMPLETED' | 'DELETED';

export interface PlatoonSectionMapping {
  platoonId: number;
  sectionIds: number[];
}

export interface CycleCreateRequest {
  startDate: string;
  rotationDays: number;
  platoonSections: PlatoonSectionMapping[];
}

export interface CycleResponse {
  id: number;
  startDate: string;
  endDate: string;
  rotationDays: number;
  status: CycleStatus;
  platoonSections: PlatoonSectionMapping[];
  createdAt: string;
  updatedAt: string;
}

export interface AssignmentResponse {
  id: number;
  cycleId: number;
  date: string;
  platoonId: number;
  sectionId: number;
  personId: number;
  personName: string;
  shiftType: string;
  dutyName: string | null;
  groupIndex: string | null;
  status: string;
  adhocDutyName: string | null;
  adhocDutyTime: string | null;
  isOverride: boolean;
  updatedAt: string;
  onLeave: boolean;
}

export interface SectionInfo {
  id: number;
  code: string;
  name: string;
  description: string | null;
  sortOrder: number;
  isActive: boolean;
  dutyTypeCount: number;
}

export interface ReassignResponse {
  id: number;
  cycleId: number;
  date: string;
  platoonId: number;
  sectionId: number;
  personId: number;
  shiftType: string;
  isOverride: boolean;
  updatedAt: string;
}

export interface CycleAuditLog {
  id: number;
  cycleId: number;
  action: string;
  description: string;
  oldValue: string | null;
  newValue: string | null;
  performedBy: number | null;
  createdAt: string;
}

export interface AvailablePersonnel {
  id: number;
  personName: string;
  badgeId: string;
  section: string;
  currentDutyType: string;
}

export interface AutoReassignResponse {
  assignmentId: number;
  cycleId: number;
  date: string;
  platoonId: number;
  sectionId: number;
  newPersonId: number;
  newPersonName: string;
  newPersonBadgeId: string;
  newPersonPlatoonId: number;
  isOverride: boolean;
  reason: string;
}

export interface AutoGenerateResponse {
  mappings: { platoonId: number; sectionIds: number[] }[];
  previousCycle: { id: number; mappings: { platoonId: number; sectionIds: number[] }[] } | null;
  previousPlatoonSections: Record<number, number> | null;
  rotationIndex: number;
}

export interface AdhocDutyResponse {
  id: number;
  dutyName: string;
  date: string;
  startTime: string;
  endTime: string;
  requiredCount: number;
  actualCount: number;
  pickFrom: string;
  platoonIds: number[] | null;
  location: string | null;
  status: string;
  createdAt: string;
  assignees?: AdhocAssigneeInfo[];
}

export interface AdhocAssigneeInfo {
  personId: number;
  personName: string;
  badgeId: string;
  designation: string;
  section: string;
  originalShift: string;
  originalDutyName: string;
  disruptionScore: number;
  status: string;
}

export interface CreateAdhocDutyRequest {
  dutyName: string;
  date: string;
  startTime: string;
  endTime: string;
  requiredCount: number;
  location?: string;
  pickFrom?: string;
  platoonIds?: number[];
  personnelIds?: number[];
}

export const cycleService = {
  /** Fetch all sections (for schedule display labels/colors) */
  getSections: () =>
    api.get<SectionInfo[]>('/api/sections').then((r) => r.data),

  /** Fetch all cycles, optionally filtered by status */
  getCycles: (status?: CycleStatus) =>
    api
      .get<CycleResponse[]>('/api/cycles', {
        params: status ? { status } : undefined,
      })
      .then((r) => r.data),

  /** Fetch a single cycle by ID */
  getCycleById: (id: number) =>
    api.get<CycleResponse>(`/api/cycles/${id}`).then((r) => r.data),

  /** Create a new cycle with platoon-section mappings */
  createCycle: (request: CycleCreateRequest) =>
    api.post<CycleResponse>('/api/cycles', request).then((r) => r.data),

  /** Fetch assignments for a given cycle and date, including leave conflict flags */
  getAssignments: (cycleId: number, date: string) =>
    api
      .get<AssignmentResponse[]>('/api/assignments', {
        params: { cycleId, date },
      })
      .then((r) => r.data),

  /** Fetch assignments for a date range (for week/month views) */
  getAssignmentsByRange: (cycleId: number, startDate: string, endDate: string) =>
    api
      .get<AssignmentResponse[]>('/api/assignments/range', {
        params: { cycleId, startDate, endDate },
      })
      .then((r) => r.data),

  /** Reassign a duty assignment to a different person */
  reassignDuty: (assignmentId: number, newPersonId: number) =>
    api
      .patch<ReassignResponse>('/api/assignments/reassign', {
        assignmentId,
        newPersonId,
      })
      .then((r) => r.data),

  /** Fetch all audit logs */
  getAuditLogs: () =>
    api.get<CycleAuditLog[]>('/api/cycles/audit').then((r) => r.data),

  /** Fetch audit logs for a specific cycle */
  getAuditLogsByCycle: (cycleId: number) =>
    api.get<CycleAuditLog[]>(`/api/cycles/${cycleId}/audit`).then((r) => r.data),

  /** Fetch available personnel for reassignment */
  getAvailablePersonnel: (assignmentId: number, search?: string) =>
    api.get<AvailablePersonnel[]>(`/api/assignments/${assignmentId}/available-personnel`, {
      params: search ? { search } : undefined,
    }).then((r) => r.data),

  /** Auto-reassign a duty to someone from another platoon */
  autoReassign: (assignmentId: number) =>
    api.post<AutoReassignResponse>(`/api/assignments/${assignmentId}/auto-reassign`).then((r) => r.data),

  /** Auto-generate next cycle's platoon-section mappings */
  autoGenerateMappings: () =>
    api.get<AutoGenerateResponse>('/api/cycles/auto-generate').then((r) => r.data),

  /** Get the next available start date for a new cycle */
  getNextAvailableDate: () =>
    api.get<{ nextAvailableDate: string }>('/api/cycles/next-available-date').then((r) => r.data),

  /** Update a cycle (partial update) */
  updateCycle: (id: number, request: Partial<CycleCreateRequest>) =>
    api.patch<CycleResponse>(`/api/cycles/${id}`, request).then((r) => r.data),

  /** Delete (soft-delete) a cycle */
  deleteCycle: (id: number) =>
    api.delete(`/api/cycles/${id}`).then((r) => r.data),

  // Adhoc Duty APIs
  getAdhocDuties: (date?: string, status?: string) =>
    api.get<AdhocDutyResponse[]>('/api/adhoc-duties', { params: { date, status } }).then(r => r.data),

  getAdhocDutyById: (id: number) =>
    api.get<AdhocDutyResponse>(`/api/adhoc-duties/${id}`).then(r => r.data),

  createAdhocDuty: (request: CreateAdhocDutyRequest) =>
    api.post<AdhocDutyResponse>('/api/adhoc-duties', request).then(r => r.data),

  cancelAdhocDuty: (id: number) =>
    api.delete<AdhocDutyResponse>(`/api/adhoc-duties/${id}`).then(r => r.data),

  previewAdhocPersonnel: (date: string, startTime: string, endTime: string, count: number, pickFrom?: string, platoonIds?: number[]) =>
    api.get<AdhocAssigneeInfo[]>('/api/adhoc-duties/preview', {
      params: { date, startTime, endTime, count, pickFrom, platoonIds: platoonIds?.join(',') }
    }).then(r => r.data),

  searchAdhocPersonnel: (query: string, date: string, startTime: string, endTime: string) =>
    api.get<AdhocAssigneeInfo[]>('/api/adhoc-duties/search-personnel', {
      params: { query, date, startTime, endTime }
    }).then(r => r.data),

  downloadAdhocPdf: (id: number) =>
    api.get(`/api/adhoc-duties/${id}/report/pdf`, { responseType: 'blob' }).then(r => r.data),

  downloadAdhocExcel: (id: number) =>
    api.get(`/api/adhoc-duties/${id}/report/excel`, { responseType: 'blob' }).then(r => r.data),
};

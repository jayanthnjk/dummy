import React, { useRef, useState } from 'react';
import {
  Drawer,
  Box,
  Typography,
  IconButton,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Tooltip,
  Chip,
  Divider,
  alpha,
  useMediaQuery,
  useTheme,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Button,
} from '@mui/material';
import KeyboardDoubleArrowLeftIcon from '@mui/icons-material/KeyboardDoubleArrowLeft';
import KeyboardDoubleArrowRightIcon from '@mui/icons-material/KeyboardDoubleArrowRight';
import ExitToAppIcon from '@mui/icons-material/ExitToApp';
import { useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguageContext } from '@/contexts/LanguageContext';
import { navigationGroups, getVisibleNavItems } from '@/config/navigation';
import { PersonAvatar } from '@/components/common/PersonAvatar';

// ─── Exported Constants ────────────────────────────────────────────────
export const SIDEBAR_WIDTH = 260;
export const SIDEBAR_COLLAPSED_WIDTH = 72;

// ─── Props ─────────────────────────────────────────────────────────────
interface SidebarProps {
  collapsed: boolean;
  mobileOpen: boolean;
  onToggleCollapse: () => void;
  onClose: () => void;
}

/**
 * Sidebar — enhanced navigation drawer for the CAR WorkBoard application.
 *
 * Sections (top to bottom):
 * 1. Logo + CAR Unit subtitle
 * 2. User Profile (avatar + name + role badge) with dropdown menu
 * 3. Language toggle + Notifications indicator
 * 4. Navigation groups with labeled dividers (scrollable, hidden scrollbar)
 * 5. Collapse/Expand toggle at bottom
 *
 * Features:
 * - Permanent mode (desktop ≥ 900px) / Temporary overlay (mobile < 900px)
 * - Expanded: 260px, Collapsed: 72px with cubic-bezier transition over 250ms
 * - Nav item hover: scale(1.02) + background, 200ms ease-out
 * - Active indicator: 3px left accent bar (teal)
 * - Collapsed: icons only, tooltips with 300ms delay, text fade 150ms
 * - Scrollable nav section (scrollbar-width: none)
 * - aria-label="Main navigation", aria-current="page" on active
 * - Collapsed items: aria-label matching full text label
 * - Focus preserved on collapse toggle during transitions
 *
 * Validates: Requirements 1.1–1.7, 2.1–2.11, 12.1–12.3, 12.9
 */
const Sidebar: React.FC<SidebarProps> = ({
  collapsed,
  mobileOpen,
  onToggleCollapse,
  onClose,
}) => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();
  const theme = useTheme();
  const { role, displayName, logout, units } = useAuth();
  const { locale, toggleLanguage } = useLanguageContext();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));

  const collapseButtonRef = useRef<HTMLButtonElement>(null);

  // Logout confirmation dialog state
  const [logoutDialogOpen, setLogoutDialogOpen] = useState(false);

  // Filtered navigation groups based on user role
  const visibleGroups = getVisibleNavItems(navigationGroups, role || '', units);

  const width = collapsed ? SIDEBAR_COLLAPSED_WIDTH : SIDEBAR_WIDTH;

  // ─── Handlers ──────────────────────────────────────────────────────
  const handleNavClick = (path: string) => {
    navigate(path);
    if (isMobile) onClose();
  };

  const handleLogoutConfirm = () => {
    setLogoutDialogOpen(false);
    logout();
  };

  const handleCollapseToggle = () => {
    onToggleCollapse();
    // Preserve focus on the collapse toggle button after transition completes
    setTimeout(() => {
      collapseButtonRef.current?.focus();
    }, 260);
  };

  // ─── Drawer Content ────────────────────────────────────────────────
  const drawerContent = (
    <Box
      sx={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
      }}
    >
      {/* ── Section 1: Logo + CAR Unit ─────────────────────────────── */}
      <Box
        sx={{
          px: collapsed ? 1.5 : 2.5,
          py: 2,
          display: 'flex',
          alignItems: 'center',
          gap: 1.2,
          minHeight: 56,
          borderBottom: `1px solid ${theme.palette.divider}`,
          flexShrink: 0,
        }}
      >
        <Box
          sx={{
            width: 36,
            height: 36,
            flexShrink: 0,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            borderRadius: 2,
            bgcolor: alpha(theme.palette.primary.main, 0.06),
            boxShadow: `0 1px 3px ${alpha(theme.palette.primary.main, 0.08)}`,
          }}
        >
          <Box
            component="img"
            src="/workboardlogo.png"
            alt="CAR Logo"
            sx={{ width: 26, height: 26 }}
          />
        </Box>
        {!collapsed && (
          <Box
            sx={{
              opacity: 1,
              transition: 'opacity 150ms ease 150ms',
            }}
          >
            <Typography
              sx={{
                fontWeight: 700,
                fontSize: '0.88rem',
                color: theme.palette.primary.main,
                lineHeight: 1.1,
                letterSpacing: '-0.02em',
              }}
            >
              {t('app.title', 'CAR WorkBoard')}
            </Typography>
            <Typography
              sx={{
                fontSize: '0.64rem',
                color: theme.palette.text.disabled,
                lineHeight: 1.3,
                fontWeight: 500,
              }}
            >
              {t('app.subtitle', 'CAR Unit')}
            </Typography>
          </Box>
        )}
      </Box>

      {/* Section 2 removed — User Profile moved to bottom */}

      {/* Section 3 removed — language toggle moved to bottom */}

      {/* ── Section 4: Navigation Groups (scrollable) ──────────────── */}
      <Box
        component="nav"
        aria-label="Main navigation"
        sx={{
          flex: 1,
          overflowY: 'auto',
          overflowX: 'hidden',
          scrollbarWidth: 'none',
          '&::-webkit-scrollbar': { display: 'none' },
          px: 1,
          py: 1,
        }}
      >
        {visibleGroups.map((group) => (
          <Box key={group.id} sx={{ mb: 1 }}>
            {/* Group Label / Divider */}
            {!collapsed ? (
              <Typography
                variant="caption"
                sx={{
                  display: 'block',
                  px: 1,
                  py: 0.5,
                  fontSize: '0.68rem',
                  fontWeight: 600,
                  textTransform: 'uppercase',
                  letterSpacing: '0.05em',
                  color: theme.palette.text.disabled,
                  transition: 'opacity 150ms ease 150ms',
                }}
              >
                {t(group.labelKey, group.label)}
              </Typography>
            ) : (
              <Divider sx={{ my: 0.5, mx: 1 }} />
            )}

            {/* Nav Items */}
            <List disablePadding>
              {group.items.map((item) => {
                const isActive = location.pathname === item.path;
                const Icon = item.icon;
                const label = t(item.labelKey, item.id);

                const navButton = (
                  <ListItem key={item.id} disablePadding sx={{ mb: 0.3 }}>
                    <ListItemButton
                      onClick={() => handleNavClick(item.path)}
                      aria-current={isActive ? 'page' : undefined}
                      aria-label={collapsed ? label : undefined}
                      sx={{
                        borderRadius: 2,
                        py: 0.9,
                        px: collapsed ? 'auto' : 1.5,
                        justifyContent: collapsed ? 'center' : 'flex-start',
                        position: 'relative',
                        minHeight: 40,
                        color: isActive
                          ? theme.palette.primary.main
                          : theme.palette.text.secondary,
                        bgcolor: isActive
                          ? alpha(theme.palette.secondary.main, 0.06)
                          : 'transparent',
                        transition: 'all 200ms ease-out',
                        '&:hover': {
                          bgcolor: isActive
                            ? alpha(theme.palette.secondary.main, 0.08)
                            : alpha(theme.palette.primary.main, 0.04),
                          transform: 'scale(1.02)',
                          color: isActive
                            ? theme.palette.primary.main
                            : theme.palette.text.primary,
                        },
                        '&:focus-visible': {
                          outline: `2px solid ${theme.palette.primary.main}`,
                          outlineOffset: '2px',
                        },
                        // Active indicator: 3px left accent bar (teal)
                        '&::before': isActive
                          ? {
                              content: '""',
                              position: 'absolute',
                              left: 0,
                              top: '15%',
                              bottom: '15%',
                              width: 3,
                              borderRadius: 4,
                              bgcolor: theme.palette.secondary.main,
                            }
                          : {},
                      }}
                    >
                      <ListItemIcon
                        sx={{
                          minWidth: collapsed ? 0 : 34,
                          color: isActive
                            ? theme.palette.secondary.main
                            : theme.palette.text.disabled,
                          justifyContent: 'center',
                          transition: 'color 200ms ease',
                        }}
                      >
                        <Icon />
                      </ListItemIcon>
                      {!collapsed && (
                        <ListItemText
                          primary={label}
                          primaryTypographyProps={{
                            fontSize: '0.82rem',
                            fontWeight: isActive ? 600 : 450,
                            letterSpacing: '-0.01em',
                            sx: {
                              opacity: 1,
                              transition: 'opacity 150ms ease 150ms',
                            },
                          }}
                        />
                      )}
                    </ListItemButton>
                  </ListItem>
                );

                // In collapsed state, wrap with tooltip (300ms delay)
                if (collapsed) {
                  return (
                    <Tooltip
                      key={item.id}
                      title={label}
                      placement="right"
                      enterDelay={300}
                      arrow
                    >
                      {navButton}
                    </Tooltip>
                  );
                }

                return <React.Fragment key={item.id}>{navButton}</React.Fragment>;
              })}
            </List>
          </Box>
        ))}
      </Box>

      {/* ── User Profile + Logout Icon (single row) ─────────────────── */}
      <Box
        sx={{
          px: collapsed ? 1 : 2,
          py: 1.5,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: 1.2,
          borderTop: `1px solid ${theme.palette.divider}`,
          flexShrink: 0,
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.2, overflow: 'hidden' }}>
          <PersonAvatar
            name={displayName || 'U'}
            size="small"
          />
          {!collapsed && (
            <Box
              sx={{
                overflow: 'hidden',
                opacity: 1,
                transition: 'opacity 150ms ease 150ms',
              }}
            >
              <Typography
                sx={{
                  fontSize: '0.82rem',
                  fontWeight: 600,
                  color: theme.palette.text.primary,
                  lineHeight: 1.2,
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                  whiteSpace: 'nowrap',
                }}
              >
                {displayName || 'User'}
              </Typography>
              <Chip
                label={role || 'Officer'}
                size="small"
                sx={{
                  height: 18,
                  fontSize: '0.62rem',
                  fontWeight: 600,
                  mt: 0.3,
                  bgcolor: alpha(theme.palette.secondary.main, 0.1),
                  color: theme.palette.secondary.dark,
                  borderRadius: '4px',
                }}
              />
            </Box>
          )}
        </Box>
        <Tooltip
          title={t('nav.logout', 'Logout')}
          placement="right"
          enterDelay={300}
        >
          <IconButton
            onClick={() => setLogoutDialogOpen(true)}
            size="small"
            aria-label={t('nav.logout', 'Logout')}
            sx={{
              color: '#dc2626',
              '&:hover': {
                bgcolor: 'rgba(220, 38, 38, 0.08)',
              },
            }}
          >
            <ExitToAppIcon sx={{ fontSize: 20 }} />
          </IconButton>
        </Tooltip>
      </Box>

      {/* ── Section 5: Language Toggle + Collapse/Expand Toggle (bottom) ─── */}
      <Box
        sx={{
          px: 1,
          py: 1.5,
          borderTop: `1px solid ${theme.palette.divider}`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: collapsed ? 'center' : 'space-between',
          flexShrink: 0,
          gap: 1,
        }}
      >
        {/* Language Toggle */}
        <Tooltip
          title={locale === 'en' ? 'Switch to Kannada' : 'Switch to English'}
          enterDelay={collapsed ? 300 : 0}
          placement="right"
        >
          <Chip
            label={collapsed ? (locale === 'en' ? 'KA' : 'EN') : (locale === 'en' ? 'ಕನ್ನಡ' : 'English')}
            onClick={toggleLanguage}
            size="small"
            sx={{
              fontWeight: 600,
              fontSize: '0.7rem',
              cursor: 'pointer',
              bgcolor: alpha(theme.palette.primary.main, 0.06),
              color: theme.palette.primary.main,
              '&:hover': {
                bgcolor: alpha(theme.palette.primary.main, 0.12),
              },
            }}
            aria-label={`Language: ${locale === 'en' ? 'English' : 'Kannada'}. Click to switch.`}
          />
        </Tooltip>

        {/* Collapse/Expand Toggle */}
        <Tooltip
          title={collapsed ? t('nav.expand', 'Expand sidebar') : t('nav.collapse', 'Collapse sidebar')}
          placement="right"
          enterDelay={300}
        >
          <IconButton
            ref={collapseButtonRef}
            onClick={handleCollapseToggle}
            size="small"
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            sx={{
              color: theme.palette.text.secondary,
              bgcolor: alpha(theme.palette.primary.main, 0.04),
              borderRadius: 2,
              width: 32,
              height: 32,
              border: `1px solid ${theme.palette.divider}`,
              '&:hover': {
                bgcolor: alpha(theme.palette.secondary.main, 0.1),
                color: theme.palette.secondary.main,
                borderColor: theme.palette.secondary.main,
              },
              transition: 'all 200ms ease',
            }}
          >
            {collapsed ? (
              <KeyboardDoubleArrowRightIcon sx={{ fontSize: 16 }} />
            ) : (
              <KeyboardDoubleArrowLeftIcon sx={{ fontSize: 16 }} />
            )}
          </IconButton>
        </Tooltip>
      </Box>
    </Box>
  );

  // ─── Render ────────────────────────────────────────────────────────
  return (
    <Box
      component="nav"
      sx={{
        width: { md: width },
        flexShrink: { md: 0 },
      }}
    >
      {/* Mobile Drawer (temporary overlay, viewport < 900px) */}
      <Drawer
        variant="temporary"
        open={mobileOpen}
        onClose={onClose}
        ModalProps={{ keepMounted: true }}
        sx={{
          display: { xs: 'block', md: 'none' },
          '& .MuiDrawer-paper': {
            width: SIDEBAR_WIDTH,
            borderRight: 'none',
            bgcolor: alpha(theme.palette.background.paper, 0.92),
            backdropFilter: 'blur(16px)',
          },
        }}
      >
        {drawerContent}
      </Drawer>

      {/* Desktop Drawer (permanent, viewport ≥ 900px) */}
      <Drawer
        variant="permanent"
        open
        sx={{
          display: { xs: 'none', md: 'block' },
          '& .MuiDrawer-paper': {
            width,
            borderRight: 'none',
            transition: 'width 250ms cubic-bezier(0.4, 0, 0.2, 1)',
            bgcolor: alpha(theme.palette.background.paper, 0.85),
            backdropFilter: 'blur(16px)',
            boxShadow: `1px 0 0 ${alpha(theme.palette.divider, 0.6)}`,
            overflow: 'hidden',
          },
        }}
      >
        {drawerContent}
      </Drawer>

      {/* Logout Confirmation Dialog */}
      <Dialog
        open={logoutDialogOpen}
        onClose={() => setLogoutDialogOpen(false)}
        maxWidth="xs"
      >
        <DialogTitle>{t('nav.logout', 'Logout')}</DialogTitle>
        <DialogContent>
          <DialogContentText>
            {t('nav.logoutConfirmation', 'Are you sure you want to logout?')}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setLogoutDialogOpen(false)}>
            {t('common.cancel', 'Cancel')}
          </Button>
          <Button
            variant="contained"
            color="error"
            onClick={handleLogoutConfirm}
          >
            {t('nav.logout', 'Logout')}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Sidebar;

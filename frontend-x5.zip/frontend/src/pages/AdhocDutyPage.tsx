import React, { useEffect, useState, useCallback } from 'react';
import {
  Alert,
  Box,
  Button,
  Collapse,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  IconButton,
  InputLabel,
  MenuItem,
  Paper,
  Select,
  Skeleton,
  Snackbar,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import CancelIcon from '@mui/icons-material/Cancel';
import VisibilityIcon from '@mui/icons-material/Visibility';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import TableChartIcon from '@mui/icons-material/TableChart';
import FilterListIcon from '@mui/icons-material/FilterList';
import { useNavigate } from 'react-router-dom';
import {
  cycleService,
  type AdhocDutyResponse,
} from '@/services/cycleService';
import PageHeader from '@/components/common/PageHeader';
import StatusBadge from '@/components/common/StatusBadge';
import DataTable, { type Column } from '@/components/DataTable';

/**
 * Maps backend status strings (uppercase) to StatusBadge-compatible display strings.
 */
function toDisplayStatus(status: string): string {
  switch (status) {
    case 'ACTIVE': return 'Active';
    case 'COMPLETED': return 'Completed';
    case 'CANCELLED': return 'Cancelled';
    default: return status;
  }
}

const AdhocDutyPage: React.FC = () => {
  const navigate = useNavigate();
  const [duties, setDuties] = useState<AdhocDutyResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterDate, setFilterDate] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filtersExpanded, setFiltersExpanded] = useState(true);
  const [snackbar, setSnackbar] = useState<{ open: boolean; message: string; severity: 'success' | 'error' }>({
    open: false, message: '', severity: 'success'
  });

  // Detail dialog
  const [detailOpen, setDetailOpen] = useState(false);
  const [detailDuty, setDetailDuty] = useState<AdhocDutyResponse | null>(null);

  // Cancel confirmation
  const [cancelId, setCancelId] = useState<number | null>(null);

  const fetchDuties = useCallback(async () => {
    setLoading(true);
    try {
      // Note: Adhoc duty expiry is now handled by a scheduled backend job
      // that runs daily at 3:00 AM. See: StatusUpdateSchedulerService.java
      
      const data = await cycleService.getAdhocDuties(
        filterDate || undefined,
        filterStatus || undefined
      );
      setDuties(data);
    } catch {
      setSnackbar({ open: true, message: 'Failed to fetch adhoc duties', severity: 'error' });
    } finally {
      setLoading(false);
    }
  }, [filterDate, filterStatus]);

  useEffect(() => { fetchDuties(); }, [fetchDuties]);

  const handleCancel = async () => {
    if (!cancelId) return;
    try {
      await cycleService.cancelAdhocDuty(cancelId);
      setSnackbar({ open: true, message: 'Adhoc duty cancelled', severity: 'success' });
      setCancelId(null);
      fetchDuties();
    } catch {
      setSnackbar({ open: true, message: 'Failed to cancel', severity: 'error' });
    }
  };

  const handleViewDetail = async (id: number) => {
    try {
      const detail = await cycleService.getAdhocDutyById(id);
      setDetailDuty(detail);
      setDetailOpen(true);
    } catch {
      setSnackbar({ open: true, message: 'Failed to fetch details', severity: 'error' });
    }
  };

  const handleDownload = async (id: number, format: 'pdf' | 'excel') => {
    try {
      const blob = format === 'pdf'
        ? await cycleService.downloadAdhocPdf(id)
        : await cycleService.downloadAdhocExcel(id);
      const url = URL.createObjectURL(new Blob([blob]));
      const link = document.createElement('a');
      link.href = url;
      link.download = `adhoc-duty-${id}.${format === 'pdf' ? 'pdf' : 'xlsx'}`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch {
      setSnackbar({ open: true, message: 'Download failed', severity: 'error' });
    }
  };

  // DataTable columns with StatusBadge for status column
  const columns: Column<AdhocDutyResponse>[] = [
    { id: 'id', labelKey: 'adhoc.id', width: 60 },
    { id: 'dutyName', labelKey: 'adhoc.dutyName', minWidth: 160 },
    { id: 'date', labelKey: 'adhoc.date', width: 110 },
    {
      id: 'startTime',
      labelKey: 'adhoc.time',
      render: (row) => <Typography variant="body2">{row.startTime} - {row.endTime}</Typography>,
    },
    { id: 'location', labelKey: 'adhoc.location', render: (row) => <>{row.location || '-'}</> },
    { id: 'requiredCount', labelKey: 'adhoc.required', width: 80 },
    { id: 'actualCount', labelKey: 'adhoc.actual', width: 80 },
    {
      id: 'status',
      labelKey: 'adhoc.status',
      render: (row) => <StatusBadge status={toDisplayStatus(row.status)} size="small" />,
    },
  ];

  // Skeleton loading for the table area
  const renderSkeleton = () => (
    <Box sx={{ p: 2 }}>
      {/* Filter skeleton */}
      <Stack direction="row" spacing={2} sx={{ mb: 3 }}>
        <Skeleton variant="rounded" width={200} height={40} />
        <Skeleton variant="rounded" width={180} height={40} />
      </Stack>
      {/* Table skeleton */}
      <Skeleton variant="rounded" width="100%" height={40} sx={{ mb: 1 }} />
      {Array.from({ length: 6 }).map((_, i) => (
        <Skeleton key={i} variant="rounded" width="100%" height={36} sx={{ mb: 0.5 }} />
      ))}
    </Box>
  );

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', bgcolor: 'background.default' }}>
      {/* PageHeader replaces gradient banner */}
      <PageHeader
        title="Adhoc Duties"
        breadcrumbs={[
          { label: 'Home', path: '/' },
          { label: 'Adhoc Duties' },
        ]}
        actions={[
          {
            label: 'Create Duty',
            variant: 'primary',
            icon: <AddIcon />,
            onClick: () => navigate('/schedules/adhoc/create'),
          },
        ]}
      />

      {/* Main Content */}
      <Box sx={{ flex: 1, p: 3 }}>
        {/* Collapsible Filter Panel */}
        <Box sx={{ mb: 2 }}>
          <Button
            size="small"
            startIcon={<FilterListIcon />}
            onClick={() => setFiltersExpanded((prev) => !prev)}
            sx={{
              textTransform: 'none',
              fontWeight: 500,
              fontSize: '0.82rem',
              color: filtersExpanded ? 'primary.main' : 'text.secondary',
              mb: 1,
            }}
          >
            {filtersExpanded ? 'Hide Filters' : 'Show Filters'}
          </Button>
          <Collapse in={filtersExpanded}>
            <Box
              sx={{
                display: 'flex',
                gap: 2,
                flexWrap: 'wrap',
                alignItems: 'flex-end',
                p: 2,
                bgcolor: 'action.hover',
                borderRadius: 2,
                border: (theme) => `1px solid ${theme.palette.divider}`,
              }}
            >
              <TextField
                type="date"
                label="Date"
                value={filterDate}
                onChange={(e) => setFilterDate(e.target.value)}
                InputLabelProps={{ shrink: true }}
                size="small"
                sx={{ width: 200 }}
              />
              <FormControl size="small" sx={{ width: 180 }}>
                <InputLabel>Status</InputLabel>
                <Select
                  value={filterStatus}
                  label="Status"
                  onChange={(e) => setFilterStatus(e.target.value)}
                >
                  <MenuItem value="">All</MenuItem>
                  <MenuItem value="ACTIVE">Active</MenuItem>
                  <MenuItem value="COMPLETED">Completed</MenuItem>
                  <MenuItem value="CANCELLED">Cancelled</MenuItem>
                </Select>
              </FormControl>
              <Typography variant="body2" sx={{ alignSelf: 'center', color: 'text.secondary' }}>
                Total: {duties.length} records
              </Typography>
            </Box>
          </Collapse>
        </Box>

        {/* DataTable with skeleton loading and empty state */}
        {loading ? (
          renderSkeleton()
        ) : (
          <DataTable<AdhocDutyResponse>
            columns={columns}
            data={duties}
            keyField="id"
            dense
            actions={(row) => (
              <Stack direction="row" spacing={0.5}>
                <Tooltip title="View Details">
                  <IconButton size="small" onClick={() => handleViewDetail(row.id)}>
                    <VisibilityIcon fontSize="small" />
                  </IconButton>
                </Tooltip>
                {row.status === 'ACTIVE' && (
                  <Tooltip title="Cancel">
                    <IconButton size="small" color="error" onClick={() => setCancelId(row.id)}>
                      <CancelIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                )}
                <Tooltip title="Download PDF">
                  <IconButton size="small" onClick={() => handleDownload(row.id, 'pdf')}>
                    <PictureAsPdfIcon fontSize="small" />
                  </IconButton>
                </Tooltip>
                <Tooltip title="Download Excel">
                  <IconButton size="small" onClick={() => handleDownload(row.id, 'excel')}>
                    <TableChartIcon fontSize="small" />
                  </IconButton>
                </Tooltip>
              </Stack>
            )}
          />
        )}
      </Box>

      {/* Detail Dialog */}
      <Dialog open={detailOpen} onClose={() => setDetailOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>Adhoc Duty Details</DialogTitle>
        <DialogContent>
          {detailDuty && (
            <Stack spacing={2} sx={{ mt: 1 }}>
              <Stack direction="row" spacing={4}>
                <Typography><strong>Name:</strong> {detailDuty.dutyName}</Typography>
                <Typography><strong>Date:</strong> {detailDuty.date}</Typography>
                <Typography><strong>Time:</strong> {detailDuty.startTime} - {detailDuty.endTime}</Typography>
              </Stack>
              <Stack direction="row" spacing={4} alignItems="center">
                <Typography><strong>Location:</strong> {detailDuty.location || '-'}</Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Typography><strong>Status:</strong></Typography>
                  <StatusBadge status={toDisplayStatus(detailDuty.status)} size="small" />
                </Box>
                <Typography><strong>Personnel:</strong> {detailDuty.actualCount}/{detailDuty.requiredCount}</Typography>
              </Stack>
              {detailDuty.assignees && detailDuty.assignees.length > 0 && (
                <TableContainer component={Paper} variant="outlined">
                  <Table size="small">
                    <TableHead>
                      <TableRow sx={{ bgcolor: 'action.hover' }}>
                        <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem' }}>#</TableCell>
                        <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem' }}>Name</TableCell>
                        <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem' }}>Badge ID</TableCell>
                        <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem' }}>Designation</TableCell>
                        <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem' }}>Section</TableCell>
                        <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem' }}>Original Duty</TableCell>
                        <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem' }}>Original Shift</TableCell>
                        <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem' }}>Status</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {detailDuty.assignees.map((a, idx) => (
                        <TableRow key={a.personId}>
                          <TableCell>{idx + 1}</TableCell>
                          <TableCell>{a.personName}</TableCell>
                          <TableCell>{a.badgeId}</TableCell>
                          <TableCell>{a.designation}</TableCell>
                          <TableCell>{a.section}</TableCell>
                          <TableCell>{a.originalDutyName}</TableCell>
                          <TableCell>{a.originalShift}</TableCell>
                          <TableCell>
                            <StatusBadge status={a.status} size="small" />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}
              <Stack direction="row" spacing={1}>
                <Button startIcon={<PictureAsPdfIcon />} onClick={() => handleDownload(detailDuty.id, 'pdf')}>
                  Download PDF
                </Button>
                <Button startIcon={<TableChartIcon />} onClick={() => handleDownload(detailDuty.id, 'excel')}>
                  Download Excel
                </Button>
              </Stack>
            </Stack>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDetailOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>

      {/* Cancel Confirmation */}
      <Dialog open={cancelId !== null} onClose={() => setCancelId(null)}>
        <DialogTitle>Cancel Adhoc Duty</DialogTitle>
        <DialogContent>
          <Typography>Are you sure you want to cancel this adhoc duty? All assigned personnel will be released back to their regular duties.</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setCancelId(null)}>No, Keep It</Button>
          <Button variant="contained" color="error" onClick={handleCancel}>Yes, Cancel</Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar */}
      <Snackbar open={snackbar.open} autoHideDuration={4000} onClose={() => setSnackbar(s => ({ ...s, open: false }))}>
        <Alert severity={snackbar.severity}>{snackbar.message}</Alert>
      </Snackbar>
    </Box>
  );
};

export default AdhocDutyPage;

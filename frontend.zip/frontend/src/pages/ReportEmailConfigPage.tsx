import React, { useEffect, useState } from 'react';
import { observer } from 'mobx-react-lite';
import {
  Box,
  Typography,
  Paper,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  OutlinedInput,
  Checkbox,
  ListItemText,
  Alert,
  CircularProgress,
  Tooltip,
  alpha,
  Snackbar,
  FormControlLabel,
  Switch,
  ToggleButton,
  ToggleButtonGroup,
  Divider,
  Stack,
  InputAdornment,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import EmailIcon from '@mui/icons-material/Email';
import DescriptionIcon from '@mui/icons-material/Description';
import ScheduleIcon from '@mui/icons-material/Schedule';
import SettingsIcon from '@mui/icons-material/Settings';
import PersonIcon from '@mui/icons-material/Person';
import AssessmentIcon from '@mui/icons-material/Assessment';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import { useTranslation } from 'react-i18next';
import { reportEmailConfigStore } from '@/stores/reportEmailConfigStore';
import { ReportEmailConfig, ReportSpecificEmailConfig } from '@/services/reportEmailConfigApi';
import { userApi, UserDto, CreateUserRequest } from '@/services/userApi';
import PageHeader from '@/components/common/PageHeader';

// Days of week for schedule selection
const DAYS_OF_WEEK = [
  { value: 'SUN', label: 'S', fullLabel: 'Sunday' },
  { value: 'MON', label: 'M', fullLabel: 'Monday' },
  { value: 'TUE', label: 'T', fullLabel: 'Tuesday' },
  { value: 'WED', label: 'W', fullLabel: 'Wednesday' },
  { value: 'THU', label: 'T', fullLabel: 'Thursday' },
  { value: 'FRI', label: 'F', fullLabel: 'Friday' },
  { value: 'SAT', label: 'S', fullLabel: 'Saturday' },
];

// Available user roles
const USER_ROLES = [
  { value: 'ADMIN', label: 'Admin' },
  { value: 'HIGHER_OFFICER', label: 'Higher Officer' },
  { value: 'GENERAL_USER', label: 'General User' },
  { value: 'SUPPORT_ADMIN', label: 'Support Admin' },
];

/**
 * ReportEmailConfigPage - Configuration tab under Administration
 * Contains three tabs:
 * 1. Reports Configuration - Generate Reports Configuration
 * 2. Email Configuration - Report Specific Email Configuration
 * 3. User Configuration - User management
 */
const ReportEmailConfigPage: React.FC = observer(() => {
  const { t } = useTranslation();
  const store = reportEmailConfigStore;
  
  // Active tab state
  const [activeTab, setActiveTab] = useState(0);
  const CONFIG_TABS = ['Reports Configuration', 'Email Configuration', 'User Configuration'];

  // User management state
  const [users, setUsers] = useState<UserDto[]>([]);
  const [usersLoading, setUsersLoading] = useState(false);
  const [userDialogOpen, setUserDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<UserDto | null>(null);
  const [userForm, setUserForm] = useState<CreateUserRequest & { confirmPassword: string }>({
    username: '',
    password: '',
    confirmPassword: '',
    displayName: '',
    email: '',
    role: 'GENERAL_USER',
    locale: 'en',
  });
  const [userFormErrors, setUserFormErrors] = useState<Record<string, string>>({});
  const [userSaving, setUserSaving] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [deleteUserDialogOpen, setDeleteUserDialogOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState<UserDto | null>(null);

  // Local form state for Generate Reports Configuration
  // Note: subjectTitle and emailBody are auto-populated from report_specific_email_config
  const [generateForm, setGenerateForm] = useState<ReportEmailConfig>({
    subjectTitle: '', // Auto-populated based on selected reports
    emailIds: [],
    emailBody: '', // Auto-populated based on selected reports
    selectedReports: [],
    isActive: true,
  });
  const [emailInput, setEmailInput] = useState('');
  const [generateFormErrors, setGenerateFormErrors] = useState<Record<string, string>>({});

  // Local form state for Report Specific Email Configuration
  const [specificForm, setSpecificForm] = useState<ReportSpecificEmailConfig>({
    reportType: '',
    reportName: '',
    emailSubject: '',
    emailBody: '',
    scheduleDays: [],
    scheduleTime: '06:00',
    isScheduleEnabled: false,
  });
  const [specificFormErrors, setSpecificFormErrors] = useState<Record<string, string>>({});

  // Snackbar state
  const [snackbar, setSnackbar] = useState<{ open: boolean; message: string; severity: 'success' | 'error' }>({
    open: false,
    message: '',
    severity: 'success',
  });

  useEffect(() => {
    store.loadAllData();
  }, []);

  // Load users when User Configuration tab is active
  useEffect(() => {
    if (activeTab === 2) {
      loadUsers();
    }
  }, [activeTab]);

  // ─── User Management Functions ─────────────────────────────────────────────

  const loadUsers = async () => {
    setUsersLoading(true);
    try {
      const data = await userApi.getAll();
      setUsers(data);
    } catch (error) {
      console.error('Failed to load users:', error);
      setSnackbar({ open: true, message: 'Failed to load users', severity: 'error' });
    } finally {
      setUsersLoading(false);
    }
  };

  const validateUserForm = (): boolean => {
    const errors: Record<string, string> = {};
    
    if (!userForm.username.trim()) {
      errors.username = 'Username is required';
    } else if (userForm.username.length < 3) {
      errors.username = 'Username must be at least 3 characters';
    }
    
    if (!userForm.displayName.trim()) {
      errors.displayName = 'Display name is required';
    }
    
    // Password validation only for new users or when password is provided for edit
    if (!editingUser || userForm.password) {
      if (!editingUser && !userForm.password) {
        errors.password = 'Password is required';
      } else if (userForm.password && userForm.password.length < 6) {
        errors.password = 'Password must be at least 6 characters';
      }
      
      if (userForm.password !== userForm.confirmPassword) {
        errors.confirmPassword = 'Passwords do not match';
      }
    }
    
    if (userForm.email && !/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(userForm.email)) {
      errors.email = 'Invalid email format';
    }
    
    if (!userForm.role) {
      errors.role = 'Role is required';
    }
    
    setUserFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleOpenUserDialog = (user?: UserDto) => {
    if (user) {
      setEditingUser(user);
      setUserForm({
        username: user.username,
        password: '',
        confirmPassword: '',
        displayName: user.displayName,
        email: user.email || '',
        role: user.role,
        locale: user.locale || 'en',
        personnelId: user.personnelId,
      });
    } else {
      setEditingUser(null);
      setUserForm({
        username: '',
        password: '',
        confirmPassword: '',
        displayName: '',
        email: '',
        role: 'GENERAL_USER',
        locale: 'en',
      });
    }
    setUserFormErrors({});
    setShowPassword(false);
    setShowConfirmPassword(false);
    setUserDialogOpen(true);
  };

  const handleCloseUserDialog = () => {
    setUserDialogOpen(false);
    setEditingUser(null);
    setUserFormErrors({});
  };

  const handleSaveUser = async () => {
    if (!validateUserForm()) return;
    
    setUserSaving(true);
    try {
      const request: CreateUserRequest = {
        username: userForm.username.trim(),
        password: userForm.password,
        displayName: userForm.displayName.trim(),
        email: userForm.email?.trim() || undefined,
        role: userForm.role,
        locale: userForm.locale || 'en',
        personnelId: userForm.personnelId || undefined,
      };
      
      if (editingUser) {
        // For update, only include password if it was changed
        if (!request.password) {
          delete (request as any).password;
        }
        await userApi.update(editingUser.id, request);
        setSnackbar({ open: true, message: 'User updated successfully', severity: 'success' });
      } else {
        await userApi.create(request);
        setSnackbar({ open: true, message: 'User created successfully', severity: 'success' });
      }
      
      handleCloseUserDialog();
      loadUsers();
    } catch (error: any) {
      const message = error.response?.data?.message || error.response?.data?.error || 'Failed to save user';
      setSnackbar({ open: true, message, severity: 'error' });
    } finally {
      setUserSaving(false);
    }
  };

  const handleOpenDeleteUserDialog = (user: UserDto) => {
    setUserToDelete(user);
    setDeleteUserDialogOpen(true);
  };

  const handleCloseDeleteUserDialog = () => {
    setDeleteUserDialogOpen(false);
    setUserToDelete(null);
  };

  const handleDeleteUser = async () => {
    if (!userToDelete) return;
    
    try {
      await userApi.delete(userToDelete.id);
      setSnackbar({ open: true, message: 'User deleted successfully', severity: 'success' });
      handleCloseDeleteUserDialog();
      loadUsers();
    } catch (error: any) {
      const message = error.response?.data?.message || error.response?.data?.error || 'Failed to delete user';
      setSnackbar({ open: true, message, severity: 'error' });
    }
  };

  const getRoleChipColor = (role: string): 'error' | 'warning' | 'info' | 'success' => {
    switch (role) {
      case 'ADMIN': return 'error';
      case 'HIGHER_OFFICER': return 'warning';
      case 'SUPPORT_ADMIN': return 'info';
      default: return 'success';
    }
  };

  // Reset generate form when dialog opens/closes
  useEffect(() => {
    if (store.generateConfigDialogOpen) {
      if (store.editingGenerateConfig) {
        setGenerateForm({
          subjectTitle: '', // Auto-populated from report_specific_email_config
          emailIds: store.editingGenerateConfig.emailIds,
          emailBody: '', // Auto-populated from report_specific_email_config
          selectedReports: store.editingGenerateConfig.selectedReports,
          isActive: store.editingGenerateConfig.isActive ?? true,
        });
      } else {
        setGenerateForm({
          subjectTitle: '',
          emailIds: [],
          emailBody: '',
          selectedReports: [],
          isActive: true,
        });
      }
      setEmailInput('');
      setGenerateFormErrors({});
    }
  }, [store.generateConfigDialogOpen, store.editingGenerateConfig]);

  // Reset specific form when dialog opens/closes
  useEffect(() => {
    if (store.specificConfigDialogOpen) {
      if (store.editingSpecificConfig) {
        setSpecificForm({
          reportType: store.editingSpecificConfig.reportType,
          reportName: store.editingSpecificConfig.reportName,
          emailSubject: store.editingSpecificConfig.emailSubject,
          emailBody: store.editingSpecificConfig.emailBody,
          scheduleDays: store.editingSpecificConfig.scheduleDays || [],
          scheduleTime: store.editingSpecificConfig.scheduleTime || '06:00',
          isScheduleEnabled: store.editingSpecificConfig.isScheduleEnabled || false,
        });
      } else {
        setSpecificForm({
          reportType: '',
          reportName: '',
          emailSubject: '',
          emailBody: '',
          scheduleDays: [],
          scheduleTime: '06:00',
          isScheduleEnabled: false,
        });
      }
      setSpecificFormErrors({});
    }
  }, [store.specificConfigDialogOpen, store.editingSpecificConfig]);

  // ─── Validation ────────────────────────────────────────────────────────────

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email.trim());
  };

  const validateGenerateForm = (): boolean => {
    const errors: Record<string, string> = {};
    // Subject Title and Email Body are auto-populated from report_specific_email_config
    if (generateForm.emailIds.length === 0) {
      errors.emailIds = 'At least one Email ID is mandatory';
    }
    if (generateForm.selectedReports.length === 0) {
      errors.selectedReports = 'At least one report must be selected';
    }
    setGenerateFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const validateSpecificForm = (): boolean => {
    const errors: Record<string, string> = {};
    if (!specificForm.reportType.trim()) {
      errors.reportType = 'Report Name is mandatory';
    }
    if (!specificForm.emailSubject.trim()) {
      errors.emailSubject = 'Email Subject is mandatory';
    }
    if (!specificForm.emailBody.trim()) {
      errors.emailBody = 'Email Body is mandatory';
    }
    setSpecificFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // ─── Handlers: Generate Reports Configuration ──────────────────────────────

  const handleAddEmail = () => {
    if (emailInput.trim()) {
      if (!validateEmail(emailInput)) {
        setGenerateFormErrors({ ...generateFormErrors, emailInput: 'Invalid email format' });
        return;
      }
      if (!generateForm.emailIds.includes(emailInput.trim())) {
        setGenerateForm({
          ...generateForm,
          emailIds: [...generateForm.emailIds, emailInput.trim()],
        });
      }
      setEmailInput('');
      setGenerateFormErrors({ ...generateFormErrors, emailInput: '', emailIds: '' });
    }
  };

  const handleRemoveEmail = (email: string) => {
    setGenerateForm({
      ...generateForm,
      emailIds: generateForm.emailIds.filter((e) => e !== email),
    });
  };

  const handleSaveGenerateConfig = async () => {
    if (!validateGenerateForm()) return;
    const success = await store.saveGenerateConfig(generateForm);
    if (success) {
      setSnackbar({ open: true, message: 'Configuration saved successfully', severity: 'success' });
    } else {
      setSnackbar({ open: true, message: store.error || 'Failed to save configuration', severity: 'error' });
    }
  };

  // ─── Handlers: Report Specific Email Configuration ─────────────────────────

  const handleReportTypeChange = (reportType: string) => {
    const report = store.availableReports.find((r) => r.reportType === reportType);
    setSpecificForm({
      ...specificForm,
      reportType,
      reportName: report?.reportName || '',
    });
  };

  // Handler for day selection toggle
  const handleDayToggle = (day: string) => {
    const currentDays = specificForm.scheduleDays || [];
    const newDays = currentDays.includes(day)
      ? currentDays.filter((d) => d !== day)
      : [...currentDays, day];
    setSpecificForm({ ...specificForm, scheduleDays: newDays });
  };

  // Handler for select all days
  const handleSelectAllDays = () => {
    const allDays = DAYS_OF_WEEK.map((d) => d.value);
    const currentDays = specificForm.scheduleDays || [];
    const allSelected = allDays.every((day) => currentDays.includes(day));
    setSpecificForm({
      ...specificForm,
      scheduleDays: allSelected ? [] : allDays,
    });
  };

  const handleSaveSpecificConfig = async () => {
    if (!validateSpecificForm()) return;
    const success = await store.saveSpecificConfig(specificForm);
    if (success) {
      setSnackbar({ open: true, message: 'Configuration saved successfully', severity: 'success' });
    } else {
      setSnackbar({ open: true, message: store.error || 'Failed to save configuration', severity: 'error' });
    }
  };

  // ─── Handlers: Delete ──────────────────────────────────────────────────────

  const handleConfirmDelete = async () => {
    const success = await store.confirmDelete();
    if (success) {
      setSnackbar({ open: true, message: 'Configuration deleted successfully', severity: 'success' });
    } else {
      setSnackbar({ open: true, message: store.error || 'Failed to delete configuration', severity: 'error' });
    }
  };

  // ─── Render ────────────────────────────────────────────────────────────────

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', bgcolor: 'background.default' }}>
      <PageHeader
        title={t('admin.configuration.title', 'Configuration')}
        breadcrumbs={[
          { label: t('nav.home', 'Home'), path: '/' },
          { label: t('admin.configuration.title', 'Configuration') },
        ]}
      />

      <Box sx={{ flex: 1, px: { xs: 2, md: 3 }, py: 2 }}>
        {/* Toggle Tab Navigation */}
        <Box sx={{ mb: 3, display: 'inline-flex', bgcolor: '#f1f5f9', borderRadius: '10px', p: '4px', gap: '4px' }}>
          {CONFIG_TABS.map((label, idx) => (
            <Box
              key={label}
              onClick={() => setActiveTab(idx)}
              sx={{
                px: 2.5,
                py: 1,
                borderRadius: '8px',
                cursor: 'pointer',
                fontWeight: 600,
                fontSize: '0.82rem',
                transition: 'all 0.2s ease',
                userSelect: 'none',
                display: 'flex',
                alignItems: 'center',
                gap: 1,
                ...(activeTab === idx
                  ? { bgcolor: '#fff', color: '#312e81', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }
                  : { bgcolor: 'transparent', color: '#64748b', '&:hover': { color: '#312e81' } }
                ),
              }}
            >
              {idx === 0 && <AssessmentIcon sx={{ fontSize: 18 }} />}
              {idx === 1 && <EmailIcon sx={{ fontSize: 18 }} />}
              {idx === 2 && <PersonIcon sx={{ fontSize: 18 }} />}
              {label}
            </Box>
          ))}
        </Box>

        {store.loading && (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
            <CircularProgress />
          </Box>
        )}

        {store.error && (
          <Alert severity="error" sx={{ mb: 2 }} onClose={() => store.clearError()}>
            {store.error}
          </Alert>
        )}

        {/* TAB 0: Reports Configuration */}
        {activeTab === 0 && (
          <>
        {/* Section 1: Generate Reports Configuration */}
        <Paper elevation={0} sx={{ mb: 3, border: '1px solid', borderColor: 'divider', borderRadius: 2 }}>
          <Box sx={{ px: 3, py: 2, borderBottom: '1px solid', borderColor: 'divider', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <EmailIcon sx={{ color: 'primary.main' }} />
              <Typography variant="h6" sx={{ fontWeight: 600 }}>
                {t('admin.configuration.generateReports', 'Generate Reports Configuration')}
              </Typography>
            </Box>
            <Button
              variant="contained"
              startIcon={<AddIcon />}
              onClick={() => store.openGenerateConfigDialog()}
              size="small"
            >
              {t('common.add', 'Add')}
            </Button>
          </Box>

          <TableContainer>
            <Table>
              <TableHead>
                <TableRow sx={{ bgcolor: alpha('#0d9488', 0.04) }}>
                  <TableCell sx={{ fontWeight: 600 }}>{t('admin.configuration.emailIds', 'Email IDs')}</TableCell>
                  <TableCell sx={{ fontWeight: 600 }}>{t('admin.configuration.reportsSelection', 'Reports Selection')}</TableCell>
                  <TableCell sx={{ fontWeight: 600 }} align="center">{t('common.actions', 'Actions')}</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {store.reportEmailConfigs.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={3} align="center" sx={{ py: 4, color: 'text.secondary' }}>
                      {t('admin.configuration.noConfigs', 'No configurations found. Click "Add" to create one.')}
                    </TableCell>
                  </TableRow>
                ) : (
                  store.reportEmailConfigs.map((config) => (
                    <TableRow key={config.id} hover>
                      <TableCell>
                        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                          {config.emailIds.slice(0, 2).map((email) => (
                            <Chip key={email} label={email} size="small" />
                          ))}
                          {config.emailIds.length > 2 && (
                            <Chip label={`+${config.emailIds.length - 2} more`} size="small" variant="outlined" />
                          )}
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                          {config.selectedReports.slice(0, 2).map((reportType) => (
                            <Chip key={reportType} label={store.getReportNameByType(reportType)} size="small" color="primary" variant="outlined" />
                          ))}
                          {config.selectedReports.length > 2 && (
                            <Chip label={`+${config.selectedReports.length - 2} more`} size="small" variant="outlined" />
                          )}
                        </Box>
                      </TableCell>
                      <TableCell align="center">
                        <Tooltip title={t('common.edit', 'Edit')}>
                          <IconButton size="small" onClick={() => store.openGenerateConfigDialog(config)}>
                            <EditIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title={t('common.delete', 'Delete')}>
                          <IconButton size="small" color="error" onClick={() => store.openDeleteConfirmDialog('generate', config.id!)}>
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
          </>
        )}

        {/* TAB 1: Email Configuration */}
        {activeTab === 1 && (
        <Paper elevation={0} sx={{ border: '1px solid', borderColor: 'divider', borderRadius: 2 }}>
          <Box sx={{ px: 3, py: 2, borderBottom: '1px solid', borderColor: 'divider', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <DescriptionIcon sx={{ color: 'secondary.main' }} />
              <Typography variant="h6" sx={{ fontWeight: 600 }}>
                {t('admin.configuration.reportSpecific', 'Report Specific Email Configuration')}
              </Typography>
            </Box>
            <Button
              variant="contained"
              color="secondary"
              startIcon={<AddIcon />}
              onClick={() => store.openSpecificConfigDialog()}
              size="small"
            >
              {t('common.add', 'Add')}
            </Button>
          </Box>

          <TableContainer>
            <Table>
              <TableHead>
                <TableRow sx={{ bgcolor: alpha('#312e81', 0.04) }}>
                  <TableCell sx={{ fontWeight: 600 }}>{t('admin.configuration.reportName', 'Report Name')}</TableCell>
                  <TableCell sx={{ fontWeight: 600 }}>{t('admin.configuration.emailSubject', 'Email Subject')}</TableCell>
                  <TableCell sx={{ fontWeight: 600 }}>{t('admin.configuration.schedule', 'Schedule')}</TableCell>
                  <TableCell sx={{ fontWeight: 600 }} align="center">{t('common.actions', 'Actions')}</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {store.reportSpecificEmailConfigs.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} align="center" sx={{ py: 4, color: 'text.secondary' }}>
                      {t('admin.configuration.noSpecificConfigs', 'No report-specific configurations found. Click "Add" to create one.')}
                    </TableCell>
                  </TableRow>
                ) : (
                  store.reportSpecificEmailConfigs.map((config) => (
                    <TableRow key={config.id} hover>
                      <TableCell>
                        <Chip label={config.reportName} color="secondary" variant="outlined" size="small" />
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2" sx={{ maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          {config.emailSubject}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        {config.isScheduleEnabled ? (
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <ScheduleIcon fontSize="small" color="success" />
                            <Box>
                              <Typography variant="body2" sx={{ fontWeight: 500 }}>
                                {config.scheduleTime}
                              </Typography>
                              <Typography variant="caption" color="text.secondary">
                                {config.scheduleDays?.join(', ') || 'No days'}
                              </Typography>
                            </Box>
                          </Box>
                        ) : (
                          <Chip label="Not Scheduled" size="small" variant="outlined" color="default" />
                        )}
                      </TableCell>
                      <TableCell align="center">
                        <Tooltip title={t('common.edit', 'Edit')}>
                          <IconButton size="small" onClick={() => store.openSpecificConfigDialog(config)}>
                            <EditIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title={t('common.delete', 'Delete')}>
                          <IconButton size="small" color="error" onClick={() => store.openDeleteConfirmDialog('specific', config.id!)}>
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
        )}

        {/* TAB 2: User Configuration */}
        {activeTab === 2 && (
          <Paper elevation={0} sx={{ border: '1px solid', borderColor: 'divider', borderRadius: 2 }}>
            <Box sx={{ px: 3, py: 2, borderBottom: '1px solid', borderColor: 'divider', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <PersonIcon sx={{ color: 'secondary.main' }} />
                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                  {t('admin.configuration.userSettings', 'User Configuration')}
                </Typography>
              </Box>
              <Button
                variant="contained"
                startIcon={<AddIcon />}
                onClick={() => handleOpenUserDialog()}
                size="small"
              >
                {t('admin.configuration.addUser', 'Add User')}
              </Button>
            </Box>

            {usersLoading ? (
              <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
                <CircularProgress />
              </Box>
            ) : (
              <TableContainer>
                <Table>
                  <TableHead>
                    <TableRow sx={{ bgcolor: alpha('#312e81', 0.04) }}>
                      <TableCell sx={{ fontWeight: 600 }}>{t('admin.configuration.username', 'Username')}</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>{t('admin.configuration.displayName', 'Display Name')}</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>{t('admin.configuration.email', 'Email')}</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>{t('admin.configuration.role', 'Role')}</TableCell>
                      <TableCell sx={{ fontWeight: 600 }} align="center">{t('common.actions', 'Actions')}</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {users.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} align="center" sx={{ py: 4, color: 'text.secondary' }}>
                          {t('admin.configuration.noUsers', 'No users found. Click "Add User" to create one.')}
                        </TableCell>
                      </TableRow>
                    ) : (
                      users.map((user) => (
                        <TableRow key={user.id} hover>
                          <TableCell>
                            <Typography variant="body2" sx={{ fontWeight: 500 }}>
                              {user.username}
                            </Typography>
                          </TableCell>
                          <TableCell>{user.displayName}</TableCell>
                          <TableCell>
                            <Typography variant="body2" color="text.secondary">
                              {user.email || '-'}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Chip 
                              label={USER_ROLES.find(r => r.value === user.role)?.label || user.role} 
                              size="small" 
                              color={getRoleChipColor(user.role)}
                              variant="outlined"
                            />
                          </TableCell>
                          <TableCell align="center">
                            <Tooltip title={t('common.edit', 'Edit')}>
                              <IconButton size="small" onClick={() => handleOpenUserDialog(user)}>
                                <EditIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                            <Tooltip title={t('common.delete', 'Delete')}>
                              <IconButton size="small" color="error" onClick={() => handleOpenDeleteUserDialog(user)}>
                                <DeleteIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </Paper>
        )}
      </Box>

      {/* Generate Reports Configuration Dialog */}
      <Dialog open={store.generateConfigDialogOpen} onClose={() => store.closeGenerateConfigDialog()} maxWidth="md" fullWidth>
        <DialogTitle>
          {store.editingGenerateConfig ? t('admin.configuration.editConfig', 'Edit Configuration') : t('admin.configuration.addConfig', 'Add Configuration')}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 1 }}>
            <Alert severity="info" sx={{ mb: 1 }}>
              {t('admin.configuration.autoPopulateInfo', 'Email subject and body will be automatically populated from the Report Specific Email Configuration below. If not configured, default values will be used.')}
            </Alert>

            <Box>
              <Box sx={{ display: 'flex', gap: 1, mb: 1 }}>
                <TextField
                  label={t('admin.configuration.addEmail', 'Add Email')}
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  error={!!generateFormErrors.emailInput}
                  helperText={generateFormErrors.emailInput}
                  size="small"
                  sx={{ flex: 1 }}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddEmail();
                    }
                  }}
                />
                <Button variant="outlined" onClick={handleAddEmail}>
                  {t('common.add', 'Add')}
                </Button>
              </Box>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                {generateForm.emailIds.map((email) => (
                  <Chip
                    key={email}
                    label={email}
                    onDelete={() => handleRemoveEmail(email)}
                    size="small"
                  />
                ))}
              </Box>
              {generateFormErrors.emailIds && (
                <Typography variant="caption" color="error">
                  {generateFormErrors.emailIds}
                </Typography>
              )}
            </Box>

            <FormControl fullWidth error={!!generateFormErrors.selectedReports}>
              <InputLabel>{t('admin.configuration.selectReports', 'Select Reports')}</InputLabel>
              <Select
                multiple
                value={generateForm.selectedReports}
                onChange={(e) => setGenerateForm({ ...generateForm, selectedReports: e.target.value as string[] })}
                input={<OutlinedInput label={t('admin.configuration.selectReports', 'Select Reports')} />}
                renderValue={(selected) => (
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                    {selected.map((value) => (
                      <Chip key={value} label={store.getReportNameByType(value)} size="small" />
                    ))}
                  </Box>
                )}
              >
                {store.availableReports.map((report) => (
                  <MenuItem key={report.reportType} value={report.reportType}>
                    <Checkbox checked={generateForm.selectedReports.includes(report.reportType)} />
                    <ListItemText primary={report.reportName} secondary={report.description} />
                  </MenuItem>
                ))}
              </Select>
              {generateFormErrors.selectedReports && (
                <Typography variant="caption" color="error" sx={{ mt: 0.5, ml: 2 }}>
                  {generateFormErrors.selectedReports}
                </Typography>
              )}
            </FormControl>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => store.closeGenerateConfigDialog()}>{t('common.cancel', 'Cancel')}</Button>
          <Button variant="contained" onClick={handleSaveGenerateConfig} disabled={store.loading}>
            {store.loading ? <CircularProgress size={20} /> : t('common.save', 'Save')}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Report Specific Email Configuration Dialog */}
      <Dialog open={store.specificConfigDialogOpen} onClose={() => store.closeSpecificConfigDialog()} maxWidth="sm" fullWidth>
        <DialogTitle>
          {store.editingSpecificConfig ? t('admin.configuration.editSpecificConfig', 'Edit Report Configuration') : t('admin.configuration.addSpecificConfig', 'Add Report Configuration')}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 1 }}>
            <FormControl fullWidth error={!!specificFormErrors.reportType} required>
              <InputLabel>{t('admin.configuration.reportName', 'Report Name')}</InputLabel>
              <Select
                value={specificForm.reportType}
                onChange={(e) => handleReportTypeChange(e.target.value)}
                label={t('admin.configuration.reportName', 'Report Name')}
                disabled={!!store.editingSpecificConfig}
              >
                {(store.editingSpecificConfig
                  ? store.availableReports
                  : store.getUnconfiguredReports()
                ).map((report) => (
                  <MenuItem key={report.reportType} value={report.reportType}>
                    {report.reportName}
                  </MenuItem>
                ))}
              </Select>
              {specificFormErrors.reportType && (
                <Typography variant="caption" color="error" sx={{ mt: 0.5, ml: 2 }}>
                  {specificFormErrors.reportType}
                </Typography>
              )}
            </FormControl>

            <TextField
              label={t('admin.configuration.emailSubject', 'Email Subject')}
              value={specificForm.emailSubject}
              onChange={(e) => setSpecificForm({ ...specificForm, emailSubject: e.target.value })}
              error={!!specificFormErrors.emailSubject}
              helperText={specificFormErrors.emailSubject}
              fullWidth
              required
            />

            <TextField
              label={t('admin.configuration.emailBody', 'Email Body')}
              value={specificForm.emailBody}
              onChange={(e) => setSpecificForm({ ...specificForm, emailBody: e.target.value })}
              error={!!specificFormErrors.emailBody}
              helperText={specificFormErrors.emailBody}
              multiline
              rows={4}
              fullWidth
              required
            />

            {/* Schedule Section */}
            <Divider sx={{ my: 1 }} />
            <Box>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <ScheduleIcon color="primary" />
                  <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                    {t('admin.configuration.scheduleSettings', 'Email Schedule')}
                  </Typography>
                </Box>
                <FormControlLabel
                  control={
                    <Switch
                      checked={specificForm.isScheduleEnabled || false}
                      onChange={(e) => setSpecificForm({ ...specificForm, isScheduleEnabled: e.target.checked })}
                      color="primary"
                    />
                  }
                  label={t('admin.configuration.enableSchedule', 'Enable')}
                />
              </Box>

              {specificForm.isScheduleEnabled && (
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, p: 2, bgcolor: alpha('#312e81', 0.04), borderRadius: 2 }}>
                  {/* Day Selector */}
                  <Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
                      <Typography variant="body2" sx={{ fontWeight: 500 }}>
                        {t('admin.configuration.selectDays', 'Select Days')}
                      </Typography>
                      <Button size="small" onClick={handleSelectAllDays}>
                        {(specificForm.scheduleDays || []).length === 7 ? 'Clear All' : 'Select All'}
                      </Button>
                    </Box>
                    <Box sx={{ display: 'flex', gap: 0.5, justifyContent: 'center' }}>
                      {DAYS_OF_WEEK.map((day) => (
                        <Tooltip key={day.value} title={day.fullLabel}>
                          <ToggleButton
                            value={day.value}
                            selected={(specificForm.scheduleDays || []).includes(day.value)}
                            onChange={() => handleDayToggle(day.value)}
                            sx={{
                              width: 40,
                              height: 40,
                              borderRadius: '50%',
                              border: '1px solid',
                              borderColor: 'divider',
                              '&.Mui-selected': {
                                bgcolor: 'secondary.main',
                                color: 'white',
                                '&:hover': {
                                  bgcolor: 'secondary.dark',
                                },
                              },
                            }}
                          >
                            {day.label}
                          </ToggleButton>
                        </Tooltip>
                      ))}
                    </Box>
                    {specificFormErrors.scheduleDays && (
                      <Typography variant="caption" color="error" sx={{ mt: 0.5 }}>
                        {specificFormErrors.scheduleDays}
                      </Typography>
                    )}
                  </Box>

                  {/* Time Picker */}
                  <TextField
                    label={t('admin.configuration.scheduleTime', 'Time')}
                    type="time"
                    value={specificForm.scheduleTime || '06:00'}
                    onChange={(e) => setSpecificForm({ ...specificForm, scheduleTime: e.target.value })}
                    fullWidth
                    InputLabelProps={{ shrink: true }}
                    inputProps={{ step: 300 }} // 5 min intervals
                    helperText={t('admin.configuration.scheduleTimeHelp', 'Report will be generated and sent at this time')}
                  />
                </Box>
              )}
            </Box>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => store.closeSpecificConfigDialog()}>{t('common.cancel', 'Cancel')}</Button>
          <Button variant="contained" color="secondary" onClick={handleSaveSpecificConfig} disabled={store.loading}>
            {store.loading ? <CircularProgress size={20} /> : t('common.save', 'Save')}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={store.deleteConfirmDialogOpen} onClose={() => store.closeDeleteConfirmDialog()}>
        <DialogTitle>{t('common.confirmDelete', 'Confirm Delete')}</DialogTitle>
        <DialogContent>
          <Typography>
            {t('admin.configuration.deleteConfirmation', 'Are you sure you want to delete this configuration? This action cannot be undone.')}
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => store.closeDeleteConfirmDialog()}>{t('common.cancel', 'Cancel')}</Button>
          <Button variant="contained" color="error" onClick={handleConfirmDelete} disabled={store.loading}>
            {store.loading ? <CircularProgress size={20} /> : t('common.delete', 'Delete')}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Add/Edit User Dialog */}
      <Dialog open={userDialogOpen} onClose={handleCloseUserDialog} maxWidth="sm" fullWidth>
        <DialogTitle>
          {editingUser ? t('admin.configuration.editUser', 'Edit User') : t('admin.configuration.addUser', 'Add User')}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 1 }}>
            <TextField
              label={t('admin.configuration.username', 'Username')}
              value={userForm.username}
              onChange={(e) => setUserForm({ ...userForm, username: e.target.value })}
              error={!!userFormErrors.username}
              helperText={userFormErrors.username}
              fullWidth
              required
              disabled={!!editingUser}
            />

            <TextField
              label={t('admin.configuration.displayName', 'Display Name')}
              value={userForm.displayName}
              onChange={(e) => setUserForm({ ...userForm, displayName: e.target.value })}
              error={!!userFormErrors.displayName}
              helperText={userFormErrors.displayName}
              fullWidth
              required
            />

            <TextField
              label={t('admin.configuration.email', 'Email')}
              value={userForm.email}
              onChange={(e) => setUserForm({ ...userForm, email: e.target.value })}
              error={!!userFormErrors.email}
              helperText={userFormErrors.email}
              fullWidth
              type="email"
            />

            <TextField
              label={editingUser ? t('admin.configuration.newPassword', 'New Password (leave blank to keep current)') : t('admin.configuration.password', 'Password')}
              value={userForm.password}
              onChange={(e) => setUserForm({ ...userForm, password: e.target.value })}
              error={!!userFormErrors.password}
              helperText={userFormErrors.password}
              fullWidth
              required={!editingUser}
              type={showPassword ? 'text' : 'password'}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      onClick={() => setShowPassword(!showPassword)}
                      edge="end"
                      size="small"
                    >
                      {showPassword ? <VisibilityOffIcon /> : <VisibilityIcon />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />

            <TextField
              label={t('admin.configuration.confirmPassword', 'Confirm Password')}
              value={userForm.confirmPassword}
              onChange={(e) => setUserForm({ ...userForm, confirmPassword: e.target.value })}
              error={!!userFormErrors.confirmPassword}
              helperText={userFormErrors.confirmPassword}
              fullWidth
              required={!editingUser || !!userForm.password}
              type={showConfirmPassword ? 'text' : 'password'}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      edge="end"
                      size="small"
                    >
                      {showConfirmPassword ? <VisibilityOffIcon /> : <VisibilityIcon />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />

            <FormControl fullWidth error={!!userFormErrors.role} required>
              <InputLabel>{t('admin.configuration.role', 'Role')}</InputLabel>
              <Select
                value={userForm.role}
                onChange={(e) => setUserForm({ ...userForm, role: e.target.value })}
                label={t('admin.configuration.role', 'Role')}
              >
                {USER_ROLES.map((role) => (
                  <MenuItem key={role.value} value={role.value}>
                    {role.label}
                  </MenuItem>
                ))}
              </Select>
              {userFormErrors.role && (
                <Typography variant="caption" color="error" sx={{ mt: 0.5, ml: 2 }}>
                  {userFormErrors.role}
                </Typography>
              )}
            </FormControl>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseUserDialog}>{t('common.cancel', 'Cancel')}</Button>
          <Button variant="contained" onClick={handleSaveUser} disabled={userSaving}>
            {userSaving ? <CircularProgress size={20} /> : t('common.save', 'Save')}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete User Confirmation Dialog */}
      <Dialog open={deleteUserDialogOpen} onClose={handleCloseDeleteUserDialog}>
        <DialogTitle>{t('common.confirmDelete', 'Confirm Delete')}</DialogTitle>
        <DialogContent>
          <Typography>
            {t('admin.configuration.deleteUserConfirmation', 'Are you sure you want to delete user')} <strong>{userToDelete?.username}</strong>? {t('admin.configuration.cannotBeUndone', 'This action cannot be undone.')}
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDeleteUserDialog}>{t('common.cancel', 'Cancel')}</Button>
          <Button variant="contained" color="error" onClick={handleDeleteUser}>
            {t('common.delete', 'Delete')}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar for notifications */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert severity={snackbar.severity} onClose={() => setSnackbar({ ...snackbar, open: false })}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
});

export default ReportEmailConfigPage;

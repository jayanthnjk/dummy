package com.policescheduler.report.generator;

import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
import com.policescheduler.report.PdfReportGenerator;
import com.policescheduler.report.PdfStyleHelper;
import com.policescheduler.report.ReportDataService;
import com.policescheduler.report.ReportGenerationException;
import com.policescheduler.report.ReportLocalizationService;
import com.policescheduler.report.ReportRequest;
import com.policescheduler.report.dto.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SectionABReportGenerator implements PdfReportGenerator {

    private static final Logger log = LoggerFactory.getLogger(SectionABReportGenerator.class);

    private static final List<String> DESIGNATION_COLUMNS =
            List.of("DCP", "ACP", "RPI", "RSI", "ARSI", "AHC", "APC");

    private static final Color HEADER_BG = new Color(211, 211, 211);  // Light gray
    private static final Color TOTAL_BG = new Color(211, 211, 211);   // Light gray
    private static final Font HEADER_FONT = new Font(Font.HELVETICA, 7, Font.BOLD, Color.BLACK);
    private static final Font CELL_FONT = new Font(Font.HELVETICA, 7, Font.NORMAL, Color.BLACK);
    private static final Font CELL_BOLD_FONT = new Font(Font.HELVETICA, 7, Font.BOLD, Color.BLACK);
    private static final Font TOTAL_FONT = new Font(Font.HELVETICA, 7, Font.BOLD, Color.BLACK);
    private static final Font TITLE_FONT = new Font(Font.HELVETICA, 10, Font.BOLD, Color.BLACK);

    private final ReportDataService reportDataService;
    private final PdfStyleHelper pdfStyleHelper;
    private final ReportLocalizationService localizationService;

    public SectionABReportGenerator(ReportDataService reportDataService,
                                     PdfStyleHelper pdfStyleHelper,
                                     ReportLocalizationService localizationService) {
        this.reportDataService = reportDataService;
        this.pdfStyleHelper = pdfStyleHelper;
        this.localizationService = localizationService;
    }

    @Override
    public String getReportType() {
        return "section_ab";
    }

    @Override
    public byte[] generate(ReportRequest request) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            Document document = new Document(PageSize.A4.rotate(), 15, 15, 15, 15);
            PdfWriter.getInstance(document, baos);
            document.open();

            String locale = request.getLocale() != null ? request.getLocale() : "en";

            if (request.isCombined()) {
                // Combined A + B report
                SectionReportData dataA = reportDataService.buildSectionData("A");
                addSectionToDocument(document, dataA);

                document.newPage();

                SectionReportData dataB = reportDataService.buildSectionData("B");
                addSectionToDocument(document, dataB);
            } else {
                String section = request.getSection() != null ? request.getSection() : "A";
                SectionReportData data = reportDataService.buildSectionData(section);
                addSectionToDocument(document, data);
            }

            document.close();
            return baos.toByteArray();
        } catch (Exception e) {
            log.error("Failed to generate section A/B report", e);
            throw new ReportGenerationException("section_ab",
                    "Failed to generate section A/B report", e);
        }
    }

    private void addSectionToDocument(Document document, SectionReportData data) throws DocumentException {
        // Column widths: SL(3%), Parent Duty(17%), Sub Duty/Location(20%), Personnel(25%), DCP(5%), ACP(5%), RPI(5%), RSI(5%), ARSI(5%), AHC(5%), APC(5%)
        float[] columnWidths = {3f, 17f, 20f, 25f, 4.3f, 4.3f, 4.3f, 4.3f, 4.3f, 4.3f, 4.3f};
        PdfPTable table = new PdfPTable(columnWidths.length);
        table.setWidthPercentage(100);
        table.setWidths(columnWidths);

        // Header row: Section title spanning first 4 cols + designation columns
        PdfPCell titleCell = new PdfPCell(new Phrase(data.sectionLabel(), HEADER_FONT));
        titleCell.setColspan(4);
        titleCell.setBackgroundColor(HEADER_BG);
        titleCell.setPadding(3);
        titleCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        titleCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table.addCell(titleCell);

        for (String col : DESIGNATION_COLUMNS) {
            PdfPCell cell = new PdfPCell(new Phrase(col, HEADER_FONT));
            cell.setBackgroundColor(HEADER_BG);
            cell.setPadding(2);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            table.addCell(cell);
        }

        // Data rows
        for (DutyCategoryRow row : data.rows()) {
            if (row.subRows().isEmpty()) {
                // Simple row — no sub-categories, personnel spans sub-duty + personnel columns
                // SL | Parent Duty | Personnel (colspan 2, spanning sub-duty + personnel) | counts
                PdfPCell slCell = new PdfPCell(new Phrase(String.valueOf(row.serialNumber()), CELL_FONT));
                slCell.setPadding(2);
                slCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                slCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                table.addCell(slCell);

                PdfPCell catCell = new PdfPCell(new Phrase(row.categoryName(), CELL_BOLD_FONT));
                catCell.setPadding(2);
                catCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                table.addCell(catCell);

                // Personnel spans both sub-duty and personnel columns
                PdfPCell persCell = new PdfPCell(new Phrase(formatPersonnelList(row.personnel()), CELL_FONT));
                persCell.setColspan(2);
                persCell.setPadding(2);
                table.addCell(persCell);

                for (int count : row.designationCounts()) {
                    PdfPCell countCell = new PdfPCell(new Phrase(String.valueOf(count), CELL_FONT));
                    countCell.setPadding(2);
                    countCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                    table.addCell(countCell);
                }
            } else {
                // Category with sub-rows: use rowspan on SL and Parent Duty columns
                int numSubRows = row.subRows().size();

                // SL cell with rowspan
                PdfPCell slCell = new PdfPCell(new Phrase(String.valueOf(row.serialNumber()), CELL_FONT));
                slCell.setRowspan(numSubRows);
                slCell.setPadding(2);
                slCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                slCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                table.addCell(slCell);

                // Parent Duty cell with rowspan
                PdfPCell catCell = new PdfPCell(new Phrase(row.categoryName(), CELL_BOLD_FONT));
                catCell.setRowspan(numSubRows);
                catCell.setPadding(2);
                catCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                table.addCell(catCell);

                // First sub-row in same line as parent
                SubDutyRow firstSub = row.subRows().get(0);
                PdfPCell subCell = new PdfPCell(new Phrase(firstSub.subCategoryName(), CELL_FONT));
                subCell.setPadding(2);
                table.addCell(subCell);

                PdfPCell persCell = new PdfPCell(new Phrase(formatPersonnelList(firstSub.personnel()), CELL_FONT));
                persCell.setPadding(2);
                table.addCell(persCell);

                for (int count : firstSub.designationCounts()) {
                    PdfPCell countCell = new PdfPCell(new Phrase(String.valueOf(count), CELL_FONT));
                    countCell.setPadding(2);
                    countCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                    table.addCell(countCell);
                }

                // Remaining sub-rows (SL and Parent Duty already spanned)
                for (int i = 1; i < row.subRows().size(); i++) {
                    SubDutyRow sub = row.subRows().get(i);

                    PdfPCell subCellN = new PdfPCell(new Phrase(sub.subCategoryName(), CELL_FONT));
                    subCellN.setPadding(2);
                    table.addCell(subCellN);

                    PdfPCell persCellN = new PdfPCell(new Phrase(formatPersonnelList(sub.personnel()), CELL_FONT));
                    persCellN.setPadding(2);
                    table.addCell(persCellN);

                    for (int count : sub.designationCounts()) {
                        PdfPCell countCell = new PdfPCell(new Phrase(String.valueOf(count), CELL_FONT));
                        countCell.setPadding(2);
                        countCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                        table.addCell(countCell);
                    }
                }
            }
        }

        // TOTAL row
        PdfPCell totalLabelCell = new PdfPCell(new Phrase("TOTAL=", TOTAL_FONT));
        totalLabelCell.setColspan(4);
        totalLabelCell.setBackgroundColor(TOTAL_BG);
        totalLabelCell.setPadding(3);
        totalLabelCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        table.addCell(totalLabelCell);

        for (int count : data.designationTotals()) {
            PdfPCell cell = new PdfPCell(new Phrase(String.valueOf(count), TOTAL_FONT));
            cell.setBackgroundColor(TOTAL_BG);
            cell.setPadding(2);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(cell);
        }

        // GRAND TOTAL row - inside table as final row, right-aligned
        int grandTotal = 0;
        for (int count : data.designationTotals()) {
            grandTotal += count;
        }

        PdfPCell grandTotalCell = new PdfPCell(new Phrase("GRAND TOTAL=" + grandTotal, TOTAL_FONT));
        grandTotalCell.setColspan(11);
        grandTotalCell.setPadding(3);
        grandTotalCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        table.addCell(grandTotalCell);

        document.add(table);
    }

    private String formatPersonnelList(List<PersonnelEntry> entries) {
        if (entries == null || entries.isEmpty()) return "";
        // Simply comma-separate all display names (badge IDs or names as-is)
        return entries.stream()
                .map(PersonnelEntry::displayName)
                .filter(d -> d != null && !d.isEmpty())
                .collect(Collectors.joining(", "));
    }
}

import React, { useEffect, useState, useCallback } from 'react';
import { observer } from 'mobx-react-lite';
import { Box, CircularProgress, Alert, Typography, alpha } from '@mui/material';
import PeopleIcon from '@mui/icons-material/People';
import DirectionsCarIcon from '@mui/icons-material/DirectionsCar';
import { useTranslation } from 'react-i18next';
import { dutySectionStore } from '@/stores/dutySectionStore';
import SectionTabsBar from './SectionTabsBar';
import SearchFilterBar from './SearchFilterBar';
import SplitPanel from './SplitPanel';
import DutyTypeFormDialog from './DutyTypeFormDialog';
import SectionManagementDialog from './SectionManagementDialog';
import ReassignDialog from './ReassignDialog';

/**
 * DutyAndSectionsTab — Main container component for the unified "Duty & Sections" view.
 * Composes SectionTabsBar (chip filters), SearchFilterBar, and SplitPanel (Sidebar + Map + Personnel Table).
 * Manages dialog open/close state and wires map interactions to the form dialog.
 */
const DutyAndSectionsTab: React.FC = observer(() => {
  const { t } = useTranslation();

  // Dialog open/close state
  const [sectionManagementOpen, setSectionManagementOpen] = useState(false);
  const [dutyTypeFormOpen, setDutyTypeFormOpen] = useState(false);
  const [editDutyTypeId, setEditDutyTypeId] = useState<number | null>(null);
  const [reassignOpen, setReassignOpen] = useState(false);
  const [preSelectedReassignIds, setPreSelectedReassignIds] = useState<number[]>([]);

  // Map click-to-place / pin drag coordinates (passed to DutyTypeFormDialog)
  const [mapClickCoords, setMapClickCoords] = useState<{ lat: number; lng: number } | null>(null);

  // Fetch sections on mount
  useEffect(() => {
    dutySectionStore.fetchSections();
  }, []);

  // Watch store for header "Add Duty Type" button trigger
  useEffect(() => {
    if (dutySectionStore.showAddDutyTypeDialog) {
      setEditDutyTypeId(null);
      setMapClickCoords(null);
      setDutyTypeFormOpen(true);
      dutySectionStore.closeAddDutyTypeDialog();
    }
  }, [dutySectionStore.showAddDutyTypeDialog]);

  // --- Section Management Dialog handlers ---
  const handleSettingsClick = useCallback(() => {
    setSectionManagementOpen(true);
  }, []);

  const handleSectionManagementClose = useCallback(() => {
    setSectionManagementOpen(false);
  }, []);

  // --- Duty Type Form Dialog handlers ---
  const handleAddDutyType = useCallback(() => {
    setEditDutyTypeId(null);
    setMapClickCoords(null);
    setDutyTypeFormOpen(true);
  }, []);

  const handleEditDutyType = useCallback((id: number) => {
    setEditDutyTypeId(id);
    setMapClickCoords(null);
    setDutyTypeFormOpen(true);
  }, []);

  const handleDutyTypeFormClose = useCallback(() => {
    setDutyTypeFormOpen(false);
    setEditDutyTypeId(null);
    setMapClickCoords(null);
  }, []);

  // --- Reassign Dialog handlers ---
  const handleReassignDutyType = useCallback((id: number) => {
    setPreSelectedReassignIds([id]);
    setReassignOpen(true);
  }, []);

  const handleReassignClose = useCallback(() => {
    setReassignOpen(false);
    setPreSelectedReassignIds([]);
  }, []);

  // --- Map interactions (click-to-place / pin drag) ---
  const handleMapClick = useCallback(
    (lat: number, lng: number) => {
      if (dutyTypeFormOpen) {
        setMapClickCoords({ lat, lng });
      }
    },
    [dutyTypeFormOpen]
  );

  const handlePinDrag = useCallback(
    (lat: number, lng: number) => {
      if (dutyTypeFormOpen) {
        setMapClickCoords({ lat, lng });
      }
    },
    [dutyTypeFormOpen]
  );

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      {/* Loading indicator */}
      {dutySectionStore.loading && (
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            py: 2,
            backgroundColor: 'white',
            borderRadius: 2,
            border: '1px solid #E2E8F0',
          }}
        >
          <CircularProgress size={24} sx={{ color: '#3B82F6' }} />
          <Typography variant="body2" color="text.secondary" sx={{ ml: 1.5 }}>
            {t('admin.dutySections.loading', 'Loading...')}
          </Typography>
        </Box>
      )}

      {/* Error alert */}
      {dutySectionStore.error && (
        <Alert
          severity="error"
          sx={{
            borderRadius: 2,
            border: '1px solid #FEE2E2',
            '& .MuiAlert-icon': { color: '#EF4444' },
          }}
        >
          {dutySectionStore.error}
        </Alert>
      )}

      {/* Unit Toggle: CAR / MT */}
      <Box sx={{ display: 'flex', gap: 2 }}>
        {/* CAR Unit Card */}
        <Box
          onClick={() => dutySectionStore.setUnit('CAR')}
          sx={{
            flex: 1,
            border: dutySectionStore.selectedUnit === 'CAR' ? '2px solid #312e81' : '1px solid #e5e7eb',
            borderRadius: 2,
            p: 1.5,
            bgcolor: dutySectionStore.selectedUnit === 'CAR' ? '#f5f3ff' : '#fff',
            display: 'flex',
            alignItems: 'center',
            gap: 1.5,
            cursor: 'pointer',
            transition: 'all 0.2s',
            '&:hover': { borderColor: '#312e81', bgcolor: alpha('#312e81', 0.04) },
          }}
        >
          <PeopleIcon sx={{ color: '#312e81', fontSize: 24 }} />
          <Box>
            <Typography sx={{ fontSize: '0.95rem', fontWeight: 700, color: '#111827', lineHeight: 1.2 }}>
              CAR Unit
            </Typography>
            <Typography sx={{ fontSize: '0.72rem', color: '#6b7280' }}>
              Sections & Duty Types
            </Typography>
          </Box>
        </Box>

        {/* MT Unit Card */}
        <Box
          onClick={() => dutySectionStore.setUnit('MT')}
          sx={{
            flex: 1,
            border: dutySectionStore.selectedUnit === 'MT' ? '2px solid #059669' : '1px solid #e5e7eb',
            borderRadius: 2,
            p: 1.5,
            bgcolor: dutySectionStore.selectedUnit === 'MT' ? '#ecfdf5' : '#fff',
            display: 'flex',
            alignItems: 'center',
            gap: 1.5,
            cursor: 'pointer',
            transition: 'all 0.2s',
            '&:hover': { borderColor: '#059669', bgcolor: alpha('#059669', 0.04) },
          }}
        >
          <DirectionsCarIcon sx={{ color: '#059669', fontSize: 24 }} />
          <Box>
            <Typography sx={{ fontSize: '0.95rem', fontWeight: 700, color: '#111827', lineHeight: 1.2 }}>
              MT Unit
            </Typography>
            <Typography sx={{ fontSize: '0.72rem', color: '#6b7280' }}>
              Motor Transport Duties
            </Typography>
          </Box>
        </Box>
      </Box>

      {/* 1. Section Filter Chips Bar */}
      <SectionTabsBar onSettingsClick={handleSettingsClick} />

      {/* 2. Search / Filter Bar */}
      <SearchFilterBar />

      {/* 3. Split Panel (Sidebar + Map + Personnel Table) */}
      <SplitPanel
        isFormOpen={dutyTypeFormOpen}
        onMapClick={handleMapClick}
        onPinDrag={handlePinDrag}
        onAddDutyType={handleAddDutyType}
        onEditDutyType={handleEditDutyType}
        onReassignDutyType={handleReassignDutyType}
      />

      {/* Dialogs */}
      <DutyTypeFormDialog
        open={dutyTypeFormOpen}
        onClose={handleDutyTypeFormClose}
        editDutyTypeId={editDutyTypeId}
        onMapClick={mapClickCoords}
      />

      <SectionManagementDialog
        open={sectionManagementOpen}
        onClose={handleSectionManagementClose}
      />

      <ReassignDialog
        open={reassignOpen}
        onClose={handleReassignClose}
        preSelectedDutyTypeIds={preSelectedReassignIds}
      />
    </Box>
  );
});

export default DutyAndSectionsTab;

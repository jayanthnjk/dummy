package com.policescheduler.dto.chat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FormResponseData {

    private String formId;
    private String title;
    private List<FieldDef> fields;
    private String submitAction;
    private String submitLabel;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FieldDef {
        private String name;
        private String label;
        private String type;       // "text", "select", "date", "number", "time", "textarea", "switch", "chip-select", "designation-counts", "multi-select", "personnel-list", "hidden"
        private boolean required;
        private String value;      // pre-filled value
        private List<String> options; // for select type, or personnel options for personnel-list (format: id|name|badge|designation|section)
        private String placeholder;   // placeholder text for text inputs
        private String helperText;    // helper/description text below the field
        private String group;         // field grouping: "basic", "personal", "contact", "driver"
    }
}

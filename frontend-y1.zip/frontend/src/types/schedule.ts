// ===== Schedule Page Types =====

// ===== View Mode =====
export type ViewMode = 'day' | 'week' | 'month';

// ===== Date Range =====
export interface DateRange {
  start: string; // ISO date "YYYY-MM-DD"
  end: string;   // ISO date "YYYY-MM-DD"
  label: string; // Display label e.g., "Jun 15 - Jun 21, 2026"
}

// ===== Team Member =====
export interface TeamMember {
  id: number;
  badgeId: string;
  name: string;
  avatar?: string;   // URL or null (initials circle fallback)
  role: string;      // designation
  group: string;     // section/group label
  email: string;
}

// ===== Shift =====
export interface Shift {
  id: number;
  personnelId: number;
  date: string;         // ISO date
  startTime: string;    // "HH:mm"
  endTime: string;      // "HH:mm"
  shiftType: string;    // e.g., "Morning", "Afternoon", "Night", "Special"
  durationHours: number;
}

// ===== Open Shift =====
export interface OpenShift {
  id: number;
  date: string;
  startTime: string;
  endTime: string;
  shiftType: string;
  durationHours: number;
}

// ===== Time Off =====
export interface TimeOff {
  id: number;
  personnelId: number;
  date: string;
  leaveType: string;   // e.g., "Annual", "Sick", "Earned"
  status: 'APPROVED' | 'PENDING';
}

// ===== Shift Type =====
export interface ShiftType {
  name: string;
  color: string;       // hex background color
  textColor: string;   // hex text color for contrast
}

// ===== Team Member Schedule =====
export interface TeamMemberSchedule {
  member: TeamMember;
  shifts: Shift[];
  timeOffs: TimeOff[];
  totalHours: number;  // computed sum for the displayed week
}

// ===== Request Types =====
export interface CreateShiftRequest {
  personnelId: number;
  date: string;
  startTime: string;
  endTime: string;
  shiftType: string;
}

export interface PublishScheduleRequest {
  startDate: string;
  endDate: string;
}

// ===== Component Props =====
export interface ScheduleHeaderProps {
  onRefresh: () => void;
  onExport: () => void;
  onPublish: () => void;
  isLoading: boolean;
}

export interface NavigationBarProps {
  viewMode: ViewMode;
  onViewModeChange: (mode: ViewMode) => void;
  dateRange: DateRange;
  onNavigate: (direction: 'prev' | 'next' | 'today') => void;
  groupFilter: string;
  onGroupFilterChange: (group: string) => void;
  groups: string[];
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export interface ScheduleGridProps {
  viewMode: ViewMode;
  dateRange: DateRange;
  teamMembers: TeamMemberSchedule[];
  openShifts: OpenShift[];
  showOpenShifts: boolean;
  showTimeOff: boolean;
  onAddShift: (memberId: number, date: string) => void;
  onShiftClick?: (shift: Shift, memberName: string, memberGroup: string) => void;
  todayDate: string;
}

export interface ShiftBlockProps {
  shift: Shift;
  color: string;
  textColor: string;
  onClick?: (shift: Shift) => void;
}

export interface TimeOffEntryProps {
  entry: TimeOff;
}

export interface ShiftDetailDialogProps {
  open: boolean;
  onClose: () => void;
  shift: Shift | null;
  memberName: string;
  memberGroup: string;
}

export interface ShiftCreateDialogProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (data: CreateShiftRequest) => void;
  prefilledMember: TeamMember | null;
  prefilledDate: string | null;
  shiftTypes: ShiftType[];
}

import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

export const SupportAdminRoute: React.FC = () => {
  const { isAuthenticated, role } = useAuth();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (role !== 'SUPPORT_ADMIN') {
    return <Navigate to="/" replace />;
  }

  return <Outlet />;
};

import React from 'react';
import { Box, Typography, Button, IconButton, CircularProgress } from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import PublishIcon from '@mui/icons-material/Publish';
import type { ScheduleHeaderProps } from '@/types/schedule';

/**
 * ScheduleHeader — Enterprise-grade page header with title and action buttons.
 * White card-based design with subtle shadow for elevation.
 */
const ScheduleHeader: React.FC<ScheduleHeaderProps> = ({
  onRefresh,
  onExport,
  onPublish,
  isLoading,
}) => {
  return (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        px: 3,
        py: 2,
        backgroundColor: '#FFFFFF',
        borderBottom: '1px solid #E5E7EB',
        boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.05)',
        flexShrink: 0,
      }}
    >
      {/* Title and subtitle */}
      <Box>
        <Typography
          variant="h5"
          sx={{
            fontWeight: 700,
            color: '#111827',
            fontSize: '1.5rem',
            lineHeight: 1.3,
            letterSpacing: '-0.01em',
          }}
        >
          Schedule
        </Typography>
        <Typography
          variant="body2"
          sx={{
            color: '#6B7280',
            mt: 0.5,
            fontSize: '0.8125rem',
          }}
        >
          Manage team schedules and shifts
        </Typography>
      </Box>

      {/* Action buttons */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
        {/* Refresh icon button */}
        <IconButton
          onClick={onRefresh}
          disabled={isLoading}
          size="small"
          aria-label="Refresh schedule"
          sx={{
            color: '#6B7280',
            border: '1px solid #E5E7EB',
            borderRadius: '8px',
            width: 36,
            height: 36,
            '&:hover': {
              backgroundColor: '#F9FAFB',
              borderColor: '#D1D5DB',
            },
          }}
        >
          {isLoading ? (
            <CircularProgress size={18} color="inherit" />
          ) : (
            <RefreshIcon sx={{ fontSize: 18 }} />
          )}
        </IconButton>

        {/* Export outlined button */}
        <Button
          variant="outlined"
          size="small"
          startIcon={<FileDownloadIcon sx={{ fontSize: 16 }} />}
          onClick={onExport}
          disabled={isLoading}
          sx={{
            textTransform: 'none',
            fontWeight: 500,
            fontSize: '0.8125rem',
            borderColor: '#E5E7EB',
            color: '#374151',
            borderRadius: '8px',
            px: 2,
            py: 0.75,
            '&:hover': {
              backgroundColor: '#F9FAFB',
              borderColor: '#D1D5DB',
            },
          }}
        >
          Export
        </Button>

        {/* Publish Schedule primary button */}
        <Button
          variant="contained"
          size="small"
          startIcon={<PublishIcon sx={{ fontSize: 16 }} />}
          onClick={onPublish}
          disabled={isLoading}
          disableElevation
          sx={{
            textTransform: 'none',
            fontWeight: 600,
            fontSize: '0.8125rem',
            backgroundColor: '#2563EB',
            borderRadius: '8px',
            px: 2.5,
            py: 0.75,
            '&:hover': {
              backgroundColor: '#1D4ED8',
            },
          }}
        >
          Publish Schedule
        </Button>
      </Box>
    </Box>
  );
};

export default ScheduleHeader;

import React, { useEffect, useState, useCallback } from 'react';
import { observer } from 'mobx-react-lite';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Alert,
  Stack,
  type SelectChangeEvent,
} from '@mui/material';
import { useTranslation } from 'react-i18next';
import { dutySectionStore } from '@/stores/dutySectionStore';
import { dutyTypeService } from '@/services/dutySectionService';
import type { DutyTypeCreateRequest, DutyTypeUpdateRequest } from '@/types/dutySections';

interface DutyTypeFormDialogProps {
  open: boolean;
  onClose: () => void;
  editDutyTypeId?: number | null;
  onMapClick?: { lat: number; lng: number } | null;
}

interface FormValues {
  name: string;
  section: string;
  sortOrder: string;
  latitude: string;
  longitude: string;
  radiusMeters: string;
}

interface FormErrors {
  name?: string;
  section?: string;
  sortOrder?: string;
  latitude?: string;
  longitude?: string;
  radiusMeters?: string;
  paired?: string;
}

const DutyTypeFormDialog: React.FC<DutyTypeFormDialogProps> = observer(
  ({ open, onClose, editDutyTypeId, onMapClick }) => {
    const { t } = useTranslation();
    const isEditMode = editDutyTypeId != null;

    const [formValues, setFormValues] = useState<FormValues>({
      name: '',
      section: '',
      sortOrder: '',
      latitude: '',
      longitude: '',
      radiusMeters: '500',
    });
    const [errors, setErrors] = useState<FormErrors>({});
    const [apiError, setApiError] = useState<string | null>(null);
    const [submitting, setSubmitting] = useState(false);

    // Compute next available sort order for a given section
    const getNextSortOrder = useCallback(
      (sectionCode: string): number => {
        const existing = dutySectionStore.dutyTypes
          .filter((dt) => dt.section === sectionCode)
          .map((dt) => dt.sortOrder);
        if (existing.length === 0) return 1;
        return Math.min(Math.max(...existing) + 1, 999);
      },
      []
    );

    // Initialize form when dialog opens
    useEffect(() => {
      if (!open) return;

      setErrors({});
      setApiError(null);

      if (isEditMode) {
        const dutyType = dutySectionStore.dutyTypes.find(
          (dt) => dt.id === editDutyTypeId
        );
        if (dutyType) {
          setFormValues({
            name: dutyType.name,
            section: dutyType.section,
            sortOrder: String(dutyType.sortOrder),
            latitude: dutyType.latitude != null ? String(dutyType.latitude) : '',
            longitude:
              dutyType.longitude != null ? String(dutyType.longitude) : '',
            radiusMeters:
              dutyType.radiusMeters != null
                ? String(dutyType.radiusMeters)
                : '500',
          });
        }
      } else {
        const defaultSection =
          dutySectionStore.selectedSectionCode ||
          (dutySectionStore.activeSections.length > 0
            ? dutySectionStore.activeSections[0].code
            : '');
        const nextSort = getNextSortOrder(defaultSection);
        setFormValues({
          name: '',
          section: defaultSection,
          sortOrder: String(nextSort),
          latitude: '',
          longitude: '',
          radiusMeters: '500',
        });
      }
    }, [open, isEditMode, editDutyTypeId, getNextSortOrder]);

    // Update lat/lng when map click prop changes
    useEffect(() => {
      if (!open || !onMapClick) return;
      setFormValues((prev) => ({
        ...prev,
        latitude: onMapClick.lat.toFixed(6),
        longitude: onMapClick.lng.toFixed(6),
      }));
    }, [open, onMapClick]);

    const handleChange = (field: keyof FormValues) => (
      e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
    ) => {
      setFormValues((prev) => ({ ...prev, [field]: e.target.value }));
      // Clear field error on change
      setErrors((prev) => ({ ...prev, [field]: undefined, paired: undefined }));
    };

    const handleSectionChange = (e: SelectChangeEvent<string>) => {
      const newSection = e.target.value;
      const nextSort = getNextSortOrder(newSection);
      setFormValues((prev) => ({
        ...prev,
        section: newSection,
        sortOrder: String(nextSort),
      }));
      setErrors((prev) => ({ ...prev, section: undefined }));
    };

    const validate = (): boolean => {
      const newErrors: FormErrors = {};

      // Name: required, 1-100 chars
      if (!formValues.name.trim()) {
        newErrors.name = t(
          'admin.dutySections.dutyTypeForm.errors.nameRequired',
          'Name is required'
        );
      } else if (formValues.name.trim().length > 100) {
        newErrors.name = t(
          'admin.dutySections.dutyTypeForm.errors.nameMaxLength',
          'Name must be 100 characters or less'
        );
      }

      // Section: required
      if (!formValues.section) {
        newErrors.section = t(
          'admin.dutySections.dutyTypeForm.errors.sectionRequired',
          'Section is required'
        );
      }

      // Sort Order: required, 1-999
      const sortOrderNum = Number(formValues.sortOrder);
      if (!formValues.sortOrder || isNaN(sortOrderNum)) {
        newErrors.sortOrder = t(
          'admin.dutySections.dutyTypeForm.errors.sortOrderRequired',
          'Sort order is required'
        );
      } else if (sortOrderNum < 1 || sortOrderNum > 999 || !Number.isInteger(sortOrderNum)) {
        newErrors.sortOrder = t(
          'admin.dutySections.dutyTypeForm.errors.sortOrderRange',
          'Sort order must be between 1 and 999'
        );
      }

      // Latitude: optional, -90 to 90
      const hasLat = formValues.latitude.trim() !== '';
      const hasLng = formValues.longitude.trim() !== '';

      if (hasLat) {
        const lat = Number(formValues.latitude);
        if (isNaN(lat)) {
          newErrors.latitude = t(
            'admin.dutySections.dutyTypeForm.errors.latitudeInvalid',
            'Latitude must be a number'
          );
        } else if (lat < -90 || lat > 90) {
          newErrors.latitude = t(
            'admin.dutySections.dutyTypeForm.errors.latitudeRange',
            'Latitude must be between -90 and 90'
          );
        }
      }

      // Longitude: optional, -180 to 180
      if (hasLng) {
        const lng = Number(formValues.longitude);
        if (isNaN(lng)) {
          newErrors.longitude = t(
            'admin.dutySections.dutyTypeForm.errors.longitudeInvalid',
            'Longitude must be a number'
          );
        } else if (lng < -180 || lng > 180) {
          newErrors.longitude = t(
            'admin.dutySections.dutyTypeForm.errors.longitudeRange',
            'Longitude must be between -180 and 180'
          );
        }
      }

      // Paired validation: if one provided, other must be too
      if (hasLat && !hasLng) {
        newErrors.longitude = t(
          'admin.dutySections.dutyTypeForm.errors.longitudeRequired',
          'Longitude is required when latitude is provided'
        );
        newErrors.paired = t(
          'admin.dutySections.dutyTypeForm.errors.pairedRequired',
          'Both latitude and longitude must be provided together'
        );
      } else if (hasLng && !hasLat) {
        newErrors.latitude = t(
          'admin.dutySections.dutyTypeForm.errors.latitudeRequired',
          'Latitude is required when longitude is provided'
        );
        newErrors.paired = t(
          'admin.dutySections.dutyTypeForm.errors.pairedRequired',
          'Both latitude and longitude must be provided together'
        );
      }

      // Radius meters: optional, 1-10000
      if (formValues.radiusMeters.trim() !== '') {
        const radius = Number(formValues.radiusMeters);
        if (isNaN(radius)) {
          newErrors.radiusMeters = t(
            'admin.dutySections.dutyTypeForm.errors.radiusInvalid',
            'Radius must be a number'
          );
        } else if (radius < 1 || radius > 10000) {
          newErrors.radiusMeters = t(
            'admin.dutySections.dutyTypeForm.errors.radiusRange',
            'Radius must be between 1 and 10000'
          );
        }
      }

      setErrors(newErrors);
      return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async () => {
      if (!validate()) return;

      setSubmitting(true);
      setApiError(null);

      const hasCoords = formValues.latitude.trim() !== '' && formValues.longitude.trim() !== '';

      try {
        if (isEditMode) {
          const request: DutyTypeUpdateRequest = {
            name: formValues.name.trim(),
            section: formValues.section,
            sortOrder: Number(formValues.sortOrder),
            latitude: hasCoords ? Number(formValues.latitude) : null,
            longitude: hasCoords ? Number(formValues.longitude) : null,
            radiusMeters: hasCoords && formValues.radiusMeters.trim() !== ''
              ? Number(formValues.radiusMeters)
              : null,
          };
          await dutyTypeService.update(editDutyTypeId!, request);
        } else {
          const request: DutyTypeCreateRequest = {
            name: formValues.name.trim(),
            section: formValues.section,
            sortOrder: Number(formValues.sortOrder),
            latitude: hasCoords ? Number(formValues.latitude) : null,
            longitude: hasCoords ? Number(formValues.longitude) : null,
            radiusMeters: hasCoords && formValues.radiusMeters.trim() !== ''
              ? Number(formValues.radiusMeters)
              : null,
          };
          await dutyTypeService.create(request);
        }

        await dutySectionStore.refresh();
        onClose();
      } catch (err: unknown) {
        const message =
          err instanceof Error
            ? err.message
            : t(
                'admin.dutySections.dutyTypeForm.errors.submitFailed',
                'Failed to save duty type'
              );
        setApiError(message);
      } finally {
        setSubmitting(false);
      }
    };

    const dialogTitle = isEditMode
      ? t('admin.dutySections.dutyTypeForm.editTitle', 'Edit Duty Type')
      : t('admin.dutySections.dutyTypeForm.createTitle', 'Add Duty Type');

    return (
      <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
        <DialogTitle>{dialogTitle}</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            {apiError && (
              <Alert severity="error" onClose={() => setApiError(null)}>
                {apiError}
              </Alert>
            )}

            {/* Name */}
            <TextField
              label={t('admin.dutySections.dutyTypeForm.name', 'Name')}
              value={formValues.name}
              onChange={handleChange('name')}
              required
              error={!!errors.name}
              helperText={errors.name}
              fullWidth
              size="small"
              inputProps={{ maxLength: 100 }}
            />

            {/* Section */}
            <FormControl fullWidth size="small" required error={!!errors.section}>
              <InputLabel id="duty-type-section-label">
                {t('admin.dutySections.dutyTypeForm.section', 'Section')}
              </InputLabel>
              <Select
                labelId="duty-type-section-label"
                value={formValues.section}
                onChange={handleSectionChange}
                label={t('admin.dutySections.dutyTypeForm.section', 'Section')}
              >
                {dutySectionStore.activeSections.map((section) => (
                  <MenuItem key={section.code} value={section.code}>
                    {section.name} ({section.code})
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            {/* Sort Order */}
            <TextField
              label={t('admin.dutySections.dutyTypeForm.sortOrder', 'Sort Order')}
              value={formValues.sortOrder}
              onChange={handleChange('sortOrder')}
              required
              error={!!errors.sortOrder}
              helperText={errors.sortOrder}
              fullWidth
              size="small"
              type="number"
              inputProps={{ min: 1, max: 999 }}
            />

            {/* Latitude */}
            <TextField
              label={t('admin.dutySections.dutyTypeForm.latitude', 'Latitude')}
              value={formValues.latitude}
              onChange={handleChange('latitude')}
              error={!!errors.latitude}
              helperText={
                errors.latitude ||
                t('admin.dutySections.dutyTypeForm.latitudeHint', '-90 to 90')
              }
              fullWidth
              size="small"
              type="number"
              inputProps={{ min: -90, max: 90, step: 'any' }}
            />

            {/* Longitude */}
            <TextField
              label={t('admin.dutySections.dutyTypeForm.longitude', 'Longitude')}
              value={formValues.longitude}
              onChange={handleChange('longitude')}
              error={!!errors.longitude}
              helperText={
                errors.longitude ||
                t('admin.dutySections.dutyTypeForm.longitudeHint', '-180 to 180')
              }
              fullWidth
              size="small"
              type="number"
              inputProps={{ min: -180, max: 180, step: 'any' }}
            />

            {/* Radius Meters */}
            <TextField
              label={t(
                'admin.dutySections.dutyTypeForm.radiusMeters',
                'Radius (meters)'
              )}
              value={formValues.radiusMeters}
              onChange={handleChange('radiusMeters')}
              error={!!errors.radiusMeters}
              helperText={
                errors.radiusMeters ||
                t(
                  'admin.dutySections.dutyTypeForm.radiusHint',
                  '1 to 10000, default 500'
                )
              }
              fullWidth
              size="small"
              type="number"
              inputProps={{ min: 1, max: 10000 }}
            />
          </Stack>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={onClose} disabled={submitting}>
            {t('admin.dutySections.dutyTypeForm.cancel', 'Cancel')}
          </Button>
          <Button
            variant="contained"
            onClick={handleSubmit}
            disabled={submitting}
          >
            {submitting
              ? t('admin.dutySections.dutyTypeForm.saving', 'Saving...')
              : isEditMode
                ? t('admin.dutySections.dutyTypeForm.update', 'Update')
                : t('admin.dutySections.dutyTypeForm.create', 'Create')}
          </Button>
        </DialogActions>
      </Dialog>
    );
  }
);

export default DutyTypeFormDialog;

import api from './api';
import type { ChatResponse } from '@/types';

export const chatService = {
  sendMessage: (message: string) =>
    api.post<ChatResponse>('/api/chat/message', { message }).then((r) => r.data),

  uploadPdf: (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post<ChatResponse>('/api/chat/upload-pdf', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }).then((r) => r.data);
  },

  submitForm: (formId: string, submitAction: string, fields: Record<string, string>) =>
    api.post<ChatResponse>('/api/chat/form-submit', { formId, submitAction, fields })
      .then((r) => r.data),

  checkAiStatus: () =>
    api.get<{ connected: boolean; reason?: string }>('/api/health/ai').then((r) => r.data),
};

package com.policescheduler.report.model;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class LeaveStatementModel {
    private List<LeaveGroup> groups; // EL/CML/PL, CL, W/OFF, PERMISSION, ABSENT, SUSPENSION, SICK
}

package com.policescheduler.report.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DutyRowModel {
    private int serialNumber;
    private String dutyDescription;
    private int[] counts; // ACP, RPI, RSI, ARSI, AHC, APC, SWP (7 elements)
    private int total;
    private String personnelDetails; // "ARSI SRI [NAME], AHC-123, APC-456"
}

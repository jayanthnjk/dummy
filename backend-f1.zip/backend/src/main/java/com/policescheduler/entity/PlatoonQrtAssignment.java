package com.policescheduler.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "platoon_qrt_assignments")
public class PlatoonQrtAssignment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "platoon_id", nullable = false)
    private Long platoonId;

    @Column(name = "personnel_id", nullable = false)
    private Long personnelId;

    @Column(name = "qrt_group", nullable = false)
    private String qrtGroup; // PRIMARY or SECONDARY

    @Column(name = "is_active", nullable = false)
    private Boolean isActive = true;

    public PlatoonQrtAssignment() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getPlatoonId() { return platoonId; }
    public void setPlatoonId(Long platoonId) { this.platoonId = platoonId; }

    public Long getPersonnelId() { return personnelId; }
    public void setPersonnelId(Long personnelId) { this.personnelId = personnelId; }

    public String getQrtGroup() { return qrtGroup; }
    public void setQrtGroup(String qrtGroup) { this.qrtGroup = qrtGroup; }

    public Boolean getIsActive() { return isActive; }
    public void setIsActive(Boolean isActive) { this.isActive = isActive; }
}

import React, { useState } from 'react';
import {
  Box, Typography, Button, CircularProgress, alpha,
  Tabs, Tab,
} from '@mui/material';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import GridOnIcon from '@mui/icons-material/GridOn';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import DescriptionIcon from '@mui/icons-material/Description';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import DirectionsCarIcon from '@mui/icons-material/DirectionsCar';
import EventBusyIcon from '@mui/icons-material/EventBusy';
import SecurityIcon from '@mui/icons-material/Security';

import { useTranslation } from 'react-i18next';
import api from '@/services/api';
import DownloadedReportsTab from '@/components/reports/DownloadedReportsTab';
import PageHeader from '@/components/common/PageHeader';
import DisplayCard from '@/components/common/DisplayCard';

interface ReportCard {
  title: string;
  description: string;
  endpoint: string;
  filename: string;
  excelEndpoint?: string;
  excelFilename?: string;
  icon: React.ReactNode;
  color: string;
}

const ReportsPage: React.FC = () => {
  const { t } = useTranslation();
  const [downloading, setDownloading] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState(0);

  const reports: ReportCard[] = [
    {
      title: t('reports.platoonChartAB', 'Platoon Chart A & B'),
      description: t('reports.platoonChartABDesc', 'Combined Section A and Section B personnel list with duty assignments and designation counts'),
      endpoint: '/api/reports/section-ab',
      filename: 'section-ab-report.pdf',
      excelEndpoint: '/api/reports/section-ab/excel',
      excelFilename: 'section-ab.xlsx',
      icon: <SecurityIcon />,
      color: '#3b82f6',
    },
    {
      title: t('reports.platoonChartC', 'Platoon Chart C - Rotational Duties'),
      description: t('reports.platoonChartCDesc', 'Combined Section C, D, E, F, G platoon rotation chart with badge IDs'),
      endpoint: '/api/reports/platoon-chart',
      filename: 'platoon-chart.pdf',
      excelEndpoint: '/api/reports/platoon-chart/excel',
      excelFilename: 'section-c.xlsx',
      icon: <CalendarMonthIcon />,
      color: '#059669',
    },
    {
      title: t('reports.dailyStatement', 'Daily Statement (Form 168)'),
      description: t('reports.dailyStatementDesc', 'Official daily strength and duty abstract report with designation breakdown'),
      endpoint: '/api/reports/form-168',
      filename: 'form-168.pdf',
      excelEndpoint: '/api/reports/form-168/excel',
      excelFilename: 'daily-statement.xlsx',
      icon: <DescriptionIcon />,
      color: '#e8722a',
    },
    {
      title: t('reports.mtSection', 'MT Section (Drivers)'),
      description: t('reports.mtSectionDesc', 'CAR Motor Transport section with driver details, vehicle numbers, PDMS status'),
      endpoint: '/api/reports/mt-section',
      filename: 'mt-section-report.pdf',
      excelEndpoint: '/api/reports/mt-section/excel',
      excelFilename: 'mt-section.xlsx',
      icon: <DirectionsCarIcon />,
      color: '#0891b2',
    },
    {
      title: t('reports.leaveStatement', 'Leave Statement'),
      description: t('reports.leaveStatementDesc', 'Leave request summary with status, type, dates, and personnel details'),
      endpoint: '/api/reports/leave-statement',
      filename: 'leave-statement.pdf',
      excelEndpoint: '/api/reports/leave-statement/excel',
      excelFilename: 'leave-statement.xlsx',
      icon: <EventBusyIcon />,
      color: '#7c3aed',
    },
  ];

  const handleDownload = async (report: ReportCard) => {
    setDownloading(report.endpoint);
    try {
      const response = await api.get(report.endpoint, { responseType: 'blob' });
      const contentDisposition = response.headers['content-disposition'];
      let serverFilename = report.filename;
      if (contentDisposition) {
        const match = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
        if (match && match[1]) {
          serverFilename = match[1].replace(/['"]/g, '');
        }
      }
      const url = window.URL.createObjectURL(response.data);
      const link = document.createElement('a');
      link.href = url;
      link.download = serverFilename;
      link.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Download failed:', error);
    } finally {
      setDownloading(null);
    }
  };

  const handleExcelDownload = async (report: ReportCard) => {
    if (!report.excelEndpoint || !report.excelFilename) return;
    setDownloading(report.excelEndpoint);
    try {
      const response = await api.get(report.excelEndpoint, { responseType: 'blob' });
      const contentDisposition = response.headers['content-disposition'];
      let serverFilename = report.excelFilename;
      if (contentDisposition) {
        const match = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
        if (match && match[1]) {
          serverFilename = match[1].replace(/['"]/g, '');
        }
      }
      const url = window.URL.createObjectURL(response.data);
      const link = document.createElement('a');
      link.href = url;
      link.download = serverFilename;
      link.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Excel download failed:', error);
    } finally {
      setDownloading(null);
    }
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', bgcolor: 'background.default' }}>
      {/* PageHeader replacing the gradient banner */}
      <PageHeader
        title={t('reports.title', 'Reports')}
        breadcrumbs={[
          { label: 'Home', path: '/' },
          { label: 'Reports' },
        ]}
      />

      {/* Tabs below header */}
      <Box sx={{ borderBottom: 1, borderColor: 'divider', bgcolor: 'white' }}>
        <Tabs
          value={activeTab}
          onChange={(_, newValue) => setActiveTab(newValue)}
          sx={{
            px: { xs: 2, md: 4 },
            '& .MuiTab-root': {
              textTransform: 'none',
              fontWeight: 500,
              color: 'text.secondary',
              '&.Mui-selected': {
                fontWeight: 700,
                color: 'primary.main',
              },
            },
            '& .MuiTabs-indicator': {
              backgroundColor: 'primary.main',
            },
          }}
        >
          <Tab label={t('reports.tab.reports', 'Reports')} />
          <Tab label={t('reports.tab.downloaded', 'Downloaded Reports')} />
        </Tabs>
      </Box>

      {/* Tab Content */}
      <Box sx={{ flex: 1, p: { xs: 2, md: 4 }, maxWidth: 1200, mx: 'auto', width: '100%' }}>
        {activeTab === 0 && (
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: {
                xs: '1fr',
                md: 'repeat(2, 1fr)',
                lg: 'repeat(3, 1fr)',
              },
              gap: 3,
            }}
          >
            {reports.map((report, index) => (
              <DisplayCard
                key={report.endpoint}
                title={report.title}
                subtitle={report.description}
                icon={
                  <Box
                    sx={{
                      width: 40,
                      height: 40,
                      borderRadius: 2,
                      bgcolor: alpha(report.color, 0.1),
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      color: report.color,
                    }}
                  >
                    {report.icon}
                  </Box>
                }
                staggerIndex={index}
              >
                {/* Download action buttons */}
                <Box sx={{ mt: 2 }}>
                  {report.excelEndpoint ? (
                    <Box sx={{ display: 'flex', gap: 1 }}>
                      <Button
                        variant="outlined"
                        size="small"
                        startIcon={
                          downloading === report.endpoint ? (
                            <CircularProgress size={16} />
                          ) : (
                            <PictureAsPdfIcon />
                          )
                        }
                        disabled={!!downloading}
                        onClick={() => handleDownload(report)}
                        sx={{
                          borderRadius: 2,
                          textTransform: 'none',
                          fontWeight: 600,
                          borderColor: report.color,
                          color: report.color,
                          '&:hover': {
                            bgcolor: alpha(report.color, 0.08),
                            borderColor: report.color,
                          },
                        }}
                      >
                        {downloading === report.endpoint
                          ? t('reports.generating', 'Generating...')
                          : t('reports.pdf', 'PDF')}
                      </Button>
                      <Button
                        variant="outlined"
                        size="small"
                        startIcon={
                          downloading === report.excelEndpoint ? (
                            <CircularProgress size={16} />
                          ) : (
                            <GridOnIcon />
                          )
                        }
                        disabled={!!downloading}
                        onClick={() => handleExcelDownload(report)}
                        sx={{
                          borderRadius: 2,
                          textTransform: 'none',
                          fontWeight: 600,
                          borderColor: report.color,
                          color: report.color,
                          '&:hover': {
                            bgcolor: alpha(report.color, 0.08),
                            borderColor: report.color,
                          },
                        }}
                      >
                        {downloading === report.excelEndpoint
                          ? t('reports.generating', 'Generating...')
                          : t('reports.excel', 'Excel')}
                      </Button>
                    </Box>
                  ) : (
                    <Button
                      variant="outlined"
                      size="small"
                      startIcon={
                        downloading === report.endpoint ? (
                          <CircularProgress size={16} />
                        ) : (
                          <FileDownloadIcon />
                        )
                      }
                      disabled={downloading === report.endpoint}
                      onClick={() => handleDownload(report)}
                      sx={{
                        borderRadius: 2,
                        textTransform: 'none',
                        fontWeight: 600,
                        borderColor: report.color,
                        color: report.color,
                        '&:hover': {
                          bgcolor: alpha(report.color, 0.08),
                          borderColor: report.color,
                        },
                      }}
                    >
                      {downloading === report.endpoint
                        ? t('reports.generating', 'Generating...')
                        : t('reports.downloadPdf', 'Download PDF')}
                    </Button>
                  )}
                </Box>
              </DisplayCard>
            ))}
          </Box>
        )}

        {activeTab === 1 && <DownloadedReportsTab />}
      </Box>
    </Box>
  );
};

export default ReportsPage;

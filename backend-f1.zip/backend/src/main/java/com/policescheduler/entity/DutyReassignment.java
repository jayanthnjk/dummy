package com.policescheduler.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Tracks duty reassignments when a person goes on leave.
 * The replacement person covers the leave person's duty for specific dates.
 */
@Entity
@Table(name = "duty_reassignments")
public class DutyReassignment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** The person who is on leave */
    @Column(name = "leave_person_id", nullable = false)
    private Long leavePersonId;

    /** The replacement person covering the duty */
    @Column(name = "replacement_person_id", nullable = false)
    private Long replacementPersonId;

    /** The leave request this reassignment is associated with */
    @Column(name = "leave_request_id")
    private Long leaveRequestId;

    /** Section code where the reassignment applies */
    @Column(name = "section_code", nullable = false, length = 10)
    private String sectionCode;

    /** The duty type being covered (from the leave person's original duty) */
    @Column(name = "duty_type", length = 200)
    private String dutyType;

    /** The duty location being covered */
    @Column(name = "duty_location", length = 200)
    private String dutyLocation;

    /** Start date of the reassignment */
    @Column(name = "start_date", nullable = false)
    private LocalDate startDate;

    /** End date of the reassignment */
    @Column(name = "end_date", nullable = false)
    private LocalDate endDate;

    /** Status: ACTIVE, CANCELLED, EXPIRED */
    @Column(nullable = false, length = 20)
    private String status = "ACTIVE";

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getLeavePersonId() { return leavePersonId; }
    public void setLeavePersonId(Long leavePersonId) { this.leavePersonId = leavePersonId; }

    public Long getReplacementPersonId() { return replacementPersonId; }
    public void setReplacementPersonId(Long replacementPersonId) { this.replacementPersonId = replacementPersonId; }

    public Long getLeaveRequestId() { return leaveRequestId; }
    public void setLeaveRequestId(Long leaveRequestId) { this.leaveRequestId = leaveRequestId; }

    public String getSectionCode() { return sectionCode; }
    public void setSectionCode(String sectionCode) { this.sectionCode = sectionCode; }

    public String getDutyType() { return dutyType; }
    public void setDutyType(String dutyType) { this.dutyType = dutyType; }

    public String getDutyLocation() { return dutyLocation; }
    public void setDutyLocation(String dutyLocation) { this.dutyLocation = dutyLocation; }

    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }

    public LocalDate getEndDate() { return endDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}

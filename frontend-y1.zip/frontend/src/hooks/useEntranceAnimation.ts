import { useRef, useState, useEffect, useCallback } from 'react';

/**
 * Options for the useEntranceAnimation hook.
 */
export interface UseEntranceAnimationOptions {
  /** Index of the element among siblings — used to compute stagger delay (index * 100ms) */
  index?: number;
  /** Animation duration in milliseconds (default: 400) */
  duration?: number;
  /** Stagger delay per sibling in milliseconds (default: 100) */
  staggerMs?: number;
  /** Whether the entrance animation is enabled (default: true) */
  enabled?: boolean;
  /** IntersectionObserver threshold — fraction of element visible to trigger (default: 0.1) */
  threshold?: number;
  /** Root margin for the observer (default: '0px') */
  rootMargin?: string;
}

/**
 * Return value from the useEntranceAnimation hook.
 */
export interface UseEntranceAnimationReturn {
  /** Ref to attach to the animated element */
  ref: React.RefObject<HTMLElement | null>;
  /** Whether the element has entered the viewport and animation is complete or in progress */
  hasEntered: boolean;
  /** Inline style to apply to the animated element */
  style: React.CSSProperties;
}

/**
 * Detects whether the user prefers reduced motion.
 */
function getPrefersReducedMotion(): boolean {
  if (typeof window === 'undefined') return false;
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

/**
 * useEntranceAnimation — A custom hook that uses IntersectionObserver to detect
 * when an element enters the viewport and applies a fade-in + slide-up animation.
 *
 * Animation: opacity 0→1 + translateY(20px→0) over 400ms ease-out
 * Stagger: each sibling delays by index * 100ms
 * Respects prefers-reduced-motion: reduce — shows element immediately without animation.
 *
 * Validates: Requirements 5.5, 5.7, 12.6
 */
export function useEntranceAnimation(
  options: UseEntranceAnimationOptions = {}
): UseEntranceAnimationReturn {
  const {
    index = 0,
    duration = 400,
    staggerMs = 100,
    enabled = true,
    threshold = 0.1,
    rootMargin = '0px',
  } = options;

  const ref = useRef<HTMLElement | null>(null);
  const [hasEntered, setHasEntered] = useState(false);
  const prefersReducedMotion = useRef(getPrefersReducedMotion());

  // Listen for changes to prefers-reduced-motion
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const mql = window.matchMedia('(prefers-reduced-motion: reduce)');
    const handler = (e: MediaQueryListEvent) => {
      prefersReducedMotion.current = e.matches;
      // If reduced motion is now on and we haven't entered yet, show immediately
      if (e.matches && !hasEntered) {
        setHasEntered(true);
      }
    };

    mql.addEventListener('change', handler);
    return () => mql.removeEventListener('change', handler);
  }, [hasEntered]);

  // Set up IntersectionObserver
  useEffect(() => {
    // If animation is disabled or reduced motion is preferred, show immediately
    if (!enabled || prefersReducedMotion.current) {
      setHasEntered(true);
      return;
    }

    const element = ref.current;
    if (!element) return;

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            setHasEntered(true);
            // Only animate once — disconnect after first intersection
            observer.disconnect();
            break;
          }
        }
      },
      { threshold, rootMargin }
    );

    observer.observe(element);

    return () => {
      observer.disconnect();
    };
  }, [enabled, threshold, rootMargin]);

  // Compute the inline style
  const getStyle = useCallback((): React.CSSProperties => {
    // If reduced motion is preferred, always show fully visible with no transforms
    if (prefersReducedMotion.current || !enabled) {
      return {
        opacity: 1,
        transform: 'none',
      };
    }

    if (hasEntered) {
      return {
        opacity: 1,
        transform: 'translateY(0)',
        transition: `opacity ${duration}ms ease-out ${index * staggerMs}ms, transform ${duration}ms ease-out ${index * staggerMs}ms`,
      };
    }

    // Not yet entered — invisible and shifted down
    return {
      opacity: 0,
      transform: 'translateY(20px)',
      transition: `opacity ${duration}ms ease-out ${index * staggerMs}ms, transform ${duration}ms ease-out ${index * staggerMs}ms`,
    };
  }, [hasEntered, enabled, duration, index, staggerMs]);

  return {
    ref,
    hasEntered,
    style: getStyle(),
  };
}

export default useEntranceAnimation;

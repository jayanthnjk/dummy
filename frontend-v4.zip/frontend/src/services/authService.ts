import api from './api';
import type { LoginRequest, AuthResponse, ChangePasswordRequest } from '@/types';

export const authService = {
  login: (data: LoginRequest) =>
    api.post<AuthResponse>('/api/auth/login', data).then((r) => r.data),

  logout: () =>
    api.post<void>('/api/auth/logout'),

  changePassword: (data: ChangePasswordRequest) =>
    api.post<void>('/api/auth/change-password', data),
};

import React, { useState, useEffect } from 'react';
import { Box, Typography, CircularProgress, Paper } from '@mui/material';
import {
  sectionChartService,
  type Form168ViewData,
  type Form168DutyCard,
  type Form168DutyRow,
  type Form168LeaveRow,
} from '@/services/sectionChartService';

// ===== Styles =====
const tableStyles: Record<string, React.CSSProperties> = {
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    fontSize: '0.72rem',
    fontFamily: 'Arial, sans-serif',
  },
  th: {
    border: '1px solid #333',
    padding: '4px 6px',
    textAlign: 'center',
    fontWeight: 700,
    backgroundColor: '#f5f5f5',
    fontSize: '0.68rem',
    textTransform: 'uppercase' as const,
  },
  td: {
    border: '1px solid #999',
    padding: '3px 5px',
    textAlign: 'center',
    fontSize: '0.7rem',
    verticalAlign: 'middle',
  },
  tdLeft: {
    border: '1px solid #999',
    padding: '3px 6px',
    textAlign: 'left',
    fontSize: '0.7rem',
    verticalAlign: 'middle',
  },
  tdDetails: {
    border: '1px solid #999',
    padding: '3px 6px',
    textAlign: 'left',
    fontSize: '0.68rem',
    verticalAlign: 'middle',
    maxWidth: '300px',
    wordWrap: 'break-word' as const,
  },
  totalRow: {
    border: '1px solid #333',
    padding: '4px 6px',
    textAlign: 'center',
    fontWeight: 700,
    backgroundColor: '#e8e8e8',
    fontSize: '0.72rem',
  },
  sectionHeader: {
    border: '1px solid #333',
    padding: '6px 8px',
    textAlign: 'left',
    fontWeight: 700,
    backgroundColor: '#d4e6f1',
    fontSize: '0.78rem',
    textTransform: 'uppercase' as const,
  },
  subSectionHeader: {
    border: '1px solid #333',
    padding: '4px 6px',
    textAlign: 'left',
    fontWeight: 700,
    backgroundColor: '#eaf2f8',
    fontSize: '0.72rem',
    textTransform: 'uppercase' as const,
  },
};

// Column headers matching Form 168
const DESIG_COLS = ['ACP', 'RPI', 'RSI', 'ARSI', 'AHC', 'APC', 'SWP'];

interface Form168TableViewProps {
  sectionCode: string;
  sectionColor: string;
}

const Form168TableView: React.FC<Form168TableViewProps> = ({ sectionCode, sectionColor }) => {
  const [data, setData] = useState<Form168ViewData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (sectionCode) {
      loadData(sectionCode);
    }
  }, [sectionCode]);

  const loadData = async (code: string) => {
    setLoading(true);
    setError(null);
    try {
      const result = await sectionChartService.getForm168View(code);
      setData(result);
    } catch (err) {
      setError('Failed to load Form 168 view data');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ py: 4, textAlign: 'center' }}>
        <Typography color="error">{error}</Typography>
      </Box>
    );
  }

  if (!data) return null;

  return (
    <Paper elevation={0} sx={{ border: '1px solid', borderColor: 'divider', borderRadius: '12px', overflow: 'hidden' }}>
      {/* Header */}
      <Box sx={{ px: 3, py: 1.5, bgcolor: `${sectionColor}10`, borderBottom: '1px solid', borderColor: 'divider' }}>
        <Typography variant="h6" sx={{ fontWeight: 700, color: sectionColor }}>
          SECTION {data.sectionCode} — Form 168 View
        </Typography>
        <Typography variant="caption" color="text.secondary">
          On Duty: {data.totalOnDuty} | On Leave: {data.totalOnLeave} | Total: {data.totalPersonnel}
        </Typography>
      </Box>

      {/* Table */}
      <Box sx={{ overflowX: 'auto', p: 2 }}>
        <table style={tableStyles.table}>
          <thead>
            <tr>
              <th style={{ ...tableStyles.th, width: '30px' }}>S.No</th>
              <th style={{ ...tableStyles.th, minWidth: '180px' }}>HEADS</th>
              {DESIG_COLS.map((col) => (
                <th key={col} style={{ ...tableStyles.th, width: '38px' }}>{col}</th>
              ))}
              <th style={{ ...tableStyles.th, width: '42px' }}>TOTAL</th>
              <th style={{ ...tableStyles.th, minWidth: '250px' }}>PERSONNEL DETAILS</th>
            </tr>
          </thead>
          <tbody>
            {/* Duty Cards */}
            {data.dutyCards.map((card) => (
              <DutyCardRows key={card.dutyTypeId} card={card} />
            ))}

            {/* Duty Sub-Total Row */}
            <tr>
              <td colSpan={2} style={tableStyles.totalRow}>TOTAL (ON DUTY)</td>
              {data.dutySubTotal.slice(0, 7).map((val, i) => (
                <td key={i} style={tableStyles.totalRow}>{val || 0}</td>
              ))}
              <td style={tableStyles.totalRow}>{data.dutySubTotal[7] || 0}</td>
              <td style={tableStyles.totalRow}></td>
            </tr>

            {/* Leave Section Header */}
            <tr>
              <td colSpan={10} style={tableStyles.sectionHeader}>LEAVE</td>
            </tr>

            {/* Leave Rows */}
            {data.leaveSection.rows.map((row) => (
              <LeaveRow key={row.categoryName} row={row} />
            ))}

            {/* Leave Total */}
            <tr>
              <td colSpan={2} style={tableStyles.totalRow}>TOTAL (LEAVE)</td>
              {data.leaveSection.counts.slice(0, 7).map((val, i) => (
                <td key={i} style={tableStyles.totalRow}>{val || 0}</td>
              ))}
              <td style={tableStyles.totalRow}>{data.leaveSection.counts[7] || 0}</td>
              <td style={tableStyles.totalRow}></td>
            </tr>

            {/* Grand Total */}
            <tr>
              <td colSpan={2} style={{ ...tableStyles.totalRow, backgroundColor: '#c8dbbe', fontWeight: 800 }}>
                GRAND TOTAL
              </td>
              {data.grandTotal.slice(0, 7).map((val, i) => (
                <td key={i} style={{ ...tableStyles.totalRow, backgroundColor: '#c8dbbe', fontWeight: 800 }}>{val || 0}</td>
              ))}
              <td style={{ ...tableStyles.totalRow, backgroundColor: '#c8dbbe', fontWeight: 800 }}>
                {data.grandTotal[7] || 0}
              </td>
              <td style={{ ...tableStyles.totalRow, backgroundColor: '#c8dbbe' }}></td>
            </tr>
          </tbody>
        </table>
      </Box>
    </Paper>
  );
};

// ===== Duty Card Rows (Parent Duty with Sub-Duties) =====
const DutyCardRows: React.FC<{ card: Form168DutyCard }> = ({ card }) => {
  if (card.subDutyRows.length === 0) {
    // Empty duty type — show header only
    return (
      <>
        <tr>
          <td colSpan={10} style={tableStyles.subSectionHeader}>
            {card.dutyTypeName}
          </td>
        </tr>
      </>
    );
  }

  // If there's only one row and its subDutyName is null, show as flat (no separate header)
  const hasMultipleRows = card.subDutyRows.length > 1 || card.subDutyRows[0].subDutyName !== null;

  return (
    <>
      {/* Parent Duty Header */}
      {hasMultipleRows && (
        <tr>
          <td colSpan={10} style={tableStyles.subSectionHeader}>
            {card.dutyTypeName}
          </td>
        </tr>
      )}

      {/* Sub-Duty Rows */}
      {card.subDutyRows.map((row) => (
        <DutyRow key={`${card.dutyTypeId}-${row.serialNumber}`} row={row} parentName={!hasMultipleRows ? card.dutyTypeName : undefined} />
      ))}

      {/* Parent Total (only if multiple sub-duties) */}
      {hasMultipleRows && (
        <tr>
          <td style={tableStyles.totalRow}></td>
          <td style={{ ...tableStyles.totalRow, textAlign: 'right' }}>TOTAL</td>
          {card.counts.slice(0, 7).map((val, i) => (
            <td key={i} style={tableStyles.totalRow}>{val || 0}</td>
          ))}
          <td style={tableStyles.totalRow}>{card.counts[7] || 0}</td>
          <td style={tableStyles.totalRow}></td>
        </tr>
      )}
    </>
  );
};

// ===== Single Duty Row =====
const DutyRow: React.FC<{ row: Form168DutyRow; parentName?: string }> = ({ row, parentName }) => {
  const displayName = parentName || row.subDutyName || '—';
  const personnelText = buildPersonnelText(row.personnelByDesignation);

  return (
    <tr>
      <td style={tableStyles.td}>{row.serialNumber}</td>
      <td style={tableStyles.tdLeft}>{displayName}</td>
      {row.counts.slice(0, 7).map((val, i) => (
        <td key={i} style={tableStyles.td}>{val || 0}</td>
      ))}
      <td style={{ ...tableStyles.td, fontWeight: 600 }}>{row.total}</td>
      <td style={tableStyles.tdDetails}>{personnelText}</td>
    </tr>
  );
};

// ===== Leave Row =====
const LeaveRow: React.FC<{ row: Form168LeaveRow }> = ({ row }) => {
  const personnelText = buildPersonnelText(row.personnelByDesignation);

  return (
    <tr>
      <td style={tableStyles.td}>{row.serialNumber}</td>
      <td style={tableStyles.tdLeft}>{row.categoryName}</td>
      {row.counts.slice(0, 7).map((val, i) => (
        <td key={i} style={tableStyles.td}>{val || 0}</td>
      ))}
      <td style={{ ...tableStyles.td, fontWeight: 600 }}>{row.total}</td>
      <td style={tableStyles.tdDetails}>{personnelText}</td>
    </tr>
  );
};

// ===== Helper: Build personnel text grouped by designation =====
function buildPersonnelText(personnelByDesignation: Record<string, Array<{ displayText: string; designation?: string }>>): string {
  const parts: string[] = [];
  const desigOrder = ['RPI', 'RSI', 'ARSI', 'AHC', 'APC', 'DCP', 'ACP'];

  for (const desig of desigOrder) {
    const personnel = personnelByDesignation[desig];
    if (!personnel || personnel.length === 0) continue;
    const texts = personnel.map((p) => p.displayText).filter(Boolean);
    if (texts.length > 0) {
      parts.push(...texts);
    }
  }

  // Any remaining designations not in the standard order
  for (const [desig, personnel] of Object.entries(personnelByDesignation)) {
    if (desigOrder.includes(desig)) continue;
    if (!personnel || personnel.length === 0) continue;
    const texts = personnel.map((p) => p.displayText).filter(Boolean);
    if (texts.length > 0) {
      parts.push(...texts);
    }
  }

  return parts.join(', ');
}

export default Form168TableView;

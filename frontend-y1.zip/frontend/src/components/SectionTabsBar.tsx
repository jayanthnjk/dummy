import React, { useEffect } from 'react';
import { observer } from 'mobx-react-lite';
import { Box, Button, Typography, Select, MenuItem, FormControl, InputLabel } from '@mui/material';
import SettingsIcon from '@mui/icons-material/Settings';
import { useTranslation } from 'react-i18next';
import { dutySectionStore } from '@/stores/dutySectionStore';

/** Color palette for sections */
const SECTION_COLORS: Record<string, string> = {
  A: '#3B82F6',
  B: '#10B981',
  C: '#8B5CF6',
  D: '#F97316',
  E: '#06B6D4',
  F: '#EC4899',
  G: '#EF4444',
};

function getSectionColor(code: string): string {
  const key = code.charAt(0).toUpperCase();
  return SECTION_COLORS[key] || '#6B7280';
}

interface SectionTabsBarProps {
  onSettingsClick: () => void;
}

/**
 * SectionTabsBar — Compact dropdown section selector.
 * Shows a single Select dropdown with "All Sections" + per-section options with colored dots and counts.
 * Layout: [Section: [dropdown ▼]] [⚙️ Settings]
 */
const SectionTabsBar: React.FC<SectionTabsBarProps> = observer(({ onSettingsClick }) => {
  const { t } = useTranslation();
  const { activeSections, selectedSectionCode } = dutySectionStore;

  // Auto-select first section on mount
  useEffect(() => {
    if (activeSections.length > 0 && !selectedSectionCode) {
      dutySectionStore.selectSection(activeSections[0].code);
    }
  }, [activeSections, selectedSectionCode]);

  const handleChange = (value: string) => {
    if (value === '__ALL__') {
      // Select first section as "all" equivalent
      if (activeSections.length > 0) {
        dutySectionStore.selectSection(activeSections[0].code);
      }
    } else {
      dutySectionStore.selectSection(value);
    }
  };

  return (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        gap: 1.5,
        px: 2,
        py: 1.5,
        backgroundColor: 'white',
        borderRadius: 2,
        border: '1px solid',
        borderColor: '#E2E8F0',
        boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
      }}
    >
      {/* Section Dropdown */}
      <FormControl size="small" sx={{ minWidth: 220, flex: 1, maxWidth: 320 }}>
        <InputLabel
          id="section-select-label"
          sx={{ fontSize: '0.82rem', fontWeight: 500 }}
        >
          {t('admin.dutySections.section', 'Section')}
        </InputLabel>
        <Select
          labelId="section-select-label"
          value={selectedSectionCode || '__ALL__'}
          label={t('admin.dutySections.section', 'Section')}
          onChange={(e) => handleChange(e.target.value)}
          sx={{
            fontSize: '0.85rem',
            borderRadius: 2,
            '& .MuiSelect-select': {
              display: 'flex',
              alignItems: 'center',
              gap: 1,
              py: 1,
            },
          }}
          renderValue={(value) => {
            if (value === '__ALL__') {
              return (
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Box sx={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: '#6B7280' }} />
                  <Typography variant="body2" sx={{ fontSize: '0.85rem', fontWeight: 600 }}>
                    {t('admin.dutySections.allSections', 'All Sections')}
                  </Typography>
                </Box>
              );
            }
            const section = activeSections.find(s => s.code === value);
            if (!section) return value;
            const color = getSectionColor(section.code);
            return (
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <Box sx={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: color }} />
                <Typography variant="body2" sx={{ fontSize: '0.85rem', fontWeight: 600 }}>
                  {section.code}: {section.name}
                </Typography>
              </Box>
            );
          }}
        >
          {/* All Sections option */}
          <MenuItem value="__ALL__">
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
              <Box sx={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: '#6B7280' }} />
              <Typography variant="body2" sx={{ fontSize: '0.82rem', fontWeight: 500, flex: 1 }}>
                {t('admin.dutySections.allSections', 'All Sections')}
              </Typography>
            </Box>
          </MenuItem>

          {/* Individual section options */}
          {activeSections.map((section) => {
            const color = getSectionColor(section.code);
            const count = section.dutyTypeCount ?? 0;
            return (
              <MenuItem key={section.code} value={section.code}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
                  <Box sx={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: color }} />
                  <Typography variant="body2" sx={{ fontSize: '0.82rem', fontWeight: 500, flex: 1 }}>
                    {section.code}: {section.name}
                  </Typography>
                  {count > 0 && (
                    <Box
                      sx={{
                        backgroundColor: '#E2E8F0',
                        color: '#64748B',
                        borderRadius: '10px',
                        px: 0.75,
                        py: 0.1,
                        fontSize: '0.65rem',
                        fontWeight: 700,
                        minWidth: 18,
                        textAlign: 'center',
                      }}
                    >
                      {count}
                    </Box>
                  )}
                </Box>
              </MenuItem>
            );
          })}
        </Select>
      </FormControl>

      {/* Settings gear icon + label */}
      <Button
        onClick={onSettingsClick}
        size="small"
        startIcon={<SettingsIcon fontSize="small" />}
        sx={{
          color: '#64748B',
          backgroundColor: '#F1F5F9',
          borderRadius: 1.5,
          textTransform: 'none',
          fontWeight: 600,
          fontSize: '0.78rem',
          px: 1.5,
          py: 0.8,
          '&:hover': { backgroundColor: '#E2E8F0', color: '#1E293B' },
        }}
      >
        Manage Sections
      </Button>
    </Box>
  );
});

export default SectionTabsBar;

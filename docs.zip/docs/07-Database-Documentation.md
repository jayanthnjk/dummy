# Database Documentation
## KSP WorkBoard — Police Station Management System

| Field | Details |
|-------|---------|
| **Document Title** | Database Schema & Documentation |
| **Database Engine** | PostgreSQL 15+ with pgvector extension |
| **Schema** | public (default) |
| **Total Tables** | 22 |
| **Version** | 1.0.0 |
| **Date** | June 2026 |

---

## 1. Overview

The KSP WorkBoard uses PostgreSQL as its primary data store with the pgvector extension for document embedding similarity searches. The schema is managed manually (Hibernate ddl-auto: none) with explicit DDL scripts. All tables use BIGSERIAL primary keys and include temporal tracking columns.

---

## 2. Complete CREATE TABLE Scripts

### 2.1 Authentication & Users

```sql
-- Users table: Authentication and role management
CREATE TABLE users (
    id              BIGSERIAL PRIMARY KEY,
    username        VARCHAR(100) NOT NULL,
    password_hash   VARCHAR(255) NOT NULL,
    role            VARCHAR(20) NOT NULL,
    display_name    VARCHAR(200),
    locale          VARCHAR(5) NOT NULL DEFAULT 'en',
    personnel_id    BIGINT,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT uk_users_username UNIQUE (username),
    CONSTRAINT chk_users_role CHECK (role IN ('ADMIN', 'HIGHER_OFFICER', 'GENERAL_USER')),
    CONSTRAINT chk_users_locale CHECK (locale IN ('en', 'kn'))
);

COMMENT ON TABLE users IS 'System authentication users with role-based access. Each user optionally links to a personnel record.';
COMMENT ON COLUMN users.role IS 'ADMIN=full access, HIGHER_OFFICER=elevated ops, GENERAL_USER=basic view/chat';
COMMENT ON COLUMN users.personnel_id IS 'Optional link to personnel record for GENERAL_USER role-based leave filtering';
COMMENT ON COLUMN users.locale IS 'Preferred UI language: en=English, kn=Kannada';
```

### 2.2 Personnel Management

```sql
-- Personnel table: Core police staff records
CREATE TABLE personnel (
    id              BIGSERIAL PRIMARY KEY,
    badge_id        VARCHAR(50) NOT NULL,
    person_name     VARCHAR(200) NOT NULL,
    duty_type       VARCHAR(100),
    duty_type_id    BIGINT,
    location        VARCHAR(200),
    phone_number    VARCHAR(20),
    email           VARCHAR(200),
    designation     VARCHAR(100),
    section         VARCHAR(5) NOT NULL,
    date_of_joining DATE,
    vehicle_number  VARCHAR(50),
    duty_location   VARCHAR(200),
    pdms            VARCHAR(100),
    licence_type    VARCHAR(50),
    deployed_from   VARCHAR(200),
    platoon_id      BIGINT,
    is_active       BOOLEAN NOT NULL DEFAULT true,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT uk_personnel_badge_id UNIQUE (badge_id),
    CONSTRAINT fk_personnel_duty_type FOREIGN KEY (duty_type_id) REFERENCES duty_types(id),
    CONSTRAINT fk_personnel_platoon FOREIGN KEY (platoon_id) REFERENCES platoons(id)
);

COMMENT ON TABLE personnel IS 'Police personnel records. Badge ID format: PREFIX-NUMBER (e.g., AHC-2649). Sections: A,B,C,D,E,F,G,MT,PMT.';
COMMENT ON COLUMN personnel.badge_id IS 'Unique identifier in format PREFIX-NUMBER. Prefixes: DCP,ACP,RPI,RSI,ARSI,AHC,APC';
COMMENT ON COLUMN personnel.section IS 'Organizational section: A=Fixed, B=Office, C-G=Rotational, MT=Drivers, PMT=Strength';
COMMENT ON COLUMN personnel.platoon_id IS 'Required for sections C-G (rotational). NULL for fixed sections A,B,MT';
COMMENT ON COLUMN personnel.pdms IS 'Professional Development Management System status: DONE or NOT DONE (MT section)';
COMMENT ON COLUMN personnel.licence_type IS 'Driving licence category: LMV, HMV, LMV&HMV (MT section)';
COMMENT ON COLUMN personnel.deployed_from IS 'Original unit from which personnel was transferred';
```

### 2.3 Organizational Structure

```sql
-- Sections table: Organizational groupings
CREATE TABLE sections (
    id              BIGSERIAL PRIMARY KEY,
    code            VARCHAR(5) NOT NULL,
    name            VARCHAR(100) NOT NULL,
    description     VARCHAR(500),
    sort_order      INTEGER NOT NULL DEFAULT 0,
    is_active       BOOLEAN NOT NULL DEFAULT true,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT uk_sections_code UNIQUE (code)
);

COMMENT ON TABLE sections IS 'Organizational sections. A=Fixed/Essential, B=Office, C-G=Rotational platoon sections, MT=Motor Transport';

-- Platoons table: 5 platoons for rotational duty
CREATE TABLE platoons (
    id              BIGSERIAL PRIMARY KEY,
    name            VARCHAR(50) NOT NULL,
    base_offset     INTEGER NOT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE platoons IS 'Exactly 5 platoons that rotate through sections C-G. base_offset determines rotation order.';

-- Duty types table: Hierarchical duty definitions with geolocation
CREATE TABLE duty_types (
    id              BIGSERIAL PRIMARY KEY,
    name            VARCHAR(100) NOT NULL,
    section         VARCHAR(5) NOT NULL,
    sort_order      INTEGER NOT NULL DEFAULT 0,
    latitude        DOUBLE PRECISION,
    longitude       DOUBLE PRECISION,
    radius_meters   INTEGER DEFAULT 500,
    parent_id       BIGINT,
    CONSTRAINT fk_duty_types_parent FOREIGN KEY (parent_id) REFERENCES duty_types(id)
);

COMMENT ON TABLE duty_types IS 'Duty type hierarchy with optional geolocation for geofencing. Self-referential parent-child structure.';
COMMENT ON COLUMN duty_types.radius_meters IS 'Geofence radius in meters for duty location verification. Default 500m.';
COMMENT ON COLUMN duty_types.parent_id IS 'Self-referential FK for hierarchical duty types (e.g., GUARD > GUARD-I, GUARD-II)';
```

### 2.4 Schedule Cycle Management

```sql
-- Schedule cycles table: Platoon rotation periods
CREATE TABLE schedule_cycles (
    id              BIGSERIAL PRIMARY KEY,
    start_date      DATE NOT NULL,
    end_date        DATE NOT NULL,
    rotation_days   INTEGER NOT NULL,
    status          VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    created_by      BIGINT,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_cycle_status CHECK (status IN ('ACTIVE', 'COMPLETED', 'DELETED')),
    CONSTRAINT chk_cycle_dates CHECK (end_date >= start_date)
);

COMMENT ON TABLE schedule_cycles IS 'Platoon rotation cycles. Each cycle defines which platoon works which section for rotation_days.';
COMMENT ON COLUMN schedule_cycles.status IS 'ACTIVE=current, COMPLETED=past, DELETED=soft-deleted (data preserved)';
COMMENT ON COLUMN schedule_cycles.rotation_days IS 'Number of consecutive days. end_date = start_date + rotation_days - 1';

-- Cycle-Platoon-Section mapping: Which platoon goes to which section per cycle
CREATE TABLE cycle_platoon_sections (
    id              BIGSERIAL PRIMARY KEY,
    cycle_id        BIGINT NOT NULL,
    platoon_id      BIGINT NOT NULL,
    section_id      BIGINT NOT NULL,
    CONSTRAINT fk_cps_cycle FOREIGN KEY (cycle_id) REFERENCES schedule_cycles(id),
    CONSTRAINT fk_cps_platoon FOREIGN KEY (platoon_id) REFERENCES platoons(id),
    CONSTRAINT fk_cps_section FOREIGN KEY (section_id) REFERENCES sections(id)
);

COMMENT ON TABLE cycle_platoon_sections IS 'Maps each platoon to a section for a given cycle. Typically 5 rows per cycle (one per platoon).';

-- Cycle duty assignments: Auto-generated daily personnel assignments
CREATE TABLE cycle_duty_assignments (
    id              BIGSERIAL PRIMARY KEY,
    cycle_id        BIGINT NOT NULL,
    date            DATE NOT NULL,
    platoon_id      BIGINT NOT NULL,
    section_id      BIGINT NOT NULL,
    person_id       BIGINT NOT NULL,
    shift_type      VARCHAR(10) NOT NULL DEFAULT 'DAY',
    is_override     BOOLEAN NOT NULL DEFAULT false,
    group_index     VARCHAR(1),
    status          VARCHAR(20),
    adhoc_duty_id   BIGINT,
    duty_name       VARCHAR(100),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_cda_cycle FOREIGN KEY (cycle_id) REFERENCES schedule_cycles(id),
    CONSTRAINT fk_cda_person FOREIGN KEY (person_id) REFERENCES personnel(id),
    CONSTRAINT chk_cda_shift CHECK (shift_type IN ('DAY', 'AFTERNOON', 'NIGHT')),
    CONSTRAINT chk_cda_group CHECK (group_index IN ('A', 'B', 'C') OR group_index IS NULL)
);

COMMENT ON TABLE cycle_duty_assignments IS 'Auto-generated daily duty assignments. One record per person per day per cycle. ~3000 records per 15-day cycle with 200 rotational personnel.';
COMMENT ON COLUMN cycle_duty_assignments.shift_type IS 'Three-shift rotation: DAY, AFTERNOON, NIGHT. Rotates daily by group.';
COMMENT ON COLUMN cycle_duty_assignments.is_override IS 'True if manually reassigned from original auto-generated assignment.';
COMMENT ON COLUMN cycle_duty_assignments.group_index IS 'Shift group: A, B, or C. Personnel are divided into 3 groups for shift rotation.';
COMMENT ON COLUMN cycle_duty_assignments.status IS 'ACTIVE=normal, ON_LEAVE=person on leave, COVERED_BY_ADHOC=pulled for special duty';
COMMENT ON COLUMN cycle_duty_assignments.adhoc_duty_id IS 'If status=COVERED_BY_ADHOC, references the adhoc duty that pulled this person';
COMMENT ON COLUMN cycle_duty_assignments.duty_name IS 'Section name (e.g., "Section C") for display purposes';

-- Shift groups: Records personnel group assignments for a cycle
CREATE TABLE shift_groups (
    id              BIGSERIAL PRIMARY KEY,
    cycle_id        BIGINT NOT NULL,
    section_id      BIGINT NOT NULL,
    platoon_id      BIGINT NOT NULL,
    group_name      VARCHAR(1) NOT NULL,
    personnel_ids   TEXT,
    CONSTRAINT chk_sg_group CHECK (group_name IN ('A', 'B', 'C'))
);

COMMENT ON TABLE shift_groups IS 'Records which personnel belong to which shift group (A/B/C) for a given cycle-section-platoon.';
COMMENT ON COLUMN shift_groups.personnel_ids IS 'JSON array of personnel IDs, e.g., [1,5,12,18]';

-- Cycle audit log: Immutable change history
CREATE TABLE cycle_audit_log (
    id              BIGSERIAL PRIMARY KEY,
    cycle_id        BIGINT NOT NULL,
    action          VARCHAR(50) NOT NULL,
    description     TEXT NOT NULL,
    old_value       TEXT,
    new_value       TEXT,
    performed_by    BIGINT,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE cycle_audit_log IS 'Immutable audit trail for all cycle operations. INSERT-only, never updated or deleted.';
COMMENT ON COLUMN cycle_audit_log.action IS 'Action types: CYCLE_CREATED, CYCLE_UPDATED, CYCLE_DELETED, DUTY_REASSIGNED';
```

### 2.5 Leave Management

```sql
-- Leave requests table: Leave application workflow
CREATE TABLE leave_requests (
    id              BIGSERIAL PRIMARY KEY,
    personnel_id    BIGINT NOT NULL,
    leave_type      VARCHAR(30) NOT NULL,
    start_date      DATE NOT NULL,
    end_date        DATE NOT NULL,
    status          VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    reason          VARCHAR(500),
    approved_by     BIGINT,
    rejection_reason VARCHAR(500),
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_leave_personnel FOREIGN KEY (personnel_id) REFERENCES personnel(id),
    CONSTRAINT chk_leave_type CHECK (leave_type IN ('CASUAL_LEAVE','SICK_LEAVE','EARNED_LEAVE','WEEKLY_OFF','COMPENSATORY_OFF')),
    CONSTRAINT chk_leave_status CHECK (status IN ('PENDING','APPROVED','REJECTED','CANCELLED')),
    CONSTRAINT chk_leave_dates CHECK (end_date >= start_date)
);

COMMENT ON TABLE leave_requests IS 'Leave application workflow with approval chain. Status: PENDING→APPROVED/REJECTED, or CANCELLED by user.';
COMMENT ON COLUMN leave_requests.approved_by IS 'User ID of the approver/rejector (ADMIN or HIGHER_OFFICER)';
```

### 2.6 Adhoc Duty Management

```sql
-- Adhoc duties table: One-time special assignments
CREATE TABLE adhoc_duties (
    id              BIGSERIAL PRIMARY KEY,
    duty_name       VARCHAR(200) NOT NULL,
    date            DATE NOT NULL,
    start_time      TIME NOT NULL,
    end_time        TIME NOT NULL,
    required_count  INTEGER NOT NULL,
    actual_count    INTEGER DEFAULT 0,
    pick_from       VARCHAR(50) DEFAULT 'ALL_PLATOONS',
    platoon_ids     JSONB,
    location        VARCHAR(300),
    min_strength_check BOOLEAN DEFAULT true,
    status          VARCHAR(20) DEFAULT 'ACTIVE',
    created_by      BIGINT,
    created_at      TIMESTAMP DEFAULT NOW(),
    updated_at      TIMESTAMP DEFAULT NOW(),
    CONSTRAINT chk_adhoc_status CHECK (status IN ('ACTIVE','COMPLETED','CANCELLED')),
    CONSTRAINT chk_adhoc_pick CHECK (pick_from IN ('ALL_PLATOONS','SPECIFIC_PLATOONS'))
);

COMMENT ON TABLE adhoc_duties IS 'One-time special/bandobast duties with auto-assigned personnel. actual_count may be < required_count if insufficient available.';
COMMENT ON COLUMN adhoc_duties.platoon_ids IS 'JSONB array of platoon IDs when pick_from=SPECIFIC_PLATOONS, e.g., [1,2,3]';
COMMENT ON COLUMN adhoc_duties.min_strength_check IS 'If true, system validates minimum section strength before pulling personnel';

-- Adhoc duty assignments: Personnel assigned to adhoc duties
CREATE TABLE adhoc_duty_assignments (
    id              BIGSERIAL PRIMARY KEY,
    adhoc_duty_id   BIGINT NOT NULL,
    person_id       BIGINT NOT NULL,
    CONSTRAINT fk_ada_duty FOREIGN KEY (adhoc_duty_id) REFERENCES adhoc_duties(id),
    CONSTRAINT fk_ada_person FOREIGN KEY (person_id) REFERENCES personnel(id)
);

COMMENT ON TABLE adhoc_duty_assignments IS 'Many-to-many: personnel assigned to adhoc duties. Created during auto-assignment, preserved on cancellation for audit.';
```

### 2.7 Chat & AI

```sql
-- Chat messages: Conversation history
CREATE TABLE chat_messages (
    id              BIGSERIAL PRIMARY KEY,
    user_id         BIGINT NOT NULL,
    user_message    TEXT NOT NULL,
    ai_response     TEXT,
    command_type    VARCHAR(50),
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_chat_user FOREIGN KEY (user_id) REFERENCES users(id)
);

COMMENT ON TABLE chat_messages IS 'Persistent chat history for all user-AI interactions. command_type tracks which tool was invoked.';
COMMENT ON COLUMN chat_messages.command_type IS 'Uppercase tool name, e.g., SEARCH_PERSONNEL, CREATE_LEAVE, DIRECT_RESPONSE, GENERAL';

-- Chat audit log: Detailed interaction auditing
CREATE TABLE chat_audit_logs (
    id              BIGSERIAL PRIMARY KEY,
    user_id         BIGINT NOT NULL,
    session_id      VARCHAR(36),
    user_message    TEXT,
    detected_language VARCHAR(5),
    tool_name       VARCHAR(100),
    parameters      TEXT,
    response_type   VARCHAR(20),
    latency_ms      BIGINT,
    success         BOOLEAN,
    error_message   TEXT,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE chat_audit_logs IS 'Detailed audit of every chat interaction including tool resolution, parameters, and latency.';

-- Document chunks: RAG embeddings
CREATE TABLE document_chunks (
    id              BIGSERIAL PRIMARY KEY,
    upload_id       BIGINT,
    content         TEXT NOT NULL,
    embedding       vector(1536),
    CONSTRAINT fk_dc_upload FOREIGN KEY (upload_id) REFERENCES pdf_uploads(id)
);

COMMENT ON TABLE document_chunks IS 'PDF document chunks with vector embeddings for RAG (Retrieval-Augmented Generation) queries.';
COMMENT ON COLUMN document_chunks.embedding IS 'pgvector type: 1536-dimensional embedding vector for similarity search';

-- PDF uploads: Uploaded document metadata
CREATE TABLE pdf_uploads (
    id              BIGSERIAL PRIMARY KEY,
    user_id         BIGINT NOT NULL,
    filename        VARCHAR(255),
    file_size       BIGINT,
    page_count      INTEGER,
    uploaded_at     TIMESTAMP DEFAULT NOW()
);

COMMENT ON TABLE pdf_uploads IS 'Metadata for uploaded PDF documents that are parsed and embedded for RAG.';
```

### 2.8 Configuration & Support

```sql
-- System configuration: Key-value admin settings
CREATE TABLE system_config (
    id              BIGSERIAL PRIMARY KEY,
    config_key      VARCHAR(100) NOT NULL,
    config_value    TEXT,
    CONSTRAINT uk_config_key UNIQUE (config_key)
);

COMMENT ON TABLE system_config IS 'Admin-configurable key-value system parameters. Modifiable without deployment.';

-- Translations: i18n entries
CREATE TABLE translations (
    id              BIGSERIAL PRIMARY KEY,
    translation_key VARCHAR(200) NOT NULL,
    locale          VARCHAR(5) NOT NULL,
    translation_value TEXT NOT NULL,
    category        VARCHAR(50),
    CONSTRAINT uk_translation UNIQUE (translation_key, locale)
);

COMMENT ON TABLE translations IS 'Server-side i18n translations. Supports en (English) and kn (Kannada) locales.';

-- Holidays: Public/gazetted holiday calendar
CREATE TABLE holidays (
    id              BIGSERIAL PRIMARY KEY,
    date            DATE NOT NULL,
    name            VARCHAR(200) NOT NULL,
    type            VARCHAR(50)
);

COMMENT ON TABLE holidays IS 'Public and gazetted holidays that may affect scheduling calculations.';

-- Support tickets: User help requests
CREATE TABLE support_tickets (
    id              BIGSERIAL PRIMARY KEY,
    user_id         BIGINT NOT NULL,
    subject         VARCHAR(200) NOT NULL,
    description     TEXT,
    status          VARCHAR(20) DEFAULT 'OPEN',
    admin_response  TEXT,
    created_at      TIMESTAMP DEFAULT NOW(),
    updated_at      TIMESTAMP DEFAULT NOW(),
    CONSTRAINT fk_ticket_user FOREIGN KEY (user_id) REFERENCES users(id),
    CONSTRAINT chk_ticket_status CHECK (status IN ('OPEN','IN_PROGRESS','RESOLVED','CLOSED'))
);

COMMENT ON TABLE support_tickets IS 'Internal support ticket system for officers to report issues.';

-- Section strength: Personnel counts per section
CREATE TABLE section_strength (
    id              BIGSERIAL PRIMARY KEY,
    section_code    VARCHAR(5) NOT NULL,
    total_count     INTEGER DEFAULT 0,
    active_count    INTEGER DEFAULT 0,
    updated_at      TIMESTAMP DEFAULT NOW()
);

COMMENT ON TABLE section_strength IS 'Cached personnel counts per section for quick strength lookup.';
```

### 2.9 Legacy/Supporting Tables

```sql
-- Duty assignments: Current static duty assignments (sections A, B)
CREATE TABLE duty_assignments (
    id              BIGSERIAL PRIMARY KEY,
    personnel_id    BIGINT NOT NULL,
    duty_type_id    BIGINT NOT NULL,
    section         VARCHAR(5) NOT NULL,
    effective_date  DATE NOT NULL,
    end_date        DATE,
    shift           VARCHAR(20),
    sub_assignment  VARCHAR(200),
    is_current      BOOLEAN DEFAULT true,
    created_at      TIMESTAMP DEFAULT NOW(),
    updated_at      TIMESTAMP DEFAULT NOW(),
    CONSTRAINT fk_da_personnel FOREIGN KEY (personnel_id) REFERENCES personnel(id),
    CONSTRAINT fk_da_duty_type FOREIGN KEY (duty_type_id) REFERENCES duty_types(id)
);

COMMENT ON TABLE duty_assignments IS 'Static duty assignments for sections A and B (non-rotational). Tracks current and historical assignments.';

-- Platoon rotation schedules: Duty type rotation pattern
CREATE TABLE platoon_rotation_schedules (
    id              BIGSERIAL PRIMARY KEY,
    platoon_id      BIGINT NOT NULL,
    duty_type       VARCHAR(100) NOT NULL,
    position        INTEGER NOT NULL,
    CONSTRAINT fk_prs_platoon FOREIGN KEY (platoon_id) REFERENCES platoons(id)
);

-- Platoon rotation state: Current rotation position
CREATE TABLE platoon_rotation_states (
    id              BIGSERIAL PRIMARY KEY,
    current_cycle_index INTEGER NOT NULL DEFAULT 0,
    last_rotation_date DATE,
    next_rotation_date DATE,
    updated_at      TIMESTAMP DEFAULT NOW()
);
```

---

## 3. Index Definitions

```sql
-- =============================================
-- PERFORMANCE INDEXES
-- =============================================

-- Personnel table indexes
CREATE INDEX idx_personnel_badge_id ON personnel(badge_id);
CREATE INDEX idx_personnel_section ON personnel(section);
CREATE INDEX idx_personnel_platoon_id ON personnel(platoon_id) WHERE platoon_id IS NOT NULL;
CREATE INDEX idx_personnel_is_active ON personnel(is_active);
CREATE INDEX idx_personnel_designation ON personnel(designation) WHERE designation IS NOT NULL;
CREATE INDEX idx_personnel_duty_type ON personnel(LOWER(duty_type)) WHERE duty_type IS NOT NULL;
CREATE INDEX idx_personnel_name_trgm ON personnel USING gin (person_name gin_trgm_ops);

-- Cycle duty assignments (most queried table - ~3000 rows per cycle)
CREATE INDEX idx_cda_cycle_date ON cycle_duty_assignments(cycle_id, date);
CREATE INDEX idx_cda_person_date ON cycle_duty_assignments(person_id, date);
CREATE INDEX idx_cda_cycle_date_section ON cycle_duty_assignments(cycle_id, date, section_id);
CREATE INDEX idx_cda_cycle_date_section_person ON cycle_duty_assignments(cycle_id, date, section_id, person_id);
CREATE INDEX idx_cda_cycle_date_platoon ON cycle_duty_assignments(cycle_id, date, platoon_id);

-- Leave requests
CREATE INDEX idx_leave_personnel_id ON leave_requests(personnel_id);
CREATE INDEX idx_leave_status ON leave_requests(status);
CREATE INDEX idx_leave_dates ON leave_requests(start_date, end_date);
CREATE INDEX idx_leave_personnel_dates ON leave_requests(personnel_id, start_date, end_date);

-- Schedule cycles
CREATE INDEX idx_cycle_status ON schedule_cycles(status);
CREATE INDEX idx_cycle_status_dates ON schedule_cycles(status, start_date, end_date);

-- Cycle platoon sections
CREATE INDEX idx_cps_cycle_id ON cycle_platoon_sections(cycle_id);

-- Adhoc duties
CREATE INDEX idx_adhoc_date ON adhoc_duties(date);
CREATE INDEX idx_adhoc_status ON adhoc_duties(status);
CREATE INDEX idx_adhoc_date_status ON adhoc_duties(date, status);

-- Chat messages
CREATE INDEX idx_chat_user_id ON chat_messages(user_id);
CREATE INDEX idx_chat_created_at ON chat_messages(created_at DESC);

-- Audit logs
CREATE INDEX idx_audit_cycle_id ON cycle_audit_log(cycle_id);
CREATE INDEX idx_audit_created_at ON cycle_audit_log(created_at DESC);

-- Duty types
CREATE INDEX idx_duty_types_section ON duty_types(section);
CREATE INDEX idx_duty_types_parent ON duty_types(parent_id) WHERE parent_id IS NOT NULL;
CREATE INDEX idx_duty_types_section_sort ON duty_types(section, sort_order);

-- Translations
CREATE INDEX idx_translations_locale ON translations(locale);

-- Document chunks (vector similarity search)
CREATE INDEX idx_doc_chunks_embedding ON document_chunks USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);

-- Holidays
CREATE INDEX idx_holidays_date ON holidays(date);
```

---

## 4. Table Relationships (ER Description)

### 4.1 Relationship Matrix

| Parent Table | Child Table | FK Column | Relationship | Description |
|-------------|-------------|-----------|--------------|-------------|
| personnel | users | personnel_id | 1:0..1 | User optionally links to personnel |
| duty_types | personnel | duty_type_id | 1:N | Personnel assigned to duty type |
| platoons | personnel | platoon_id | 1:N | Personnel belongs to platoon |
| duty_types | duty_types | parent_id | 1:N (self) | Hierarchical duty types |
| schedule_cycles | cycle_platoon_sections | cycle_id | 1:N | Cycle has platoon mappings |
| platoons | cycle_platoon_sections | platoon_id | 1:N | Platoon assigned per cycle |
| sections | cycle_platoon_sections | section_id | 1:N | Section mapped per cycle |
| schedule_cycles | cycle_duty_assignments | cycle_id | 1:N | Cycle generates assignments |
| personnel | cycle_duty_assignments | person_id | 1:N | Person has daily assignments |
| personnel | leave_requests | personnel_id | 1:N | Person submits leaves |
| adhoc_duties | adhoc_duty_assignments | adhoc_duty_id | 1:N | Duty has assignees |
| personnel | adhoc_duty_assignments | person_id | 1:N | Person assigned to adhoc |
| users | chat_messages | user_id | 1:N | User has chat history |
| pdf_uploads | document_chunks | upload_id | 1:N | Document has chunks |

### 4.2 Entity Relationship Diagram

```mermaid
erDiagram
    USERS ||--o| PERSONNEL : "links to"
    PERSONNEL }o--o| DUTY_TYPES : "assigned duty"
    PERSONNEL }o--o| PLATOONS : "belongs to"
    DUTY_TYPES ||--o{ DUTY_TYPES : "parent-child"
    SCHEDULE_CYCLES ||--|{ CYCLE_PLATOON_SECTIONS : "mappings"
    CYCLE_PLATOON_SECTIONS }o--|| PLATOONS : "platoon"
    CYCLE_PLATOON_SECTIONS }o--|| SECTIONS : "section"
    SCHEDULE_CYCLES ||--|{ CYCLE_DUTY_ASSIGNMENTS : "generates"
    CYCLE_DUTY_ASSIGNMENTS }o--|| PERSONNEL : "assigned to"
    SCHEDULE_CYCLES ||--|{ CYCLE_AUDIT_LOG : "audit"
    SCHEDULE_CYCLES ||--|{ SHIFT_GROUPS : "groups"
    PERSONNEL ||--|{ LEAVE_REQUESTS : "submits"
    ADHOC_DUTIES ||--|{ ADHOC_DUTY_ASSIGNMENTS : "has"
    ADHOC_DUTY_ASSIGNMENTS }o--|| PERSONNEL : "personnel"
    USERS ||--|{ CHAT_MESSAGES : "history"
    PDF_UPLOADS ||--|{ DOCUMENT_CHUNKS : "chunks"
```

---

## 5. Table Purpose & Description

| # | Table | Purpose | Avg Rows | Growth Rate |
|---|-------|---------|----------|-------------|
| 1 | users | System authentication | 10-20 | Static |
| 2 | personnel | Staff records | 200-250 | Low (5/year) |
| 3 | sections | Org structure | 9 | Static |
| 4 | platoons | Platoon definitions | 5 | Static |
| 5 | duty_types | Duty catalog | 30-50 | Low |
| 6 | schedule_cycles | Rotation periods | 20-50/year | 2/month |
| 7 | cycle_platoon_sections | Platoon-section maps | 5 per cycle | With cycles |
| 8 | cycle_duty_assignments | Daily assignments | ~3000/cycle | High |
| 9 | shift_groups | Group membership | 15 per cycle | With cycles |
| 10 | cycle_audit_log | Change audit | 10-50/cycle | Medium |
| 11 | leave_requests | Leave applications | 500-1000/year | Medium |
| 12 | adhoc_duties | Special duties | 50-100/year | Low-Medium |
| 13 | adhoc_duty_assignments | Adhoc personnel | 10-30 per duty | With adhoc |
| 14 | duty_assignments | Static assignments | 100-150 | Low |
| 15 | chat_messages | Chat history | 5000-20000/year | High |
| 16 | chat_audit_logs | Detailed audit | Same as chat | High |
| 17 | document_chunks | RAG embeddings | 100-500 | Low |
| 18 | pdf_uploads | Upload metadata | 10-50 | Low |
| 19 | system_config | App settings | 10-20 | Static |
| 20 | translations | i18n text | 200-500 | Low |
| 21 | holidays | Calendar | 20-30/year | Low |
| 22 | support_tickets | Help requests | 50-100/year | Low |

---

## 6. Data Flow: API → Query → Table

### 6.1 Personnel Search Query Flow

```
GET /api/personnel?search=jayanth&section=A&isActive=true

→ PersonnelService.listPersonnel(filter, pageable)
→ JPA Specification builds:
    SELECT * FROM personnel
    WHERE (LOWER(badge_id) LIKE '%jayanth%'
           OR LOWER(person_name) LIKE '%jayanth%'
           OR LOWER(duty_type) LIKE '%jayanth%'
           OR LOWER(email) LIKE '%jayanth%'
           ...)
      AND section = 'A'
      AND is_active = true
    ORDER BY person_name ASC
    LIMIT 20 OFFSET 0
```

### 6.2 Cycle Creation Query Flow

```
POST /api/cycles

→ CycleService.createCycle()
→ 1. SELECT * FROM schedule_cycles WHERE status='ACTIVE' AND start_date <= ? AND end_date >= ?
→ 2. INSERT INTO schedule_cycles (start_date, end_date, rotation_days, status) VALUES (...)
→ 3. INSERT INTO cycle_platoon_sections (cycle_id, platoon_id, section_id) VALUES (...) × 5
→ 4. SELECT * FROM personnel WHERE platoon_id = ? AND is_active = true  (×5 platoons)
→ 5. INSERT INTO shift_groups (...) × 15 (5 platoons × 3 groups)
→ 6. INSERT INTO cycle_duty_assignments (...) × ~3000 (bulk)
→ 7. INSERT INTO cycle_audit_log (cycle_id, action, description) VALUES (...)
```

### 6.3 Leave Conflict Check Query Flow

```
POST /api/leave-requests

→ LeaveService.submit()
→ 1. SELECT * FROM personnel WHERE id = ?
→ 2. SELECT * FROM leave_requests
       WHERE personnel_id = ? AND start_date <= ? AND end_date >= ? AND status != 'CANCELLED'
→ 3. INSERT INTO leave_requests (...) VALUES (...)
→ 4. SELECT * FROM cycle_duty_assignments WHERE person_id = ? AND date = ?  (per day in range)
```

---

## 7. Database Configuration

```yaml
# application.yml
spring:
  datasource:
    url: ${DB_URL}                    # jdbc:postgresql://host:5432/ksp_workboard
    username: ${DB_USERNAME}
    password: ${DB_PASSWORD}
    driver-class-name: org.postgresql.Driver
  jpa:
    hibernate:
      ddl-auto: none                  # Manual schema management
    open-in-view: false               # Prevent lazy-loading issues
    properties:
      hibernate:
        dialect: org.hibernate.dialect.PostgreSQLDialect
        format_sql: true
```

### 7.1 pgvector Extension Setup

```sql
-- Required for document embeddings (RAG feature)
CREATE EXTENSION IF NOT EXISTS vector;

-- Required for trigram text search (optional, for fuzzy name matching)
CREATE EXTENSION IF NOT EXISTS pg_trgm;
```

---

## 8. Data Integrity Rules

| Rule | Enforcement Level | Description |
|------|-------------------|-------------|
| Badge ID uniqueness | DB constraint + Service check | Prevents duplicate personnel |
| Cycle date non-overlap | Service-level query | No two ACTIVE cycles with overlapping dates |
| Leave date non-overlap | Repository query | No overlapping leaves for same person |
| Section code uniqueness | DB constraint | Each section code appears once |
| Translation uniqueness | DB constraint | One translation per (key, locale) |
| Audit immutability | No UPDATE/DELETE operations | Audit tables are append-only |
| Referential integrity | FK constraints | Personnel, cycles, sections properly linked |
| Check constraints | DB-level | Valid enums for status, role, leave_type, shift_type |

---

## 9. Backup & Maintenance

### 9.1 Recommended Backup Strategy

```bash
# Daily full backup
pg_dump -h localhost -U ksp_user -d ksp_workboard -Fc -f /backups/ksp_$(date +%Y%m%d).dump

# Restore
pg_restore -h localhost -U ksp_user -d ksp_workboard /backups/ksp_20260621.dump
```

### 9.2 Table Maintenance

```sql
-- Analyze tables after bulk inserts (cycle creation)
ANALYZE cycle_duty_assignments;
ANALYZE personnel;

-- Vacuum to reclaim space after soft-deletes
VACUUM ANALYZE schedule_cycles;
VACUUM ANALYZE leave_requests;
```

---

## 10. Document Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0.0 | June 2026 | Generated from Codebase | Initial complete DB docs |

---

*End of Document — Database Documentation v1.0.0*

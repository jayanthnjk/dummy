import { makeAutoObservable, runInAction } from 'mobx';
import {
  AvailableReport,
  ReportEmailConfig,
  ReportSpecificEmailConfig,
  getAvailableReports,
  getAllReportEmailConfigs,
  createReportEmailConfig,
  updateReportEmailConfig,
  deleteReportEmailConfig,
  getAllReportSpecificEmailConfigs,
  createReportSpecificEmailConfig,
  updateReportSpecificEmailConfig,
  deleteReportSpecificEmailConfig,
} from '@/services/reportEmailConfigApi';

/**
 * MobX Store for Report Email Configuration management.
 * Manages state for both Generate Reports Configuration and Report Specific Email Configuration.
 */
class ReportEmailConfigStore {
  // ─── State ─────────────────────────────────────────────────────────────────
  availableReports: AvailableReport[] = [];
  reportEmailConfigs: ReportEmailConfig[] = [];
  reportSpecificEmailConfigs: ReportSpecificEmailConfig[] = [];
  
  loading = false;
  error: string | null = null;
  
  // Dialog states
  generateConfigDialogOpen = false;
  specificConfigDialogOpen = false;
  editingGenerateConfig: ReportEmailConfig | null = null;
  editingSpecificConfig: ReportSpecificEmailConfig | null = null;
  
  // Delete confirmation
  deleteConfirmDialogOpen = false;
  deleteTarget: { type: 'generate' | 'specific'; id: number } | null = null;

  constructor() {
    makeAutoObservable(this);
  }

  // ─── Actions: Loading Data ─────────────────────────────────────────────────

  async loadAvailableReports() {
    try {
      const reports = await getAvailableReports();
      runInAction(() => {
        this.availableReports = reports;
      });
    } catch (error: unknown) {
      console.error('Failed to load available reports:', error);
    }
  }

  async loadReportEmailConfigs() {
    this.loading = true;
    this.error = null;
    try {
      const configs = await getAllReportEmailConfigs();
      runInAction(() => {
        this.reportEmailConfigs = configs;
        this.loading = false;
      });
    } catch (error: unknown) {
      runInAction(() => {
        this.error = error instanceof Error ? error.message : 'Failed to load configurations';
        this.loading = false;
      });
    }
  }

  async loadReportSpecificEmailConfigs() {
    this.loading = true;
    this.error = null;
    try {
      const configs = await getAllReportSpecificEmailConfigs();
      runInAction(() => {
        this.reportSpecificEmailConfigs = configs;
        this.loading = false;
      });
    } catch (error: unknown) {
      runInAction(() => {
        this.error = error instanceof Error ? error.message : 'Failed to load configurations';
        this.loading = false;
      });
    }
  }

  async loadAllData() {
    this.loading = true;
    this.error = null;
    try {
      const [reports, generateConfigs, specificConfigs] = await Promise.all([
        getAvailableReports(),
        getAllReportEmailConfigs(),
        getAllReportSpecificEmailConfigs(),
      ]);
      runInAction(() => {
        this.availableReports = reports;
        this.reportEmailConfigs = generateConfigs;
        this.reportSpecificEmailConfigs = specificConfigs;
        this.loading = false;
      });
    } catch (error: unknown) {
      runInAction(() => {
        this.error = error instanceof Error ? error.message : 'Failed to load data';
        this.loading = false;
      });
    }
  }

  // ─── Actions: Generate Reports Configuration ───────────────────────────────

  openGenerateConfigDialog(config?: ReportEmailConfig) {
    this.editingGenerateConfig = config || null;
    this.generateConfigDialogOpen = true;
  }

  closeGenerateConfigDialog() {
    this.generateConfigDialogOpen = false;
    this.editingGenerateConfig = null;
  }

  async saveGenerateConfig(config: ReportEmailConfig): Promise<boolean> {
    this.loading = true;
    this.error = null;
    try {
      if (this.editingGenerateConfig?.id) {
        await updateReportEmailConfig(this.editingGenerateConfig.id, config);
      } else {
        await createReportEmailConfig(config);
      }
      await this.loadReportEmailConfigs();
      runInAction(() => {
        this.closeGenerateConfigDialog();
        this.loading = false;
      });
      return true;
    } catch (error: unknown) {
      runInAction(() => {
        this.error = error instanceof Error ? error.message : 'Failed to save configuration';
        this.loading = false;
      });
      return false;
    }
  }

  async deleteGenerateConfig(id: number): Promise<boolean> {
    this.loading = true;
    this.error = null;
    try {
      await deleteReportEmailConfig(id);
      await this.loadReportEmailConfigs();
      runInAction(() => {
        this.loading = false;
        this.closeDeleteConfirmDialog();
      });
      return true;
    } catch (error: unknown) {
      runInAction(() => {
        this.error = error instanceof Error ? error.message : 'Failed to delete configuration';
        this.loading = false;
      });
      return false;
    }
  }

  // ─── Actions: Report Specific Email Configuration ──────────────────────────

  openSpecificConfigDialog(config?: ReportSpecificEmailConfig) {
    this.editingSpecificConfig = config || null;
    this.specificConfigDialogOpen = true;
  }

  closeSpecificConfigDialog() {
    this.specificConfigDialogOpen = false;
    this.editingSpecificConfig = null;
  }

  async saveSpecificConfig(config: ReportSpecificEmailConfig): Promise<boolean> {
    this.loading = true;
    this.error = null;
    try {
      if (this.editingSpecificConfig?.id) {
        await updateReportSpecificEmailConfig(this.editingSpecificConfig.id, config);
      } else {
        await createReportSpecificEmailConfig(config);
      }
      await this.loadReportSpecificEmailConfigs();
      runInAction(() => {
        this.closeSpecificConfigDialog();
        this.loading = false;
      });
      return true;
    } catch (error: unknown) {
      runInAction(() => {
        this.error = error instanceof Error ? error.message : 'Failed to save configuration';
        this.loading = false;
      });
      return false;
    }
  }

  async deleteSpecificConfig(id: number): Promise<boolean> {
    this.loading = true;
    this.error = null;
    try {
      await deleteReportSpecificEmailConfig(id);
      await this.loadReportSpecificEmailConfigs();
      runInAction(() => {
        this.loading = false;
        this.closeDeleteConfirmDialog();
      });
      return true;
    } catch (error: unknown) {
      runInAction(() => {
        this.error = error instanceof Error ? error.message : 'Failed to delete configuration';
        this.loading = false;
      });
      return false;
    }
  }

  // ─── Actions: Delete Confirmation Dialog ───────────────────────────────────

  openDeleteConfirmDialog(type: 'generate' | 'specific', id: number) {
    this.deleteTarget = { type, id };
    this.deleteConfirmDialogOpen = true;
  }

  closeDeleteConfirmDialog() {
    this.deleteConfirmDialogOpen = false;
    this.deleteTarget = null;
  }

  async confirmDelete(): Promise<boolean> {
    if (!this.deleteTarget) return false;
    
    if (this.deleteTarget.type === 'generate') {
      return this.deleteGenerateConfig(this.deleteTarget.id);
    } else {
      return this.deleteSpecificConfig(this.deleteTarget.id);
    }
  }

  // ─── Helper Methods ────────────────────────────────────────────────────────

  getReportNameByType(reportType: string): string {
    const report = this.availableReports.find(r => r.reportType === reportType);
    return report?.reportName || reportType;
  }

  getConfiguredReportTypes(): string[] {
    return this.reportSpecificEmailConfigs.map(c => c.reportType);
  }

  getUnconfiguredReports(): AvailableReport[] {
    const configured = this.getConfiguredReportTypes();
    return this.availableReports.filter(r => !configured.includes(r.reportType));
  }

  clearError() {
    this.error = null;
  }
}

export const reportEmailConfigStore = new ReportEmailConfigStore();

# UAT Test Cases
## KSP WorkBoard — User Acceptance Testing

| Field | Details |
|-------|---------|
| **Document Title** | UAT Sign-off Document |
| **Version** | 1.0.0 |
| **Date** | June 2026 |
| **Total Test Cases** | 85 |

---

## 1. UAT Overview

This document contains end-to-end User Acceptance Test cases organized by module. Each test case includes step-by-step instructions, expected results, and pass/fail criteria for client validation.

---

## 2. Module: Authentication (8 Test Cases)

| TC# | Test Case | Steps | Expected Result | Status |
|-----|-----------|-------|-----------------|--------|
| UAT-AUTH-01 | Successful Login | 1. Open app 2. Enter valid username/password 3. Click Login | Redirects to Home, shows display name | ☐ |
| UAT-AUTH-02 | Invalid Credentials | 1. Enter wrong password 2. Click Login | Shows "Invalid credentials" error | ☐ |
| UAT-AUTH-03 | Empty Username | 1. Leave username blank 2. Click Login | Validation error shown | ☐ |
| UAT-AUTH-04 | Token Expiry | 1. Login 2. Wait 24 hours (or modify token) | Redirects to login on next API call | ☐ |
| UAT-AUTH-05 | Inactivity Logout | 1. Login 2. Do nothing for 15 minutes | Warning dialog appears, then auto-logout | ☐ |
| UAT-AUTH-06 | Logout | 1. Login 2. Click Logout | Returns to login page, token cleared | ☐ |
| UAT-AUTH-07 | Change Password | 1. Login 2. Change password 3. Logout 4. Login with new password | Login succeeds with new password | ☐ |
| UAT-AUTH-08 | Role-Based Nav | 1. Login as GENERAL_USER | Admin Config not visible in sidebar | ☐ |

---

## 3. Module: Personnel Management (12 Test Cases)

| TC# | Test Case | Steps | Expected Result | Status |
|-----|-----------|-------|-----------------|--------|
| UAT-PERS-01 | View Personnel List | 1. Navigate to Personnel page | Table shows all active personnel with pagination | ☐ |
| UAT-PERS-02 | Search by Name | 1. Type "Jayanth" in search box | Shows matching records | ☐ |
| UAT-PERS-03 | Search by Badge ID | 1. Type "AHC-2649" in search | Shows exact personnel record | ☐ |
| UAT-PERS-04 | Filter by Section | 1. Select Section = "A" | Shows only Section A personnel | ☐ |
| UAT-PERS-05 | Filter by Designation | 1. Select Designation = "AHC" | Shows only AHC-ranked personnel | ☐ |
| UAT-PERS-06 | View Profile | 1. Click on a personnel row | Profile page shows all details | ☐ |
| UAT-PERS-07 | Add Personnel | 1. Click Add 2. Fill name, badge, section 3. Save | Record created, appears in list | ☐ |
| UAT-PERS-08 | Duplicate Badge Error | 1. Try adding person with existing badge ID | Shows "Badge ID already exists" error | ☐ |
| UAT-PERS-09 | Edit Personnel | 1. Open profile 2. Edit phone number 3. Save | Updated successfully | ☐ |
| UAT-PERS-10 | Driver Validation | 1. Add person with dutyType=DRIVER 2. Leave vehicle/pdms/licence blank | Shows validation error for missing driver fields | ☐ |
| UAT-PERS-11 | Delete Personnel (Admin) | 1. Login as ADMIN 2. Delete a personnel | Record removed from list | ☐ |
| UAT-PERS-12 | Delete Denied (Non-Admin) | 1. Login as HIGHER_OFFICER 2. Try delete | Gets 403 Forbidden | ☐ |

---

## 4. Module: Cycle Management (12 Test Cases)

| TC# | Test Case | Steps | Expected Result | Status |
|-----|-----------|-------|-----------------|--------|
| UAT-CYC-01 | View Cycles List | 1. Navigate to Schedules → Cycles | Shows all active/completed cycles | ☐ |
| UAT-CYC-02 | Create Cycle | 1. Click Create 2. Review auto-filled form 3. Submit | Cycle created with correct dates and mappings | ☐ |
| UAT-CYC-03 | Auto-Generate Mappings | 1. Create cycle after previous one exists | Platoon-section mappings shifted +1 from previous | ☐ |
| UAT-CYC-04 | Overlap Prevention | 1. Try creating cycle overlapping existing active cycle | Shows overlap error with existing cycle details | ☐ |
| UAT-CYC-05 | Next Available Date | 1. Open create form | Start date auto-fills as day after last cycle ends | ☐ |
| UAT-CYC-06 | View Cycle Details | 1. Click on a cycle | Shows all details including platoon-section mappings | ☐ |
| UAT-CYC-07 | Update Cycle | 1. Edit cycle 2. Change rotation days | End date recalculated, assignments regenerated | ☐ |
| UAT-CYC-08 | Delete Cycle | 1. Delete a cycle | Status changes to DELETED, still visible with filter | ☐ |
| UAT-CYC-09 | View Assignments | 1. Select a cycle and date | Shows all personnel assignments with shifts | ☐ |
| UAT-CYC-10 | Manual Reassignment | 1. Click Reassign 2. Select replacement | Assignment updated, shows override flag | ☐ |
| UAT-CYC-11 | Auto Reassignment | 1. Click Auto-Reassign on a leave-conflicting assignment | System picks replacement from other platoon | ☐ |
| UAT-CYC-12 | View Activities | 1. Navigate to Activities page | Shows audit log with all cycle changes | ☐ |

---

## 5. Module: Leave Management (10 Test Cases)

| TC# | Test Case | Steps | Expected Result | Status |
|-----|-----------|-------|-----------------|--------|
| UAT-LEAVE-01 | Submit Leave | 1. Create leave request with valid data | Status=PENDING, shows in list | ☐ |
| UAT-LEAVE-02 | Overlapping Leave Rejected | 1. Submit leave overlapping existing one | Shows "Overlapping leave request exists" | ☐ |
| UAT-LEAVE-03 | Duty Conflict Warning | 1. Submit leave on a day with duty assignment | Shows leave created + duty conflict warning | ☐ |
| UAT-LEAVE-04 | Approve Leave | 1. Login as ADMIN 2. Approve pending leave | Status changes to APPROVED | ☐ |
| UAT-LEAVE-05 | Reject Leave with Reason | 1. Reject leave 2. Enter reason | Status=REJECTED, reason saved | ☐ |
| UAT-LEAVE-06 | Cancel Pending Leave | 1. Cancel own pending leave | Status=CANCELLED | ☐ |
| UAT-LEAVE-07 | Cannot Cancel Past Leave | 1. Try cancelling leave with end_date in past | Shows "Cannot cancel past leave requests" | ☐ |
| UAT-LEAVE-08 | GENERAL_USER Visibility | 1. Login as GENERAL_USER | Only sees own leave requests | ☐ |
| UAT-LEAVE-09 | Filter by Status | 1. Filter by PENDING | Shows only pending requests | ☐ |
| UAT-LEAVE-10 | All Leave Types | 1. Create one of each type (Casual, Sick, Earned, Weekly Off, Comp Off) | All 5 types create successfully | ☐ |

---

## 6. Module: Adhoc Duties (8 Test Cases)

| TC# | Test Case | Steps | Expected Result | Status |
|-----|-----------|-------|-----------------|--------|
| UAT-ADHOC-01 | Create Adhoc Duty | 1. Fill form (name, date, time, count) 2. Submit | Duty created with auto-assigned personnel | ☐ |
| UAT-ADHOC-02 | Personnel Auto-Assignment | 1. Create duty needing 10 people | Shows actual_count=10 (or less if insufficient) | ☐ |
| UAT-ADHOC-03 | Preview Available | 1. Use preview before creating | Shows list of available candidates | ☐ |
| UAT-ADHOC-04 | Cancel Adhoc Duty | 1. Cancel an active duty | Status=CANCELLED, personnel released | ☐ |
| UAT-ADHOC-05 | List with Date Filter | 1. Filter by specific date | Shows only duties on that date | ☐ |
| UAT-ADHOC-06 | Download PDF Report | 1. Click download PDF for a duty | PDF downloads with duty details and personnel | ☐ |
| UAT-ADHOC-07 | Download Excel Report | 1. Click download Excel | Excel file with assignment data | ☐ |
| UAT-ADHOC-08 | Specific Platoons | 1. Create with pickFrom=SPECIFIC_PLATOONS | Only personnel from specified platoons assigned | ☐ |

---

## 7. Module: AI Chat (15 Test Cases)

| TC# | Test Case | Steps | Expected Result | Status |
|-----|-----------|-------|-----------------|--------|
| UAT-CHAT-01 | Greeting | 1. Type "hello" | Gets greeting response with suggestions | ☐ |
| UAT-CHAT-02 | Personnel Search | 1. Type "show personnel list" | Returns table with personnel data | ☐ |
| UAT-CHAT-03 | Badge ID Lookup | 1. Type "details of AHC 2649" | Returns specific person's details | ☐ |
| UAT-CHAT-04 | Kannada Input | 1. Type "ಸಿಬ್ಬಂದಿ ಪಟ್ಟಿ ತೋರಿಸು" | Returns personnel list (responds in Kannada) | ☐ |
| UAT-CHAT-05 | Create Leave via Chat | 1. Type "create sick leave for AHC 2649 on June 25 2026" | Leave created with correct details | ☐ |
| UAT-CHAT-06 | Create Cycle via Chat | 1. Type "create platoon" | Returns pre-filled form | ☐ |
| UAT-CHAT-07 | Form Submission | 1. Fill and submit chat form | Gets confirmation response | ☐ |
| UAT-CHAT-08 | Download Report | 1. Type "download platoon chart" | PDF file downloads | ☐ |
| UAT-CHAT-09 | Voice Input | 1. Record voice saying "show schedule" | Transcribes and shows schedule | ☐ |
| UAT-CHAT-10 | PDF Upload | 1. Upload a PDF document | Confirms upload and allows querying | ☐ |
| UAT-CHAT-11 | Leave Status Query | 1. Type "show leave status" | Returns leave details table | ☐ |
| UAT-CHAT-12 | Duty Types Query | 1. Type "show duty types" | Returns duty type list | ☐ |
| UAT-CHAT-13 | Adhoc via Chat | 1. Type "create adhoc duty" | Returns form or creates duty | ☐ |
| UAT-CHAT-14 | Prompt Injection | 1. Type injection attempt | Gets "cannot be processed" message | ☐ |
| UAT-CHAT-15 | Unknown Command | 1. Type nonsensical query | Gets helpful suggestions | ☐ |

---

## 8. Module: Reports (10 Test Cases)

| TC# | Test Case | Steps | Expected Result | Status |
|-----|-----------|-------|-----------------|--------|
| UAT-RPT-01 | Platoon Chart PDF | 1. Navigate to Reports 2. Download Platoon Chart | PDF with current rotation data | ☐ |
| UAT-RPT-02 | Form 168 PDF | 1. Download Form 168 | Daily statement PDF with correct date | ☐ |
| UAT-RPT-03 | Section A PDF | 1. Download Section A | PDF with Section A personnel and duties | ☐ |
| UAT-RPT-04 | MT Section PDF | 1. Download MT Section | PDF with drivers, vehicles, licences | ☐ |
| UAT-RPT-05 | Leave Statement PDF | 1. Download Leave Statement | PDF with leave request summary | ☐ |
| UAT-RPT-06 | Excel Report | 1. Download any Excel variant | Valid .xlsx file opens in Excel | ☐ |
| UAT-RPT-07 | Filtered Report | 1. Download Leave Statement with status=APPROVED | Only approved leaves in report | ☐ |
| UAT-RPT-08 | Date-Based Report | 1. Download Form 168 with specific date | Report shows data for that date | ☐ |
| UAT-RPT-09 | Correct Filename | 1. Download any report | Filename includes current date (dd-MM-yyyy) | ☐ |
| UAT-RPT-10 | Personnel Report | 1. Download with section=MT filter | Only MT section personnel in report | ☐ |

---

## 9. Module: Admin (10 Test Cases)

| TC# | Test Case | Steps | Expected Result | Status |
|-----|-----------|-------|-----------------|--------|
| UAT-ADM-01 | Access Admin Page | 1. Login as ADMIN 2. Navigate to Admin Config | Duty Sections page loads | ☐ |
| UAT-ADM-02 | Access Denied Non-Admin | 1. Login as GENERAL_USER 2. Navigate to /admin/* | Redirected away | ☐ |
| UAT-ADM-03 | Create Duty Type | 1. Add new duty type with name and section | Appears in duty type list | ☐ |
| UAT-ADM-04 | Update Duty Type | 1. Edit duty type name | Name updated | ☐ |
| UAT-ADM-05 | Delete Duty Type | 1. Delete unused duty type | Removed from list | ☐ |
| UAT-ADM-06 | Geolocation Map | 1. Set lat/lng on duty type | Map pin displays at location | ☐ |
| UAT-ADM-07 | View System Config | 1. GET /api/admin/config | Returns config key-values | ☐ |
| UAT-ADM-08 | Update System Config | 1. PUT /api/admin/config with new values | Values updated | ☐ |
| UAT-ADM-09 | Holiday Management | 1. Add holiday 2. Verify in list | Holiday appears | ☐ |
| UAT-ADM-10 | Support Ticket Response | 1. Respond to support ticket | User can see admin response | ☐ |

---

## 10. Sign-off

| Module | Test Cases | Passed | Failed | Blocked | Sign-off |
|--------|-----------|--------|--------|---------|----------|
| Authentication | 8 | ☐ | ☐ | ☐ | _____________ |
| Personnel | 12 | ☐ | ☐ | ☐ | _____________ |
| Cycles | 12 | ☐ | ☐ | ☐ | _____________ |
| Leave | 10 | ☐ | ☐ | ☐ | _____________ |
| Adhoc | 8 | ☐ | ☐ | ☐ | _____________ |
| Chat | 15 | ☐ | ☐ | ☐ | _____________ |
| Reports | 10 | ☐ | ☐ | ☐ | _____________ |
| Admin | 10 | ☐ | ☐ | ☐ | _____________ |
| **Total** | **85** | | | | |

**UAT Sign-off Date:** ________________  
**Signed By:** ________________  
**Role:** ________________

---

*End of Document — UAT Test Cases v1.0.0*

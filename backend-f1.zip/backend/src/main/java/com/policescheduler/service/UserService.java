package com.policescheduler.service;

import com.policescheduler.dto.CreateUserRequest;
import com.policescheduler.dto.UserDto;
import com.policescheduler.entity.User;
import com.policescheduler.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserService {

    private static final Logger log = LoggerFactory.getLogger(UserService.class);

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public List<UserDto> getAllUsers() {
        return userRepository.findAll().stream()
                .map(UserDto::new)
                .collect(Collectors.toList());
    }

    public UserDto getUserById(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("User not found with id: " + id));
        return new UserDto(user);
    }

    @Transactional
    public UserDto createUser(CreateUserRequest request) {
        log.info("Creating new user with username: {}", request.getUsername());

        // Validate password is provided for new user
        if (request.getPassword() == null || request.getPassword().isBlank()) {
            throw new IllegalArgumentException("Password is required for new user");
        }

        // Check if username already exists
        if (userRepository.findByUsername(request.getUsername()).isPresent()) {
            throw new IllegalArgumentException("Username already exists: " + request.getUsername());
        }

        // Check if email already exists (if provided)
        if (request.getEmail() != null && !request.getEmail().isBlank()) {
            if (userRepository.findByEmailIgnoreCase(request.getEmail()).isPresent()) {
                throw new IllegalArgumentException("Email already exists: " + request.getEmail());
            }
        }

        // Validate role
        User.Role role;
        try {
            role = User.Role.valueOf(request.getRole().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid role: " + request.getRole() + 
                ". Valid roles are: ADMIN, GENERAL_USER, SUPPORT_ADMIN");
        }

        User user = new User();
        user.setUsername(request.getUsername());
        user.setPasswordHash(passwordEncoder.encode(request.getPassword()));
        user.setDisplayName(request.getDisplayName());
        user.setEmail(request.getEmail());
        user.setRole(role);
        user.setPersonnelId(request.getPersonnelId());
        user.setLocale(request.getLocale() != null ? request.getLocale() : "en");

        // Set units: ADMIN and SUPPORT_ADMIN get "CAR,MT" by default, GENERAL_USER gets what's specified
        if (role == User.Role.ADMIN || role == User.Role.SUPPORT_ADMIN) {
            user.setUnits("CAR,MT");
        } else {
            user.setUnits(request.getUnits() != null && !request.getUnits().isBlank() ? request.getUnits() : "CAR");
        }

        User savedUser = userRepository.save(user);
        log.info("User created successfully with id: {}", savedUser.getId());

        return new UserDto(savedUser);
    }

    @Transactional
    public UserDto updateUser(Long id, CreateUserRequest request) {
        log.info("Updating user with id: {}", id);

        User user = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("User not found with id: " + id));

        // Check if username is being changed and if it already exists
        if (!user.getUsername().equals(request.getUsername())) {
            if (userRepository.findByUsername(request.getUsername()).isPresent()) {
                throw new IllegalArgumentException("Username already exists: " + request.getUsername());
            }
            user.setUsername(request.getUsername());
        }

        // Check if email is being changed and if it already exists
        if (request.getEmail() != null && !request.getEmail().isBlank()) {
            if (!request.getEmail().equalsIgnoreCase(user.getEmail())) {
                if (userRepository.findByEmailIgnoreCase(request.getEmail()).isPresent()) {
                    throw new IllegalArgumentException("Email already exists: " + request.getEmail());
                }
            }
            user.setEmail(request.getEmail());
        } else {
            user.setEmail(null);
        }

        // Update password only if provided
        if (request.getPassword() != null && !request.getPassword().isBlank()) {
            user.setPasswordHash(passwordEncoder.encode(request.getPassword()));
        }

        // Validate and update role
        User.Role role;
        try {
            role = User.Role.valueOf(request.getRole().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid role: " + request.getRole());
        }
        user.setRole(role);

        user.setDisplayName(request.getDisplayName());
        user.setPersonnelId(request.getPersonnelId());
        user.setLocale(request.getLocale() != null ? request.getLocale() : "en");

        User savedUser = userRepository.save(user);
        log.info("User updated successfully with id: {}", savedUser.getId());

        return new UserDto(savedUser);
    }

    @Transactional
    public void deleteUser(Long id) {
        log.info("Deleting user with id: {}", id);

        User user = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("User not found with id: " + id));

        userRepository.delete(user);
        log.info("User deleted successfully with id: {}", id);
    }
}

import React, { useRef, useEffect } from 'react';
import { Box, Typography, Avatar } from '@mui/material';
import SecurityIcon from '@mui/icons-material/Security';
import ResponseRenderer from './chat/ResponseRenderer';

import type { TableResponseData, FormResponseData, ConfirmationResponseData, SuggestionsResponseData } from '@/types';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  responseType?: 'text' | 'table' | 'form' | 'confirmation' | 'suggestions';
  data?: TableResponseData | FormResponseData | ConfirmationResponseData | SuggestionsResponseData;
}

interface ChatConversationProps {
  messages: ChatMessage[];
  userName?: string;
  onFormSubmit: (formId: string, submitAction: string, fields: Record<string, string>) => Promise<boolean>;
  onSuggestionClick: (suggestion: string) => void;
}

const ChatConversation: React.FC<ChatConversationProps> = ({ messages, userName, onFormSubmit, onSuggestionClick }) => {
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <Box sx={{ flex: 1, overflowY: 'auto', px: { xs: 2, md: 3 }, py: 2, display: 'flex', flexDirection: 'column', gap: 2.5 }}>
      {messages.map((msg) => {
        const isUser = msg.role === 'user';
        return (
          <Box key={msg.id} sx={{ display: 'flex', gap: 1.5, flexDirection: isUser ? 'row-reverse' : 'row', alignItems: 'flex-start' }}>
            {/* Avatar */}
            {isUser ? (
              <Avatar sx={{ width: 30, height: 30, bgcolor: '#1a1e4a', fontSize: '0.7rem', fontWeight: 700, color: '#c4a44a', flexShrink: 0 }}>
                {userName?.charAt(0)?.toUpperCase() || 'U'}
              </Avatar>
            ) : (
              <Avatar sx={{ width: 30, height: 30, bgcolor: '#1a1e4a', borderRadius: 1.5, flexShrink: 0 }}>
                <SecurityIcon sx={{ fontSize: 16, color: '#c4a44a' }} />
              </Avatar>
            )}

            {/* Bubble */}
            {(() => {
              const isStructured = !isUser && msg.responseType && msg.responseType !== 'text';
              return (
            <Box sx={{
              maxWidth: isUser ? '70%' : (isStructured ? '95%' : '70%'),
              ...(isStructured
                ? { p: 0, borderRadius: 2, overflow: 'hidden', color: '#374151' }
                : {
                    px: 2, py: 1.5,
                    borderRadius: isUser ? '16px 16px 4px 16px' : '16px 16px 16px 4px',
                    bgcolor: isUser ? '#1a1e4a' : '#f8f9fa',
                    color: isUser ? '#ffffff' : '#374151',
                    border: isUser ? 'none' : '1px solid #f0ede6',
                  }),
            }}>
              {isUser ? (
                <Typography sx={{ fontSize: '0.85rem', lineHeight: 1.6, whiteSpace: 'pre-wrap' }}>
                  {msg.content}
                </Typography>
              ) : (
                <ResponseRenderer
                  content={msg.content}
                  responseType={msg.responseType}
                  data={msg.data}
                  onFormSubmit={onFormSubmit}
                  onSuggestionClick={onSuggestionClick}
                />
              )}
            </Box>
              );
            })()}
          </Box>
        );
      })}
      <div ref={endRef} />
    </Box>
  );
};

export default ChatConversation;

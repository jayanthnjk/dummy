import React, { useState, useRef, useCallback, useEffect } from 'react';
import {
  Box,
  InputBase,
  Typography,
  CircularProgress,
  Paper,
  ClickAwayListener,
  Chip,
  alpha,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import HistoryIcon from '@mui/icons-material/History';
import PersonIcon from '@mui/icons-material/Person';
import CloseIcon from '@mui/icons-material/Close';
import { sectionChartService, type PersonnelSearchResult } from '@/services/sectionChartService';

interface PersonnelSearchBoxProps {
  onSelect: (person: PersonnelSearchResult) => void;
  onCancel?: () => void;
  placeholder?: string;
  autoFocus?: boolean;
  showCancelButton?: boolean;
  variant?: 'default' | 'compact';
  width?: number | string;
  maxResults?: number;
}

const PersonnelSearchBox: React.FC<PersonnelSearchBoxProps> = ({
  onSelect,
  onCancel,
  placeholder = 'Search by name or badge ID...',
  autoFocus = false,
  showCancelButton = false,
  variant = 'default',
  width = '100%',
  maxResults = 10,
}) => {
  const [inputValue, setInputValue] = useState('');
  const [options, setOptions] = useState<PersonnelSearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [focusedIndex, setFocusedIndex] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const searchPersonnel = useCallback(async (query: string) => {
    if (query.length < 2) {
      setOptions([]);
      return;
    }
    setLoading(true);
    try {
      const results = await sectionChartService.searchPersonnel(query, maxResults);
      setOptions(results);
    } catch {
      setOptions([]);
    } finally {
      setLoading(false);
    }
  }, [maxResults]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setInputValue(value);
    setIsOpen(true);
    setFocusedIndex(-1);
    
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => searchPersonnel(value), 250);
  };

  const handleSelect = (person: PersonnelSearchResult) => {
    onSelect(person);
    setInputValue('');
    setOptions([]);
    setIsOpen(false);
    setFocusedIndex(-1);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!isOpen || options.length === 0) {
      if (e.key === 'Escape' && onCancel) {
        onCancel();
      }
      return;
    }

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setFocusedIndex(prev => (prev < options.length - 1 ? prev + 1 : 0));
        break;
      case 'ArrowUp':
        e.preventDefault();
        setFocusedIndex(prev => (prev > 0 ? prev - 1 : options.length - 1));
        break;
      case 'Enter':
        e.preventDefault();
        if (focusedIndex >= 0 && focusedIndex < options.length) {
          handleSelect(options[focusedIndex]);
        }
        break;
      case 'Escape':
        setIsOpen(false);
        setFocusedIndex(-1);
        if (onCancel) onCancel();
        break;
    }
  };

  const handleClickAway = () => {
    setIsOpen(false);
    setFocusedIndex(-1);
  };

  const handleFocus = () => {
    setIsOpen(true);
  };

  const handleClear = () => {
    setInputValue('');
    setOptions([]);
    setIsOpen(false);
    inputRef.current?.focus();
  };

  useEffect(() => {
    if (autoFocus && inputRef.current) {
      inputRef.current.focus();
    }
  }, [autoFocus]);

  const isCompact = variant === 'compact';
  const hasResults = options.length > 0;
  const showDropdown = isOpen && (inputValue.length >= 2 || loading);

  return (
    <ClickAwayListener onClickAway={handleClickAway}>
      <Box
        ref={containerRef}
        sx={{
          position: 'relative',
          width,
          display: 'flex',
          alignItems: 'center',
          gap: showCancelButton ? 0.5 : 0,
        }}
      >
        <Box sx={{ flex: 1, position: 'relative' }}>
          <Paper
            elevation={showDropdown ? 3 : 0}
            sx={{
              borderRadius: showDropdown ? '24px 24px 0 0' : '24px',
              border: showDropdown ? 'none' : '1px solid #dfe1e5',
              overflow: 'hidden',
              transition: 'box-shadow 0.2s, border-radius 0.2s',
              '&:hover': {
                boxShadow: showDropdown ? undefined : '0 1px 6px rgba(32,33,36,0.28)',
                borderColor: showDropdown ? undefined : 'transparent',
              },
              '&:focus-within': {
                boxShadow: showDropdown ? undefined : '0 1px 6px rgba(32,33,36,0.28)',
                borderColor: showDropdown ? undefined : 'transparent',
              },
            }}
          >
            {/* Search Input */}
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                px: 2,
                py: isCompact ? 0.75 : 1,
                bgcolor: '#fff',
              }}
            >
              <SearchIcon 
                sx={{ 
                  color: '#9aa0a6', 
                  fontSize: isCompact ? 20 : 22,
                  mr: 1.5,
                }} 
              />
              <InputBase
                inputRef={inputRef}
                value={inputValue}
                onChange={handleInputChange}
                onKeyDown={handleKeyDown}
                onFocus={handleFocus}
                placeholder={placeholder}
                fullWidth
                sx={{
                  fontSize: isCompact ? '0.875rem' : '1rem',
                  '& input': {
                    p: 0,
                    '&::placeholder': {
                      color: '#9aa0a6',
                      opacity: 1,
                    },
                  },
                }}
              />
              {loading && (
                <CircularProgress size={18} sx={{ color: '#9aa0a6', ml: 1 }} />
              )}
              {inputValue && !loading && (
                <Box
                  onClick={handleClear}
                  sx={{
                    cursor: 'pointer',
                    p: 0.5,
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    '&:hover': { bgcolor: '#f1f3f4' },
                  }}
                >
                  <CloseIcon sx={{ fontSize: 18, color: '#70757a' }} />
                </Box>
              )}
            </Box>
          </Paper>

          {/* Results Dropdown - Absolutely positioned to overlay content */}
          {showDropdown && (
            <Paper
              elevation={4}
              sx={{
                position: 'absolute',
                top: '100%',
                left: 0,
                right: 0,
                zIndex: 1300,
                bgcolor: '#fff',
                maxHeight: 350,
                overflowY: 'auto',
                borderRadius: '0 0 24px 24px',
                boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
              }}
            >
              {inputValue.length < 2 ? (
                <Box sx={{ py: 2, px: 2.5 }}>
                  <Typography sx={{ fontSize: '0.85rem', color: '#70757a' }}>
                    Type at least 2 characters to search...
                  </Typography>
                </Box>
              ) : loading ? (
                <Box sx={{ py: 2.5, display: 'flex', justifyContent: 'center' }}>
                  <CircularProgress size={24} />
                </Box>
              ) : hasResults ? (
                <Box sx={{ py: 0.5 }}>
                  {options.map((person, index) => (
                    <Box
                      key={person.id}
                      onClick={() => handleSelect(person)}
                      sx={{
                        display: 'flex',
                        alignItems: 'center',
                        px: 2,
                        py: 1.25,
                        cursor: 'pointer',
                        bgcolor: focusedIndex === index ? '#f1f3f4' : 'transparent',
                        '&:hover': {
                          bgcolor: '#f1f3f4',
                        },
                      }}
                    >
                      <Box
                        sx={{
                          width: 28,
                          height: 28,
                          borderRadius: '50%',
                          bgcolor: alpha('#6366f1', 0.1),
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          mr: 1.5,
                          flexShrink: 0,
                        }}
                      >
                        <PersonIcon sx={{ fontSize: 16, color: '#6366f1' }} />
                      </Box>
                      <Box sx={{ flex: 1, minWidth: 0 }}>
                        <Typography
                          sx={{
                            fontSize: '0.9rem',
                            color: '#202124',
                            fontWeight: 500,
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap',
                          }}
                        >
                          {person.personName}
                        </Typography>
                        <Typography
                          sx={{
                            fontSize: '0.75rem',
                            color: '#70757a',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap',
                          }}
                        >
                          {person.badgeId || '—'} • {person.designation || 'No designation'}
                          {person.currentSection && ` • Section ${person.currentSection}`}
                        </Typography>
                      </Box>
                      {person.designation && (
                        <Chip
                          label={person.designation}
                          size="small"
                          sx={{
                            ml: 1,
                            height: 20,
                            fontSize: '0.65rem',
                            fontWeight: 600,
                            bgcolor: alpha('#6366f1', 0.1),
                            color: '#6366f1',
                            '& .MuiChip-label': { px: 1 },
                          }}
                        />
                      )}
                    </Box>
                  ))}
                </Box>
              ) : (
                <Box sx={{ py: 2.5, px: 2.5 }}>
                  <Typography sx={{ fontSize: '0.85rem', color: '#70757a', textAlign: 'center' }}>
                    No personnel found for "{inputValue}"
                  </Typography>
                </Box>
              )}
            </Paper>
          )}
        </Box>

        {/* Cancel Button (optional) */}
        {showCancelButton && onCancel && (
          <Box
            onClick={onCancel}
            sx={{
              cursor: 'pointer',
              px: 1,
              py: 0.5,
              borderRadius: 1,
              color: '#70757a',
              fontSize: '0.8rem',
              fontWeight: 500,
              '&:hover': { bgcolor: '#f1f3f4', color: '#202124' },
            }}
          >
            Cancel
          </Box>
        )}
      </Box>
    </ClickAwayListener>
  );
};

export default PersonnelSearchBox;
